"""Native single-rule keys, distinct from transformation-family equivalence."""

from functools import lru_cache


@lru_cache(maxsize=32768)
def rule_querycgr_identity(rule_smarts: str) -> str:
    """Return SynPlanner's canonical QueryCGR key for legacy SMARTS input.

    Production extraction computes this key directly from the extracted rule object.
    This parser-backed helper is retained for compatibility with callers that only
    have historical rule SMARTS.
    """
    try:
        from chython import smarts
        from synplan.chem.utils import canonical_query_cgr_key

        return canonical_query_cgr_key(~smarts(rule_smarts))
    except Exception:
        # Historical artifacts may contain serializer output that Chython cannot
        # parse back. Keep such text distinct instead of applying a lossy key.
        return f"unparsed_smarts:{rule_smarts}"


def rule_queries_are_isomorphic(left_rule: str, right_rule: str) -> bool:
    """Compare two legacy SMARTS through SynPlanner's native QueryCGR key."""
    return rule_querycgr_identity(left_rule) == rule_querycgr_identity(right_rule)
