"""Resolved chemistry configuration evidence and dependency versions."""

import json
from dataclasses import asdict, dataclass
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, Mapping


def _config_value(value: Any) -> Any:
    """Convert resolved configuration values without lossy object reprs."""

    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _config_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_config_value(item) for item in value]
    if type(value).__module__.startswith("chython"):
        return {
            "object_type": f"{type(value).__module__}.{type(value).__qualname__}",
            "query_smarts": str(value),
        }
    raise TypeError(
        "unsupported resolved configuration value: "
        f"{type(value).__module__}.{type(value).__qualname__}"
    )


def dependency_version(distribution: str) -> str:
    try:
        return version(distribution)
    except PackageNotFoundError:
        return "unknown"


def resolved_config_mapping(config: Any) -> dict[str, Any]:
    """Serialize resolved configuration, retaining paths as stable strings."""

    if hasattr(config, "model_dump"):
        try:
            value = config.model_dump(mode="python", warnings=False)
        except TypeError:
            value = config.model_dump()
    elif hasattr(config, "dict"):
        value = config.dict()
    else:
        value = asdict(config)
    normalized = _config_value(value)
    return json.loads(
        json.dumps(
            normalized,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
    )


@dataclass(kw_only=True)
class RuleExtractionSettings:
    """Shared extraction settings, independent of CLI argument containers."""

    config: Path | None = None
    environment_atom_count: int = 1
    include_rings: bool = False
    keep_leaving_groups: bool = True
    keep_incoming_groups: bool = False
    reactor_validation: bool = False


def rule_extractor_args_dict(args: RuleExtractionSettings) -> dict[str, Any]:
    """Return rule extractor args dict used for rule extraction or comparison.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    return {
        "config": str(args.config) if getattr(args, "config", None) else None,
        "environment_atom_count": getattr(args, "environment_atom_count", 1),
        "include_rings": getattr(args, "include_rings", False),
        "keep_leaving_groups": getattr(args, "keep_leaving_groups", True),
        "keep_incoming_groups": getattr(args, "keep_incoming_groups", False),
        "reactor_validation": getattr(args, "reactor_validation", False),
    }
