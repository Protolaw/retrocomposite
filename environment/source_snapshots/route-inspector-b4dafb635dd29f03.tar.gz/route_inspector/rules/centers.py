"""Reaction-side center projections shared by rule preparation."""

from typing import Any, Iterable

from route_inspector.rules.models import MoleculeCenterProjection


def side_center_molecules(
    molecules: Iterable[Any],
    center_atoms: frozenset[int],
) -> tuple[MoleculeCenterProjection, ...]:
    """Find reactant or product molecules that contain reaction-center atoms.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    projections = []
    for molecule in molecules:
        molecule_center_atoms = center_atoms & set(molecule)
        projections.append(
            MoleculeCenterProjection(
                molecule=molecule,
                center_atoms=frozenset(molecule_center_atoms),
            )
        )
    return tuple(projections)
