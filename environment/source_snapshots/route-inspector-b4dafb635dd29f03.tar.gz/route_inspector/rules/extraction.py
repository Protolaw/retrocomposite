"""SynPlanner-backed reaction-rule chemistry extraction and serialization."""

from __future__ import annotations

from itertools import islice
from typing import Any, Iterable

from route_inspector import chemistry
from route_inspector.chemistry.standardization import (
    resolve_remove_reagents_standardizer,
)
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.rules.centers import side_center_molecules
from route_inspector.rules.config import RuleExtractionSettings
from route_inspector.rules.identity import rule_querycgr_identity
from route_inspector.rules.models import (
    MoleculeCenterProjection,
    ReactionRuleStep,
    RuleExtractionError,
)


def base_rule_atom_maps_from_standardized_reaction(
    config: Any,
    reaction: Any,
    *,
    restricted_center_atoms: set[int] | None = None,
) -> frozenset[int]:
    """Return the rule atom mask obtained by skipping only FG expansion.

    The ordering deliberately mirrors SynPlanner ``create_rule``: reaction
    environment, optional rings, then leaving/incoming atoms.  It operates on
    the same standardized reaction used to create the context-bearing rule.
    """

    from synplan.chem.reaction.rules.extraction import (
        add_environment_atoms,
        add_leaving_incoming_groups,
        add_ring_structures,
    )

    cgr = ~reaction
    center_atoms = (
        set(cgr.center_atoms)
        if restricted_center_atoms is None
        else set(restricted_center_atoms)
    )
    rule_atoms = add_environment_atoms(
        cgr,
        center_atoms,
        config.environment_atom_count,
    )
    if config.include_rings:
        rule_atoms = add_ring_structures(cgr, rule_atoms)
    rule_atoms, _metadata = add_leaving_incoming_groups(
        reaction,
        rule_atoms,
        config.keep_leaving_groups,
        config.keep_incoming_groups,
    )
    return frozenset(int(atom_map) for atom_map in rule_atoms)


def crop_query_cgr_preserving_labels(
    query_cgr: Any,
    atom_maps: Iterable[int],
) -> Any:
    """Crop a live QueryCGR without weakening its graph-level query labels.

    Chython substructure reconstruction can both weaken graph-level labels and
    reject valid live atoms whose current/product hybridization query tuples
    have different lengths. Copy the validated live graph and delete excluded
    atoms instead; this preserves every retained label without asking the
    constructor to reinterpret it.
    """

    retained = frozenset(int(atom_map) for atom_map in atom_maps)
    cropped = query_cgr.copy()
    for atom_map in tuple(cropped):
        if atom_map not in retained:
            cropped.delete_atom(atom_map)
    cropped.flush_cache()
    return cropped


class SynPlannerRuleExtractor:
    def __init__(self, config: Any):
        """Initialize this object with its resolved configuration.

        The helper feeds rule extraction, center-overlap filtering, or final TSV
        aggregation without changing the original route JSON in place.
        """
        self.config = config
        standardizer_type = resolve_remove_reagents_standardizer()
        self.standardizer = standardizer_type()
        self.cache: dict[str, ReactionRuleStep | None] = {}

    @classmethod
    def from_args(cls, args: RuleExtractionSettings) -> "SynPlannerRuleExtractor":
        """Build an extractor instance from parsed CLI arguments.

        The helper feeds rule extraction, center-overlap filtering, or final TSV
        aggregation without changing the original route JSON in place.
        """
        from synplan.utils.config import RuleExtractionConfig

        if args.config:
            config = RuleExtractionConfig.from_yaml(
                str(resolve_existing_path(args.config))
            )
        else:
            config = RuleExtractionConfig(
                ignore_stereo=True,
                min_popularity=1,
                single_product_only=True,
                environment_atom_count=args.environment_atom_count,
                multicenter_rules=True,
                include_rings=args.include_rings,
                include_func_groups=False,
                keep_leaving_groups=args.keep_leaving_groups,
                keep_incoming_groups=args.keep_incoming_groups,
                keep_reagents=False,
                reactor_validation=args.reactor_validation,
            )
        return cls(config)

    def extract(self, reaction_smiles: str) -> tuple[ReactionRuleStep | None, bool]:
        """Extract one rule from a mapped reaction SMILES string.

        The helper feeds rule extraction, center-overlap filtering, or final TSV
        aggregation without changing the original route JSON in place.
        """

        if reaction_smiles in self.cache:
            if getattr(self, "evidence", None) is not None:
                self.evidence.record(
                    "single", reaction_smiles, self.cache[reaction_smiles]
                )
            return self.cache[reaction_smiles], True

        from chython import smiles as parse_smiles
        from synplan.chem.reaction.rules.extraction import (
            _rule_to_reactor_smarts,
            create_rule,
        )
        from synplan.chem.utils import canonical_query_cgr_key

        reaction = parse_smiles(reaction_smiles)
        if self.config.ignore_stereo:
            reaction = reaction.copy()
            reaction.clean_stereo()
        standardized = self.standardizer(reaction)
        if self.config.single_product_only and len(standardized.products) != 1:
            self.cache[reaction_smiles] = None
            if getattr(self, "evidence", None) is not None:
                self.evidence.record("single", reaction_smiles, None)
            return None, False

        cgr = ~standardized
        candidates: list[tuple[Any, set[int] | None]]
        if self.config.multicenter_rules:
            candidates = [(create_rule(self.config, standardized), None)]
        else:
            candidates_by_cgr: dict[Any, tuple[Any, set[int]]] = {}
            center_components = [
                set(component) for component in islice(cgr.centers_list, 15)
            ]
            skip_full_validation = len(center_components) > 1
            for component in center_components:
                rule = create_rule(
                    self.config,
                    standardized,
                    _restrict_center_atoms=component,
                    _skip_full_reaction_validation=skip_full_validation,
                )
                candidates_by_cgr.setdefault(~rule, (rule, component))
            candidates = list(candidates_by_cgr.values())

        center_atoms = frozenset((~standardized).center_atoms)
        reactant_center_molecules = side_center_molecules(
            standardized.reactants,
            center_atoms,
        )
        product_center_molecules = side_center_molecules(
            standardized.products,
            center_atoms,
        )
        if not candidates:
            self.cache[reaction_smiles] = None
            if getattr(self, "evidence", None) is not None:
                self.evidence.record("single", reaction_smiles, None)
            return None, False
        if len(candidates) != 1:
            raise RuleExtractionError(
                "rrseq extraction expects one multicenter rule per reaction; "
                f"got {len(candidates)} rules"
            )

        rule, restricted_center_atoms = candidates[0]
        query_cgr = ~rule
        query_cgr_key = canonical_query_cgr_key(query_cgr)
        base_rule_atom_maps = base_rule_atom_maps_from_standardized_reaction(
            self.config,
            standardized,
            restricted_center_atoms=restricted_center_atoms,
        )
        context_rule_atom_maps = frozenset(int(atom_map) for atom_map in query_cgr)
        if not base_rule_atom_maps <= context_rule_atom_maps:
            missing = sorted(base_rule_atom_maps - context_rule_atom_maps)
            raise RuleExtractionError(
                "base rule atom mask is not a subset of the context rule; "
                f"missing atom maps={missing}"
            )
        base_query_cgr = crop_query_cgr_preserving_labels(
            query_cgr,
            base_rule_atom_maps,
        )
        base_query_cgr_key = canonical_query_cgr_key(base_query_cgr)
        from route_inspector.rules.transformation import capture_rule

        transformation = capture_rule(rule, query_cgr_key)
        rule_smarts = _rule_to_reactor_smarts(rule)
        step = ReactionRuleStep(
            rule_smarts=rule_smarts,
            center_atoms=center_atoms,
            reaction_smiles=reaction_smiles,
            reactant_center_molecules=reactant_center_molecules,
            product_center_molecules=product_center_molecules,
            query_cgr_key=query_cgr_key,
            transformation=transformation,
            base_query_cgr_key=base_query_cgr_key,
            base_rule_atom_maps=base_rule_atom_maps,
        )
        self.cache[reaction_smiles] = step
        if getattr(self, "evidence", None) is not None:
            self.evidence.record("single", reaction_smiles, step)
        return step, False


SerializedReactionRuleStep = dict[str, Any]


def serialize_center_projection(
    projection: MoleculeCenterProjection,
) -> tuple[str, tuple[int, ...]]:
    """Serialize center projection for worker-safe transport.

    Serialization keeps rule-step metadata small enough to pass through worker processes
    and stable enough for later TSV aggregation.
    """
    return (
        format(projection.molecule, "m"),
        tuple(sorted(projection.center_atoms)),
    )


def deserialize_center_projection(
    serialized: tuple[str, tuple[int, ...]],
) -> MoleculeCenterProjection:
    """Deserialize center projection from worker output.

    Serialization keeps rule-step metadata small enough to pass through worker processes
    and stable enough for later TSV aggregation.
    """
    molecule_smiles, center_atoms = serialized
    return MoleculeCenterProjection(
        molecule=chemistry.parse_molecule(molecule_smiles),
        center_atoms=frozenset(center_atoms),
    )


def serialize_reaction_rule_step(
    step: ReactionRuleStep,
    *,
    include_transformation: bool = True,
) -> SerializedReactionRuleStep:
    """Serialize reaction rule step for worker-safe transport.

    Serialization keeps rule-step metadata small enough to pass through worker processes
    and stable enough for later TSV aggregation.
    """
    return {
        "rule_smarts": step.rule_smarts,
        "query_cgr_key": step.query_cgr_key,
        **({"transformation": step.transformation} if include_transformation else {}),
        "base_query_cgr_key": step.base_query_cgr_key,
        "base_rule_atom_maps": tuple(sorted(step.base_rule_atom_maps)),
        "center_atoms": tuple(sorted(step.center_atoms)),
        "reaction_smiles": step.reaction_smiles,
        "reactant_center_molecules": tuple(
            serialize_center_projection(projection)
            for projection in step.reactant_center_molecules
        ),
        "product_center_molecules": tuple(
            serialize_center_projection(projection)
            for projection in step.product_center_molecules
        ),
    }


def deserialize_reaction_rule_step(
    serialized: SerializedReactionRuleStep,
) -> ReactionRuleStep:
    """Deserialize reaction rule step from worker output.

    Serialization keeps rule-step metadata small enough to pass through worker processes
    and stable enough for later TSV aggregation.
    """
    return ReactionRuleStep(
        rule_smarts=serialized["rule_smarts"],
        query_cgr_key=(
            serialized.get("query_cgr_key")
            or rule_querycgr_identity(serialized["rule_smarts"])
        ),
        base_query_cgr_key=str(serialized.get("base_query_cgr_key") or ""),
        transformation=dict(serialized.get("transformation") or {}),
        base_rule_atom_maps=frozenset(
            int(atom_map) for atom_map in serialized.get("base_rule_atom_maps", ())
        ),
        center_atoms=frozenset(serialized["center_atoms"]),
        reaction_smiles=serialized["reaction_smiles"],
        reactant_center_molecules=tuple(
            deserialize_center_projection(projection)
            for projection in serialized["reactant_center_molecules"]
        ),
        product_center_molecules=tuple(
            deserialize_center_projection(projection)
            for projection in serialized["product_center_molecules"]
        ),
    )


class PrecomputedRuleExtractor:
    def __init__(
        self,
        serialized_steps_by_reaction: dict[str, SerializedReactionRuleStep | None],
        errors_by_reaction: dict[str, dict[str, str]] | None = None,
    ):
        """Initialize this object with its resolved configuration.

        The helper feeds rule extraction, center-overlap filtering, or final TSV
        aggregation without changing the original route JSON in place.
        """
        self.serialized_steps_by_reaction = serialized_steps_by_reaction
        self.errors_by_reaction = errors_by_reaction or {}
        self.cache: dict[str, ReactionRuleStep | None] = {}

    def extract(self, reaction_smiles: str) -> tuple[ReactionRuleStep | None, bool]:
        """Extract one rule from a mapped reaction SMILES string.

        The helper feeds rule extraction, center-overlap filtering, or final TSV
        aggregation without changing the original route JSON in place.
        """
        if reaction_smiles in self.errors_by_reaction:
            error = self.errors_by_reaction[reaction_smiles]
            raise RuleExtractionError(
                f"precomputed unique reaction extraction failed: "
                f"{error['error_type']}: {error['message']}"
            )
        if reaction_smiles in self.cache:
            return self.cache[reaction_smiles], True
        if reaction_smiles not in self.serialized_steps_by_reaction:
            raise KeyError("reaction was not present in the precomputed rule cache")

        serialized = self.serialized_steps_by_reaction[reaction_smiles]
        step = deserialize_reaction_rule_step(serialized) if serialized else None
        self.cache[reaction_smiles] = step
        return step, True


__all__ = [
    "PrecomputedRuleExtractor",
    "SerializedReactionRuleStep",
    "SynPlannerRuleExtractor",
    "base_rule_atom_maps_from_standardized_reaction",
    "crop_query_cgr_preserving_labels",
    "deserialize_center_projection",
    "deserialize_reaction_rule_step",
    "serialize_center_projection",
    "serialize_reaction_rule_step",
]
