"""One-pass route normalization and occurrence-local RRSeq preparation."""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import replace
from typing import Any, Iterable, Mapping

import route_inspector.routes.access as route_access
from route_inspector import chemistry
from route_inspector.datasets.paroutes.source_ids import PAROUTES_SOURCE_ID_ADAPTER
from route_inspector.datasets.source_ids import reaction_source_identifiers
from route_inspector.infrastructure.artifacts import dataset_prefix_from_path
from route_inspector.routes import normalization as routes
from route_inspector.routes.provenance import raw_source_record_id
from route_inspector.rules.identity import rule_querycgr_identity
from route_inspector.rules.models import (
    LocatedReactionRuleStep,
    PreparedRootReactionPaths,
    PreparedRouteRuleData,
    ReactionNodeOccurrenceContext,
    ReactionPathStep,
    ReactionRuleStep,
    RouteProcessingStats,
    RuleExtractionError,
)
from route_inspector.rules.occurrences import (
    SingleRuleOccurrence,
    stable_single_rule_occurrence_id,
)


def child_reaction_nodes(reaction_node: dict[str, Any]) -> list[dict[str, Any]]:
    """Return reaction children directly below a route reaction node.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    children = []
    for mol_node in reaction_node.get("children", []) or []:
        if mol_node.get("type") != "mol":
            continue
        for child in mol_node.get("children", []) or []:
            if child.get("type") == "reaction":
                children.append(child)
    return children


def root_reaction_nodes(route: dict[str, Any]) -> list[dict[str, Any]]:
    """Return top-level reaction nodes below the target molecule.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    return [
        child
        for child in route.get("children", []) or []
        if isinstance(child, dict) and child.get("type") == "reaction"
    ]


def route_target_smiles(route: dict[str, Any]) -> str:
    """Return route target SMILES from a normalized route tree.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    metadata = route.get("metadata") or {}
    return (
        metadata.get("original_smiles")
        or route.get("smiles")
        or metadata.get("smiles")
        or ""
    )


def reaction_paths_from_node(
    reaction_node: dict[str, Any],
    step_by_reaction_smiles: dict[str, ReactionRuleStep],
) -> list[list[ReactionRuleStep]]:
    """Read reaction paths stored on a route node.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    step = step_by_reaction_smiles[
        route_access.reaction_smiles_from_node(reaction_node)
    ]
    children = child_reaction_nodes(reaction_node)
    if not children:
        return [[step]]

    paths: list[list[ReactionRuleStep]] = []
    for child in children:
        for suffix in reaction_paths_from_node(child, step_by_reaction_smiles):
            paths.append([step] + suffix)
    return paths


def located_reaction_paths_from_node(
    reaction_node: dict[str, Any],
    reaction_node_path: tuple[int, ...],
    target_molecule_path: tuple[int, ...],
    step_by_reaction_smiles: dict[str, ReactionRuleStep],
    *,
    step_by_reaction_path: Mapping[tuple[int, ...], ReactionRuleStep] | None = None,
    source_id_adapter: str = PAROUTES_SOURCE_ID_ADAPTER,
) -> list[list[LocatedReactionRuleStep]]:
    """Return route reaction paths while retaining exact tree-node provenance.

    Unlike the stricter consecutive-occurrence traversal, this helper does not
    rematch reaction components.  It therefore preserves the historical gapped
    extraction domain, branch order, and occurrence identities while adding the
    paths needed to audit and visualize selected and skipped steps.
    """

    template = step_by_reaction_smiles[
        route_access.reaction_smiles_from_node(reaction_node)
    ]
    step = (
        step_by_reaction_path.get(reaction_node_path, template)
        if step_by_reaction_path is not None
        else template
    )
    source_ids = reaction_source_identifiers(
        reaction_node,
        adapter=source_id_adapter,
    )
    metadata = reaction_node.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}
    located_step = LocatedReactionRuleStep(
        step=step,
        reaction_node_path=reaction_node_path,
        target_molecule_path=target_molecule_path,
        raw_source_record_id=raw_source_record_id(metadata),
        source_record_id=source_ids.source_record_id,
        source_document_id=source_ids.source_document_id,
        source_id_adapter=source_ids.adapter,
    )
    child_reactions: list[tuple[dict[str, Any], tuple[int, ...], tuple[int, ...]]] = []
    for molecule_index, molecule_node in enumerate(
        reaction_node.get("children", []) or []
    ):
        if not isinstance(molecule_node, dict) or molecule_node.get("type") != "mol":
            continue
        molecule_path = reaction_node_path + (molecule_index,)
        for reaction_index, child in enumerate(molecule_node.get("children", []) or []):
            if isinstance(child, dict) and child.get("type") == "reaction":
                child_reactions.append(
                    (
                        child,
                        molecule_path + (reaction_index,),
                        molecule_path,
                    )
                )
    if not child_reactions:
        return [[located_step]]

    paths: list[list[LocatedReactionRuleStep]] = []
    for child, child_path, molecule_path in child_reactions:
        for suffix in located_reaction_paths_from_node(
            child,
            child_path,
            molecule_path,
            step_by_reaction_smiles,
            step_by_reaction_path=step_by_reaction_path,
            source_id_adapter=source_id_adapter,
        ):
            paths.append([located_step, *suffix])
    return paths


def _mapping_pairs(
    source: Any | None, target: Any | None
) -> tuple[tuple[int, int], ...]:
    """Return one deterministic source-to-target atom alignment witness."""

    if source is None or target is None:
        return ()
    identity_mapping = chemistry.exact_map_identity_mapping(source, target)
    if identity_mapping is not None:
        return identity_mapping
    try:
        mapping = next(iter(source.get_mapping(target)))
    except Exception:
        return ()
    return tuple(
        sorted(
            (int(source_atom), int(target_atom))
            for source_atom, target_atom in mapping.items()
        )
    )


def root_reaction_nodes_with_paths(
    route: dict[str, Any],
) -> list[tuple[int, tuple[int, ...], dict[str, Any]]]:
    """Return root reactions with display indices and absolute tree paths."""

    roots = []
    root_index = 0
    for child_index, child in enumerate(route.get("children", []) or []):
        if isinstance(child, dict) and child.get("type") == "reaction":
            roots.append((root_index, (child_index,), child))
            root_index += 1
    return roots


def _structural_reaction_paths_from_node(
    reaction_node: dict[str, Any],
    reaction_node_path: tuple[int, ...],
) -> list[list[tuple[int, ...]]]:
    """Enumerate root-to-leaf reaction-node paths without chemistry rematching."""

    child_reactions: list[tuple[dict[str, Any], tuple[int, ...]]] = []
    for molecule_index, molecule_node in enumerate(
        reaction_node.get("children", []) or []
    ):
        if not isinstance(molecule_node, dict) or molecule_node.get("type") != "mol":
            continue
        molecule_path = reaction_node_path + (molecule_index,)
        for child_index, child in enumerate(molecule_node.get("children", []) or []):
            if isinstance(child, dict) and child.get("type") == "reaction":
                child_reactions.append((child, molecule_path + (child_index,)))
    if not child_reactions:
        return [[reaction_node_path]]

    paths: list[list[tuple[int, ...]]] = []
    for child, child_path in child_reactions:
        for suffix in _structural_reaction_paths_from_node(child, child_path):
            paths.append([reaction_node_path, *suffix])
    return paths


def collect_reaction_occurrence_contexts(
    route: dict[str, Any],
) -> list[ReactionNodeOccurrenceContext]:
    """Collect every exact reaction node with route-tree branch memberships."""

    branch_memberships: dict[tuple[int, tuple[int, ...]], set[int]] = defaultdict(set)
    for root_index, root_path, root in root_reaction_nodes_with_paths(route):
        for branch_index, path in enumerate(
            _structural_reaction_paths_from_node(root, root_path)
        ):
            for reaction_path in path:
                branch_memberships[(root_index, reaction_path)].add(branch_index)

    contexts: list[ReactionNodeOccurrenceContext] = []

    def visit_reaction(
        reaction_node: dict[str, Any],
        reaction_path: tuple[int, ...],
        target_node: dict[str, Any],
        target_path: tuple[int, ...],
        root_index: int,
    ) -> None:
        contexts.append(
            ReactionNodeOccurrenceContext(
                reaction_smiles=route_access.reaction_smiles_from_node(reaction_node),
                target_smiles=route_access.molecule_node_smiles(target_node),
                reaction_node_path=reaction_path,
                target_molecule_path=target_path,
                reaction_node=reaction_node,
                root_index=root_index,
                branch_indices=tuple(
                    sorted(branch_memberships[(root_index, reaction_path)])
                ),
            )
        )
        for molecule_index, molecule_node in enumerate(
            reaction_node.get("children", []) or []
        ):
            if (
                not isinstance(molecule_node, dict)
                or molecule_node.get("type") != "mol"
            ):
                continue
            molecule_path = reaction_path + (molecule_index,)
            for child_index, child in enumerate(
                molecule_node.get("children", []) or []
            ):
                if isinstance(child, dict) and child.get("type") == "reaction":
                    visit_reaction(
                        child,
                        molecule_path + (child_index,),
                        molecule_node,
                        molecule_path,
                        root_index,
                    )

    for root_index, root_path, root in root_reaction_nodes_with_paths(route):
        visit_reaction(root, root_path, route, (), root_index)
    return contexts


def exact_single_rule_occurrence(
    occurrence_context: ReactionNodeOccurrenceContext,
    step: ReactionRuleStep,
    *,
    dataset_id: str,
    source_identity: str,
    route_id: Any,
    route_target: str,
    source_id_adapter: str = PAROUTES_SOURCE_ID_ADAPTER,
) -> SingleRuleOccurrence:
    """Build one authoritative t1 record from a native extracted step."""

    if not step.query_cgr_key:
        raise RuleExtractionError(
            "exact single-rule occurrence requires a native context QueryCGR key"
        )
    if not step.base_query_cgr_key:
        raise RuleExtractionError(
            "exact single-rule occurrence requires a native base QueryCGR key"
        )
    source_ids = reaction_source_identifiers(
        occurrence_context.reaction_node,
        adapter=source_id_adapter,
    )
    metadata = occurrence_context.reaction_node.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}
    route_id_text = str(route_id)
    return SingleRuleOccurrence(
        occurrence_id=stable_single_rule_occurrence_id(
            source_identity=source_identity,
            route_id=route_id_text,
            reaction_node_path=occurrence_context.reaction_node_path,
        ),
        dataset_id=dataset_id,
        source_identity=source_identity,
        route_id=route_id_text,
        route_target_smiles=route_target,
        target_smiles=occurrence_context.target_smiles,
        root_index=occurrence_context.root_index,
        branch_indices=occurrence_context.branch_indices,
        reaction_node_path=occurrence_context.reaction_node_path,
        target_molecule_path=occurrence_context.target_molecule_path,
        rule_smarts=step.rule_smarts,
        reaction_smiles=occurrence_context.reaction_smiles,
        center_atom_maps=tuple(sorted(step.center_atoms)),
        query_cgr_key=step.query_cgr_key,
        base_query_cgr_key=step.base_query_cgr_key,
        base_rule_atom_maps=tuple(sorted(step.base_rule_atom_maps)),
        raw_source_record_id=raw_source_record_id(metadata),
        source_record_id=source_ids.source_record_id,
        source_document_id=source_ids.source_document_id,
        source_id_adapter=source_ids.adapter,
    )


def _historical_reaction_node_paths(
    occurrence: Mapping[str, Any],
) -> set[tuple[int, ...]]:
    """Return every exact reaction path carried by a legacy occurrence."""

    paths: set[tuple[int, ...]] = set()
    path = occurrence.get("reaction_node_path")
    if path is not None:
        paths.add(tuple(int(index) for index in path))
    for value in occurrence.get("reaction_node_paths", ()) or ():
        paths.add(tuple(int(index) for index in value))
    for collection in ("source_matches", "selected_steps", "skipped_steps"):
        for step in occurrence.get(collection, ()) or ():
            value = step.get("reaction_node_path")
            if value is not None:
                paths.add(tuple(int(index) for index in value))
    return paths


def reconstruct_single_rule_occurrences_from_clean_routes(
    routes_json: Any,
    rule_extractor: Any,
    *,
    dataset_id: str | None = None,
    source_identity: str,
    historical_occurrences: Iterable[Mapping[str, Any]] = (),
    source_id_adapter: str = PAROUTES_SOURCE_ID_ADAPTER,
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    """Reconstruct exact t1 evidence from clean routes with one extraction per reaction.

    Historical occurrence payloads are used only to validate their node provenance.
    No canonical key or serialized SMARTS is inverted, and no second no-FG rule is
    extracted: the supplied context-bearing extractor derives both identities in its
    single standardized pass.
    """

    contexts_by_route: list[tuple[Any, str, list[ReactionNodeOccurrenceContext]]] = []
    unique_reactions: set[str] = set()
    for route_id, route in route_access.route_items(routes_json):
        normalized_route = routes.normalized_route_for_analysis(route)
        contexts = collect_reaction_occurrence_contexts(normalized_route)
        contexts_by_route.append(
            (route_id, route_target_smiles(normalized_route), contexts)
        )
        unique_reactions.update(context.reaction_smiles for context in contexts)

    steps_by_reaction: dict[str, ReactionRuleStep | None] = {}
    extracted = 0
    skipped = 0
    for reaction_smiles in sorted(unique_reactions):
        step, _cache_hit = rule_extractor.extract(reaction_smiles)
        steps_by_reaction[reaction_smiles] = step
        if step is None:
            skipped += 1
        else:
            extracted += 1

    skipped_contexts = [
        (str(route_id), context.reaction_node_path, context.reaction_smiles)
        for route_id, _route_target, contexts in contexts_by_route
        for context in contexts
        if steps_by_reaction[context.reaction_smiles] is None
    ]
    if skipped_contexts:
        diagnostics = "; ".join(
            "route_id="
            f"{route_id!r} reaction_node_path={list(reaction_path)!r} "
            f"reaction_smiles={reaction_smiles!r}"
            for route_id, reaction_path, reaction_smiles in skipped_contexts[:10]
        )
        remaining = len(skipped_contexts) - min(len(skipped_contexts), 10)
        if remaining:
            diagnostics += f"; ... and {remaining} more exact reaction occurrences"
        raise RuleExtractionError(
            "clean-route t1 reconstruction cannot omit reactions whose rule "
            f"extraction returned None: {diagnostics}"
        )

    effective_dataset_id = str(
        dataset_id
        or (dataset_prefix_from_path(source_identity) if source_identity else "")
    )
    records: list[dict[str, Any]] = []
    available_nodes: set[tuple[str, tuple[int, ...]]] = set()
    for route_id, route_target, contexts in contexts_by_route:
        route_id_text = str(route_id)
        for context in contexts:
            step = steps_by_reaction[context.reaction_smiles]
            if step is None:  # pragma: no cover - guarded above for type narrowing
                raise AssertionError("unreachable missing reconstructed t1 rule")
            record = exact_single_rule_occurrence(
                context,
                step,
                dataset_id=effective_dataset_id,
                source_identity=source_identity,
                route_id=route_id,
                route_target=route_target,
                source_id_adapter=source_id_adapter,
            )
            records.append(record.to_dict())
            available_nodes.add((route_id_text, context.reaction_node_path))

    legacy_nodes: set[tuple[str, tuple[int, ...]]] = set()
    for occurrence in historical_occurrences:
        route_id_text = str(occurrence.get("route_id", ""))
        legacy_nodes.update(
            (route_id_text, path)
            for path in _historical_reaction_node_paths(occurrence)
        )
    missing_nodes = sorted(legacy_nodes - available_nodes)
    if missing_nodes:
        raise ValueError(
            "historical occurrences reference reaction nodes absent from the "
            f"reconstructed t1 evidence: {missing_nodes[:10]}"
        )

    records.sort(key=lambda item: str(item["occurrence_id"]))
    return records, {
        "unique_reactions_seen": len(unique_reactions),
        "unique_reaction_rules_extracted": extracted,
        "unique_reaction_rules_skipped": skipped,
        "single_rule_occurrences": len(records),
        "historical_reaction_nodes_validated": len(legacy_nodes),
    }


def reaction_path_occurrences_from_node(
    reaction_node: dict[str, Any],
    reaction_node_path: tuple[int, ...],
    target_node: dict[str, Any],
    target_molecule_path: tuple[int, ...],
    step_by_reaction_smiles: dict[str, ReactionRuleStep],
    *,
    source_id_adapter: str = PAROUTES_SOURCE_ID_ADAPTER,
) -> list[list[ReactionPathStep]]:
    """Return exact route paths with node, component, and atom-match witnesses."""

    reaction_smiles = route_access.reaction_smiles_from_node(reaction_node)
    template_step = step_by_reaction_smiles[reaction_smiles]
    target_smiles = route_access.molecule_node_smiles(target_node)
    step = replace(template_step, target_smiles=target_smiles)
    reaction = chemistry.parse_reaction(step.reaction_smiles)
    target_molecule = chemistry.parse_molecule(target_smiles)
    product_index, product = chemistry.find_matching_molecule(
        reaction.products,
        target_molecule,
        fallback_smiles=target_smiles,
    )
    product_mapping = _mapping_pairs(product, target_molecule)
    if product_index is None or not product_mapping:
        raise ValueError(
            "could not preserve the source product-to-target match at path "
            f"{reaction_node_path}"
        )

    reactant_paths: list[tuple[int, ...] | None] = [None for _ in reaction.reactants]
    used_reactant_indexes: set[int] = set()
    edges: list[
        tuple[
            dict[str, Any],
            tuple[int, ...],
            dict[str, Any],
            tuple[int, ...],
            int,
            Any,
        ]
    ] = []
    for molecule_index, molecule_child in enumerate(
        reaction_node.get("children", []) or []
    ):
        if not isinstance(molecule_child, dict) or molecule_child.get("type") != "mol":
            continue
        molecule_path = reaction_node_path + (molecule_index,)
        reactant_index, reactant = chemistry.find_matching_molecule(
            reaction.reactants,
            None,
            fallback_smiles=route_access.molecule_node_smiles(molecule_child),
            excluded_indexes=used_reactant_indexes,
        )
        if reactant_index is None or reactant is None:
            raise ValueError(
                "ordinary RRseq source-leaf bijection invariant failed: "
                "route molecule child at path "
                f"{molecule_path} has no unique parsed reaction reactant"
            )
        used_reactant_indexes.add(reactant_index)
        reactant_paths[reactant_index] = molecule_path

        for child_index, child in enumerate(molecule_child.get("children", []) or []):
            if not isinstance(child, dict) or child.get("type") != "reaction":
                continue
            edges.append(
                (
                    child,
                    molecule_path + (child_index,),
                    molecule_child,
                    molecule_path,
                    reactant_index,
                    reactant,
                )
            )

    missing_reactant_indexes = [
        reactant_index
        for reactant_index, molecule_path in enumerate(reactant_paths)
        if molecule_path is None
    ]
    if missing_reactant_indexes:
        raise ValueError(
            "ordinary RRseq source-leaf bijection invariant failed: parsed "
            f"reaction reactant indices {missing_reactant_indexes} at path "
            f"{reaction_node_path} have no route molecule children"
        )

    source_ids = reaction_source_identifiers(
        reaction_node,
        adapter=source_id_adapter,
    )
    metadata = reaction_node.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}
    base = {
        "step": step,
        "reaction_node_path": reaction_node_path,
        "target_molecule_path": target_molecule_path,
        "product_index": product_index,
        "raw_source_record_id": raw_source_record_id(metadata),
        "source_record_id": source_ids.source_record_id,
        "source_document_id": source_ids.source_document_id,
        "source_id_adapter": source_ids.adapter,
        "product_to_target_atom_map": product_mapping,
        "reactant_molecule_paths": tuple(reactant_paths),
    }
    if not edges:
        return [[ReactionPathStep(**base)]]

    paths: list[list[ReactionPathStep]] = []
    for (
        child,
        child_path,
        molecule_child,
        molecule_path,
        reactant_index,
        reactant,
    ) in edges:
        suffixes = reaction_path_occurrences_from_node(
            child,
            child_path,
            molecule_child,
            molecule_path,
            step_by_reaction_smiles,
            source_id_adapter=source_id_adapter,
        )
        for suffix in suffixes:
            next_target = chemistry.parse_molecule(suffix[0].step.target_smiles)
            continuation_mapping = _mapping_pairs(reactant, next_target)
            if not continuation_mapping:
                raise ValueError(
                    "could not preserve the source continuation match at path "
                    f"{reaction_node_path}"
                )
            current = ReactionPathStep(
                **base,
                continuation_reactant_index=reactant_index,
                continuation_molecule_path=molecule_path,
                continuation_to_next_target_atom_map=continuation_mapping,
            )
            paths.append([current, *suffix])
    return paths


def collect_reaction_contexts(route: dict[str, Any]) -> list[tuple[str, str]]:
    """Collect reaction contexts from route-analysis input data.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    contexts: list[tuple[str, str]] = []

    def visit(node: dict[str, Any]) -> None:
        """Visit one route-tree node during recursive route traversal.

        The helper feeds rule extraction, center-overlap filtering, or final TSV
        aggregation without changing the original route JSON in place.
        """
        if node.get("type") == "mol":
            target_smiles = node.get("smiles", "")
            for child in node.get("children", []) or []:
                if isinstance(child, dict) and child.get("type") == "reaction":
                    contexts.append(
                        (route_access.reaction_smiles_from_node(child), target_smiles)
                    )
        for child in node.get("children", []) or []:
            if isinstance(child, dict):
                visit(child)

    visit(route)
    return contexts


def collect_reaction_smiles(route: dict[str, Any]) -> list[str]:
    """Collect reaction SMILES from route-analysis input data.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    return [reaction_smiles for reaction_smiles, _ in collect_reaction_contexts(route)]


def prepare_route_rule_data(
    route: dict[str, Any],
    rule_extractor: Any,
    *,
    stats: RouteProcessingStats,
    route_id: Any = "",
    source_identity: str = "",
    dataset_id: str = "",
    source_id_adapter: str = PAROUTES_SOURCE_ID_ADAPTER,
    include_single_rule_occurrences: bool = False,
) -> PreparedRouteRuleData:
    """Normalize once and bind cached chemistry to exact reaction occurrences."""

    normalized_route = routes.normalized_route_for_analysis(route)
    rule_templates: dict[str, ReactionRuleStep] = {}
    steps_by_path: dict[tuple[int, ...], ReactionRuleStep] = {}
    single_rules: dict[tuple[str, ...], set[str]] = defaultdict(set)
    single_rule_query_cgr_keys: dict[tuple[str, ...], tuple[str, ...]] = {}
    single_rule_base_query_cgr_keys: dict[tuple[str, ...], tuple[str, ...]] = {}
    occurrences: list[dict[str, Any]] = []
    missing_t1_occurrences: list[dict[str, Any]] = []
    extracted_steps: dict[str, ReactionRuleStep | None] = {}
    resolved_dataset_id = str(
        dataset_id
        or (dataset_prefix_from_path(source_identity) if source_identity else "")
    )
    route_target = route_target_smiles(normalized_route)

    for context in collect_reaction_occurrence_contexts(normalized_route):
        reaction_smiles = context.reaction_smiles
        stats.reactions_seen += 1
        if reaction_smiles in extracted_steps:
            step = extracted_steps[reaction_smiles]
            cache_hit = True
        else:
            step, cache_hit = rule_extractor.extract(reaction_smiles)
            extracted_steps[reaction_smiles] = step
        if cache_hit:
            stats.reaction_rule_cache_hits += 1
        else:
            stats.reaction_rule_cache_misses += 1
        if step is None:
            stats.skipped_reactions += 1
            if include_single_rule_occurrences:
                missing_t1_occurrences.append(
                    {
                        "reaction_node_path": list(context.reaction_node_path),
                        "reaction_smiles": reaction_smiles,
                    }
                )
            continue

        query_cgr_key = step.query_cgr_key or rule_querycgr_identity(step.rule_smarts)
        base_query_cgr_key = step.base_query_cgr_key
        if include_single_rule_occurrences and not base_query_cgr_key:
            raise RuleExtractionError(
                "exact single-rule occurrence requires a native base QueryCGR key"
            )
        template = ReactionRuleStep(
            rule_smarts=step.rule_smarts,
            center_atoms=step.center_atoms,
            reaction_smiles=step.reaction_smiles,
            reactant_center_molecules=step.reactant_center_molecules,
            product_center_molecules=step.product_center_molecules,
            query_cgr_key=query_cgr_key,
            base_query_cgr_key=base_query_cgr_key,
            base_rule_atom_maps=step.base_rule_atom_maps,
            transformation=step.transformation,
        )
        rule_templates.setdefault(reaction_smiles, template)
        occurrence_step = replace(template, target_smiles=context.target_smiles)
        steps_by_path[context.reaction_node_path] = occurrence_step

        single_rule = (step.rule_smarts,)
        single_rules[single_rule].add(context.target_smiles)
        for identities, identity in (
            (single_rule_query_cgr_keys, (query_cgr_key,)),
            (single_rule_base_query_cgr_keys, (base_query_cgr_key,)),
        ):
            previous = identities.setdefault(single_rule, identity)
            if previous != identity:
                raise ValueError(
                    "one SMARTS sequence produced conflicting QueryCGR keys"
                )

        if include_single_rule_occurrences:
            occurrence = exact_single_rule_occurrence(
                context,
                occurrence_step,
                dataset_id=resolved_dataset_id,
                source_identity=source_identity,
                route_id=route_id,
                route_target=route_target,
                source_id_adapter=source_id_adapter,
            )
            occurrences.append(occurrence.to_dict())

    if missing_t1_occurrences:
        missing_json = json.dumps(
            missing_t1_occurrences,
            separators=(",", ":"),
        )
        raise RuleExtractionError(
            "exact single-rule occurrence coverage is incomplete; "
            f"missing={missing_json}"
        )

    occurrences.sort(key=lambda item: str(item["occurrence_id"]))
    return PreparedRouteRuleData(
        route=normalized_route,
        step_by_reaction_smiles=rule_templates,
        single_rules=dict(single_rules),
        single_rule_query_cgr_keys=single_rule_query_cgr_keys,
        step_by_reaction_path=steps_by_path,
        single_rule_base_query_cgr_keys=single_rule_base_query_cgr_keys,
        single_rule_occurrences=tuple(occurrences),
        source_id_adapter=source_id_adapter,
    )


def prepare_root_reaction_paths(
    prepared: PreparedRouteRuleData,
) -> tuple[PreparedRootReactionPaths, ...]:
    """Build exact path and atom-match witnesses once for all motif extractors."""

    prepared_roots: list[PreparedRootReactionPaths] = []
    for root_index, root_path, root in root_reaction_nodes_with_paths(prepared.route):
        try:
            detailed_paths = reaction_path_occurrences_from_node(
                root,
                root_path,
                prepared.route,
                (),
                prepared.step_by_reaction_smiles,
                source_id_adapter=prepared.source_id_adapter,
            )
        except KeyError:
            detailed_paths = []
        prepared_roots.append(
            PreparedRootReactionPaths(
                root_index=root_index,
                root_path=root_path,
                detailed_paths=tuple(tuple(path) for path in detailed_paths),
            )
        )
    return tuple(prepared_roots)


def _prepared_located_paths(
    root_paths: PreparedRootReactionPaths,
) -> tuple[tuple[LocatedReactionRuleStep, ...], ...]:
    """Project exact prepared paths to the lighter gapped-RRSeq path view."""

    return tuple(
        tuple(
            LocatedReactionRuleStep(
                step=item.step,
                reaction_node_path=item.reaction_node_path,
                target_molecule_path=item.target_molecule_path,
                raw_source_record_id=item.raw_source_record_id,
                source_record_id=item.source_record_id,
                source_document_id=item.source_document_id,
                source_id_adapter=item.source_id_adapter,
            )
            for item in path
        )
        for path in root_paths.detailed_paths
    )


def _merge_prepared_single_rule_identities(
    destination: dict[tuple[str, ...], tuple[str, ...]] | None,
    prepared: PreparedRouteRuleData,
) -> None:
    if destination is None:
        return
    for sequence, identity in prepared.single_rule_query_cgr_keys.items():
        previous = destination.setdefault(sequence, identity)
        if previous != identity:
            raise ValueError("one SMARTS sequence produced conflicting QueryCGR keys")


def _located_root_path_groups(
    prepared: PreparedRouteRuleData,
    prepared_root_paths: tuple[PreparedRootReactionPaths, ...] | None,
) -> Iterable[tuple[int, tuple[tuple[LocatedReactionRuleStep, ...], ...]]]:
    if prepared_root_paths is not None:
        for root_paths in prepared_root_paths:
            yield root_paths.root_index, _prepared_located_paths(root_paths)
        return

    for root_index, root_path, root in root_reaction_nodes_with_paths(prepared.route):
        try:
            paths = located_reaction_paths_from_node(
                root,
                root_path,
                (),
                prepared.step_by_reaction_smiles,
                step_by_reaction_path=prepared.step_by_reaction_path,
                source_id_adapter=prepared.source_id_adapter,
            )
        except KeyError:
            continue
        yield root_index, tuple(tuple(path) for path in paths)


def _detailed_root_path_groups(
    prepared: PreparedRouteRuleData,
    prepared_root_paths: tuple[PreparedRootReactionPaths, ...] | None,
) -> Iterable[tuple[int, tuple[tuple[ReactionPathStep, ...], ...]]]:
    if prepared_root_paths is not None:
        for root_paths in prepared_root_paths:
            yield root_paths.root_index, root_paths.detailed_paths
        return

    for root_index, root_path, root in root_reaction_nodes_with_paths(prepared.route):
        try:
            paths = reaction_path_occurrences_from_node(
                root,
                root_path,
                prepared.route,
                (),
                prepared.step_by_reaction_smiles,
                source_id_adapter=prepared.source_id_adapter,
            )
        except KeyError:
            continue
        yield root_index, tuple(tuple(path) for path in paths)


__all__ = [
    "child_reaction_nodes",
    "collect_reaction_contexts",
    "collect_reaction_occurrence_contexts",
    "collect_reaction_smiles",
    "exact_single_rule_occurrence",
    "located_reaction_paths_from_node",
    "prepare_root_reaction_paths",
    "prepare_route_rule_data",
    "reaction_path_occurrences_from_node",
    "reaction_paths_from_node",
    "reconstruct_single_rule_occurrences_from_clean_routes",
    "root_reaction_nodes",
    "root_reaction_nodes_with_paths",
    "route_target_smiles",
]
