"""Neutral rule trees used by chemical notation and depiction adapters."""

from dataclasses import dataclass


@dataclass(frozen=True)
class RuleNode:
    key: int
    label: str
    rule_smarts: str
    reaction_path: tuple[int, ...] | None = None


@dataclass(frozen=True)
class RuleEdge:
    parent: int
    child: int
    skipped_count: int
    skipped_paths: tuple[tuple[int, ...], ...] | None = None


@dataclass(frozen=True)
class RuleTree:
    nodes: tuple[RuleNode, ...]
    edges: tuple[RuleEdge, ...]
    all_edges_rrseq_connected: bool | None = None

    @property
    def kind(self) -> str:
        return "gap" if any(edge.skipped_count for edge in self.edges) else "cons"
