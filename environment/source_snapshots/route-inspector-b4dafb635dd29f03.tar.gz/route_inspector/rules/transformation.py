"""Versioned transformation families: independent query sides, exact witnesses.

Native QueryCGR keys accelerate repeated representations. Unequal native keys
can join a family only after a candidate signature and exact side isomorphism.
"""

import json
from collections import Counter, defaultdict

from route_inspector.infrastructure.auditing import audit_lru_cache
from route_inspector.rules.graph import (
    GRAPH_SCHEMA_VERSION,
    canonical_json,
    labelled_graphs_are_isomorphic,
)

TRANSFORMATION_IDENTITY_VERSION = 3
POLICY = {
    "version": 1,
    "equivalence": "independent_complete_query_sides",
    "candidate": "atom_and_bond_label_multisets",
    "verification": "exact_labelled_graph_isomorphism",
    "cross_side_atom_correspondence": False,
    "native_keys": "preserved_fast_path",
    "unsupported": "exact_representation_only",
}
METRICS = Counter()


def _value(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (tuple, list, set, frozenset)):
        return sorted((_value(x) for x in value), key=canonical_json)
    raise ValueError(f"Unsupported query predicate type: {type(value).__name__}")


def _predicates(value):
    result = {}
    for cls in type(value).__mro__:
        for slot in getattr(cls, "__slots__", ()):
            if slot in {"_xy", "__dict__", "__weakref__"}:
                continue
            try:
                item = getattr(value, slot)
            except AttributeError:
                continue
            if slot == "_stereo" and item is not None:
                raise ValueError("Stereo query predicates require exact representation")
            result[slot] = _value(item)
    return result


def _side(molecules):
    atoms, bonds = [], []
    for molecule in molecules:
        positions = {}
        for number, atom in molecule.atoms():
            positions[number] = len(atoms)
            atoms.append(
                {
                    "node": len(atoms),
                    "label": {
                        "element": _value(atom.atomic_number),
                        "symbol": atom.atomic_symbol,
                        "predicates": _predicates(atom),
                    },
                }
            )
        for a, b, bond in molecule.bonds():
            bonds.append(
                {
                    "nodes": sorted((positions[a], positions[b])),
                    "label": _predicates(bond),
                }
            )
    return {
        "graph_schema_version": GRAPH_SCHEMA_VERSION,
        "atoms": atoms,
        "bonds": bonds,
    }


def capture_rule(rule, native_key):
    """Capture from the live query, without a SMARTS parse/serialize round trip."""
    try:
        if rule.reagents:
            raise ValueError("Reaction-agent query")
        result = {
            "query_cgr_key": native_key,
            "reactants": _side(rule.reactants),
            "products": _side(rule.products),
        }
        rule_signature(result)  # Validate before persisting a new scientific field.
        return result
    except (ValueError, TypeError, AttributeError) as exc:
        return {
            "query_cgr_key": native_key,
            "exact_representation": str(rule),
            "diagnostic": str(exc),
        }


def _graph_signature(graph):
    from route_inspector.rules.graph import _validated_graph

    labels, adjacency = _validated_graph(graph)
    return {
        "atoms": sorted(canonical_json(label) for label in labels.values()),
        "bonds": sorted(
            canonical_json(label)
            for n, edges in adjacency.items()
            for m, label in edges.items()
            if n < m
        ),
    }


@audit_lru_cache(maxsize=32768)
def _signature(encoded):
    rule = json.loads(encoded)
    if "exact_representation" in rule:
        return canonical_json({"exact_representation": rule["exact_representation"]})
    return canonical_json(
        {side: _graph_signature(rule[side]) for side in ("reactants", "products")}
    )


def rule_signature(rule):
    return _signature(canonical_json(rule))


@audit_lru_cache(maxsize=65536)
def _equivalent(left, right):
    a, b = json.loads(left), json.loads(right)
    if _signature(left) != _signature(right):
        return False
    return _equivalent_candidates(a, b)


def _equivalent_candidates(a, b):
    """Verify candidates already bucketed by the complete rule signature."""
    if "exact_representation" in a or "exact_representation" in b:
        return a.get("exact_representation") == b.get("exact_representation")
    if a["query_cgr_key"] == b["query_cgr_key"] and all(
        a[s] == b[s] for s in ("reactants", "products")
    ):
        METRICS["native_key_fast_matches"] += 1
        return True
    METRICS["rule_pair_isomorphism_checks"] += 1
    return all(
        labelled_graphs_are_isomorphic(a[s], b[s]) for s in ("reactants", "products")
    )


def rules_equivalent(left, right):
    a, b = sorted((canonical_json(left), canonical_json(right)))
    return _equivalent(a, b)


class RuleFamilyIndex:
    """Compare each new representation only with candidate representatives."""

    def __init__(self):
        self.buckets = defaultdict(list)
        self.exact = {}
        self.metrics = Counter()

    def family(self, rule):
        encoded = canonical_json(rule)
        key = (rule["query_cgr_key"], encoded)
        if key in self.exact:
            self.metrics["fast_hits"] += 1
            return self.exact[key]
        signature = rule_signature(rule)
        bucket = self.buckets[signature]
        self.metrics["representations"] += 1
        for representative, family in bucket:
            self.metrics["candidate_comparisons"] += 1
            if rules_equivalent(rule, representative):
                self.exact[key] = family
                return family
        family = len(self.exact)
        bucket.append((rule, family))
        self.exact[key] = family
        self.metrics["families"] += 1
        self.metrics["largest_bucket"] = max(
            self.metrics["largest_bucket"], len(bucket)
        )
        return family
