"""Disposable, content-addressed live-query evidence shared across publications.

Objects contain the original captured query predicates, never reconstructed
SMARTS. Dataset membership and certificates belong to the calling publication.
"""

import fcntl
import hashlib
import json
import os
import sqlite3
import zlib
from collections import Counter
from functools import lru_cache, wraps
from pathlib import Path
from types import SimpleNamespace

from route_inspector.infrastructure.build_workspace import ByteMemo
from route_inspector.rules.graph import canonical_json

VERSION = 1


class EvidenceCacheError(RuntimeError):
    """Infrastructure failure, never a failed chemical extraction."""


def cache_operation(function):
    @wraps(function)
    def checked(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except (sqlite3.Error, OSError) as exc:
            raise EvidenceCacheError(
                f"Reusable rule evidence is unavailable: {exc}"
            ) from exc

    return checked


def evidence_path(publication):
    """Share evidence within a workspace, including nonstandard publication paths."""
    path = Path(publication).resolve()
    for parent in (path, *path.parents):
        if parent.name == "outputs":
            return parent / "cache/rule_evidence/catalog.sqlite"
    return path.parent / ".rule_evidence/catalog.sqlite"


@lru_cache(maxsize=1)
def implementation_identity():
    from route_inspector.rules.config import dependency_version

    root = Path(__file__).parents[1]
    files = (
        "rules/evidence.py",
        "rules/extraction.py",
        "rules/centers.py",
        "rules/config.py",
        "rules/transformation.py",
        "rules/graph.py",
        "chemistry/standardization.py",
        "chemistry/parsing.py",
        "routes/access.py",
        "tactics/rrsubtree/models.py",
        "composite_rules/composite.py",
        "composite_rules/transformation_overlap.py",
        "composite_rules/rrsubtree.py",
    )
    return {
        "version": VERSION,
        "runtime": {
            name: dependency_version(name) for name in ("SynPlanner", "chython-synplan")
        },
        "implementation": {name: digest((root / name).read_bytes()) for name in files},
    }


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def configure_evidence(extractor, path):
    """Opt native builders into recording; custom extractors retain their behavior."""
    from route_inspector.composite_rules.composite import CompositeRuleExtractor
    from route_inspector.rules.config import resolved_config_mapping
    from route_inspector.rules.extraction import SynPlannerRuleExtractor

    if isinstance(extractor, (CompositeRuleExtractor, SynPlannerRuleExtractor)):
        extractor.evidence = RuleEvidenceStore(
            path, resolved_config_mapping(extractor.config)
        )
    return getattr(extractor, "evidence", None)


class RuleEvidenceStore:
    """One lazy connection per worker; atomic records survive interrupted builds."""

    def __init__(self, path, config):
        self.path = Path(path)
        self.namespace = canonical_json({"config": config, **implementation_identity()})
        self.namespace_id = digest(self.namespace.encode())
        self.metrics = Counter()
        self._db = None
        self._pid = None
        self._objects = ByteMemo(self._object, max_bytes=8 * 1024 * 1024)

    def __getstate__(self):
        return {
            k: v
            for k, v in self.__dict__.items()
            if k not in {"_db", "_pid", "_objects"}
        }

    def __setstate__(self, state):
        self.__dict__.update(state)
        self._db = self._pid = None
        self._objects = ByteMemo(self._object, max_bytes=8 * 1024 * 1024)

    @property
    def db(self):
        if self._db is None or self._pid != os.getpid():
            self.close()
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.with_suffix(".lock").open("a+b") as lock:
                fcntl.flock(lock, fcntl.LOCK_EX)
                db = sqlite3.connect(self.path, timeout=60)
                if db.execute("PRAGMA journal_mode").fetchone()[0] != "wal":
                    db.execute("PRAGMA journal_mode=WAL")
                db.execute("PRAGMA synchronous=NORMAL")
                db.execute("PRAGMA cache_size=-8192")
                db.executescript("""
                    CREATE TABLE IF NOT EXISTS evidence_contexts(
                        id TEXT PRIMARY KEY, payload TEXT NOT NULL
                    ) WITHOUT ROWID;
                    CREATE TABLE IF NOT EXISTS evidence_objects(
                        id TEXT PRIMARY KEY, payload BLOB NOT NULL
                    ) WITHOUT ROWID;
                    CREATE TABLE IF NOT EXISTS evidence_inputs(
                        id TEXT PRIMARY KEY, input BLOB NOT NULL, object_id TEXT NOT NULL,
                        checksum TEXT NOT NULL
                    ) WITHOUT ROWID;
                    CREATE TABLE IF NOT EXISTS evidence_pairs(
                        id TEXT PRIMARY KEY, input BLOB NOT NULL, value INTEGER NOT NULL, checksum TEXT NOT NULL
                    ) WITHOUT ROWID;
                """)
                with db:
                    db.execute(
                        "INSERT OR IGNORE INTO evidence_contexts VALUES(?,?)",
                        (self.namespace_id, self.namespace),
                    )
                if (
                    db.execute(
                        "SELECT payload FROM evidence_contexts WHERE id=?",
                        (self.namespace_id,),
                    ).fetchone()[0]
                    != self.namespace
                ):
                    db.close()
                    raise EvidenceCacheError(
                        "Reusable evidence context is damaged or collides"
                    )
            self._db, self._pid = db, os.getpid()
        return self._db

    def close(self):
        if self._db is not None:
            self._db.close()
        self._db = None
        self._objects.cache_clear()

    def _object(self, data):
        oid = digest(data)
        row = self.db.execute(
            "SELECT payload FROM evidence_objects WHERE id=?", (oid,)
        ).fetchone()
        if row is not None:
            try:
                stored = zlib.decompress(row[0])
                if stored == data:
                    return oid
                if digest(stored) == oid:
                    raise ValueError("Evidence object digest collision")
            except zlib.error:
                pass
        with self.db:
            self.db.execute(
                "INSERT OR REPLACE INTO evidence_objects VALUES(?,?)",
                (oid, zlib.compress(data, 3)),
            )
        return oid

    def _input(self, kind, value):
        raw = canonical_json([self.namespace_id, kind, value]).encode()
        return digest(raw), raw

    @cache_operation
    def get(self, kind, value):
        key, raw = self._input(kind, value)
        row = self.db.execute(
            "SELECT i.input,i.object_id,i.checksum,o.payload FROM evidence_inputs i "
            "LEFT JOIN evidence_objects o ON o.id=i.object_id WHERE i.id=?",
            (key,),
        ).fetchone()
        if row is None:
            self.metrics[f"{kind}_misses"] += 1
            return False, None
        try:
            stored, oid, checksum, payload = row
            if zlib.decompress(stored) != raw or checksum != digest(
                (key + oid).encode()
            ):
                raise ValueError("input checksum mismatch")
            data = zlib.decompress(payload)
            if digest(data) != oid:
                raise ValueError("object checksum mismatch")
            result = json.loads(data)
        except (ValueError, TypeError, zlib.error):
            with self.db:
                self.db.execute("DELETE FROM evidence_inputs WHERE id=?", (key,))
            self.metrics["damaged_records"] += 1
            self.metrics[f"{kind}_misses"] += 1
            return False, None
        self.metrics[f"{kind}_hits"] += 1
        return True, result

    @cache_operation
    def put(self, kind, value, result):
        key, raw = self._input(kind, value)
        data = canonical_json(result).encode()
        oid = digest(data)
        with self.db:
            # Repair a damaged shared object when fresh extraction supplies it.
            self.db.execute(
                "INSERT OR REPLACE INTO evidence_objects VALUES(?,?)",
                (oid, zlib.compress(data, 3)),
            )
            self.db.execute(
                "INSERT OR REPLACE INTO evidence_inputs VALUES(?,?,?,?)",
                (key, zlib.compress(raw, 3), oid, digest((key + oid).encode())),
            )

    def record(self, kind, reaction, step):
        self.put(
            kind,
            reaction,
            None
            if step is None
            else {
                "rule_smarts": step.rule_smarts,
                "transformation": step.transformation,
            },
        )

    def extract(self, kind, reaction, extractor):
        found, result = self.get(kind, reaction)
        if found:
            return None if result is None else SimpleNamespace(**result)
        result = extractor.extract(reaction)
        step = result[0] if kind == "single" else result
        self.record(kind, reaction, step)
        # The durable evidence store replaces the unbounded extraction memo for
        # overlap scans. Builders retain their ordinary route-extraction caches.
        cache = getattr(extractor, "cache", None)
        if cache is not None:
            cache.pop(reaction, None)
        return step

    @cache_operation
    def equivalent(self, left, right):
        """Reuse only complete exact comparisons; hashes never prove equivalence."""
        from route_inspector.rules.transformation import _equivalent_candidates

        pair = sorted(
            self._objects(canonical_json(graph).encode()) for graph in (left, right)
        )
        key, raw = self._input("comparison", pair)
        row = self.db.execute(
            "SELECT input,value,checksum FROM evidence_pairs WHERE id=?", (key,)
        ).fetchone()
        valid = False
        if row is not None:
            try:
                valid = (
                    zlib.decompress(row[0]) == raw
                    and row[1] in (0, 1)
                    and row[2] == digest(f"{key}:{row[1]}".encode())
                )
            except (TypeError, zlib.error):
                pass
        if valid:
            self.metrics["comparison_hits"] += 1
            return bool(row[1])
        self.metrics["comparison_misses"] += 1
        value = int(_equivalent_candidates(left, right))
        with self.db:
            self.db.execute(
                "INSERT OR REPLACE INTO evidence_pairs VALUES(?,?,?,?)",
                (key, zlib.compress(raw, 3), value, digest(f"{key}:{value}".encode())),
            )
        return bool(value)
