"""Shared extracted rules, preparation, and complete-query comparison."""

from importlib import import_module

_EXPORTS = {
    "RuleExtractionSettings": "config",
    "SynPlannerRuleExtractor": "extraction",
    "PrecomputedRuleExtractor": "extraction",
    "ReactionRuleStep": "models",
    "PreparedRouteRuleData": "models",
    "RuleExtractionError": "models",
    "prepare_route_rule_data": "preparation",
    "RuleNode": "structure",
    "RuleEdge": "structure",
    "RuleTree": "structure",
    "RuleFamilyIndex": "transformation",
}
__all__ = sorted(_EXPORTS)


def __getattr__(name):
    if name not in _EXPORTS:
        raise AttributeError(name)
    value = getattr(import_module(f"{__name__}.{_EXPORTS[name]}"), name)
    globals()[name] = value
    return value
