"""Typed RRSeq chemistry templates and exact route-occurrence views."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from route_inspector.datasets.paroutes.source_ids import PAROUTES_SOURCE_ID_ADAPTER


@dataclass(frozen=True)
class MoleculeCenterProjection:
    molecule: Any
    center_atoms: frozenset[int]


@dataclass(frozen=True)
class ReactionRuleStep:
    """A route reaction annotated with its extracted rule and reaction center."""

    rule_smarts: str
    center_atoms: frozenset[int]
    reaction_smiles: str
    target_smiles: str = ""
    reactant_center_molecules: tuple[MoleculeCenterProjection, ...] = ()
    product_center_molecules: tuple[MoleculeCenterProjection, ...] = ()
    query_cgr_key: str = ""
    base_query_cgr_key: str = ""
    base_rule_atom_maps: frozenset[int] = frozenset()
    transformation: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class LocatedReactionRuleStep:
    """One rule step tied to its exact reaction and target molecule nodes."""

    step: ReactionRuleStep
    reaction_node_path: tuple[int, ...]
    target_molecule_path: tuple[int, ...]
    raw_source_record_id: str = ""
    source_record_id: str = ""
    source_document_id: str = ""
    source_id_adapter: str = "raw"


@dataclass(frozen=True)
class ReactionNodeOccurrenceContext:
    """One source reaction node and the molecule it transforms."""

    reaction_smiles: str
    target_smiles: str
    reaction_node_path: tuple[int, ...]
    target_molecule_path: tuple[int, ...]
    reaction_node: dict[str, Any]
    root_index: int
    branch_indices: tuple[int, ...]


@dataclass(frozen=True)
class ReactionPathStep:
    """One exact route-node occurrence of an extracted reaction-rule step."""

    step: ReactionRuleStep
    reaction_node_path: tuple[int, ...]
    target_molecule_path: tuple[int, ...]
    product_index: int | None
    raw_source_record_id: str = ""
    source_record_id: str = ""
    source_document_id: str = ""
    source_id_adapter: str = "raw"
    product_to_target_atom_map: tuple[tuple[int, int], ...] = ()
    continuation_reactant_index: int | None = None
    continuation_molecule_path: tuple[int, ...] | None = None
    continuation_to_next_target_atom_map: tuple[tuple[int, int], ...] = ()
    reactant_molecule_paths: tuple[tuple[int, ...] | None, ...] = ()


@dataclass
class RouteProcessingStats:
    routes_seen: int = 0
    routes_with_rrseqs: int = 0
    reactions_seen: int = 0
    reaction_rule_cache_hits: int = 0
    reaction_rule_cache_misses: int = 0
    skipped_reactions: int = 0
    no_net_selected_change: int = 0
    errors: int = 0


@dataclass(frozen=True)
class PreparedRouteRuleData:
    """Normalized route data with chemistry cached separately from occurrences."""

    route: dict[str, Any]
    step_by_reaction_smiles: dict[str, ReactionRuleStep]
    single_rules: dict[tuple[str, ...], set[str]]
    single_rule_query_cgr_keys: dict[tuple[str, ...], tuple[str, ...]]
    step_by_reaction_path: dict[tuple[int, ...], ReactionRuleStep] = field(
        default_factory=dict
    )
    single_rule_base_query_cgr_keys: dict[tuple[str, ...], tuple[str, ...]] = field(
        default_factory=dict
    )
    single_rule_occurrences: tuple[dict[str, Any], ...] = ()
    source_id_adapter: str = PAROUTES_SOURCE_ID_ADAPTER


@dataclass(frozen=True)
class PreparedRootReactionPaths:
    """Exact root-to-leaf reaction paths and match witnesses for one route root."""

    root_index: int
    root_path: tuple[int, ...]
    detailed_paths: tuple[tuple[ReactionPathStep, ...], ...]


class RuleExtractionError(Exception):
    """Raised when a reaction cannot produce exactly one usable rule."""


__all__ = [
    "LocatedReactionRuleStep",
    "MoleculeCenterProjection",
    "PreparedRootReactionPaths",
    "PreparedRouteRuleData",
    "ReactionNodeOccurrenceContext",
    "ReactionPathStep",
    "ReactionRuleStep",
    "RouteProcessingStats",
    "RuleExtractionError",
]
