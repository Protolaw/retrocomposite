"""Optional catalogue compatibility with precursor-side stored query components.

This describes extracted patterns, not experimental reagent use. In particular,
an unspecified query charge is a wildcard; no charge is invented for the rule.
"""

from __future__ import annotations

import csv
import hashlib
import io
from collections import Counter
from dataclasses import dataclass
from importlib.resources import files

from route_inspector.rules.transformation import _side

MATCH_VERSION = 1
FILTERS = ("all", "present", "absent")


def catalogue_bytes():
    return files("route_inspector").joinpath("configs/activators.csv").read_bytes()


@dataclass(frozen=True)
class Activator:
    name: str
    smiles: str
    molecule: object


def load_catalogue(raw=None):
    """Validate the packaged CSV; keep aromatic notation in public records."""
    from chython import smiles
    from chython.containers import MoleculeContainer

    raw = catalogue_bytes() if raw is None else raw
    reader = csv.DictReader(io.StringIO(raw.decode("utf-8")))
    if reader.fieldnames != ["name", "smiles"]:
        raise ValueError("Activator catalogue requires name,smiles columns")
    result, names = [], set()
    for row in reader:
        name, text = row["name"], row["smiles"]
        if not name or name in names or not text or None in row:
            raise ValueError("Activator names must be unique and rows complete")
        molecule = smiles(text)
        if (
            not isinstance(molecule, MoleculeContainer)
            or len(molecule.connected_components) != 1
        ):
            raise ValueError(f"Activator {name} must be one molecule")
        # Chython computes aromatic valence during aromaticity normalization.
        # Only the aromatic representation is retained; the CSV is never rewritten.
        molecule.kekule()
        molecule.thiele()
        if molecule.check_valence():
            raise ValueError(f"Invalid activator valence: {name}")
        names.add(name)
        result.append(Activator(name, text, molecule))
    if not result:
        raise ValueError("Empty activator catalogue")
    return tuple(result)


def catalogue_digest():
    return hashlib.sha256(catalogue_bytes()).hexdigest()


def components(graph):
    """QueryContainer has no molecule connected-components helper."""
    adjacency = {n: set() for n in graph}
    for a, b, _ in graph.bonds():
        adjacency[a].add(b)
        adjacency[b].add(a)
    unseen = set(adjacency)
    while unseen:
        root = min(unseen)
        nodes, pending = {root}, [root]
        unseen.remove(root)
        while pending:
            for other in adjacency[pending.pop()] & unseen:
                unseen.remove(other)
                nodes.add(other)
                pending.append(other)
        yield nodes


class ActivatorMatcher:
    """Native query matching, constrained to a complete labelled component."""

    def __init__(self, catalogue=None):
        self.catalogue = load_catalogue() if catalogue is None else catalogue
        self.buckets = {}
        for item in self.catalogue:
            self.buckets.setdefault(self.signature(item.molecule), []).append(item)

    @staticmethod
    def signature(graph):
        elements = Counter(atom.atomic_number for _, atom in graph.atoms())
        return (
            tuple(sorted(elements.items())),
            sum(1 for _ in graph.bonds()),
        )

    @staticmethod
    def compatible(component, molecule):
        if next(component.get_mapping(molecule, _cython=False), None) is not None:
            return True
        # Older stored rules can spell aromatic rings with alternating bonds.
        # Match native transient assignments without changing/storing either rule
        # or catalogue notation. All encoded query constraints still apply.
        if any(int(b) == 4 for _, _, b in molecule.bonds()):
            for assignment in molecule.enumerate_kekule():
                if (
                    next(component.get_mapping(assignment, _cython=False), None)
                    is not None
                ):
                    return True
        return False

    def check(self, rule):
        """Return names, component witnesses and diagnostics without raising chemistry errors."""
        from chython import smarts

        matches, diagnostics = [], []
        try:
            if not isinstance(rule, str) or rule.count(">>") != 1:
                raise ValueError(
                    "Expected stored reaction SMARTS with one >> separator"
                )
            rhs = rule.split(">>")[1]
            if not rhs.strip():
                raise ValueError("Empty precursor side")
            query = smarts(rule)
            position = 0
            for molecule in query.products:
                for nodes in components(molecule):
                    position += 1
                    component = molecule.copy()
                    for n in set(component) - set(nodes):
                        component.delete_atom(n)
                    try:
                        # Unsupported predicates must never silently turn into absence.
                        _side([component])
                        if any(
                            not isinstance(a.atomic_number, int)
                            for _, a in component.atoms()
                        ):
                            raise ValueError(
                                "Ambiguous element query in precursor component"
                            )
                        for item in self.buckets.get(self.signature(component), ()):
                            if self.compatible(component, item.molecule):
                                matches.append(
                                    {"name": item.name, "component": position}
                                )
                    except (
                        ValueError,
                        TypeError,
                        AttributeError,
                        KeyError,
                        NotImplementedError,
                    ) as exc:
                        diagnostics.append(
                            f"Component {position}: {type(exc).__name__}: {exc}"
                        )
        except (
            ValueError,
            TypeError,
            AttributeError,
            KeyError,
            NotImplementedError,
        ) as exc:
            diagnostics.append(f"{type(exc).__name__}: {exc}")
        return {
            "status": "present" if matches else "unknown" if diagnostics else "absent",
            "matches": matches,
            "diagnostics": diagnostics,
        }


def filter_ids(mode, index, kind):
    """Shared browser contract: All is available before the optional index exists."""
    if mode not in FILTERS:
        raise ValueError("invalid activator filter")
    if mode == "all":
        return None
    if index is None:
        raise ValueError("Activator index is not ready")
    return index.ids(kind, mode)
