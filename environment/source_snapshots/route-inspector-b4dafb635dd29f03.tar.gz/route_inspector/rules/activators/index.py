"""Optional activator membership over immutable, already verified libraries."""

from __future__ import annotations

import json
import os
import sqlite3
import tempfile
from pathlib import Path
from typing import NamedTuple

from route_inspector.rules.activators import ActivatorMatcher

INDEX_VERSION = 1
TACTIC_POLICY_VERSION = 2


class RuleMembership(NamedTuple):
    entry_id: str
    kind: str
    reference: str
    rule: str | None
    diagnostic: str | None = None
    eligible: bool = True


def selected_rules(kind, payload):
    """Selected rules in retrosynthetic order, with the subtree root first."""
    if kind.startswith("rrsubtree"):
        root = tuple(payload["root_reaction_node_path"])
        nodes = payload["nodes"]
        if sum(tuple(n["reaction_node_path"]) == root for n in nodes) != 1:
            raise ValueError("Subtree root must identify exactly one selected node")
        nodes = sorted(nodes, key=lambda n: tuple(n["reaction_node_path"]) != root)
        rules = [(str(n["reaction_node_path"]), n["rule_smarts"]) for n in nodes]
    elif kind == "rrseq_gap":
        rules = [
            (f"Rule {i + 1}", s["rule_smarts"])
            for i, s in enumerate(payload["selected_steps"])
        ]
    else:
        values = payload.get("raw_sequence") or payload.get("RRseq_cons")
        if isinstance(values, str):
            values = values.split("$")
        rules = [(f"Rule {i + 1}", rule) for i, rule in enumerate(values or ())]
    if not rules:
        raise ValueError("No stored selected rules")
    return rules


def tactic_records(library):
    """Stream one representative per exact entry, without re-extraction or re-audit."""
    if library._connection is not None:
        rows = library._connection.execute(
            "SELECT e.entry_id, e.tactic_kind, "
            "json_extract(o.occurrence_json, '$.native_payload') AS native "
            "FROM entries e JOIN occurrences o "
            "ON o.reference_occurrence_id=e.representative_occurrence_id"
        )
        source = ((r[0], r[1], json.loads(r[2])) for r in rows)
    else:
        source = (
            (
                entry.entry_id,
                entry.kind,
                library.get_occurrence(
                    entry.representative_occurrence_id
                ).native_payload,
            )
            for entry in library.entries()
        )
    for entry_id, kind, native in source:
        try:
            rules = selected_rules(kind, native)
        except (KeyError, TypeError, ValueError) as exc:
            yield entry_id, kind, "Unavailable selected rules", None, str(exc)
            continue
        for position, (reference, rule) in enumerate(rules):
            # Step 1 is the final transformation in forward synthesis. Eligibility
            # belongs to this position, not the rule shared with other tactics.
            yield RuleMembership(entry_id, kind, reference, rule, eligible=position > 0)


def composite_records(library):
    """All certified net variants, scoped by the kinds of their recorded links."""
    from route_inspector.composite_rules.identity import normalize_rule

    if library._connection is not None:
        # No occurrence payloads or chemistry extraction: only existing link fields.
        rows = library._connection.execute(
            "SELECT l.composite_id, l.kind, "
            "json_extract(l.link_json, '$.variant_id') AS variant, "
            "min(coalesce(json_extract(l.link_json, '$.composite_rule'), e.normalized_rule)) AS rule "
            "FROM links l JOIN entries e USING(composite_id) "
            "GROUP BY l.composite_id,l.kind,variant"
        )
        for row in rows:
            yield (
                row[0],
                row[1],
                row[2] or "Legacy certified rule",
                normalize_rule(row[3]),
                None,
            )
    else:
        seen = set()
        for link in library._links or ():
            key = (link.composite_id, link.kind, link.variant_id)
            if key in seen:
                continue
            seen.add(key)
            rule = (
                link.composite_rule
                or library.get_entry(link.composite_id).normalized_rule
            )
            yield (
                link.composite_id,
                link.kind,
                link.variant_id or "Legacy certified rule",
                normalize_rule(rule),
                None,
            )


class ActivatorIndex:
    """Store each rule check once; membership and aggregate results are relational."""

    def __init__(self, path):
        self.connection = sqlite3.connect(
            Path(path).resolve().as_uri() + "?mode=ro", uri=True
        )
        self.connection.row_factory = sqlite3.Row
        self._ids = {}

    def close(self):
        self.connection.close()

    @staticmethod
    def build(path, records, identity, *, matcher=None, progress=None):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(
            dir=path.parent, prefix=".activators-", suffix=".sqlite"
        )
        os.close(fd)
        db = sqlite3.connect(temporary)
        matcher = ActivatorMatcher() if matcher is None else matcher
        try:
            db.executescript("""
                CREATE TABLE rules (
                    id INTEGER PRIMARY KEY, rule TEXT NOT NULL UNIQUE,
                    status TEXT NOT NULL, evidence TEXT NOT NULL);
                CREATE TABLE membership (
                    entry_id TEXT NOT NULL, kind TEXT NOT NULL, reference TEXT NOT NULL,
                    rule_id INTEGER REFERENCES rules(id),
                    PRIMARY KEY(entry_id, kind, reference));
                CREATE TABLE entries (
                    entry_id TEXT NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL,
                    PRIMARY KEY(entry_id, kind));
                CREATE INDEX by_status ON entries(kind, status, entry_id);
                CREATE TABLE metadata (identity TEXT NOT NULL);
            """)
            for count, record in enumerate(records, 1):
                if count > 1 and (count - 1) % 1000 == 0:
                    db.commit()
                    if progress is not None:
                        progress(count - 1)
                entry_id, kind, reference, rule, diagnostic, eligible = RuleMembership(
                    *record
                )
                if not eligible:
                    # Keep zero-eligible-step tactics in All/Absent. NULL records
                    # an excluded membership, not an unreadable chemical query.
                    db.execute(
                        "INSERT INTO membership VALUES(?,?,?,NULL)",
                        (entry_id, kind, reference),
                    )
                    continue
                key = rule if rule is not None else "!unreadable:" + str(diagnostic)
                existing = db.execute(
                    "SELECT id FROM rules WHERE rule=?", (key,)
                ).fetchone()
                if existing is None:
                    evidence = (
                        matcher.check(rule)
                        if diagnostic is None
                        else {
                            "status": "unknown",
                            "matches": [],
                            "diagnostics": [diagnostic],
                        }
                    )
                    rule_id = db.execute(
                        "INSERT INTO rules(rule,status,evidence) VALUES(?,?,?)",
                        (key, evidence["status"], json.dumps(evidence, sort_keys=True)),
                    ).lastrowid
                else:
                    rule_id = existing[0]
                db.execute(
                    "INSERT INTO membership VALUES(?,?,?,?)",
                    (entry_id, kind, reference, rule_id),
                )
            aggregate = (
                "CASE WHEN max(r.status='present') THEN 'present' "
                "WHEN max(r.status='unknown') THEN 'unknown' ELSE 'absent' END"
            )
            db.execute(
                f"INSERT INTO entries SELECT m.entry_id,m.kind,{aggregate} "
                "FROM membership m LEFT JOIN rules r ON r.id=m.rule_id GROUP BY m.entry_id,m.kind"
            )
            db.execute(
                f"INSERT INTO entries SELECT m.entry_id,'all',{aggregate} "
                "FROM membership m LEFT JOIN rules r ON r.id=m.rule_id GROUP BY m.entry_id"
            )
            db.execute("INSERT INTO metadata VALUES(?)", (identity,))
            db.commit()
            if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("Activator index integrity check failed")
            db.close()
            os.replace(temporary, path)
        finally:
            db.close()
            Path(temporary).unlink(missing_ok=True)

    def valid(self, identity):
        if self.connection.execute("PRAGMA quick_check").fetchone()[0] != "ok":
            return False
        row = self.connection.execute("SELECT identity FROM metadata").fetchone()
        # Exercise every required relation, including empty publications.
        self.connection.execute(
            "SELECT r.evidence FROM membership m JOIN rules r ON r.id=m.rule_id LIMIT 1"
        ).fetchone()
        self.connection.execute(
            "SELECT entry_id,kind,status FROM entries LIMIT 1"
        ).fetchone()
        return row is not None and row[0] == identity

    def ids(self, kind, status):
        key = kind or "all", status
        if key not in self._ids:
            self._ids[key] = frozenset(
                r[0]
                for r in self.connection.execute(
                    "SELECT entry_id FROM entries WHERE kind=? AND status=?", key
                )
            )
        return self._ids[key]

    def counts(self, kind=None):
        return {
            **dict.fromkeys(("present", "absent", "unknown"), 0),
            **dict(
                self.connection.execute(
                    "SELECT status,count(*) FROM entries WHERE kind=? GROUP BY status",
                    (kind or "all",),
                )
            ),
        }

    def detail(self, entry_id, kind=None):
        row = self.connection.execute(
            "SELECT status FROM entries WHERE entry_id=? AND kind=?",
            (entry_id, kind or "all"),
        ).fetchone()
        if row is None:
            return {
                "status": "unknown",
                "evidence": [],
                "diagnostics": ["No indexed rules for this entry"],
            }
        evidence, diagnostics = [], []
        sql = (
            "SELECT DISTINCT m.reference,r.evidence FROM membership m "
            "JOIN rules r ON r.id=m.rule_id WHERE m.entry_id=?"
        )
        params = [entry_id]
        if kind:
            sql += " AND m.kind=?"
            params.append(kind)
        for reference, encoded in self.connection.execute(
            sql + " ORDER BY m.reference", params
        ):
            record = json.loads(encoded)
            evidence.extend(
                {**match, "reference": reference} for match in record["matches"]
            )
            diagnostics.extend(
                f"{reference}: {message}" for message in record["diagnostics"]
            )
        return {"status": row[0], "evidence": evidence, "diagnostics": diagnostics}
