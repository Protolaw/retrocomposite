"""Map-independent labelled graphs for exact reaction-rule equivalence.

The compact lookup signature in this module is deliberately only an index.
Scientific equivalence is decided by :func:`labelled_graphs_are_isomorphic`,
which performs an exact label-preserving graph isomorphism check.
"""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from collections.abc import Mapping, Sequence
from enum import Enum
from typing import Any

from route_inspector.infrastructure.auditing import audit_memo

GRAPH_SCHEMA_VERSION = 1

_REACTION_CENTER_ATOM_STATE_PAIRS = (
    ("reactant_present", "product_present"),
    ("reactant_atomic_number", "product_atomic_number"),
    ("reactant_atomic_symbol", "product_atomic_symbol"),
    ("reactant_isotope", "product_isotope"),
    ("charge", "product_charge"),
    ("is_radical", "product_is_radical"),
    ("neighbors", "product_neighbors"),
    ("hybridizations", "product_hybridizations"),
)
_REACTION_CENTER_ATOM_LABELS = tuple(
    label for pair in _REACTION_CENTER_ATOM_STATE_PAIRS for label in pair
)


def canonical_json(value: Any) -> str:
    """Return the deterministic JSON representation used by this package."""

    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    )


def _label_value(value: Any) -> Any:
    """Encode a QueryCGR label without losing its Python value category."""

    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise ValueError("QueryCGR labels cannot contain non-finite floats")
        return value
    if isinstance(value, Enum):
        return {
            "value_type": "enum",
            "enum_type": f"{type(value).__module__}.{type(value).__qualname__}",
            "value": _label_value(value.value),
        }
    if isinstance(value, tuple):
        return {
            "value_type": "tuple",
            "items": [_label_value(item) for item in value],
        }
    if isinstance(value, list):
        return {
            "value_type": "list",
            "items": [_label_value(item) for item in value],
        }
    if isinstance(value, (set, frozenset)):
        items = [_label_value(item) for item in value]
        return {
            "value_type": "frozenset" if isinstance(value, frozenset) else "set",
            "items": sorted(items, key=canonical_json),
        }
    raise TypeError(
        "unsupported QueryCGR label value "
        f"{type(value).__module__}.{type(value).__qualname__}"
    )


def serialize_query_cgr(
    query_cgr: Any,
    *,
    atom_side_labels: Mapping[int, Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Serialize all QueryCGR atom/bond labels without maps or coordinates.

    ``node`` values are graph-local positional identifiers. They do not retain
    Chython atom-map numbers and have no chemical meaning. Exact equivalence is
    consequently graph-isomorphic rather than positional equality.
    """

    atom_numbers = tuple(sorted(int(atom_number) for atom_number in query_cgr._atoms))
    if not atom_numbers:
        raise ValueError("a reaction-rule QueryCGR must contain at least one atom")
    positions = {atom_number: index for index, atom_number in enumerate(atom_numbers)}

    if atom_side_labels is not None and set(atom_side_labels) != set(atom_numbers):
        raise ValueError("reaction-side atom labels do not match the QueryCGR atoms")

    atoms: list[dict[str, Any]] = []
    for atom_number in atom_numbers:
        atom = query_cgr.atom(atom_number)
        label = {
            "atomic_number": _label_value(getattr(atom, "atomic_number", None)),
            "atomic_symbol": _label_value(getattr(atom, "atomic_symbol", None)),
            "isotope": _label_value(getattr(atom, "isotope", None)),
            "charge": _label_value(query_cgr._charges.get(atom_number, 0)),
            "product_charge": _label_value(query_cgr._p_charges.get(atom_number, 0)),
            "is_radical": _label_value(query_cgr._radicals.get(atom_number, False)),
            "product_is_radical": _label_value(
                query_cgr._p_radicals.get(atom_number, False)
            ),
            "neighbors": _label_value(tuple(query_cgr._neighbors.get(atom_number, ()))),
            "product_neighbors": _label_value(
                tuple(query_cgr._p_neighbors.get(atom_number, ()))
            ),
            "hybridizations": _label_value(
                tuple(query_cgr._hybridizations.get(atom_number, ()))
            ),
            "product_hybridizations": _label_value(
                tuple(query_cgr._p_hybridizations.get(atom_number, ()))
            ),
        }
        if atom_side_labels is not None:
            label.update(
                {
                    str(name): _label_value(value)
                    for name, value in atom_side_labels[atom_number].items()
                }
            )
        atoms.append(
            {
                "node": positions[atom_number],
                "label": label,
            }
        )

    bonds: list[dict[str, Any]] = []
    for atom_1 in atom_numbers:
        for atom_2, bond in query_cgr._bonds[atom_1].items():
            atom_2 = int(atom_2)
            if positions[atom_1] >= positions[atom_2]:
                continue
            bonds.append(
                {
                    "nodes": [positions[atom_1], positions[atom_2]],
                    "label": {
                        "order": _label_value(bond.order),
                        "product_order": _label_value(bond.p_order),
                    },
                }
            )
    bonds.sort(key=canonical_json)
    return {
        "graph_schema_version": GRAPH_SCHEMA_VERSION,
        "atoms": atoms,
        "bonds": bonds,
    }


_UNSUPPORTED_ATOM_CONSTRAINTS = (
    ("_stereo", "atom stereo"),
    ("_heteroatoms", "heteroatom-neighbor count"),
    ("_ring_sizes", "ring size"),
    ("_implicit_hydrogens", "implicit hydrogen"),
    ("_total_connectivity", "total connectivity"),
    ("_rings_count", "ring count"),
    ("_charge_not", "negated charge"),
    ("_recursive_smarts", "recursive SMARTS"),
    ("_excluded_elements", "excluded element"),
    ("_valence", "valence"),
    ("_ring_connectivity", "ring connectivity"),
    ("_excluded_ring_sizes", "excluded ring size"),
    ("_label", "atom label"),
    ("_masked", "masked atom"),
)
_UNSUPPORTED_BOND_CONSTRAINTS = (
    ("_stereo", "bond stereo"),
    ("_in_ring", "ring-bond constraint"),
)


def _constraint_is_active(value: Any) -> bool:
    if value is None or value is False:
        return False
    if isinstance(value, (str, bytes, tuple, list, set, frozenset, Mapping)):
        return bool(value)
    return True


def _unsupported_query_constraints(reaction: Any) -> tuple[str, ...]:
    """Return SMARTS constraints that QueryCGR identity v1 cannot preserve."""

    unsupported: set[str] = set()
    for side in (*reaction.reactants, *reaction.products):
        for _atom_number, atom in side.atoms():
            for attribute, label in _UNSUPPORTED_ATOM_CONSTRAINTS:
                if _constraint_is_active(getattr(atom, attribute, None)):
                    unsupported.add(label)
        for _atom_1, _atom_2, bond in side.bonds():
            for attribute, label in _UNSUPPORTED_BOND_CONSTRAINTS:
                if _constraint_is_active(getattr(bond, attribute, None)):
                    unsupported.add(label)
    return tuple(sorted(unsupported))


def _reaction_atom_side_labels(reaction: Any) -> dict[int, dict[str, Any]]:
    """Preserve atom appearance and immutable labels on both reaction sides."""

    sides: dict[str, dict[int, Any]] = {}
    for side_name, molecules in (
        ("reactant", reaction.reactants),
        ("product", reaction.products),
    ):
        atoms: dict[int, Any] = {}
        for molecule in molecules:
            for atom_number, atom in molecule.atoms():
                atom_number = int(atom_number)
                if atom_number in atoms:
                    raise ValueError(
                        "reaction-rule SMARTS contains duplicate or ambiguous "
                        f"atom mapping on the {side_name} side"
                    )
                atoms[atom_number] = atom
        sides[side_name] = atoms

    labels: dict[int, dict[str, Any]] = {}
    for atom_number in sorted(set(sides["reactant"]) | set(sides["product"])):
        reactant = sides["reactant"].get(atom_number)
        product = sides["product"].get(atom_number)
        labels[atom_number] = {
            "reactant_present": reactant is not None,
            "product_present": product is not None,
            "reactant_atomic_number": (
                None if reactant is None else reactant.atomic_number
            ),
            "product_atomic_number": (
                None if product is None else product.atomic_number
            ),
            "reactant_atomic_symbol": (
                None if reactant is None else reactant.atomic_symbol
            ),
            "product_atomic_symbol": (
                None if product is None else product.atomic_symbol
            ),
            "reactant_isotope": None if reactant is None else reactant.isotope,
            "product_isotope": None if product is None else product.isotope,
        }
    return labels


def rule_smarts_to_graph(rule_smarts: str) -> dict[str, Any]:
    """Parse one executable rule SMARTS into its lossless labelled graph."""

    text = str(rule_smarts).strip()
    if not text or text.startswith("unparsed_smarts:"):
        raise ValueError("a parseable reaction-rule SMARTS string is required")
    if ">>" not in text:
        raise ValueError("reaction-rule SMARTS must contain '>>'")
    try:
        from chython import smarts

        reaction = smarts(text)
    except Exception as exc:
        raise ValueError("reaction-rule SMARTS cannot be parsed as a QueryCGR") from exc
    unsupported = _unsupported_query_constraints(reaction)
    if unsupported:
        raise ValueError(
            "reaction-rule SMARTS contains query constraints that tactic identity "
            "v1 cannot preserve: " + ", ".join(unsupported)
        )
    try:
        atom_side_labels = _reaction_atom_side_labels(reaction)
        query_cgr = ~reaction
        return serialize_query_cgr(
            query_cgr,
            atom_side_labels=atom_side_labels,
        )
    except Exception as exc:
        if isinstance(exc, (TypeError, ValueError)):
            raise
        raise ValueError("reaction-rule QueryCGR cannot be serialized") from exc


def _validated_graph(
    value: Mapping[str, Any],
) -> tuple[dict[int, Any], dict[int, dict[int, Any]]]:
    if int(value.get("graph_schema_version", -1)) != GRAPH_SCHEMA_VERSION:
        raise ValueError("unsupported labelled-graph schema version")
    atom_rows = value.get("atoms")
    bond_rows = value.get("bonds")
    if not isinstance(atom_rows, Sequence) or isinstance(atom_rows, (str, bytes)):
        raise ValueError("labelled graph atoms must be an array")
    if not isinstance(bond_rows, Sequence) or isinstance(bond_rows, (str, bytes)):
        raise ValueError("labelled graph bonds must be an array")

    labels: dict[int, Any] = {}
    adjacency: dict[int, dict[int, Any]] = {}
    for row in atom_rows:
        if not isinstance(row, Mapping) or "node" not in row or "label" not in row:
            raise ValueError("every labelled-graph atom requires node and label")
        node = int(row["node"])
        if node < 0 or node in labels:
            raise ValueError("labelled-graph node identifiers must be unique")
        canonical_json(row["label"])
        labels[node] = row["label"]
        adjacency[node] = {}
    if not labels:
        raise ValueError("a labelled graph must contain at least one atom")

    seen_edges: set[tuple[int, int]] = set()
    for row in bond_rows:
        if not isinstance(row, Mapping) or "nodes" not in row or "label" not in row:
            raise ValueError("every labelled-graph bond requires nodes and label")
        endpoints = row["nodes"]
        if not isinstance(endpoints, Sequence) or len(endpoints) != 2:
            raise ValueError("labelled-graph bond endpoints must contain two nodes")
        atom_1, atom_2 = (int(endpoint) for endpoint in endpoints)
        if atom_1 == atom_2 or atom_1 not in labels or atom_2 not in labels:
            raise ValueError("labelled-graph bond endpoints are invalid")
        edge = tuple(sorted((atom_1, atom_2)))
        if edge in seen_edges:
            raise ValueError("labelled graphs cannot contain duplicate bonds")
        seen_edges.add(edge)
        canonical_json(row["label"])
        adjacency[atom_1][atom_2] = row["label"]
        adjacency[atom_2][atom_1] = row["label"]
    return labels, adjacency


@audit_memo
def graph_coarse_signature(value: Mapping[str, Any]) -> str:
    """Return a numbering-invariant WL signature used only for lookup."""

    labels, adjacency = _validated_graph(value)
    colors = {
        node: hashlib.sha256(canonical_json(label).encode("utf-8")).hexdigest()
        for node, label in labels.items()
    }
    for _ in range(len(labels)):
        colors = {
            node: hashlib.sha256(
                canonical_json(
                    {
                        "self": colors[node],
                        "neighbors": sorted(
                            (
                                {
                                    "bond": adjacency[node][neighbor],
                                    "color": colors[neighbor],
                                }
                                for neighbor in adjacency[node]
                            ),
                            key=canonical_json,
                        ),
                    }
                ).encode("utf-8")
            ).hexdigest()
            for node in labels
        }
    edge_labels = sorted(
        (
            adjacency[node][neighbor]
            for node in labels
            for neighbor in adjacency[node]
            if node < neighbor
        ),
        key=canonical_json,
    )
    payload = {
        "graph_schema_version": GRAPH_SCHEMA_VERSION,
        "atom_count": len(labels),
        "bond_count": len(edge_labels),
        "colors": sorted(colors.values()),
        "edge_labels": edge_labels,
    }
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def reaction_center_graph(value: Mapping[str, Any]) -> dict[str, Any]:
    """Project a labelled rule graph onto its exact transformed centre.

    Centre membership is determined only by an atom-state change or by being an
    endpoint of a changed bond. Unchanged surrounding rule context is removed,
    while reactant/product atom state and bonds between centre atoms retain their
    direction-sensitive labels. Graph-local node identifiers remain arbitrary;
    compare projections with :func:`labelled_graphs_are_isomorphic`.
    """

    labels, _adjacency = _validated_graph(value)
    atom_rows = {int(row["node"]): row for row in value["atoms"]}
    center_nodes = {
        node
        for node, label in labels.items()
        if any(
            label.get(left) != label.get(right)
            for left, right in _REACTION_CENTER_ATOM_STATE_PAIRS
        )
    }
    for row in value["bonds"]:
        label = row["label"]
        if label.get("order") != label.get("product_order"):
            center_nodes.update(int(node) for node in row["nodes"])
    if not center_nodes:
        raise ValueError("labelled rule graph contains no transformed reaction centre")

    atoms = [
        {
            "node": node,
            "label": {
                name: atom_rows[node]["label"].get(name)
                for name in _REACTION_CENTER_ATOM_LABELS
            },
        }
        for node in sorted(center_nodes)
    ]
    bonds = [
        {
            "nodes": [int(node) for node in row["nodes"]],
            "label": {
                "order": row["label"].get("order"),
                "product_order": row["label"].get("product_order"),
            },
        }
        for row in value["bonds"]
        if set(map(int, row["nodes"])) <= center_nodes
    ]
    bonds.sort(key=canonical_json)
    return {
        "graph_schema_version": GRAPH_SCHEMA_VERSION,
        "atoms": atoms,
        "bonds": bonds,
    }


def reaction_center_graphs_are_isomorphic(
    left: Mapping[str, Any],
    right: Mapping[str, Any],
) -> bool:
    """Return exact map-independent equivalence of two transformed centres."""

    return labelled_graphs_are_isomorphic(
        reaction_center_graph(left),
        reaction_center_graph(right),
    )


@audit_memo
def labelled_graphs_are_isomorphic(
    left: Mapping[str, Any],
    right: Mapping[str, Any],
) -> bool:
    """Return exact atom- and bond-label-preserving graph isomorphism."""

    left_labels, left_adjacency = _validated_graph(left)
    right_labels, right_adjacency = _validated_graph(right)
    if len(left_labels) != len(right_labels):
        return False
    if sum(map(len, left_adjacency.values())) != sum(
        map(len, right_adjacency.values())
    ):
        return False

    def node_profile(
        node: int,
        labels: Mapping[int, Any],
        adjacency: Mapping[int, Mapping[int, Any]],
    ) -> tuple[Any, ...]:
        return (
            canonical_json(labels[node]),
            len(adjacency[node]),
            tuple(
                sorted(
                    (
                        canonical_json(adjacency[node][neighbor]),
                        canonical_json(labels[neighbor]),
                    )
                    for neighbor in adjacency[node]
                )
            ),
        )

    left_profiles = {
        node: node_profile(node, left_labels, left_adjacency) for node in left_labels
    }
    right_profiles = {
        node: node_profile(node, right_labels, right_adjacency) for node in right_labels
    }
    if Counter(left_profiles.values()) != Counter(right_profiles.values()):
        return False
    candidates = {
        node: tuple(
            candidate
            for candidate in right_labels
            if right_profiles[candidate] == left_profiles[node]
        )
        for node in left_labels
    }

    mapping: dict[int, int] = {}
    used: set[int] = set()

    def compatible(left_node: int, right_node: int) -> bool:
        for mapped_left, mapped_right in mapping.items():
            left_bond = left_adjacency[left_node].get(mapped_left)
            right_bond = right_adjacency[right_node].get(mapped_right)
            if (left_bond is None) != (right_bond is None):
                return False
            if left_bond is not None and left_bond != right_bond:
                return False
        return True

    def search() -> bool:
        if len(mapping) == len(left_labels):
            return True
        unmapped = [node for node in left_labels if node not in mapping]
        left_node = min(
            unmapped,
            key=lambda node: (
                sum(
                    candidate not in used and compatible(node, candidate)
                    for candidate in candidates[node]
                ),
                -sum(neighbor in mapping for neighbor in left_adjacency[node]),
                node,
            ),
        )
        for right_node in candidates[left_node]:
            if right_node in used or not compatible(left_node, right_node):
                continue
            mapping[left_node] = right_node
            used.add(right_node)
            if search():
                return True
            used.remove(right_node)
            del mapping[left_node]
        return False

    return search()


__all__ = [
    "GRAPH_SCHEMA_VERSION",
    "canonical_json",
    "graph_coarse_signature",
    "labelled_graphs_are_isomorphic",
    "reaction_center_graph",
    "reaction_center_graphs_are_isomorphic",
    "rule_smarts_to_graph",
    "serialize_query_cgr",
]
