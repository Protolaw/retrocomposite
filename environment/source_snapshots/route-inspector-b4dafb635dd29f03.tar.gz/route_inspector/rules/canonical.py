"""Exact labelled-graph certificates, preserving the historical encoding."""

from collections import defaultdict
from typing import Any, Mapping, Sequence

from route_inspector.infrastructure.auditing import audit_memo
from route_inspector.rules.graph import (
    GRAPH_SCHEMA_VERSION,
    canonical_json,
    labelled_graphs_are_isomorphic,
)


def _graph_parts(
    graph: Mapping[str, Any],
) -> tuple[dict[int, Any], dict[int, dict[int, Any]]]:
    """Return validated graph labels for exact canonical labelling."""

    # Identity construction has already validated the graph. Rechecking exact
    # self-isomorphism here keeps this certificate safe for loaded payloads too.
    if not labelled_graphs_are_isomorphic(graph, graph):
        raise ValueError("labelled graph failed exact self-equivalence")
    labels = {int(row["node"]): row["label"] for row in graph["atoms"]}
    adjacency: dict[int, dict[int, Any]] = {node: {} for node in labels}
    for row in graph["bonds"]:
        left, right = (int(node) for node in row["nodes"])
        adjacency[left][right] = row["label"]
        adjacency[right][left] = row["label"]
    return labels, adjacency


def _rank_descriptors(descriptors: Mapping[int, str]) -> dict[int, int]:
    ranks = {
        value: index for index, value in enumerate(sorted(set(descriptors.values())))
    }
    return {node: ranks[value] for node, value in descriptors.items()}


def _refine_graph_colors(
    nodes: frozenset[int],
    labels: Mapping[int, Any],
    adjacency: Mapping[int, Mapping[int, Any]],
    initial: Mapping[int, str] | None = None,
) -> dict[int, int]:
    if initial is None:
        descriptors = {
            node: canonical_json(
                {
                    "atom_label": labels[node],
                    "degree": len(adjacency[node]),
                    "incident_bond_labels": sorted(
                        (adjacency[node][neighbor] for neighbor in adjacency[node]),
                        key=canonical_json,
                    ),
                }
            )
            for node in nodes
        }
    else:
        descriptors = dict(initial)
    colors = _rank_descriptors(descriptors)
    for _iteration in range(len(nodes)):
        refined = _rank_descriptors(
            {
                node: canonical_json(
                    {
                        "self": colors[node],
                        "neighbors": sorted(
                            (
                                {
                                    "bond_label": adjacency[node][neighbor],
                                    "color": colors[neighbor],
                                }
                                for neighbor in adjacency[node]
                                if neighbor in nodes
                            ),
                            key=canonical_json,
                        ),
                    }
                )
                for node in nodes
            }
        )
        if refined == colors:
            return refined
        colors = refined
    return colors


def _marked_colored_graph(
    nodes: frozenset[int],
    labels: Mapping[int, Any],
    adjacency: Mapping[int, Mapping[int, Any]],
    colors: Mapping[int, int],
    marked: int,
) -> dict[str, Any]:
    return {
        "graph_schema_version": GRAPH_SCHEMA_VERSION,
        "atoms": [
            {
                "node": node,
                "label": {
                    "atom_label": labels[node],
                    "refinement_color": colors[node],
                    "individualized": node == marked,
                },
            }
            for node in sorted(nodes)
        ],
        "bonds": [
            {
                "nodes": [left, right],
                "label": adjacency[left][right],
            }
            for left in sorted(nodes)
            for right in sorted(adjacency[left])
            if left < right and right in nodes
        ],
    }


def _orbit_representatives(
    cell: Sequence[int],
    nodes: frozenset[int],
    labels: Mapping[int, Any],
    adjacency: Mapping[int, Mapping[int, Any]],
    colors: Mapping[int, int],
) -> tuple[int, ...]:
    """Return one node per exact color-preserving automorphism orbit."""

    representatives: list[int] = []
    marked_graphs: dict[int, dict[str, Any]] = {}
    for node in sorted(cell):
        marked_graphs[node] = _marked_colored_graph(
            nodes, labels, adjacency, colors, node
        )
        if any(
            labelled_graphs_are_isomorphic(marked_graphs[node], marked_graphs[other])
            for other in representatives
        ):
            continue
        representatives.append(node)
    return tuple(representatives)


def _canonical_connected_graph(
    nodes: frozenset[int],
    labels: Mapping[int, Any],
    adjacency: Mapping[int, Mapping[int, Any]],
    colors: Mapping[int, int] | None = None,
) -> str:
    """Compute an exact canonical certificate by individualization/refinement."""

    current = (
        _refine_graph_colors(nodes, labels, adjacency)
        if colors is None
        else dict(colors)
    )
    cells: dict[int, list[int]] = defaultdict(list)
    for node, color in current.items():
        cells[color].append(node)
    non_singletons = [
        (len(cell), color, tuple(cell))
        for color, cell in cells.items()
        if len(cell) > 1
    ]
    if not non_singletons:
        order = tuple(sorted(nodes, key=current.__getitem__))
        positions = {node: index for index, node in enumerate(order)}
        return canonical_json(
            {
                "atoms": [labels[node] for node in order],
                "bonds": [
                    {
                        "nodes": [positions[left], positions[right]],
                        "label": adjacency[left][right],
                    }
                    for left in order
                    for right in sorted(adjacency[left], key=positions.__getitem__)
                    if positions[left] < positions[right]
                ],
            }
        )

    _size, _color, cell = min(non_singletons)
    certificates: list[str] = []
    for representative in _orbit_representatives(
        cell, nodes, labels, adjacency, current
    ):
        individualized = {
            node: canonical_json(
                {
                    "previous_color": current[node],
                    "individualized": node == representative,
                }
            )
            for node in nodes
        }
        next_colors = _refine_graph_colors(
            nodes,
            labels,
            adjacency,
            initial=individualized,
        )
        certificates.append(
            _canonical_connected_graph(
                nodes,
                labels,
                adjacency,
                colors=next_colors,
            )
        )
    return min(certificates)


@audit_memo
def _canonical_graph_certificate(graph: Mapping[str, Any]) -> str:
    labels, adjacency = _graph_parts(graph)
    unseen = set(labels)
    components: list[str] = []
    while unseen:
        pending = [min(unseen)]
        component: set[int] = set()
        while pending:
            node = pending.pop()
            if node in component:
                continue
            component.add(node)
            pending.extend(
                neighbor for neighbor in adjacency[node] if neighbor not in component
            )
        unseen.difference_update(component)
        components.append(
            _canonical_connected_graph(
                frozenset(component),
                labels,
                adjacency,
            )
        )
    return canonical_json({"components": sorted(components)})
