"""Exact source occurrence records for individual extracted reactions."""

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION = 2
SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION = 1
_SUPPORTED_SINGLE_RULE_OCCURRENCE_SCHEMA_VERSIONS = frozenset({1, 2})


def _path(value: Iterable[int]) -> tuple[int, ...]:
    return tuple(int(index) for index in value)


def _validate_source_identifiers(
    *,
    raw_source_record_id: str,
    source_record_id: str,
    source_document_id: str,
    source_id_adapter: str,
) -> None:
    """Require persisted source IDs to match their declared adapter."""

    from route_inspector.datasets.source_ids import source_id_adapter_from_name

    expected = source_id_adapter_from_name(source_id_adapter).parse(
        {"ID": raw_source_record_id}
    )
    if source_record_id != expected.source_record_id:
        raise ValueError("source_record_id differs from the adapter-derived value")
    if source_document_id != expected.source_document_id:
        raise ValueError("source_document_id differs from the adapter-derived value")


def stable_single_rule_occurrence_id(
    *,
    source_identity: str,
    route_id: str,
    reaction_node_path: Iterable[int],
) -> str:
    """Return a stable ID for one exact reaction node in one source route."""

    payload = {
        "identity_version": SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
        "source_identity": str(source_identity),
        "route_id": str(route_id),
        "reaction_node_path": list(_path(reaction_node_path)),
    }
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")
    return f"t1o_{hashlib.sha256(encoded).hexdigest()[:24]}"


@dataclass(frozen=True)
class SingleRuleOccurrence:
    """One extracted single rule tied to its exact source reaction node."""

    occurrence_id: str
    dataset_id: str
    source_identity: str
    route_id: str
    route_target_smiles: str
    target_smiles: str
    root_index: int
    branch_indices: tuple[int, ...]
    reaction_node_path: tuple[int, ...]
    target_molecule_path: tuple[int, ...]
    rule_smarts: str
    reaction_smiles: str
    center_atom_maps: tuple[int, ...]
    query_cgr_key: str
    base_query_cgr_key: str
    base_rule_atom_maps: tuple[int, ...]
    source_record_id: str = ""
    raw_source_record_id: str = ""
    source_document_id: str = ""
    source_id_adapter: str = "raw"
    context_history_ref: str = ""
    route_context_history_id: str = ""
    context_history_projection_id: str = ""
    context_history_reference_schema_version: int = 0
    schema_version: int = SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version not in _SUPPORTED_SINGLE_RULE_OCCURRENCE_SCHEMA_VERSIONS:
            raise ValueError(
                "unsupported single-rule occurrence schema version: "
                f"{self.schema_version}"
            )
        if self.schema_version == SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION and (
            not self.dataset_id
            or not self.source_identity
            or not self.route_id
            or not self.route_target_smiles
            or not self.target_smiles
        ):
            raise ValueError(
                "current single-rule occurrences require complete route provenance"
            )
        if (
            self.root_index < 0
            or any(index < 0 for index in self.branch_indices)
            or not self.reaction_node_path
            or any(index < 0 for index in self.reaction_node_path)
            or any(index < 0 for index in self.target_molecule_path)
        ):
            raise ValueError("route indices and node paths must be non-negative")
        expected_id = stable_single_rule_occurrence_id(
            source_identity=self.source_identity,
            route_id=self.route_id,
            reaction_node_path=self.reaction_node_path,
        )
        if self.occurrence_id != expected_id:
            raise ValueError("occurrence_id does not match occurrence identity fields")
        if not self.branch_indices:
            raise ValueError("branch_indices must contain at least one branch")
        if tuple(sorted(set(self.branch_indices))) != self.branch_indices:
            raise ValueError("branch_indices must be sorted and unique")
        if self.target_molecule_path != self.reaction_node_path[:-1]:
            raise ValueError("target_molecule_path must parent reaction_node_path")
        if not self.rule_smarts or not self.reaction_smiles:
            raise ValueError("rule_smarts and reaction_smiles are required")
        if not self.query_cgr_key:
            raise ValueError("query_cgr_key is required")
        if not self.base_query_cgr_key:
            raise ValueError("base_query_cgr_key is required")
        if not set(self.center_atom_maps) <= set(self.base_rule_atom_maps):
            raise ValueError("center_atom_maps must be a subset of base_rule_atom_maps")
        if tuple(sorted(set(self.center_atom_maps))) != self.center_atom_maps:
            raise ValueError("center_atom_maps must be sorted and unique")
        if tuple(sorted(set(self.base_rule_atom_maps))) != self.base_rule_atom_maps:
            raise ValueError("base_rule_atom_maps must be sorted and unique")
        _validate_source_identifiers(
            raw_source_record_id=self.raw_source_record_id,
            source_record_id=self.source_record_id,
            source_document_id=self.source_document_id,
            source_id_adapter=self.source_id_adapter,
        )
        if (
            self.context_history_ref
            and self.route_context_history_id
            and self.context_history_ref != self.route_context_history_id
        ):
            raise ValueError(
                "context_history_ref and route_context_history_id disagree"
            )

    @property
    def local_context_query_cgr_key(self) -> str:
        """Return the explicit name for the legacy context-bearing identity."""

        return self.query_cgr_key

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "identity_version": SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
            "occurrence_id": self.occurrence_id,
            "dataset_id": self.dataset_id,
            "source_identity": self.source_identity,
            "route_id": self.route_id,
            "route_target_smiles": self.route_target_smiles,
            "target_smiles": self.target_smiles,
            "root_index": self.root_index,
            "branch_indices": list(self.branch_indices),
            "reaction_node_path": list(self.reaction_node_path),
            "target_molecule_path": list(self.target_molecule_path),
            "rule_smarts": self.rule_smarts,
            "reaction_smiles": self.reaction_smiles,
            "center_atom_maps": list(self.center_atom_maps),
            "query_cgr_key": self.query_cgr_key,
            "local_context_query_cgr_key": self.local_context_query_cgr_key,
            "base_query_cgr_key": self.base_query_cgr_key,
            "base_rule_atom_maps": list(self.base_rule_atom_maps),
            "source_record_id": self.source_record_id,
            "raw_source_id": self.raw_source_record_id,
            "raw_source_record_id": self.raw_source_record_id,
            "source_document_id": self.source_document_id,
            "source_id_adapter": self.source_id_adapter,
            "context_history_ref": self.context_history_ref,
            "route_context_history_id": self.route_context_history_id,
            "context_history_projection_id": self.context_history_projection_id,
            "context_history_reference_schema_version": (
                self.context_history_reference_schema_version
            ),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SingleRuleOccurrence":
        version = int(value.get("schema_version", -1))
        if version not in _SUPPORTED_SINGLE_RULE_OCCURRENCE_SCHEMA_VERSIONS:
            raise ValueError(
                f"unsupported single-rule occurrence schema version: {version}"
            )
        identity_version = int(
            value.get(
                "identity_version",
                SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
            )
        )
        if identity_version != SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION:
            raise ValueError(
                "unsupported single-rule occurrence identity version: "
                f"{identity_version}"
            )
        if (
            "raw_source_record_id" in value
            and "raw_source_id" in value
            and str(value["raw_source_record_id"]) != str(value["raw_source_id"])
        ):
            raise ValueError("raw source identifier aliases disagree")
        query_cgr_key = str(
            value.get("query_cgr_key") or value.get("local_context_query_cgr_key") or ""
        )
        local_context_key = str(
            value.get("local_context_query_cgr_key") or query_cgr_key
        )
        if query_cgr_key != local_context_key:
            raise ValueError("query_cgr_key and local_context_query_cgr_key disagree")
        return cls(
            schema_version=version,
            occurrence_id=str(value["occurrence_id"]),
            dataset_id=str(value.get("dataset_id", "")),
            source_identity=str(value["source_identity"]),
            route_id=str(value["route_id"]),
            route_target_smiles=str(value.get("route_target_smiles", "")),
            target_smiles=str(value.get("target_smiles", "")),
            root_index=int(value.get("root_index", 0)),
            branch_indices=tuple(
                int(index) for index in value.get("branch_indices", (0,))
            ),
            reaction_node_path=_path(value["reaction_node_path"]),
            target_molecule_path=_path(value.get("target_molecule_path", ())),
            rule_smarts=str(value["rule_smarts"]),
            reaction_smiles=str(value["reaction_smiles"]),
            center_atom_maps=tuple(
                int(atom_map) for atom_map in value.get("center_atom_maps", ())
            ),
            query_cgr_key=query_cgr_key,
            base_query_cgr_key=str(value.get("base_query_cgr_key", "")),
            base_rule_atom_maps=tuple(
                int(atom_map) for atom_map in value.get("base_rule_atom_maps", ())
            ),
            source_record_id=str(value.get("source_record_id", "")),
            raw_source_record_id=str(
                value.get("raw_source_record_id") or value.get("raw_source_id") or ""
            ),
            source_document_id=str(value.get("source_document_id", "")),
            source_id_adapter=str(value.get("source_id_adapter", "raw")),
            context_history_ref=str(
                value.get("context_history_ref")
                or value.get("route_context_history_id")
                or ""
            ),
            route_context_history_id=str(
                value.get("route_context_history_id")
                or value.get("context_history_ref")
                or ""
            ),
            context_history_projection_id=str(
                value.get("context_history_projection_id") or ""
            ),
            context_history_reference_schema_version=int(
                value.get("context_history_reference_schema_version") or 0
            ),
        )


def single_rule_occurrence_sidecar_path(output: Path) -> Path:
    """Return the exact t1 occurrence sidecar path for an extraction prefix."""

    stem = output.with_suffix("")
    return stem.with_name(f"{stem.name}_t1_single_rule_occurrences.json")


def write_single_rule_occurrences(
    path: Path,
    occurrences: Iterable[SingleRuleOccurrence | Mapping[str, Any]],
) -> Path:
    """Write a deterministic plain-JSON array of exact t1 occurrences."""

    records = [
        occurrence
        if isinstance(occurrence, SingleRuleOccurrence)
        else SingleRuleOccurrence.from_dict(occurrence)
        for occurrence in occurrences
    ]
    records.sort(key=lambda item: item.occurrence_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(
            [occurrence.to_dict() for occurrence in records],
            stream,
            sort_keys=True,
            separators=(",", ":"),
        )
        stream.write("\n")
    return path


def iter_single_rule_occurrences(path: Path) -> Iterable[SingleRuleOccurrence]:
    """Read exact t1 occurrences from a deterministic plain-JSON sidecar."""

    with path.open("r", encoding="utf-8") as stream:
        values = json.load(stream)
    if not isinstance(values, list):
        raise ValueError(f"single-rule occurrence JSON must be an array: {path}")
    for record_index, value in enumerate(values):
        try:
            yield SingleRuleOccurrence.from_dict(value)
        except Exception as exc:
            raise ValueError(
                f"invalid single-rule occurrence at {path}[{record_index}]: {exc}"
            ) from exc
