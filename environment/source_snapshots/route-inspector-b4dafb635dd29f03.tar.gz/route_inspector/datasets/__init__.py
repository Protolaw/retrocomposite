"""Dataset-specific workflow adapters; no datasets are bundled."""
