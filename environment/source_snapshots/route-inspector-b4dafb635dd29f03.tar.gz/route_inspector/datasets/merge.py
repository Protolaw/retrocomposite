"""Merge cleaned route corpora using target buckets and exact RouteCGR equality."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import tempfile
import time
from collections import Counter
from decimal import Decimal
from pathlib import Path

from route_inspector.datasets.merge_publication import (
    PENDING_ROUTES,
    publish_merge,
    recover_merge,
)
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.routes.io import iter_route_json_file
from route_inspector.rules.graph import canonical_json, labelled_graphs_are_isomorphic

POLICY = "target-stereo-smiles-and-ordered-routecgr-history-v1"


def _number(value):
    if isinstance(value, Decimal):
        return float(value)
    raise TypeError(type(value).__name__)


def target_key(route):
    """Canonical SMILES spelling only; retain stereo, charge and isotopes."""
    from route_inspector.chemistry.stereo import stereo_molecule

    return str(stereo_molecule(route["smiles"]))


def route_graph(route):
    """Keep transient bonds, depths, chronological orders and intermediate states.

    Atom numbers are graph-local identifiers, never labels. As in SynPlanner's
    RouteCGR comparison, intermediate stereochemistry is not encoded. The
    separate target bucket remains stereochemistry-sensitive.
    """
    from synplan.chem.reaction.routes.representation.hash import route_cgr_graph

    from route_inspector.routes.synplanner import build_route_cgr, make_route_cgr_dict

    result = build_route_cgr(
        make_route_cgr_dict({0: route}), 0, preserve_transient_bonds=True
    )
    if not result.ok:
        raise ValueError(str(result.diagnostic))
    cgr = result.cgr
    native = route_cgr_graph(cgr, include_route_order=True)
    positions = {atom: i for i, atom in enumerate(sorted(native.node_labels))}
    atoms, bonds = [], []
    for atom_id, atom in cgr.atoms():
        label = json.loads(native.node_labels[atom_id])
        label["step_states"] = sorted(
            getattr(atom, "route_atom_step_states", {}).items()
        )
        atoms.append({"node": positions[atom_id], "label": label})
    for left, right, bond in cgr.bonds():
        label = json.loads(native.edge_labels[tuple(sorted((left, right)))])
        label["step_states"] = sorted(
            getattr(bond, "route_bond_step_states", {}).items()
        )
        bonds.append({"nodes": [positions[left], positions[right]], "label": label})
    return {"graph_schema_version": 1, "atoms": atoms, "bonds": bonds}


def graph_bucket(graph):
    """A cheap candidate index; exact isomorphism always decides equality."""
    return hashlib.sha256(
        canonical_json(
            {
                "atoms": sorted(canonical_json(row["label"]) for row in graph["atoms"]),
                "bonds": sorted(canonical_json(row["label"]) for row in graph["bonds"]),
            }
        ).encode()
    ).hexdigest()


def _signature(path):
    stat = path.stat()
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns


def _publish(path, write):
    """Publish a complete file without replacing an existing destination."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".route-merge-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            write(stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def merge_clean_routes(
    inputs, output, audit_dir, *, work_dir=None, progress_interval=500
):
    """Retain one source tree per exact class, and every original source label.

    Inputs are ordered (dataset label, JSON path) pairs. The first matching
    source wins. Only target buckets containing multiple routes compose CGRs.
    Comparison failures retain distinct routes with explicit diagnostics.
    """
    output, audit_dir = Path(output), Path(audit_dir)
    inputs = list(inputs)
    labels = [label for label, _ in inputs]
    if len(labels) < 2 or len(set(labels)) != len(labels) or not all(labels):
        raise ValueError("provide at least two uniquely labelled input corpora")
    for _, path in inputs:
        if Path(path).is_absolute() or ".." in Path(path).parts:
            raise ValueError("input paths must be workspace-relative")
    if output.resolve().is_relative_to(audit_dir.resolve()):
        raise ValueError("merged JSON must be outside the audit directory")
    recovered = recover_merge(inputs, output, audit_dir)
    if recovered is not None:
        return recovered
    audit_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        prefix=".route-merge-", dir=audit_dir.parent
    ) as staging:
        staged_audit = Path(staging) / "audit"
        staged_audit.mkdir()
        result = _build_merge(
            inputs,
            staged_audit / PENDING_ROUTES,
            staged_audit,
            published_output=output,
            work_dir=work_dir,
            progress_interval=progress_interval,
        )
        publish_merge(staged_audit, output, audit_dir)
        return result


def _build_merge(
    inputs, output, audit_dir, *, published_output, work_dir, progress_interval
):
    """Build and check the entire file set privately before publication."""
    started = time.monotonic()
    statistics = Counter(duplicates_eliminated=0, route_cgrs_compared=0)
    sources, signatures = [], {}
    if work_dir is not None:
        Path(work_dir).mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="route-merge-", dir=work_dir) as scratch:
        with sqlite3.connect(Path(scratch) / "routes.sqlite") as db:
            db.execute("PRAGMA cache_size=-16384")
            db.execute(
                "CREATE TABLE routes (id INTEGER PRIMARY KEY, dataset TEXT, original_id TEXT, target TEXT, payload TEXT, digest TEXT, representative INTEGER, merged_id INTEGER, UNIQUE(dataset,original_id))"
            )
            db.execute("CREATE INDEX targets ON routes(target,id)")
            db.execute(
                "CREATE TABLE diagnostics(dataset TEXT,route_id TEXT,stage TEXT,error TEXT)"
            )
            for dataset, filename in inputs:
                path = Path(filename)
                before = _signature(path)
                source = dict(
                    dataset=dataset,
                    path=path.as_posix(),
                    sha256=sha256_file(path),
                    route_count=0,
                )
                for route_id, route in iter_route_json_file(path):
                    if "route_merge" in (route.get("metadata") or {}):
                        raise ValueError(
                            "input already has route_merge provenance; merge original corpora"
                        )
                    payload = json.dumps(
                        route, separators=(",", ":"), sort_keys=True, default=_number
                    )
                    digest = hashlib.sha256(payload.encode()).hexdigest()
                    try:
                        target = target_key(route)
                    except Exception as exc:
                        target = None
                        db.execute(
                            "INSERT INTO diagnostics VALUES(?,?,?,?)",
                            (
                                dataset,
                                str(route_id),
                                "target",
                                f"{type(exc).__name__}: {exc}",
                            ),
                        )
                    db.execute(
                        "INSERT INTO routes(dataset,original_id,target,payload,digest) VALUES(?,?,?,?,?)",
                        (dataset, str(route_id), target, payload, digest),
                    )
                    source["route_count"] += 1
                if before != _signature(path):
                    raise ValueError(f"input changed during merge: {path}")
                sources.append(source)
                signatures[path] = before
                db.commit()
            statistics["input_routes"] = db.execute(
                "SELECT COUNT(*) FROM routes"
            ).fetchone()[0]
            db.execute("UPDATE routes SET representative=id")
            targets = db.execute(
                "SELECT target,COUNT(*) FROM routes WHERE target IS NOT NULL GROUP BY target HAVING COUNT(*)>1 ORDER BY MIN(id)"
            ).fetchall()
            statistics["matching_target_buckets"] = len(targets)
            statistics["routes_in_matching_target_buckets"] = sum(n for _, n in targets)
            for group_index, (target, _) in enumerate(targets, 1):
                candidates = {}
                for row_id, dataset, route_id, payload in db.execute(
                    "SELECT id,dataset,original_id,payload FROM routes WHERE target=? ORDER BY id",
                    (target,),
                ).fetchall():
                    try:
                        graph = route_graph(json.loads(payload))
                        statistics["route_cgrs_compared"] += 1
                        bucket = graph_bucket(graph)
                        representative = next(
                            (
                                other
                                for other, candidate in candidates.get(bucket, ())
                                if labelled_graphs_are_isomorphic(graph, candidate)
                            ),
                            None,
                        )
                    except Exception as exc:
                        db.execute(
                            "INSERT INTO diagnostics VALUES(?,?,?,?)",
                            (
                                dataset,
                                route_id,
                                "route_cgr",
                                f"{type(exc).__name__}: {exc}",
                            ),
                        )
                        continue
                    if representative is None:
                        candidates.setdefault(bucket, []).append((row_id, graph))
                    else:
                        db.execute(
                            "UPDATE routes SET representative=? WHERE id=?",
                            (representative, row_id),
                        )
                        statistics["duplicates_eliminated"] += 1
                if progress_interval and group_index % progress_interval == 0:
                    print(
                        f"[merge] compared {group_index}/{len(targets)} target buckets; {statistics['duplicates_eliminated']} duplicates",
                        flush=True,
                    )
                db.commit()
            representatives = [
                r[0]
                for r in db.execute(
                    "SELECT id FROM routes WHERE representative=id ORDER BY id"
                )
            ]
            db.execute("CREATE INDEX memberships ON routes(representative,id)")
            for merged_id, representative in enumerate(representatives):
                db.execute(
                    "UPDATE routes SET merged_id=? WHERE representative=?",
                    (merged_id, representative),
                )
            digests = {source["dataset"]: source["sha256"] for source in sources}

            def members(representative):
                return [
                    dict(
                        dataset=d, route_id=r, route_sha256=h, source_sha256=digests[d]
                    )
                    for d, r, h in db.execute(
                        "SELECT dataset,original_id,digest FROM routes WHERE representative=? ORDER BY id",
                        (representative,),
                    )
                ]

            written = Counter()

            def write_routes(stream):
                stream.write("[\n")
                for merged_id, representative in enumerate(representatives):
                    if merged_id:
                        stream.write(",\n")
                    route = json.loads(
                        db.execute(
                            "SELECT payload FROM routes WHERE id=?", (representative,)
                        ).fetchone()[0]
                    )
                    origins = members(representative)
                    if route.get("metadata") is None:
                        route["metadata"] = {}
                    route["metadata"]["route_merge"] = dict(
                        policy=POLICY,
                        merged_route_id=str(merged_id),
                        labels=[f"{o['dataset']}:{o['route_id']}" for o in origins],
                        sources=origins,
                    )
                    json.dump(route, stream, separators=(",", ":"))
                    written["routes"] += 1
                stream.write("\n]\n")

            if any(_signature(path) != before for path, before in signatures.items()):
                raise ValueError("input changed while RouteCGRs were compared")
            _publish(output, write_routes)
            with (audit_dir / "route_labels.jsonl").open("w") as stream:
                for merged_id, representative in enumerate(representatives):
                    origins = members(representative)
                    stream.write(
                        json.dumps(
                            dict(
                                merged_route_id=str(merged_id),
                                sources=origins,
                            )
                        )
                        + "\n"
                    )
                    written["labels"] += len(origins)
            with (audit_dir / "errors.tsv").open("w") as stream:
                import csv

                writer = csv.writer(stream, delimiter="\t")
                writer.writerow(("dataset", "route_id", "stage", "error"))
                writer.writerows(
                    db.execute(
                        "SELECT * FROM diagnostics ORDER BY dataset,route_id,stage"
                    )
                )
            statistics["diagnostic_count"] = db.execute(
                "SELECT COUNT(*) FROM diagnostics"
            ).fetchone()[0]
            statistics["output_routes"] = len(representatives)
            if (
                statistics["input_routes"]
                != statistics["output_routes"] + statistics["duplicates_eliminated"]
                or written["routes"] != statistics["output_routes"]
                or written["labels"] != statistics["input_routes"]
            ):
                raise ValueError("merged routes and provenance counts are inconsistent")
            result = dict(
                schema_version=1,
                policy=POLICY,
                inputs=sources,
                output=published_output.as_posix(),
                output_sha256=sha256_file(output),
                statistics=dict(statistics),
                elapsed_seconds=time.monotonic() - started,
            )
            (audit_dir / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
            if any(_signature(path) != before for path, before in signatures.items()):
                raise ValueError("input changed while merge artifacts were written")
            return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", action="append", required=True, metavar="LABEL=JSON")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--audit-dir", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path)
    parser.add_argument("--progress-interval", type=int, default=500)
    args = parser.parse_args(argv)
    inputs = []
    for value in args.input:
        if "=" not in value:
            parser.error("--input requires LABEL=JSON")
        label, path = value.split("=", 1)
        inputs.append((label, Path(path)))
    result = merge_clean_routes(
        inputs,
        args.output,
        args.audit_dir,
        work_dir=args.work_dir,
        progress_interval=args.progress_interval,
    )
    print(json.dumps(result["statistics"], sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
