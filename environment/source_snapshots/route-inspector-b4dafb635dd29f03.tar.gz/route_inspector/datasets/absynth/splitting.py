"""Conservative, map-preserving ABSynth main-transformation/deprotection splits.

These are inferred decompositions, not evidence for isolated intermediates. Only
complete, source-supported protecting-group loss is implemented. Ambiguous or
unsupported chemistry stays in its original validated route representation.
"""

from __future__ import annotations

import copy
import hashlib
import json
import re
from functools import lru_cache

from route_inspector import chemistry
from route_inspector.datasets.absynth.conversion import (
    mapped_reaction_has_complete_atom_sources,
    reaction_children_are_complete,
)
from route_inspector.protection.analysis import matching_site_mappings
from route_inspector.protection.chython_rules import load_chython_protection_rules
from route_inspector.routes.access import reaction_nodes
from route_inspector.routes.alignment import (
    mapped_component_multisets_equal,
    mapped_molecules_stereo_equal,
)
from route_inspector.routes.normalization import normalize_route_tree
from route_inspector.routes.reaction_changes import component_forward_change
from route_inspector.routes.split_validation import (
    validate_generated_reaction_has_structural_change,
)
from route_inspector.routes.validation import (
    validate_raw_reaction_atom_mapping,
    validate_routes_mapping,
)

POLICY = "absynth_complete_pg_main_then_deprotection_v1"


class SplitUnresolved(ValueError):
    """A candidate is not proved safe; retain the original route."""


def eligible(raw_code: str, center_count: int) -> bool:
    codes = [
        c for c in raw_code.split(";") if re.fullmatch(r"\d+\.\d+\.\d+(?:\.\d+)*", c)
    ]
    return (
        center_count == 2
        and any(c.startswith("6.") for c in codes)
        and any(not c.startswith("6.") for c in codes)
    )


@lru_cache(maxsize=1)
def protection_rules():
    return load_chython_protection_rules()


def protecting_group_matches(source, anchor: int, removed: set[int]) -> list[str]:
    """Require a curated protected site and removal of its matched group.

    A narrowly scoped aromatic-N-Boc rule supplements the shared rule table;
    the PaRoutes/protection-analysis defaults are not modified.
    """
    found = []
    for key, rule in protection_rules().items():
        for kept, mapping in matching_site_mappings(source, rule):
            group = set(mapping.values()) - set(kept)
            if anchor in kept and group and group <= removed:
                found.append(key)
                break
    from chython import smarts

    query = smarts("[n:1]-[C:2](=[O:3])-[O:4]-[C:5]([CH3:6])([CH3:7])-[CH3:8]")
    if any(
        m[1] == anchor and set(m.values()) - {anchor} <= removed
        for m in query.get_mapping(source)
    ):
        found.append("absynth_aromatic_n_boc")
    return sorted(set(found))


def _atom_state(atom):
    return (
        atom.atomic_number,
        atom.isotope,
        atom.charge,
        atom.is_radical,
        atom.implicit_hydrogens or 0,
    )


def _cgr_identity(cgr):
    return (
        tuple(
            sorted(
                (
                    n,
                    a.atomic_number,
                    a.isotope,
                    a.charge,
                    a.p_charge,
                    a.is_radical,
                    a.p_is_radical,
                )
                for n, a in cgr.atoms()
            )
        ),
        tuple(
            sorted(
                (min(n, m), max(n, m), b.order, b.p_order) for n, m, b in cgr.bonds()
            )
        ),
    )


def _restore_anchor(molecule, source, anchor):
    atom, recorded = molecule.atom(anchor), source.atom(anchor)
    atom.charge, atom.is_radical = recorded.charge, recorded.is_radical
    # Chython has no public setter for implicit H; aromatic n/nH cannot be
    # inferred from added bonds alone. Copy the evidenced boundary atom state.
    atom._implicit_hydrogens = recorded.implicit_hydrogens
    molecule.flush_cache()


def construct_intermediate(reaction):
    """Restore a unique, complete PG fragment from the original mapped input."""
    if len(reaction.products) != 1:
        raise SplitUnresolved("requires exactly one recorded product")
    product = reaction.products[0]
    product_ids = set(product)
    centers = [frozenset(c) for c in (~reaction).centers_list]
    if len(centers) != 2:
        raise SplitUnresolved("requires exactly two CGR center components")
    candidates = []
    for center in centers:
        delta = component_forward_change(reaction, center)
        if delta["forward_bonds_formed"] or delta["forward_bonds_changed"]:
            continue
        boundary = [
            (a, b)
            for a, b in delta["forward_bonds_broken"]
            if (a in product_ids) != (b in product_ids)
        ]
        if len(boundary) != 1:
            continue
        anchor, detached = boundary[0]
        if detached in product_ids:
            anchor, detached = detached, anchor
        source = next(m for m in reaction.reactants if m.has_atom(detached))
        removed, stack = set(), [detached]
        while stack:
            atom = stack.pop()
            if atom in removed or atom in product_ids:
                continue
            removed.add(atom)
            stack.extend(source._bonds[atom])
        attachments = {
            (min(n, m), max(n, m))
            for n, m, _ in source.bonds()
            if (n in removed) != (m in removed)
        }
        if attachments != {(min(anchor, detached), max(anchor, detached))}:
            continue
        recognized = protecting_group_matches(source, anchor, removed)
        if recognized:
            candidates.append((source, anchor, removed, center, recognized))
    if len(candidates) != 1:
        raise SplitUnresolved(
            "no uniquely recognized complete protecting-group cleavage"
            if not candidates
            else "ambiguous: both centers match protecting-group cleavage"
        )
    source, anchor, removed, pg_center, recognized = candidates[0]
    intermediate = product.copy()
    for atom_id in sorted(removed):
        atom = source.atom(atom_id)
        intermediate.add_atom(
            atom.copy(full=True),
            atom_id,
            charge=atom.charge,
            is_radical=atom.is_radical,
            _skip_calculation=True,
        )
    for n, m, bond in source.bonds():
        if (
            (n in removed or m in removed)
            and intermediate.has_atom(n)
            and intermediate.has_atom(m)
        ):
            intermediate.add_bond(n, m, bond.copy(), _skip_calculation=True)
    intermediate.fix_structure()
    _restore_anchor(intermediate, source, anchor)
    intermediate.fix_stereo()
    for atom_id in removed | {anchor}:
        if _atom_state(intermediate.atom(atom_id)) != _atom_state(source.atom(atom_id)):
            raise SplitUnresolved(
                "restored protecting-group atom state differs from its source"
            )
    for atom_id in product_ids - {anchor}:
        if _atom_state(intermediate.atom(atom_id)) != _atom_state(
            product.atom(atom_id)
        ):
            raise SplitUnresolved(
                "intermediate changes an unaffected product atom state"
            )
    # Removing the complete added fragment must recover the exact mapped stereo
    # product, not merely an unlabelled constitutional isomorph.
    # Build a fresh graph: older Chython releases retain deleted ring atoms in
    # cached structural properties when deletion skips recalculation.
    recovered = intermediate.substructure(product_ids, recalculate_hydrogens=True)
    recovered.fix_structure()
    _restore_anchor(recovered, product, anchor)
    recovered.fix_stereo()
    if not mapped_molecules_stereo_equal(recovered, product):
        raise SplitUnresolved(
            "intermediate does not preserve the mapped product stereochemistry"
        )
    # Match the complete restored PG, including its boundary, to the input.
    fragment_ids = removed | {anchor}
    left = intermediate.substructure(fragment_ids, recalculate_hydrogens=False)
    right = source.substructure(fragment_ids, recalculate_hydrogens=False)
    if not mapped_molecules_stereo_equal(left, right):
        raise SplitUnresolved(
            "restored complete protecting group differs from recorded source"
        )
    return intermediate, {
        "anchor_map": anchor,
        "restored_atom_maps": sorted(removed),
        "deprotection_center_maps": sorted(pg_center),
        "protection_rules": recognized,
    }


def split_reaction(node: dict, path: tuple) -> tuple[dict, dict]:
    """Return a replacement reaction subtree without mutating the source node."""
    from chython.containers import ReactionContainer

    reaction = chemistry.parse_reaction(node["smiles"])
    if validate_raw_reaction_atom_mapping(
        node["smiles"]
    ) or not mapped_reaction_has_complete_atom_sources(node["smiles"]):
        raise SplitUnresolved(
            "invalid original mapping or incomplete product atom sources"
        )
    if not reaction_children_are_complete(node):
        raise SplitUnresolved("original reactant-child mismatch")
    intermediate, detail = construct_intermediate(reaction)
    # Supported PG cleavages only remove source atoms: all original inputs belong
    # to the main stage, including recorded unused terminal reagents. A cleavage
    # requiring new atoms/inputs is not supported or guessed by this policy.
    first = ReactionContainer(
        tuple(m.copy() for m in reaction.reactants),
        (intermediate.copy(),),
        tuple(m.copy() for m in reaction.reagents),
    )
    second = ReactionContainer(
        (intermediate.copy(),), tuple(m.copy() for m in reaction.products)
    )
    for generated in (first, second):
        text = format(generated, "m")
        if len((~generated).centers_list) != 1:
            raise SplitUnresolved("generated stage does not have exactly one center")
        if validate_raw_reaction_atom_mapping(
            text
        ) or not mapped_reaction_has_complete_atom_sources(text):
            raise SplitUnresolved("generated stage has invalid atom sources or maps")
        validate_generated_reaction_has_structural_change(generated)
    if set((~second).center_atoms) != set(detail["deprotection_center_maps"]):
        raise SplitUnresolved(
            "generated deprotection includes changes outside its original center"
        )
    if _cgr_identity((~first) ^ (~second)) != _cgr_identity(~reaction):
        raise SplitUnresolved(
            "composed mapped changes differ from the original transformation"
        )
    if not mapped_component_multisets_equal(first.reactants, reaction.reactants):
        raise SplitUnresolved("generated sequence changes recorded starting components")
    meta = node["metadata"]
    identity = json.dumps(
        [str(meta["path_id"]), int(meta["source_row"]), list(path)],
        separators=(",", ":"),
    )
    split_id = "absynth_split_" + hashlib.sha256(identity.encode()).hexdigest()[:24]
    provenance = {
        "policy": POLICY,
        "inferred": True,
        "experimental_intermediate": False,
        "split_id": split_id,
        "original_node_path": list(path),
        "original_reaction_smiles": node["smiles"],
        "original_metadata": copy.deepcopy(meta),
        "forward_order": "main_transformation_then_deprotection",
        **detail,
    }

    def metadata(stage, generated):
        smi = format(generated, "m")
        return {
            "path_id": meta["path_id"],
            "step_id": meta["step_id"],
            "source_record_id": meta["step_id"],
            "source_row": meta["source_row"],
            "rxn_name": meta.get("rxn_name", ""),
            "conditions": meta.get("conditions", ""),
            "smiles": smi,
            "original_rxn_smiles": str(generated),
            "mapping_source": "derived_from_existing_route_maps_not_Graphormer_prediction",
            "generated_stage_id": f"{split_id}:{stage}",
            "inferred": True,
            "transformation_kind": "inferred_main_transformation"
            if stage == 1
            else "inferred_deprotection",
            "absynth_deprotection_split": {
                **copy.deepcopy(provenance),
                "forward_stage": stage,
            },
        }

    first_node = {
        "type": "reaction",
        "smiles": format(first, "m"),
        "metadata": metadata(1, first),
        "children": copy.deepcopy(node.get("children", [])),
    }
    molecule = {
        "type": "mol",
        "smiles": format(intermediate, "m"),
        "in_stock": False,
        "metadata": {
            "mapped_smiles": format(intermediate, "m"),
            "original_smiles": str(intermediate),
            "inferred": True,
            "experimental_intermediate": False,
            "role": "inferred_protected_intermediate",
            "split_id": split_id,
        },
        "children": [first_node],
    }
    second_node = {
        "type": "reaction",
        "smiles": format(second, "m"),
        "metadata": metadata(2, second),
        "children": [molecule],
    }
    if not all(reaction_children_are_complete(n) for n in (first_node, second_node)):
        raise SplitUnresolved("generated reactant-child mismatch")
    return second_node, {
        **detail,
        "split_id": split_id,
        "intermediate_smiles": format(intermediate, "m"),
        "generated_reactions_forward": [format(first, "m"), format(second, "m")],
    }


def handle_diff_multicentered_reactions(
    root: dict, audited_rows: list[dict]
) -> tuple[dict, list[dict]]:
    """Route-atomic splitting: a failed candidate or validation rolls back all."""
    original_nodes = dict(reaction_nodes(root))
    candidates = []
    for row in audited_rows:
        path = (
            tuple(json.loads(row["node_path"]))
            if isinstance(row["node_path"], str)
            else tuple(row["node_path"])
        )
        node = original_nodes[path]
        if node.get("metadata", {}).get("absynth_deprotection_split"):
            continue  # Explicit idempotence even if an old parent label is supplied.
        if row["mapped_reaction"] != node["smiles"]:
            raise ValueError("stale mapped reaction in splitting audit")
        if eligible(row["raw_code"], int(row["center_count"])):
            candidates.append((path, row))
    if not candidates:
        return root, []
    candidate = copy.deepcopy(root)
    # Descendant-first avoids losing another replacement when its parent splits.
    decisions = []
    for path, row in sorted(candidates, key=lambda x: (-len(x[0]), x[0])):
        holder = candidate
        for part in path[:-1]:
            holder = holder["children"][part]
        node = holder["children"][path[-1]]
        entry = {
            "path_id": str(row["path_id"]),
            "source_row": int(row["source_row"]),
            "step_id": row["step_id"],
            "original_node_path": list(path),
            "raw_code": row["raw_code"],
            "status": "proposed",
            "reason": "",
        }
        try:
            replacement, detail = split_reaction(node, path)
            holder["children"][path[-1]] = replacement
            entry.update(detail)
        except Exception as exc:
            entry.update(status="unresolved", reason=f"{type(exc).__name__}: {exc}")
        decisions.append(entry)
    if not any(d["status"] == "unresolved" for d in decisions):
        try:
            normalized = normalize_route_tree(
                candidate,
                anchor_target_map_one=True,
                alignment_policy="stereo_preserving_witness",
            )
            records = validate_routes_mapping(
                {str(root["metadata"]["path_id"]): normalized},
                dataset="ABSynth",
                allow_stereo_only_reactions=True,
            ).records
            if records:
                raise SplitUnresolved(json.dumps(records, sort_keys=True))
            before_rxns = {p: n for p, n in reaction_nodes(candidate)}
            for path, node in reaction_nodes(normalized):
                # Normalization must not renumber an already consistent source:
                # strict map correspondence, stereo and original metadata survive.
                before = chemistry.parse_reaction(before_rxns[path]["smiles"])
                after = chemistry.parse_reaction(node["smiles"])
                if not (
                    mapped_component_multisets_equal(before.reactants, after.reactants)
                    and mapped_component_multisets_equal(
                        before.products, after.products
                    )
                ):
                    raise SplitUnresolved(
                        "normalization changed existing mapped atom identities or stereochemistry"
                    )
            for d in decisions:
                d["status"] = "split"
            return normalized, sorted(decisions, key=lambda d: d["original_node_path"])
        except Exception as exc:
            for d in decisions:
                d.update(
                    status="rolled_back",
                    reason=f"route_validation: {type(exc).__name__}: {exc}",
                )
            return root, sorted(decisions, key=lambda d: d["original_node_path"])
    for d in decisions:
        if d["status"] == "proposed":
            d.update(
                status="rolled_back",
                reason="another eligible reaction in the route could not be split safely",
            )
    return root, sorted(decisions, key=lambda d: d["original_node_path"])
