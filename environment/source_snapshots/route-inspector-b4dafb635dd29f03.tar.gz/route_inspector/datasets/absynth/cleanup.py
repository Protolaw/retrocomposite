"""Clean a hash-verified ABSynth snapshot without source conversion or remapping."""

from __future__ import annotations

import csv
import json
import shutil
from concurrent.futures import ProcessPoolExecutor
from importlib.metadata import version
from multiprocessing import get_context
from pathlib import Path
from types import SimpleNamespace

from route_inspector.datasets.absynth import analysis as analysis
from route_inspector.datasets.absynth.filtering import (
    file_record,
    verified_analysis_artifact,
)
from route_inspector.datasets.absynth.postprocess import (
    classify_processed,
    verify_baseline,
)
from route_inspector.datasets.absynth.runtime import runtime_provenance
from route_inspector.infrastructure.artifacts import write_json
from route_inspector.routes.access import reaction_nodes
from route_inspector.routes.cleanup import (
    POLICY,
    cleanup_route_reactants,
    cleanup_summary,
    write_cleanup_audit,
)


def checked(record):
    path = Path(record["path"])
    if file_record(path)["sha256"] != record["sha256"]:
        raise ValueError(f"snapshot artifact hash mismatch: {path}")
    return path


def _clean_item(item):
    index, root = item
    audit = []
    # The baseline binds this already-normalized tree to a passing validation.
    # Cleanup reuses those exact maps and checks the whole modified route.
    cleaned = cleanup_route_reactants(
        root, audit=audit, allow_stereo_only_reactions=True
    )
    decision = {
        "path_id": str(root["metadata"]["path_id"]),
        "status": "cleaned"
        if cleaned != root
        else "rolled_back"
        if audit
        else "unchanged",
        "reaction_nodes_before": sum(1 for _ in reaction_nodes(root)),
        "reaction_nodes_after": sum(1 for _ in reaction_nodes(cleaned)),
        **cleanup_summary(audit),
    }
    return index, cleaned, audit, decision


def visual_baseline(args, manifest):
    """Follow hash-verified split provenance; do not join the newer live CSV."""
    path = args.analysis_dir.parent / "manifest.json"
    provenance = json.loads(path.read_text())
    if provenance["output"]["sha256"] != file_record(args.input)["sha256"]:
        raise ValueError("postprocessing manifest differs from the requested input")
    checked(provenance["analysis_manifest"])
    original_manifest_path = checked(provenance["baseline_analysis"])
    original_manifest = json.loads(original_manifest_path.read_text())
    before_path = checked(original_manifest["input"])
    before_rows_path = checked(provenance["baseline_reactions"])
    split_path = args.analysis_dir.parent / "split_decisions.json"
    verified_analysis_artifact(provenance, split_path)
    examples_path = args.analysis_dir / "multicenter_examples.json"
    verified_analysis_artifact(manifest, examples_path)
    with before_rows_path.open() as stream:
        before_rows = list(csv.DictReader(stream, delimiter="\t"))
    return {
        "before_roots": json.loads(before_path.read_text()),
        "before_rows": before_rows,
        "split_decisions": json.loads(split_path.read_text()),
        "example_occurrences": json.loads(examples_path.read_text()),
    }, {
        "postprocess_manifest": file_record(path),
        "original_analysis_manifest": file_record(original_manifest_path),
        "before_routes": file_record(before_path),
        "before_rows": file_record(before_rows_path),
        "split_decisions": file_record(split_path),
        "examples": file_record(examples_path),
    }


def run(args):
    if args.workers < 1 or args.batch_size < 1:
        raise ValueError("workers and batch size must be positive")
    if args.output.exists() or args.output.resolve() == args.input.resolve():
        raise FileExistsError("use a separate, new output JSON")
    if args.work_dir.exists() and any(
        p.suffix != ".log" for p in args.work_dir.iterdir()
    ):
        raise FileExistsError("use a fresh work directory")
    roots, _rows, _grouped, cache, baseline = verify_baseline(
        args.input, args.analysis_dir, args.namerxn_path
    )
    original_record = file_record(args.input)
    baseline_record = file_record(args.analysis_dir / "manifest.json")
    views, view_provenance = visual_baseline(args, baseline)
    args.work_dir.mkdir(parents=True, exist_ok=True)
    write_json(
        args.work_dir / "progress.json", {"stage": "cleanup", "routes": len(roots)}
    )
    transformed, entries, decisions = [], [], []
    with ProcessPoolExecutor(
        max_workers=args.workers,
        mp_context=get_context("spawn"),
        initializer=analysis.initialize_worker,
    ) as pool:
        for i, (_index, cleaned, audit, decision) in enumerate(
            pool.map(_clean_item, enumerate(roots)), 1
        ):
            transformed.append(cleaned)
            entries.extend(audit)
            decisions.append(decision)
            if i % 100 == 0 or i == len(roots):
                print(
                    json.dumps({"stage": "cleanup", "routes": i, "total": len(roots)}),
                    flush=True,
                )
    cleanup = write_cleanup_audit(args.work_dir, entries)
    analysis.tsv(args.work_dir / "route_decisions.tsv", decisions)
    before_count = sum(1 for r in roots for _ in reaction_nodes(r))
    after_count = sum(1 for r in transformed for _ in reaction_nodes(r))
    assert len(transformed) == len(roots)
    assert before_count - after_count == cleanup["summary"]["pruned_reaction_nodes"]
    for before, after, decision in zip(roots, transformed, decisions):
        assert before["metadata"]["path_id"] == after["metadata"]["path_id"]
        assert before["smiles"] == after["smiles"]
        if decision["status"] != "cleaned":
            assert before == after
    staged = args.work_dir / "routes.staging.json"
    write_json(staged, transformed)
    out = args.work_dir / "analysis"
    out.mkdir()
    opts = SimpleNamespace(
        routes_json=staged,
        output_dir=out,
        workers=args.workers,
        batch_size=args.batch_size,
        namerxn_path=args.namerxn_path,
        config=args.config,
        show_cleaned_after=True,
        visual_examples=len(views["example_occurrences"]),
        **views,
    )
    fingerprint = file_record(staged)
    scanned = analysis.scan(opts, transformed, fingerprint)
    write_json(
        out / "cx_input_support.json", analysis.restore_supported_cx_inputs(scanned)
    )
    write_json(
        out / "classifier_input_fallbacks.json",
        analysis.restore_serialization_only_inputs(scanned),
    )
    errors = [
        e
        for r in scanned
        for category in ("mapping_errors", "errors")
        for e in r[category]
    ]
    analysis.tsv(args.work_dir / "errors.tsv", errors)
    if errors:
        raise ValueError("final corpus validation failed; output not published")
    reactions = [row for r in scanned for row in r["reactions"]]
    classified = classify_processed(
        opts, reactions, cache, baseline_record, force_generated=False
    )
    smoke = analysis.smoke_library(opts, transformed, scanned, fingerprint)
    analysis.report(opts, transformed, scanned, classified, smoke, fingerprint)
    final_analysis = json.loads((out / "summary.json").read_text())
    if final_analysis["mapping_error_records"] or final_analysis["other_error_records"]:
        raise ValueError("analysis or report errors; output not published")
    selected = json.loads((out / "multicenter_examples.json").read_text())
    assert [(e["path_id"], e["source_row"], e["node_path"]) for e in selected] == [
        (e["path_id"], e["source_row"], e["node_path"])
        for e in views["example_occurrences"]
    ]
    assert (
        file_record(args.input) == original_record
        and file_record(args.analysis_dir / "manifest.json") == baseline_record
    )
    for record in view_provenance.values():
        checked(record)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pending = args.output.with_name(args.output.name + ".pending")
    if pending.exists() or args.output.exists():
        raise FileExistsError("output appeared during processing")
    shutil.copy2(staged, pending)
    assert file_record(pending)["sha256"] == fingerprint["sha256"]
    pending.replace(args.output)
    summary = {
        **cleanup["summary"],
        "input_routes": len(roots),
        "output_routes": len(transformed),
        "input_reaction_nodes": before_count,
        "output_reaction_nodes": after_count,
        "unchanged_routes": sum(d["status"] == "unchanged" for d in decisions),
        "rolled_back_routes": sum(d["status"] == "rolled_back" for d in decisions),
        "route_order_and_targets_preserved": True,
        "input_unchanged": True,
        "analysis": final_analysis,
    }
    write_json(args.work_dir / "summary.json", summary)
    write_json(
        args.work_dir / "progress.json", {"stage": "complete", "routes": len(roots)}
    )
    manifest = {
        "format": "route-inspector.absynth.reactant-cleanup.v1",
        "runtime": runtime_provenance(),
        "input": original_record,
        "output": file_record(args.output),
        "baseline_analysis": baseline_record,
        "baseline_reactions": file_record(args.analysis_dir / "reactions.tsv"),
        "baseline_classifications": file_record(
            args.analysis_dir / "classifications.json"
        ),
        "visual_provenance": view_provenance,
        "analysis_manifest": file_record(out / "manifest.json"),
        "policy": {
            "name": POLICY,
            "rule": "whole component with zero local-target mapped atom overlap",
            "unused_branches": "prune this occurrence; archive complete subtree",
            "failure": "whole-route rollback",
            "rerun_graphormer": False,
            "rerun_filters_or_splitting": False,
            "box_solid": False,
        },
        "settings": {"workers": args.workers, "batch_size": args.batch_size},
        "versions": {p: version(p) for p in ("SynPlanner", "chython-synplan", "rdkit")},
        "implementation": [
            file_record(Path(p))
            for p in (
                "route_inspector/datasets/absynth/cleanup.py",
                "route_inspector/routes/cleanup.py",
                "route_inspector/routes/normalization.py",
                "route_inspector/routes/alignment.py",
                "route_inspector/datasets/absynth/reporting.py",
                "route_inspector/datasets/absynth/analysis.py",
                "route_inspector/datasets/absynth/postprocess.py",
            )
        ],
        "summary": summary,
        "artifacts": [
            file_record(p)
            for p in sorted(args.work_dir.iterdir())
            if p.is_file() and p.suffix in {".json", ".jsonl", ".tsv"}
        ],
    }
    write_json(args.work_dir / "manifest.json", manifest)
    print(json.dumps(summary, indent=2), flush=True)
