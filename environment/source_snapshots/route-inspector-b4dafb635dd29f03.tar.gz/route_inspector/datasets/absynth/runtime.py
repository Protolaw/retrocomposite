"""Runtime and reviewed-input evidence for private ABSynth computations."""

from __future__ import annotations

import hashlib
import importlib.metadata as metadata
import inspect
import json
import os
import platform
import subprocess
import sys
from functools import lru_cache
from pathlib import Path

BUNDLE_ROLES = (
    "input",
    "condition_registry",
    "condition_overrides",
    "reaction_overrides",
    "route_exclusions",
    "pubchem_cache",
)


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def verify_reviewed_bundle(path: Path, inputs: dict[str, Path]) -> dict:
    """Use historical expected hashes, never rewrite them to fit local files.

    The original conversion manifest is sufficient: its six named input records
    contain the expected hashes. Recorded historical paths are not dereferenced;
    callers supply relocated files explicitly.
    """
    expected = json.loads(path.read_text())
    verified = {}
    for role in BUNDLE_ROLES:
        record = expected.get(role) if isinstance(expected, dict) else None
        sha = record.get("sha256") if isinstance(record, dict) else None
        if (
            not isinstance(sha, str)
            or len(sha) != 64
            or any(c not in "0123456789abcdef" for c in sha)
        ):
            raise ValueError(f"Reviewed bundle has no valid expected hash for {role}")
        supplied = inputs.get(role)
        if supplied is None or not supplied.is_file():
            raise FileNotFoundError(f"Reviewed bundle requires {role}")
        if digest(supplied) != sha:
            raise ValueError(f"Reviewed bundle hash mismatch: {role}")
        verified[role] = {"path": str(supplied), "sha256": sha}
    return {"manifest": {"path": str(path), "sha256": digest(path)}, "inputs": verified}


def mapping_options(*, device: str, no_amp: bool = False) -> dict:
    if device not in {"cpu", "cuda", "mps"}:
        raise ValueError("mapping device must be cpu, cuda or mps")
    amp = device != "cpu" and not no_amp
    return {"device": device, "no_amp": not amp}


def mapping_execution(settings: dict, *, mode: str) -> dict:
    """Do not misattribute a reused snapshot to the current device or precision."""
    fresh = mode != "reuse"
    return {
        "mode": mode,
        "device": settings["device"] if fresh else None,
        "amp": not settings["no_amp"] if fresh else None,
        "precision": ("autocast" if not settings["no_amp"] else "float32")
        if fresh
        else None,
        "scope": "new predictions only" if mode == "incremental" else mode,
    }


def mapper_identity() -> dict:
    """Fingerprint the model provider actually loaded by native SynPlanner.

    Do not require a separately named distribution or import an optional mapper
    merely to report a reused/mocked run. Native mapping loads its own provider.
    """
    provider = "synplan.chem.reaction.curation.mapping"
    native = sys.modules.get(provider)
    if native is None or not hasattr(native, "Model"):
        return {"provider": provider, "available": False}
    source = Path(inspect.getfile(native.Model))
    weights = [
        {
            "path": os.path.relpath(p),
            "sha256": digest(p),
        }
        for p in sorted(source.parent.iterdir())
        if p.suffix in {".pt", ".pth", ".pkl", ".ckpt", ".safetensors"} and p.is_file()
    ]
    return {
        "provider": provider,
        "model_class": f"{native.Model.__module__}.{native.Model.__qualname__}",
        "source": {"path": os.path.relpath(source), "sha256": digest(source)},
        "available": True,
        "weights": weights,
    }


@lru_cache(maxsize=1)
def runtime_provenance() -> dict:
    """Record dependency versions and code content separately from Git revision."""
    root = Path(__file__).resolve().parents[3]
    code = {
        str(p.relative_to(root)): digest(p)
        for p in sorted((root / "route_inspector").rglob("*.py"))
    }
    try:
        revision = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=root,
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        revision = None
    dependencies = sorted(
        {
            (d.metadata["Name"], d.version)
            for d in metadata.distributions()
            if d.metadata["Name"]
        }
    )
    return {
        "git_revision": revision,
        "code_sha256": hashlib.sha256(
            json.dumps(code, sort_keys=True).encode()
        ).hexdigest(),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "dependencies": dict(dependencies),
        "invocation": [
            "python",
            *[
                str(Path(a).relative_to(root))
                if Path(a).is_absolute() and Path(a).is_relative_to(root)
                else a
                for a in sys.argv
            ],
        ],
    }


def mapping_preflight(device: str, no_amp: bool) -> dict:
    """Load installed weights on the requested device; predict no chemistry."""
    from synplan.chem.reaction.curation import mapping

    options = mapping_options(device=device, no_amp=no_amp)
    config = mapping.MappingConfig(**options)
    effective = str(mapping.select_device(config.device))
    if effective.split(":")[0] != device:
        raise RuntimeError(f"Requested {device}, mapper selected {effective}")
    model = mapper_identity()
    if not model["available"] or not model["weights"]:
        raise RuntimeError(
            "Native SynPlanner mapper weights could not be fingerprinted"
        )
    loaded = mapping.Model().to(effective)
    dtypes = sorted({str(parameter.dtype) for parameter in loaded.parameters()})
    if dtypes != ["torch.float32"]:
        raise RuntimeError(f"Unexpected mapper parameter precision: {dtypes}")
    return {
        "runtime": runtime_provenance(),
        "model": model,
        "mapping": mapping_execution(options, mode="fresh"),
        "torch": metadata.version("torch"),
        "model_loaded": True,
        "parameter_dtypes": dtypes,
    }


def classifier_preflight(path: Path) -> dict:
    """Require a working local NameRXN classification, not only an executable bit."""
    from tempfile import TemporaryDirectory

    from route_inspector.chemistry.classification.providers import _resolve_executable

    executable = Path(_resolve_executable(path)).resolve()
    identity = digest(executable)
    try:
        help_result = subprocess.run(
            [str(executable), "-help"],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        with TemporaryDirectory(prefix="absynth-namerxn-") as directory:
            source, output = Path(directory) / "in.smi", Path(directory) / "out.smi"
            source.write_text("CO>>C=O absynth-preflight\n")
            result = subprocess.run(
                [str(executable), "-nomap", str(source), str(output)],
                capture_output=True,
                text=True,
                timeout=30,
                check=False,
            )
            lines = output.read_text().splitlines() if output.is_file() else []
            parts = lines[0].rsplit(maxsplit=2) if len(lines) == 1 else []
            if result.returncode or len(parts) != 3 or parts[1] != "absynth-preflight":
                raise RuntimeError(
                    "NameRXN synthetic classification failed; verify the local installation and license"
                )
            from route_inspector.datasets.absynth.analysis import parse_codes

            if parse_codes(parts[2])["status"] != "classified":
                raise RuntimeError(
                    "NameRXN did not classify the synthetic oxidation; verify its license and data files"
                )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(
            f"NameRXN cannot execute on this {platform.system()} host: {exc}"
        ) from exc
    if digest(executable) != identity:
        raise RuntimeError("NameRXN executable changed during preflight")
    return {
        "executable": path.name,
        "sha256": identity,
        "version_output_sha256": hashlib.sha256(
            (help_result.stdout + help_result.stderr).encode()
        ).hexdigest(),
        "synthetic_classification": parts[2],
        "platform": platform.platform(),
    }
