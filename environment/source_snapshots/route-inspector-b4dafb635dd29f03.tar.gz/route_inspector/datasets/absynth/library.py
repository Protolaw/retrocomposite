"""Strict library eligibility without modifying the complete ABSynth corpus."""

from __future__ import annotations

import tempfile
from collections import Counter
from pathlib import Path

from route_inspector.datasets.absynth.runtime import digest, runtime_provenance
from route_inspector.infrastructure.artifacts import write_json
from route_inspector.infrastructure.publication import publish_directory_no_replace
from route_inspector.infrastructure.text import write_tsv
from route_inspector.routes.io import iter_route_json_file
from route_inspector.routes.validation import (
    ROUTE_MAPPING_VALIDATION_FIELDS,
    validate_routes_mapping,
)


def prepare_reference_inputs(
    source: Path, *, expected_sha256: str, audit_dir: Path
) -> tuple[tuple[str, dict], ...]:
    """Audit every clean route under production defaults and retain accepted IDs.

    Array offsets remain source route IDs; opaque PathId/StepId values stay in
    metadata. No renumbered subset is written. Pass the returned items and the
    *complete* source digest to the standard Reference-library builder, which
    still validates and extracts every accepted route under its normal policy.
    Extraction errors are never suppressed by this eligibility check.
    """
    if audit_dir.exists():
        raise FileExistsError(f"preserve the existing eligibility audit: {audit_dir}")
    if digest(source) != expected_sha256:
        raise ValueError("clean ABSynth source hash mismatch")
    accepted, excluded, errors = [], [], []
    for route_id, route in iter_route_json_file(source):
        key = str(route_id)
        result = validate_routes_mapping({key: route}, dataset="absynth")
        if result.records:
            excluded.append(key)
            path_id = route.get("metadata", {}).get("path_id", "")
            errors.extend({**record, "path_id": path_id} for record in result.records)
        else:
            accepted.append((key, route))
    if digest(source) != expected_sha256:
        raise ValueError("clean ABSynth source changed during eligibility audit")
    summary = {
        "routes_seen": len(accepted) + len(excluded),
        "routes_accepted": len(accepted),
        "routes_excluded": len(excluded),
        "error_records": len(errors),
        "failures_by_stage": dict(sorted(Counter(e["stage"] for e in errors).items())),
    }
    audit_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        prefix=".absynth-selection-", dir=audit_dir.parent
    ) as work:
        staged = Path(work) / "audit"
        staged.mkdir()
        write_json(staged / "summary.json", summary)
        write_tsv(
            staged / "errors.tsv", [*ROUTE_MAPPING_VALIDATION_FIELDS, "path_id"], errors
        )
        write_json(
            staged / "manifest.json",
            {
                "format": "route-inspector.absynth-library-selection.v1",
                "source": {"path": str(source), "sha256": expected_sha256},
                "policy": "strict production validation; stereo-only steps remain in clean data but exclude the complete route from the library",
                "accepted_route_ids": [key for key, _ in accepted],
                "excluded_route_ids": excluded,
                "runtime": runtime_provenance(),
                "summary": summary,
                "artifacts": {
                    name: {"sha256": digest(staged / name)}
                    for name in ("summary.json", "errors.tsv")
                },
            },
        )
        publish_directory_no_replace(staged, audit_dir)
    return tuple(accepted)
