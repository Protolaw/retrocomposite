"""Three-entrypoint ABSynth workflow; all intermediate artifacts stay local."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

from route_inspector.chemistry.classification.providers import _resolve_executable
from route_inspector.datasets.absynth import analysis as analysis
from route_inspector.datasets.absynth import cleanup as cleanup
from route_inspector.datasets.absynth import postprocess as splitting
from route_inspector.datasets.absynth.config import (
    DEFAULT_SOURCE_SNAPSHOT as DEFAULT_SOURCE_SNAPSHOT,
)
from route_inspector.datasets.absynth.config import require_local_config
from route_inspector.datasets.absynth.filtering import filter_routes

DEFAULT_WORK_DIR = Path("data/tmp/absynth")


def verify_source_snapshot(input_path: Path, snapshot_path: Path) -> dict:
    """Reject a different CSV before applying physical-row-based corrections."""
    if not input_path.is_file():
        raise FileNotFoundError(
            f"ABSynth is not bundled: request academic access at https://allchemy.net/#absynth "
            f"and place the reviewed source at {input_path}"
        )
    snapshot = json.loads(require_local_config(snapshot_path).read_text())
    with input_path.open("rb") as stream:
        actual = hashlib.file_digest(stream, "sha256").hexdigest()
    if snapshot.get("sha256") != actual:
        raise ValueError(
            "ABSynth source snapshot mismatch: these occurrence overrides target a reviewed CSV. "
            "Review source changes and the override identities, then supply their matching "
            "--source-snapshot; do not apply corrections by row number to a different download."
        )
    return {"path": str(input_path), "sha256": actual, "snapshot": str(snapshot_path)}


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--stage", choices=("all", "filter", "split", "clean"), default="all"
    )
    parser.add_argument("--work-dir", type=Path, default=DEFAULT_WORK_DIR)
    parser.add_argument(
        "--input", type=Path, help="Default: prerequisite snapshot beneath --work-dir."
    )
    parser.add_argument(
        "--analysis-dir", type=Path, help="Hash-matched analysis of --input."
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Default: stage snapshot, or data/clean/absynth_routes.json.",
    )
    parser.add_argument("--namerxn-path", type=Path, required=True)
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("route_inspector/configs/rule_extraction_functional_groups.yaml"),
    )
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=1000)
    parser.add_argument("--visual-examples", type=int, default=50)
    return parser


def _assert_analysis(directory):
    manifest = json.loads((directory / "manifest.json").read_text())
    summary = manifest["summary"]
    if summary["mapping_error_records"] or summary.get("other_error_records", 0):
        raise ValueError(f"stage validation failed; inspect {directory}")


def run(args):
    if args.workers < 1 or args.batch_size < 1 or args.visual_examples < 0:
        raise ValueError(
            "workers and batch size must be positive; visual examples nonnegative"
        )
    root = args.work_dir
    stages = ("filter", "split", "clean") if args.stage == "all" else (args.stage,)
    names = {
        "filter": ("raw", "filtered"),
        "split": ("filtered", "postprocessed"),
        "clean": ("postprocessed", "cleaned"),
    }
    initial = names[stages[0]][0]
    input_path = args.input or root / initial / "absynth_routes.json"
    analysis_dir = args.analysis_dir or root / initial / "analysis"
    destinations = []
    for stage in stages:
        work = root / names[stage][1]
        output = (
            Path("data/clean/absynth_routes.json")
            if stage == "clean"
            else work / "absynth_routes.json"
        )
        if args.output is not None and stage == stages[-1]:
            output = args.output
        if output.exists() or output.resolve() == input_path.resolve():
            raise FileExistsError(
                f"preserve the existing snapshot; choose a new output: {output}"
            )
        if work.exists() and any(work.iterdir()):
            raise FileExistsError(f"use a fresh stage directory: {work}")
        destinations.append((stage, work, output))
    executable = _resolve_executable(args.namerxn_path)
    for stage, work, output in destinations:
        options = SimpleNamespace(
            input=input_path,
            analysis_dir=analysis_dir,
            output=output,
            work_dir=work,
            namerxn_path=executable,
            config=args.config,
            workers=args.workers,
            batch_size=args.batch_size,
            visual_examples=args.visual_examples,
        )
        if stage == "filter":
            filter_routes(input_path, analysis_dir, output, work)
            analysis.run(
                SimpleNamespace(
                    routes_json=output,
                    output_dir=work / "analysis",
                    workers=args.workers,
                    batch_size=args.batch_size,
                    namerxn_path=executable,
                    config=args.config,
                    visual_examples=args.visual_examples,
                    classification_baseline=analysis_dir,
                )
            )
        elif stage == "split":
            splitting.run(options)
        else:
            cleanup.run(options)
        _assert_analysis(work / "analysis")
        input_path, analysis_dir = output, work / "analysis"
    return {
        "output": str(input_path),
        "analysis_dir": str(analysis_dir),
        "stages": list(stages),
    }


def main():
    print(json.dumps(run(build_parser().parse_args()), indent=2))
    return 0
