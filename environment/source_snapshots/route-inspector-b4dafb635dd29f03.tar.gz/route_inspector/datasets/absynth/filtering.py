"""Audited whole-route filtering of an already mapped ABSynth snapshot."""

from __future__ import annotations

import csv
import json
import re
import shutil
from collections import Counter, defaultdict
from pathlib import Path

from route_inspector.datasets.absynth.runtime import runtime_provenance
from route_inspector.infrastructure.artifacts import write_json
from route_inspector.infrastructure.hashing import file_record
from route_inspector.infrastructure.text import write_tsv
from route_inspector.routes.access import reaction_nodes

FILTER_VERSION = 1
ALL_SIX = "mixed_classes_all_6"
MULTICENTER = "more_than_two_centers"


def mixed_classes_all_six(raw_code: str) -> bool:
    """Require distinct Tier-3 classes and every raw annotation to be valid 6.*."""
    labels = raw_code.split(";") if raw_code else []
    if not labels or any(
        not re.fullmatch(r"6\.\d+\.\d+(?:\.\d+)*", code) for code in labels
    ):
        return False
    return len({".".join(code.split(".")[:3]) for code in labels}) > 1


def exclusion_reasons(raw_code: str, center_count: int) -> list[str]:
    if (
        not isinstance(center_count, int)
        or isinstance(center_count, bool)
        or center_count < 0
    ):
        raise ValueError("center_count must be a known non-negative integer")
    reasons = [ALL_SIX] if mixed_classes_all_six(raw_code) else []
    if center_count > 2:
        reasons.append(MULTICENTER)
    return reasons


def verified_analysis_artifact(manifest: dict, path: Path) -> dict:
    declarations = [
        item
        for item in manifest["artifacts"]
        if Path(item["path"]).resolve() == path.resolve()
    ]
    if (
        len(declarations) != 1
        or declarations[0]["sha256"] != file_record(path)["sha256"]
    ):
        raise ValueError(f"missing, ambiguous or stale analysis artifact: {path}")
    return declarations[0]


def filter_routes(
    input_path: Path, analysis_dir: Path, output_path: Path, work_dir: Path
) -> dict:
    """Preserve retained route objects exactly; exclude the union of both policies."""
    if input_path.resolve() == output_path.resolve():
        raise ValueError(
            "use a separate filtered output; preserve the original conversion manifest"
        )
    if output_path.exists():
        raise FileExistsError(output_path)
    work_dir.mkdir(parents=True, exist_ok=True)
    if (work_dir / "manifest.json").exists() or (
        work_dir / "unfiltered_routes.json"
    ).exists():
        raise FileExistsError("use a fresh post-processing work directory")
    input_record = file_record(input_path)
    analysis_path = analysis_dir / "manifest.json"
    analysis = json.loads(analysis_path.read_text())
    if analysis["input"]["sha256"] != input_record["sha256"]:
        raise ValueError("analysis does not describe this exact input JSON")
    if analysis["summary"]["mapping_error_records"] != 0:
        raise ValueError(
            "baseline analysis has mapping errors; filtering is not a mapping repair"
        )
    reactions_path, classes_path = (
        analysis_dir / "reactions.tsv",
        analysis_dir / "classifications.json",
    )
    verified_analysis_artifact(analysis, reactions_path)
    verified_analysis_artifact(analysis, classes_path)
    classifications = json.loads(classes_path.read_text())
    with reactions_path.open() as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    audited = {}
    for row in rows:
        key = row["path_id"], tuple(json.loads(row["node_path"]))
        if key in audited:
            raise ValueError(f"duplicate reaction occurrence: {key}")
        audited[key] = row
    roots = json.loads(input_path.read_text())
    if not isinstance(roots, list):
        raise ValueError("ABSynth filter requires a top-level route list")
    if len(roots) != analysis["summary"]["input_routes"]:
        raise ValueError("analysis route count differs")
    seen, path_ids, triggers = set(), set(), []
    reasons_by_route, counts = defaultdict(set), Counter()
    for route_index, root in enumerate(roots):
        pid = str(root["metadata"]["path_id"])
        if pid in path_ids:
            raise ValueError(f"duplicate PathId: {pid}")
        path_ids.add(pid)
        for path, node in reaction_nodes(root):
            key = pid, path
            if key not in audited:
                raise ValueError(f"missing analysis occurrence: {key}")
            row, meta = audited[key], node["metadata"]
            if (
                row["mapped_reaction"] != node["smiles"]
                or row["step_id"] != str(meta["step_id"])
                or int(row["source_row"]) != int(meta["source_row"])
                or int(row["route_index"]) != route_index
            ):
                raise ValueError(f"analysis provenance differs from JSON: {key}")
            label = classifications[row["classification_id"]]
            if (
                label["raw_code"] != row["raw_code"]
                or label["classifier_input"] != row["classifier_input"]
            ):
                raise ValueError(f"NameRXN result differs from occurrence: {key}")
            center_count = int(row["center_count"])
            if len(json.loads(row["center_components"])) != center_count:
                raise ValueError(f"center component count differs: {key}")
            reasons = exclusion_reasons(row["raw_code"], center_count)
            if reasons:
                triggers.append(
                    {
                        "path_id": pid,
                        "source_row": meta["source_row"],
                        "step_id": meta["step_id"],
                        "node_path": json.dumps(path),
                        "raw_code": row["raw_code"],
                        "center_count": center_count,
                        "reasons": json.dumps(reasons),
                    }
                )
                reasons_by_route[pid].update(reasons)
            counts[pid] += 1
            seen.add(key)
    if seen != set(audited) or len(seen) != analysis["summary"]["reaction_nodes"]:
        raise ValueError("analysis contains missing or extra reaction occurrences")
    removed = set(reasons_by_route)
    kept = [root for root in roots if str(root["metadata"]["path_id"]) not in removed]
    old_indices = {
        str(root["metadata"]["path_id"]): index for index, root in enumerate(roots)
    }
    new_indices = {
        str(root["metadata"]["path_id"]): index for index, root in enumerate(kept)
    }
    decisions = [
        {
            "path_id": pid,
            "input_route_index": index,
            "output_route_index": new_indices.get(pid, ""),
            "action": "removed" if pid in removed else "retained",
            "reaction_nodes": counts[pid],
            "reasons": json.dumps(sorted(reasons_by_route[pid])),
        }
        for pid, index in old_indices.items()
    ]
    before = work_dir / "unfiltered_routes.json"
    shutil.copy2(input_path, before)
    if file_record(before)["sha256"] != input_record["sha256"]:
        raise ValueError("source changed during backup")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_path.with_name(output_path.name + ".postfilter.tmp")
    if temporary.exists():
        raise FileExistsError(temporary)
    write_json(temporary, kept)
    if json.loads(temporary.read_text()) != kept:
        raise ValueError("output round trip changed retained routes")
    if file_record(input_path) != input_record:
        raise ValueError("source changed during filtering")
    if output_path.exists():
        raise FileExistsError(output_path)
    temporary.replace(output_path)
    write_tsv(
        work_dir / "trigger_reactions.tsv",
        [
            "path_id",
            "source_row",
            "step_id",
            "node_path",
            "raw_code",
            "center_count",
            "reasons",
        ],
        triggers,
    )
    fields = [
        "path_id",
        "input_route_index",
        "output_route_index",
        "action",
        "reaction_nodes",
        "reasons",
    ]
    write_tsv(work_dir / "route_decisions.tsv", fields, decisions)
    write_tsv(
        work_dir / "removed_routes.tsv",
        fields,
        [r for r in decisions if r["action"] == "removed"],
    )
    a = {pid for pid in removed if ALL_SIX in reasons_by_route[pid]}
    b = {pid for pid in removed if MULTICENTER in reasons_by_route[pid]}
    summary = {
        "input_routes": len(roots),
        "output_routes": len(kept),
        "removed_routes": len(removed),
        "mixed_classes_all_6_routes": len(a),
        "more_than_two_center_routes": len(b),
        "overlap_routes": len(a & b),
        "only_mixed_classes_all_6_routes": len(a - b),
        "only_more_than_two_center_routes": len(b - a),
        "input_reaction_nodes": len(seen),
        "output_reaction_nodes": sum(counts[pid] for pid in new_indices),
        "removed_reaction_nodes": sum(counts[pid] for pid in removed),
        "trigger_reaction_nodes": len(triggers),
        "retained_route_objects_unchanged": True,
        "input_unchanged": True,
        "filter_version": FILTER_VERSION,
    }
    assert len(roots) == len(kept) + len(removed) and len(removed) == len(a) + len(
        b
    ) - len(a & b)
    write_json(work_dir / "summary.json", summary)
    write_tsv(work_dir / "errors.tsv", ["stage", "message"], [])
    write_json(
        work_dir / "manifest.json",
        {
            "input": input_record,
            "runtime": runtime_provenance(),
            "output": file_record(output_path),
            "implementation": file_record(Path(__file__).relative_to(Path.cwd())),
            "backup": file_record(before),
            "analysis_manifest": file_record(analysis_path),
            "analysis_reactions": file_record(reactions_path),
            "analysis_classifications": file_record(classes_path),
            "policy": {
                "version": FILTER_VERSION,
                "combine": "OR, remove complete route",
                "all_6": "at least two distinct numeric Tier-3 classes in one reaction and every raw annotation is valid 6.*",
                "centers": "Chython CGR.centers_list component count strictly greater than two",
                "unknown_classes": "not an all-6 match; still apply center criterion",
                "molecules_maps_and_metadata": "unchanged",
                "route_order": "preserved; list indices compacted",
            },
            "summary": summary,
            "artifacts": [
                file_record(work_dir / name)
                for name in (
                    "summary.json",
                    "route_decisions.tsv",
                    "removed_routes.tsv",
                    "trigger_reactions.tsv",
                    "errors.tsv",
                )
            ],
        },
    )
    return summary
