"""Conservative route-level reuse for an audited ABSynth baseline snapshot.

This module never patches atom maps. Any changed source occurrence or donor
selection invalidates the entire containing route; unchanged routes retain
their exact JSON objects and step-local mappings, including prior exclusions.
"""

from __future__ import annotations

import csv
import json
from collections import defaultdict
from dataclasses import asdict
from pathlib import Path

from route_inspector.infrastructure.artifacts import write_json
from route_inspector.infrastructure.text import write_tsv


def read_tsv(path):
    if not path.exists():
        return []
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def changed_route_reasons(
    old_rows,
    new_rows,
    old_conditions,
    new_conditions,
    old_exclusions=(),
    new_exclusions=(),
):
    """Return affected PathIds without pairing ambiguous duplicate StepIds."""
    old_groups, new_groups = defaultdict(list), defaultdict(list)
    for row in old_rows:
        old_groups[row.path_id].append(asdict(row))
    for row in new_rows:
        new_groups[row.path_id].append(asdict(row))
    reasons = defaultdict(set)
    for pid in old_groups.keys() | new_groups.keys():
        if old_groups.get(pid) != new_groups.get(pid):
            reasons[pid].add("source_occurrence_or_metadata_changed")
    for pid in set(old_exclusions) ^ set(new_exclusions):
        reasons[pid].add("route_exclusion_policy_changed")

    def group_conditions(rows):
        grouped = defaultdict(list)
        for row in rows:
            grouped[row["path_id"]].append(
                (
                    int(row["source_row"]),
                    row["step_id"],
                    row["status"],
                    row["resolution_method"],
                    row["deficit"],
                    row["conditions"],
                    json.loads(row["selected_donors"]),
                    row["original_rxn_smiles"],
                    row["enriched_rxn_smiles"],
                )
            )
        return grouped

    old_cond, new_cond = (
        group_conditions(old_conditions),
        group_conditions(new_conditions),
    )
    for pid in old_cond.keys() | new_cond.keys():
        if old_cond.get(pid) != new_cond.get(pid):
            reasons[pid].add("condition_resolution_or_donor_provenance_changed")
    return {pid: sorted(items) for pid, items in reasons.items()}


class IncrementalBaseline:
    """Read and validate an immutable, separately backed-up conversion."""

    def __init__(
        self,
        directory: Path,
        output: Path,
        source_rows,
        condition_rows,
        exclusions,
        candidates,
        work_dir: Path,
    ):
        from route_inspector.datasets.absynth import conversion as absynth

        self.directory, self.work_dir = directory, work_dir
        self.manifest_path = directory / "manifest.json"
        self.manifest = json.loads(self.manifest_path.read_text())
        self.output_path = output
        if absynth._sha256(output) != self.manifest["output_sha256"]:
            raise absynth.ABSynthError("incremental baseline output hash mismatch")
        self.output = json.loads(output.read_text())
        if len(self.output) != self.manifest["summary"]["output_routes"]:
            raise absynth.ABSynthError("incremental baseline route count mismatch")
        self.routes = {r["metadata"]["path_id"]: r for r in self.output}
        if len(self.routes) != len(self.output):
            raise absynth.ABSynthError("duplicate baseline PathId")
        source_spec = self.manifest["input"]
        source_path = directory / "runtime_snapshot" / Path(source_spec["path"]).name
        if not source_path.exists():
            source_path = Path(source_spec["path"])
        if absynth._sha256(source_path) != source_spec["sha256"]:
            raise absynth.ABSynthError("incremental baseline source hash mismatch")
        self.old_rows = absynth.load_absynth(source_path)
        for filename, section in [
            ("mapping_input.smi", "input"),
            ("mapped_reactions.smi", "output"),
        ]:
            if (
                absynth._sha256(directory / filename)
                != self.manifest["mapping_snapshot"][section]["sha256"]
            ):
                raise absynth.ABSynthError(
                    f"incremental baseline hash mismatch: {filename}"
                )
        # Published review artifacts have explicit hashes. Minimal converter
        # manifests (e.g. isolated test runs) may not have an artifact inventory.
        prefix = self.manifest["summary"]["work_dir"].rstrip("/") + "/"
        for item in self.manifest.get("artifacts", []):
            original = item.get("path", "")
            if original.startswith(prefix) and "/" not in original[len(prefix) :]:
                path = directory / original[len(prefix) :]
                if absynth._sha256(path) != item["sha256"]:
                    raise absynth.ABSynthError(
                        f"incremental baseline artifact hash mismatch: {path}"
                    )
        self.old_input = absynth._read_mapped_steps(directory / "mapping_input.smi")
        self.old_mapped = absynth._read_mapped_steps(directory / "mapped_reactions.smi")
        self.errors = read_tsv(directory / "route_errors.tsv")
        if set(self.routes) & {e["path_id"] for e in self.errors}:
            raise absynth.ABSynthError("baseline contains an emitted failed route")
        self.reasons = changed_route_reasons(
            self.old_rows,
            source_rows,
            read_tsv(directory / "condition_resolution.tsv"),
            condition_rows,
            (self.manifest.get("route_exclusions") or {}).get("path_ids", []),
            exclusions,
        )
        for pid, topology in candidates.items():
            if any(row.source_row not in self.old_input for row in topology.rows):
                self.reasons.setdefault(pid, []).append("no_prior_mapping_input")
        self.affected = set(self.reasons)
        self.candidate_ids = set(candidates)
        self.reused_routes = {
            pid: route
            for pid, route in self.routes.items()
            if pid in candidates and pid not in self.affected
        }
        self.mapping_stats = {}
        write_tsv(
            work_dir / "incremental_routes.tsv",
            ["path_id", "action", "reasons"],
            [
                {
                    "path_id": pid,
                    "action": "rebuild" if pid in candidates else "exclude_or_remove",
                    "reasons": json.dumps(sorted(set(self.reasons[pid]))),
                }
                for pid in sorted(
                    self.affected,
                    key=lambda p: min(
                        (
                            r.source_row
                            for r in [*self.old_rows, *source_rows]
                            if r.path_id == p
                        ),
                        default=0,
                    ),
                )
            ],
        )

    def carried_errors(self):
        return [
            e
            for e in self.errors
            if e["path_id"] in self.candidate_ids
            and e["path_id"] not in self.affected
            and e["stage"]
            not in {"mapping", "condition_resolution", "topology", "route_excluded"}
        ]

    def carried_audit(self, name):
        return [
            r
            for r in read_tsv(self.directory / name)
            if r["path_id"] in self.candidate_ids and r["path_id"] not in self.affected
        ]

    def map_affected(self, candidate_rows, selections, config, mapper, workers):
        from route_inspector.datasets.absynth import conversion as absynth

        fresh = [r for r in candidate_rows if r.path_id in self.affected]
        reused = [r for r in candidate_rows if r.path_id not in self.affected]
        for row in reused:
            if (
                self.old_input[row.source_row]
                != selections[row.source_row].enriched_rxn_smiles
            ):
                raise absynth.ABSynthError(
                    "attempted reuse of changed enriched reaction"
                )
        fresh_input, fresh_output = (
            self.work_dir / "revised_mapping_input.smi",
            self.work_dir / "revised_mapped_reactions.smi",
        )
        fresh_errors = self.work_dir / "revised_mapping_errors.tsv"
        absynth._write_mapping_input(fresh_input, fresh, selections)
        if fresh:
            mapper(
                config,
                fresh_input,
                fresh_output,
                num_workers=workers,
                silent=False,
                ignore_errors=False,
                error_file_path=fresh_errors,
            )
            mapped = absynth._read_mapped_steps(fresh_output)
            if not set(mapped) <= {r.source_row for r in fresh}:
                raise absynth.ABSynthError("mapper returned out-of-scope occurrences")
        else:
            fresh_output.write_text("")
            mapped = {}
        mapped.update(
            {
                r.source_row: self.old_mapped[r.source_row]
                for r in reused
                if r.source_row in self.old_mapped
            }
        )
        with (self.work_dir / "mapped_reactions.smi").open("w") as stream:
            for row in candidate_rows:
                if row.source_row in mapped:
                    stream.write(f"{mapped[row.source_row]}\t{row.source_row}\n")
        error_rows = read_tsv(fresh_errors)
        reused_ids = {r.source_row for r in reused}
        for error in read_tsv(self.directory / "mapping_errors.tsv"):
            sid = str(error.get("source_info", "")).split("\t", 1)[0]
            if sid.isdigit() and int(sid) in reused_ids:
                error_rows.append(error)
        fields = list(error_rows[0]) if error_rows else ["source_info", "error"]
        write_tsv(self.work_dir / "mapping_errors.tsv", fields, error_rows)
        self.mapping_stats = {
            "fresh_mapping_input_rows": len(fresh),
            "fresh_mapped_rows": sum(r.source_row in mapped for r in fresh),
            "reused_mapping_rows": sum(r.source_row in mapped for r in reused),
            "rebuilt_candidate_routes": len(self.affected & self.candidate_ids),
            "reused_output_routes": len(self.reused_routes),
            "affected_routes": len(self.affected),
        }

    def provenance(self, output_routes, *, cleanup_reprocessed_ids=frozenset()):
        from route_inspector.datasets.absynth import conversion as absynth

        output = {r["metadata"]["path_id"]: r for r in output_routes}
        for pid, original in self.reused_routes.items():
            if pid not in cleanup_reprocessed_ids and output.get(pid) != original:
                raise absynth.ABSynthError(f"unchanged route object mutated: {pid}")
        report = {
            **self.mapping_stats,
            "policy": "whole_changed_route_v1",
            "unchanged_route_objects_identical": True,
            "baseline_manifest": {
                "path": str(self.manifest_path),
                "sha256": absynth._sha256(self.manifest_path),
            },
            "baseline_output": {
                "path": str(self.output_path),
                "sha256": absynth._sha256(self.output_path),
            },
            "affected_path_ids": sorted(self.affected | set(cleanup_reprocessed_ids)),
            "reused_path_ids": sorted(
                set(self.reused_routes) - set(cleanup_reprocessed_ids)
            ),
            "cleanup_reprocessed_path_ids": sorted(cleanup_reprocessed_ids),
        }
        acceptance = self.directory / "acceptance.json"
        if acceptance.exists():
            accepted = json.loads(acceptance.read_text())
            if (
                not accepted.get("passed")
                or accepted.get("output_sha256") != self.manifest["output_sha256"]
            ):
                raise absynth.ABSynthError(
                    "baseline acceptance does not cover baseline output"
                )
            expected = self.manifest.get("acceptance", {}).get("sha256")
            if expected and absynth._sha256(acceptance) != expected:
                raise absynth.ABSynthError("baseline acceptance hash mismatch")
            report["baseline_acceptance"] = {
                "path": str(acceptance),
                "sha256": absynth._sha256(acceptance),
            }
        write_json(self.work_dir / "incremental_reuse.json", report)
        return report
