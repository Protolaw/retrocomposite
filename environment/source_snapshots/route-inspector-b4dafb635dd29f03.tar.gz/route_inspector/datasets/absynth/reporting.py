"""Provenance-aware names and full-route multicenter review reports."""

from __future__ import annotations

import copy
import json
import re
from collections import defaultdict, deque
from html import escape

from route_inspector import chemistry
from route_inspector.datasets.absynth.config import preferred_visual_steps
from route_inspector.infrastructure.artifacts import write_json
from route_inspector.routes.access import reaction_nodes


def class_name_display(row: dict, metadata: dict) -> dict:
    """CSV names are display fallback only, never a synthetic NameRXN label."""
    original = row.get("namerxn_class_names", row.get("class_names", []))
    if isinstance(original, str):
        original = json.loads(original)
    original = list(original or [])
    source_name = (metadata.get("rxn_name") or "").strip()
    known = any(str(value).strip() for value in original)
    return {
        "namerxn_class_names": original,
        "class_names": original if known else ([source_name] if source_name else []),
        "class_names_source": "namerxn"
        if known
        else "csv_rxn_name"
        if source_name
        else "empty",
        "rxn_name": source_name,
    }


def typed_row(row: dict) -> dict:
    row = dict(row)
    for key in (
        "node_path",
        "center_components",
        "center_atom_maps",
        "tier3_codes",
        "class_names",
        "reaction_names",
    ):
        if isinstance(row.get(key), str):
            row[key] = json.loads(row[key])
    row["source_row"], row["center_count"] = (
        int(row["source_row"]),
        int(row["center_count"]),
    )
    return row


def _sort_key(row):
    return (int(row["path_id"]), int(row["source_row"]), tuple(row["node_path"]))


def select_visual_examples(
    rows: list[dict],
    count: int = 50,
    *,
    preferred_step_ids: tuple[str, ...] = (),
) -> list[dict]:
    """Stable status/class round-robin, one example per physical occurrence."""
    if count < 0:
        raise ValueError("visual example count must be nonnegative")
    candidates = sorted((r for r in rows if int(r["center_count"]) > 1), key=_sort_key)
    unique = {}
    for row in candidates:
        unique.setdefault(int(row["source_row"]), row)
    candidates = list(unique.values())
    selected = []
    seen = set()

    def take(row):
        if row["source_row"] not in seen and len(selected) < count:
            selected.append(row)
            seen.add(row["source_row"])

    for step in preferred_step_ids:
        matches = [r for r in candidates if r["step_id"] == step]
        if matches:
            take(matches[0])
    grouped = defaultdict(lambda: defaultdict(list))
    for row in candidates:
        if row["source_row"] in seen:
            continue
        status = row.get("split_status", "unchanged")
        if status == "unchanged" and row.get("class_names_source") == "csv_rxn_name":
            status = "csv_fallback"
        combo = tuple(sorted(set(row.get("tier3_codes", []))))
        if not combo:
            combo = ("csv:" + row.get("rxn_name", ""),)
        grouped[status][combo].append(row)
    rings = {
        status: deque(deque(groups[key]) for key in sorted(groups))
        for status, groups in grouped.items()
    }
    status_order = [
        s
        for s in ("split", "unresolved", "rolled_back", "unchanged", "csv_fallback")
        if s in rings
    ]
    status_order += sorted(set(rings) - set(status_order))
    while len(selected) < min(count, len(candidates)):
        advanced = False
        for status in status_order:
            ring = rings[status]
            if not ring:
                continue
            group = ring.popleft()
            take(group.popleft())
            if group:
                ring.append(group)
            advanced = True
        if not advanced:
            break
    return selected


def render_full_route(
    root: dict, highlighted: list[tuple[tuple, str]], intermediate_split_id: str = ""
) -> str:
    """Render the entire tree; highlights are restricted to exact step edges."""
    from route_inspector.visualization.route import _prepare_json_route_svg_inputs
    from route_inspector.visualization.synplanner import _render_prepared_route

    drawn = copy.deepcopy(root)
    nodes = {}

    def walk(node, path=()):
        nodes[path] = node
        for index, child in enumerate(node.get("children") or []):
            walk(child, (*path, index))

    walk(drawn)
    main, deprotection, intermediates = {}, {}, {}
    for path, node in reaction_nodes(drawn):
        meta = node.get("metadata", {})
        stage = meta.get("absynth_deprotection_split", {}).get("forward_stage")
        node["rule_key"] = str(meta.get("step_id", "")) + (
            {1: " / main", 2: " / deprotect"}.get(stage, "")
        )
    for reaction_path, role in highlighted:
        node = nodes[reaction_path]
        center = set((~chemistry.parse_reaction(node["smiles"])).center_atoms)
        edges = [
            reaction_path[:-1],
            *(
                reaction_path + (i,)
                for i, child in enumerate(node.get("children") or [])
                if child.get("type") == "mol"
            ),
        ]
        destination = deprotection if role == "deprotection" else main
        for path in edges:
            atoms = center & set(chemistry.parse_molecule(nodes[path]["smiles"]))
            destination[path] = frozenset(set(destination.get(path, ())) | atoms)
    for path, node in nodes.items():
        meta = node.get("metadata", {})
        if (
            intermediate_split_id
            and node.get("type") == "mol"
            and meta.get("split_id") == intermediate_split_id
        ):
            intermediates[path] = frozenset(chemistry.parse_molecule(node["smiles"]))
    columns, pred = _prepare_json_route_svg_inputs(
        drawn,
        labeled=True,
        highlights=main,
        skipped_highlights={},
        pg_highlights={"deprotection": deprotection, "protection": intermediates},
    )
    svg = _render_prepared_route(drawn, columns, pred, box_solid=False)
    # Keep whole long routes readable in a horizontal/vertical scroll viewport.
    viewbox = re.search(r'viewBox="([^"]+)"', svg)
    if viewbox:
        width = max(1000, float(viewbox[1].split()[2]))
        svg = svg.replace("<svg ", f'<svg style="width:{width:.0f}px;height:auto" ', 1)
    return svg


def write_multicenter_report(
    output_dir,
    *,
    before_roots,
    after_roots,
    before_rows,
    after_rows,
    decisions=(),
    count=50,
    example_occurrences=None,
    show_cleaned_after=False,
):
    before = {str(r["metadata"]["path_id"]): r for r in before_roots}
    after = {str(r["metadata"]["path_id"]): r for r in after_roots}
    decisions_by_key = {
        (str(d["path_id"]), tuple(d["original_node_path"])): d for d in decisions
    }
    node_indexes = {pid: dict(reaction_nodes(root)) for pid, root in before.items()}
    review_rows = []
    for raw in before_rows:
        row = typed_row(raw)
        if row["center_count"] < 2:
            continue
        node = node_indexes[row["path_id"]][tuple(row["node_path"])]
        row.update(class_name_display(row, node["metadata"]))
        decision = decisions_by_key.get((row["path_id"], tuple(row["node_path"])), {})
        row.update(
            split_status=decision.get("status", "unchanged"),
            split_reason=decision.get("reason", ""),
            split_id=decision.get("split_id", ""),
        )
        review_rows.append(row)
    chosen = (
        select_visual_examples(
            review_rows, count, preferred_step_ids=preferred_visual_steps()
        )
        if example_occurrences is None
        else []
    )
    if example_occurrences is not None:
        indexed = {
            (r["path_id"], r["source_row"], tuple(r["node_path"])): r
            for r in review_rows
        }
        keys = [
            (str(r["path_id"]), int(r["source_row"]), tuple(r["node_path"]))
            for r in example_occurrences
        ]
        if len(set(keys)) != len(keys) or len({key[1] for key in keys}) != len(keys):
            raise ValueError("visual baseline must contain distinct source occurrences")
        chosen = [indexed[key] for key in keys]
    sections, examples = [], []
    generated_rows = {
        r.get("generated_stage_id"): r
        for r in after_rows
        if r.get("generated_stage_id")
    }
    for ordinal, row in enumerate(chosen, 1):
        pid, path = row["path_id"], tuple(row["node_path"])
        old_svg = render_full_route(before[pid], [(path, "main")])
        subtitle = (
            f"Path {pid} / Step {row['step_id']} / source row {row['source_row']}"
        )
        detail = {
            key: row[key]
            for key in (
                "path_id",
                "step_id",
                "source_row",
                "node_path",
                "raw_code",
                "class_names",
                "class_names_source",
                "split_status",
                "split_reason",
                "split_id",
            )
        }
        detail.update(
            example_index=ordinal,
            before_route_reaction_nodes=len(node_indexes[pid]),
            full_route=True,
        )
        drawings = (
            '<details open><summary>Before: complete recorded route</summary><div class="diagram">'
            + old_svg
            + "</div></details>"
        )
        stages = []
        if row["split_status"] == "split":
            paths = [
                (
                    p,
                    "deprotection"
                    if n["metadata"]["absynth_deprotection_split"]["forward_stage"] == 2
                    else "main",
                )
                for p, n in reaction_nodes(after[pid])
                if n.get("metadata", {})
                .get("absynth_deprotection_split", {})
                .get("split_id")
                == row["split_id"]
            ]
            if len(paths) != 2:
                raise ValueError(
                    "visual example cannot locate its two generated stages"
                )
            svg = render_full_route(after[pid], paths, row["split_id"])
            drawings += (
                '<details open><summary>After: complete inferred route</summary><div class="diagram">'
                + svg
                + "</div></details>"
            )
            for stage in (1, 2):
                r = generated_rows.get(f"{row['split_id']}:{stage}", {})
                stages.append(
                    {
                        "forward_stage": stage,
                        "raw_code": r.get("raw_code", ""),
                        "class_names": r.get("class_names", []),
                        "class_names_source": r.get("class_names_source", ""),
                    }
                )
            detail["after_route_reaction_nodes"] = sum(
                1 for _ in reaction_nodes(after[pid])
            )
        elif show_cleaned_after:
            original = chemistry.parse_reaction(node_indexes[pid][path]["smiles"])
            product_maps = [set(m) for m in original.products]
            matches = [
                (p, n)
                for p, n in reaction_nodes(after[pid])
                if int(n.get("metadata", {}).get("source_row", -1)) == row["source_row"]
                and [set(m) for m in chemistry.parse_reaction(n["smiles"]).products]
                == product_maps
            ]
            if len(matches) != 1:
                raise ValueError(
                    "cannot identify exact retained visual occurrence after cleanup"
                )
            svg = render_full_route(after[pid], [(matches[0][0], "main")])
            drawings += (
                '<details open><summary>After: complete cleaned route</summary><div class="diagram">'
                + svg
                + "</div></details>"
            )
            detail["after_route_reaction_nodes"] = sum(
                1 for _ in reaction_nodes(after[pid])
            )
        if show_cleaned_after:
            detail["after_view_reactant_cleanup_applied"] = True
        stage_text = "".join(
            f"<li>Stage {s['forward_stage']}: {escape(s['raw_code'])} — {escape('; '.join(s['class_names']))} ({escape(s['class_names_source'])})</li>"
            for s in stages
        )
        detail["generated_classifications"] = stages
        sections.append(
            f'<section id="case-{ordinal}"><h2>{ordinal}. {escape(subtitle)}</h2><p>{escape(row["raw_code"])} — '
            f"{escape('; '.join(row['class_names']))} <small>({escape(row['class_names_source'])})</small></p>"
            f"<p>Status: <strong>{escape(row['split_status'])}</strong>. {escape(row['split_reason'])}</p>"
            + ("<ol>" + stage_text + "</ol>" if stages else "")
            + drawings
            + "</section>"
        )
        examples.append(detail)
    links = {
        (r["path_id"], r["source_row"]): f"#case-{i}" for i, r in enumerate(chosen, 1)
    }

    def table(rows, title, ident):
        body = []
        for r in rows:
            target = links.get((r["path_id"], int(r["source_row"])), "")
            step = escape(str(r["step_id"]))
            if target:
                step = f'<a href="{target}">{step}</a>'
            body.append(
                f"<tr><td>{escape(str(r['path_id']))}</td><td>{step}</td><td>{r['source_row']}</td>"
                f"<td>{r['center_count']}</td><td>{escape(r['raw_code'])}</td><td>{escape('; '.join(r['class_names']))}</td>"
                f"<td>{escape(r.get('class_names_source', ''))}</td><td>{escape(r.get('split_status', ''))}</td></tr>"
            )
        return (
            f'<h2>{title} ({len(body)})</h2><input class="search" data-table="{ident}" placeholder="Search PathId, StepId, class, name or status">'
            + f'<div class="table-scroll"><table id="{ident}"><thead><tr><th>PathId</th><th>StepId</th><th>Source row</th><th>Centers</th><th>NameRXN codes</th><th>Class names</th><th>Name source</th><th>Split status</th></tr></thead><tbody>'
            + "".join(body)
            + "</tbody></table></div>"
        )

    remaining = [r for r in after_rows if int(r.get("center_count", 0)) > 1]
    html = '<!doctype html><html><head><meta charset="utf-8"><title>ABSynth multicenter transformations</title><style>body{font:16px sans-serif;margin:25px}table{border-collapse:collapse}td,th{border:1px solid #ddd;padding:5px}.diagram,.table-scroll{overflow:auto;max-height:850px;border:1px solid #ddd}.diagram{padding:15px}section{border-top:3px solid #aaa;margin-top:30px}input{padding:8px;width:70%;margin:12px 0}details{margin:15px 0}small{color:#555}</style></head><body><h1>ABSynth multicenter transformations</h1>'
    html += f"<p>{len(examples)} distinct source-reaction examples with complete routes. Yellow: selected/main reaction centers; purple: deprotection centers; blue: inferred protected intermediate. Retrosynthetic tree layout is shown; synthetic execution is main transformation → intermediate → deprotection.</p>"
    html += "<p>Generated steps are inferred decompositions, not experimentally demonstrated isolated intermediates. CSV RxnName values fill empty displayed class names only; they are not NameRXN classifications. Two-center reactions that cannot be split safely remain unchanged.</p>"
    if show_cleaned_after:
        html += "<p>After views use the cleaned snapshot: whole reactant components with no mapped atoms in their local product have been removed, including unused branch occurrences. This does not imply those reagents were chemically unnecessary. Before views retain the original source provenance.</p>"
    html += table(
        review_rows, "Original multicenter reactions and split outcomes", "before-table"
    )
    html += table(
        remaining, "Remaining multicenter reactions after processing", "after-table"
    )
    html += "".join(sections)
    html += '<script>document.querySelectorAll("input.search").forEach(input=>input.addEventListener("input",()=>{const q=input.value.toLowerCase();document.querySelectorAll("#"+input.dataset.table+" tbody tr").forEach(row=>row.hidden=!row.textContent.toLowerCase().includes(q));}));</script></body></html>'
    (output_dir / "multicenter_report.html").write_text(html)
    write_json(output_dir / "multicenter_examples.json", examples)
    return examples
