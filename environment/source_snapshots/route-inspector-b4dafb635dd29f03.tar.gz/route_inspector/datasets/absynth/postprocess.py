"""Split verified ABSynth deprotection combinations after whole-route filtering."""

from __future__ import annotations

import csv
import json
import shutil
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from importlib.metadata import version
from multiprocessing import get_context
from pathlib import Path
from types import SimpleNamespace

from route_inspector.datasets.absynth import analysis as analysis
from route_inspector.datasets.absynth.filtering import (
    file_record,
    mixed_classes_all_six,
    verified_analysis_artifact,
)
from route_inspector.datasets.absynth.runtime import runtime_provenance
from route_inspector.datasets.absynth.splitting import (
    POLICY,
    eligible,
    handle_diff_multicentered_reactions,
)
from route_inspector.infrastructure.artifacts import write_json
from route_inspector.routes.access import reaction_nodes


def _split_item(item):
    index, root, rows = item
    transformed, decisions = handle_diff_multicentered_reactions(root, rows)
    return index, transformed, decisions


def verify_baseline(input_path, analysis_dir, namerxn_path):
    """Bind labels/centers to exact route occurrences, not StepId-only joins."""
    manifest_path = analysis_dir / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    if manifest["input"]["sha256"] != file_record(input_path)["sha256"]:
        raise ValueError("baseline analysis does not match the filtered input JSON")
    if manifest["summary"]["mapping_error_records"]:
        raise ValueError("baseline contains mapping errors")
    if manifest["namerxn_executable"]["sha256"] != file_record(namerxn_path)["sha256"]:
        raise ValueError("baseline uses a different NameRXN executable")
    for name in ("reactions.tsv", "classifications.json"):
        verified_analysis_artifact(manifest, analysis_dir / name)
    with (analysis_dir / "reactions.tsv").open() as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    classifications = json.loads((analysis_dir / "classifications.json").read_text())
    roots = json.loads(input_path.read_text())
    if not isinstance(roots, list) or len(roots) != manifest["summary"]["input_routes"]:
        raise ValueError("input route collection/count differs from baseline")
    indexed = {}
    for row in rows:
        key = str(row["path_id"]), tuple(json.loads(row["node_path"]))
        if key in indexed:
            raise ValueError("duplicate audited reaction occurrence")
        indexed[key] = row
    seen, ids = set(), set()
    grouped = defaultdict(list)
    for index, root in enumerate(roots):
        pid = str(root["metadata"]["path_id"])
        if pid in ids:
            raise ValueError("duplicate PathId")
        ids.add(pid)
        for path, node in reaction_nodes(root):
            key = pid, path
            if key not in indexed:
                raise ValueError("missing audited occurrence")
            row, meta = indexed[key], node["metadata"]
            if (
                row["mapped_reaction"] != node["smiles"]
                or row["step_id"] != str(meta["step_id"])
                or int(row["source_row"]) != int(meta["source_row"])
                or int(row["route_index"]) != index
            ):
                raise ValueError("stale reaction or source occurrence provenance")
            classification = classifications[row["classification_id"]]
            if (
                classification["classifier_input"] != row["classifier_input"]
                or classification["raw_code"] != row["raw_code"]
            ):
                raise ValueError("inconsistent cached NameRXN annotation")
            if len(json.loads(row["center_components"])) != int(row["center_count"]):
                raise ValueError("inconsistent audited center count")
            if int(row["center_count"]) > 2 or mixed_classes_all_six(row["raw_code"]):
                raise ValueError("run the existing whole-route filter before splitting")
            grouped[pid].append(row)
            seen.add(key)
    if seen != set(indexed) or len(seen) != manifest["summary"]["reaction_nodes"]:
        raise ValueError("incomplete or excess analysis rows")
    return roots, rows, grouped, classifications, manifest


def classify_processed(
    args, reactions, cache, baseline_manifest, *, force_generated=True
):
    reused, fresh_rows = {}, []
    for row in reactions:
        rid = row.get("classification_id")
        if not rid:
            continue
        cached = cache.get(rid)
        if cached and cached["classifier_input"] != row["classifier_input"]:
            raise ValueError("classifier ID collision or altered cached input")
        if cached and not (force_generated and row.get("generated_stage_id")):
            reused[rid] = cached
        else:
            fresh_rows.append(row)
    fresh = analysis.classify(args, fresh_rows)
    analysis.class_names(args, fresh)
    merged = {**reused, **fresh}
    write_json(args.output_dir / "classifications.json", merged)
    write_json(
        args.output_dir / "namerxn_class_names.json",
        {
            r["raw_code"]: {
                "class_names": r.get("class_names", []),
                "reaction_names": r.get("reaction_names", []),
            }
            for r in merged.values()
            if r["status"] == "classified"
        },
    )
    write_json(
        args.output_dir / "classification_reuse.json",
        {
            "policy": (
                "unchanged_exact_inputs_only_generated_stages_freshly_classified"
                if force_generated
                else "unchanged_exact_inputs_reused_changed_inputs_freshly_classified"
            ),
            "baseline_manifest": baseline_manifest,
            "reused_unique_inputs": len(set(reused) - set(fresh)),
            "fresh_unique_inputs": len(fresh),
            "generated_stages_never_inherit_parent_codes": True,
            "csv_names_not_used_as_classifications": True,
        },
    )
    return merged


def run(args):
    if args.workers < 1 or args.visual_examples < 0:
        raise ValueError(
            "workers must be positive; visual examples must be nonnegative"
        )
    if args.output.exists() or args.output.resolve() == args.input.resolve():
        raise FileExistsError(
            "use a new output, preserving the filtered and original datasets"
        )
    args.work_dir.mkdir(parents=True, exist_ok=True)
    if (args.work_dir / "routes.staging.json").exists() or (
        args.work_dir / "manifest.json"
    ).exists():
        raise FileExistsError(
            "use a fresh work directory; do not overwrite a previous run"
        )
    original_record = file_record(args.input)
    roots, rows, grouped, cache, baseline = verify_baseline(
        args.input, args.analysis_dir, args.namerxn_path
    )
    baseline_record = file_record(args.analysis_dir / "manifest.json")
    before_count = sum(1 for root in roots for _ in reaction_nodes(root))
    transformed = list(roots)
    decisions = []
    jobs = [
        (i, r, grouped[str(r["metadata"]["path_id"])])
        for i, r in enumerate(roots)
        if any(
            eligible(n["raw_code"], int(n["center_count"]))
            for n in grouped[str(r["metadata"]["path_id"])]
        )
    ]
    with ProcessPoolExecutor(
        max_workers=args.workers,
        mp_context=get_context("spawn"),
        initializer=analysis.initialize_worker,
    ) as pool:
        for completed, (index, root, records) in enumerate(
            pool.map(_split_item, jobs), 1
        ):
            transformed[index] = root
            decisions.extend(records)
            if completed % 25 == 0 or completed == len(jobs):
                print(
                    json.dumps(
                        {
                            "stage": "split_routes",
                            "routes": completed,
                            "total": len(jobs),
                        }
                    ),
                    flush=True,
                )
    decisions.sort(key=lambda d: (int(d["path_id"]), tuple(d["original_node_path"])))
    write_json(args.work_dir / "split_decisions.json", decisions)
    fields = [
        "path_id",
        "source_row",
        "step_id",
        "original_node_path",
        "raw_code",
        "status",
        "reason",
        "split_id",
        "protection_rules",
        "anchor_map",
        "restored_atom_maps",
        "deprotection_center_maps",
        "intermediate_smiles",
        "generated_reactions_forward",
    ]
    analysis.tsv(args.work_dir / "split_decisions.tsv", decisions, fields)
    analysis.tsv(
        args.work_dir / "unresolved_splits.tsv",
        [d for d in decisions if d["status"] != "split"],
        fields,
    )
    successful = [d for d in decisions if d["status"] == "split"]
    modified_ids = {d["path_id"] for d in successful}
    for old, new in zip(roots, transformed):
        if str(old["metadata"]["path_id"]) not in modified_ids and old != new:
            raise ValueError("unchanged or rolled-back route was mutated")
    after_count = sum(1 for root in transformed for _ in reaction_nodes(root))
    if after_count != before_count + len(successful) or len(roots) != len(transformed):
        raise ValueError("split count invariant failed")
    staged = args.work_dir / "routes.staging.json"
    write_json(staged, transformed)
    analysis_dir = args.work_dir / "analysis"
    analysis_dir.mkdir()
    opts = SimpleNamespace(
        routes_json=staged,
        output_dir=analysis_dir,
        workers=args.workers,
        batch_size=args.batch_size,
        namerxn_path=args.namerxn_path,
        config=args.config,
        visual_examples=args.visual_examples,
        before_roots=roots,
        before_rows=rows,
        split_decisions=decisions,
    )
    fingerprint = file_record(staged)
    scanned = analysis.scan(opts, transformed, fingerprint)
    write_json(
        analysis_dir / "cx_input_support.json",
        analysis.restore_supported_cx_inputs(scanned),
    )
    write_json(
        analysis_dir / "classifier_input_fallbacks.json",
        analysis.restore_serialization_only_inputs(scanned),
    )
    mapping_errors = [r for route in scanned for r in route["mapping_errors"]]
    other_errors = [r for route in scanned for r in route["errors"]]
    analysis.tsv(args.work_dir / "errors.tsv", mapping_errors + other_errors)
    if mapping_errors or other_errors:
        raise ValueError(
            "final corpus validation failed; output not published; see errors.tsv"
        )
    reactions = [row for route in scanned for row in route["reactions"]]
    if any(r["center_count"] > 2 for r in reactions):
        raise ValueError(
            "postprocessed corpus contains a reaction with more than two centers"
        )
    classified = classify_processed(opts, reactions, cache, baseline_record)
    smoke = analysis.smoke_library(opts, transformed, scanned, fingerprint)
    analysis.report(opts, transformed, scanned, classified, smoke, fingerprint)
    generated = [r for r in reactions if r.get("generated_stage_id")]
    if len(generated) != 2 * len(successful) or any(
        r["center_count"] != 1 for r in generated
    ):
        raise ValueError("generated-stage count or center invariant failed")
    analysis.tsv(
        args.work_dir / "generated_stage_classifications.tsv",
        generated,
        [
            "path_id",
            "source_row",
            "step_id",
            "node_path",
            "generated_stage_id",
            "center_count",
            "raw_code",
            "status",
            "class_names",
            "namerxn_class_names",
            "class_names_source",
            "classifier_input",
        ],
    )
    if (
        file_record(args.input) != original_record
        or file_record(args.analysis_dir / "manifest.json") != baseline_record
    ):
        raise ValueError("input or baseline analysis changed during processing")
    # Publish only after full-corpus validation, classification and report creation.
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        raise FileExistsError(args.output)
    pending = args.output.with_name(args.output.name + ".pending")
    if pending.exists():
        raise FileExistsError(pending)
    shutil.copy2(staged, pending)
    if file_record(pending)["sha256"] != fingerprint["sha256"]:
        raise ValueError("publication copy hash mismatch")
    pending.replace(args.output)
    final_summary = json.loads((analysis_dir / "summary.json").read_text())
    summary = {
        "policy": POLICY,
        "input_routes": len(roots),
        "output_routes": len(transformed),
        "input_reaction_nodes": before_count,
        "output_reaction_nodes": after_count,
        "eligible_reaction_nodes": len(decisions),
        "eligible_routes": len(jobs),
        "split_reaction_nodes": len(successful),
        "modified_routes": len(modified_ids),
        "unresolved_candidate_routes": len(jobs) - len(modified_ids),
        "decision_counts": dict(Counter(d["status"] for d in decisions)),
        "unresolved_reason_counts": dict(
            Counter(d["reason"] for d in decisions if d["status"] != "split")
        ),
        "unchanged_routes": len(roots) - len(modified_ids),
        "route_count_preserved": True,
        "unchanged_and_rolled_back_route_objects_equal": True,
        "input_unchanged": True,
        "mapping_error_records": 0,
        "analysis": final_summary,
    }
    write_json(args.work_dir / "summary.json", summary)
    write_json(
        args.work_dir / "manifest.json",
        {
            "input": original_record,
            "runtime": runtime_provenance(),
            "output": file_record(args.output),
            "baseline_analysis": baseline_record,
            "baseline_reactions": file_record(args.analysis_dir / "reactions.tsv"),
            "baseline_classifications": file_record(
                args.analysis_dir / "classifications.json"
            ),
            "analysis_manifest": file_record(analysis_dir / "manifest.json"),
            "namerxn_executable": file_record(args.namerxn_path),
            "implementation": [
                file_record(Path(p))
                for p in (
                    "route_inspector/datasets/absynth/splitting.py",
                    "route_inspector/datasets/absynth/reporting.py",
                    "route_inspector/datasets/absynth/postprocess.py",
                    "route_inspector/datasets/absynth/analysis.py",
                )
            ],
            "versions": {
                p: version(p) for p in ("chython-synplan", "SynPlanner", "rdkit")
            },
            "policy": {
                "name": POLICY,
                "order": "main then deprotection",
                "rollback": "whole route",
                "new_donors": False,
                "new_Graphormer_mapping": False,
                "intermediates": "inferred, not experimental",
                "source_csv": "published snapshot provenance in reaction metadata; live CSV not joined or changed",
            },
            "settings": {
                "workers": args.workers,
                "batch_size": args.batch_size,
                "visual_examples": args.visual_examples,
            },
            "summary": summary,
            "artifacts": [
                file_record(p)
                for p in sorted(args.work_dir.iterdir())
                if p.is_file()
                and p.suffix in {".json", ".tsv"}
                and p.name != "manifest.json"
            ],
        },
    )
    print(json.dumps(summary, indent=2), flush=True)
