"""ABSynth route conversion with condition-derived atom-donor provenance."""

from __future__ import annotations

import csv
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from importlib import import_module
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

import route_inspector.routes.access as route_access
from route_inspector import chemistry
from route_inspector.datasets.absynth.runtime import (
    mapper_identity,
    mapping_execution,
    mapping_options,
    runtime_provenance,
    verify_reviewed_bundle,
)
from route_inspector.infrastructure.artifacts import write_json
from route_inspector.infrastructure.hashing import sha256_file as _sha256
from route_inspector.infrastructure.text import write_tsv
from route_inspector.routes import normalization as routes
from route_inspector.routes.alignment import mapped_component_multisets_equal
from route_inspector.routes.stereo import classify_recorded_noop
from route_inspector.routes.validation import (
    validate_route_edges,
    validate_routes_mapping,
)

CONDITION_RESOLUTION_FIELDS = [
    "source_row",
    "path_id",
    "step_id",
    "status",
    "resolution_method",
    "deficit",
    "conditions",
    "condition_tokens",
    "selected_donors",
    "original_rxn_smiles",
    "enriched_rxn_smiles",
    "message",
]
ROUTE_ERROR_FIELDS = [
    "path_id",
    "stage",
    "source_row",
    "step_id",
    "message",
    "details",
]
UNRESOLVED_TOKEN_FIELDS = [
    "token",
    "normalized_token",
    "resolution_status",
    "failed_rows",
    "affected_routes",
    "deficit_signatures",
    "example_source_rows",
]
STEREO_CLASSIFICATION_FIELDS = [
    "source_row",
    "path_id",
    "step_id",
    "reaction_step",
    "reaction_node_path",
    "classification",
    "reason",
    "route_emitted",
]
NORMALIZATION_AUDIT_FIELDS = [
    "source_row",
    "path_id",
    "step_id",
    "reaction_node_path",
    "alignment_policy",
    "method",
    "status",
    "reason",
    "candidates_examined",
    "route_emitted",
]
DONOR_ATTRIBUTION_FIELDS = [
    "source_row",
    "path_id",
    "step_id",
    "status",
    "check",
    "expected_atom_maps",
    "observed_atom_maps",
    "message",
]

_STEP_RE = re.compile(r"^(?P<number>\d+)(?P<suffix>.*)$")
_SPACE_RE = re.compile(r"\s+")
_LEADING_THEN_RE = re.compile(r"^(?:then|and then)\s+", re.IGNORECASE)
_NON_CHEMICAL_RE = re.compile(
    r"^(?:"
    r"rt|r\.t\.?|room temperature|reflux|quant(?:\.|itative)?|crude|"
    r"dark|air|argon|nitrogen|vacuum|hv|microwave|"
    r"[-+]?\d+(?:[.,]\d+)?\s*(?:°|º|℃)?\s*[CFK]?|"
    r"[-+]?\d+(?:[.,]\d+)?\s*(?:°|º|℃)?\s*[CFK]?\s*to\s*rt|"
    r"[-+]?\d+(?:[.,]\d+)?\s*(?:h|hr|hrs|min|mins|s|sec|days?|psi|bar|atm)|"
    r"[-+]?\d+(?:[.,]\d+)?\s*%|"
    r"\d+\s*steps?"
    r")$",
    re.IGNORECASE,
)


class ABSynthError(ValueError):
    """Base error for strict ABSynth conversion failures."""


class TopologyError(ABSynthError):
    """Raised when a source route cannot be reconstructed unambiguously."""


class DonorResolutionError(ABSynthError):
    """Raised when Conditions cannot provide an unambiguous atom donor."""


@dataclass(frozen=True)
class SourceReaction:
    """One physical ABSynth source row."""

    source_row: int
    path_id: str
    target_name: str
    year: str
    doi: str
    author: str
    step_id: str
    rxn_smiles: str
    rxn_name: str
    conditions: str

    @property
    def reactants(self) -> tuple[str, ...]:
        left, _right = split_reaction_smiles(self.rxn_smiles)
        return tuple(component for component in left.split(".") if component)

    @property
    def product(self) -> str:
        _left, right = split_reaction_smiles(self.rxn_smiles)
        if "." in right:
            raise ABSynthError(
                f"source row {self.source_row} has more than one product"
            )
        return right


@dataclass(frozen=True)
class DonorCandidate:
    """A condition token resolved to a complete molecular structure."""

    token: str
    normalized_token: str
    smiles: str
    element_counts: tuple[tuple[str, int], ...]
    priority: int = 0
    source: str = "curated"
    pubchem_cid: str = ""
    condition_evidenced: bool = True
    override_reason: str = ""

    def counts(self) -> Counter[str]:
        return Counter(dict(self.element_counts))

    def as_dict(self, *, copies: int = 1) -> dict[str, Any]:
        return {
            "token": self.token,
            "normalized_token": self.normalized_token,
            "smiles": self.smiles,
            "copies": copies,
            "priority": self.priority,
            "source": self.source,
            "pubchem_cid": self.pubchem_cid,
            "condition_evidenced": self.condition_evidenced,
            "override_reason": self.override_reason,
        }


@dataclass(frozen=True)
class DonorSelection:
    """Resolved enrichment for one reaction."""

    deficit: tuple[tuple[str, int], ...]
    candidates: tuple[DonorCandidate, ...]
    selected: tuple[tuple[DonorCandidate, int], ...]
    enriched_rxn_smiles: str
    resolution_method: str = "condition"


@dataclass
class RouteTopology:
    """Exact source-row producer relationships for one route."""

    path_id: str
    rows: tuple[SourceReaction, ...]
    root_row: SourceReaction
    producers: dict[tuple[int, int], SourceReaction] = field(default_factory=dict)


@dataclass(frozen=True)
class RegistryEntry:
    alias: str
    smiles: str
    priority: int
    source: str
    eligible: bool = True
    pubchem_cid: str = ""


@dataclass(frozen=True)
class ReactionDonorOverride:
    """Occurrence-specific donors and oxygen-fallback policy."""

    source_row: int
    path_id: str
    step_id: str
    donors: tuple[tuple[str, int], ...]
    oxygen_water_fallback: str
    reason: str
    allow_ineligible_donors: tuple[str, ...] = ()
    apply_when_balanced: bool = False
    donor_attribution_check: str = ""


def _parse_donor_spec(text: str, *, context: str) -> tuple[tuple[str, int], ...]:
    donors: list[tuple[str, int]] = []
    # A JSON string array preserves aliases containing commas (1,1'-CDI).
    # Ordinary bracketed SMILES, such as [Cl-], keep their existing syntax.
    if re.match(r'^\s*\[\s*"', text) or text.strip() == "[]":
        try:
            items = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ABSynthError(f"invalid donor JSON array at {context}: {exc}") from exc
        if not isinstance(items, list) or any(
            not isinstance(item, str) or not item.strip() for item in items
        ):
            raise ABSynthError(
                f"donor JSON array must contain nonempty strings at {context}"
            )
    else:
        items = text.split(",")
    for item in items:
        item = item.strip()
        if not item:
            continue
        alias, separator, copies = item.partition("*")
        count = int(copies) if separator else 1
        if count < 1:
            raise ABSynthError(f"invalid donor multiplicity at {context}")
        donors.append((normalize_condition_token(alias), count))
    return tuple(donors)


def load_reaction_donor_overrides(
    path: Path | None,
) -> dict[int, ReactionDonorOverride]:
    """Load versioned occurrence-level donor and water-fallback overrides."""

    if path is None or not path.exists():
        return {}
    overrides: dict[int, ReactionDonorOverride] = {}
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        required = {
            "version",
            "source_row",
            "path_id",
            "step_id",
            "donors",
            "oxygen_water_fallback",
            "reason",
        }
        missing = required.difference(reader.fieldnames or ())
        if missing:
            raise ABSynthError(
                "reaction override registry is missing columns: "
                + ", ".join(sorted(missing))
            )
        for line, raw in enumerate(reader, start=2):
            if (raw.get("version") or "").strip() != "1":
                raise ABSynthError(
                    f"unsupported reaction override version at {path}:{line}"
                )
            source_row = int((raw.get("source_row") or "0").strip())
            policy = (raw.get("oxygen_water_fallback") or "default").strip().casefold()
            if policy not in {"default", "allow", "deny"}:
                raise ABSynthError(f"invalid oxygen fallback policy at {path}:{line}")
            apply_balanced = (raw.get("apply_when_balanced") or "").strip().casefold()
            if apply_balanced not in {"", "false", "true"}:
                raise ABSynthError(
                    f"invalid apply_when_balanced value at {path}:{line}"
                )
            override = ReactionDonorOverride(
                source_row=source_row,
                path_id=(raw.get("path_id") or "").strip(),
                step_id=(raw.get("step_id") or "").strip(),
                donors=_parse_donor_spec(
                    raw.get("donors") or "", context=f"{path}:{line}"
                ),
                oxygen_water_fallback=policy,
                reason=(raw.get("reason") or "").strip(),
                allow_ineligible_donors=tuple(
                    normalize_condition_token(alias)
                    for alias in (raw.get("allow_ineligible_donors") or "").split(",")
                    if alias.strip()
                ),
                apply_when_balanced=apply_balanced == "true",
                donor_attribution_check=(
                    raw.get("donor_attribution_check") or ""
                ).strip(),
            )
            if override.donor_attribution_check not in {
                "",
                "reviewed_etoac_ethoxy_pair_v1",
            }:
                raise ABSynthError(f"unknown donor attribution check at {path}:{line}")
            if source_row < 2 or not override.path_id or not override.step_id:
                raise ABSynthError(
                    f"invalid reaction override identity at {path}:{line}"
                )
            if not override.donors and policy == "default":
                raise ABSynthError(f"empty reaction override at {path}:{line}")
            if override.apply_when_balanced and not override.donors:
                raise ABSynthError(
                    f"balanced override requires explicit donors at {path}:{line}"
                )
            if not override.reason:
                raise ABSynthError(f"reaction override lacks a reason at {path}:{line}")
            if source_row in overrides:
                raise ABSynthError(f"duplicate reaction override at {path}:{line}")
            overrides[source_row] = override
    return overrides


def validate_reaction_donor_overrides(
    overrides: Mapping[int, ReactionDonorOverride],
    rows_by_id: Mapping[int, SourceReaction],
    registry: Mapping[str, RegistryEntry],
) -> None:
    """Reject stale occurrence identities and unknown or ineligible donor aliases."""

    for source_row, override in overrides.items():
        row = rows_by_id.get(source_row)
        if row is None:
            raise ABSynthError(f"reaction override source row {source_row} is absent")
        if row.path_id != override.path_id or row.step_id != override.step_id:
            raise ABSynthError(
                f"reaction override identity mismatch for source row {source_row}: "
                f"expected {row.path_id}/{row.step_id}, got "
                f"{override.path_id}/{override.step_id}"
            )
        _validate_occurrence_donor_eligibility(override, row.conditions, registry)


def _validate_occurrence_donor_eligibility(
    override: ReactionDonorOverride,
    conditions: str,
    registry: Mapping[str, RegistryEntry],
) -> None:
    allowed = set(override.allow_ineligible_donors)
    if len(allowed) != len(override.allow_ineligible_donors):
        raise ABSynthError("duplicate occurrence eligibility exception")
    requested = {alias for alias, _copies in override.donors}
    evidenced = {
        normalize_condition_token(token) for token in tokenize_conditions(conditions)
    }
    if not allowed <= requested or not allowed <= evidenced:
        raise ABSynthError(
            "occurrence eligibility exceptions must be requested donors present in Conditions"
        )
    for alias, _copies in override.donors:
        entry = registry.get(alias)
        if entry is None:
            raise ABSynthError(
                f"reaction override donor {alias!r} is absent from the registry"
            )
        if not entry.eligible and alias not in allowed:
            raise ABSynthError(f"reaction override donor {alias!r} is ineligible")


def split_reaction_smiles(reaction_smiles: str) -> tuple[str, str]:
    """Split an ABSynth two-part reaction SMILES."""

    if reaction_smiles.count(">>") != 1:
        raise ABSynthError(f"expected one '>>' in reaction: {reaction_smiles!r}")
    left, right = reaction_smiles.split(">>")
    if not left or not right:
        raise ABSynthError(f"reaction has an empty side: {reaction_smiles!r}")
    return left, right


def load_route_exclusions(path: Path | None) -> dict[str, str]:
    """Read explicit temporary PathId exclusions without deleting source rows."""
    if path is None:
        return {}
    exclusions: dict[str, str] = {}
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        if not {"version", "path_id", "reason"}.issubset(reader.fieldnames or ()):
            raise ABSynthError(
                "route exclusions require version, path_id and reason columns"
            )
        for line, record in enumerate(reader, 2):
            path_id = (record.get("path_id") or "").strip()
            reason = (record.get("reason") or "").strip()
            if (
                (record.get("version") or "").strip() != "1"
                or not path_id
                or not reason
            ):
                raise ABSynthError(f"invalid route exclusion at {path}:{line}")
            if path_id in exclusions:
                raise ABSynthError(f"duplicate route exclusion for {path_id}")
            exclusions[path_id] = reason
    return exclusions


def partition_excluded_routes(
    source_rows: Sequence[SourceReaction], exclusions: Mapping[str, str]
) -> tuple[list[SourceReaction], list[dict[str, Any]]]:
    """Skip reviewed routes before topology, donor resolution and mapping."""
    available = {row.path_id for row in source_rows}
    unknown = set(exclusions) - available
    if unknown:
        raise ABSynthError(
            "excluded PathIds absent from input: " + ", ".join(sorted(unknown))
        )
    excluded: dict[str, list[SourceReaction]] = defaultdict(list)
    retained: list[SourceReaction] = []
    for row in source_rows:
        if row.path_id in exclusions:
            excluded[row.path_id].append(row)
        else:
            retained.append(row)
    errors = [
        {
            "path_id": path_id,
            "stage": "route_excluded",
            "source_row": rows[0].source_row,
            "step_id": rows[0].step_id,
            "message": exclusions[path_id],
            "details": json.dumps(
                {
                    "source_rows": [row.source_row for row in rows],
                    "step_ids": [row.step_id for row in rows],
                    "excluded_reaction_count": len(rows),
                },
                sort_keys=True,
            ),
        }
        for path_id, rows in excluded.items()
    ]
    return retained, errors


def load_absynth(path: Path) -> list[SourceReaction]:
    """Read the tab-separated ABSynth file while retaining physical row IDs."""

    rows: list[SourceReaction] = []
    with path.open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        required = {
            "PathId",
            "TargetName",
            "Year",
            "DOI",
            "Author",
            "StepId",
            "RxnSMILES",
            "RxnName",
            "Conditions",
        }
        missing = required.difference(reader.fieldnames or ())
        if missing:
            raise ABSynthError(
                "ABSynth input is missing columns: " + ", ".join(sorted(missing))
            )
        for source_row, raw in enumerate(reader, start=2):
            row = SourceReaction(
                source_row=source_row,
                path_id=(raw.get("PathId") or "").strip(),
                target_name=(raw.get("TargetName") or "").strip(),
                year=(raw.get("Year") or "").strip(),
                doi=(raw.get("DOI") or "").strip(),
                author=(raw.get("Author") or "").strip(),
                step_id=(raw.get("StepId") or "").strip(),
                rxn_smiles=(raw.get("RxnSMILES") or "").strip(),
                rxn_name=(raw.get("RxnName") or "").strip(),
                conditions=(raw.get("Conditions") or "").strip(),
            )
            if not row.path_id or not row.step_id or not row.rxn_smiles:
                raise ABSynthError(f"source row {source_row} has empty core fields")
            split_reaction_smiles(row.rxn_smiles)
            rows.append(row)
    return rows


def normalize_condition_token(token: str) -> str:
    """Normalize only presentation-level variation in a condition token."""

    token = token.strip().strip(";,:")
    token = _LEADING_THEN_RE.sub("", token)
    token = token.replace("−", "-").replace("–", "-").replace("—", "-")
    return _SPACE_RE.sub(" ", token).strip().casefold()


def tokenize_conditions(conditions: str) -> tuple[str, ...]:
    """Extract plausible chemical tokens from ABSynth condition text."""

    tokens: list[str] = []
    # Recorded hydroformylation mixtures: expose the complete gas molecules,
    # not the pressure or mixing ratio. CO is case-sensitive, distinct from Co.
    conditions = re.sub(
        r"(?<![A-Za-z0-9])\(\s*\d+(?:\.\d+)?\s*:\s*\d+(?:\.\d+)?\s*\)"
        r"\s*CO\s*[:/]\s*H2\b",
        "CO.H2",
        conditions,
    )
    conditions = re.sub(
        r"(?<![A-Za-z0-9])\d+(?:\.\d+)?\s*(?:atm|bar|psi)\s*(?=CO\b)",
        "",
        conditions,
    )
    # This explicit solvent ratio is not a compound name. Do not split
    # arbitrary colons elsewhere in Conditions or infer stoichiometry.
    conditions = re.sub(
        r"\bMeOH\s*:\s*PhCN\(\s*\d+\s*:\s*\d+\s*\)",
        "MeOH.PhCN",
        conditions,
    )
    # One reviewed reagent name contains a mistaken period in the dataset.
    # Do not merge arbitrary dotted chemical mixtures or alter source metadata.
    conditions = re.sub(
        r"\bLawesson['’]s\.\s*reagent\b",
        "Lawesson's reagent",
        conditions,
        flags=re.IGNORECASE,
    )
    # Preserve both the reagent and the aqueous qualifier in this reviewed
    # concentration form. Do not interpret bare yield percentages as donors.
    conditions = re.sub(
        r"(?<![A-Za-z0-9])\d+(?:[.,]\d+)?\s*%\s*aq\.?\s*MeNH2\b",
        "MeNH2(aq)",
        conditions,
        flags=re.IGNORECASE,
    )
    # Preserve explicitly named common aqueous reagents after a leading
    # concentration (e.g. "28% NH3" or "12M HCl"), not arbitrary yield text.
    conditions = re.sub(
        r"(?<![A-Za-z0-9])\d+(?:[.,]\d+)?\s*(?:M\b|%)\s*(?:aq\.?\s*)?"
        r"(?=(?:HCl|HBr|NH3)(?![A-Za-z0-9]))",
        "",
        conditions,
        flags=re.IGNORECASE,
    )
    # Pressure qualifiers are not part of these simple reagent names.
    # Keep aqueous acid tokens: curated HCl (aq) includes evidenced water.
    conditions = re.sub(
        r"(?<![A-Za-z0-9])(NH3|HCl|HBr|NH4OH)\s*"
        r"\(\s*\d+(?:[.,]\d+)?\s*(?:psi|bar|atm)\s*\)",
        r"\1",
        conditions,
        flags=re.IGNORECASE,
    )
    # The NH4OH registry entry already represents aqueous ammonium hydroxide.
    conditions = re.sub(
        r"(?<![A-Za-z0-9])(NH4OH)\s*\(\s*aq\.?\s*\)",
        r"\1",
        conditions,
        flags=re.IGNORECASE,
    )
    # An aqueous concentration describes the preceding reagent, not the yield.
    # Strip only this specific qualifier before period/percentage filtering.
    conditions = re.sub(
        r"\(\s*\d+(?:[.,]\d+)?\s*%\s*,?\s*aq\.?\s*\)",
        "",
        conditions,
        flags=re.IGNORECASE,
    )
    # A full quantity qualifier must be removed before splitting on periods;
    # otherwise "Ac2O(3 eq.)" is truncated into the unknown token "Ac2O(3 eq".
    # This does not infer donor multiplicity or strip molecular parentheses.
    conditions = re.sub(
        r"\(\s*\d+(?:[.,]\d+)?\s*(?:eq(?:uiv)?s?\.?|equivalents?)\s*\)",
        "",
        conditions,
        flags=re.IGNORECASE,
    )
    # This reviewed pair lost its delimiter. Split only the complete known
    # pair, not arbitrary whitespace inside reagent names or descriptions.
    conditions = re.sub(
        r"(^|[.;])(\s*)triphosgene[ \t]+pyridine(?=\s*(?:[.;]|$))",
        r"\1\2triphosgene.pyridine",
        conditions,
        flags=re.IGNORECASE,
    )
    protected_conditions = re.sub(
        r"((?:°|º|℃)\s*[CFK]?)\s*then(?=[A-Za-z(\[])",
        r"\1.then.",
        conditions,
        flags=re.IGNORECASE,
    )
    protected_conditions = re.sub(
        r"(?<![A-Za-z0-9])(\d+),(?=\d)",
        r"\1<LOCANT_COMMA>",
        protected_conditions,
    )
    protected_conditions = re.sub(
        r"(?<![A-Za-z0-9])[NOSP](?:,[NOSP])+(?=-)",
        lambda match: match.group(0).replace(",", "<LOCANT_COMMA>"),
        protected_conditions,
    )
    # This recorded mixture uses a hyphen as a delimiter. Do not split
    # arbitrary hyphens: 9-I-9-BBN, t-BuLi and ligand names must stay intact.
    protected_conditions = re.sub(
        r"\bEtOH-Boc2O\b", "EtOH.Boc2O", protected_conditions, flags=re.IGNORECASE
    )
    protected_conditions = re.sub(
        r"\br\.\s*t\.(?![A-Za-z])", "rt", protected_conditions, flags=re.IGNORECASE
    )
    for group_pattern in (r"\([^()]*\)", r"\[[^][]*\]"):
        protected_conditions = re.sub(
            group_pattern,
            lambda match: match.group(0).replace(",", "<LOCANT_COMMA>"),
            protected_conditions,
        )
    for raw in re.split(
        r"[.;/,]|\bthen\b",
        protected_conditions,
        flags=re.IGNORECASE,
    ):
        token = raw.replace("<LOCANT_COMMA>", ",").strip().strip(";,:")
        token = _LEADING_THEN_RE.sub("", token).strip()
        # Remove the complete temperature suffix, including ranges with a
        # Unicode minus sign. Stripping only its final endpoint leaves strings
        # such as 'DMF -78°C to' instead of an evidenced reagent token.
        token = re.sub(
            r"\s+[+\-−–—]?\d+(?:[.,]\d+)?\s*(?:°|º|℃).*$",
            "",
            token,
        ).strip()
        token = re.sub(
            r"\s+(?:conc|concentrated)\Z", "", token, flags=re.IGNORECASE
        ).strip()
        token = re.sub(
            r"\s*-?\d+(?:[.,]\d+)?\s*(?:°|º|℃)\s*[CFK]?(?:\s*to\s*rt)?\Z",
            "",
            token,
            flags=re.IGNORECASE,
        ).strip()
        normalized = normalize_condition_token(token)
        if (
            not token
            or normalized in {"then", "to", "cat"}
            or "%" in token
            or "step" in normalized
            or _NON_CHEMICAL_RE.fullmatch(token)
            or (
                token[0] in "+-0123456789"
                and any(marker in token for marker in ("°", "º", "℃"))
            )
        ):
            continue
        if not any(character.isalpha() for character in token):
            continue
        tokens.append(token)
    return tuple(tokens)


def _heavy_element_counts(molecules: Iterable[Any]) -> Counter[str]:
    counts: Counter[str] = Counter()
    for molecule in molecules:
        counts.update(
            atom.atomic_symbol
            for _atom_number, atom in molecule.atoms()
            if atom.atomic_symbol != "H"
        )
    return counts


def reaction_heavy_atom_deficit(reaction_smiles: str) -> Counter[str]:
    """Return product heavy atoms not supplied by recorded reactants."""

    reaction = chemistry.parse_reaction(reaction_smiles)
    reactants = _heavy_element_counts(reaction.reactants)
    products = _heavy_element_counts(reaction.products)
    return Counter(
        {
            element: products[element] - reactants[element]
            for element in products
            if products[element] > reactants[element]
        }
    )


def molecule_heavy_atom_counts(smiles_text: str) -> Counter[str]:
    molecule = chemistry.parse_molecule(smiles_text)
    return _heavy_element_counts((molecule,))


def format_deficit(deficit: Mapping[str, int]) -> str:
    return ";".join(
        f"{element}:{count}" for element, count in sorted(deficit.items()) if count > 0
    )


def parse_deficit(text: str) -> Counter[str]:
    if not text.strip():
        return Counter()
    result: Counter[str] = Counter()
    for item in text.split(";"):
        element, count = item.split(":", 1)
        result[element] += int(count)
    return result


def load_condition_registry(path: Path) -> dict[str, RegistryEntry]:
    """Load an auditable alias-to-structure registry."""

    entries: dict[str, RegistryEntry] = {}
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        required = {
            "alias",
            "smiles",
            "priority",
            "source",
            "eligible",
            "pubchem_cid",
        }
        missing = required.difference(reader.fieldnames or ())
        if missing:
            raise ABSynthError(
                "condition registry is missing columns: " + ", ".join(sorted(missing))
            )
        for line, raw in enumerate(reader, start=2):
            alias = (raw.get("alias") or "").strip()
            smiles_text = (raw.get("smiles") or "").strip()
            if not alias or not smiles_text:
                continue
            key = normalize_condition_token(alias)
            if key in entries:
                raise ABSynthError(
                    f"duplicate condition alias {alias!r} at {path}:{line}"
                )
            molecule_heavy_atom_counts(smiles_text)
            eligibility = (raw.get("eligible") or "").strip().casefold()
            if eligibility not in {"true", "false"}:
                raise ABSynthError(
                    f"invalid donor eligibility for {alias!r} at {path}:{line}"
                )
            entries[key] = RegistryEntry(
                alias=alias,
                smiles=smiles_text,
                priority=int((raw.get("priority") or "0").strip()),
                source=(raw.get("source") or "curated").strip(),
                eligible=eligibility == "true",
                pubchem_cid=(raw.get("pubchem_cid") or "").strip(),
            )
    return entries


def load_condition_overrides(
    path: Path | None,
) -> dict[tuple[str, str], tuple[tuple[str, int], ...]]:
    """Load exact Conditions+deficit donor choices for ambiguous contexts."""

    if path is None or not path.exists():
        return {}
    overrides: dict[tuple[str, str], tuple[tuple[str, int], ...]] = {}
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        for line, raw in enumerate(reader, start=2):
            conditions = normalize_condition_token(raw.get("conditions") or "")
            deficit = (raw.get("deficit") or "").strip()
            donors: list[tuple[str, int]] = []
            for item in (raw.get("donors") or "").split(","):
                item = item.strip()
                if not item:
                    continue
                alias, separator, copies = item.partition("*")
                donors.append(
                    (normalize_condition_token(alias), int(copies) if separator else 1)
                )
            key = (conditions, deficit)
            if not conditions or not deficit or not donors:
                raise ABSynthError(f"invalid condition override at {path}:{line}")
            if key in overrides:
                raise ABSynthError(f"duplicate condition override at {path}:{line}")
            overrides[key] = tuple(donors)
    return overrides


class PubChemCache:
    """Append-only cache for exact-name PubChem structure resolution."""

    base_url = "https://pubchem.ncbi.nlm.nih.gov/rest/pug"

    def __init__(
        self,
        path: Path,
        *,
        enabled: bool = True,
        requests_per_second: float = 2.0,
        timeout: float = 30.0,
        opener: Callable[..., Any] = urllib.request.urlopen,
    ) -> None:
        self.path = path
        self.enabled = enabled
        self.minimum_interval = 1.0 / requests_per_second
        self.timeout = timeout
        self.opener = opener
        self.records: dict[str, dict[str, Any]] = {}
        self._last_request = 0.0
        if path.exists():
            with path.open(encoding="utf-8") as stream:
                for line in stream:
                    if line.strip():
                        record = json.loads(line)
                        self.records[str(record["normalized_token"])] = record

    def _request_json(self, url: str) -> dict[str, Any]:
        delay = self.minimum_interval - (time.monotonic() - self._last_request)
        if delay > 0:
            time.sleep(delay)
        for attempt in range(5):
            try:
                self._last_request = time.monotonic()
                with self.opener(url, timeout=self.timeout) as response:
                    return json.loads(response.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                if exc.code == 404:
                    raise LookupError("PubChem name not found") from exc
                if exc.code not in {429, 500, 502, 503, 504} or attempt == 4:
                    raise
            except urllib.error.URLError:
                if attempt == 4:
                    raise
            time.sleep(min(30, 2 ** (attempt + 1)))
        raise RuntimeError("unreachable PubChem retry state")

    def _append(self, record: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, sort_keys=True) + "\n")
        self.records[str(record["normalized_token"])] = record

    def resolve(self, token: str) -> dict[str, Any] | None:
        key = normalize_condition_token(token)
        cached = self.records.get(key)
        if cached is not None:
            if cached.get("status") != "resolved":
                return None
            try:
                molecule_heavy_atom_counts(str(cached["smiles"]))
            except Exception as exc:
                invalid = {
                    **cached,
                    "status": "invalid_smiles",
                    "message": f"{type(exc).__name__}: {exc}",
                }
                self._append(invalid)
                return None
            return cached
        if not self.enabled:
            return None
        encoded = urllib.parse.quote(token, safe="")
        try:
            identifiers = self._request_json(
                f"{self.base_url}/compound/name/{encoded}/cids/JSON?name_type=complete"
            )
            cids = identifiers.get("IdentifierList", {}).get("CID", [])
            if len(cids) != 1:
                record = {
                    "normalized_token": key,
                    "token": token,
                    "status": "ambiguous",
                    "cids": cids,
                }
                self._append(record)
                return None
            cid = str(cids[0])
            properties = self._request_json(
                f"{self.base_url}/compound/cid/{cid}/property/SMILES/JSON"
            )
            values = properties.get("PropertyTable", {}).get("Properties", [])
            smiles_text = str(values[0]["SMILES"]) if len(values) == 1 else ""
            if not smiles_text:
                raise LookupError("PubChem returned no SMILES")
            try:
                molecule_heavy_atom_counts(smiles_text)
            except Exception as exc:
                self._append(
                    {
                        "normalized_token": key,
                        "token": token,
                        "status": "invalid_smiles",
                        "cid": cid,
                        "smiles": smiles_text,
                        "message": f"{type(exc).__name__}: {exc}",
                    }
                )
                return None
            record = {
                "normalized_token": key,
                "token": token,
                "status": "resolved",
                "cid": cid,
                "smiles": smiles_text,
            }
            self._append(record)
            return record
        except LookupError as exc:
            self._append(
                {
                    "normalized_token": key,
                    "token": token,
                    "status": "not_found",
                    "message": str(exc),
                }
            )
            return None


class ConditionDonorResolver:
    """Resolve condition, override, and oxygen-fallback atom donors."""

    def __init__(
        self,
        registry: Mapping[str, RegistryEntry],
        *,
        overrides: Mapping[tuple[str, str], tuple[tuple[str, int], ...]] | None = None,
        pubchem: PubChemCache | None = None,
        oxygen_water_fallback: bool = False,
    ) -> None:
        self.registry = dict(registry)
        self.overrides = dict(overrides or {})
        self.pubchem = pubchem
        self.oxygen_water_fallback = oxygen_water_fallback

    def _candidate(self, token: str) -> DonorCandidate | None:
        key = normalize_condition_token(token)
        entry = self.registry.get(key)
        if entry is not None:
            if not entry.eligible:
                return None
            counts = molecule_heavy_atom_counts(entry.smiles)
            return DonorCandidate(
                token=token,
                normalized_token=key,
                smiles=entry.smiles,
                element_counts=tuple(sorted(counts.items())),
                priority=entry.priority,
                source=entry.source,
                pubchem_cid=entry.pubchem_cid,
            )
        if self.pubchem is None:
            return None
        record = self.pubchem.resolve(token)
        if record is None:
            return None
        smiles_text = str(record["smiles"])
        counts = molecule_heavy_atom_counts(smiles_text)
        return DonorCandidate(
            token=token,
            normalized_token=key,
            smiles=smiles_text,
            element_counts=tuple(sorted(counts.items())),
            priority=50,
            source="pubchem",
            pubchem_cid=str(record["cid"]),
        )

    def _override_selection(
        self,
        conditions: str,
        deficit: Counter[str],
        candidates: Sequence[DonorCandidate],
    ) -> tuple[tuple[DonorCandidate, int], ...] | None:
        requested = self.overrides.get(
            (normalize_condition_token(conditions), format_deficit(deficit))
        )
        if requested is None:
            return None
        by_alias = {candidate.normalized_token: candidate for candidate in candidates}
        selected: list[tuple[DonorCandidate, int]] = []
        for alias, copies in requested:
            candidate = by_alias.get(alias)
            if candidate is None:
                raise DonorResolutionError(
                    f"override donor {alias!r} is absent from Conditions"
                )
            selected.append((candidate, copies))
        if not _selection_covers(deficit, selected):
            raise DonorResolutionError("condition override does not cover deficit")
        return tuple(selected)

    def _occurrence_override_selection(
        self,
        override: ReactionDonorOverride,
        conditions: str,
        deficit: Counter[str],
    ) -> tuple[tuple[DonorCandidate, int], ...]:
        _validate_occurrence_donor_eligibility(override, conditions, self.registry)
        condition_tokens = {
            normalize_condition_token(token)
            for token in tokenize_conditions(conditions)
        }
        selected: list[tuple[DonorCandidate, int]] = []
        for alias, copies in override.donors:
            entry = self.registry[alias]
            evidenced = alias in condition_tokens
            counts = molecule_heavy_atom_counts(entry.smiles)
            selected.append(
                (
                    DonorCandidate(
                        token=entry.alias,
                        normalized_token=alias,
                        smiles=entry.smiles,
                        element_counts=tuple(sorted(counts.items())),
                        priority=entry.priority,
                        source=(
                            entry.source
                            if evidenced
                            else f"reaction_override:{entry.source}"
                        ),
                        pubchem_cid=entry.pubchem_cid,
                        condition_evidenced=evidenced,
                        override_reason=override.reason,
                    ),
                    copies,
                )
            )
        if not _selection_covers(deficit, selected):
            raise DonorResolutionError("reaction override does not cover deficit")
        return tuple(selected)

    def _water_fallback_selection(
        self,
        deficit: Counter[str],
    ) -> tuple[tuple[DonorCandidate, int], ...]:
        entry = self.registry.get(normalize_condition_token("H2O"))
        if entry is None or not entry.eligible:
            raise DonorResolutionError("eligible H2O registry entry is required")
        candidate = DonorCandidate(
            token="H2O",
            normalized_token=normalize_condition_token("H2O"),
            smiles=entry.smiles,
            element_counts=tuple(
                sorted(molecule_heavy_atom_counts(entry.smiles).items())
            ),
            priority=entry.priority,
            source="oxygen_water_fallback",
            pubchem_cid=entry.pubchem_cid,
            condition_evidenced=False,
            override_reason=(
                "automatic water donor for an oxygen-only unresolved deficit"
            ),
        )
        selected = ((candidate, deficit["O"]),)
        if not _selection_covers(deficit, selected):
            raise DonorResolutionError("water fallback does not cover deficit")
        return selected

    def resolve(
        self,
        reaction_smiles: str,
        conditions: str,
        *,
        occurrence_override: ReactionDonorOverride | None = None,
    ) -> DonorSelection:
        deficit = reaction_heavy_atom_deficit(reaction_smiles)
        deficit_tuple = tuple(sorted(deficit.items()))
        force_override = (
            occurrence_override is not None and occurrence_override.apply_when_balanced
        )
        if force_override and not occurrence_override.donors:
            raise DonorResolutionError("balanced override requires explicit donors")
        if not deficit and not force_override:
            return DonorSelection(
                deficit_tuple, (), (), reaction_smiles, resolution_method="balanced"
            )

        tokens = tokenize_conditions(conditions)
        candidate_by_identity: dict[str, DonorCandidate] = {}
        # Explicit occurrence corrections precede unrelated name resolution.
        for token in (
            () if occurrence_override and occurrence_override.donors else tokens
        ):
            candidate = self._candidate(token)
            if candidate is None or not any(
                candidate.counts()[element] for element in deficit
            ):
                continue
            current = candidate_by_identity.get(candidate.smiles)
            if current is None or candidate.priority > current.priority:
                candidate_by_identity[candidate.smiles] = candidate
        candidates = tuple(candidate_by_identity.values())

        if occurrence_override is not None and occurrence_override.donors:
            selected = self._occurrence_override_selection(
                occurrence_override, conditions, deficit
            )
            resolution_method = "reaction_override"
        else:
            try:
                if not candidates:
                    raise DonorResolutionError(
                        "no condition token resolved to a molecule containing missing atoms"
                    )
                selected = self._override_selection(conditions, deficit, candidates)
                if selected is None:
                    selected = select_minimum_donors(deficit, candidates)
                resolution_method = "condition"
            except DonorResolutionError:
                policy = (
                    occurrence_override.oxygen_water_fallback
                    if occurrence_override is not None
                    else "default"
                )
                fallback_enabled = self.oxygen_water_fallback or policy == "allow"
                if fallback_enabled and policy != "deny" and set(deficit) == {"O"}:
                    selected = self._water_fallback_selection(deficit)
                    resolution_method = "oxygen_water_fallback"
                else:
                    raise

        donors = [
            candidate.smiles
            for candidate, copies in selected
            for _copy in range(copies)
        ]
        left, right = split_reaction_smiles(reaction_smiles)
        enriched = f"{left}.{'.'.join(donors)}>>{right}"
        if reaction_heavy_atom_deficit(enriched):
            raise DonorResolutionError("selected donors did not close the atom deficit")
        return DonorSelection(
            deficit_tuple,
            candidates,
            selected,
            enriched,
            resolution_method=resolution_method,
        )


def build_unresolved_token_rows(
    failed_condition_rows: Sequence[Mapping[str, Any]],
    registry: Mapping[str, RegistryEntry],
    pubchem: PubChemCache,
) -> list[dict[str, Any]]:
    """Summarize unavailable tokens from the final failed condition rows."""

    stats: dict[str, dict[str, Any]] = {}
    for row in failed_condition_rows:
        tokens = json.loads(str(row.get("condition_tokens") or "[]"))
        for token in tokens:
            normalized = normalize_condition_token(str(token))
            entry = registry.get(normalized)
            if entry is not None:
                if entry.eligible:
                    continue
                status = "registry_ineligible"
            else:
                cached = pubchem.records.get(normalized)
                if cached is None:
                    status = (
                        "uncached_online" if pubchem.enabled else "uncached_offline"
                    )
                elif cached.get("status") == "resolved":
                    continue
                else:
                    status = f"pubchem_{cached.get('status', 'unknown')}"
            record = stats.setdefault(
                normalized,
                {
                    "tokens": set(),
                    "statuses": set(),
                    "source_rows": set(),
                    "path_ids": set(),
                    "deficits": set(),
                },
            )
            record["tokens"].add(str(token))
            record["statuses"].add(status)
            record["source_rows"].add(int(row["source_row"]))
            record["path_ids"].add(str(row["path_id"]))
            if row.get("deficit"):
                record["deficits"].add(str(row["deficit"]))

    output: list[dict[str, Any]] = []
    for normalized, record in stats.items():
        source_rows = sorted(record["source_rows"])
        output.append(
            {
                "token": sorted(
                    record["tokens"], key=lambda value: (value.casefold(), value)
                )[0],
                "normalized_token": normalized,
                "resolution_status": "+".join(sorted(record["statuses"])),
                "failed_rows": len(source_rows),
                "affected_routes": len(record["path_ids"]),
                "deficit_signatures": json.dumps(sorted(record["deficits"])),
                "example_source_rows": json.dumps(source_rows[:5]),
            }
        )
    output.sort(
        key=lambda row: (
            -int(row["failed_rows"]),
            str(row["normalized_token"]),
        )
    )
    return output


def _selection_covers(
    deficit: Mapping[str, int],
    selected: Sequence[tuple[DonorCandidate, int]],
) -> bool:
    supplied: Counter[str] = Counter()
    for candidate, copies in selected:
        for element, count in candidate.element_counts:
            supplied[element] += count * copies
    return all(supplied[element] >= count for element, count in deficit.items())


def select_minimum_donors(
    deficit: Mapping[str, int],
    candidates: Sequence[DonorCandidate],
) -> tuple[tuple[DonorCandidate, int], ...]:
    """Select a unique minimum donor multiset, refusing unresolved ties."""

    targets = tuple(sorted((element, count) for element, count in deficit.items()))
    useful = [
        candidate
        for candidate in candidates
        if any(candidate.counts()[element] for element, _count in targets)
    ]
    if not useful:
        raise DonorResolutionError("no donor candidate covers the deficit")

    states: dict[tuple[int, ...], list[tuple[int, ...]]] = {
        tuple(0 for _item in targets): [tuple(0 for _item in useful)]
    }
    max_steps = sum(count for _element, count in targets)
    solutions: list[tuple[int, ...]] = []
    for _step in range(max_steps):
        next_states: dict[tuple[int, ...], list[tuple[int, ...]]] = defaultdict(list)
        for state, paths in states.items():
            for candidate_index, candidate in enumerate(useful):
                counts = candidate.counts()
                new_state = tuple(
                    min(target, current + counts[element])
                    for current, (element, target) in zip(state, targets, strict=True)
                )
                if new_state == state:
                    continue
                for path in paths:
                    updated = list(path)
                    updated[candidate_index] += 1
                    value = tuple(updated)
                    if value not in next_states[new_state]:
                        next_states[new_state].append(value)
        target_state = tuple(count for _element, count in targets)
        if target_state in next_states:
            solutions = next_states[target_state]
            break
        states = next_states
    if not solutions:
        raise DonorResolutionError("condition molecules cannot cover atom deficit")

    def score(path: tuple[int, ...]) -> tuple[int, int]:
        priority = sum(
            copies * candidate.priority
            for candidate, copies in zip(useful, path, strict=True)
        )
        supplied = Counter()
        for candidate, copies in zip(useful, path, strict=True):
            for element, count in candidate.element_counts:
                supplied[element] += count * copies
        excess = sum(supplied[element] - count for element, count in targets)
        return (-priority, excess)

    best_score = min(score(path) for path in solutions)
    best = [path for path in solutions if score(path) == best_score]
    unique = {
        tuple(
            sorted(
                (candidate.normalized_token, candidate.smiles, copies)
                for candidate, copies in zip(useful, path, strict=True)
                if copies
            )
        ): path
        for path in best
    }
    if len(unique) != 1:
        descriptions = [
            ",".join(f"{alias}*{copies}" for alias, _smiles, copies in key)
            for key in sorted(unique)
        ]
        raise DonorResolutionError(
            "ambiguous minimum condition donors: " + " | ".join(descriptions)
        )
    chosen = next(iter(unique.values()))
    return tuple(
        (candidate, copies)
        for candidate, copies in zip(useful, chosen, strict=True)
        if copies
    )


def _step_parts(step_id: str) -> tuple[int, str]:
    match = _STEP_RE.match(step_id)
    if match is None:
        return (10**18, step_id)
    return int(match.group("number")), match.group("suffix")


def _producer_score(
    producer: SourceReaction,
    consumer: SourceReaction,
) -> tuple[int, int, int, int]:
    producer_number, producer_suffix = _step_parts(producer.step_id)
    consumer_number, consumer_suffix = _step_parts(consumer.step_id)
    if producer_number == consumer_number and producer_suffix:
        tier = 0
        branch = int(
            bool(consumer_suffix) and not producer_suffix.startswith(consumer_suffix)
        )
    elif producer_number < consumer_number:
        tier = 1
        branch = 0
    elif producer_number == consumer_number:
        tier = 2
        branch = 0
    else:
        tier = 3
        branch = 0
    chronology = abs(consumer_number - producer_number)
    source_distance = abs(consumer.source_row - producer.source_row)
    return tier, branch, chronology, source_distance


def reconstruct_route_topology(rows: Sequence[SourceReaction]) -> RouteTopology:
    """Reconstruct one exact-string ABSynth route tree."""

    if not rows:
        raise TopologyError("route has no reactions")
    path_ids = {row.path_id for row in rows}
    if len(path_ids) != 1:
        raise TopologyError("topology input mixes PathIds")
    products: dict[str, list[SourceReaction]] = defaultdict(list)
    for row in rows:
        products[row.product].append(row)

    producers: dict[tuple[int, int], SourceReaction] = {}
    consumed_rows: set[int] = set()
    for consumer in rows:
        for reactant_index, reactant in enumerate(consumer.reactants):
            candidates = [
                producer
                for producer in products.get(reactant, ())
                if producer.source_row != consumer.source_row
            ]
            if not candidates:
                continue
            ranked = sorted(
                (
                    (_producer_score(candidate, consumer), candidate)
                    for candidate in candidates
                ),
                key=lambda item: (item[0], item[1].source_row),
            )
            if len(ranked) > 1 and ranked[0][0] == ranked[1][0]:
                raise TopologyError(
                    f"ambiguous producer for source row {consumer.source_row} "
                    f"reactant {reactant_index}: "
                    + ",".join(str(item[1].source_row) for item in ranked[:4])
                )
            producer = ranked[0][1]
            producers[(consumer.source_row, reactant_index)] = producer
            consumed_rows.add(producer.source_row)

    roots = [row for row in rows if row.source_row not in consumed_rows]
    if len(roots) != 1:
        raise TopologyError(
            f"expected one final product row, found {len(roots)}: "
            + ",".join(str(row.source_row) for row in roots)
        )

    root = roots[0]
    visited: set[int] = set()
    active: set[int] = set()

    def visit(row: SourceReaction) -> None:
        if row.source_row in active:
            raise TopologyError(f"cycle through source row {row.source_row}")
        active.add(row.source_row)
        visited.add(row.source_row)
        for reactant_index in range(len(row.reactants)):
            producer = producers.get((row.source_row, reactant_index))
            if producer is not None:
                visit(producer)
        active.remove(row.source_row)

    visit(root)
    missing = sorted(row.source_row for row in rows if row.source_row not in visited)
    if missing:
        raise TopologyError(
            "route contains disconnected source rows: " + ",".join(map(str, missing))
        )
    return RouteTopology(rows[0].path_id, tuple(rows), root, producers)


def group_route_topologies(
    source_rows: Sequence[SourceReaction],
) -> tuple[dict[str, RouteTopology], list[dict[str, Any]]]:
    grouped: dict[str, list[SourceReaction]] = defaultdict(list)
    for row in source_rows:
        grouped[row.path_id].append(row)
    topologies: dict[str, RouteTopology] = {}
    errors: list[dict[str, Any]] = []
    for path_id, rows in grouped.items():
        try:
            topologies[path_id] = reconstruct_route_topology(rows)
        except Exception as exc:
            errors.append(
                {
                    "path_id": path_id,
                    "stage": "topology",
                    "source_row": "",
                    "step_id": "",
                    "message": f"{type(exc).__name__}: {exc}",
                }
            )
    return topologies, errors


def _reaction_metadata(
    row: SourceReaction,
    selection: DonorSelection,
    mapped_step_smiles: str,
) -> dict[str, Any]:
    return {
        "smiles": mapped_step_smiles,
        "rsmi": row.rxn_smiles,
        "original_rxn_smiles": row.rxn_smiles,
        "enriched_rxn_smiles": selection.enriched_rxn_smiles,
        "source_row": row.source_row,
        "path_id": row.path_id,
        "step_id": row.step_id,
        "rxn_name": row.rxn_name,
        "source_record_id": row.step_id,
        "conditions": row.conditions,
        "resolution_method": selection.resolution_method,
        "condition_donors": [
            candidate.as_dict(copies=copies) for candidate, copies in selection.selected
        ],
    }


def build_route_tree(
    topology: RouteTopology,
    selections: Mapping[int, DonorSelection],
    mapped_steps: Mapping[int, str],
) -> dict[str, Any]:
    """Build an n1-shaped tree, duplicating reused source subtrees."""

    def molecule_node(
        smiles_text: str,
        *,
        producer: SourceReaction | None = None,
        donor: DonorCandidate | None = None,
        donor_source_row: int | None = None,
    ) -> dict[str, Any]:
        metadata: dict[str, Any] = {"original_smiles": smiles_text}
        node: dict[str, Any] = {
            "smiles": smiles_text,
            "type": "mol",
            "in_stock": producer is None,
            "children": [],
            "metadata": metadata,
        }
        if donor is not None:
            metadata.update(
                {
                    "role": (
                        "condition_atom_donor"
                        if donor.condition_evidenced
                        else "atom_balance_fallback"
                    ),
                    "donor_token": donor.token,
                    "condition_token": (
                        donor.token if donor.condition_evidenced else ""
                    ),
                    "normalized_condition_token": donor.normalized_token,
                    "condition_evidenced": donor.condition_evidenced,
                    "donor_smiles": donor.smiles,
                    "source_occurrence": donor_source_row,
                    "resolution_source": donor.source,
                    "override_reason": donor.override_reason,
                    "pubchem_cid": donor.pubchem_cid,
                }
            )
        if producer is not None:
            node["children"] = [reaction_node(producer)]
        return node

    def reaction_node(row: SourceReaction) -> dict[str, Any]:
        selection = selections[row.source_row]
        children: list[dict[str, Any]] = []
        for reactant_index, reactant in enumerate(row.reactants):
            producer = topology.producers.get((row.source_row, reactant_index))
            children.append(molecule_node(reactant, producer=producer))
        for candidate, copies in selection.selected:
            for _copy in range(copies):
                children.extend(
                    molecule_node(
                        component,
                        donor=candidate,
                        donor_source_row=row.source_row,
                    )
                    for component in candidate.smiles.split(".")
                    if component
                )
        return {
            "type": "reaction",
            "smiles": mapped_steps[row.source_row],
            "children": children,
            "metadata": _reaction_metadata(
                row,
                selection,
                mapped_steps[row.source_row],
            ),
        }

    root_row = topology.root_row
    root = molecule_node(root_row.product, producer=root_row)
    root["metadata"].update(
        {
            "path_id": root_row.path_id,
            "target_name": root_row.target_name,
            "year": root_row.year,
            "doi": root_row.doi,
            "author": root_row.author,
        }
    )
    return root


def annotate_stereo_only_steps(route: dict[str, Any]) -> list[dict[str, Any]]:
    """Annotate proven stereo-only steps and audit all normalized no-op candidates."""
    audit: list[dict[str, Any]] = []
    reaction_index = 0

    def visit(node: dict[str, Any], path: tuple[int, ...]) -> None:
        nonlocal reaction_index
        if node.get("type") == "reaction":
            reaction_index += 1
            metadata = node.setdefault("metadata", {})
            classification = classify_recorded_noop(
                route_access.reaction_smiles_from_node(node), metadata
            )
            if classification is not None:
                audit.append(
                    {
                        "source_row": metadata.get("source_row", ""),
                        "path_id": metadata.get("path_id", ""),
                        "step_id": metadata.get("step_id", ""),
                        "reaction_step": f"r{reaction_index}",
                        "reaction_node_path": ".".join(map(str, path)),
                        "classification": classification.classification,
                        "reason": classification.reason,
                    }
                )
                if classification.accepted:
                    metadata["transformation_kind"] = "stereo_only"
                    metadata["constitutional_change"] = False
        for index, child in enumerate(node.get("children") or ()):
            if isinstance(child, dict):
                visit(child, path + (index,))

    visit(route, ())
    return audit


def _validation_error_with_source(
    path_id: str, route: dict[str, Any], record: Mapping[str, Any]
) -> dict[str, Any]:
    """Keep source identifiers separate from validator traversal identifiers."""
    path_text = str(record.get("reaction_node_path", ""))
    reaction_step = record.get("reaction_step", "")
    if (
        not path_text
        and record.get("stage") == "route_normalization"
        and "reaction molecule children do not equal reactant multiset"
        in str(record.get("message", ""))
    ):
        # This check predates structured normalization exceptions. Recover
        # the exact first failing node in the converter's same stack order.
        stack = [(route, ())]
        while stack:
            candidate, candidate_path = stack.pop()
            if candidate.get(
                "type"
            ) == "reaction" and not reaction_children_are_complete(candidate):
                path_text = ".".join(map(str, candidate_path))
                break
            stack.extend(
                (child, candidate_path + (index,))
                for index, child in enumerate(candidate.get("children") or ())
                if isinstance(child, dict)
            )
    node = route
    if path_text:
        for index in path_text.split("."):
            node = node["children"][int(index)]
    metadata = node.get("metadata", {}) if node.get("type") == "reaction" else {}
    return {
        "path_id": path_id,
        "stage": record.get("stage", "route_validation"),
        "source_row": metadata.get("source_row", ""),
        "step_id": metadata.get("step_id", ""),
        "message": str(record.get("message", "")),
        "details": json.dumps(
            {
                "reaction_step": reaction_step,
                "reaction_node_path": path_text,
            },
            sort_keys=True,
        ),
    }


def mapped_reaction_has_complete_atom_sources(mapped_smiles: str) -> bool:
    reaction = chemistry.parse_reaction(mapped_smiles)
    reactant_maps = {
        int(atom_id) for molecule in reaction.reactants for atom_id in molecule
    }
    product_maps = {
        int(atom_id) for molecule in reaction.products for atom_id in molecule
    }
    return bool(product_maps) and product_maps.issubset(reactant_maps)


def reviewed_donor_attribution(
    row: SourceReaction,
    mapped_smiles: str,
    *,
    occurrence_override: ReactionDonorOverride | None = None,
) -> dict[str, Any] | None:
    """Run an explicitly configured donor-source check, without changing maps."""
    if occurrence_override is None or not occurrence_override.donor_attribution_check:
        return None
    if (row.source_row, row.path_id, row.step_id) != (
        occurrence_override.source_row,
        occurrence_override.path_id,
        occurrence_override.step_id,
    ):
        raise ABSynthError("donor attribution override identity mismatch")
    if occurrence_override.donor_attribution_check != "reviewed_etoac_ethoxy_pair_v1":
        raise ABSynthError("unknown donor attribution check")
    from rdkit import Chem

    from route_inspector.routes.stereo import stereo_component_signature

    record = {
        "source_row": row.source_row,
        "path_id": row.path_id,
        "step_id": row.step_id,
        "status": "failed",
        "check": "reviewed_etoac_ethoxy_pair_v1",
        "expected_atom_maps": "[]",
        "observed_atom_maps": "[]",
        "message": "",
    }
    try:
        reaction = chemistry.parse_reaction(mapped_smiles)
        etoac = [
            m
            for m in reaction.reactants
            if stereo_component_signature(format(m, "m"))
            == stereo_component_signature("CCOC(C)=O")
        ]
        if len(etoac) != 1 or len(reaction.products) != 1:
            raise ValueError("expected one EtOAc donor and one product")
        query = Chem.MolFromSmarts("[CH3][CH2]OC(=O)")

        def carbon_pair(molecule):
            parsed = Chem.MolFromSmiles(format(molecule, "m"))
            if parsed is None:
                raise ValueError("could not parse ethoxy attribution structure")
            matches = parsed.GetSubstructMatches(query)
            if len(matches) != 1:
                raise ValueError("expected one unambiguous ethoxy ester group")
            return [parsed.GetAtomWithIdx(i).GetAtomMapNum() for i in matches[0][:2]]

        expected = carbon_pair(etoac[0])
        observed = carbon_pair(reaction.products[0])
        record["expected_atom_maps"] = json.dumps(expected)
        record["observed_atom_maps"] = json.dumps(observed)
        if expected != observed:
            raise ValueError(
                "product ethoxy carbon pair does not inherit EtOAc ethoxy maps"
            )
        record["status"] = "passed"
    except Exception as exc:
        record["message"] = f"{type(exc).__name__}: {exc}"
    return record


def reaction_children_are_complete(reaction_node: Mapping[str, Any]) -> bool:
    """Check that route molecule children equal the mapped reactant multiset."""

    reaction = chemistry.parse_reaction(
        route_access.reaction_smiles_from_node(dict(reaction_node))
    )
    children = []
    for child in reaction_node.get("children") or ():
        if isinstance(child, Mapping) and child.get("type") == "mol":
            molecule = chemistry.parse_molecule(
                route_access.molecule_node_mapped_smiles(dict(child))
                or route_access.molecule_node_smiles(dict(child))
            )
            children.append(molecule)
    return mapped_component_multisets_equal(reaction.reactants, children)


def _package_version(name: str) -> str:
    try:
        return version(name)
    except PackageNotFoundError:
        return "unknown"


def _write_mapping_input(
    path: Path,
    rows: Sequence[SourceReaction],
    selections: Mapping[int, DonorSelection],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(
                f"{selections[row.source_row].enriched_rxn_smiles}\t{row.source_row}\n"
            )


def _read_mapped_steps(path: Path) -> dict[int, str]:
    mapped: dict[int, str] = {}
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            reaction, separator, source_info = line.rstrip("\n").partition("\t")
            if not separator:
                raise ABSynthError("mapped reaction row lacks source occurrence ID")
            source_row = int(source_info.split("\t", 1)[0])
            if source_row in mapped:
                raise ABSynthError(f"duplicate mapped source row {source_row}")
            mapped[source_row] = reaction
    return mapped


def _mapping_error_source_rows(path: Path) -> set[int]:
    if not path.exists():
        return set()
    failed: set[int] = set()
    with path.open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream, delimiter="\t"):
            source_info = (row.get("source_info") or "").strip()
            if source_info:
                with_value = source_info.split("\t", 1)[0]
                if with_value.isdigit():
                    failed.add(int(with_value))
    return failed


def _map_reactions_from_file(settings, input_path, output_path, **kwargs):
    """Load the optional neural mapper only when new predictions are required."""
    try:
        mapping = import_module("synplan.chem.reaction.curation.mapping")
    except ModuleNotFoundError as exc:
        if not (exc.name or "").startswith("synplan.chem.reaction.curation"):
            raise
        raise ABSynthError(
            "Fresh ABSynth atom mapping requires SynPlanner >=1.7; "
            "verified mapped snapshots can still be reused without the mapper."
        ) from exc
    effective = str(mapping.select_device(settings["device"]))
    if effective.split(":")[0] != settings["device"]:
        raise ABSynthError(
            f"Requested {settings['device']}, mapper selected {effective}; choose the effective device explicitly"
        )
    return mapping.map_reactions_from_file(
        mapping.MappingConfig(**settings), input_path, output_path, **kwargs
    )


def convert_absynth(
    *,
    input_path: Path,
    output_path: Path,
    work_dir: Path,
    condition_registry_path: Path,
    condition_overrides_path: Path | None = None,
    reaction_overrides_path: Path | None = None,
    route_exclusions_path: Path | None = None,
    normalization_baseline_path: Path | None = None,
    oxygen_water_fallback: bool = False,
    pubchem_cache_path: Path,
    use_pubchem: bool = True,
    device: str = "cuda",
    no_amp: bool = False,
    bundle_manifest_path: Path | None = None,
    batch_size: int = 16,
    chunk_size: int = 5000,
    workers: int = 8,
    worker_timeout: int = 120,
    reuse_mapped: bool = False,
    validate_route_cgr: bool = True,
    incremental_baseline_dir: Path | None = None,
    incremental_baseline_output: Path | None = None,
) -> dict[str, Any]:
    """Run the strict end-to-end ABSynth conversion pipeline."""

    reviewed_inputs = {
        "input": input_path,
        "condition_registry": condition_registry_path,
        "condition_overrides": condition_overrides_path,
        "reaction_overrides": reaction_overrides_path,
        "route_exclusions": route_exclusions_path,
        "pubchem_cache": pubchem_cache_path,
    }
    if bundle_manifest_path is not None and use_pubchem:
        raise ABSynthError("A frozen reviewed bundle requires offline PubChem")
    bundle = (
        verify_reviewed_bundle(bundle_manifest_path, reviewed_inputs)
        if bundle_manifest_path
        else None
    )
    options = mapping_options(device=device, no_amp=no_amp)
    work_dir.mkdir(parents=True, exist_ok=True)
    if (incremental_baseline_dir is None) != (incremental_baseline_output is None):
        raise ABSynthError(
            "incremental baseline directory and output must be supplied together"
        )
    if incremental_baseline_dir is not None and (
        reuse_mapped or work_dir.resolve() == incremental_baseline_dir.resolve()
    ):
        raise ABSynthError(
            "incremental conversion requires separate staging and cannot use --reuse-mapped"
        )
    normalization_baseline: set[str] = set()
    if normalization_baseline_path is not None:
        with normalization_baseline_path.open(newline="", encoding="utf-8") as stream:
            normalization_baseline = {
                row["path_id"]
                for row in csv.DictReader(stream, delimiter="\t")
                if row.get("stage") == "route_normalization"
            }
    source_rows = load_absynth(input_path)
    rows_by_id = {row.source_row: row for row in source_rows}
    route_exclusions = load_route_exclusions(route_exclusions_path)
    retained_rows, exclusion_errors = partition_excluded_routes(
        source_rows, route_exclusions
    )
    topologies, route_errors = group_route_topologies(retained_rows)
    route_errors[:0] = exclusion_errors

    registry = load_condition_registry(condition_registry_path)
    overrides = load_condition_overrides(condition_overrides_path)
    reaction_overrides = load_reaction_donor_overrides(reaction_overrides_path)
    validate_reaction_donor_overrides(reaction_overrides, rows_by_id, registry)
    pubchem = PubChemCache(pubchem_cache_path, enabled=use_pubchem)
    resolver = ConditionDonorResolver(
        registry,
        overrides=overrides,
        pubchem=pubchem,
        oxygen_water_fallback=oxygen_water_fallback,
    )

    condition_rows: list[dict[str, Any]] = []
    selections: dict[int, DonorSelection] = {}
    condition_failed_routes: set[str] = set()
    for path_id, topology in topologies.items():
        for row in topology.rows:
            try:
                selection = resolver.resolve(
                    row.rxn_smiles,
                    row.conditions,
                    occurrence_override=reaction_overrides.get(row.source_row),
                )
                selections[row.source_row] = selection
                condition_rows.append(
                    {
                        "source_row": row.source_row,
                        "path_id": path_id,
                        "step_id": row.step_id,
                        "status": "resolved",
                        "resolution_method": selection.resolution_method,
                        "deficit": format_deficit(dict(selection.deficit)),
                        "conditions": row.conditions,
                        "condition_tokens": json.dumps(
                            tokenize_conditions(row.conditions)
                        ),
                        "selected_donors": json.dumps(
                            [
                                candidate.as_dict(copies=copies)
                                for candidate, copies in selection.selected
                            ],
                            sort_keys=True,
                        ),
                        "original_rxn_smiles": row.rxn_smiles,
                        "enriched_rxn_smiles": selection.enriched_rxn_smiles,
                        "message": "",
                    }
                )
            except Exception as exc:
                condition_failed_routes.add(path_id)
                try:
                    missing_atoms = reaction_heavy_atom_deficit(row.rxn_smiles)
                    failed_deficit = format_deficit(missing_atoms)
                    failure_details = {
                        "missing_atoms": dict(sorted(missing_atoms.items()))
                    }
                except Exception as deficit_exc:
                    failed_deficit = ""
                    failure_details = {
                        "missing_atoms": None,
                        "deficit_parse_error": (
                            f"{type(deficit_exc).__name__}: {deficit_exc}"
                        ),
                    }
                condition_rows.append(
                    {
                        "source_row": row.source_row,
                        "path_id": path_id,
                        "step_id": row.step_id,
                        "status": "failed",
                        "resolution_method": "failed",
                        "deficit": failed_deficit,
                        "conditions": row.conditions,
                        "condition_tokens": json.dumps(
                            tokenize_conditions(row.conditions)
                        ),
                        "selected_donors": "[]",
                        "original_rxn_smiles": row.rxn_smiles,
                        "enriched_rxn_smiles": "",
                        "message": f"{type(exc).__name__}: {exc}",
                    }
                )
                route_errors.append(
                    {
                        "path_id": path_id,
                        "stage": "condition_resolution",
                        "source_row": row.source_row,
                        "step_id": row.step_id,
                        "message": f"{type(exc).__name__}: {exc}",
                        "details": json.dumps(failure_details, sort_keys=True),
                    }
                )
    write_tsv(
        work_dir / "condition_resolution.tsv",
        CONDITION_RESOLUTION_FIELDS,
        condition_rows,
    )
    unresolved_token_path = work_dir / "offline_unresolved_tokens.tsv"
    unresolved_token_rows = build_unresolved_token_rows(
        [row for row in condition_rows if row["status"] == "failed"],
        registry,
        pubchem,
    )
    write_tsv(
        unresolved_token_path,
        UNRESOLVED_TOKEN_FIELDS,
        unresolved_token_rows,
    )

    candidate_topologies = {
        path_id: topology
        for path_id, topology in topologies.items()
        if path_id not in condition_failed_routes
    }
    candidate_rows = [
        row for topology in candidate_topologies.values() for row in topology.rows
    ]
    candidate_rows.sort(key=lambda row: row.source_row)

    incremental = None
    if incremental_baseline_dir is not None:
        from route_inspector.datasets.absynth.incremental import IncrementalBaseline

        incremental = IncrementalBaseline(
            incremental_baseline_dir,
            incremental_baseline_output,
            source_rows,
            condition_rows,
            route_exclusions,
            candidate_topologies,
            work_dir,
        )

    mapping_input = work_dir / "mapping_input.smi"
    mapped_output = work_dir / "mapped_reactions.smi"
    mapping_errors = work_dir / "mapping_errors.tsv"
    progress_path = work_dir / "progress.json"
    write_json(
        progress_path,
        {
            "stage": "mapping",
            "candidate_routes": len(candidate_topologies),
            "candidate_rows": len(candidate_rows),
        },
    )
    if reuse_mapped:
        if not mapped_output.exists() or not mapping_input.exists():
            raise ABSynthError(
                "--reuse-mapped requires both mapping input and output snapshots"
            )
        previous_input = _read_mapped_steps(mapping_input)
        expected_input = {
            row.source_row: selections[row.source_row].enriched_rxn_smiles
            for row in candidate_rows
        }
        if previous_input != expected_input:
            raise ABSynthError(
                "--reuse-mapped input differs from the enriched reaction snapshot"
            )
    else:
        _write_mapping_input(mapping_input, candidate_rows, selections)
    mapping_settings = dict(
        batch_size=batch_size,
        chunk_size=chunk_size,
        **options,
        worker_timeout=worker_timeout,
    )
    if incremental is not None:
        incremental.map_affected(
            candidate_rows,
            selections,
            mapping_settings,
            _map_reactions_from_file,
            workers,
        )
    elif not reuse_mapped or not mapped_output.exists():
        _map_reactions_from_file(
            mapping_settings,
            mapping_input,
            mapped_output,
            num_workers=workers,
            silent=False,
            ignore_errors=False,
            error_file_path=mapping_errors,
        )
    mapped_steps = _read_mapped_steps(mapped_output)
    mapping_failed_rows = _mapping_error_source_rows(mapping_errors)
    mapping_failed_rows.update(
        row.source_row for row in candidate_rows if row.source_row not in mapped_steps
    )
    mapping_failed_routes = {
        rows_by_id[source_row].path_id
        for source_row in mapping_failed_rows
        if source_row in rows_by_id
    }
    for source_row in sorted(mapping_failed_rows):
        row = rows_by_id[source_row]
        route_errors.append(
            {
                "path_id": row.path_id,
                "stage": "mapping",
                "source_row": source_row,
                "step_id": row.step_id,
                "message": "reaction absent from mapped output; see mapping_errors.tsv",
            }
        )

    emitted: list[tuple[int, dict[str, Any]]] = []
    validation_failed_routes: set[str] = set()
    target_map_anchored_routes: set[str] = set()
    stereo_audit: list[dict[str, Any]] = []
    normalization_audit: list[dict[str, Any]] = []
    donor_attribution_audit: list[dict[str, Any]] = []
    from route_inspector.routes.cleanup import (
        cleanup_route_reactants,
        write_cleanup_audit,
    )

    reactant_cleanup_audit: list[dict[str, Any]] = []
    cleanup_reprocessed_ids: set[str] = set()
    if incremental is not None:
        # Cached route objects predate this policy in older conversions. Reuse
        # their maps, but never let a mapping cache bypass component cleanup.
        for pid, route in incremental.reused_routes.items():
            cleaned = cleanup_route_reactants(
                route, audit=reactant_cleanup_audit, allow_stereo_only_reactions=True
            )
            if cleaned != route:
                cleanup_reprocessed_ids.add(pid)
            emitted.append(
                (min(r.source_row for r in candidate_topologies[pid].rows), cleaned)
            )
        carried = incremental.carried_errors()
        route_errors.extend(carried)
        validation_failed_routes.update(e["path_id"] for e in carried)
        stereo_audit.extend(incremental.carried_audit("stereo_classification.tsv"))
        normalization_audit.extend(
            incremental.carried_audit("route_normalization_audit.tsv")
        )
        donor_attribution_audit.extend(
            incremental.carried_audit("donor_attribution.tsv")
        )
        target_map_anchored_routes.update(
            pid
            for pid, route in incremental.reused_routes.items()
            if route.get("metadata", {})
            .get("route_map_normalization", {})
            .get("method")
            == "target_map_one_anchor"
        )
    for route_index, (path_id, topology) in enumerate(candidate_topologies.items()):
        if route_index % 25 == 0:
            write_json(
                progress_path,
                {
                    "stage": "route_validation",
                    "routes_processed": route_index,
                    "candidate_routes": len(candidate_topologies),
                    "current_path_id": path_id,
                    "valid_routes": len(emitted),
                    "validation_failed_routes": len(validation_failed_routes),
                    "mapping_failed_routes": len(mapping_failed_routes),
                },
            )
        if path_id in mapping_failed_routes:
            continue
        if incremental is not None and path_id not in incremental.affected:
            if (
                path_id not in incremental.reused_routes
                and path_id not in validation_failed_routes
            ):
                raise ABSynthError(
                    f"baseline route has neither an output nor a failure: {path_id}"
                )
            continue
        incomplete = [
            row
            for row in topology.rows
            if not mapped_reaction_has_complete_atom_sources(
                mapped_steps[row.source_row]
            )
        ]
        if incomplete:
            validation_failed_routes.add(path_id)
            for row in incomplete:
                route_errors.append(
                    {
                        "path_id": path_id,
                        "stage": "atom_source_validation",
                        "source_row": row.source_row,
                        "step_id": row.step_id,
                        "message": "a product atom map is absent from the reactant side",
                    }
                )
            continue
        attribution_failures = []
        for row in topology.rows:
            attribution = reviewed_donor_attribution(
                row,
                mapped_steps[row.source_row],
                occurrence_override=reaction_overrides.get(row.source_row),
            )
            if attribution is not None:
                donor_attribution_audit.append(attribution)
                if attribution["status"] != "passed":
                    attribution_failures.append(attribution)
        if attribution_failures:
            validation_failed_routes.add(path_id)
            for attribution in attribution_failures:
                route_errors.append(
                    {
                        "path_id": path_id,
                        "source_row": attribution["source_row"],
                        "step_id": attribution["step_id"],
                        "stage": "donor_attribution_validation",
                        "message": attribution["message"],
                        "details": json.dumps(
                            {
                                "check": attribution["check"],
                                "expected_atom_maps": json.loads(
                                    attribution["expected_atom_maps"]
                                ),
                                "observed_atom_maps": json.loads(
                                    attribution["observed_atom_maps"]
                                ),
                            },
                            sort_keys=True,
                        ),
                    }
                )
            continue
        route = None
        try:
            route = build_route_tree(topology, selections, mapped_steps)
            route = routes.normalize_route_tree(
                route,
                anchor_target_map_one=True,
                alignment_policy="stereo_preserving_witness",
                alignment_audit=normalization_audit,
                remove_noncontributing_reactants=True,
                reactant_cleanup_audit=reactant_cleanup_audit,
            )
            stereo_audit.extend(annotate_stereo_only_steps(route))
            if (
                route.get("metadata", {})
                .get("route_map_normalization", {})
                .get("method")
                == "target_map_one_anchor"
            ):
                target_map_anchored_routes.add(path_id)
            stack = [route]
            while stack:
                node = stack.pop()
                if node.get(
                    "type"
                ) == "reaction" and not reaction_children_are_complete(node):
                    raise ABSynthError(
                        "reaction molecule children do not equal reactant multiset"
                    )
                stack.extend(
                    child
                    for child in node.get("children", ())
                    if isinstance(child, dict)
                )
            if validate_route_cgr:
                result = validate_routes_mapping(
                    {path_id: route},
                    dataset="ABSynth",
                    allow_stereo_only_reactions=True,
                )
                validation_records = result.records
            else:
                validation_records, _count = validate_route_edges(
                    path_id, route, dataset="ABSynth", allow_stereo_only_reactions=True
                )
            if validation_records:
                route_errors.extend(
                    _validation_error_with_source(path_id, route, record)
                    for record in validation_records
                )
                validation_failed_routes.add(path_id)
                continue
            emitted.append((min(row.source_row for row in topology.rows), route))
        except Exception as exc:
            validation_failed_routes.add(path_id)
            error_path = getattr(exc, "reaction_node_path", None)
            route_errors.append(
                _validation_error_with_source(
                    path_id,
                    route or {},
                    {
                        "stage": "route_normalization",
                        "reaction_node_path": ".".join(map(str, error_path or ())),
                        "message": f"{type(exc).__name__}: {exc}",
                    },
                )
            )

    emitted.sort(key=lambda item: item[0])
    output_routes = [route for _source_row, route in emitted]
    cleanup_provenance = write_cleanup_audit(work_dir, reactant_cleanup_audit)
    emitted_ids = {route["metadata"]["path_id"] for route in output_routes}
    stereo_audit.sort(
        key=lambda row: (
            int(row["source_row"]),
            tuple(int(index) for index in row["reaction_node_path"].split(".")),
        )
    )
    for audit_row in stereo_audit:
        audit_row["route_emitted"] = audit_row["path_id"] in emitted_ids
    stereo_audit_path = work_dir / "stereo_classification.tsv"
    write_tsv(stereo_audit_path, STEREO_CLASSIFICATION_FIELDS, stereo_audit)
    normalization_audit.sort(
        key=lambda row: (
            int(row["source_row"] or 0),
            tuple(
                int(index) for index in row["reaction_node_path"].split(".") if index
            ),
            row["method"],
        )
    )
    for audit_row in normalization_audit:
        audit_row["route_emitted"] = audit_row["path_id"] in emitted_ids
    normalization_audit_path = work_dir / "route_normalization_audit.tsv"
    write_tsv(normalization_audit_path, NORMALIZATION_AUDIT_FIELDS, normalization_audit)
    donor_attribution_path = work_dir / "donor_attribution.tsv"
    donor_attribution_audit.sort(key=lambda row: int(row["source_row"]))
    write_tsv(donor_attribution_path, DONOR_ATTRIBUTION_FIELDS, donor_attribution_audit)
    stereo_steps = [
        row for row in stereo_audit if row["classification"] == "stereo_only"
    ]
    stereo_routes = {row["path_id"] for row in stereo_steps}
    if bundle_manifest_path:
        if verify_reviewed_bundle(bundle_manifest_path, reviewed_inputs) != bundle:
            raise ABSynthError("Reviewed bundle changed during conversion")
    write_json(output_path, output_routes)
    for route_error in route_errors:
        route_error.setdefault("details", "{}")
    write_tsv(work_dir / "route_errors.tsv", ROUTE_ERROR_FIELDS, route_errors)

    summary = {
        "reactant_cleanup": cleanup_provenance["summary"],
        "input_rows": len(source_rows),
        "input_routes": len({row.path_id for row in source_rows}),
        "excluded_routes": len(route_exclusions),
        "excluded_rows": len(source_rows) - len(retained_rows),
        "topology_valid_routes": len(topologies),
        "topology_failed_routes": len(
            {row["path_id"] for row in route_errors if row["stage"] == "topology"}
        ),
        "condition_failed_routes": len(condition_failed_routes),
        "mapping_input_rows": len(candidate_rows),
        "mapped_rows": len(mapped_steps),
        "mapping_failed_routes": len(mapping_failed_routes),
        "validation_failed_routes": len(validation_failed_routes),
        "target_map_anchored_routes": len(target_map_anchored_routes),
        "normalization_baseline_routes": len(normalization_baseline),
        "normalization_recovered_routes": len(normalization_baseline & emitted_ids),
        "donor_attribution_failed_rows": sum(
            row["status"] != "passed" for row in donor_attribution_audit
        ),
        "normalization_alignment_methods": dict(
            sorted(
                Counter(
                    row["method"]
                    for row in normalization_audit
                    if row["status"] == "valid"
                ).items()
            )
        ),
        "stereo_only_step_occurrences": len(stereo_steps),
        "stereo_only_source_rows": len({row["source_row"] for row in stereo_steps}),
        "stereo_only_routes": len(stereo_routes),
        "stereo_only_recovered_routes": len(stereo_routes & emitted_ids),
        "stereo_classification_counts": dict(
            sorted(Counter(row["classification"] for row in stereo_audit).items())
        ),
        "output_routes": len(output_routes),
        "output_reaction_occurrences": sum(
            route_access.count_reaction_nodes(route) for route in output_routes
        ),
        "condition_deficit_rows": sum(
            bool(selection.deficit) for selection in selections.values()
        ),
        "condition_donor_rows": sum(
            bool(selection.selected) for selection in selections.values()
        ),
        "condition_resolution_methods": dict(
            sorted(
                Counter(
                    selection.resolution_method for selection in selections.values()
                ).items()
            )
        ),
        "unresolved_condition_tokens": len(unresolved_token_rows),
        "input": str(input_path),
        "output": str(output_path),
        "work_dir": str(work_dir),
    }
    incremental_provenance = None
    if incremental is not None:
        incremental_provenance = incremental.provenance(
            output_routes, cleanup_reprocessed_ids=cleanup_reprocessed_ids
        )
        summary["incremental"] = incremental.mapping_stats
    write_json(work_dir / "summary.json", summary)
    mode = (
        "incremental"
        if incremental is not None
        else "reuse"
        if reuse_mapped
        else "fresh"
    )
    manifest = {
        "format": "route-inspector.absynth.v2",
        "runtime": runtime_provenance(),
        "reviewed_bundle": bundle,
        "mapper_model": mapper_identity() if mode != "reuse" else None,
        "reactant_cleanup": cleanup_provenance,
        "input": {"path": str(input_path), "sha256": _sha256(input_path)},
        "route_exclusions": (
            {
                "path": str(route_exclusions_path),
                "sha256": _sha256(route_exclusions_path),
                "path_ids": sorted(route_exclusions),
                "excluded_rows": len(source_rows) - len(retained_rows),
            }
            if route_exclusions_path is not None
            else None
        ),
        "condition_registry": {
            "path": str(condition_registry_path),
            "sha256": _sha256(condition_registry_path),
        },
        "condition_overrides": (
            {
                "path": str(condition_overrides_path),
                "sha256": _sha256(condition_overrides_path),
            }
            if condition_overrides_path is not None
            and condition_overrides_path.exists()
            else None
        ),
        "reaction_overrides": (
            {
                "path": str(reaction_overrides_path),
                "sha256": _sha256(reaction_overrides_path),
            }
            if reaction_overrides_path is not None and reaction_overrides_path.exists()
            else None
        ),
        "oxygen_water_fallback": oxygen_water_fallback,
        "route_alignment": {
            "policy": "stereo_preserving_witness",
            "minimum_remaps_proven": False,
            "comparison_tool": "chython-synplan",
            "comparison_tool_version": _package_version("chython-synplan"),
            "audit": {
                "path": str(normalization_audit_path),
                "sha256": _sha256(normalization_audit_path),
                "row_count": len(normalization_audit),
            },
            "baseline": (
                {
                    "path": str(normalization_baseline_path),
                    "sha256": _sha256(normalization_baseline_path),
                }
                if normalization_baseline_path is not None
                else None
            ),
            "recovered_routes": len(normalization_baseline & emitted_ids),
        },
        "donor_attribution": {
            "policy": "reviewed_etoac_ethoxy_pair_v1",
            "path": str(donor_attribution_path),
            "sha256": _sha256(donor_attribution_path),
            "row_count": len(donor_attribution_audit),
        },
        "stereo_validation": {
            "policy": "preserve_evidenced_stereo_only_v1",
            "allow_stereo_only_reactions": True,
            "comparison_tool": "chython-synplan",
            "comparison_tool_version": _package_version("chython-synplan"),
            "audit": {
                "path": str(stereo_audit_path),
                "sha256": _sha256(stereo_audit_path),
                "row_count": len(stereo_audit),
            },
            "recovered_routes": len(stereo_routes & emitted_ids),
        },
        "mapping_snapshot": {
            "reused": reuse_mapped or incremental is not None,
            "mode": "incremental"
            if incremental is not None
            else ("reuse" if reuse_mapped else "fresh"),
            "input": {"path": str(mapping_input), "sha256": _sha256(mapping_input)},
            "output": {"path": str(mapped_output), "sha256": _sha256(mapped_output)},
        },
        "unresolved_condition_tokens": {
            "path": str(unresolved_token_path),
            "sha256": _sha256(unresolved_token_path),
            "row_count": len(unresolved_token_rows),
            "pubchem_mode": "online" if use_pubchem else "offline",
        },
        "pubchem_cache": {
            "path": str(pubchem_cache_path),
            "sha256": _sha256(pubchem_cache_path)
            if pubchem_cache_path.exists()
            else "",
        },
        "mapping": {
            **mapping_execution(mapping_settings, mode=mode),
            "requested_device": device,
            "requested_no_amp": no_amp,
            "batch_size": batch_size,
            "chunk_size": chunk_size,
            "workers": workers,
            "worker_timeout": worker_timeout,
        },
        "versions": {
            "route-inspector": _package_version("route-inspector"),
            "SynPlanner": _package_version("SynPlanner"),
            "chython-synplan": _package_version("chython-synplan"),
            "rdkit": _package_version("rdkit"),
        },
        "summary": summary,
        "output_sha256": _sha256(output_path),
    }
    if incremental_provenance is not None:
        manifest["incremental"] = incremental_provenance
    write_json(work_dir / "manifest.json", manifest)
    write_json(
        progress_path,
        {
            "stage": "complete",
            "candidate_routes": len(candidate_topologies),
            "routes_processed": len(candidate_topologies),
            "valid_routes": len(output_routes),
            "validation_failed_routes": len(validation_failed_routes),
            "mapping_failed_routes": len(mapping_failed_routes),
        },
    )
    return summary


__all__ = [
    "ABSynthError",
    "ConditionDonorResolver",
    "DonorCandidate",
    "DonorResolutionError",
    "DonorSelection",
    "PubChemCache",
    "ReactionDonorOverride",
    "RegistryEntry",
    "RouteTopology",
    "SourceReaction",
    "TopologyError",
    "build_route_tree",
    "build_unresolved_token_rows",
    "convert_absynth",
    "format_deficit",
    "group_route_topologies",
    "load_absynth",
    "load_condition_overrides",
    "load_condition_registry",
    "load_reaction_donor_overrides",
    "mapped_reaction_has_complete_atom_sources",
    "normalize_condition_token",
    "reaction_heavy_atom_deficit",
    "reconstruct_route_topology",
    "select_minimum_donors",
    "split_reaction_smiles",
    "tokenize_conditions",
    "validate_reaction_donor_overrides",
]
