"""Read-only ABSynth mapping, reaction-center and NameRXN readiness analysis.

This does not build a Reference library, change routes, or reinterpret auxiliary
NameRXN labels as a single class. All output occurrences retain CSV provenance.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import subprocess
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from html import escape
from multiprocessing import get_context
from pathlib import Path

from route_inspector import chemistry
from route_inspector.datasets.absynth import conversion as absynth
from route_inspector.datasets.absynth.reporting import (
    class_name_display,
    write_multicenter_report,
)
from route_inspector.datasets.absynth.runtime import (
    classifier_preflight,
    runtime_provenance,
)
from route_inspector.infrastructure.artifacts import write_json
from route_inspector.infrastructure.hashing import file_record as record
from route_inspector.infrastructure.text import write_tsv
from route_inspector.routes.validation import (
    validate_route_edges,
    validate_routes_mapping,
)


def walk(node, path=()):
    yield path, node
    for index, child in enumerate(node.get("children") or []):
        yield from walk(child, (*path, index))


def parse_codes(raw):
    """Keep primary/auxiliary order and unknown labels; deduplicate only sets."""
    labels = raw.split(";") if raw else []
    numeric = [s for s in labels if re.fullmatch(r"\d+\.\d+\.\d+(?:\.\d+)*", s)]
    tiers = sorted({".".join(s.split(".")[:3]) for s in numeric})
    return {
        "raw_code": raw,
        "raw_labels": labels,
        "tier3_codes": tiers,
        "status": "classified" if numeric else "unclassified",
        "has_auxiliary_labels": len(labels) > 1,
        "mixed_classes": len(tiers) > 1,
        "unknown_labels": [s for s in labels if s not in numeric],
    }


def initialize_worker():
    import torch

    torch.set_num_threads(1)


def supported_classifier_input(text):
    """Accept one SMILES token with its intact optional CXSMILES extension."""
    return bool(re.fullmatch(r"\S+(?: \|[^|\r\n]*\|)?", text))


def restore_supported_cx_inputs(scanned):
    """Upgrade cached conservative preflights after the NameRXN CX probe."""
    restored = []
    for route in scanned:
        for row in route["reactions"]:
            text = row.get("classifier_input", "")
            if "classification_id" not in row and supported_classifier_input(text):
                row["classification_id"] = (
                    "RXN_" + hashlib.sha256(text.encode()).hexdigest()
                )
                restored.append(
                    {
                        "path_id": row["path_id"],
                        "step_id": row["step_id"],
                        "source_row": row["source_row"],
                        "node_path": row["node_path"],
                        "classifier_input": text,
                    }
                )
                route["errors"] = [
                    e
                    for e in route["errors"]
                    if not (
                        e.get("node_path") == row["node_path"]
                        and "CXSMILES/whitespace requires explicit classifier support"
                        in e.get("message", "")
                    )
                ]
    return restored


def restore_serialization_only_inputs(scanned):
    """Try intact serialization when optional canonicalization rejects aromaticity.

    This neither sanitizes nor repairs the structure. NameRXN may still reject it.
    """
    fallbacks = []
    for route in scanned:
        for row in route["reactions"]:
            matching = [
                e
                for e in route["errors"]
                if e.get("node_path") == row["node_path"]
                and e.get("message", "").startswith("InvalidAromaticRing:")
            ]
            if matching and "classification_id" not in row:
                text = str(chemistry.parse_reaction(row["mapped_reaction"]).copy())
                if not supported_classifier_input(text):
                    continue
                row.update(
                    classifier_input=text,
                    classification_id="RXN_"
                    + hashlib.sha256(text.encode()).hexdigest(),
                    classifier_input_policy="serialization_only_no_canonicalization",
                    classifier_input_warning=matching[0]["message"],
                )
                fallbacks.append(
                    {
                        "path_id": row["path_id"],
                        "step_id": row["step_id"],
                        "source_row": row["source_row"],
                        "classifier_input": text,
                        "reason": matching[0]["message"],
                    }
                )
                route["errors"] = [e for e in route["errors"] if e not in matching]
    return fallbacks


def scan_route(item):
    index, root = item
    pid = str(root["metadata"]["path_id"])
    validation = validate_routes_mapping(
        {pid: root}, dataset="ABSynth", allow_stereo_only_reactions=True
    )
    has_stereo = any(
        n.get("metadata", {}).get("transformation_kind") == "stereo_only"
        for _, n in walk(root)
    )
    default_errors = (
        validate_route_edges(pid, root, dataset="ABSynth")[0]
        if has_stereo
        else validation.records
    )
    reactions, errors = [], []
    for path, node in walk(root):
        if node.get("type") != "reaction":
            continue
        meta = node["metadata"]
        row = {
            "route_index": index,
            "path_id": pid,
            "source_row": meta["source_row"],
            "step_id": meta["step_id"],
            "node_path": list(path),
            "mapped_reaction": node["smiles"],
            "transformation_kind": meta.get("transformation_kind", ""),
            "original_rxn_smiles": meta["original_rxn_smiles"],
            "rxn_name": meta.get("rxn_name", ""),
            "generated_stage_id": meta.get("generated_stage_id", ""),
            "split_id": meta.get("absynth_deprotection_split", {}).get("split_id", ""),
        }
        try:
            rxn = chemistry.parse_reaction(node["smiles"])
            cgr = ~rxn
            centers = sorted(
                (sorted(c) for c in cgr.centers_list), key=lambda c: tuple(c)
            )
            row.update(
                center_components=centers,
                center_count=len(centers),
                center_atom_maps=sorted(cgr.center_atoms),
                more_than_two_centers=len(centers) > 2,
            )
            assert absynth.mapped_reaction_has_complete_atom_sources(node["smiles"]), (
                "incomplete product atom sources"
            )
            assert absynth.reaction_children_are_complete(node), (
                "reactant-child mismatch"
            )
            row["classifier_input"] = chemistry.canonical_unmapped_reaction_string(
                node["smiles"]
            )
            # Local NameRXN/RDKit accepts intact CXSMILES before the record ID.
            if not supported_classifier_input(row["classifier_input"]):
                raise ValueError(
                    "unsupported whitespace/title in classifier input; not silently stripped"
                )
            row["classification_id"] = (
                "RXN_" + hashlib.sha256(row["classifier_input"].encode()).hexdigest()
            )
        except Exception as exc:
            errors.append(
                {
                    "path_id": pid,
                    "step_id": meta["step_id"],
                    "source_row": meta["source_row"],
                    "node_path": list(path),
                    "stage": "reaction_preflight",
                    "message": f"{type(exc).__name__}: {exc}",
                }
            )
        reactions.append(row)
    return {
        "path_id": pid,
        "reactions": reactions,
        "mapping_errors": validation.records,
        "library_default_errors": default_errors,
        "errors": errors,
    }


def tsv(path, rows, fields=None):
    serial = [
        {
            key: json.dumps(value, sort_keys=True)
            if isinstance(value, (dict, list))
            else value
            for key, value in row.items()
            if fields is None or key in fields
        }
        for row in rows
    ]
    write_tsv(
        path,
        fields or (list(serial[0]) if serial else ["path_id", "step_id", "message"]),
        serial,
    )


def scan(args, roots, fingerprint):
    target = args.output_dir / "scan.jsonl"
    if target.exists():
        info = json.loads((args.output_dir / "scan_manifest.json").read_text())
        assert info["input"] == fingerprint and info["scan"] == record(target)
        return [json.loads(line) for line in target.read_text().splitlines()]
    results = []
    with ProcessPoolExecutor(
        max_workers=args.workers,
        mp_context=get_context("spawn"),
        initializer=initialize_worker,
    ) as pool:
        with target.open("w") as stream:
            for index, result in enumerate(
                pool.map(scan_route, enumerate(roots), chunksize=1), 1
            ):
                results.append(result)
                stream.write(json.dumps(result) + "\n")
                if index % 100 == 0:
                    stream.flush()
                    print(
                        json.dumps(
                            {
                                "stage": "mapping_and_centers",
                                "routes": index,
                                "total": len(roots),
                            }
                        ),
                        flush=True,
                    )
    write_json(
        args.output_dir / "scan_manifest.json",
        {"input": fingerprint, "scan": record(target)},
    )
    return results


def classify(args, reactions):
    unique = {
        r["classification_id"]: r["classifier_input"]
        for r in reactions
        if "classification_id" in r
    }
    results = {}
    rawdir = args.output_dir / "namerxn_raw"
    rawdir.mkdir(exist_ok=True)
    executable = args.namerxn_path.resolve()
    version = subprocess.run(
        [str(executable), "-help"], capture_output=True, text=True, check=False
    )
    (rawdir / "version.txt").write_text(version.stdout + version.stderr)
    fallback_ids = {
        r["classification_id"]
        for r in reactions
        if r.get("classifier_input_policy") == "serialization_only_no_canonicalization"
    }
    ordinary = sorted(
        (rid, smi)
        for rid, smi in unique.items()
        if rid not in fallback_ids and not any(c.isspace() for c in smi)
    )
    extended = sorted(
        (rid, smi)
        for rid, smi in unique.items()
        if rid not in fallback_ids and any(c.isspace() for c in smi)
    )
    fallback = sorted((rid, smi) for rid, smi in unique.items() if rid in fallback_ids)
    batches = [
        (prefix, offset, items[offset : offset + args.batch_size])
        for prefix, items in (
            ("", ordinary),
            ("cx_", extended),
            ("noncanonical_", fallback),
        )
        for offset in range(0, len(items), args.batch_size)
    ]
    for prefix, offset, batch in batches:
        inp, out = (
            rawdir / f"{prefix}{offset:06d}.input.smi",
            rawdir / f"{prefix}{offset:06d}.output.smi",
        )
        expected = "".join(f"{smi} {rid}\n" for rid, smi in batch)
        marker = rawdir / f"{prefix}{offset:06d}.complete.json"
        if marker.exists():
            saved = json.loads(marker.read_text())
            assert inp.read_text() == expected and saved["input"] == record(inp)
            assert saved["output"] == record(out) and saved["executable"] == record(
                args.namerxn_path
            )
        else:
            inp.write_text(expected)
            completed = subprocess.run(
                [str(executable), "-nomap", str(inp), str(out)],
                capture_output=True,
                text=True,
                check=False,
            )
            (rawdir / f"{prefix}{offset:06d}.log").write_text(
                completed.stdout + completed.stderr
            )
            if completed.returncode or not out.exists():
                raise RuntimeError(
                    f"NameRXN failed in batch {offset}, exit={completed.returncode}; see raw log"
                )
            write_json(
                marker,
                {
                    "input": record(inp),
                    "output": record(out),
                    "executable": record(args.namerxn_path),
                },
            )
        ids = {rid for rid, _ in batch}
        found = {}
        for line in out.read_text().splitlines():
            parts = line.rsplit(maxsplit=2)
            if len(parts) != 3 or parts[1] not in ids or parts[1] in found:
                raise ValueError(
                    f"Malformed, unexpected or duplicate NameRXN record in {out}"
                )
            found[parts[1]] = parse_codes(parts[2])
        for rid, smi in batch:
            results[rid] = {
                "classification_id": rid,
                "classifier_input": smi,
                **found.get(
                    rid,
                    {
                        **parse_codes(""),
                        "status": "missing_output",
                        "reason": "NameRXN emitted no record",
                    },
                ),
            }
        print(
            json.dumps(
                {
                    "stage": "namerxn",
                    "unique_reactions": len(results),
                    "total": len(unique),
                }
            ),
            flush=True,
        )
    write_json(args.output_dir / "classifications.json", results)
    return results


def reuse_classifications(args, reactions):
    """Reuse only hash-verified results for byte-identical classifier inputs."""
    from route_inspector.datasets.absynth.filtering import verified_analysis_artifact

    baseline = args.classification_baseline
    manifest_path = baseline / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    cached_path = baseline / "classifications.json"
    verified_analysis_artifact(manifest, cached_path)
    if manifest["namerxn_executable"]["sha256"] != record(args.namerxn_path)["sha256"]:
        raise ValueError("classification baseline uses a different NameRXN executable")
    cache = json.loads(cached_path.read_text())
    reused = {}
    for row in reactions:
        rid = row.get("classification_id")
        if rid is None:
            continue
        text = row["classifier_input"]
        expected = "RXN_" + hashlib.sha256(text.encode()).hexdigest()
        if (
            rid != expected
            or rid not in cache
            or cache[rid]["classifier_input"] != text
        ):
            raise ValueError(
                f"no exact cached classification for {row['path_id']}/{row['step_id']}; rerun without --classification-baseline"
            )
        reused[rid] = cache[rid]
    write_json(args.output_dir / "classifications.json", reused)
    write_json(
        args.output_dir / "classification_reuse.json",
        {
            "mode": "exact_input_verified_cache_reuse",
            "baseline_manifest": record(manifest_path),
            "baseline_classifications": record(cached_path),
            "baseline_input": manifest["input"],
            "namerxn_executable": record(args.namerxn_path),
            "reused_unique_inputs": len(reused),
            "new_classifier_calls": 0,
            "missing_and_unclassified_results_preserved": True,
        },
    )
    names = {
        r["raw_code"]: {
            "reaction_names": r.get("reaction_names", []),
            "class_names": r.get("class_names", []),
        }
        for r in reused.values()
        if r["status"] == "classified"
    }
    write_json(args.output_dir / "namerxn_class_names.json", names)
    return reused


def smoke_library(args, roots, scanned, fingerprint):
    from route_inspector.workflows.reference_library import (
        route_tactic_processor_from_config,
    )

    processor = route_tactic_processor_from_config(
        args.config, source_id_adapter="raw", include_retro_bleu_bigrams=True
    )
    by_id = {str(r["metadata"]["path_id"]): r for r in roots}
    selected = {}
    # Check independent cohorts without changing any production validation policy.
    for category, predicate in (
        ("ordinary", lambda r: not r["library_default_errors"]),
        (
            "stereo_only",
            lambda r: any(
                n["transformation_kind"] == "stereo_only" for n in r["reactions"]
            ),
        ),
        (
            "more_than_two_centers",
            lambda r: any(n.get("more_than_two_centers") for n in r["reactions"]),
        ),
    ):
        cohort = sorted(
            (r for r in scanned if predicate(r)),
            key=lambda r: (len(r["reactions"]), int(r["path_id"])),
        )[:3]
        for r in cohort:
            selected.setdefault(r["path_id"], []).append(category)
    outcomes = []
    for pid, categories in selected.items():
        try:
            result = processor.process_route(
                pid,
                by_id[pid],
                dataset_id="ABSynth",
                source_identity="sha256:" + fingerprint["sha256"],
            )
            outcome = {
                "path_id": pid,
                "categories": categories,
                "status": "passed",
                "summary": result.to_summary(),
            }
        except Exception as exc:
            outcome = {
                "path_id": pid,
                "categories": categories,
                "status": "failed",
                "message": str(exc),
                "details": getattr(exc, "details", {}),
            }
        outcomes.append(outcome)
        print(
            json.dumps(
                {"stage": "library_smoke", "path_id": pid, "status": outcome["status"]}
            ),
            flush=True,
        )
    write_json(
        args.output_dir / "library_smoke.json",
        {
            "profile": processor.profile.to_dict(),
            "outcomes": outcomes,
            "scope": "production processor smoke test, not full corpus library construction",
        },
    )
    return outcomes


def class_names(args, classified):
    """Obtain authoritative readable names for each observed label combination."""
    examples = {}
    for row in classified.values():
        if row["status"] == "classified":
            examples.setdefault(row["raw_code"], row)
    path = args.output_dir / "namerxn_raw/names.input.smi"
    path.write_text(
        "".join(
            f"{r['classifier_input']} {r['classification_id']}\n"
            for _, r in sorted(examples.items())
        )
    )
    completed = (
        subprocess.run(
            [str(args.namerxn_path.resolve()), "-nomap", str(path)],
            capture_output=True,
            text=True,
            check=False,
        )
        if examples
        else subprocess.CompletedProcess([], 0, "", "")
    )
    (args.output_dir / "namerxn_raw/names.output.txt").write_text(completed.stdout)
    (args.output_dir / "namerxn_raw/names.log").write_text(completed.stderr)
    if completed.returncode:
        raise RuntimeError("NameRXN readable-name lookup failed; see names.log")
    by_id = {r["classification_id"]: r for r in examples.values()}
    names = {}
    for line in completed.stdout.splitlines():
        rid, separator, text = line.partition(": ")
        if not separator or rid not in by_id:
            continue
        code = by_id[rid]["raw_code"]
        if not text.startswith(code + " ") or not text.endswith("]"):
            raise ValueError(
                "NameRXN readable-name output differs from classified codes"
            )
        reaction_names, sep, tier_names = text[len(code) + 1 :].rpartition(" [")
        if not sep:
            raise ValueError("NameRXN readable-name output lacks class names")
        names[code] = {
            "reaction_names": reaction_names.split(";"),
            "class_names": tier_names[:-1].split(";"),
        }
    for row in classified.values():
        row.update(
            names.get(row["raw_code"], {"reaction_names": [], "class_names": []})
        )
    write_json(args.output_dir / "classifications.json", classified)
    write_json(args.output_dir / "namerxn_class_names.json", names)


def render_example(root, row):
    from route_inspector.visualization.route import _prepare_json_route_svg_inputs
    from route_inspector.visualization.synplanner import _render_prepared_route

    nodes = dict(walk(root))
    path = tuple(row["node_path"])
    reaction = nodes[path]
    target = copy.deepcopy(nodes[path[:-1]])
    target["children"] = [copy.deepcopy(reaction)]
    for child in target["children"][0]["children"]:
        child["children"] = []
    centers = set(row["center_atom_maps"])
    highlights = {}
    for molecule_path, node in walk(target):
        if node.get("type") == "mol":
            maps = centers & set(chemistry.parse_molecule(node["smiles"]))
            if maps:
                highlights[molecule_path] = frozenset(maps)
    columns, pred = _prepare_json_route_svg_inputs(
        target,
        labeled=True,
        highlights=highlights,
        skipped_highlights={},
        pg_highlights={},
    )
    return _render_prepared_route(target, columns, pred, box_solid=False)


def report(args, roots, scanned, classified, smoke, fingerprint):
    reactions = [n for r in scanned for n in r["reactions"]]
    source_nodes = {
        (str(root["metadata"]["path_id"]), path): node
        for root in roots
        for path, node in walk(root)
        if node.get("type") == "reaction"
    }
    for row in reactions:
        label = classified.get(
            row.get("classification_id"), {**parse_codes(""), "status": "input_error"}
        )
        row.update(
            {
                key: label[key]
                for key in (
                    "raw_code",
                    "tier3_codes",
                    "status",
                    "has_auxiliary_labels",
                    "mixed_classes",
                    "unknown_labels",
                )
            }
        )
        row.update(
            reaction_names=label.get("reaction_names", []),
            class_names=label.get("class_names", []),
        )
        row["namerxn_class_names"] = label.get("class_names", [])
        row.update(
            class_name_display(
                row,
                source_nodes[(row["path_id"], tuple(row["node_path"]))].get(
                    "metadata", {}
                ),
            )
        )
        row["classification_diagnostic"] = label.get("reason", "")
    mapping_errors = [e for r in scanned for e in r["mapping_errors"]]
    library_errors = [e for r in scanned for e in r["library_default_errors"]]
    other_errors = [e for r in scanned for e in r["errors"]]
    tsv(args.output_dir / "mapping_errors.tsv", mapping_errors)
    tsv(args.output_dir / "library_default_errors.tsv", library_errors)
    tsv(args.output_dir / "errors.tsv", other_errors)
    fields = list(dict.fromkeys(key for row in reactions for key in row))
    tsv(args.output_dir / "reactions.tsv", reactions, fields)
    flagged = [r for r in reactions if r.get("more_than_two_centers")]
    multicenter = [r for r in reactions if r.get("center_count", 0) > 1]
    mixed = [r for r in reactions if r["mixed_classes"]]
    tsv(args.output_dir / "more_than_two_centers.tsv", flagged, fields)
    tsv(args.output_dir / "multicenter_reactions.tsv", multicenter, fields)
    tsv(args.output_dir / "mixed_class_reactions.tsv", mixed, fields)
    unresolved = [r for r in reactions if r["status"] != "classified"]
    tsv(args.output_dir / "classification_unresolved.tsv", unresolved, fields)
    tsv(
        args.output_dir / "classification_errors.tsv",
        [r for r in reactions if r["status"] in {"missing_output", "input_error"}],
        fields,
    )
    grouped = defaultdict(list)
    for r in reactions:
        grouped[r["path_id"]].append(r)
    routes = [
        {
            "path_id": pid,
            "route_index": rows[0]["route_index"],
            "reaction_nodes": len(rows),
            "distinct_source_rows": len({r["source_row"] for r in rows}),
            "more_than_two_center_steps": sorted(
                {r["step_id"] for r in rows if r.get("more_than_two_centers")}
            ),
            "mixed_class_steps": sorted(
                {r["step_id"] for r in rows if r["mixed_classes"]}
            ),
            "tier3_codes_across_steps": sorted(
                {code for r in rows for code in r["tier3_codes"]}
            ),
            "unclassified_reaction_nodes": sum(
                r["status"] != "classified" for r in rows
            ),
        }
        for pid, rows in grouped.items()
    ]
    tsv(args.output_dir / "routes.tsv", routes)
    tsv(
        args.output_dir / "mixed_class_routes.tsv",
        [r for r in routes if r["mixed_class_steps"]],
        list(routes[0]) if routes else None,
    )
    sample = sorted(
        {(r["path_id"], r["source_row"]): r for r in [*flagged, *mixed]}.values(),
        key=lambda r: (
            -int(r["mixed_classes"]),
            -r.get("center_count", 0),
            int(r["path_id"]),
        ),
    )[:12]
    by_id = {str(r["metadata"]["path_id"]): r for r in roots}
    figures = []
    for row in sample:
        try:
            svg = render_example(by_id[row["path_id"]], row)
            figures.append(
                f"<h3>Path {escape(row['path_id'])} / Step {escape(row['step_id'])}: {row['center_count']} centers; {escape(row['raw_code'])}</h3><p>{escape('; '.join(row['class_names']))}</p>{svg}"
            )
        except Exception as exc:
            other_errors.append(
                {
                    "path_id": row["path_id"],
                    "step_id": row["step_id"],
                    "stage": "render",
                    "message": str(exc),
                }
            )
    tsv(
        args.output_dir / "errors.tsv",
        other_errors,
        list(dict.fromkeys(k for row in other_errors for k in row)) or None,
    )
    table = "".join(
        f'<tr class="{"multi" if r.get("more_than_two_centers") else "mixed"}"><td>{escape(r["path_id"])}</td><td>{escape(r["step_id"])}</td><td>{r["source_row"]}</td><td>{r.get("center_count", "")}</td><td>{escape(r["raw_code"])}</td><td>{r["mixed_classes"]}</td></tr>'
        for r in reactions
        if r.get("more_than_two_centers") or r["mixed_classes"]
    )
    (args.output_dir / "report.html").write_text(
        '<!doctype html><html><meta charset="utf-8"><title>ABSynth route readiness</title><style>body{font:16px sans-serif;margin:30px}table{border-collapse:collapse}td,th{padding:5px;border:1px solid #ddd}.multi{background:#ffe4cc}.mixed{background:#eee3ff}svg{max-width:100%;height:auto}</style><h1>ABSynth flagged reactions</h1><p>Orange: more than two CGR center components. Purple: multiple distinct NameRXN Tier-3 classes. Neither flag by itself proves a chemistry error. Source occurrence IDs distinguish repeated tree nodes.</p><p>Selected reaction-context drawings below use yellow halos on changed atoms. They are not extracted tactics or complete routes.</p><table><tr><th>PathId</th><th>StepId</th><th>Source row</th><th>Centers</th><th>NameRXN primary;auxiliary</th><th>Mixed classes</th></tr>'
        + table
        + "</table>"
        + "".join(figures)
        + "</html>"
    )
    examples = write_multicenter_report(
        args.output_dir,
        before_roots=getattr(args, "before_roots", roots),
        after_roots=roots,
        before_rows=getattr(args, "before_rows", reactions),
        after_rows=reactions,
        decisions=getattr(args, "split_decisions", ()),
        count=getattr(args, "visual_examples", 50),
        example_occurrences=getattr(args, "example_occurrences", None),
        show_cleaned_after=getattr(args, "show_cleaned_after", False),
    )
    summary = {
        "input_routes": len(roots),
        "reaction_nodes": len(reactions),
        "unique_source_occurrences": len({r["source_row"] for r in reactions}),
        "mapping_error_records": len(mapping_errors),
        "mapping_failed_routes": len({r["route_id"] for r in mapping_errors}),
        "library_default_failed_routes": len({r["route_id"] for r in library_errors}),
        "library_default_error_stages": dict(
            Counter(e["stage"] for e in library_errors)
        ),
        "center_count_distribution": dict(
            sorted(Counter(r.get("center_count", -1) for r in reactions).items())
        ),
        "multicenter_reaction_nodes": len(multicenter),
        "multicenter_source_occurrences": len({r["source_row"] for r in multicenter}),
        "multicenter_routes": len({r["path_id"] for r in multicenter}),
        "more_than_two_centers_reaction_nodes": len(flagged),
        "more_than_two_centers_source_occurrences": len(
            {r["source_row"] for r in flagged}
        ),
        "more_than_two_centers_routes": len({r["path_id"] for r in flagged}),
        "namerxn_unique_inputs": len(classified),
        "namerxn_status_by_reaction_node": dict(
            Counter(r["status"] for r in reactions)
        ),
        "namerxn_status_by_unique_input": dict(
            Counter(r["status"] for r in classified.values())
        ),
        "namerxn_mixed_reaction_nodes": len(mixed),
        "namerxn_mixed_source_occurrences": len({r["source_row"] for r in mixed}),
        "namerxn_mixed_routes": len({r["path_id"] for r in mixed}),
        "routes_with_different_classes_across_steps": sum(
            len(r["tier3_codes_across_steps"]) > 1 for r in routes
        ),
        "library_smoke_passed": sum(r["status"] == "passed" for r in smoke),
        "library_smoke_tested": len(smoke),
        "other_error_records": len(other_errors),
        "highlighted_reaction_examples": len(figures),
        "full_route_visual_examples": len(examples),
        "csv_rxn_name_fallback_nodes": sum(
            r["class_names_source"] == "csv_rxn_name" for r in reactions
        ),
        "input_modified": False,
    }
    assert record(args.routes_json) == fingerprint
    write_json(args.output_dir / "summary.json", summary)
    write_json(
        args.output_dir / "manifest.json",
        {
            "input": fingerprint,
            "runtime": runtime_provenance(),
            "script": record(Path(__file__).relative_to(Path.cwd())),
            "config": record(args.config),
            "namerxn_executable": record(args.namerxn_path),
            "visualization": {"box_solid": False},
            "policies": {
                "route_validation": "ABSynth stereo-only opt-in; all mapping/CGR checks enabled",
                "library_check": "unchanged production defaults",
                "centers": "Chython CGR.centers_list, strictly >2",
                "mixed_classes": "two or more distinct valid Tier-3 codes in a single primary;auxiliary output",
                "classification_input": "canonical unmapped route-consistent reaction, including donors; -nomap",
                "unknown_label": "not evidence of a homogeneous reaction",
                "source_ids": "PathId, StepId, source_row, exact node_path",
            },
            "summary": summary,
            "artifacts": [
                record(p)
                for p in sorted(args.output_dir.rglob("*"))
                if p.is_file() and p.name not in {"manifest.json", "run.log"}
            ],
        },
    )
    print(json.dumps(summary, indent=2), flush=True)


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--routes-json",
        type=Path,
        default=Path("data/tmp/absynth/raw/absynth_routes.json"),
    )
    parser.add_argument(
        "--output-dir", type=Path, default=Path("data/tmp/absynth/raw/analysis")
    )
    parser.add_argument("--namerxn-path", type=Path, required=True)
    parser.add_argument(
        "--preflight",
        action="store_true",
        help="Check the local licensed classifier on synthetic chemistry without analyzing a dataset.",
    )
    parser.add_argument(
        "--classification-baseline",
        type=Path,
        help="Verified prior analysis directory; reuse only exact classifier inputs and the same executable.",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("route_inspector/configs/rule_extraction_functional_groups.yaml"),
    )
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=1000)
    parser.add_argument("--visual-examples", type=int, default=50)
    return parser


def main():
    return run(build_parser().parse_args())


def run(args):
    if getattr(args, "preflight", False):
        print(json.dumps(classifier_preflight(args.namerxn_path), indent=2))
        return
    args.output_dir.mkdir(parents=True, exist_ok=True)
    fingerprint = record(args.routes_json)
    roots = json.loads(args.routes_json.read_text())
    scanned = scan(args, roots, fingerprint)
    restored = restore_supported_cx_inputs(scanned)
    write_json(
        args.output_dir / "cx_input_support.json",
        {
            "restored_from_conservative_preflight": restored,
            "policy": "intact optional CXSMILES extension, no radical annotations stripped",
        },
    )
    fallback = restore_serialization_only_inputs(scanned)
    write_json(args.output_dir / "classifier_input_fallbacks.json", fallback)
    reactions = [n for r in scanned for n in r["reactions"]]
    if args.classification_baseline:
        classified = reuse_classifications(args, reactions)
    else:
        classified = classify(args, reactions)
        class_names(args, classified)
    smoke = smoke_library(args, roots, scanned, fingerprint)
    report(args, roots, scanned, classified, smoke, fingerprint)


if __name__ == "__main__":
    main()
