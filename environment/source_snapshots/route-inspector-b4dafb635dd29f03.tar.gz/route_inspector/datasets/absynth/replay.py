"""Replay normalization failures using one internally consistent saved snapshot."""

from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from importlib.metadata import version
from pathlib import Path

from route_inspector.datasets.absynth import conversion as absynth
from route_inspector.infrastructure.artifacts import write_json
from route_inspector.infrastructure.text import write_tsv
from route_inspector.routes import normalization as routes
from route_inspector.routes.validation import validate_routes_mapping


def replay(baseline: Path, output: Path) -> dict:
    def table(name):
        with (baseline / name).open(newline="", encoding="utf-8") as stream:
            return list(csv.DictReader(stream, delimiter="\t"))

    errors = [
        r for r in table("route_errors.tsv") if r["stage"] == "route_normalization"
    ]
    path_ids = {r["path_id"] for r in errors}
    grouped = defaultdict(list)
    selections = {}
    for record in table("condition_resolution.tsv"):
        if record["path_id"] not in path_ids:
            continue
        if record["status"] != "resolved":
            raise ValueError("normalization baseline contains unresolved chemistry")
        source_row = int(record["source_row"])
        # Physical source IDs and source reactions come from the SAME old audit,
        # never from a subsequently edited CSV.
        row = absynth.SourceReaction(
            source_row,
            record["path_id"],
            "",
            "",
            "",
            "",
            record["step_id"],
            record["original_rxn_smiles"],
            "",
            record["conditions"],
        )
        grouped[row.path_id].append(row)
        selected = []
        for raw in json.loads(record["selected_donors"]):
            donor = dict(raw)
            copies = donor.pop("copies")
            donor["element_counts"] = tuple(
                sorted(absynth.molecule_heavy_atom_counts(donor["smiles"]).items())
            )
            selected.append((absynth.DonorCandidate(**donor), copies))
        selections[source_row] = absynth.DonorSelection(
            tuple(sorted(absynth.parse_deficit(record["deficit"]).items())),
            (),
            tuple(selected),
            record["enriched_rxn_smiles"],
            record["resolution_method"],
        )
    if set(grouped) != path_ids:
        raise ValueError("baseline donor audit does not cover failed routes")
    mapped = absynth._read_mapped_steps(baseline / "mapped_reactions.smi")
    recovered = []
    failures = []
    audit = []
    for index, (path_id, source) in enumerate(grouped.items(), 1):
        route = None
        try:
            route = absynth.build_route_tree(
                absynth.reconstruct_route_topology(source), selections, mapped
            )
            route = routes.normalize_route_tree(
                route,
                alignment_policy="stereo_preserving_witness",
                anchor_target_map_one=True,
                alignment_audit=audit,
            )
            stack = [route]
            while stack:
                node = stack.pop()
                stack.extend(node.get("children", []))
                if node["type"] == "reaction":
                    if not absynth.reaction_children_are_complete(node):
                        raise ValueError("reactant-child mapped stereo/state mismatch")
                    if (
                        node["metadata"]["smiles"]
                        != mapped[node["metadata"]["source_row"]]
                    ):
                        raise ValueError("step-local mapped reaction changed")
            absynth.annotate_stereo_only_steps(route)
            result = validate_routes_mapping(
                {path_id: route}, dataset="ABSynth", allow_stereo_only_reactions=True
            )
            if result.records:
                failures.extend(
                    absynth._validation_error_with_source(path_id, route, record)
                    for record in result.records
                )
            else:
                recovered.append(path_id)
        except Exception as exc:
            failures.append(
                absynth._validation_error_with_source(
                    path_id,
                    route or {},
                    {
                        "stage": "route_normalization",
                        "reaction_node_path": ".".join(
                            map(str, getattr(exc, "reaction_node_path", None) or ())
                        ),
                        "message": f"{type(exc).__name__}: {exc}",
                    },
                )
            )
        if index % 10 == 0:
            print(
                json.dumps({"checked": index, "recovered": len(recovered)}), flush=True
            )
    for row in audit:
        row["route_emitted"] = row["path_id"] in recovered
    audit.sort(
        key=lambda row: (
            int(row["source_row"]),
            tuple(int(i) for i in row["reaction_node_path"].split(".")),
        )
    )
    output.mkdir(parents=True, exist_ok=True)
    write_tsv(
        output / "route_normalization_audit.tsv",
        absynth.NORMALIZATION_AUDIT_FIELDS,
        audit,
    )
    write_tsv(output / "route_errors.tsv", absynth.ROUTE_ERROR_FIELDS, failures)
    summary = {
        "baseline_routes": len(path_ids),
        "recovered_routes": len(recovered),
        "failed_routes": len({r["path_id"] for r in failures}),
        "recovered_path_ids": recovered,
        "graphormer_rerun": False,
    }
    write_json(output / "summary.json", summary)
    artifacts = [
        baseline / "condition_resolution.tsv",
        baseline / "mapped_reactions.smi",
        baseline / "route_errors.tsv",
        output / "route_normalization_audit.tsv",
        output / "route_errors.tsv",
    ]
    write_json(
        output / "manifest.json",
        {
            "format": "route-inspector.absynth.normalization-replay.v1",
            "policy": "stereo_preserving_witness",
            "comparison_tool": "chython-synplan",
            "comparison_tool_version": version("chython-synplan"),
            "artifacts": [
                {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                for p in artifacts
            ],
            "summary": summary,
        },
    )
    return summary
