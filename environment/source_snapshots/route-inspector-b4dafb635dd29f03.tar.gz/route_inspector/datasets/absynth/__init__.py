"""ABSynth workflow implementations; reviewed records remain local."""
