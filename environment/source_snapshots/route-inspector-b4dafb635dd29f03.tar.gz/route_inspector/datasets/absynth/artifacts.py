"""Recoverable relocation of local snapshots, without changing route JSON bytes."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from route_inspector.infrastructure.artifacts import write_json
from route_inspector.infrastructure.hashing import sha256_file as _sha256_file


def sha256(path):
    return _sha256_file(Path(path))


def relocate_local_artifacts(*, directories, datasets, manifests, archive):
    """Copy active artifacts, move datasets, rebase hash links, archive originals.

    Arguments are explicit repository-relative paths. Historical implementation
    fingerprints stay historical: they are not replaced by current source hashes.
    Dataset bytes are never parsed or rewritten. Failure restores dataset names;
    copied working artifacts remain available for inspection and recovery.
    """
    directories = {Path(a): Path(b) for a, b in directories.items()}
    datasets = {Path(a): Path(b) for a, b in datasets.items()}
    archive = Path(archive)
    sources = {**directories, **datasets}
    for src, dst in sources.items():
        if (
            src.is_absolute()
            or dst.is_absolute()
            or ".." in src.parts
            or ".." in dst.parts
        ):
            raise ValueError(
                "relocation paths must be explicit repository-relative paths"
            )
        if not src.exists():
            raise FileNotFoundError(src)
        if dst.exists() and dst not in datasets:
            raise FileExistsError(dst)
        if src == dst or src in dst.parents or dst in src.parents:
            raise ValueError("source and destination must be disjoint")
    if archive.exists():
        raise FileExistsError(archive)
    originals = {p: sha256(p) for p in datasets}
    archive.mkdir(parents=True)
    moved, documents, active = [], {}, set()

    def destination(path):
        path = Path(path)
        if path in datasets:
            return datasets[path]
        for old, new in sorted(
            directories.items(), key=lambda x: len(x[0].parts), reverse=True
        ):
            if path == old or old in path.parents:
                return new / path.relative_to(old)
        return path

    def source_file(path):
        return datasets[path] if path in moved else path

    def historical(value):
        if isinstance(value, dict):
            return {
                ("original_path" if k == "path" else k): historical(v)
                for k, v in value.items()
            }
        if isinstance(value, list):
            return [historical(v) for v in value]
        return value

    def transform(value, *, code=False):
        if code:
            return {"historical_only": True, "recorded": historical(value)}
        if isinstance(value, dict):
            if isinstance(value.get("path"), str) and value.get("sha256"):
                old = Path(value["path"])
                current = source_file(old)
                if not current.is_file() or sha256(current) != value["sha256"]:
                    raise ValueError(f"stale artifact before relocation: {old}")
                new = destination(old)
                if new != old:
                    rebase(old)
                return {**value, "path": str(new), "sha256": sha256(new)}
            return {
                k: transform(
                    v,
                    code=k
                    in {
                        "implementation",
                        "script",
                        "verification_script",
                        "regression_tests",
                        "regression_fixtures",
                    },
                )
                for k, v in value.items()
            }
        if isinstance(value, list):
            return [transform(v) for v in value]
        if isinstance(value, str):
            for old, new in sorted(
                sources.items(), key=lambda x: len(str(x[0])), reverse=True
            ):
                if value == str(old) or value.startswith(str(old) + "/"):
                    return str(new) + value[len(str(old)) :]
        return value

    def rebase(old):
        old = Path(old)
        new = destination(old)
        if old in documents or new == old or old in datasets or old.suffix != ".json":
            return
        # Route trees, classification tables, and removed-subtree archives are
        # chemistry payloads, not relocation metadata. Preserve them bytewise.
        if "routes" in old.name or old.name in {
            "classifications.json",
            "multicenter_examples.json",
        }:
            return
        if old in active:
            raise ValueError(f"cyclic manifest dependency: {old}")
        active.add(old)
        data = json.loads(source_file(old).read_text())
        updated = transform(data)
        if updated != data:
            write_json(new, updated)
        documents[old] = {
            "old_path": str(old),
            "new_path": str(new),
            "old_sha256": sha256(source_file(old)),
            "new_sha256": sha256(new),
        }
        active.remove(old)

    try:
        for src, dst in directories.items():
            shutil.copytree(src, dst)
        # A final output may occupy an earlier dataset's name. Move that source
        # to its preserved intermediate location before promoting the final one.
        pending = dict(datasets)
        while pending:
            ready = [(a, b) for a, b in pending.items() if not b.exists()]
            if not ready:
                raise ValueError("dataset destination collision or relocation cycle")
            for src, dst in ready:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(src, dst)
                moved.append(src)
                del pending[src]
                if sha256(dst) != originals[src]:
                    raise ValueError(f"dataset changed during relocation: {src}")
        for path in manifests:
            rebase(path)
        report = {
            "operation": "local_artifact_relocation_only",
            "chemistry_recomputed": False,
            "datasets": [
                {"old_path": str(a), "new_path": str(b), "sha256": originals[a]}
                for a, b in datasets.items()
            ],
            "directories": [
                {
                    "old_path": str(a),
                    "new_path": str(b),
                    "historical_archive": str(archive / a),
                }
                for a, b in directories.items()
            ],
            "rebased_metadata": list(documents.values()),
            "historical_code_hashes": "retained as original_path records, not current implementation claims",
        }
        write_json(archive / "relocation.json", report)
    except Exception:
        for src in reversed(moved):
            shutil.move(datasets[src], src)
        raise
    for src in directories:
        target = archive / src
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(src, target)
    return report
