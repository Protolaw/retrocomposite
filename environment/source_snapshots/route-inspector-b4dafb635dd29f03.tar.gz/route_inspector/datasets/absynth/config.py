"""Locations and preflight checks for user-supplied ABSynth configuration.

No reviewed source records or occurrence identities belong in this module.
"""

from __future__ import annotations

import json
from pathlib import Path

LOCAL_CONFIG_DIR = Path("data/tmp/absynth/configs")
DEFAULT_SOURCE_SNAPSHOT = LOCAL_CONFIG_DIR / "absynth_source_snapshot.json"
DEFAULT_REPORT_PREFERENCES = LOCAL_CONFIG_DIR / "absynth_report_preferences.json"


def require_local_config(path: Path) -> Path:
    """Fail closed instead of silently omitting reviewed corrections."""
    if not path.is_file():
        raise FileNotFoundError(
            f"ABSynth local configuration is not bundled: {path}. "
            "Supply independently reviewed configuration for your permitted source; "
            "see docs/workflows/absynth_conversion.rst. "
            "Use an explicitly supplied header-only table for no overrides."
        )
    return path


def preferred_visual_steps(path: Path = DEFAULT_REPORT_PREFERENCES) -> tuple[str, ...]:
    """Optional local report priorities; absent preferences use round-robin only."""
    if not path.exists():
        return ()
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or value.get("version") != 1:
        raise ValueError("unsupported ABSynth report preferences")
    steps = value.get("preferred_step_ids")
    if not isinstance(steps, list) or any(
        not isinstance(step, str) or not step.strip() for step in steps
    ):
        raise ValueError("preferred_step_ids must be a list of nonempty strings")
    if len(set(steps)) != len(steps):
        raise ValueError("duplicate preferred_step_ids")
    return tuple(steps)
