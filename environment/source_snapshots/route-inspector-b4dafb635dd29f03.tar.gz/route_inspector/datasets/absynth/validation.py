"""Independently validate an ABSynth conversion before promoting its artifacts."""

from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
from pathlib import Path

from route_inspector import chemistry
from route_inspector.datasets.absynth import conversion as absynth
from route_inspector.infrastructure.artifacts import write_json
from route_inspector.routes.validation import (
    validate_raw_reaction_atom_mapping,
    validate_routes_mapping,
)


def _configure_validation_worker() -> None:
    import torch

    torch.set_num_threads(1)


def _validate_one_route(route: dict) -> list[dict]:
    result = validate_routes_mapping(
        {route["metadata"]["path_id"]: route},
        dataset="ABSynth",
        allow_stereo_only_reactions=True,
    )
    return result.records


def _molecule_has_explicit_unique_maps(smiles: str) -> bool:
    # This is a raw map-field preflight only. A molecule CXSMILES suffix must
    # not precede the synthetic reaction arrow: reaction CXSMILES has one
    # suffix after the entire reaction. Graph/state checks retain the suffix.
    core = smiles.split(" |", 1)[0]
    return not validate_raw_reaction_atom_mapping(core + ">>" + core)


def validate(
    manifest_path: Path,
    report_path: Path,
    *,
    workers: int = 8,
    incremental_only: bool = False,
) -> dict:
    if workers < 1:
        raise ValueError("workers must be positive")
    manifest = json.loads(manifest_path.read_text())
    summary = manifest["summary"]
    verified_files = []

    def check_hashes(value):
        if isinstance(value, dict):
            if value.get("path") and value.get("sha256"):
                path = Path(value["path"])
                actual = hashlib.sha256(path.read_bytes()).hexdigest()
                if actual != value["sha256"]:
                    raise ValueError(f"artifact hash mismatch: {path}")
                verified_files.append(str(path))
            for child in value.values():
                check_hashes(child)
        elif isinstance(value, list):
            for child in value:
                check_hashes(child)

    check_hashes(manifest)
    output_path = Path(summary["output"])
    assert (
        hashlib.sha256(output_path.read_bytes()).hexdigest()
        == manifest["output_sha256"]
    )
    output = json.loads(output_path.read_text())
    assert isinstance(output, list) and len(output) == summary["output_routes"]
    inherited = {}
    if incremental_only:
        reuse = manifest["incremental"]
        previous = json.loads(Path(reuse["baseline_output"]["path"]).read_text())
        acceptance = json.loads(Path(reuse["baseline_acceptance"]["path"]).read_text())
        assert acceptance["passed"] and not acceptance["validation_errors"]
        assert acceptance["output_sha256"] == reuse["baseline_output"]["sha256"]
        old_by_id = {r["metadata"]["path_id"]: r for r in previous}
        for route in output:
            pid = route["metadata"]["path_id"]
            if pid not in reuse["affected_path_ids"]:
                assert route == old_by_id[pid], f"unchanged route differs: {pid}"
                inherited[pid] = route
        assert set(inherited) == set(reuse["reused_path_ids"])
    source = absynth.load_absynth(Path(manifest["input"]["path"]))
    source_by_id = {row.source_row: row for row in source}
    source_by_path = defaultdict(set)
    for row in source:
        source_by_path[row.path_id].add(row.source_row)
    assert len(source) == summary["input_rows"]
    assert len(source_by_path) == summary["input_routes"]
    assert summary["input_routes"] == sum(
        summary[key]
        for key in (
            "excluded_routes",
            "topology_failed_routes",
            "condition_failed_routes",
            "mapping_failed_routes",
            "validation_failed_routes",
            "output_routes",
        )
    )
    mapped = absynth._read_mapped_steps(
        Path(manifest["mapping_snapshot"]["output"]["path"])
    )
    mapping_input = absynth._read_mapped_steps(
        Path(manifest["mapping_snapshot"]["input"]["path"])
    )
    assert len(mapped) == summary["mapped_rows"]
    assert len(mapping_input) == summary["mapping_input_rows"]
    assert set(mapped) <= set(mapping_input) <= source_by_id.keys()
    exclusions = set((manifest.get("route_exclusions") or {}).get("path_ids", []))
    assert len(exclusions) == summary["excluded_routes"]
    assert (
        sum(len(source_by_path[pid]) for pid in exclusions) == summary["excluded_rows"]
    )
    with (manifest_path.parent / "condition_resolution.tsv").open() as stream:
        conditions = {
            int(row["source_row"]): row
            for row in csv.DictReader(stream, delimiter="\t")
        }
    ids = [route["metadata"]["path_id"] for route in output]
    assert len(set(ids)) == len(ids) and not set(ids) & exclusions
    assert [min(source_by_path[pid]) for pid in ids] == sorted(
        min(source_by_path[pid]) for pid in ids
    )

    errors = []
    reaction_count = 0
    terminal_donors = 0
    for route in output:
        path_id = route["metadata"]["path_id"]
        chemically_check = path_id not in inherited
        if chemically_check:
            assert 1 in set(chemistry.parse_molecule(route["smiles"]))
        seen_rows = set()
        stack = [route]
        while stack:
            node = stack.pop()
            stack.extend(node.get("children", []))
            metadata = node["metadata"]
            if node["type"] == "reaction":
                reaction_count += 1
                source_row = int(metadata["source_row"])
                original = source_by_id[source_row]
                seen_rows.add(source_row)
                assert metadata["path_id"] == path_id == original.path_id
                assert metadata["step_id"] == original.step_id
                assert metadata["original_rxn_smiles"] == original.rxn_smiles
                assert metadata["smiles"] == mapped[source_row]
                assert metadata["enriched_rxn_smiles"] == mapping_input[source_row]
                assert conditions[source_row]["status"] == "resolved"
                if chemically_check:
                    assert absynth.reaction_children_are_complete(node)
                    assert absynth.mapped_reaction_has_complete_atom_sources(
                        node["smiles"]
                    )
            else:
                assert node["type"] == "mol"
                assert metadata["mapped_smiles"] == node["smiles"]
                if chemically_check:
                    assert _molecule_has_explicit_unique_maps(node["smiles"])
                assert metadata["original_smiles"]
                if metadata.get("role") in {
                    "condition_atom_donor",
                    "atom_balance_fallback",
                }:
                    terminal_donors += 1
                    assert node["in_stock"] is True and not node.get("children")
                    assert metadata["source_occurrence"] in source_by_path[path_id]
                    assert metadata["condition_evidenced"] == (
                        metadata["role"] == "condition_atom_donor"
                    )
        # Pruned synthetic branches remain verifiable source records, not live
        # route reactions. Do not count or certify their archived nodes as active.
        from route_inspector.routes.cleanup import archived_nodes

        for archived in archived_nodes(route):
            if archived.get("type") != "reaction":
                continue
            meta = archived["metadata"]
            sid = int(meta["source_row"])
            source_row = source_by_id[sid]
            assert meta["path_id"] == path_id == source_row.path_id
            assert meta["step_id"] == source_row.step_id
            assert meta["original_rxn_smiles"] == source_row.rxn_smiles
            assert meta["smiles"] == mapped[sid]
            assert meta["enriched_rxn_smiles"] == mapping_input[sid]
            seen_rows.add(sid)
        assert seen_rows == source_by_path[path_id]
    assert reaction_count == summary["output_reaction_occurrences"]

    def collect(results):
        for index, records in enumerate(results, 1):
            errors.extend(records)
            if index % 250 == 0:
                print(
                    json.dumps(
                        {"validated_routes": index, "validation_errors": len(errors)}
                    ),
                    flush=True,
                )

    to_validate = [r for r in output if r["metadata"]["path_id"] not in inherited]
    if workers == 1:
        collect(map(_validate_one_route, to_validate))
    else:
        with ProcessPoolExecutor(
            max_workers=workers,
            mp_context=get_context("spawn"),
            initializer=_configure_validation_worker,
        ) as executor:
            collect(executor.map(_validate_one_route, to_validate))
    report = {
        "passed": not errors,
        "validated_routes": len(to_validate),
        "verified_output_routes": len(output),
        "inherited_validated_routes": len(inherited),
        "acceptance_mode": "incremental_identity_verified"
        if incremental_only
        else "full",
        "validated_reaction_occurrences": reaction_count,
        "terminal_donor_nodes": terminal_donors,
        "validation_errors": errors,
        "verified_artifact_paths": sorted(set(verified_files)),
        "output_sha256": manifest["output_sha256"],
        "mapping_snapshot_reused": manifest["mapping_snapshot"]["reused"],
        "count_invariants_passed": True,
    }
    write_json(report_path, report)
    return report
