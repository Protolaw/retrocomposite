#!/usr/bin/env python3
"""Convert ABSynth TSV reactions into strict route-consistent JSON trees."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from route_inspector.datasets.absynth.config import (
    LOCAL_CONFIG_DIR,
    require_local_config,
)
from route_inspector.datasets.absynth.conversion import convert_absynth
from route_inspector.datasets.absynth.runtime import (
    mapping_preflight,
    verify_reviewed_bundle,
)
from route_inspector.datasets.absynth.validation import validate
from route_inspector.datasets.absynth.workflow import (
    DEFAULT_SOURCE_SNAPSHOT,
    verify_source_snapshot,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input",
        type=Path,
        default=Path("data/literature/ABSynth_Dataset.csv"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("data/tmp/absynth/raw/absynth_routes.json"),
    )
    parser.add_argument(
        "--work-dir",
        type=Path,
        default=Path("data/tmp/absynth/raw"),
    )
    parser.add_argument(
        "--condition-registry",
        type=Path,
        default=LOCAL_CONFIG_DIR / "absynth_condition_donors.tsv",
    )
    parser.add_argument(
        "--condition-overrides",
        type=Path,
        default=LOCAL_CONFIG_DIR / "absynth_condition_overrides.tsv",
    )
    parser.add_argument(
        "--reaction-overrides",
        type=Path,
        default=LOCAL_CONFIG_DIR / "absynth_reaction_donor_overrides.tsv",
    )
    parser.add_argument(
        "--oxygen-water-fallback", action=argparse.BooleanOptionalAction, default=True
    )
    parser.add_argument("--source-snapshot", type=Path, default=DEFAULT_SOURCE_SNAPSHOT)
    parser.add_argument(
        "--bundle-manifest",
        type=Path,
        help="Historical manifest binding the reviewed CSV, four correction tables and frozen cache by SHA-256.",
    )
    parser.add_argument(
        "--preflight",
        action="store_true",
        help="Verify inputs and mapper dependencies without converting or writing routes.",
    )
    parser.add_argument(
        "--normalization-baseline",
        type=Path,
        help="Prior route_errors.tsv used only to audit normalization recovery counts.",
    )
    parser.add_argument(
        "--route-exclusions",
        type=Path,
        default=LOCAL_CONFIG_DIR / "absynth_route_exclusions.tsv",
        help="Versioned temporary PathId exclusions; source rows stay in the CSV.",
    )
    parser.add_argument(
        "--pubchem-cache",
        type=Path,
        help="Default: --work-dir/pubchem_cache.jsonl.",
    )
    parser.add_argument("--no-pubchem", action="store_true")
    parser.add_argument("--device", choices=("cuda", "cpu", "mps"), default="cuda")
    parser.add_argument(
        "--no-amp",
        action="store_true",
        help="Disable mixed precision; CPU always uses float32.",
    )
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--chunk-size", type=int, default=5000)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--worker-timeout", type=int, default=120)
    parser.add_argument("--reuse-mapped", action="store_true")
    parser.add_argument(
        "--incremental-baseline",
        type=Path,
        help="Immutable prior conversion directory; remap/rebuild changed routes only.",
    )
    parser.add_argument(
        "--baseline-output",
        type=Path,
        help="Backed-up JSON associated with --incremental-baseline.",
    )
    parser.add_argument(
        "--skip-route-cgr-validation",
        action="store_true",
        help="Development-only: skip RouteCGR/SB-CGR validation.",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    snapshot = verify_source_snapshot(args.input, args.source_snapshot)
    for path in (
        args.condition_registry,
        args.condition_overrides,
        args.reaction_overrides,
        args.route_exclusions,
    ):
        require_local_config(path)
    args.pubchem_cache = args.pubchem_cache or args.work_dir / "pubchem_cache.jsonl"
    bundle = None
    if args.bundle_manifest:
        if not args.no_pubchem:
            raise ValueError("A frozen reviewed bundle requires --no-pubchem")
        bundle = verify_reviewed_bundle(
            args.bundle_manifest,
            {
                "input": args.input,
                "condition_registry": args.condition_registry,
                "condition_overrides": args.condition_overrides,
                "reaction_overrides": args.reaction_overrides,
                "route_exclusions": args.route_exclusions,
                "pubchem_cache": args.pubchem_cache,
            },
        )
    if args.preflight:
        print(
            json.dumps(
                {
                    **mapping_preflight(args.device, args.no_amp),
                    "source_snapshot": snapshot,
                    "reviewed_bundle": bundle,
                },
                indent=2,
            )
        )
        return 0
    if args.output.exists() or args.output.resolve() == args.input.resolve():
        raise FileExistsError("preserve the existing snapshot; choose a new output")
    if (
        not args.reuse_mapped
        and args.work_dir.exists()
        and any(
            p.name != "pubchem_cache.jsonl" and p.suffix != ".log"
            for p in args.work_dir.iterdir()
        )
    ):
        raise FileExistsError("use a fresh conversion work directory")
    args.pubchem_cache = args.pubchem_cache or args.work_dir / "pubchem_cache.jsonl"
    summary = convert_absynth(
        input_path=args.input,
        output_path=args.output,
        work_dir=args.work_dir,
        condition_registry_path=args.condition_registry,
        condition_overrides_path=args.condition_overrides,
        reaction_overrides_path=args.reaction_overrides,
        route_exclusions_path=args.route_exclusions,
        normalization_baseline_path=args.normalization_baseline,
        oxygen_water_fallback=args.oxygen_water_fallback,
        pubchem_cache_path=args.pubchem_cache,
        use_pubchem=not args.no_pubchem,
        device=args.device,
        no_amp=args.no_amp,
        bundle_manifest_path=args.bundle_manifest,
        batch_size=args.batch_size,
        chunk_size=args.chunk_size,
        workers=args.workers,
        worker_timeout=args.worker_timeout,
        reuse_mapped=args.reuse_mapped,
        validate_route_cgr=not args.skip_route_cgr_validation,
        incremental_baseline_dir=args.incremental_baseline,
        incremental_baseline_output=args.baseline_output,
    )
    print(json.dumps(summary, indent=2, sort_keys=True))
    acceptance = validate(
        args.work_dir / "manifest.json",
        args.work_dir / "acceptance.json",
        workers=args.workers,
    )
    if not acceptance["passed"]:
        raise ValueError("conversion acceptance failed; see acceptance.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
