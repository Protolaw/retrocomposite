"""Source-record provenance adapters for route reaction nodes.

The route corpora handled by Route Inspector do not share one source identifier
schema.  This module keeps the raw identifier lossless and makes parsing an
explicit, versioned adapter decision rather than embedding PaRoutes assumptions in
the occurrence/index code."""

from __future__ import annotations

from typing import Any, Mapping

from route_inspector.datasets.paroutes.source_ids import (
    PAROUTES_SOURCE_ID_ADAPTER,
    PaRoutesSourceIdAdapter,
)
from route_inspector.routes.provenance import (
    RAW_SOURCE_ID_ADAPTER,
    RawMetadataSourceIdAdapter,
    SourceIdAdapter,
    SourceIdentifiers,
)

SOURCE_ID_ADAPTER_CHOICES = (
    PAROUTES_SOURCE_ID_ADAPTER,
    RAW_SOURCE_ID_ADAPTER,
)


def source_id_adapter_from_name(name: str | None) -> SourceIdAdapter:
    """Resolve a persisted adapter name without silently guessing a corpus.

    ``None`` retains Route Inspector's historical PaRoutes default.  Callers
    handling another corpus must select ``raw`` explicitly so semicolon-bearing
    opaque record IDs are not interpreted as patent/document components.
    """

    normalized = str(name or PAROUTES_SOURCE_ID_ADAPTER).strip().lower()
    if normalized == PAROUTES_SOURCE_ID_ADAPTER:
        return PaRoutesSourceIdAdapter()
    if normalized == RAW_SOURCE_ID_ADAPTER:
        return RawMetadataSourceIdAdapter()
    raise ValueError(
        f"unsupported source-ID adapter {name!r}; expected one of "
        f"{', '.join(SOURCE_ID_ADAPTER_CHOICES)}"
    )


def reaction_source_identifiers(
    reaction_node: Mapping[str, Any],
    *,
    adapter: SourceIdAdapter | str | None = None,
) -> SourceIdentifiers:
    """Extract source identifiers from a reaction node without mutating it."""

    metadata = reaction_node.get("metadata")
    if not isinstance(metadata, Mapping):
        metadata = {}
    resolved = (
        source_id_adapter_from_name(adapter)
        if isinstance(adapter, str) or adapter is None
        else adapter
    )
    return resolved.parse(metadata)
