"""Workspace dataset bindings and atomic activation of verified revisions."""

import json
import os
import tempfile
from pathlib import Path

DATASETS = ("n1", "n5", "absynth", "n1+n5")


def activate_library_revision(workspace: Path, dataset: str, revision: Path) -> None:
    """Switch all GUI inputs together, only after a verified update publication."""
    from route_inspector.infrastructure.hashing import sha256_file

    workspace, revision = Path(workspace).resolve(), Path(revision).resolve()
    aliases = corpus_ids(dataset)
    relative = revision.relative_to(workspace)
    report = json.loads((revision / "update.json").read_text())
    if set(report.get("libraries", {})) != {"reference", "pg", "composites"}:
        raise ValueError("GUI activation requires a complete library revision")
    if sha256_file(revision / "routes.json") != report["source_sha256"]:
        raise ValueError("updated source fingerprint differs from the update audit")
    for name in ("reference", "pg", "composites"):
        manifest_path = revision / name / "manifest.json"
        if sha256_file(manifest_path) != report["libraries"][name]["manifest_sha256"]:
            raise ValueError("updated library differs from the update audit")
        manifest = json.loads(manifest_path.read_text())
        if name != "composites" and any(
            c["dataset_id"] not in aliases for c in manifest["reference_corpora"]
        ):
            raise ValueError("library revision belongs to another GUI dataset")
    config = workspace / "outputs/gui/datasets.json"
    config.parent.mkdir(parents=True, exist_ok=True)
    # Validate existing bindings and preserve other datasets verbatim.
    for known in DATASETS:
        dataset_bindings(workspace, known)
    value = (
        json.loads(config.read_text())
        if config.exists()
        else {"schema_version": 1, "datasets": {}}
    )
    value["datasets"][dataset] = {
        "source": (relative / "routes.json").as_posix(),
        **{
            name: (relative / name).as_posix()
            for name in ("reference", "pg", "composites")
        },
    }
    fd, temporary = tempfile.mkstemp(
        prefix=".datasets-", suffix=".json", dir=config.parent
    )
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, config)
    finally:
        Path(temporary).unlink(missing_ok=True)


def corpus_ids(dataset: str) -> tuple[str, ...]:
    """Only PaRoutes has prefixed aliases; ABSynth requires its exact corpus ID."""
    if dataset not in DATASETS:
        raise ValueError("choose n1, n5, absynth or n1+n5")
    return (dataset,) if dataset == "absynth" else (dataset, f"paroutes-{dataset}")


def dataset_bindings(workspace: Path, dataset: str) -> dict[str, Path]:
    """Select an explicit local publication without relocating historical inputs."""
    corpus_ids(dataset)
    paths = {
        "source": f"data/clean/{dataset}_routes.json",
        "reference": f"outputs/reference_libraries/{dataset}",
        "pg": f"outputs/pg_libraries/{dataset}",
        "composites": f"outputs/composite_libraries/{dataset}",
    }
    annotated = f"outputs/composite_libraries/{dataset}-ring-breaking"
    if (workspace / annotated / "manifest.json").is_file():
        paths["composites"] = annotated
    config = workspace / "outputs/gui/datasets.json"
    if config.is_file():
        value = json.loads(config.read_text())
        if (
            not isinstance(value, dict)
            or value.get("schema_version") != 1
            or not isinstance(value.get("datasets"), dict)
            or set(value["datasets"]) - set(DATASETS)
        ):
            raise ValueError(
                "Invalid GUI dataset bindings in outputs/gui/datasets.json"
            )
        override = value["datasets"].get(dataset)
        if override is not None:
            if not isinstance(override, dict) or set(override) != set(paths):
                raise ValueError(
                    "Dataset bindings require source, reference, pg and composites"
                )
            for key, path in override.items():
                if (
                    not isinstance(path, str)
                    or not path.strip()
                    or Path(path).is_absolute()
                    or ".." in Path(path).parts
                ):
                    raise ValueError("Dataset binding paths must be workspace-relative")
                paths[key] = path
    return {key: workspace / path for key, path in paths.items()}
