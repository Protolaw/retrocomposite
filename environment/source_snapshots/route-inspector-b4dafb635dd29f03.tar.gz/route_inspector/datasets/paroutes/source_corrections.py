"""Explicit, guarded source-record corrections applied before normalization.

These are curated data repairs, never general chemistry inference. The original
record and removed route evidence remain attached to the corrected route.
"""

from copy import deepcopy
from dataclasses import dataclass
from hashlib import sha256

from route_inspector import chemistry
from route_inspector.routes.access import reaction_nodes, reaction_smiles_from_node

CORRECTION_ID = "paroutes-us20100125072a1-0847-formaldehyde-v1"
SOURCE_RECORD_ID = "US20100125072A1;0847;882057"
REMOVED_RECORD_ID = "US20100125072A1;0697;881939"
RECORDED_REACTION_SHA256 = (
    "8c668940142b278cd26501891a9b7c947866bf5eae12782d6cbe3c204a7d8fd8"
)
REMOVED_REACTION_SHA256 = (
    "55c21e6c0e943f8809d347e880342aad9e04e6f2ea6b2b2d7b5be0b23bd194b4"
)
FORMALDEHYDE = "[CH2:10]=[O:11]"
PHOSPHONIUM_CORRECTION_ID = "paroutes-us20120329732a1-0234-phosphonium-v1"
PHOSPHONIUM_SOURCE_RECORD_ID = "US20120329732A1;0234;1315477"
PHOSPHONIUM_REACTION_SHA256 = (
    "94b450e5979f5447dc2270c99f2ae9882ad9f7a03f1dd0ed32f747132b78a674"
)
METHYLTRIPHENYLPHOSPHONIUM = (
    "[cH:28]1[cH:29][c:30]([cH:44][cH:45][cH:27]1)[P+:31]"
    "([c:32]2[cH:33][cH:34][cH:35][cH:36][cH:37]2)"
    "([c:38]3[cH:43][cH:42][cH:41][cH:40][cH:39]3)[CH3:1]"
)
DIBORON_CORRECTION_ID = "paroutes-us20120207767a1-0524-direct-diboron-v1"
DIBORON_SOURCE_RECORD_ID = "US20120207767A1;0524;1254610"
DIBORON_REACTION_SHA256 = (
    "19f9e6eb6c79b935afb5bf3766a5b28b48aa37699e3eebf71bb489c66e183a28"
)
DIBORON_REMOVED_RECORD_ID = "US20120207767A1;0486;1254591"
DIBORON_REMOVED_REACTION_SHA256 = (
    "6eb746b17c72681cb6e8c08844a6daada002d37a876fb85befcfdd963650d4b6"
)
BIS_PINACOLATO_DIBORON = (
    "[CH3:32][C:33]1([CH3:34])[C:38]([CH3:40])([CH3:39])[O:37][B:36]"
    "([O:35]1)[B:8]2[O:16][C:13]([CH3:14])([CH3:15])"
    "[C:10]([CH3:11])([CH3:12])[O:9]2"
)
THP_MAPPING_SOURCE_RECORD_ID = "US20060035920A1;0369;326666"
THP_MAPPING_CORRECTION_ID = "paroutes-us20060035920a1-0369-thp-atom-mapping-v1"
THP_MAPPING_REACTION_SHA256 = (
    "bcd22631e042b07a60c550d9d9a2c6f09cf3320aee23235f18ad4bdb467c1055"
)


def correct_source_route(route):
    """Apply guarded, idempotent corrections without changing the input tree."""
    return _correct_thp_mapping(
        _correct_diboron_source(
            _correct_stock_donors(
                _correct_phosphonium_source(_correct_formaldehyde_source(route))
            )
        )
    )


def _correct_thp_mapping(route):
    """Reflect the DHP ring's recorded maps so N adds to its enol-ether carbon."""
    corrected = route
    for path, node in reaction_nodes(route):
        metadata = node.get("metadata", {})
        if metadata.get("ID") != THP_MAPPING_SOURCE_RECORD_ID:
            continue
        if metadata.get("source_correction_id") == THP_MAPPING_CORRECTION_ID:
            continue
        recorded = metadata.get("smiles", "")
        if (
            "route_preprocessing_split" in metadata
            or sha256(recorded.encode()).hexdigest() != THP_MAPPING_REACTION_SHA256
        ):
            raise ValueError(
                "Known source correction THP recorded reaction has changed"
            )
        reaction = chemistry.parse_reaction(recorded)
        parent = _node_at_path(route, path[:-1])
        if not chemistry.molecules_equivalent(
            chemistry.parse_molecule(parent["smiles"]), reaction.products[0]
        ):
            raise ValueError("Known source correction THP target guard failed")
        children = node.get("children", [])
        if len(children) != 2 or any(c.get("type") != "mol" for c in children):
            raise ValueError("Known source correction THP precursor count guard failed")
        matched_children = []
        for molecule in reaction.reactants:
            matches = [
                child
                for child in children
                if chemistry.molecules_equivalent(
                    chemistry.parse_molecule(child["smiles"]), molecule
                )
            ]
            if len(matches) != 1:
                raise ValueError("Known source correction THP precursor guard failed")
            matched_children.append(matches[0])
        donor_child = matched_children[0]
        if donor_child.get("children") or donor_child.get("in_stock") is not True:
            raise ValueError(
                "Known source correction THP requires a terminal stock donor"
            )
        working = chemistry.parse_reaction(reaction_smiles_from_node(node))
        for old_side, working_side in (
            (reaction.reactants, working.reactants),
            (reaction.products, working.products),
        ):
            if len(old_side) != len(working_side) or any(
                sum(chemistry.molecules_equivalent(m, w) for w in working_side) != 1
                for m in old_side
            ):
                raise ValueError(
                    "Known source correction THP working reaction has changed"
                )
        # Keep the product and every ring bond endpoint. Reversing the carbon
        # correspondence makes the existing product N16--C17 bond an addition
        # across reactant C17=C18 next to O22, instead of substitution at CH2.
        permutation = {17: 21, 18: 20, 19: 19, 20: 18, 21: 17, 22: 22}
        donor = reaction.reactants[0].copy()
        donor.remap(permutation)
        corrected_smiles = (
            ".".join(format(m, "m") for m in (donor, reaction.reactants[1]))
            + ">>"
            + format(reaction.products[0], "m")
        )
        if corrected is route:
            corrected = deepcopy(route)
        repaired = _node_at_path(corrected, path)
        corrected.setdefault("metadata", {}).setdefault(
            "source_corrections", []
        ).append(
            {
                "correction_id": THP_MAPPING_CORRECTION_ID,
                "source_record_id": THP_MAPPING_SOURCE_RECORD_ID,
                "reaction_node_path": list(path),
                "basis": "user-curated DHP correspondence: N adds at the sp2 carbon adjacent to oxygen",
                "original_reaction_smiles": reaction_smiles_from_node(node),
                "original_reaction_metadata": deepcopy(metadata),
                "reactant_atom_map_permutation": {
                    str(k): v for k, v in permutation.items()
                },
                "corrected_reaction_smiles": corrected_smiles,
                "removed_reaction_count": 0,
                "reactant_structures_unchanged": True,
                "target_unchanged": True,
            }
        )
        repaired["smiles"] = corrected_smiles
        repaired["metadata"]["smiles"] = corrected_smiles
        old_rsmi = metadata.get("rsmi", "").split(">")
        reagents = old_rsmi[1] if len(old_rsmi) == 3 else ""
        repaired["metadata"]["rsmi"] = corrected_smiles.replace(">>", f">{reagents}>")
        repaired["metadata"].pop("reaction_hash", None)
        repaired["metadata"]["source_correction_id"] = THP_MAPPING_CORRECTION_ID
    return corrected


def _correct_diboron_source(route):
    """Connect recorded stock B2pin2 directly to r1 in n1 route 3989."""
    if any(
        row.get("correction_id") == DIBORON_CORRECTION_ID
        for row in route.get("metadata", {}).get("source_corrections", [])
    ):
        return route
    roots = route.get("children", [])
    matches = [
        n
        for n in roots
        if n.get("type") == "reaction"
        and n.get("metadata", {}).get("ID") == DIBORON_SOURCE_RECORD_ID
    ]
    if not matches:
        return route
    if len(roots) != 1 or len(matches) != 1:
        raise ValueError("Known source correction requires one root reaction")
    node = matches[0]
    metadata = node.get("metadata", {})
    recorded = metadata.get("smiles", "")
    if (
        "route_preprocessing_split" in metadata
        or sha256(recorded.encode()).hexdigest() != DIBORON_REACTION_SHA256
    ):
        raise ValueError("Known source correction diboron root record has changed")
    reaction = chemistry.parse_reaction(recorded)
    donor, substrate = reaction.reactants
    if not chemistry.molecules_equivalent(
        chemistry.parse_molecule(route["smiles"]), reaction.products[0]
    ):
        raise ValueError("Known source correction target guard failed")
    children = node.get("children", [])
    if len(children) != 2 or any(c.get("type") != "mol" for c in children):
        raise ValueError("Known source correction requires two original precursors")
    child_matches = [
        [
            i
            for i, child in enumerate(children)
            if chemistry.molecules_equivalent(
                chemistry.parse_molecule(child["smiles"]), molecule
            )
        ]
        for molecule in (donor, substrate)
    ]
    if (
        any(len(indices) != 1 for indices in child_matches)
        or child_matches[0] == child_matches[1]
    ):
        raise ValueError("Known source correction precursor guard failed")
    donor_index = child_matches[0][0]
    removed = children[donor_index]
    branch = removed.get("children", [])
    if len(branch) != 1 or branch[0].get("type") != "reaction":
        raise ValueError("Known source correction removed-branch guard failed")
    removed_metadata = branch[0].get("metadata", {})
    if (
        removed_metadata.get("ID") != DIBORON_REMOVED_RECORD_ID
        or "route_preprocessing_split" in removed_metadata
        or sha256(removed_metadata.get("smiles", "").encode()).hexdigest()
        != DIBORON_REMOVED_REACTION_SHA256
    ):
        raise ValueError("Known source correction removed diboron reaction has changed")
    branch_reaction = chemistry.parse_reaction(removed_metadata["smiles"])
    leaves = branch[0].get("children", [])
    if len(leaves) != 2 or any(
        leaf.get("type") != "mol"
        or leaf.get("children")
        or leaf.get("in_stock") is not True
        for leaf in leaves
    ):
        raise ValueError("Known source correction requires two terminal stock leaves")
    leaf_matches = [
        [
            i
            for i, leaf in enumerate(leaves)
            if chemistry.molecules_equivalent(
                chemistry.parse_molecule(leaf["smiles"]), molecule
            )
        ]
        for molecule in branch_reaction.reactants
    ]
    if (
        any(len(indices) != 1 for indices in leaf_matches)
        or leaf_matches[0] == leaf_matches[1]
    ):
        raise ValueError(
            "Known source correction removed-branch precursor guard failed"
        )
    stock_leaf = leaves[leaf_matches[0][0]]
    replacement = chemistry.parse_molecule(BIS_PINACOLATO_DIBORON).copy()
    if not chemistry.molecules_equivalent(
        replacement, chemistry.parse_molecule(stock_leaf["smiles"])
    ):
        raise ValueError("Known source correction recorded diboron stock guard failed")
    retained = set(range(8, 17))
    used = {n for mol in reaction.reactants + reaction.products for n in mol}
    replacement.remap(
        {
            old: fresh
            for fresh, old in enumerate(
                sorted(set(replacement) - retained), max(used) + 1
            )
        }
    )
    replacement_smiles = format(replacement, "m")
    corrected_smiles = (
        f"{replacement_smiles}.{format(substrate, 'm')}"
        f">>{format(reaction.products[0], 'm')}"
    )
    corrected = deepcopy(route)
    repaired = corrected["children"][0]
    corrected.setdefault("metadata", {}).setdefault("source_corrections", []).append(
        {
            "correction_id": DIBORON_CORRECTION_ID,
            "source_record_id": DIBORON_SOURCE_RECORD_ID,
            "basis": "user-curated direct diboron stock input; remove spurious donor synthesis",
            "original_reaction_smiles": reaction_smiles_from_node(node),
            "original_reaction_metadata": deepcopy(metadata),
            "removed_precursor_subtree": deepcopy(removed),
            "removed_reaction_count": 1,
            "removed_source_record_id": DIBORON_REMOVED_RECORD_ID,
            "recorded_stock_precursor": deepcopy(stock_leaf),
            "replacement_precursor_smiles": replacement_smiles,
            "retained_atom_maps": sorted(retained),
            "corrected_reaction_smiles": corrected_smiles,
            "target_unchanged": True,
        }
    )
    repaired["smiles"] = corrected_smiles
    repaired["metadata"]["smiles"] = corrected_smiles
    old_rsmi = metadata.get("rsmi", "").split(">")
    reagents = old_rsmi[1] if len(old_rsmi) == 3 else ""
    repaired["metadata"]["rsmi"] = corrected_smiles.replace(">>", f">{reagents}>")
    repaired["metadata"].pop("reaction_hash", None)
    repaired["metadata"]["source_correction_id"] = DIBORON_CORRECTION_ID
    repaired["children"][donor_index] = {
        "type": "mol",
        "smiles": replacement_smiles,
        "in_stock": True,
        "children": [],
        "metadata": {
            "source_correction_id": DIBORON_CORRECTION_ID,
            "stock_basis": "terminal in-stock precursor retained from the removed source branch",
        },
    }
    return corrected


def _correct_formaldehyde_source(route):
    """Repair the known erroneous formaldehyde donor; leave other routes alone.

    Match the source record and its exact recorded reaction, not route number
    4870 (which is specific to the n1 collection). Unexpected revisions fail
    closed. A corrected route is idempotent, including after normalization.
    """
    corrections = route.get("metadata", {}).get("source_corrections", [])
    if any(row.get("correction_id") == CORRECTION_ID for row in corrections):
        return route
    root_reactions = route.get("children", [])
    matching = [
        node
        for node in root_reactions
        if node.get("type") == "reaction"
        and node.get("metadata", {}).get("ID") == SOURCE_RECORD_ID
    ]
    if not matching:
        return route
    if len(root_reactions) != 1 or len(matching) != 1:
        raise ValueError("Known source correction requires one root reaction")
    reaction = matching[0]
    original_metadata = reaction.get("metadata", {})
    recorded = original_metadata.get("smiles", "")
    if (
        "route_preprocessing_split" in original_metadata
        or sha256(recorded.encode()).hexdigest() != RECORDED_REACTION_SHA256
    ):
        raise ValueError(
            "Known source correction requires the original unsplit source record "
            f"{SOURCE_RECORD_ID}; its recorded reaction has changed"
        )
    reactants, product = recorded.split(">>")
    donor, substrate = reactants.split(".")
    children = reaction.get("children", [])
    if len(children) != 2 or any(c.get("type") != "mol" for c in children):
        raise ValueError("Known source correction requires its two original precursors")
    for node, expected in zip([route, *children], [product, donor, substrate]):
        if not chemistry.molecules_equivalent(
            chemistry.parse_molecule(node["smiles"]),
            chemistry.parse_molecule(expected),
        ):
            raise ValueError("Known source correction precursor/target guard failed")
    removed_branch = children[0].get("children", [])
    if len(removed_branch) != 1 or removed_branch[0].get("type") != "reaction":
        raise ValueError("Known source correction removed-branch guard failed")
    removed_reaction = removed_branch[0]
    removed_metadata = removed_reaction.get("metadata", {})
    removed_recorded = removed_metadata.get("smiles", "")
    if (
        removed_metadata.get("ID") != REMOVED_RECORD_ID
        or "route_preprocessing_split" in removed_metadata
        or sha256(removed_recorded.encode()).hexdigest() != REMOVED_REACTION_SHA256
    ):
        raise ValueError("Known source correction removed reaction has changed")
    # A normalized node can use different atom numbers, but its working reaction
    # must still describe the audited chemistry, not just retain old metadata.
    if chemistry.canonical_unmapped_reaction_string(
        reaction_smiles_from_node(removed_reaction)
    ) != chemistry.canonical_unmapped_reaction_string(removed_recorded):
        raise ValueError("Known source correction removed working reaction has changed")
    branch_reaction = chemistry.parse_reaction(removed_recorded)
    leaves = removed_reaction.get("children", [])
    if len(branch_reaction.products) != 1 or not chemistry.molecules_equivalent(
        chemistry.parse_molecule(children[0]["smiles"]), branch_reaction.products[0]
    ):
        raise ValueError("Known source correction removed-branch product guard failed")
    if (
        len(branch_reaction.reactants) != 1
        or len(leaves) != 1
        or leaves[0].get("type") != "mol"
        or leaves[0].get("children")
        or leaves[0].get("in_stock") is not True
        or not chemistry.molecules_equivalent(
            chemistry.parse_molecule(leaves[0]["smiles"]), branch_reaction.reactants[0]
        )
    ):
        raise ValueError(
            "Known source correction removed-branch precursor guard failed"
        )

    corrected = deepcopy(route)
    node = corrected["children"][0]
    replacement = f"{FORMALDEHYDE}.{substrate}>>{product}"
    evidence = {
        "correction_id": CORRECTION_ID,
        "source_record_id": SOURCE_RECORD_ID,
        "basis": "user-curated source correction; formaldehyde explicitly confirmed",
        "original_reaction_smiles": reaction_smiles_from_node(reaction),
        "original_reaction_metadata": deepcopy(original_metadata),
        "removed_precursor_subtree": deepcopy(children[0]),
        "removed_reaction_count": 1,
        "replacement_precursor_smiles": FORMALDEHYDE,
        "corrected_reaction_smiles": replacement,
        "target_unchanged": True,
    }
    corrected.setdefault("metadata", {}).setdefault("source_corrections", []).append(
        evidence
    )
    node["smiles"] = replacement
    node["metadata"].update(smiles=replacement, rsmi=replacement)
    # The source hash describes the erroneous reaction; retain it only in evidence.
    node["metadata"].pop("reaction_hash", None)
    node["metadata"]["source_correction_id"] = CORRECTION_ID
    node["children"][0] = {
        "type": "mol",
        "smiles": FORMALDEHYDE,
        "in_stock": True,
        "children": [],
        "metadata": {
            "source_correction_id": CORRECTION_ID,
            "stock_basis": "curated terminal precursor; stock membership not inferred",
        },
    }
    return corrected


@dataclass(frozen=True)
class DonorReplacement:
    original_donor: str
    replacement: str
    retained_maps: tuple[int, ...]
    restored_product_maps: tuple[int, ...] = ()


@dataclass(frozen=True)
class StockDonorCorrection:
    source_record_id: str
    reaction_sha256: str
    name: str
    original_donor: str
    replacement: str
    retained_maps: tuple[int, ...]
    restored_product_maps: tuple[int, ...] = ()
    additional_donors: tuple[DonorReplacement, ...] = ()
    removed_branch: tuple[str, str] | None = None

    @property
    def correction_id(self):
        record = self.source_record_id.split(";")[0].lower()
        return f"paroutes-{record}-{self.name}-v1"


# Maps here belong to the recorded, step-local reaction, not the clean route.
# Replacement atoms outside retained_maps/restored_product_maps receive fresh IDs.
# Restored product maps are allowed only when absent from every recorded reactant.
STOCK_DONOR_CORRECTIONS = (
    StockDonorCorrection(
        "US20090054454A1;0278;672712",
        "64e903de743c467891d8775793f3ab9f7b6004e963c09486eb071128d4d1fd99",
        "ethanol",
        "Cc1ccccc1",
        "[CH3:1][CH2:2][OH:1000]",
        (1, 2),
    ),
    StockDonorCorrection(
        "US06384041B1;;554221",
        "5325c0d7d8406bde978bbf8b4cca12e04eda710ccb54b24d4bb9aad93977ab8c",
        "ammonia",
        "c1ccncc1",
        "[NH3:8]",
        (8,),
    ),
    StockDonorCorrection(
        "US20120283216A1;0263;1295682",
        "48781d38191161106e0165ce7c89a9047e8a6d1ab3895a6fcf6a8af2fb76a4ad",
        "dimethylzinc",
        "Cc1ccccc1",
        "[CH3:10][Zn:1000][CH3:1001]",
        (10,),
    ),
    StockDonorCorrection(
        "US20120041028A1;0522;1181820",
        "415e1a92ee4d9c5195b091b9ffe86f2c7e4e45d95601c1e06224c7d98fd33371",
        "tributylvinyltin",
        "Cc1ccccc1",
        "[CH2:1]=[CH:2][Sn:1000](CCCC)(CCCC)CCCC",
        (1, 2),
    ),
    StockDonorCorrection(
        "US20150191495A1;0877;1720659",
        "8bed02ff89eb3df70712a63e58524caba4ce5dbc3b6cb8e9de0138ba6e2ac166",
        "selenium-dioxide",
        "O1CCOCC1",
        "[O:16]=[Se:1000]=[O:1001]",
        (16,),
    ),
    StockDonorCorrection(
        "US20150111876A1;0257;1679640",
        "88c2d84e3f28f311c59e2345c2d39efdb3a9a89542de7330defd68b2fbd296fb",
        "water",
        "O1CCOCC1",
        "[OH2:5]",
        (5,),
    ),
    StockDonorCorrection(
        "US08575145B2;0703;1384618",
        "d6230f40aa7b88da2bb8ed2624337bcf24beba34a72e8e695656d19df3f9d1a0",
        "selenium-dioxide",
        "O1CCOCC1",
        "[O:14]=[Se:1000]=[O:1001]",
        (14,),
    ),
    StockDonorCorrection(
        "US20140155362A1;0182;1531051",
        "69bdfdf530a42795b3302dd0576a66c88cb12f3f55ba6b7fdba75d2c522a1e4e",
        "selenium-dioxide",
        "O1CCOCC1",
        "[O:12]=[Se:1000]=[O:1001]",
        (12,),
    ),
    StockDonorCorrection(
        "US08258130B2;1082;1223583",
        "867779a21153340b523dac19d2e5d082de6a269e7814895241896a1b545642a6",
        "hosa",
        "CN(C)C=O",
        "[NH2:5][O:1000][S:1001](=[O:1002])(=[O:1003])[OH:1004]",
        (5,),
    ),
    StockDonorCorrection(
        "US20110060009A1;0120;1025078",
        "aad05eb3604d58c63b8b2c90a1c84769012a927163c5cad1ae396a774ecd32a0",
        "boc2o",
        "CC(C)(C)OC(=O)OC(C)(C)C",
        "[CH3:1000][C:1001]([CH3:1002])([CH3:1003])[O:1004]"
        "[C:1005](=[O:1006])[O:1007][C:11](=[O:12])[O:13]"
        "[C:14]([CH3:15])([CH3:16])[CH3:17]",
        (11, 12, 13, 14, 15, 16, 17),
    ),
    StockDonorCorrection(
        "US20040048915A1;0164;138297",
        "97b28e9f6b28cb017c56dd0c1372fd335c8449f431b1daec4ccacbc26a609754",
        "dimethylmethyleneiminium",
        "CC=[N+]=CC",
        "[CH2:4]=[N+:2]([CH3:3])[CH3:1]",
        (1, 2, 3, 4),
    ),
    StockDonorCorrection(
        "US20130096301A1;0294;1357336",
        "d848ab6aa31d33091e42bfdf5b1739279ec7ad6364cea4d41f6fa523872f57f3",
        "diol-water",
        "CC(C)(C)O",
        "[OH2:18]",
        (18,),
    ),
    StockDonorCorrection(
        "US20130096301A1;0301;1357338",
        "779267fe7b42b58874377cd63761d273070336a66de14b45fe5778e95d81a216",
        "second-mesyl-chloride",
        "CCN(CC)CC",
        "[CH3:24][S:23](=[O:25])(=[O:26])[Cl:1000]",
        (24,),
        restored_product_maps=(23, 25, 26),
    ),
    StockDonorCorrection(
        "US20120071473A1;0317;1194364",
        "b3e147dee91d395521e407a512dccedf038e27d4c07ec79c94e19d91f73482fa",
        "diol-water",
        "CC(C)(C)O",
        "[OH2:4]",
        (4,),
    ),
    StockDonorCorrection(
        "US20070219179A1;0776;497108",
        "8e0c783b26ec0c0a50a70749a3c46900317c31fe459a1c45638af57a6674a583",
        "diol-water",
        "CC(C)(C)O",
        "[OH2:11]",
        (11,),
    ),
    StockDonorCorrection(
        "US20070054951A1;0074;438917",
        "9125cdf8f694f68d342419848405784bf831934174bfa7bcced45b6b58f69694",
        "diol-water",
        "CC(C)(C)O",
        "[OH2:4]",
        (4,),
    ),
    StockDonorCorrection(
        "US20130123239A1;0853;1367990",
        "475d639b9d08e9b8ba7a9d29186b43cfa9130acb44944c1d6ccd80c38650f895",
        "diol-water",
        "CC(C)(C)O",
        "[OH2:18]",
        (18,),
    ),
    StockDonorCorrection(
        "US05770595;;411968",
        "5aaf0ad6b0de97f04316a3158beb06c7bbe58a6bfd0f90b2f7685ad91a107549",
        "diol-water",
        "CC(C)=O",
        "[OH2:26]",
        (26,),
    ),
    StockDonorCorrection(
        "US07109193B2;0284;744417",
        "3442f1bd6b1497d3e157479db16dfa0e9ab7d1bbb5cef9ec3b96fb2ad21eb8af",
        "hydrolysis-water",
        "CC(C)=O",
        "[OH2:15]",
        (15,),
    ),
    StockDonorCorrection(
        "US06121270;;483954",
        "7e96bc1247b7cf9b837e5488736ca199344d787437c0355d1a2c0d84e40efe23",
        "diol-water",
        "CC(C)=O",
        "[OH2:4]",
        (4,),
    ),
    StockDonorCorrection(
        "US07326700B2;0303;822991",
        "967e228c5a131dadc04388162d6fefd46ea3fc261649f75cc57c5316d338d8b8",
        "hydrolysis-water",
        "CC(C)=O",
        "[OH2:18]",
        (18,),
    ),
    StockDonorCorrection(
        "US20090105253A1;0565;695090",
        "4af803b0961c7e343b27847a0bb2a1811e7e2555670c34c163e06886da6391cd",
        "diol-water",
        "CC(C)=O",
        "[OH2:25]",
        (25,),
        additional_donors=(DonorReplacement("O=[Os](=O)(=O)=O", "[OH2:27]", (27,)),),
    ),
    StockDonorCorrection(
        "US20080103137A1;0200;567479",
        "a4196d382a0e09d11b7dec9e3a78cd628b0b11b2ea67c74cd89aa7e4a37e9756",
        "diol-water",
        "CC(C)=O",
        "[OH2:6]",
        (6,),
        additional_donors=(DonorReplacement("O=[Os](=O)(=O)=O", "[OH2:8]", (8,)),),
    ),
    StockDonorCorrection(
        "US05866576;;431815",
        "e9e3248f80c0f907ea2b52c04315ef880e5140b99a6d20a38f4fba7fcbd44fee",
        "diol-water",
        "CC(C)=O",
        "[OH2:14]",
        (14,),
        additional_donors=(DonorReplacement("O=[Os](=O)(=O)=O", "[OH2:16]", (16,)),),
    ),
    StockDonorCorrection(
        "US06630472B1;;622880",
        "b68d6d58f5c8b51db399f4a91eb00fef71ca032131c1dc528c13d463c9dafd9c",
        "diol-water",
        "CC(C)=O",
        "[OH2:12]",
        (12,),
        additional_donors=(DonorReplacement("O=[Os](=O)(=O)=O", "[OH2:14]", (14,)),),
    ),
    StockDonorCorrection(
        "US07202239B2;0342;779886",
        "a6e4852f66e9ffc717c4858f75721dd1b67d3e3cae69c1e9acfa30768cc138af",
        "hydrolysis-water",
        "CC(C)=O",
        "[OH2:3]",
        (3,),
    ),
    StockDonorCorrection(
        "US05770595;;411960",
        "f87aa3a0af24236c12d2e7530449eea9bf66e8b5160e58e7c8aeb4a3597ae660",
        "diol-water",
        "CC(C)=O",
        "[OH2:21]",
        (21,),
    ),
    StockDonorCorrection(
        "US06121270;;483995",
        "5aaf0ad6b0de97f04316a3158beb06c7bbe58a6bfd0f90b2f7685ad91a107549",
        "diol-water",
        "CC(C)=O",
        "[OH2:26]",
        (26,),
    ),
    StockDonorCorrection(
        "US06121270;;483944",
        "d05c72fb02e34fe14870ce6ab99b8280e4e186751f14f62a41a1e98beb09b126",
        "diol-water",
        "CC(C)=O",
        "[OH2:14]",
        (14,),
    ),
    StockDonorCorrection(
        "US08658637B2;0780;1427467",
        "2e5aad9d6ae06f35112ea564d7ed674e5b99675ae73363775504fc0bb9a4f024",
        "diol-water",
        "CC(C)=O",
        "[OH2:1]",
        (1,),
    ),
    StockDonorCorrection(
        "US20110105427A1;0199;1046602",
        "a4196d382a0e09d11b7dec9e3a78cd628b0b11b2ea67c74cd89aa7e4a37e9756",
        "diol-water",
        "CC(C)=O",
        "[OH2:6]",
        (6,),
        additional_donors=(DonorReplacement("O=[Os](=O)(=O)=O", "[OH2:8]", (8,)),),
    ),
    StockDonorCorrection(
        "US08138340B2;0195;1167409",
        "ff0ca211dba73ca70b3065095804fe6d03318d1d24667a470f3bbe767d281e30",
        "diol-water",
        "O=[Os](=O)(=O)=O",
        "[OH2:1]",
        (1,),
    ),
    StockDonorCorrection(
        "US07846964B2;0270;1034286",
        "90db65e9e4e6e164e432778a881f14d34e019567e776e658d79d12952eb63a88",
        "diol-water",
        "O=[Os](=O)(=O)=O",
        "[OH2:4]",
        (4,),
    ),
    StockDonorCorrection(
        "US20110144100A1;0212;1068299",
        "0f61695c65ef33656cf9e1ef0851eca5f255154497ab0d19709fb92dcffd0223",
        "diol-water",
        "C1C[N+](CCO1)(C)[O-]",
        "[OH2:25]",
        (25,),
        additional_donors=(DonorReplacement("O=[Os](=O)(=O)=O", "[OH2:27]", (27,)),),
    ),
    StockDonorCorrection(
        "US20150376191A1;0143;1808697",
        "f268e924a312ec91075d601c96ca69bece369f6619a080f04b23f8e51c69ce72",
        "diol-water",
        "O=[Os](=O)(=O)=O",
        "[OH2:4]",
        (4,),
    ),
    StockDonorCorrection(
        "US20080194670A1;0233;601251",
        "90db65e9e4e6e164e432778a881f14d34e019567e776e658d79d12952eb63a88",
        "diol-water",
        "O=[Os](=O)(=O)=O",
        "[OH2:4]",
        (4,),
    ),
    StockDonorCorrection(
        "US09346798B2;1243;1765102",
        "faaa5a7844d3467201517fae2e037a05f746cc45cb2c8258458f1788099f5a17",
        "diol-water",
        "C1C[N+](CCO1)(C)[O-]",
        "[OH2:27]",
        (27,),
        additional_donors=(DonorReplacement("O=[Os](=O)(=O)=O", "[OH2:29]", (29,)),),
    ),
    StockDonorCorrection(
        "US20160083376A1;0684;1855495",
        "5064ed23938a985f6913c237b1b7e3344a4bcd34237984dfd3e7aa67e29ebe62",
        "diol-water",
        "O=[Os](=O)(=O)=O",
        "[OH2:15]",
        (15,),
    ),
    StockDonorCorrection(
        "US20120022056A1;0273;1170936",
        "d17a42ac510ed8d913eb0be6ecf2a47df0f89258452b2387bed05b55ab9c0ab4",
        "diol-water",
        "C1C[N+](CCO1)(C)[O-]",
        "[OH2:19]",
        (19,),
        additional_donors=(DonorReplacement("O=[Os](=O)(=O)=O", "[OH2:21]", (21,)),),
    ),
    StockDonorCorrection(
        "US20120277277A1;0197;1294371",
        "dbbbb7ae3564206d372c4688bda5f6ab7cc9b1b6348974872b94344e201a875a",
        "diol-water",
        "C1C[N+](CCO1)(C)[O-]",
        "[OH2:25]",
        (25,),
        additional_donors=(DonorReplacement("O=[Os](=O)(=O)=O", "[OH2:27]", (27,)),),
    ),
    StockDonorCorrection(
        "US20160046590A1;0971;1838983",
        "afda0a10d60d79e2d8ac97c5315a3b78069dfcf52cfa3aac1c85f4e55c639956",
        "diol-water",
        "C1C[N+](CCO1)(C)[O-]",
        "[OH2:16]",
        (16,),
        additional_donors=(DonorReplacement("O=[Os](=O)(=O)=O", "[OH2:18]", (18,)),),
    ),
    StockDonorCorrection(
        "US06762197B2;;654363",
        "c0b602feda2e9039f5ca016bd29660341453bdb9eee77067626978fba6f07bf4",
        "water",
        "CCOC(=O)C",
        "[OH2:5]",
        (5,),
    ),
    StockDonorCorrection(
        "US20100173967A1;1823;911147",
        "32b91e983192285a5d56d6782b2db73346ea7ad5984fe7079c499de640b2ddbb",
        "formaldehyde",
        "C(CCN1c2cccc(c2C(c3c(O)cc4OCOc4c3)C1=O)Br)CC",
        "[CH2:19]=[O:20]",
        (19, 20),
        removed_branch=(
            "US20100173967A1;1802;911134",
            "55c21e6c0e943f8809d347e880342aad9e04e6f2ea6b2b2d7b5be0b23bd194b4",
        ),
    ),
    StockDonorCorrection(
        "US20130129624A1;0201;1370134",
        "53d9a09acf9695fa240f3f62fd0b16be8b33858f13435f70fb96c67cf1121b9e",
        "formaldehyde",
        "BC#N",
        "[CH2:1]=O",
        (1,),
    ),
    StockDonorCorrection(
        "US20110183985A1;0907;1086563",
        "96bc4f0849d7e76749f46bb3386b8743540a2c0b5e2c5eee1cfac2c43e2635d5",
        "ammonia",
        "CC#N",
        "[NH3:3]",
        (3,),
    ),
    StockDonorCorrection(
        "US20070259854A1;0125;515502",
        "c6afbd780851797c0b454bae8d280e86b2d31a0739113cb4dcb790fa023c4126",
        "hydrolysis-water",
        "OCCO",
        "[OH2:8]",
        (8,),
    ),
    StockDonorCorrection(
        "US20160137613A1;1223;1877642",
        "1f50608935d887acd812d4f5fb4e45a2aeddaac3592b0a703417afb2c83b2338",
        "2-nitropropane",
        "CCOC(=O)C",
        "CC(C)[N+](=[O:6])[O-]",
        (6,),
    ),
)


def _node_at_path(route, path):
    for index in path:
        route = route["children"][index]
    return route


def _correct_stock_donors(route):
    """Repair audited stock assignments at any depth, preserving source mapping."""
    by_record = {spec.source_record_id: spec for spec in STOCK_DONOR_CORRECTIONS}
    corrected = route
    for path, node in reaction_nodes(route):
        metadata = node.get("metadata", {})
        spec = by_record.get(metadata.get("ID"))
        if spec is None:
            continue
        # Node-local marker allows the same source reaction at multiple paths.
        if metadata.get("source_correction_id") == spec.correction_id:
            continue
        recorded = metadata.get("smiles", "")
        if (
            "route_preprocessing_split" in metadata
            or sha256(recorded.encode()).hexdigest() != spec.reaction_sha256
        ):
            raise ValueError(
                "Known source correction requires the original unsplit source record "
                f"{spec.source_record_id}; its recorded reaction has changed"
            )
        reaction = chemistry.parse_reaction(recorded)
        parent = _node_at_path(route, path[:-1])
        if len(reaction.products) != 1 or not chemistry.molecules_equivalent(
            chemistry.parse_molecule(parent["smiles"]), reaction.products[0]
        ):
            raise ValueError("Known source correction target guard failed")
        children = node.get("children", [])
        if len(children) != len(reaction.reactants) or any(
            child.get("type") != "mol" for child in children
        ):
            raise ValueError("Known source correction precursor count guard failed")
        component_children = [
            [
                i
                for i, child in enumerate(children)
                if chemistry.molecules_equivalent(
                    chemistry.parse_molecule(child["smiles"]), molecule
                )
            ]
            for molecule in reaction.reactants
        ]
        if any(len(indices) != 1 for indices in component_children) or len(
            {indices[0] for indices in component_children}
        ) != len(children):
            raise ValueError("Known source correction precursor guard failed")
        if chemistry.canonical_unmapped_reaction_string(
            reaction_smiles_from_node(node)
        ) != chemistry.canonical_unmapped_reaction_string(recorded):
            raise ValueError("Known source correction working reaction has changed")
        product = reaction.products[0]
        used_maps = {n for mol in reaction.reactants + reaction.products for n in mol}
        reactant_maps = {n for mol in reaction.reactants for n in mol}
        plans = []
        for donor_spec in (spec, *spec.additional_donors):
            donor_matches = [
                i
                for i, molecule in enumerate(reaction.reactants)
                if chemistry.molecules_equivalent(
                    molecule, chemistry.parse_molecule(donor_spec.original_donor)
                )
            ]
            if len(donor_matches) != 1:
                raise ValueError("Known source correction donor guard failed")
            donor_index = donor_matches[0]
            if any(plan["donor_index"] == donor_index for plan in plans):
                raise ValueError("Known source correction duplicate donor")
            child_index = component_children[donor_index][0]
            child = children[child_index]
            removed = spec.removed_branch if donor_spec is spec else None
            if removed is not None:
                _validate_removed_donor_branch(child, removed)
            elif child.get("children") or child.get("in_stock") is not True:
                raise ValueError(
                    "Known source correction requires a terminal in-stock donor"
                )
            donor = reaction.reactants[donor_index]
            if set(donor) & set(product) != set(donor_spec.retained_maps):
                raise ValueError("Known source correction retained-map guard failed")
            replacement = chemistry.parse_molecule(donor_spec.replacement).copy()
            for number in donor_spec.retained_maps:
                old, new = donor.atom(number), replacement.atom(number)
                if (old.atomic_number, old.isotope) != (new.atomic_number, new.isotope):
                    raise ValueError(
                        "Known source correction atom-identity guard failed"
                    )
            restored = set(donor_spec.restored_product_maps)
            if not restored <= set(product) - reactant_maps or not restored <= set(
                replacement
            ):
                raise ValueError(
                    "Known source correction restored-product-map guard failed"
                )
            for number in restored:
                old, new = product.atom(number), replacement.atom(number)
                if (old.atomic_number, old.isotope) != (new.atomic_number, new.isotope):
                    raise ValueError(
                        "Known source correction restored-atom-identity guard failed"
                    )
            preserved_maps = set(donor_spec.retained_maps) | restored
            replacement.remap(
                {
                    old: fresh
                    for fresh, old in enumerate(
                        sorted(set(replacement) - preserved_maps), max(used_maps) + 1
                    )
                }
            )
            used_maps.update(replacement)
            plans.append(
                dict(
                    donor_index=donor_index,
                    child_index=child_index,
                    replacement=replacement,
                    evidence={
                        "replaced_precursor_subtree": deepcopy(child),
                        "replacement_precursor_smiles": format(replacement, "m"),
                        "retained_atom_maps": list(donor_spec.retained_maps),
                        **(
                            {"restored_product_atom_maps": sorted(restored)}
                            if restored
                            else {}
                        ),
                        **(
                            {
                                "removed_precursor_subtree": deepcopy(child),
                                "removed_source_record_id": removed[0],
                            }
                            if removed
                            else {}
                        ),
                    },
                )
            )
        # Publish only after every donor and any pruned branch pass their guards.
        reactants = list(reaction.reactants)
        for plan in plans:
            reactants[plan["donor_index"]] = plan["replacement"]
        corrected_smiles = (
            ".".join(format(m, "m") for m in reactants) + ">>" + format(product, "m")
        )
        if corrected is route:
            corrected = deepcopy(route)
        repaired = _node_at_path(corrected, path)
        evidence = {
            "correction_id": spec.correction_id,
            "source_record_id": spec.source_record_id,
            "reaction_node_path": list(path),
            "basis": f"user-curated {spec.name} replacement of misassigned donor",
            "original_reaction_smiles": reaction_smiles_from_node(node),
            "original_reaction_metadata": deepcopy(metadata),
            "removed_reaction_count": int(spec.removed_branch is not None),
            "corrected_reaction_smiles": corrected_smiles,
            "target_unchanged": True,
            **plans[0]["evidence"],
        }
        if len(plans) > 1:
            evidence["additional_donor_replacements"] = [
                p["evidence"] for p in plans[1:]
            ]
        corrected.setdefault("metadata", {}).setdefault(
            "source_corrections", []
        ).append(evidence)
        repaired["smiles"] = corrected_smiles
        repaired["metadata"]["smiles"] = corrected_smiles
        old_rsmi = metadata.get("rsmi", "").split(">")
        reagents = old_rsmi[1] if len(old_rsmi) == 3 else ""
        repaired["metadata"]["rsmi"] = corrected_smiles.replace(">>", f">{reagents}>")
        repaired["metadata"].pop("reaction_hash", None)
        repaired["metadata"]["source_correction_id"] = spec.correction_id
        for plan in plans:
            repaired["children"][plan["child_index"]] = {
                "type": "mol",
                "smiles": plan["evidence"]["replacement_precursor_smiles"],
                "in_stock": True,
                "children": [],
                "metadata": {
                    "source_correction_id": spec.correction_id,
                    "stock_basis": "curated terminal precursor; stock membership not inferred",
                },
            }
    return corrected


def _validate_removed_donor_branch(child, expected):
    """Allow pruning only the explicitly audited one-step donor subtree."""
    branches = child.get("children", [])
    if len(branches) != 1 or branches[0].get("type") != "reaction":
        raise ValueError("Known source correction removed-branch guard failed")
    branch = branches[0]
    metadata = branch.get("metadata", {})
    recorded = metadata.get("smiles", "")
    if (
        metadata.get("ID"),
        sha256(recorded.encode()).hexdigest(),
    ) != expected or "route_preprocessing_split" in metadata:
        raise ValueError("Known source correction removed reaction has changed")
    if chemistry.canonical_unmapped_reaction_string(
        reaction_smiles_from_node(branch)
    ) != chemistry.canonical_unmapped_reaction_string(recorded):
        raise ValueError("Known source correction removed working reaction has changed")
    reaction = chemistry.parse_reaction(recorded)
    leaves = branch.get("children", [])
    if len(reaction.products) != 1 or not chemistry.molecules_equivalent(
        chemistry.parse_molecule(child["smiles"]), reaction.products[0]
    ):
        raise ValueError("Known source correction removed-branch product guard failed")
    if (
        len(leaves) != 1
        or len(reaction.reactants) != 1
        or leaves[0].get("type") != "mol"
        or leaves[0].get("children")
        or leaves[0].get("in_stock") is not True
        or not chemistry.molecules_equivalent(
            chemistry.parse_molecule(leaves[0]["smiles"]), reaction.reactants[0]
        )
    ):
        raise ValueError(
            "Known source correction removed-branch precursor guard failed"
        )


def _correct_phosphonium_source(route):
    """Replace the audited toluene donor in n1 route 227, retaining carbon map 1."""
    if any(
        row.get("correction_id") == PHOSPHONIUM_CORRECTION_ID
        for row in route.get("metadata", {}).get("source_corrections", [])
    ):
        return route
    roots = route.get("children", [])
    matches = [
        node
        for node in roots
        if node.get("type") == "reaction"
        and node.get("metadata", {}).get("ID") == PHOSPHONIUM_SOURCE_RECORD_ID
    ]
    if not matches:
        return route
    if len(roots) != 1 or len(matches) != 1:
        raise ValueError("Known source correction requires one root reaction")
    node = matches[0]
    metadata = node.get("metadata", {})
    recorded = metadata.get("smiles", "")
    if (
        "route_preprocessing_split" in metadata
        or sha256(recorded.encode()).hexdigest() != PHOSPHONIUM_REACTION_SHA256
    ):
        raise ValueError(
            "Known source correction requires the original unsplit source record "
            f"{PHOSPHONIUM_SOURCE_RECORD_ID}; its recorded reaction has changed"
        )
    reaction = chemistry.parse_reaction(recorded)
    substrate, donor = reaction.reactants
    children = node.get("children", [])
    if len(children) != 2 or any(c.get("type") != "mol" for c in children):
        raise ValueError("Known source correction requires its two original precursors")
    if not chemistry.molecules_equivalent(
        chemistry.parse_molecule(route["smiles"]), reaction.products[0]
    ):
        raise ValueError("Known source correction target guard failed")
    child_matches = [
        [
            i
            for i, child in enumerate(children)
            if chemistry.molecules_equivalent(
                chemistry.parse_molecule(child["smiles"]), molecule
            )
        ]
        for molecule in (substrate, donor)
    ]
    if any(len(indices) != 1 for indices in child_matches) or (
        child_matches[0] == child_matches[1]
    ):
        raise ValueError("Known source correction precursor guard failed")
    donor_index = child_matches[1][0]
    if children[donor_index].get("children"):
        raise ValueError("Known source correction requires a terminal toluene donor")

    # Parse the complete original reaction first so its previously unmapped atoms
    # reserve their IDs too. Only methyl carbon 1 is shared with the new donor.
    used_maps = {n for mol in reaction.reactants + reaction.products for n in mol}
    replacement = chemistry.parse_molecule(METHYLTRIPHENYLPHOSPHONIUM).copy()
    replacement.remap(
        {
            old: fresh
            for fresh, old in enumerate(
                sorted(set(replacement) - {1}), max(used_maps) + 1
            )
        }
    )
    replacement_smiles = format(replacement, "m")
    corrected_smiles = (
        f"{format(substrate, 'm')}.{replacement_smiles}"
        f">>{format(reaction.products[0], 'm')}"
    )
    corrected = deepcopy(route)
    repaired = corrected["children"][0]
    evidence = {
        "correction_id": PHOSPHONIUM_CORRECTION_ID,
        "source_record_id": PHOSPHONIUM_SOURCE_RECORD_ID,
        "basis": "user-curated methyltriphenylphosphonium donor; methyl map 1 retained",
        "original_reaction_smiles": reaction_smiles_from_node(node),
        "original_reaction_metadata": deepcopy(metadata),
        "replaced_precursor_subtree": deepcopy(children[donor_index]),
        "removed_reaction_count": 0,
        "replacement_precursor_smiles": replacement_smiles,
        "corrected_reaction_smiles": corrected_smiles,
        "retained_atom_maps": [1],
        "target_unchanged": True,
    }
    corrected.setdefault("metadata", {}).setdefault("source_corrections", []).append(
        evidence
    )
    repaired["smiles"] = corrected_smiles
    repaired["metadata"]["smiles"] = corrected_smiles
    # Keep recorded reagents when the source has a three-part rsmi field.
    old_rsmi = metadata.get("rsmi", "").split(">")
    reagents = old_rsmi[1] if len(old_rsmi) == 3 else ""
    repaired["metadata"]["rsmi"] = corrected_smiles.replace(">>", f">{reagents}>")
    repaired["metadata"].pop("reaction_hash", None)
    repaired["metadata"]["source_correction_id"] = PHOSPHONIUM_CORRECTION_ID
    repaired["children"][donor_index] = {
        "type": "mol",
        "smiles": replacement_smiles,
        "in_stock": True,
        "children": [],
        "metadata": {
            "source_correction_id": PHOSPHONIUM_CORRECTION_ID,
            "stock_basis": "curated terminal precursor; stock membership not inferred",
        },
    }
    return corrected
