"""PaRoutes adapters and audited source-record policy."""
