"""Source-record provenance adapters for route reaction nodes.

The route corpora handled by Route Inspector do not share one source identifier
schema.  This module keeps the raw identifier lossless and makes parsing an
explicit, versioned adapter decision rather than embedding PaRoutes assumptions in
the occurrence/index code."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from route_inspector.routes.provenance import SourceIdentifiers, raw_source_record_id

PAROUTES_SOURCE_ID_ADAPTER = "paroutes-semicolon-v1"


@dataclass(frozen=True)
class PaRoutesSourceIdAdapter:
    """Parse PaRoutes ``metadata.ID`` values such as ``US...;step;record``."""

    name: str = PAROUTES_SOURCE_ID_ADAPTER

    def parse(self, metadata: Mapping[str, Any]) -> SourceIdentifiers:
        value = raw_source_record_id(metadata)
        document_id = value.split(";", 1)[0].strip() if value else ""
        return SourceIdentifiers(
            source_record_id=value,
            source_document_id=document_id,
            adapter=self.name,
        )
