"""Publish a complete merge audit before making its route JSON visible."""

from __future__ import annotations

import errno
import fcntl
import json
import os
import shutil
import tempfile
from pathlib import Path

from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.infrastructure.publication import publish_directory_no_replace

PENDING_ROUTES = ".routes.pending.json"
_MARKER = ".publication.pending.json"
_AUDIT_FILES = ("summary.json", "route_labels.jsonl", "errors.tsv")


def _publish_output(source, output):
    """Link complete data without replacement; stage a copy across filesystems."""
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(source, output)
    except OSError as exc:
        if exc.errno != errno.EXDEV:
            raise
        fd, name = tempfile.mkstemp(prefix=".route-merge-", dir=output.parent)
        try:
            with os.fdopen(fd, "wb") as stream, source.open("rb") as original:
                shutil.copyfileobj(original, stream)
                stream.flush()
                os.fsync(stream.fileno())
            os.link(name, output)
        finally:
            Path(name).unlink(missing_ok=True)


def _finish(audit_dir):
    (audit_dir / PENDING_ROUTES).unlink(missing_ok=True)
    (audit_dir / _MARKER).unlink()


def publish_merge(staged_audit, output, audit_dir):
    """Audit first, JSON last. Roll back caught failures before JSON publication.

    A complete pending audit retains the route bytes and checksums if the process
    is killed between the two publications. The same invocation can finish it.
    """
    marker = staged_audit / _MARKER
    marker.write_text(
        json.dumps(
            {
                "version": 1,
                "output": output.as_posix(),
                "audit_sha256": {
                    name: sha256_file(staged_audit / name) for name in _AUDIT_FILES
                },
            },
            sort_keys=True,
        )
        + "\n"
    )
    with marker.open("rb") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        for path in staged_audit.iterdir():
            with path.open("rb") as stream:
                os.fsync(stream.fileno())
        owned = staged_audit.stat()
        try:
            publish_directory_no_replace(staged_audit, audit_dir)
            _publish_output(audit_dir / PENDING_ROUTES, output)
        except BaseException:
            # Never remove another publisher's JSON or overwrite a destination.
            # Retain the audit if publication succeeded immediately before an
            # interrupt; recovery verifies the pair and finishes cleanup.
            if audit_dir.exists() and os.path.samestat(audit_dir.lstat(), owned):
                pending = audit_dir / PENDING_ROUTES
                if not (
                    output.is_file() and sha256_file(output) == sha256_file(pending)
                ):
                    shutil.rmtree(audit_dir)
            raise
        _finish(audit_dir)


def recover_merge(inputs, output, audit_dir):
    """Finish only our intact interrupted publication, with unchanged inputs."""
    if not output.exists() and not audit_dir.exists():
        return None
    marker = audit_dir / _MARKER
    if audit_dir.is_symlink() or not marker.is_file() or marker.is_symlink():
        raise FileExistsError("merge output and audit directory must be new")
    with marker.open("rb") as lock:
        # An active publication owns the marker inode across its atomic rename.
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise FileExistsError("merge publication is still in progress") from exc
        metadata = json.load(lock)
        if metadata.get("version") != 1 or metadata.get("output") != output.as_posix():
            raise ValueError("pending merge publication does not match this output")
        checksums = metadata.get("audit_sha256", {})
        if set(checksums) != set(_AUDIT_FILES) or any(
            (audit_dir / name).is_symlink()
            or not (audit_dir / name).is_file()
            or sha256_file(audit_dir / name) != checksums[name]
            for name in _AUDIT_FILES
        ):
            raise ValueError("pending merge audit is incomplete or damaged; preserved")
        result = json.loads((audit_dir / "summary.json").read_text())
        expected = [(s["dataset"], s["path"]) for s in result["inputs"]]
        if expected != [(label, Path(path).as_posix()) for label, path in inputs]:
            raise ValueError("pending merge input selection changed; preserved")
        for source in result["inputs"]:
            if sha256_file(Path(source["path"])) != source["sha256"]:
                raise ValueError("pending merge input content changed; preserved")
        pending = audit_dir / PENDING_ROUTES
        if output.exists():
            if (
                output.is_symlink()
                or not output.is_file()
                or sha256_file(output) != result["output_sha256"]
            ):
                raise FileExistsError(
                    "merge output differs from pending publication; preserved"
                )
        else:
            if (
                pending.is_symlink()
                or not pending.is_file()
                or sha256_file(pending) != result["output_sha256"]
            ):
                raise ValueError(
                    "pending merged routes are missing or damaged; preserved"
                )
            _publish_output(pending, output)
        _finish(audit_dir)
        return result
