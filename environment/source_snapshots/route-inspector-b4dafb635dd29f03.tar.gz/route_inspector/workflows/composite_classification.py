"""Corpus execution and publication for composite classification."""

from __future__ import annotations

import json
from pathlib import Path

from route_inspector.composite_rules.classify_composite import (
    classify_composite_rules,
)
from route_inspector.composite_rules.writers import (
    default_classification_output_path,
    default_classification_summary_path,
)
from route_inspector.infrastructure.artifacts import write_json, write_standard_sidecars
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
from route_inspector.workflows.requests import ClassifyCompositeRulesRequest


def run(args: ClassifyCompositeRulesRequest) -> int:
    """Run this module command with parsed CLI arguments.

    Classification compares each composite QueryCGR against default one-step rules,
    then writes positive and negative rule sets for scoring.
    """
    setup_runtime_cache_dirs()
    if getattr(args, "output", None) is None:
        if getattr(args, "output_dir", None) is None:
            output = default_classification_output_path(args.composite_rules_tsv)
        else:
            output = args.output_dir
    elif getattr(args, "output_dir", None) is not None:
        raise ValueError("--output and --output-dir cannot be used together")
    else:
        output = args.output
    summary_path = args.summary or (
        output
        if (getattr(args, "output_dir", None) is not None)
        else default_classification_summary_path(output)
    )
    summary = classify_composite_rules(
        resolve_existing_path(args.composite_rules_tsv),
        resolve_existing_path(args.default_rules_tsv),
        output,
        summary_path,
        n_cpu=args.n_cpu,
    )
    sidecars = write_standard_sidecars(
        Path(summary["output"]).parent,
        command_name="classify-composite-rules",
        summary=summary,
        errors=[],
        input_files=[args.composite_rules_tsv, args.default_rules_tsv],
        output_files={
            "classified_composite_rules": summary["output"],
            "positive": summary["positive_output"],
            "negative": summary["negative_output"],
            "summary": summary["summary_file"],
        },
        cli_args=args,
    )
    summary["sidecar_files"] = sidecars
    write_json(Path(summary["summary_file"]), summary)
    print(json.dumps(summary, indent=2), flush=True)
    return 0
