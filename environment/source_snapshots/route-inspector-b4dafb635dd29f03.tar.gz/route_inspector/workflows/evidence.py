"""Production workflows for route-context evidence artifacts.

The command runners in this module are intentionally thin orchestration layers.
Chemistry and occurrence semantics remain in ``context``, ``rrseqs``, and
``reference_index``.  Additional context-annotation and generated-route runners
can be added here without coupling them to the SQLite implementation.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

from route_inspector.context.vocabulary import load_functional_group_vocabulary
from route_inspector.infrastructure.artifacts import write_json, write_standard_sidecars
from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.infrastructure.paths import relative_path, resolve_existing_path
from route_inspector.reference_library.context_index import (
    REFERENCE_INDEX_SCHEMA_VERSION,
    REFERENCE_OCCURRENCE_SCHEMA_VERSION,
    REFERENCE_SCOPE,
    ReferenceIndexMetadata,
    build_reference_index_from_paths,
)
from route_inspector.reference_library.context_index.models import canonical_json
from route_inspector.rules.occurrences import (
    SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
    SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION,
)
from route_inspector.tactics.rrseq.gapped import (
    RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION,
)
from route_inspector.tactics.rrseq.occurrences import (
    RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION,
)


def _sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _canonical_config(path: Path) -> Any:
    """Read JSON/YAML configuration into a canonical JSON-compatible value."""

    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        value = json.loads(text)
    else:
        try:
            import yaml
        except ImportError as exc:  # pragma: no cover - project runtime provides YAML
            raise RuntimeError(
                "PyYAML is required to hash a YAML configuration"
            ) from exc
        value = yaml.safe_load(text)
    return {} if value is None else value


def _arg_paths(args: Any, *names: str) -> tuple[Path, ...]:
    for name in names:
        value = getattr(args, name, None)
        if value:
            raw_paths = value if isinstance(value, (list, tuple)) else (value,)
            return tuple(resolve_existing_path(path) for path in raw_paths)
    return ()


def _resolve_output(args: Any) -> Path:
    output = getattr(args, "output", None)
    output_dir = getattr(args, "output_dir", None)
    if output is not None and output_dir is not None:
        raise ValueError("--output and --output-dir cannot be used together")
    if output is not None:
        return Path(output).expanduser()
    if output_dir is not None:
        return Path(output_dir).expanduser() / "reference_index.sqlite"
    raise ValueError("either --output or --output-dir is required")


def _context_history_schema_version() -> int:
    # Imported lazily so the index remains importable without loading chemistry.
    from route_inspector.context.history import CONTEXT_HISTORY_SCHEMA_VERSION

    return int(CONTEXT_HISTORY_SCHEMA_VERSION)


def _vocabulary_metadata() -> tuple[str, str, Mapping[str, Any]]:
    vocabulary = load_functional_group_vocabulary()
    manifest = vocabulary.manifest_dict()
    return vocabulary.version_id, vocabulary.manifest_sha256, manifest


def _input_hashes(paths: Iterable[Path]) -> dict[str, str]:
    unique = {Path(path) for path in paths}
    return {
        relative_path(path): _sha256_file(path)
        for path in sorted(unique, key=lambda item: str(item))
    }


def _validate_context_vocabulary(
    paths: Iterable[Path],
    *,
    vocabulary_version: str,
    vocabulary_source_sha256: str,
    vocabulary_manifest_sha256: str,
) -> str:
    """Validate vocabulary/integrity and return the unique context-policy hash."""

    from route_inspector.context.history import (
        CONTEXT_HISTORY_IDENTITY_VERSION,
        CONTEXT_HISTORY_SCHEMA_VERSION,
        validate_context_history_integrity_metadata,
    )
    from route_inspector.reference_library.context_index import iter_mapping_records

    paths = tuple(paths)
    records_seen = 0
    policy_hashes: set[str] = set()
    for path in paths:
        for record in iter_mapping_records(path):
            records_seen += 1
            actual_schema = int(record.get("schema_version", 1))
            actual_identity = int(record.get("identity_version", 1))
            if actual_schema != CONTEXT_HISTORY_SCHEMA_VERSION:
                raise ValueError(
                    f"context history schema version mismatch in {path}: "
                    f"expected={CONTEXT_HISTORY_SCHEMA_VERSION} "
                    f"actual={actual_schema}"
                )
            if actual_identity != CONTEXT_HISTORY_IDENTITY_VERSION:
                raise ValueError(
                    f"context history identity version mismatch in {path}: "
                    f"expected={CONTEXT_HISTORY_IDENTITY_VERSION} "
                    f"actual={actual_identity}"
                )
            validate_context_history_integrity_metadata(record)
            policy_hashes.add(str(record["context_policy_sha256"]))
            actual_version = str(record.get("vocabulary_version") or "")
            actual_source_hash = str(record.get("vocabulary_source_sha256") or "")
            actual_manifest_hash = str(record.get("vocabulary_manifest_sha256") or "")
            if actual_version != vocabulary_version:
                raise ValueError(
                    f"context history vocabulary version mismatch in {path}: "
                    f"expected={vocabulary_version} actual={actual_version or '<missing>'}"
                )
            if actual_source_hash != vocabulary_source_sha256:
                raise ValueError(
                    f"context history vocabulary source hash mismatch in {path}: "
                    "expected="
                    f"{vocabulary_source_sha256} "
                    f"actual={actual_source_hash or '<missing>'}"
                )
            if actual_manifest_hash != vocabulary_manifest_sha256:
                raise ValueError(
                    f"context history vocabulary manifest hash mismatch in {path}: "
                    "expected="
                    f"{vocabulary_manifest_sha256} "
                    f"actual={actual_manifest_hash or '<missing>'}"
                )
    if paths and records_seen == 0:
        raise ValueError("context-history sidecars contain no records")
    if len(policy_hashes) != 1:
        raise ValueError(
            "context-history sidecars must use one context-policy hash; "
            f"actual={sorted(policy_hashes)}"
        )
    return next(iter(policy_hashes))


def _run_build_reference_index(args: Any) -> int:
    """Build the all-corpus evidence index and its standard sidecars."""

    occurrence_paths = _arg_paths(
        args,
        "occurrences",
        "occurrence_paths",
        "occurrence_sidecars",
    )
    if not occurrence_paths:
        raise ValueError("at least one exact occurrence sidecar is required")
    context_history_paths = _arg_paths(
        args,
        "context_history",
        "context_histories",
        "context_history_paths",
    )
    if not context_history_paths:
        raise ValueError(
            "at least one authoritative context-history sidecar is required"
        )
    composite_paths = _arg_paths(
        args,
        "composite_certificates",
        "composite_validation",
        "composite_validations",
        "composite_certificate_paths",
    )
    config_value = getattr(args, "config", None) or getattr(args, "config_path", None)
    if config_value is None:
        raise ValueError("--config is required for reference-index provenance")
    config_path = resolve_existing_path(config_value)
    output = _resolve_output(args)

    all_inputs = (
        *occurrence_paths,
        *context_history_paths,
        *composite_paths,
        config_path,
    )
    missing = [str(path) for path in all_inputs if not Path(path).is_file()]
    if missing:
        raise FileNotFoundError(
            "missing reference-index input(s): " + ", ".join(missing)
        )
    input_hashes = _input_hashes(all_inputs)
    config_hash = _sha256_json(_canonical_config(config_path))
    vocabulary_version, vocabulary_hash, vocabulary_manifest = _vocabulary_metadata()
    context_policy_hash = _validate_context_vocabulary(
        context_history_paths,
        vocabulary_version=vocabulary_version,
        vocabulary_source_sha256=str(vocabulary_manifest["source_sha256"]),
        vocabulary_manifest_sha256=vocabulary_hash,
    )
    schema_versions = {
        "context_history": _context_history_schema_version(),
        "reference_occurrence": REFERENCE_OCCURRENCE_SCHEMA_VERSION,
        "rrseq_cons": RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION,
        "rrseq_gap": RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION,
        "single_rule": SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION,
        "composite_validation": 1,
    }
    mapping_validation = {
        "performed_by_stage": False,
        "status": "not_applicable",
        "input_status": "inherited",
        "policy": "exact_occurrence_sidecars_from_mapping_validated_routes",
    }
    metadata = ReferenceIndexMetadata(
        vocabulary_version=vocabulary_version,
        vocabulary_hash=vocabulary_hash,
        config_hash=config_hash,
        input_schema_versions=schema_versions,
        extra={
            "input_sha256": input_hashes,
            "mapping_validation": mapping_validation,
            "occurrence_identity_versions": {
                "rrseq_gap": RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION,
                "rrseq_cons": RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
                "single_rule": SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
            },
            "vocabulary_manifest_schema_version": vocabulary_manifest["schema_version"],
            "context_policy_sha256": context_policy_hash,
        },
    )
    export_formats = tuple(getattr(args, "export_format", ()) or ("jsonl", "tsv"))
    exports_dir_value = getattr(args, "export_dir", None) or getattr(
        args, "exports_dir", None
    )
    result = build_reference_index_from_paths(
        output,
        occurrence_paths,
        metadata=metadata,
        context_history_paths=context_history_paths,
        composite_certificate_paths=composite_paths,
        dataset_id=getattr(args, "dataset_id", None),
        batch_size=int(getattr(args, "batch_size", 5_000)),
        exports_dir=(
            None if exports_dir_value is None else Path(exports_dir_value).expanduser()
        ),
        export_formats=export_formats,
    )

    output_files: dict[str, str | Path] = {"reference_index": result.path}
    output_files.update(
        {f"export_{name}": path for name, path in sorted(result.export_paths.items())}
    )
    summary = {
        **result.to_dict(),
        "command_name": "build-reference-index",
        "reference_scope": REFERENCE_SCOPE,
        "reference_index_schema_version": REFERENCE_INDEX_SCHEMA_VERSION,
        "reference_occurrence_schema_version": REFERENCE_OCCURRENCE_SCHEMA_VERSION,
        "input_schema_versions": schema_versions,
        "input_sha256": input_hashes,
        "config": relative_path(config_path),
        "config_hash": config_hash,
        "vocabulary_version": vocabulary_version,
        "vocabulary_hash": vocabulary_hash,
        "context_policy_sha256": context_policy_hash,
        "mapping_validation": mapping_validation,
        "errors": 0,
        "output_files": {
            key: relative_path(path) for key, path in sorted(output_files.items())
        },
        "sidecar_files": {
            "summary": relative_path(output.parent / "summary.json"),
            "errors": relative_path(output.parent / "errors.tsv"),
            "manifest": relative_path(output.parent / "manifest.json"),
        },
    }
    sidecars = write_standard_sidecars(
        output.parent,
        command_name="build-reference-index",
        summary=summary,
        errors=(),
        input_files=all_inputs,
        output_files=output_files,
        config_path=config_path,
        cli_args=args,
        extra_manifest={
            "reference_scope": REFERENCE_SCOPE,
            "reference_index_schema_version": REFERENCE_INDEX_SCHEMA_VERSION,
            "input_schema_versions": schema_versions,
            "input_sha256": input_hashes,
            "config_hash": config_hash,
            "vocabulary_version": vocabulary_version,
            "vocabulary_hash": vocabulary_hash,
            "context_policy_sha256": context_policy_hash,
            "mapping_validation": mapping_validation,
        },
    )
    summary["sidecar_files"] = sidecars
    write_json(output.parent / "summary.json", summary)
    print(json.dumps(summary, indent=2), flush=True)
    return 0


def _raw_input_paths(args: Any) -> tuple[Path, ...]:
    """Return existing build inputs without triggering path-resolution failures."""

    values: list[Path] = []
    for name in (
        "occurrences",
        "occurrence_paths",
        "occurrence_sidecars",
        "context_history",
        "context_histories",
        "context_history_paths",
        "composite_certificates",
        "composite_validation",
        "composite_validations",
        "composite_certificate_paths",
        "config",
        "config_path",
    ):
        raw = getattr(args, name, None)
        if not raw:
            continue
        for value in raw if isinstance(raw, (tuple, list)) else (raw,):
            path = Path(value).expanduser()
            if path.is_file() and path not in values:
                values.append(path)
    return tuple(values)


def run_build_reference_index(args: Any) -> int:
    """Build the index and preserve standard sidecars on every failure path."""

    output = _resolve_output(args)
    try:
        return _run_build_reference_index(args)
    except Exception as exc:
        output.parent.mkdir(parents=True, exist_ok=True)
        inputs = _raw_input_paths(args)
        input_hashes = _input_hashes(inputs)
        error = {
            "dataset_id": str(getattr(args, "dataset_id", None) or "*"),
            "route_id": "*",
            "stage": "build_reference_index",
            "error_type": type(exc).__qualname__,
            "message": str(exc),
        }
        mapping_validation = {
            "performed_by_stage": False,
            "status": "not_applicable",
            "input_status": "inherited",
            "policy": "exact_occurrence_sidecars_from_mapping_validated_routes",
        }
        summary = {
            "command_name": "build-reference-index",
            "status": "failed_reference_index_build",
            "reference_scope": REFERENCE_SCOPE,
            "reference_index_schema_version": REFERENCE_INDEX_SCHEMA_VERSION,
            "reference_occurrence_schema_version": (
                REFERENCE_OCCURRENCE_SCHEMA_VERSION
            ),
            "mapping_validation": mapping_validation,
            "input_sha256": input_hashes,
            "errors": 1,
            "output_files": {},
        }
        config_value = getattr(args, "config", None) or getattr(
            args, "config_path", None
        )
        config_path = (
            Path(config_value).expanduser()
            if config_value is not None and Path(config_value).expanduser().is_file()
            else None
        )
        sidecars = write_standard_sidecars(
            output.parent,
            command_name="build-reference-index",
            summary=summary,
            errors=(error,),
            input_files=inputs,
            output_files={},
            config_path=config_path,
            cli_args=args,
            extra_manifest={
                "reference_scope": REFERENCE_SCOPE,
                "reference_index_schema_version": REFERENCE_INDEX_SCHEMA_VERSION,
                "reference_occurrence_schema_version": (
                    REFERENCE_OCCURRENCE_SCHEMA_VERSION
                ),
                "mapping_validation": mapping_validation,
                "input_sha256": input_hashes,
            },
        )
        summary["sidecar_files"] = sidecars
        write_json(output.parent / "summary.json", summary)
        raise


def run_annotate_context_history(args: Any) -> int:
    """Build the authoritative route-wide context sidecar."""

    from route_inspector.workflows.context import run_annotate_context_history as run

    return run(args)


def run_inspect_generated_routes(args: Any) -> int:
    """Retrieve exact counts and precedents for generated routes."""

    from route_inspector.workflows.generated_routes import (
        run_generated_route_inspection,
    )

    return run_generated_route_inspection(args)


__all__ = [
    "run_annotate_context_history",
    "run_build_reference_index",
    "run_inspect_generated_routes",
]
