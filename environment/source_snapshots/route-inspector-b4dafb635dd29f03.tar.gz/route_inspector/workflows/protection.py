"""CLI parsers and runners for protection analysis."""

from __future__ import annotations

import sys
from pathlib import Path

from route_inspector.infrastructure.artifacts import write_standard_sidecars
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
from route_inspector.infrastructure.text import read_json
from route_inspector.protection.analysis import (
    ProtectionAnalysisConfig,
    analyze_protection_in_routes,
    load_rrseq_index,
)
from route_inspector.protection.chython_rules import load_chython_protection_rules
from route_inspector.protection.outputs import (
    dataset_prefix_from_routes_path,
    write_protection_outputs,
)
from route_inspector.workflows.requests import AnalyzeProtectionRequest


def run_protection_analysis(args: AnalyzeProtectionRequest) -> int:
    """Run protection analysis using configured inputs.

    The function translates CLI arguments into the typed inputs expected by the
    underlying analysis module.
    """
    setup_runtime_cache_dirs()
    routes_path = resolve_existing_path(args.routes_json)
    config_path = resolve_existing_path(args.config) if args.config else None
    config = ProtectionAnalysisConfig.from_yaml(config_path).with_cli_overrides(args)

    print(
        f"[analyze-protection] loading routes: {routes_path}",
        file=sys.stderr,
        flush=True,
    )
    routes_json = read_json(routes_path)

    print("[analyze-protection] loading rrseq rule index", file=sys.stderr, flush=True)
    rrseq_index = load_rrseq_index(args.rrseq_tsv)
    print(
        f"[analyze-protection] rrseq rule families: {len(rrseq_index)}",
        file=sys.stderr,
        flush=True,
    )

    print(
        "[analyze-protection] loading chython protection rules",
        file=sys.stderr,
        flush=True,
    )
    protection_rules = load_chython_protection_rules()
    source_counts: dict[str, int] = {}
    for rule in protection_rules.values():
        source_counts[rule.source] = source_counts.get(rule.source, 0) + 1
    print(
        "[analyze-protection] protection rules: "
        f"{len(protection_rules)} from {source_counts}",
        file=sys.stderr,
        flush=True,
    )

    route_ids_path = (
        resolve_existing_path(args.route_ids_file) if args.route_ids_file else None
    )
    result = analyze_protection_in_routes(
        routes_json,
        rrseq_index=rrseq_index,
        config=config,
        protection_rules=protection_rules,
        limit=args.limit,
        route_ids=read_protection_route_ids(route_ids_path),
        progress_interval=args.progress_interval,
        n_cpu=args.n_cpu,
    )
    dataset_prefix = dataset_prefix_from_routes_path(routes_path)
    output_info = write_protection_outputs(
        result,
        args.output_dir,
        dataset_prefix=dataset_prefix,
    )
    protection_summary = dict(result.summary)
    protection_summary["dataset"] = dataset_prefix
    protection_summary["output_files"] = output_info["output_files"]
    write_standard_sidecars(
        args.output_dir,
        command_name="analyze-protection",
        summary=protection_summary,
        errors=result.summary.get("errors", []),
        input_files=[
            routes_path,
            *(args.rrseq_tsv or []),
            *(args.composite_rules_tsv or []),
        ],
        output_files=output_info["output_files"],
        config_path=config_path,
        cli_args=args,
    )
    print(
        "[analyze-protection] done: "
        f"{result.summary['n_routes']} routes, "
        f"{result.summary['n_deprotection_events']} deprotection events",
        file=sys.stderr,
        flush=True,
    )
    print(
        f"[analyze-protection] summary: {output_info['output_files']['summary']}",
        file=sys.stderr,
        flush=True,
    )
    return 0


def read_protection_route_ids(path: Path | None) -> set[str] | None:
    """Read route IDs selected for protection analysis from a text file.

    The function translates CLI arguments into the typed inputs expected by the
    underlying analysis module.
    """
    if path is None:
        return None
    route_ids = set()
    with path.open(encoding="utf-8") as file:
        for line in file:
            value = line.strip()
            if value:
                route_ids.add(value)
    return route_ids
