"""Append/replace routes while reusing verified, unchanged scientific evidence.

Serialization and support aggregation remain publication-wide. Chemistry
extraction and composite certification are restricted to changed route IDs.
"""

import hashlib
import json
from contextlib import ExitStack
from pathlib import Path

import ijson

from route_inspector.infrastructure.build_workspace import BuildWorkspace
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.infrastructure.publication import publish_directory_no_replace
from route_inspector.routes.disk_source import DiskRouteSource, _route_json
from route_inspector.workflows.requests import UpdateLibraryRoutesRequest


def _corpus(library, digest):
    corpora = library.manifest.reference_corpora
    if len(corpora) != 1:
        raise ValueError("route updates require one explicit source corpus per library")
    corpus = corpora[0]
    if corpus.get("input_sha256") != digest:
        raise ValueError("baseline library does not match --routes-json fingerprint")
    if "route_ids" not in corpus:
        raise ValueError(
            "baseline requires an explicit route roster, including empty routes"
        )
    ids = list(map(str, corpus["route_ids"]))
    if len(ids) != len(set(ids)) or len(ids) != corpus["route_count"]:
        raise ValueError("baseline route roster disagrees with its count")
    return corpus


def _changed_source(base, changes, output, mode):
    """Validate a sparse ID map; emit the merged source without renumbering."""
    with Path(changes).open("rb") as stream:
        if next(ijson.parse(stream), (None, None, None))[1] != "start_map":
            raise ValueError(
                "--changes-json must be an object keyed by explicit route IDs, not a list"
            )
    changed = {}
    with Path(changes).open("rb") as stream:
        for route_id, route in ijson.kvitems(stream, ""):
            if not route_id.strip() or route_id in changed:
                raise ValueError(f"empty or duplicate changed route ID: {route_id!r}")
            if not isinstance(route, dict) or route.get("type") != "mol":
                raise ValueError(f"changed route {route_id} must have a molecule root")
            exists = route_id in base
            if mode == "append" and exists:
                raise ValueError(
                    f"append refuses existing route ID {route_id}; use replace-library-routes"
                )
            if mode == "replace" and not exists:
                raise ValueError(f"replace requires existing route ID {route_id}")
            encoded = _route_json(route)
            previous = _route_json(base[route_id]) if exists else None
            changed[route_id] = {
                "before_sha256": hashlib.sha256(previous.encode()).hexdigest()
                if exists
                else None,
                "after_sha256": hashlib.sha256(encoded.encode()).hexdigest(),
                "changed": previous != encoded,
            }
            base.db.execute(
                "INSERT OR REPLACE INTO routes VALUES(?,?)", (route_id, encoded)
            )
    if not changed:
        raise ValueError("--changes-json contains no routes")
    with Path(output).open("w") as stream:
        stream.write("{")
        for i, (route_id, payload) in enumerate(
            base.db.execute("SELECT id,payload FROM routes ORDER BY id")
        ):
            if i:
                stream.write(",")
            stream.write(json.dumps(route_id) + ":" + payload)
        stream.write("}\n")
    # The source spool describes the immutable baseline, not this revision.
    base.db.rollback()
    return changed


def _reference_processor(args, library):
    from route_inspector.workflows.reference_library import (
        route_tactic_processor_from_config,
    )

    return route_tactic_processor_from_config(
        args.config,
        processing_profile=library.processing_profile,
        include_retro_bleu_bigrams=bool(
            library.manifest.supplementary_evidence.get("retro_bleu_bigrams")
        ),
        tactic_identity_version=library.tactic_identity_version,
    )


def _pg_processor_and_provider(args, library, *, classify=True):
    from route_inspector.chemistry.classification.providers import create_provider
    from route_inspector.protection.strategies.processor import RoutePGStrategyProcessor

    profile = library.manifest.processing_profile
    processor = RoutePGStrategyProcessor.from_profile(profile)
    classifier = profile.get("classifier", {})
    name = classifier.get("provider")
    if name == "none" or not classify:
        return processor, None
    if name not in {"reactionclassifier", "namerxn"}:
        raise ValueError("PG baseline has no reproducible classifier profile")
    provider = create_provider(
        name,
        reaction_classifier_path=args.reaction_classifier_path,
        namerxn_executable=args.namerxn_executable,
        label_policy=classifier.get("label_policy", "confirmed-or-neural"),
        torch_threads=classifier.get("torch_threads", 1),
        device=classifier.get("device", "cpu"),
    )
    if (provider.provider_version, provider.taxonomy_id) != (
        classifier.get("provider_version"),
        classifier.get("taxonomy"),
    ):
        raise ValueError("PG classifier version/taxonomy differs from baseline")
    return processor, provider


def _composite_extractor(args, library):
    from route_inspector.composite_rules.composite import CompositeRuleExtractor
    from route_inspector.composite_rules.families import IDENTITY_POLICY
    from route_inspector.composite_rules.library import _composite_extraction_profile
    from route_inspector.composite_rules.ring_breaking import (
        POLICY as RING_BREAKING_POLICY,
    )

    extractor = CompositeRuleExtractor.from_args(
        args, retain_query_cgr=False, max_cache_size=16
    )
    profile = library.manifest.construction_profile
    if _composite_extraction_profile(extractor) != profile.get("rule_extraction"):
        raise ValueError(
            "composite extraction configuration differs from baseline; supply its original --config"
        )
    if (
        profile.get("composite_identity") != IDENTITY_POLICY
        or profile.get("ring_breaking") != RING_BREAKING_POLICY
    ):
        raise ValueError(
            "composite identity/ring policy changed; a full rebuild is required"
        )
    return extractor


def _build_reference(args, job, old, corpus, source, digest, cohort, reused):
    from route_inspector.reference_library.build.streaming import (
        build_reference_library_to_directory,
    )

    path = job.publication / "reference"
    if not path.exists():
        processor = _reference_processor(args, old)
        work = job.root / "reference"
        build_reference_library_to_directory(
            ((key, source[key]) for key in sorted(cohort)),
            processor,
            output_dir=path,
            reference_id=corpus["dataset_id"],
            source_identity=corpus["source_identity"],
            corpus_sha256=digest,
            n_cpu=args.n_cpu,
            progress_interval=args.progress_interval,
            work_dir=work,
            resume=(work / "state.json").exists(),
            memory_budget_mb=args.memory_budget_mb,
            reuse_library=old,
            reuse_route_ids=reused,
        )
    return path


def _build_pg(args, job, old, corpus, digest, cohort, reused):
    from route_inspector.protection.strategies.construction import (
        build_pg_strategy_library,
    )

    path = job.publication / "pg"
    if not path.exists():
        processor, provider = _pg_processor_and_provider(
            args, old, classify=bool(cohort - reused)
        )
        work = job.root / "pg"
        build_pg_strategy_library(
            job.publication / "routes.json",
            path,
            processor,
            provider,
            reference_id=corpus["dataset_id"],
            source_identity=corpus["source_identity"],
            n_cpu=args.n_cpu,
            progress_interval=args.progress_interval,
            route_ids=cohort,
            classifier_metadata=old.manifest.processing_profile.get("classifier", {}),
            work_dir=work,
            resume=(work / "state.json").exists(),
            memory_budget_mb=args.memory_budget_mb,
            reuse_library=old,
            reuse_route_ids=reused,
        )
    return path


def _build_composites(args, job, old, reference, source, digest, reused):
    from route_inspector.composite_rules.composite import composite_extractor_args_dict
    from route_inspector.composite_rules.library import build_composite_library

    path = job.publication / "composites"
    if not path.exists():
        profile = old.manifest.construction_profile
        work = job.root / "composites"
        result = build_composite_library(
            reference,
            source,
            source_routes_sha256=digest,
            extractor=_composite_extractor(args, old),
            kinds=profile["kinds"],
            **{
                k: profile[k]
                for k in (
                    "max_replay_outcomes",
                    "max_variants",
                    "application_timeout_seconds",
                    "allow_ambiguous",
                )
            },
            ignore_errors=args.ignore_errors,
            n_cpu=args.n_cpu,
            extractor_args=composite_extractor_args_dict(args),
            progress_interval=args.progress_interval,
            work_dir=work,
            resume=(work / "constructions.sqlite").exists(),
            memory_budget_mb=args.memory_budget_mb,
            reuse_library=old,
            reuse_route_ids=reused,
        )
        try:
            # Schema 2 -> 3 changes publication storage, not certification.
            if {
                k: v
                for k, v in result.library.manifest.construction_profile.items()
                if k != "schema_version"
            } != {k: v for k, v in profile.items() if k != "schema_version"}:
                raise ValueError(
                    "composite certification policy differs from baseline; rebuild required"
                )
            result.library.save(path)
        finally:
            result.library.close()
    return path


def update_library_routes(args: UpdateLibraryRoutesRequest, *, mode):
    """Publish a complete new revision; never mutate an active library."""
    from route_inspector.composite_rules.library import CompositeDecompositionLibrary
    from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
    from route_inspector.protection.strategies.catalog import ReferencePGStrategyLibrary
    from route_inspector.reference_library import ReferenceTacticLibrary

    if mode not in {"append", "replace"}:
        raise ValueError("update mode must be append or replace")
    if not args.reference_library and not args.pg_library:
        raise ValueError("select --reference-library and/or --pg-library")
    if args.composite_library and not args.reference_library:
        raise ValueError("composite updates require their --reference-library")
    if args.gui_dataset and not all(
        (args.reference_library, args.pg_library, args.composite_library)
    ):
        raise ValueError(
            "GUI activation requires reference, PG and composite libraries together"
        )
    if args.gui_dataset:
        args.output_dir.resolve().relative_to(args.workspace.resolve())
    setup_runtime_cache_dirs()
    inputs = {
        "source": sha256_file(args.routes_json),
        "changes": sha256_file(args.changes_json),
    }
    classes = {
        "reference": ReferenceTacticLibrary,
        "pg": ReferencePGStrategyLibrary,
        "composites": CompositeDecompositionLibrary,
    }
    paths = {
        "reference": args.reference_library,
        "pg": args.pg_library,
        "composites": args.composite_library,
    }
    parents, corpora = {}, {}
    with ExitStack() as stack:
        libraries = {}
        for name, path in paths.items():
            if path is None:
                continue
            library = stack.enter_context(classes[name].load(path, verification="full"))
            libraries[name] = library
            parents[name] = {
                "library_id": library.library_id,
                "manifest_sha256": sha256_file(path / "manifest.json"),
            }
            if name != "composites":
                corpora[name] = _corpus(library, inputs["source"])
        if args.gui_dataset:
            from route_inspector.datasets.bindings import corpus_ids, dataset_bindings

            allowed = corpus_ids(args.gui_dataset)
            if any(c["dataset_id"] not in allowed for c in corpora.values()):
                raise ValueError("selected libraries belong to another GUI dataset")
            dataset_bindings(args.workspace, args.gui_dataset)
        if "composites" in libraries:
            composite = libraries["composites"]
            composite.assert_reference_library(libraries["reference"])
            if composite.manifest.source_routes_sha256 != inputs["source"]:
                raise ValueError("composite source fingerprint differs")
            expected = sum(
                libraries["reference"]
                .manifest.statistics["occurrences_by_kind"]
                .get(k, 0)
                for k in composite.manifest.construction_profile["kinds"]
            )
            if composite.manifest.statistics["constructions_seen"] != expected:
                raise ValueError(
                    "composite baseline is partial; use a complete baseline"
                )
        fingerprint = dict(
            builder="route-update-v1",
            mode=mode,
            inputs=inputs,
            parents=parents,
            config=sha256_file(args.config) if args.reference_library else None,
            ignore_errors=args.ignore_errors,
        )
        with BuildWorkspace(
            args.output_dir,
            work_dir=args.work_dir,
            resume=args.resume,
            memory_budget_mb=args.memory_budget_mb,
            fingerprint=fingerprint,
        ) as job:
            with DiskRouteSource(
                args.routes_json, job.root / "baseline.sqlite", inputs["source"]
            ) as base:
                audit = _changed_source(
                    base, args.changes_json, job.publication / "routes.json", mode
                )
                requested = set(audit)
                changed = {key for key, value in audit.items() if value["changed"]}
                cohorts, reused = {}, {}
                for name, corpus in corpora.items():
                    previous = set(map(str, corpus["route_ids"]))
                    if not previous <= set(base):
                        raise ValueError(
                            "library roster contains routes absent from source"
                        )
                    if mode == "replace" and not requested <= previous:
                        raise ValueError(
                            f"replacement routes outside {name} cohort: {sorted(requested - previous)}"
                        )
                    cohorts[name] = previous | (
                        requested if mode == "append" else set()
                    )
                    reused[name] = previous - changed
                digest = sha256_file(job.publication / "routes.json")
                updated_spool = job.root / "updated.sqlite"
                with DiskRouteSource(
                    job.publication / "routes.json", updated_spool, digest
                ) as source:
                    published = {}
                    if "reference" in libraries:
                        path = _build_reference(
                            args,
                            job,
                            libraries["reference"],
                            corpora["reference"],
                            source,
                            digest,
                            cohorts["reference"],
                            reused["reference"],
                        )
                        reference = stack.enter_context(
                            ReferenceTacticLibrary.load(path, verification="full")
                        )
                        published["reference"] = reference
                    if "pg" in libraries:
                        path = _build_pg(
                            args,
                            job,
                            libraries["pg"],
                            corpora["pg"],
                            digest,
                            cohorts["pg"],
                            reused["pg"],
                        )
                        published["pg"] = stack.enter_context(
                            ReferencePGStrategyLibrary.load(path, verification="full")
                        )
                    if "composites" in libraries:
                        path = _build_composites(
                            args,
                            job,
                            libraries["composites"],
                            reference,
                            source,
                            digest,
                            reused["reference"],
                        )
                        published["composites"] = stack.enter_context(
                            CompositeDecompositionLibrary.load(
                                path, verification="full"
                            )
                        )
                        published["composites"].assert_reference_library(reference)
                    for name in corpora:
                        actual = _corpus(published[name], digest)
                        if set(map(str, actual["route_ids"])) != cohorts[name]:
                            raise ValueError(
                                "updated library lost or introduced unrequested routes"
                            )
                    report = dict(
                        schema_version=1,
                        operation=mode,
                        parents=parents,
                        inputs=inputs,
                        source_sha256=digest,
                        route_count=len(source),
                        routes=audit,
                        libraries={
                            name: {
                                "path": name,
                                "library_id": lib.library_id,
                                "manifest_sha256": sha256_file(
                                    job.publication / name / "manifest.json"
                                ),
                                "statistics": dict(lib.manifest.statistics),
                            }
                            for name, lib in published.items()
                        },
                        reuse={
                            name: {
                                "reused_route_count": len(reused[name]),
                                "extracted_route_ids": sorted(
                                    cohorts[name] - reused[name]
                                ),
                            }
                            for name in cohorts
                        },
                    )
            if inputs != {
                "source": sha256_file(args.routes_json),
                "changes": sha256_file(args.changes_json),
            }:
                raise ValueError("source or changes file changed during update")
            for name, path in paths.items():
                if path and parents[name]["manifest_sha256"] != sha256_file(
                    path / "manifest.json"
                ):
                    raise ValueError("baseline manifest changed during update")
            (job.publication / "update.json").write_text(
                json.dumps(report, indent=2) + "\n"
            )
            job.checkpoint("verified")
            # Close SQLite readers before moving the complete revision (Windows too).
            stack.close()
            publish_directory_no_replace(job.publication, job.output)
            job.checkpoint("published")
    if args.gui_dataset:
        from route_inspector.datasets.bindings import activate_library_revision

        activate_library_revision(args.workspace, args.gui_dataset, args.output_dir)
    return args.output_dir
