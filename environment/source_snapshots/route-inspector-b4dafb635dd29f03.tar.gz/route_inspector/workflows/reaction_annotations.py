"""Persist source-bound NameRxn annotations without extracting reaction rules."""

import json
import shutil
import tempfile
from collections import Counter
from dataclasses import asdict
from pathlib import Path

from route_inspector.chemistry import canonical_unmapped_reaction_string
from route_inspector.chemistry.classification.common import (
    reconcile_batch_results,
    record_id,
)
from route_inspector.chemistry.classification.providers import (
    NameRxnProvider,
    ReactionRecord,
)
from route_inspector.chemistry.classification.taxonomy import taxonomy_names
from route_inspector.infrastructure.publication import publish_directory_no_replace
from route_inspector.infrastructure.text import read_json
from route_inspector.routes.access import (
    reaction_nodes,
    reaction_smiles_from_node,
    route_items,
)
from route_inspector.tactics.rrseq.statistics_io import record, write_json, write_tsv


def annotate_routes(
    *,
    routes_path,
    library_dir,
    executable,
    output_dir,
    dataset_id="n1",
    batch_size=100,
    provider=None,
    taxonomy_def=None,
):
    """Classify each unique forward reaction once, retaining every source node.

    A complete matching output is verified and reused. Partial or stale outputs
    are never treated as valid annotations. ``provider`` is an injectable test seam.
    """
    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    source = record(routes_path)
    library_manifest = record(Path(library_dir) / "manifest.json")
    manifest = read_json(Path(library_dir) / "manifest.json")
    corpora = manifest["reference_corpora"]
    if len(corpora) != 1 or corpora[0]["dataset_id"] != dataset_id:
        raise ValueError("requires one matching source corpus")
    corpus = corpora[0]
    source_identity = f"sha256:{source['sha256']}"
    if (
        corpus["input_sha256"] != source["sha256"]
        or corpus["source_identity"] != source_identity
    ):
        raise ValueError("route source differs from prebuilt library")
    provider = provider or NameRxnProvider(executable=executable)
    version = provider.provider_version
    if not version.startswith("3.2.") and version != "3.2":
        raise ValueError(f"expected NameRxn 3.2, found {version}")
    binary = (
        provider._ensure_executable()
        if isinstance(provider, NameRxnProvider)
        else executable
    )
    if taxonomy_def is None:
        root = Path(executable)
        candidates = [
            root / "namerxn.def",
            Path(binary).parent / "namerxn.def",
            Path(binary).parent.parent / "namerxn.def",
        ]
        taxonomy_def = next((p for p in candidates if p.is_file()), None)
    names = taxonomy_names(taxonomy_def)
    inputs = {
        "routes": source,
        "library_manifest": library_manifest,
        "executable": record(binary),
        "provider_version": version,
        "dataset_id": dataset_id,
        "source_identity": source_identity,
        "canonicalization": "RouteInspector canonical_unmapped_reaction_string",
        "implementation": record(__file__),
        "taxonomy_def": record(taxonomy_def) if taxonomy_def else None,
    }
    destination = Path(output_dir)
    if destination.exists():
        prior = read_json(destination / "manifest.json")
        if prior.get("status") != "complete" or prior.get("inputs") != inputs:
            raise ValueError(
                "existing annotation output is stale or incomplete; select a new output directory"
            )
        for name, descriptor in prior["artifacts"].items():
            current = record(destination / name)
            if any(current[k] != descriptor[k] for k in ("sha256", "size_bytes")):
                raise ValueError(f"existing annotation artifact differs: {name}")
        print(f"Reusing verified NameRxn annotations: {destination}", flush=True)
        return read_json(destination / "summary.json")
    items = list(route_items(read_json(routes_path)))
    ids = {str(key) for key, _ in items}
    if (
        len(ids) != len(items)
        or ids != set(map(str, corpus["route_ids"]))
        or len(ids) != corpus["route_count"]
    ):
        raise ValueError("source route roster mismatch")
    destination.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent)
    )
    errors = []
    try:
        rows = []
        unique = {}
        for key, root in items:
            for path, node in reaction_nodes(root):
                mapped = reaction_smiles_from_node(node)
                row = {
                    "dataset": dataset_id,
                    "source_identity": source_identity,
                    "route_id": str(key),
                    "reaction_node_path": path,
                    "mapped_reaction": mapped,
                    "classifier_input": "",
                    "record_id": "",
                    "error": "",
                }
                try:
                    canonical = canonical_unmapped_reaction_string(mapped)
                    if not canonical or ">>" not in canonical:
                        raise ValueError(
                            "canonical reaction is empty or not forward reaction SMILES"
                        )
                    identifier = record_id(canonical)
                    if (
                        identifier in unique
                        and unique[identifier].classifier_input != canonical
                    ):
                        raise ValueError("classifier record ID collision")
                    unique.setdefault(
                        identifier, ReactionRecord(identifier, mapped, canonical)
                    )
                    row.update(classifier_input=canonical, record_id=identifier)
                except Exception as exc:
                    row["error"] = str(exc)
                    errors.append(
                        {
                            "stage": "canonicalization",
                            "record_id": "",
                            "route_id": str(key),
                            "reaction_node_path": path,
                            "message": str(exc),
                        }
                    )
                rows.append(row)
        print(
            f"Prepared {len(unique):,} unique reactions from {len(rows):,} source nodes in {len(items):,} routes",
            flush=True,
        )
        records = sorted(unique.values(), key=lambda r: r.record_id)
        results = {}
        with (stage / "provider_results.jsonl").open("w") as handle:
            for offset in range(0, len(records), batch_size):
                batch = records[offset : offset + batch_size]
                received = provider.classify_many(batch, worker_chunksize=batch_size)
                reconciled = reconcile_batch_results(
                    [r.record_id for r in batch], received, ignore_errors=False
                )
                if set(reconciled.result_by_id) != {r.record_id for r in batch}:
                    raise ValueError(
                        "provider failed to return a result for every input reaction"
                    )
                for identifier, result in reconciled.result_by_id.items():
                    results[identifier] = result
                    handle.write(json.dumps(asdict(result), sort_keys=True) + "\n")
                    if result.error:
                        errors.append(
                            {
                                "stage": "provider",
                                "record_id": identifier,
                                "route_id": "",
                                "reaction_node_path": [],
                                "message": result.error,
                            }
                        )
                handle.flush()
                print(
                    f"Classified {min(offset + batch_size, len(records)):,}/{len(records):,} unique reactions",
                    flush=True,
                )
        counts = Counter()
        for row in rows:
            result = results.get(row["record_id"])
            accepted = bool(result and result.accepted and not result.error)
            row.update(
                provider="namerxn",
                provider_version=version,
                taxonomy="namerxn",
                tier3_code=result.tier3_code if accepted else "UNCLASSIFIED",
                tier3_name=(result.tier3_name or names.get(result.tier3_code, ""))
                if accepted
                else "UNCLASSIFIED",
                raw_code=result.raw_code if result else "",
                raw_name=result.raw_name if result else "",
                accepted="true" if accepted else "false",
                status=result.status if result else "error",
                error=row["error"] or (result.error if result else ""),
                diagnostics=dict(result.diagnostics) if result else {},
            )
            counts[row["status"]] += 1
        fields = [
            "dataset",
            "source_identity",
            "route_id",
            "reaction_node_path",
            "mapped_reaction",
            "classifier_input",
            "record_id",
            "provider",
            "provider_version",
            "taxonomy",
            "tier3_code",
            "tier3_name",
            "raw_code",
            "raw_name",
            "accepted",
            "status",
            "error",
            "diagnostics",
        ]
        write_tsv(stage / "reference_steps.tsv", rows, fields)
        write_tsv(
            stage / "errors.tsv",
            errors,
            ["stage", "record_id", "route_id", "reaction_node_path", "message"],
        )
        summary = {
            "route_count": len(items),
            "reaction_node_count": len(rows),
            "unique_classifier_inputs": len(unique),
            "classified_reaction_nodes": sum(r["accepted"] == "true" for r in rows),
            "unclassified_reaction_nodes": sum(r["accepted"] == "false" for r in rows),
            "error_reaction_nodes": sum(bool(r["error"]) for r in rows),
            "statuses": dict(counts),
            "error_count": len(errors),
            "provider_version": version,
        }
        write_json(stage / "summary.json", summary)
        for name in ("routes", "library_manifest", "executable", "implementation"):
            if record(inputs[name]["path"]) != inputs[name]:
                raise ValueError(f"input changed during annotation: {name}")
        if taxonomy_def and record(taxonomy_def) != inputs["taxonomy_def"]:
            raise ValueError("taxonomy definitions changed during annotation")
        artifacts = {
            p.name: {k: v for k, v in record(p).items() if k != "path"}
            for p in sorted(stage.iterdir())
            if p.is_file()
        }
        write_json(
            stage / "manifest.json",
            {
                "schema_version": 1,
                "status": "complete",
                "inputs": inputs,
                "artifacts": artifacts,
                "reaction_direction": "recorded forward source reaction",
                "deduplication": "complete canonical unmapped forward reaction string",
                "batch_size": batch_size,
            },
        )
        publish_directory_no_replace(stage, destination)
        return summary
    except Exception as exc:
        errors.append(
            {
                "stage": "workflow",
                "record_id": "",
                "route_id": "",
                "reaction_node_path": [],
                "message": str(exc),
            }
        )
        write_tsv(
            stage / "errors.tsv",
            errors,
            ["stage", "record_id", "route_id", "reaction_node_path", "message"],
        )
        write_json(
            stage / "manifest.json",
            {
                "schema_version": 1,
                "status": "failed",
                "inputs": inputs,
                "error": str(exc),
            },
        )
        failed = destination.parent / f"{stage.name}.failed"
        stage.rename(failed)
        raise RuntimeError(
            f"Annotation failed; diagnostics retained at {failed}"
        ) from exc
    finally:
        if stage.exists():
            shutil.rmtree(stage)
