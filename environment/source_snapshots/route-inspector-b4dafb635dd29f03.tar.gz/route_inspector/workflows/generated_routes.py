"""End-to-end counts-only inspection of mapping-certified generated routes."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from collections import Counter
from collections.abc import Iterable, Mapping
from dataclasses import replace
from itertools import islice
from pathlib import Path
from typing import Any

import route_inspector.routes.access as route_access
from route_inspector.context.enrichment import enrich_collection
from route_inspector.context.history import (
    CONTEXT_HISTORY_IDENTITY_VERSION,
    CONTEXT_HISTORY_SCHEMA_VERSION,
    DEFAULT_CONTEXT_POLICY,
    RouteContextHistory,
    annotate_routes_context_history,
    canonical_context_policy_sha256,
    context_history_summary,
    read_context_histories_jsonl,
    validate_route_context_history_integrity,
    write_context_histories_jsonl,
)
from route_inspector.context.occurrences import (
    OCCURRENCE_CONTEXT_REFERENCE_SCHEMA_VERSION,
    enrich_occurrence_records,
    occurrence_kind,
)
from route_inspector.context.protection_overlay import (
    _overlay_protection_events,
    _trace_protection_events,
    _write_protection_events_jsonl,
)
from route_inspector.context.vocabulary import load_functional_group_vocabulary
from route_inspector.datasets.paroutes.source_ids import PAROUTES_SOURCE_ID_ADAPTER
from route_inspector.infrastructure.artifacts import (
    dataset_prefix_from_path,
    write_json,
    write_standard_sidecars,
)
from route_inspector.infrastructure.hashing import sha256_file as _sha256
from route_inspector.infrastructure.paths import relative_path, resolve_existing_path
from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
from route_inspector.infrastructure.text import read_json, write_tsv
from route_inspector.protection.analysis import PROTECTION_TRACE_EVENT_SCHEMA_VERSION
from route_inspector.reference_library.context_index import (
    REFERENCE_INDEX_SCHEMA_VERSION,
    REFERENCE_SCOPE,
    RRSEQ_CONS_KIND,
    RRSEQ_GAP_KIND,
    T1_KIND,
    ReferenceIndex,
)
from route_inspector.reference_library.context_index.inspection import (
    GENERATED_INSPECTION_SCHEMA_VERSION,
    deterministic_jsonl,
    evidence_summary_row,
    match_generated_occurrence,
)
from route_inspector.reference_library.context_index.models import canonical_json
from route_inspector.routes.validation import (
    RouteMappingValidationError,
    validate_routes_mapping,
    write_route_mapping_validation,
)
from route_inspector.rules.extraction import SynPlannerRuleExtractor
from route_inspector.rules.occurrences import (
    SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
    SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION,
)
from route_inspector.tactics.rrseq.gapped import (
    RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION,
)
from route_inspector.tactics.rrseq.naming import (
    RRSEQ_CONS_KIND as RRSEQ_CONS_SEQUENCE_MODE,
)
from route_inspector.tactics.rrseq.naming import (
    RRSEQ_GAP_KIND as RRSEQ_GAP_SEQUENCE_MODE,
)
from route_inspector.tactics.rrseq.occurrences import (
    RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION,
)
from route_inspector.tactics.rrseq.processing import process_route_for_rrseqs

_OCCURRENCE_PAYLOAD_SCHEMA_VERSIONS = {
    T1_KIND: SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION,
    RRSEQ_CONS_KIND: RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION,
    RRSEQ_GAP_KIND: RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION,
}
_OCCURRENCE_IDENTITY_VERSIONS = {
    T1_KIND: SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_CONS_KIND: RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_GAP_KIND: RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION,
}


_COUNT_UNITS = ("occurrence_count", "route_count", "source_document_count")
_EVIDENCE_LEVELS = ("base", "local", "joint_containment", "joint_exact")
EVIDENCE_TSV_FIELDS = (
    "occurrence_kind",
    "occurrence_id",
    "dataset_id",
    "source_identity",
    "route_id",
    "reaction_node_paths_json",
    "base_query_cgr_keys_json",
    "local_context_query_cgr_keys_json",
    "joint_context_tokens_json",
    "certified_consecutive_composite_ids_json",
    "analysis_only",
    "protection_site_count",
    *(f"{level}_{unit}" for level in _EVIDENCE_LEVELS for unit in _COUNT_UNITS),
    "factorability_reference_occurrence_count",
    "factorability_certified_reference_count",
)
PROTECTION_TSV_FIELDS = (
    "occurrence_kind",
    "occurrence_id",
    "dataset_id",
    "source_identity",
    "route_id",
    "lineage_id",
    "family_id",
    "site_token",
    "generated_protection_state",
    "pg_type",
    "protection_event_ids_json",
    *(
        f"{state}_{unit}"
        for state in ("protected", "unprotected")
        for unit in _COUNT_UNITS
    ),
    "protected_references_json",
    "unprotected_references_json",
)


def _canonical_config_hash(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        value = json.loads(text)
    else:
        try:
            import yaml
        except ImportError as exc:  # pragma: no cover - runtime dependency
            raise RuntimeError(
                "PyYAML is required to inspect generated routes"
            ) from exc
        value = yaml.safe_load(text)
    payload = canonical_json({} if value is None else value)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _limited_collection(collection: Any, limit: int | None) -> Any:
    if limit is None:
        return collection
    if limit < 0:
        raise ValueError("--limit must be non-negative")
    items = list(islice(route_access.route_items(collection), limit))
    if isinstance(collection, list):
        return [route for _route_id, route in items]
    return {route_id: route for route_id, route in items}


def _atomic_write_text(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
        os.replace(temporary, path)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    return path


def _load_or_build_histories(
    collection: Any,
    *,
    dataset_id: str,
    source_identity: str,
    persisted_path: Path,
    reuse_path: Path | None,
    context_policy_sha256: str,
) -> tuple[tuple[RouteContextHistory, ...], tuple[dict[str, Any], ...], Path]:
    vocabulary = load_functional_group_vocabulary()
    if reuse_path is not None:
        histories = read_context_histories_jsonl(
            reuse_path,
            validate_vocabulary=True,
            vocabulary=vocabulary,
        )
        errors: tuple[dict[str, Any], ...] = ()
        history_path = reuse_path
    else:
        annotation = annotate_routes_context_history(
            collection,
            dataset_id=dataset_id,
            source_identity=source_identity,
            vocabulary=vocabulary,
            validate_mapping=False,
            context_policy_sha256=context_policy_sha256,
        )
        # Dataset-level strict validation has already succeeded.  Mark the
        # immutable records with that fact without repeating route chemistry.
        histories = tuple(
            replace(history, mapping_validated=True) for history in annotation.histories
        )
        errors = annotation.errors
        history_path = write_context_histories_jsonl(persisted_path, histories)

    routes_by_id = {
        str(route_id): route for route_id, route in route_access.route_items(collection)
    }
    expected_routes = set(routes_by_id)
    matching_histories = [
        history
        for history in histories
        if history.dataset_id == dataset_id
        and history.source_identity == source_identity
    ]
    actual_routes = {history.route_id for history in matching_histories}
    coverage_errors = list(errors)
    for route_id in sorted(expected_routes - actual_routes):
        coverage_errors.append(
            {
                "dataset_id": dataset_id,
                "route_id": route_id,
                "stage": "context_history_coverage",
                "error_type": "MissingRouteContextHistory",
                "message": "no context history was available for this route",
            }
        )
    for route_id in sorted(actual_routes - expected_routes):
        coverage_errors.append(
            {
                "dataset_id": dataset_id,
                "route_id": route_id,
                "stage": "context_history_coverage",
                "error_type": "UnexpectedRouteContextHistory",
                "message": "context history does not belong to the generated input",
            }
        )
    if len(histories) != len(matching_histories):
        coverage_errors.append(
            {
                "dataset_id": dataset_id,
                "route_id": "*",
                "stage": "context_history_coverage",
                "error_type": "ContextHistoryProvenanceMismatch",
                "message": (
                    "context history contains records with different dataset or "
                    "source provenance"
                ),
            }
        )
    counts = Counter(history.route_id for history in matching_histories)
    for route_id in sorted(route_id for route_id, count in counts.items() if count > 1):
        coverage_errors.append(
            {
                "dataset_id": dataset_id,
                "route_id": route_id,
                "stage": "context_history_coverage",
                "error_type": "DuplicateRouteContextHistory",
                "message": f"context history occurs {counts[route_id]} times",
            }
        )
    for history in matching_histories:
        route = routes_by_id.get(history.route_id)
        if route is None:
            continue
        try:
            validate_route_context_history_integrity(
                history,
                route,
                expected_context_policy_sha256=context_policy_sha256,
            )
        except Exception as exc:
            coverage_errors.append(
                {
                    "dataset_id": dataset_id,
                    "route_id": history.route_id,
                    "stage": "context_history_integrity",
                    "error_type": type(exc).__qualname__,
                    "message": str(exc),
                }
            )
    return histories, tuple(coverage_errors), history_path


def _with_generated_provenance(
    occurrence: Mapping[str, Any],
    *,
    dataset_id: str,
    source_identity: str,
    route_id: Any,
) -> dict[str, Any]:
    return {
        **occurrence,
        "dataset_id": dataset_id,
        "source_identity": source_identity,
        "route_id": str(route_id),
    }


def _extract_generated_occurrences(
    collection: Any,
    *,
    args: Any,
    dataset_id: str,
    source_identity: str,
) -> tuple[dict[str, list[dict[str, Any]]], list[dict[str, Any]], dict[str, int]]:
    """Extract t1/cons/gap with one shared reaction-rule cache."""

    extractor = SynPlannerRuleExtractor.from_args(args)
    occurrences: dict[str, list[dict[str, Any]]] = {
        T1_KIND: [],
        RRSEQ_CONS_KIND: [],
        RRSEQ_GAP_KIND: [],
    }
    errors: list[dict[str, Any]] = []
    totals: Counter[str] = Counter()
    for route_index, (route_id, route) in enumerate(
        route_access.route_items(collection), start=1
    ):
        route_results: dict[str, dict[str, Any]] = {}
        for kind, sequence_mode in (
            (RRSEQ_CONS_KIND, RRSEQ_CONS_SEQUENCE_MODE),
            (RRSEQ_GAP_KIND, RRSEQ_GAP_SEQUENCE_MODE),
        ):
            try:
                result = process_route_for_rrseqs(
                    route_id,
                    route,
                    extractor,
                    min_length=int(args.min_length),
                    max_length=args.max_length,
                    store_route_without_rrseqs=False,
                    sequence_mode=sequence_mode,
                    source_identity=source_identity,
                    dataset_id=dataset_id,
                    source_id_adapter=str(
                        getattr(
                            args,
                            "source_id_adapter",
                            PAROUTES_SOURCE_ID_ADAPTER,
                        )
                    ),
                )
            except Exception as exc:
                errors.append(
                    {
                        "dataset_id": dataset_id,
                        "route_id": str(route_id),
                        "stage": f"extract_{kind}",
                        "error_type": type(exc).__qualname__,
                        "message": str(exc),
                    }
                )
                continue
            route_results[kind] = result
            stats = result["stats"]
            totals[f"{kind}_reactions_seen"] += int(stats.reactions_seen)
            totals[f"{kind}_cache_hits"] += int(stats.reaction_rule_cache_hits)
            totals[f"{kind}_cache_misses"] += int(stats.reaction_rule_cache_misses)
            totals[f"{kind}_skipped_reactions"] += int(stats.skipped_reactions)
            if result.get("error"):
                errors.append(dict(result["error"]))

        cons_result = route_results.get(RRSEQ_CONS_KIND)
        if cons_result is not None:
            t1_records = [
                _with_generated_provenance(
                    record,
                    dataset_id=dataset_id,
                    source_identity=source_identity,
                    route_id=route_id,
                )
                for record in cons_result["single_rule_occurrences"]
            ]
            occurrences[T1_KIND].extend(t1_records)
            occurrences[RRSEQ_CONS_KIND].extend(
                _with_generated_provenance(
                    record,
                    dataset_id=dataset_id,
                    source_identity=source_identity,
                    route_id=route_id,
                )
                for record in cons_result["rrseq_cons_occurrences"]
            )
            expected_reactions = route_access.count_reaction_nodes(route)
            if len(t1_records) != expected_reactions:
                errors.append(
                    {
                        "dataset_id": dataset_id,
                        "route_id": str(route_id),
                        "stage": "exact_single_rule_coverage",
                        "error_type": "IncompleteRuleExtraction",
                        "message": (
                            f"extracted {len(t1_records)} exact t1 occurrences for "
                            f"{expected_reactions} reaction nodes"
                        ),
                    }
                )
        gap_result = route_results.get(RRSEQ_GAP_KIND)
        if gap_result is not None:
            occurrences[RRSEQ_GAP_KIND].extend(
                _with_generated_provenance(
                    record,
                    dataset_id=dataset_id,
                    source_identity=source_identity,
                    route_id=route_id,
                )
                for record in gap_result["rrseq_gap_occurrences"]
            )
        if args.progress_interval and route_index % args.progress_interval == 0:
            print(
                "[inspect-generated-routes] "
                f"extracted routes={route_index} cache={len(extractor.cache)}",
                flush=True,
            )

    for records in occurrences.values():
        records.sort(key=lambda value: str(value.get("occurrence_id") or ""))
    totals["unique_reactions_cached"] = len(extractor.cache)
    return occurrences, errors, dict(sorted(totals.items()))


def _protection_rows(record: Mapping[str, Any]) -> Iterable[dict[str, Any]]:
    for site in record.get("protection_precedents", ()):
        evidence = site["evidence"]
        row = {
            "occurrence_kind": record["occurrence_kind"],
            "occurrence_id": record["occurrence_id"],
            "dataset_id": record["dataset_id"],
            "source_identity": record["source_identity"],
            "route_id": record["route_id"],
            "lineage_id": site["lineage_id"],
            "family_id": site["family_id"],
            "site_token": site["site_token"],
            "generated_protection_state": site["generated_protection_state"],
            "pg_type": site["pg_type"],
            "protection_event_ids_json": canonical_json(site["protection_event_ids"]),
        }
        for state in ("protected", "unprotected"):
            match = evidence[state]
            for unit, count in match["counts"].items():
                row[f"{state}_{unit}"] = int(count)
            row[f"{state}_references_json"] = canonical_json(match["provenance"])
        yield row


def _write_table(
    path: Path,
    rows: Iterable[Mapping[str, Any]],
    *,
    fieldnames: Iterable[str],
) -> Path:
    records = [dict(row) for row in rows]
    fields = list(fieldnames)
    unexpected = sorted(
        {key for record in records for key in record if key not in fields}
    )
    if unexpected:
        raise ValueError(
            f"TSV rows contain fields absent from the declared schema: {unexpected}"
        )
    write_tsv(path, fields, records)
    return path


def _failure_sidecars(
    *,
    output_dir: Path,
    status: str,
    dataset_id: str,
    source_identity: str,
    input_paths: Iterable[Path],
    config_path: Path,
    mapping_summary: Mapping[str, Any],
    mapping_path: Path,
    errors: Iterable[Mapping[str, Any]],
    args: Any,
    output_files: Mapping[str, Path] | None = None,
    extra: Mapping[str, Any] | None = None,
) -> None:
    input_paths = tuple(input_paths)
    errors = tuple(dict(error) for error in errors)
    outputs = {"mapping_validation": mapping_path, **(output_files or {})}
    input_hashes = {relative_path(path): _sha256(path) for path in input_paths}
    summary = {
        "command_name": "inspect-generated-routes",
        "status": status,
        "reference_scope": REFERENCE_SCOPE,
        "dataset_id": dataset_id,
        "source_identity": source_identity,
        "mapping_validation": dict(mapping_summary),
        "errors": len(errors),
        "input_sha256": input_hashes,
        "output_files": {
            key: relative_path(path) for key, path in sorted(outputs.items())
        },
        **dict(extra or {}),
    }
    sidecars = write_standard_sidecars(
        output_dir,
        command_name="inspect-generated-routes",
        summary=summary,
        errors=errors,
        input_files=input_paths,
        output_files=outputs,
        config_path=config_path,
        cli_args=args,
        extra_manifest={
            "reference_scope": REFERENCE_SCOPE,
            "mapping_validation": dict(mapping_summary),
            "input_sha256": input_hashes,
            **dict(extra or {}),
        },
    )
    summary["sidecar_files"] = sidecars
    write_json(output_dir / "summary.json", summary)


def _run_generated_route_inspection(args: Any) -> int:
    """Run strict generated-route evidence retrieval without scalar judgments."""

    setup_runtime_cache_dirs()
    routes_path = resolve_existing_path(args.routes_json)
    reference_path = resolve_existing_path(args.reference_index)
    config_path = resolve_existing_path(args.config)
    reuse_history_path = (
        None
        if args.context_history is None
        else resolve_existing_path(args.context_history)
    )
    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    dataset_id = str(args.dataset_id or dataset_prefix_from_path(routes_path))
    source_identity = str(args.source_identity or routes_path.resolve())
    collection = _limited_collection(read_json(routes_path), args.limit)
    input_paths = [routes_path, reference_path, config_path]
    if reuse_history_path is not None:
        input_paths.append(reuse_history_path)

    mapping_result = validate_routes_mapping(collection, dataset=dataset_id)
    mapping_path = output_dir / "mapping_validation.tsv"
    mapping_summary = write_route_mapping_validation(mapping_result, mapping_path)
    if mapping_result.records:
        _failure_sidecars(
            output_dir=output_dir,
            status="failed_mapping_validation",
            dataset_id=dataset_id,
            source_identity=source_identity,
            input_paths=input_paths,
            config_path=config_path,
            mapping_summary=mapping_summary,
            mapping_path=mapping_path,
            errors=mapping_result.records,
            args=args,
        )
        raise RouteMappingValidationError(
            f"generated routes failed strict mapping validation; see {mapping_path}"
        )

    try:
        vocabulary = load_functional_group_vocabulary()
        config_hash = _canonical_config_hash(config_path)
        context_policy_hash = canonical_context_policy_sha256(DEFAULT_CONTEXT_POLICY)
    except Exception as exc:
        failure = {
            "dataset_id": dataset_id,
            "route_id": "*",
            "stage": "inspection_configuration",
            "error_type": type(exc).__qualname__,
            "message": str(exc),
        }
        _failure_sidecars(
            output_dir=output_dir,
            status="failed_configuration_validation",
            dataset_id=dataset_id,
            source_identity=source_identity,
            input_paths=input_paths,
            config_path=config_path,
            mapping_summary=mapping_summary,
            mapping_path=mapping_path,
            errors=(failure,),
            args=args,
        )
        raise

    expected_metadata = {
        "schema_version": REFERENCE_INDEX_SCHEMA_VERSION,
        "reference_scope": REFERENCE_SCOPE,
        "vocabulary_version": vocabulary.version_id,
        "vocabulary_hash": vocabulary.manifest_sha256,
        "config_hash": config_hash,
    }
    metadata_extra = {
        "reference_index_schema_version": REFERENCE_INDEX_SCHEMA_VERSION,
        "generated_inspection_schema_version": GENERATED_INSPECTION_SCHEMA_VERSION,
        "context_history_schema_version": CONTEXT_HISTORY_SCHEMA_VERSION,
        "context_history_identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
        "occurrence_context_reference_schema_version": (
            OCCURRENCE_CONTEXT_REFERENCE_SCHEMA_VERSION
        ),
        "occurrence_payload_schema_versions": _OCCURRENCE_PAYLOAD_SCHEMA_VERSIONS,
        "occurrence_identity_versions": _OCCURRENCE_IDENTITY_VERSIONS,
        "protection_trace_event_schema_version": (
            PROTECTION_TRACE_EVENT_SCHEMA_VERSION
        ),
        "vocabulary_version": vocabulary.version_id,
        "vocabulary_source_sha256": vocabulary.source_sha256,
        "vocabulary_manifest_sha256": vocabulary.manifest_sha256,
        "config_hash": config_hash,
        "context_policy_sha256": context_policy_hash,
    }
    try:
        with ReferenceIndex(reference_path) as index:
            metadata = index.metadata
        mismatches = {
            key: {"expected": expected, "actual": metadata.get(key)}
            for key, expected in expected_metadata.items()
            if metadata.get(key) != expected
        }
        input_schema_versions = metadata.get("input_schema_versions")
        actual_context_schema = (
            input_schema_versions.get("context_history")
            if isinstance(input_schema_versions, Mapping)
            else None
        )
        if actual_context_schema != CONTEXT_HISTORY_SCHEMA_VERSION:
            mismatches["input_schema_versions.context_history"] = {
                "expected": CONTEXT_HISTORY_SCHEMA_VERSION,
                "actual": actual_context_schema,
            }
        metadata_index_extra = metadata.get("extra")
        actual_context_policy = (
            metadata_index_extra.get("context_policy_sha256")
            if isinstance(metadata_index_extra, Mapping)
            else None
        )
        if actual_context_policy != context_policy_hash:
            mismatches["extra.context_policy_sha256"] = {
                "expected": context_policy_hash,
                "actual": actual_context_policy,
            }
        if mismatches:
            raise ValueError(
                "reference index metadata is incompatible with generated "
                f"inspection: {canonical_json(mismatches)}"
            )
    except Exception as exc:
        failure = {
            "dataset_id": dataset_id,
            "route_id": "*",
            "stage": "reference_index_metadata",
            "error_type": type(exc).__qualname__,
            "message": str(exc),
        }
        _failure_sidecars(
            output_dir=output_dir,
            status="failed_reference_index_validation",
            dataset_id=dataset_id,
            source_identity=source_identity,
            input_paths=input_paths,
            config_path=config_path,
            mapping_summary=mapping_summary,
            mapping_path=mapping_path,
            errors=(failure,),
            args=args,
            extra=metadata_extra,
        )
        raise

    try:
        histories, history_errors, history_path = _load_or_build_histories(
            collection,
            dataset_id=dataset_id,
            source_identity=source_identity,
            persisted_path=output_dir / "context_history.jsonl.gz",
            reuse_path=reuse_history_path,
            context_policy_sha256=context_policy_hash,
        )
    except Exception as exc:
        failure = {
            "dataset_id": dataset_id,
            "route_id": "*",
            "stage": "context_history_annotation",
            "error_type": type(exc).__qualname__,
            "message": str(exc),
        }
        partial_history = output_dir / "context_history.jsonl.gz"
        partial_outputs = (
            {"context_history": partial_history}
            if reuse_history_path is None and partial_history.is_file()
            else {}
        )
        _failure_sidecars(
            output_dir=output_dir,
            status="failed_context_annotation",
            dataset_id=dataset_id,
            source_identity=source_identity,
            input_paths=input_paths,
            config_path=config_path,
            mapping_summary=mapping_summary,
            mapping_path=mapping_path,
            errors=(failure,),
            args=args,
            output_files=partial_outputs,
            extra=metadata_extra,
        )
        raise

    if history_errors:
        partial_outputs = (
            {"context_history": history_path} if reuse_history_path is None else {}
        )
        _failure_sidecars(
            output_dir=output_dir,
            status="failed_context_annotation",
            dataset_id=dataset_id,
            source_identity=source_identity,
            input_paths=input_paths,
            config_path=config_path,
            mapping_summary=mapping_summary,
            mapping_path=mapping_path,
            errors=history_errors,
            args=args,
            output_files=partial_outputs,
            extra=metadata_extra,
        )
        raise RuntimeError(
            "generated-route context annotation did not cover every route; see "
            f"{output_dir / 'errors.tsv'}"
        )

    trace_event_path = output_dir / "protection_trace_events.jsonl"
    try:
        if reuse_history_path is None:
            protection_events = _trace_protection_events(collection)
            histories = _overlay_protection_events(histories, protection_events)
            history_path = write_context_histories_jsonl(
                output_dir / "context_history.jsonl.gz",
                histories,
            )
        else:
            protection_events = tuple(
                event
                for history in histories
                for event in history.protection_trace_events
            )
        _write_protection_events_jsonl(trace_event_path, protection_events)
    except Exception as exc:
        failure = {
            "dataset_id": dataset_id,
            "route_id": "*",
            "stage": "protection_context_annotation",
            "error_type": type(exc).__qualname__,
            "message": str(exc),
        }
        partial_outputs: dict[str, Path] = {}
        candidate_history = output_dir / "context_history.jsonl.gz"
        if candidate_history.is_file():
            partial_outputs["context_history"] = candidate_history
        if trace_event_path.is_file():
            partial_outputs["protection_trace_events"] = trace_event_path
        _failure_sidecars(
            output_dir=output_dir,
            status="failed_context_annotation",
            dataset_id=dataset_id,
            source_identity=source_identity,
            input_paths=input_paths,
            config_path=config_path,
            mapping_summary=mapping_summary,
            mapping_path=mapping_path,
            errors=(failure,),
            args=args,
            output_files=partial_outputs,
            extra=metadata_extra,
        )
        raise
    history_by_route = {history.route_id: history for history in histories}

    occurrences, extraction_errors, extraction_stats = _extract_generated_occurrences(
        collection,
        args=args,
        dataset_id=dataset_id,
        source_identity=source_identity,
    )
    try:
        enriched_occurrences, context_reference_counts = enrich_occurrence_records(
            (
                occurrence
                for kind in (T1_KIND, RRSEQ_CONS_KIND, RRSEQ_GAP_KIND)
                for occurrence in occurrences[kind]
            ),
            histories,
            dataset_id=dataset_id,
            source_identity=source_identity,
        )
        occurrences = {
            kind: [
                occurrence
                for occurrence in enriched_occurrences
                if occurrence_kind(occurrence) == kind
            ]
            for kind in (T1_KIND, RRSEQ_CONS_KIND, RRSEQ_GAP_KIND)
        }
    except Exception as exc:
        failure = {
            "dataset_id": dataset_id,
            "route_id": "*",
            "stage": "occurrence_context_enrichment",
            "error_type": type(exc).__qualname__,
            "message": str(exc),
        }
        _failure_sidecars(
            output_dir=output_dir,
            status="failed_occurrence_context_enrichment",
            dataset_id=dataset_id,
            source_identity=source_identity,
            input_paths=input_paths,
            config_path=config_path,
            mapping_summary=mapping_summary,
            mapping_path=mapping_path,
            errors=(*extraction_errors, failure),
            args=args,
            output_files={
                "context_history": history_path,
                "protection_trace_events": trace_event_path,
            },
            extra={
                **metadata_extra,
                "extraction": extraction_stats,
            },
        )
        raise
    errors = [*history_errors, *extraction_errors]
    matching_errors: list[dict[str, Any]] = []
    records_by_kind: dict[str, list[dict[str, Any]]] = {
        T1_KIND: [],
        RRSEQ_CONS_KIND: [],
        RRSEQ_GAP_KIND: [],
    }
    with ReferenceIndex(reference_path) as index:
        for kind in (T1_KIND, RRSEQ_CONS_KIND, RRSEQ_GAP_KIND):
            for occurrence in occurrences[kind]:
                route_id = str(occurrence["route_id"])
                try:
                    records_by_kind[kind].append(
                        match_generated_occurrence(
                            index,
                            occurrence,
                            history_by_route[route_id],
                            occurrence_kind=kind,
                        )
                    )
                except Exception as exc:
                    failure = {
                        "dataset_id": dataset_id,
                        "route_id": route_id,
                        "occurrence_id": occurrence.get("occurrence_id", ""),
                        "stage": f"match_{kind}",
                        "error_type": type(exc).__qualname__,
                        "message": str(exc),
                    }
                    matching_errors.append(failure)
                    errors.append(failure)

    output_files: dict[str, Path] = {
        "mapping_validation": mapping_path,
        "context_history": history_path,
        "protection_trace_events": trace_event_path,
    }
    for kind, records_for_kind in records_by_kind.items():
        exact_path = _atomic_write_text(
            output_dir / f"{kind}_evidence.jsonl",
            deterministic_jsonl(records_for_kind),
        )
        table_path = _write_table(
            output_dir / f"{kind}_evidence.tsv",
            (evidence_summary_row(record) for record in records_for_kind),
            fieldnames=EVIDENCE_TSV_FIELDS,
        )
        occurrence_path = output_dir / f"{kind}_occurrences.json"
        write_json(occurrence_path, occurrences[kind])
        output_files[f"{kind}_evidence_jsonl"] = exact_path
        output_files[f"{kind}_evidence_tsv"] = table_path
        output_files[f"{kind}_occurrences"] = occurrence_path

    all_records = [
        record
        for kind in (T1_KIND, RRSEQ_CONS_KIND, RRSEQ_GAP_KIND)
        for record in records_by_kind[kind]
    ]
    protection_path = _write_table(
        output_dir / "protection_precedents.tsv",
        (row for record in all_records for row in _protection_rows(record)),
        fieldnames=PROTECTION_TSV_FIELDS,
    )
    output_files["protection_precedents"] = protection_path
    if args.write_enriched_routes:
        enriched_path = output_dir / "enriched_routes.json"
        write_json(
            enriched_path,
            enrich_collection(collection, history_by_route),
        )
        output_files["enriched_routes"] = enriched_path

    support = {
        level: sum(
            int(record["evidence"][level]["counts"]["occurrence_count"] > 0)
            for record in all_records
            if record["evidence"].get(level) is not None
        )
        for level in ("base", "local", "joint_containment", "joint_exact")
    }
    input_hashes = {relative_path(path): _sha256(path) for path in input_paths}
    summary = {
        "command_name": "inspect-generated-routes",
        "status": (
            "failed_incomplete_evidence"
            if extraction_errors or matching_errors
            else "completed"
        ),
        "reference_scope": REFERENCE_SCOPE,
        "dataset_id": dataset_id,
        "source_identity": source_identity,
        "routes_seen": mapping_result.routes_seen,
        "reactions_seen": mapping_result.reactions_seen,
        "mapping_validation": mapping_summary,
        "context_history": context_history_summary(histories),
        "occurrences": {
            kind: len(records) for kind, records in records_by_kind.items()
        },
        "occurrences_extracted": {
            kind: len(records) for kind, records in occurrences.items()
        },
        "occurrences_with_support": support,
        "protection_sites": sum(
            len(record["protection_precedents"]) for record in all_records
        ),
        "protection_trace_events": len(protection_events),
        "protection_trace_event_schema_version": (
            PROTECTION_TRACE_EVENT_SCHEMA_VERSION
        ),
        "extraction": extraction_stats,
        "errors": len(errors),
        "reference_index_schema_version": REFERENCE_INDEX_SCHEMA_VERSION,
        "generated_inspection_schema_version": GENERATED_INSPECTION_SCHEMA_VERSION,
        "context_history_schema_version": CONTEXT_HISTORY_SCHEMA_VERSION,
        "context_history_identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
        "occurrence_context_reference_schema_version": (
            OCCURRENCE_CONTEXT_REFERENCE_SCHEMA_VERSION
        ),
        "occurrence_payload_schema_versions": _OCCURRENCE_PAYLOAD_SCHEMA_VERSIONS,
        "occurrence_identity_versions": _OCCURRENCE_IDENTITY_VERSIONS,
        "occurrence_context_references": context_reference_counts,
        "vocabulary_version": vocabulary.version_id,
        "vocabulary_source_sha256": vocabulary.source_sha256,
        "vocabulary_manifest_sha256": vocabulary.manifest_sha256,
        "config_hash": config_hash,
        "context_policy_sha256": context_policy_hash,
        "input_sha256": input_hashes,
        "output_files": {
            key: relative_path(path) for key, path in sorted(output_files.items())
        },
    }
    sidecars = write_standard_sidecars(
        output_dir,
        command_name="inspect-generated-routes",
        summary=summary,
        errors=errors,
        input_files=input_paths,
        output_files=output_files,
        config_path=config_path,
        cli_args=args,
        extra_manifest={
            "reference_scope": REFERENCE_SCOPE,
            "mapping_validation": mapping_summary,
            "reference_index_schema_version": REFERENCE_INDEX_SCHEMA_VERSION,
            "generated_inspection_schema_version": GENERATED_INSPECTION_SCHEMA_VERSION,
            "context_history_schema_version": CONTEXT_HISTORY_SCHEMA_VERSION,
            "context_history_identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
            "occurrence_context_reference_schema_version": (
                OCCURRENCE_CONTEXT_REFERENCE_SCHEMA_VERSION
            ),
            "occurrence_payload_schema_versions": (_OCCURRENCE_PAYLOAD_SCHEMA_VERSIONS),
            "occurrence_identity_versions": _OCCURRENCE_IDENTITY_VERSIONS,
            "protection_trace_event_schema_version": (
                PROTECTION_TRACE_EVENT_SCHEMA_VERSION
            ),
            "vocabulary_version": vocabulary.version_id,
            "vocabulary_source_sha256": vocabulary.source_sha256,
            "vocabulary_manifest_sha256": vocabulary.manifest_sha256,
            "config_hash": config_hash,
            "context_policy_sha256": context_policy_hash,
            "input_sha256": input_hashes,
        },
    )
    summary["sidecar_files"] = sidecars
    write_json(output_dir / "summary.json", summary)
    print(json.dumps(summary, indent=2), flush=True)
    if extraction_errors or matching_errors:
        raise RuntimeError(
            "generated-route extraction or evidence matching was incomplete; see "
            f"{output_dir / 'errors.tsv'}"
        )
    return 0


def run_generated_route_inspection(args: Any) -> int:
    """Run inspection and retain standard sidecars for preflight failures."""

    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    try:
        return _run_generated_route_inspection(args)
    except Exception as exc:
        standard_paths = tuple(
            output_dir / name
            for name in ("summary.json", "errors.tsv", "manifest.json")
        )
        if any(path.exists() for path in standard_paths):
            raise
        raw_values = (
            getattr(args, "routes_json", None),
            getattr(args, "reference_index", None),
            getattr(args, "config", None),
            getattr(args, "context_history", None),
        )
        input_paths = tuple(
            Path(value).expanduser()
            for value in raw_values
            if value is not None and Path(value).expanduser().is_file()
        )
        routes_value = getattr(args, "routes_json", "")
        routes_path = (
            Path(routes_value).expanduser() if routes_value else Path("routes")
        )
        dataset_id = str(
            getattr(args, "dataset_id", None) or dataset_prefix_from_path(routes_path)
        )
        source_identity = str(
            getattr(args, "source_identity", None) or routes_path.resolve()
        )
        config_value = getattr(args, "config", None)
        config_path = (
            Path(config_value).expanduser()
            if config_value is not None and Path(config_value).expanduser().is_file()
            else None
        )
        error = {
            "dataset_id": dataset_id,
            "route_id": "*",
            "stage": "preflight_inputs",
            "error_type": type(exc).__qualname__,
            "message": str(exc),
        }
        summary = {
            "command_name": "inspect-generated-routes",
            "status": "failed_preflight",
            "reference_scope": REFERENCE_SCOPE,
            "dataset_id": dataset_id,
            "source_identity": source_identity,
            "errors": 1,
            "output_files": {},
        }
        write_standard_sidecars(
            output_dir,
            command_name="inspect-generated-routes",
            summary=summary,
            errors=(error,),
            input_files=input_paths,
            output_files={},
            config_path=config_path,
            cli_args=args,
            extra_manifest={
                "reference_scope": REFERENCE_SCOPE,
                "failure_stage": "preflight_inputs",
            },
        )
        raise


__all__ = ["run_generated_route_inspection"]
