"""Corpus-level publication for C3 RRSeq-free counterfactual reassembly."""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import sys
import tempfile
import time
from collections import Counter, defaultdict
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from dataclasses import asdict, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from route_inspector import __version__, chemistry
from route_inspector.chemistry.classification.common import record_id
from route_inspector.chemistry.classification.providers import (
    ReactionRecord,
    create_provider,
)
from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.infrastructure.paths import relative_path, resolve_existing_path
from route_inspector.infrastructure.runtime import (
    git_commit_hash,
    normalize_n_cpu,
    setup_runtime_cache_dirs,
)
from route_inspector.metrics.routes import route_topology_metrics
from route_inspector.reference_library import ReferenceTacticLibrary
from route_inspector.reference_library.bigram_catalog import (
    ReferenceBigramOccurrence,
)
from route_inspector.reference_library.profile import canonical_json
from route_inspector.reference_library.storage.artifacts import (
    _publish_directory_no_replace,
)
from route_inspector.routes.counterfactuals.models import (
    C3_SCHEMA_VERSION,
    AdjacentPairAssessment,
    C3PublicationResult,
    C3ReplayLimits,
)
from route_inspector.routes.counterfactuals.replay import (
    _assess_adjacent_pair,
    _pair_identity,
    _PairReplayResult,
)
from route_inspector.routes.io import iter_route_json_file
from route_inspector.workflows.reference_library import (
    route_tactic_processor_from_config,
)

_ROUTE_COLUMNS = (
    "source_route_id",
    "reaction_count",
    "route_depth",
    "leaf_count",
    "topology",
    "is_convergent",
    "adjacent_pairs_total",
    "adjacent_pairs_resolved",
    "commutable_unique",
    "commutable_ambiguous",
    "noncommutable",
    "unresolved",
    "commutable_pair_count",
    "has_commutable_pair",
    "route_status",
    "selected_pair_identity",
    "selected_pair_status",
    "counterfactual_id",
    "original_rrseq_cons_count",
    "original_rrseq_gap_count",
    "rrseq_cons_count",
    "rrseq_gap_count",
    "rrsubtree_cons_count",
    "rrsubtree_gap_count",
)
_ERROR_COLUMNS = (
    "source_route_id",
    "stage",
    "error_type",
    "message",
)

_WORKER_PROCESSOR: Any | None = None
_WORKER_LIBRARY_ID = ""
_WORKER_LIMITS = C3ReplayLimits()


def _numeric_aware(value: Any) -> tuple[int, int | str]:
    text = str(value)
    try:
        return 0, int(text)
    except ValueError:
        return 1, text


def _artifact(path: Path) -> dict[str, Any]:
    return {
        "path": path.name,
        "sha256": _sha256_file(path),
        "size_bytes": path.stat().st_size,
    }


def _topology_adjacent_pairs(
    route: Mapping[str, Any],
) -> tuple[tuple[tuple[int, ...], tuple[int, ...]], ...]:
    pairs: list[tuple[tuple[int, ...], tuple[int, ...]]] = []

    def visit_molecule(node: Mapping[str, Any], path: tuple[int, ...]) -> None:
        for reaction_index, reaction in enumerate(node.get("children") or ()):
            if not isinstance(reaction, Mapping):
                raise ValueError("route children must contain objects")
            if reaction.get("type") != "reaction":
                raise ValueError("molecule children must be reaction nodes")
            reaction_path = path + (reaction_index,)
            for precursor_index, precursor in enumerate(reaction.get("children") or ()):
                if not isinstance(precursor, Mapping):
                    raise ValueError("reaction children must contain objects")
                if precursor.get("type") != "mol":
                    raise ValueError("reaction children must be molecule nodes")
                precursor_path = reaction_path + (precursor_index,)
                for child_index, child in enumerate(precursor.get("children") or ()):
                    if not isinstance(child, Mapping):
                        raise ValueError("molecule children must contain objects")
                    if child.get("type") != "reaction":
                        raise ValueError("molecule children must be reaction nodes")
                    pairs.append((reaction_path, precursor_path + (child_index,)))
                visit_molecule(precursor, precursor_path)

    visit_molecule(route, ())
    return tuple(sorted(pairs))


def _read_manifest_and_occurrences(
    library_dir: Path,
) -> tuple[Any, Mapping[str, tuple[ReferenceBigramOccurrence, ...]], frozenset[str]]:
    with ReferenceTacticLibrary.load(
        library_dir,
        verification="fast",
    ) as library:
        manifest = library.manifest
        eligible_routes = library.routes_without_tactics(
            kinds=("rrseq_cons", "rrseq_gap")
        )
    if len(manifest.reference_corpora) != 1:
        raise ValueError("C3 requires a single-corpus Reference library")
    corpus = manifest.reference_corpora[0]
    evidence = manifest.supplementary_evidence.get("retro_bleu_bigrams")
    if not isinstance(evidence, Mapping):
        raise ValueError("C3 requires the persisted Retro-BLEU-like bigram component")
    eligible_ids = frozenset(route.route_id for route in eligible_routes)
    # Historical declarations remain integrity checks, never the source of membership.
    for raw_ids in (
        evidence.get("reference_route_ids_without_rrseq_cons_or_gap"),
        corpus.get("route_ids_without_rrseq_cons_or_gap"),
    ):
        if raw_ids is not None and (
            not isinstance(raw_ids, list)
            or len(raw_ids) != len(eligible_ids)
            or frozenset(str(value) for value in raw_ids) != eligible_ids
        ):
            raise ValueError(
                "manifest no-RRSeq cohort declarations disagree with provenance"
            )
    recorded_count = int(evidence["reference_route_count_without_rrseq_cons_or_gap"])
    if recorded_count != len(eligible_ids):
        raise ValueError("manifest no-RRSeq route count disagrees with derived cohort")

    descriptor = manifest.artifacts.get("retro_bleu_bigram_occurrences")
    if not isinstance(descriptor, Mapping):
        raise ValueError("Reference manifest lacks bigram occurrence provenance")
    occurrence_path = library_dir / str(descriptor["path"])
    by_route: dict[str, list[ReferenceBigramOccurrence]] = defaultdict(list)
    seen_reference_ids: set[str] = set()
    with occurrence_path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            try:
                record = json.loads(line)
                wrapper = ReferenceBigramOccurrence.from_dict(record["occurrence"])
            except Exception as exc:
                raise ValueError(
                    f"invalid Reference bigram occurrence on line {line_number}: {exc}"
                ) from exc
            if (wrapper.route.dataset_id, wrapper.route.source_identity) != (
                corpus["dataset_id"],
                corpus["source_identity"],
            ):
                raise ValueError("bigram provenance refers to another source corpus")
            if wrapper.route_without_rrseq != (wrapper.route.route_id in eligible_ids):
                raise ValueError(
                    "bigram no-RRSeq membership disagrees with derived cohort"
                )
            if not wrapper.route_without_rrseq:
                continue
            if wrapper.route.route_id not in eligible_ids:
                raise ValueError("no-RRSeq bigram refers to a route outside the cohort")
            if wrapper.reference_occurrence_id in seen_reference_ids:
                raise ValueError("duplicate no-RRSeq bigram Reference occurrence")
            seen_reference_ids.add(wrapper.reference_occurrence_id)
            by_route[wrapper.route.route_id].append(wrapper)
    normalized = {
        route_id: tuple(
            sorted(
                values,
                key=lambda item: (
                    item.occurrence.reaction_node_paths,
                    item.reference_occurrence_id,
                ),
            )
        )
        for route_id, values in by_route.items()
    }
    recorded_occurrences = int(evidence["no_rrseq_retro_bleu_bigram_occurrence_count"])
    if sum(len(values) for values in normalized.values()) != recorded_occurrences:
        raise ValueError("manifest no-RRSeq bigram count disagrees with provenance")
    return manifest, normalized, eligible_ids


def _init_worker(
    config: str,
    profile_payload: Mapping[str, Any],
    library_id: str,
    limits_payload: Mapping[str, Any],
) -> None:
    global _WORKER_PROCESSOR, _WORKER_LIBRARY_ID, _WORKER_LIMITS
    from route_inspector.reference_library.profile import ReferenceProcessingProfile

    setup_runtime_cache_dirs()
    profile = ReferenceProcessingProfile.from_dict(profile_payload)
    _WORKER_PROCESSOR = route_tactic_processor_from_config(
        config,
        processing_profile=profile,
    )
    _WORKER_LIBRARY_ID = str(library_id)
    _WORKER_LIMITS = C3ReplayLimits(**limits_payload)


def _route_result(
    item: tuple[
        str,
        Mapping[str, Any],
        tuple[ReferenceBigramOccurrence, ...],
    ],
) -> dict[str, Any]:
    route_id, route, occurrences = item
    if _WORKER_PROCESSOR is None:
        raise RuntimeError("C3 worker was not initialized")
    topology = route_topology_metrics(route)
    topology_pairs = _topology_adjacent_pairs(route)
    occurrence_pairs = tuple(
        occurrence.occurrence.reaction_node_paths for occurrence in occurrences
    )
    if len(occurrence_pairs) != len(set(occurrence_pairs)):
        raise ValueError(f"route {route_id} has duplicate persisted bigram paths")
    if set(topology_pairs) != set(occurrence_pairs):
        missing = sorted(set(topology_pairs) - set(occurrence_pairs))
        extra = sorted(set(occurrence_pairs) - set(topology_pairs))
        raise ValueError(
            f"route {route_id} bigram provenance does not cover topology: "
            f"missing={missing}, extra={extra}"
        )

    replay_results: list[_PairReplayResult] = []
    for occurrence in occurrences:
        replay_results.append(
            _assess_adjacent_pair(
                route,
                occurrence,
                source_library_id=_WORKER_LIBRARY_ID,
                rule_extractor=_WORKER_PROCESSOR.rule_extractor,
                limits=_WORKER_LIMITS,
            )
        )
    assessments = [result.assessment for result in replay_results]
    successful: list[
        tuple[
            tuple[Any, ...],
            _PairReplayResult,
            Any,
        ]
    ] = []
    for result in replay_results:
        status_rank = 0 if result.assessment.status == "commutable_unique" else 1
        for counterfactual in result.counterfactuals:
            successful.append(
                (
                    (
                        status_rank,
                        result.assessment.first_reaction_path,
                        result.assessment.second_reaction_path,
                        counterfactual.realization_fingerprint,
                    ),
                    result,
                    counterfactual,
                )
            )
    successful.sort(key=lambda value: value[0])
    selected_pair: _PairReplayResult | None = None
    selected: Any | None = None
    motif_counts = {
        "rrseq_cons": 0,
        "rrseq_gap": 0,
        "rrsubtree_cons": 0,
        "rrsubtree_gap": 0,
    }
    if successful:
        _key, selected_pair, selected = successful[0]
        processed = _WORKER_PROCESSOR.process_route(
            selected.counterfactual_id,
            dict(selected.route),
            dataset_id=f"{occurrences[0].route.dataset_id}-C3",
            source_identity=f"counterfactual:{_WORKER_LIBRARY_ID}",
        )
        motif_counts.update(
            Counter(item.identity.kind for item in processed.occurrences)
        )
        selected.route.setdefault("metadata", {})["counterfactual_motif_counts"] = dict(
            motif_counts
        )

    counts = Counter(assessment.status for assessment in assessments)
    resolved_count = sum(assessment.resolved for assessment in assessments)
    commutable_count = counts["commutable_unique"] + counts["commutable_ambiguous"]
    if selected is not None:
        route_status = "counterfactual_generated"
    elif not assessments:
        route_status = "no_adjacent_pair"
    elif counts["unresolved"] == len(assessments):
        route_status = "unresolved_route"
    else:
        route_status = "no_commutable_pair"
    summary = {
        "source_route_id": route_id,
        "reaction_count": int(topology["total_reaction_count"]),
        "route_depth": int(topology["longest_linear_route"]),
        "leaf_count": int(topology["distinct_leaf_count"]),
        "topology": str(topology["topology"]),
        "is_convergent": int(topology["topology"] == "convergent"),
        "adjacent_pairs_total": len(assessments),
        "adjacent_pairs_resolved": resolved_count,
        "commutable_unique": counts["commutable_unique"],
        "commutable_ambiguous": counts["commutable_ambiguous"],
        "noncommutable": counts["noncommutable"],
        "unresolved": counts["unresolved"],
        "commutable_pair_count": commutable_count,
        "has_commutable_pair": int(commutable_count > 0),
        "route_status": route_status,
        "selected_pair_identity": (
            "" if selected_pair is None else selected_pair.assessment.pair_identity
        ),
        "selected_pair_status": (
            "" if selected_pair is None else selected_pair.assessment.status
        ),
        "counterfactual_id": ("" if selected is None else selected.counterfactual_id),
        "original_rrseq_cons_count": 0,
        "original_rrseq_gap_count": 0,
        "rrseq_cons_count": motif_counts["rrseq_cons"],
        "rrseq_gap_count": motif_counts["rrseq_gap"],
        "rrsubtree_cons_count": motif_counts["rrsubtree_cons"],
        "rrsubtree_gap_count": motif_counts["rrsubtree_gap"],
    }
    return {
        "route_summary": summary,
        "pair_assessments": [assessment.to_dict() for assessment in assessments],
        "alternative": (
            None
            if selected is None
            else {
                "counterfactual_id": selected.counterfactual_id,
                "route": selected.route,
            }
        ),
    }


def _unexpected_route_result(
    route_id: str,
    route: Mapping[str, Any],
    occurrences: Sequence[ReferenceBigramOccurrence],
    *,
    source_library_id: str,
    error: Exception,
) -> dict[str, Any]:
    """Retain complete route ownership when an unexpected error is ignored."""

    topology = route_topology_metrics(route)
    error_type = type(error).__name__
    error_message = str(error) or error_type
    pair_assessments = []
    for occurrence in occurrences:
        native = occurrence.occurrence
        centers_1 = native.steps[0].center_atom_maps
        centers_2 = native.steps[1].center_atom_maps
        pair_assessments.append(
            AdjacentPairAssessment(
                source_route_id=route_id,
                pair_identity=_pair_identity(
                    occurrence,
                    source_library_id=source_library_id,
                ),
                reference_bigram_occurrence_id=(occurrence.reference_occurrence_id),
                first_reaction_path=native.reaction_node_paths[0],
                second_reaction_path=native.reaction_node_paths[1],
                status="unresolved",
                replay_outcome_count=0,
                matching_boundary_count=0,
                unique_counterfactual_count=0,
                original_intermediate=native.steps[1].target_smiles,
                counterfactual_intermediates=(),
                boundary_precursors=(),
                original_bigram_occurrence=native.to_dict(),
                r1_center_maps=centers_1,
                r2_center_maps=centers_2,
                center_overlap=tuple(set(centers_1) & set(centers_2)),
                error_type=error_type,
                error_message=error_message,
            ).to_dict()
        )
    summary = {
        "source_route_id": route_id,
        "reaction_count": int(topology["total_reaction_count"]),
        "route_depth": int(topology["longest_linear_route"]),
        "leaf_count": int(topology["distinct_leaf_count"]),
        "topology": str(topology["topology"]),
        "is_convergent": int(topology["topology"] == "convergent"),
        "adjacent_pairs_total": len(occurrences),
        "adjacent_pairs_resolved": 0,
        "commutable_unique": 0,
        "commutable_ambiguous": 0,
        "noncommutable": 0,
        "unresolved": len(occurrences),
        "commutable_pair_count": 0,
        "has_commutable_pair": 0,
        "route_status": "processing_error",
        "selected_pair_identity": "",
        "selected_pair_status": "",
        "counterfactual_id": "",
        "original_rrseq_cons_count": 0,
        "original_rrseq_gap_count": 0,
        "rrseq_cons_count": 0,
        "rrseq_gap_count": 0,
        "rrsubtree_cons_count": 0,
        "rrsubtree_gap_count": 0,
    }
    return {
        "route_summary": summary,
        "pair_assessments": pair_assessments,
        "alternative": None,
    }


def _render_progress(
    completed: int, total: int, started_at: float, workers: int
) -> None:
    elapsed = max(time.monotonic() - started_at, 1e-9)
    fraction = completed / total if total else 1.0
    width = 28
    filled = min(width, int(width * fraction))
    bar = "#" * filled + "-" * (width - filled)
    rate = completed / elapsed
    ending = "\n" if completed >= total else ""
    print(
        f"\r[C3] |{bar}| {completed:,}/{total:,} ({fraction:6.1%}) "
        f"{rate:6.1f} routes/s elapsed {elapsed:,.1f}s workers={workers}",
        end=ending,
        file=sys.stderr,
        flush=True,
    )


def _iter_eligible_routes(
    routes_path: Path,
    eligible_ids: frozenset[str],
    occurrences_by_route: Mapping[str, tuple[ReferenceBigramOccurrence, ...]],
) -> Iterable[tuple[str, Mapping[str, Any], tuple[ReferenceBigramOccurrence, ...]]]:
    observed: set[str] = set()
    for raw_route_id, route in iter_route_json_file(routes_path):
        route_id = str(raw_route_id)
        if route_id not in eligible_ids:
            continue
        observed.add(route_id)
        yield route_id, route, occurrences_by_route.get(route_id, ())
    if observed != eligible_ids:
        missing = sorted(eligible_ids - observed, key=_numeric_aware)
        extra = sorted(observed - eligible_ids, key=_numeric_aware)
        raise ValueError(
            f"clean routes disagree with the manifest cohort: "
            f"missing={missing[:10]}, extra={extra[:10]}"
        )


def _process_routes(
    route_items: Iterable[
        tuple[str, Mapping[str, Any], tuple[ReferenceBigramOccurrence, ...]]
    ],
    *,
    config: Path,
    profile_payload: Mapping[str, Any],
    library_id: str,
    limits: C3ReplayLimits,
    total: int,
    n_cpu: int,
    progress_interval: int,
    ignore_errors: bool,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    workers = normalize_n_cpu(n_cpu)
    results: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    started = time.monotonic()
    completed = 0

    def consume(
        item: tuple[
            str,
            Mapping[str, Any],
            tuple[ReferenceBigramOccurrence, ...],
        ],
        outcome: dict[str, Any] | None,
        error: Exception | None,
    ) -> None:
        nonlocal completed
        route_id, route, occurrences = item
        completed += 1
        if error is not None:
            if not ignore_errors:
                raise error
            errors.append(
                {
                    "source_route_id": route_id,
                    "stage": "route_processing",
                    "error_type": type(error).__name__,
                    "message": str(error) or type(error).__name__,
                }
            )
            results.append(
                _unexpected_route_result(
                    route_id,
                    route,
                    occurrences,
                    source_library_id=library_id,
                    error=error,
                )
            )
        elif outcome is not None:
            results.append(outcome)
        if progress_interval and (
            completed % progress_interval == 0 or completed == total
        ):
            _render_progress(completed, total, started, workers)

    if workers == 1:
        _init_worker(
            str(config),
            profile_payload,
            library_id,
            limits.to_dict(),
        )
        for item in route_items:
            try:
                outcome = _route_result(item)
            except Exception as exc:
                consume(item, None, exc)
            else:
                consume(item, outcome, None)
        return results, errors

    iterator = iter(route_items)
    maximum_pending = max(workers * 2, workers)
    with ProcessPoolExecutor(
        max_workers=workers,
        initializer=_init_worker,
        initargs=(
            str(config),
            dict(profile_payload),
            library_id,
            limits.to_dict(),
        ),
    ) as executor:
        pending: dict[
            Any, tuple[str, Mapping[str, Any], tuple[ReferenceBigramOccurrence, ...]]
        ] = {}
        exhausted = False
        while pending or not exhausted:
            while not exhausted and len(pending) < maximum_pending:
                try:
                    item = next(iterator)
                except StopIteration:
                    exhausted = True
                    break
                future = executor.submit(_route_result, item)
                pending[future] = item
            if not pending:
                continue
            done, _ = wait(tuple(pending), return_when=FIRST_COMPLETED)
            for future in sorted(
                done, key=lambda value: _numeric_aware(pending[value][0])
            ):
                item = pending.pop(future)
                try:
                    outcome = future.result()
                except Exception as exc:
                    consume(item, None, exc)
                else:
                    consume(item, outcome, None)
    return results, errors


def _class_result_dict(result: Any) -> dict[str, Any]:
    return asdict(result)


def _annotate_reaction_classes(
    pair_records: Sequence[Mapping[str, Any]],
    *,
    provider: Any,
    n_cpu: int,
    worker_chunksize: int,
) -> list[dict[str, Any]]:
    input_to_mapped: dict[str, str] = {}
    pair_inputs: dict[str, tuple[str, str]] = {}
    for record in pair_records:
        steps = record["original_bigram_occurrence"]["steps"]
        inputs: list[str] = []
        for step in steps:
            mapped = str(step["reaction_smiles"])
            classifier_input = chemistry.canonical_unmapped_reaction_string(mapped)
            input_to_mapped.setdefault(classifier_input, mapped)
            inputs.append(classifier_input)
        pair_inputs[str(record["pair_identity"])] = (inputs[0], inputs[1])
    requests = [
        ReactionRecord(
            record_id=record_id(classifier_input),
            mapped_reaction=input_to_mapped[classifier_input],
            classifier_input=classifier_input,
        )
        for classifier_input in sorted(input_to_mapped)
    ]
    results = provider.classify_many(
        requests,
        n_cpu=n_cpu,
        worker_chunksize=worker_chunksize,
    )
    by_id = {result.record_id: result for result in results}
    if len(by_id) != len(requests):
        raise ValueError("reaction-class provider returned incomplete result ownership")

    enriched: list[dict[str, Any]] = []
    profile = {
        "provider": provider.provider_name,
        "provider_version": provider.provider_version,
        "taxonomy": provider.taxonomy_id,
    }
    for raw in pair_records:
        assessment = AdjacentPairAssessment.from_dict(raw)
        inputs = pair_inputs[assessment.pair_identity]
        classes = {
            "profile": profile,
            "r1": _class_result_dict(by_id[record_id(inputs[0])]),
            "r2": _class_result_dict(by_id[record_id(inputs[1])]),
        }
        enriched.append(replace(assessment, reaction_classes=classes).to_dict())
    return enriched


def _write_tsv(
    path: Path,
    columns: Sequence[str],
    rows: Sequence[Mapping[str, Any]],
) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def _stratum_summary(
    rows: Sequence[Mapping[str, Any]],
    pair_by_route: Mapping[str, Sequence[Mapping[str, Any]]],
) -> dict[str, Any]:
    pair_records = [
        pair
        for row in rows
        for pair in pair_by_route.get(str(row["source_route_id"]), ())
    ]
    resolved_pairs = [pair for pair in pair_records if pair["status"] != "unresolved"]
    commutable_pairs = [pair for pair in resolved_pairs if pair["commutable"]]
    routes_resolved = {
        str(row["source_route_id"])
        for row in rows
        if any(
            pair["status"] != "unresolved"
            for pair in pair_by_route.get(str(row["source_route_id"]), ())
        )
    }
    routes_commutable = {
        str(row["source_route_id"])
        for row in rows
        if any(
            pair["commutable"]
            for pair in pair_by_route.get(str(row["source_route_id"]), ())
        )
    }
    return {
        "route_count": len(rows),
        "eligible_routes_resolved": len(routes_resolved),
        "routes_with_at_least_one_commutable_pair": len(routes_commutable),
        "route_commutability_fraction": (
            len(routes_commutable) / len(routes_resolved) if routes_resolved else None
        ),
        "adjacent_pairs_total": len(pair_records),
        "adjacent_pairs_resolved": len(resolved_pairs),
        "commutable_pairs": len(commutable_pairs),
        "pair_commutability_fraction": (
            len(commutable_pairs) / len(resolved_pairs) if resolved_pairs else None
        ),
    }


def _dataset_summary(
    route_rows: Sequence[Mapping[str, Any]],
    pair_records: Sequence[Mapping[str, Any]],
    *,
    eligible_route_count: int,
    errors: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    pair_by_route: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for record in pair_records:
        pair_by_route[str(record["source_route_id"])].append(record)
    status_counts = Counter(str(record["status"]) for record in pair_records)
    overall = _stratum_summary(route_rows, pair_by_route)
    distance_counts = Counter(
        str(record["reaction_center_relationship"]["minimum_center_graph_distance"])
        for record in pair_records
        if record["reaction_center_relationship"]["minimum_center_graph_distance"]
        is not None
    )
    summary: dict[str, Any] = {
        "schema_version": C3_SCHEMA_VERSION,
        "experiment": "C3",
        "eligible_route_count": int(eligible_route_count),
        "processed_eligible_route_count": len(route_rows),
        **overall,
        "route_count_without_adjacent_pairs": sum(
            int(row["adjacent_pairs_total"]) == 0 for row in route_rows
        ),
        "routes_with_published_alternative": sum(
            bool(row["counterfactual_id"]) for row in route_rows
        ),
        "routes_with_only_noncommutable_pairs": sum(
            row["route_status"] == "no_commutable_pair" and int(row["unresolved"]) == 0
            for row in route_rows
        ),
        "unresolved_routes": sum(
            row["route_status"] == "unresolved_route" for row in route_rows
        ),
        "pair_status_counts": dict(sorted(status_counts.items())),
        "commutable_pairs_per_route_distribution": {
            str(key): value
            for key, value in sorted(
                Counter(int(row["commutable_pair_count"]) for row in route_rows).items()
            )
        },
        "center_overlap_pair_count": sum(
            bool(record["reaction_center_relationship"]["center_overlap"])
            for record in pair_records
        ),
        "minimum_center_graph_distance_distribution": dict(
            sorted(distance_counts.items(), key=lambda value: _numeric_aware(value[0]))
        ),
        "alternative_motif_totals": {
            kind: sum(int(row[f"{kind}_count"]) for row in route_rows)
            for kind in (
                "rrseq_cons",
                "rrseq_gap",
                "rrsubtree_cons",
                "rrsubtree_gap",
            )
        },
        "unexpected_error_count": len(errors),
        "stratification": {},
    }
    for field in ("reaction_count", "topology", "leaf_count"):
        groups: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
        for row in route_rows:
            groups[str(row[field])].append(row)
        summary["stratification"][field] = {
            key: _stratum_summary(groups[key], pair_by_route)
            for key in sorted(groups, key=_numeric_aware)
        }
    return summary


def generate_rrseq_free_counterfactuals(
    routes_json: str | Path,
    reference_library: str | Path,
    config: str | Path,
    output_dir: str | Path,
    *,
    n_cpu: int = 1,
    limits: C3ReplayLimits | None = None,
    progress_interval: int = 25,
    ignore_errors: bool = False,
    reaction_class_backend: str | None = None,
    reaction_classifier_path: str | Path | None = None,
    namerxn_path: str | Path | None = None,
    reaction_class_label_policy: str = "confirmed-or-neural",
    reaction_class_torch_threads: int = 1,
    reaction_class_device: str = "cpu",
    reaction_class_worker_chunksize: int = 100,
) -> C3PublicationResult:
    """Run and atomically publish Experiment C3 for the manifest cohort."""

    setup_runtime_cache_dirs()
    started = time.monotonic()
    timings: dict[str, float] = {}
    routes_path = resolve_existing_path(routes_json)
    library_dir = resolve_existing_path(reference_library)
    config_path = resolve_existing_path(config)
    destination = Path(output_dir).expanduser()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    resolved_limits = limits or C3ReplayLimits()

    load_started = time.monotonic()
    manifest, occurrences_by_route, eligible_ids = _read_manifest_and_occurrences(
        library_dir
    )
    corpus = manifest.reference_corpora[0]
    routes_digest = _sha256_file(routes_path)
    if routes_digest != str(corpus.get("input_sha256") or ""):
        raise ValueError("clean-route digest differs from the Reference manifest")
    processor = route_tactic_processor_from_config(
        config_path,
        processing_profile=manifest.processing_profile,
    )
    del processor
    timings["load_and_validate_sources_seconds"] = time.monotonic() - load_started

    provider = None
    classification_profile: dict[str, Any] | None = None
    if reaction_class_backend not in {None, "", "none"}:
        provider = create_provider(
            str(reaction_class_backend),
            reaction_classifier_path=reaction_classifier_path,
            namerxn_path=namerxn_path,
            label_policy=reaction_class_label_policy,
            torch_threads=reaction_class_torch_threads,
            device=reaction_class_device,
        )
        classification_profile = {
            "provider": provider.provider_name,
            "provider_version": provider.provider_version,
            "taxonomy": provider.taxonomy_id,
            "label_policy": reaction_class_label_policy,
            "tier": 3,
        }

    process_started = time.monotonic()
    results, errors = _process_routes(
        _iter_eligible_routes(routes_path, eligible_ids, occurrences_by_route),
        config=config_path,
        profile_payload=manifest.processing_profile.to_dict(),
        library_id=manifest.library_id,
        limits=resolved_limits,
        total=len(eligible_ids),
        n_cpu=n_cpu,
        progress_interval=int(progress_interval),
        ignore_errors=bool(ignore_errors),
    )
    timings["process_routes_seconds"] = time.monotonic() - process_started

    route_rows = sorted(
        (result["route_summary"] for result in results),
        key=lambda row: _numeric_aware(row["source_route_id"]),
    )
    pair_records = sorted(
        (record for result in results for record in result["pair_assessments"]),
        key=lambda record: (
            _numeric_aware(record["source_route_id"]),
            tuple(record["first_reaction_path"]),
            tuple(record["second_reaction_path"]),
            record["pair_identity"],
        ),
    )
    alternatives = {
        result["alternative"]["counterfactual_id"]: result["alternative"]["route"]
        for result in results
        if result["alternative"] is not None
    }

    if provider is not None:
        classify_started = time.monotonic()
        pair_records = _annotate_reaction_classes(
            pair_records,
            provider=provider,
            n_cpu=normalize_n_cpu(n_cpu),
            worker_chunksize=int(reaction_class_worker_chunksize),
        )
        timings["classify_reactions_seconds"] = time.monotonic() - classify_started

    summary = _dataset_summary(
        route_rows,
        pair_records,
        eligible_route_count=len(eligible_ids),
        errors=errors,
    )
    temporary = Path(
        tempfile.mkdtemp(
            prefix=f".{destination.name}.",
            suffix=".tmp",
            dir=destination.parent,
        )
    )
    try:
        alternative_path = temporary / "alternative_routes.json"
        alternative_path.write_text(
            json.dumps(alternatives, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        pair_path = temporary / "pair_assessment.jsonl"
        with pair_path.open("w", encoding="utf-8") as stream:
            for record in pair_records:
                stream.write(canonical_json(record) + "\n")
        route_path = temporary / "route_summary.tsv"
        _write_tsv(route_path, _ROUTE_COLUMNS, route_rows)
        summary_path = temporary / "dataset_summary.json"
        summary_path.write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        errors_path = temporary / "errors.tsv"
        _write_tsv(errors_path, _ERROR_COLUMNS, errors)
        artifacts = {
            "alternative_routes": _artifact(alternative_path),
            "pair_assessment": _artifact(pair_path),
            "route_summary": _artifact(route_path),
            "dataset_summary": _artifact(summary_path),
            "errors": _artifact(errors_path),
        }
        identity_payload = {
            "schema_version": C3_SCHEMA_VERSION,
            "experiment": "C3",
            "source_library_id": manifest.library_id,
            "source_bigram_catalog_id": manifest.supplementary_evidence[
                "retro_bleu_bigrams"
            ]["retro_bleu_bigram_catalog_id"],
            "source_routes_sha256": routes_digest,
            "processing_profile_fingerprint": manifest.configuration_fingerprint,
            "limits": resolved_limits.to_dict(),
            "reaction_classification": classification_profile,
            "artifacts": artifacts,
        }
        experiment_id = (
            "c3_rrseq_free_"
            + hashlib.sha256(
                canonical_json(identity_payload).encode("utf-8")
            ).hexdigest()
        )
        result_manifest = {
            **identity_payload,
            "experiment_id": experiment_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "route_inspector_version": __version__,
            "route_inspector_commit": git_commit_hash(),
            "sources": {
                "routes_json": relative_path(routes_path),
                "reference_library": relative_path(library_dir),
                "config": relative_path(config_path),
                "dataset_id": str(corpus["dataset_id"]),
                "source_identity": str(corpus["source_identity"]),
                "eligible_route_count": len(eligible_ids),
            },
            "definitions": {
                "eligible_cohort": (
                    "zero RRSeq_cons and zero RRSeq_gap occurrences under the "
                    "source Reference-library processing profile"
                ),
                "boundary": (
                    "all child-reaction precursors plus unaffected parent "
                    "precursor arms"
                ),
                "boundary_equivalence": (
                    "mapping-independent exact constitutional multiset; stereo ignored"
                ),
                "certification": (
                    "complete order-agnostic RouteCGR fingerprint equality with "
                    "transient bonds preserved"
                ),
            },
            "statistics": summary,
        }
        (temporary / "manifest.json").write_text(
            json.dumps(result_manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        _publish_directory_no_replace(temporary, destination)
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise
    timings["total_seconds"] = time.monotonic() - started
    return C3PublicationResult(
        output_path=destination,
        manifest=result_manifest,
        statistics=summary,
        phase_timings=timings,
    )


__all__ = ["generate_rrseq_free_counterfactuals"]
