"""Build and apply the frozen CGR-key precedent index for Experiment B."""

from __future__ import annotations

import csv
import hashlib
import math
import os
import shutil
import statistics
import tempfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from route_inspector import __version__
from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.metrics.routes import route_topology_metrics
from route_inspector.reference_library.corpus_assessment.catalog import (
    REFERENCE_ASSESSMENT_CATALOG_SCHEMA_VERSION,
    REFERENCE_ASSESSMENT_FORMAT_VERSION,
    ReferenceFamily,
    RouteAssessmentReference,
    create_catalog,
)
from route_inspector.reference_library.corpus_assessment.identity import (
    CGR_KEY_IDENTITY_VERSION,
    ENTITY_TYPES,
    AssessmentIdentity,
    EntityType,
    canonical_json,
    composite_identity_contract,
    support_bin,
)
from route_inspector.reference_library.corpus_assessment.source import (
    SourceOccurrence,
    Verification,
    iter_all_occurrences,
    open_composite_source,
    open_reference_source,
)
from route_inspector.routes.io import iter_route_items_from_json_file

ASSESSMENT_OUTPUT_SCHEMA_VERSION = 1
SUPPORT_BINS = ("novel", "singleton", "low", "moderate", "high", "very_high")


def _created_at() -> str:
    return datetime.now(timezone.utc).isoformat()


def _numeric_aware(value: str) -> tuple[int, int | str]:
    try:
        return 0, int(value)
    except ValueError:
        return 1, value


def _artifact(path: Path, root: Path) -> dict[str, Any]:
    return {
        "path": path.relative_to(root).as_posix(),
        "sha256": _sha256_file(path),
        "size_bytes": path.stat().st_size,
    }


def _write_json(path: Path, value: Any) -> None:
    path.write_text(canonical_json(value) + "\n", encoding="utf-8")


def _write_jsonl(path: Path, values: Iterable[Mapping[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        for value in values:
            stream.write(canonical_json(value))
            stream.write("\n")


def _write_tsv(
    path: Path,
    rows: Sequence[Mapping[str, Any]],
    fieldnames: Sequence[str],
) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, delimiter="\t")
        writer.writeheader()
        for row in rows:
            writer.writerow({name: row.get(name) for name in fieldnames})


def _atomic_directory(destination: Path) -> Path:
    destination = destination.expanduser()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError(destination)
    return Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.tmp-", dir=destination.parent)
    )


def _publish(temp_root: Path, destination: Path) -> None:
    if destination.exists():
        raise FileExistsError(destination)
    os.replace(temp_root, destination)


@dataclass
class _FamilyAccumulator:
    identity: AssessmentIdentity
    route_ids: set[str] = field(default_factory=set)
    occurrence_count: int = 0
    representatives: list[SourceOccurrence] = field(default_factory=list)

    def add(self, occurrence: SourceOccurrence) -> None:
        self.route_ids.add(occurrence.route_id)
        self.occurrence_count += 1
        self.representatives.append(occurrence)


def _family_records(
    occurrences: Iterable[SourceOccurrence],
) -> tuple[ReferenceFamily, ...]:
    grouped: dict[tuple[str, str], _FamilyAccumulator] = {}
    for occurrence in occurrences:
        key = (occurrence.identity.entity_type, occurrence.identity.identity_json)
        bucket = grouped.setdefault(key, _FamilyAccumulator(occurrence.identity))
        bucket.add(occurrence)

    by_locator: dict[tuple[str, str], list[str]] = defaultdict(list)
    for entity_type, identity_json in grouped:
        digest = grouped[(entity_type, identity_json)].identity.identity_sha256
        by_locator[(entity_type, digest)].append(identity_json)

    family_ids = {
        (entity_type, identity_json): (f"assessment_family_i_{digest}~{ordinal:04d}")
        for (entity_type, digest), payloads in sorted(by_locator.items())
        for ordinal, identity_json in enumerate(sorted(payloads))
    }
    records: list[ReferenceFamily] = []
    for key, bucket in sorted(grouped.items()):
        representative = min(
            bucket.representatives,
            key=lambda item: (
                _numeric_aware(item.route_id),
                item.occurrence_id,
            ),
        )
        entity_type, identity_json = key
        records.append(
            ReferenceFamily(
                family_id=family_ids[key],
                entity_type=entity_type,  # type: ignore[arg-type]
                identity_sha256=bucket.identity.identity_sha256,
                identity_json=identity_json,
                reference_route_support=len(bucket.route_ids),
                reference_occurrence_support=bucket.occurrence_count,
                reference_route_ids=tuple(sorted(bucket.route_ids)),
                representative_occurrence_id=representative.occurrence_id,
                representative_route_id=representative.route_id,
                representative_provenance=representative.provenance(),
            )
        )
    return tuple(sorted(records, key=lambda item: (item.entity_type, item.family_id)))


def _reference_summary(
    families: Sequence[ReferenceFamily],
    *,
    route_count: int,
) -> dict[str, Any]:
    by_entity: dict[str, Any] = {}
    for entity_type in ENTITY_TYPES:
        rows = [family for family in families if family.entity_type == entity_type]
        by_entity[entity_type] = {
            "family_count": len(rows),
            "occurrence_count": sum(
                family.reference_occurrence_support for family in rows
            ),
            "positive_route_count": len(
                {route_id for family in rows for route_id in family.reference_route_ids}
            ),
        }
    return {
        "schema_version": ASSESSMENT_OUTPUT_SCHEMA_VERSION,
        "route_count": route_count,
        "family_count": len(families),
        "occurrence_count": sum(
            family.reference_occurrence_support for family in families
        ),
        "by_entity": by_entity,
    }


def build_route_assessment_reference(
    reference_library: str | Path,
    composite_library: str | Path,
    output_dir: str | Path,
    *,
    verification: Verification = "fast",
) -> RouteAssessmentReference:
    """Freeze an immutable precedent index from existing n1 libraries.

    Complete context-bearing CGR-key payloads (or normalized composite SMARTS)
    are authoritative. No graph-isomorphism function is called.
    """

    destination = Path(output_dir).expanduser()
    temp_root = _atomic_directory(destination)
    try:
        with open_reference_source(
            reference_library, verification=verification
        ) as reference:
            with open_composite_source(
                composite_library,
                reference=reference,
                verification=verification,
            ) as composites:
                families = _family_records(iter_all_occurrences(reference, composites))
                route_count = int(reference.corpus["route_count"])
                summary = _reference_summary(families, route_count=route_count)
                id_payload = {
                    "format_version": REFERENCE_ASSESSMENT_FORMAT_VERSION,
                    "identity_version": CGR_KEY_IDENTITY_VERSION,
                    **(
                        {"composite_identity_contract": composite_identity_contract(2)}
                        if composites.manifest.library_format_version == 2
                        else {}
                    ),
                    "source_reference_library_id": reference.manifest.library_id,
                    "source_composite_library_id": composites.manifest.library_id,
                    "processing_profile_fingerprint": (
                        reference.manifest.configuration_fingerprint
                    ),
                    "families": [
                        {
                            "entity_type": family.entity_type,
                            "identity_sha256": family.identity_sha256,
                            "identity_json": family.identity_json,
                            "route_ids": list(family.reference_route_ids),
                            "occurrence_support": (family.reference_occurrence_support),
                        }
                        for family in families
                    ],
                }
                reference_id = (
                    "route_assessment_reference_"
                    + hashlib.sha256(
                        canonical_json(id_payload).encode("utf-8")
                    ).hexdigest()
                )

                families_path = temp_root / "families.jsonl"
                report_path = temp_root / "families.tsv"
                summary_path = temp_root / "summary.json"
                catalog_path = temp_root / "catalog.sqlite"
                _write_jsonl(families_path, (family.to_dict() for family in families))
                _write_tsv(
                    report_path,
                    [
                        {
                            "entity_type": family.entity_type,
                            "family_id": family.family_id,
                            "reference_route_support": family.reference_route_support,
                            "reference_occurrence_support": (
                                family.reference_occurrence_support
                            ),
                            "representative_route_id": (family.representative_route_id),
                            "representative_occurrence_id": (
                                family.representative_occurrence_id
                            ),
                        }
                        for family in families
                    ],
                    (
                        "entity_type",
                        "family_id",
                        "reference_route_support",
                        "reference_occurrence_support",
                        "representative_route_id",
                        "representative_occurrence_id",
                    ),
                )
                _write_json(summary_path, summary)
                metadata = {
                    "family_count": len(families),
                    "reference_assessment_id": reference_id,
                    "source_composite_library_id": composites.manifest.library_id,
                    "source_reference_library_id": reference.manifest.library_id,
                }
                create_catalog(catalog_path, families, metadata=metadata)
                artifacts = {
                    "catalog": _artifact(catalog_path, temp_root),
                    "families": _artifact(families_path, temp_root),
                    "report": _artifact(report_path, temp_root),
                    "summary": _artifact(summary_path, temp_root),
                }
                manifest = {
                    "format_version": REFERENCE_ASSESSMENT_FORMAT_VERSION,
                    "catalog_schema_version": (
                        REFERENCE_ASSESSMENT_CATALOG_SCHEMA_VERSION
                    ),
                    "reference_assessment_id": reference_id,
                    "created_at": _created_at(),
                    "route_inspector_version": __version__,
                    "reference_dataset": reference.dataset_id,
                    "reference_source_identity": reference.source_identity,
                    "reference_routes_sha256": reference.source_routes_sha256,
                    "processing_profile_fingerprint": (
                        reference.manifest.configuration_fingerprint
                    ),
                    "source_reference_library_id": reference.manifest.library_id,
                    "source_composite_library_id": composites.manifest.library_id,
                    "source_schemas": {
                        "reference_library_format": (
                            reference.manifest.library_format_version
                        ),
                        "reference_catalog": (
                            reference.manifest.catalog_schema_version
                        ),
                        "composite_library_format": (
                            composites.manifest.library_format_version
                        ),
                        "composite_catalog": (
                            composites.manifest.catalog_schema_version
                        ),
                    },
                    "identity_contract": {
                        "version": CGR_KEY_IDENTITY_VERSION,
                        "rrseq": "ordered context-bearing query_cgr_keys",
                        "rrsubtree": (
                            "recursively sorted query_cgr_key topology with "
                            "skipped-reaction counts"
                        ),
                        "retro_bleu_bigram": (
                            "ordered context-bearing step query_cgr_keys"
                        ),
                        "composite": composite_identity_contract(
                            composites.manifest.library_format_version
                        ),
                        "digest_role": "indexed locator only",
                        "authoritative_comparison": "complete serialized equality",
                        "graph_isomorphism": False,
                    },
                    "statistics": summary,
                    "artifacts": artifacts,
                }
                _write_json(temp_root / "manifest.json", manifest)
        _publish(temp_root, destination)
    except BaseException:
        shutil.rmtree(temp_root, ignore_errors=True)
        raise
    return RouteAssessmentReference.load(destination, verification=verification)


@dataclass
class _QueryFamily:
    identity: AssessmentIdentity
    occurrences: list[SourceOccurrence] = field(default_factory=list)
    reference_family: ReferenceFamily | None = None


@dataclass
class _RouteEvidence:
    occurrences: list[tuple[SourceOccurrence, ReferenceFamily | None]] = field(
        default_factory=list
    )
    families: dict[str, _QueryFamily] = field(default_factory=dict)

    def add(
        self,
        occurrence: SourceOccurrence,
        reference_family: ReferenceFamily | None,
    ) -> None:
        self.occurrences.append((occurrence, reference_family))
        family = self.families.setdefault(
            occurrence.identity.identity_json,
            _QueryFamily(occurrence.identity, reference_family=reference_family),
        )
        if family.reference_family != reference_family:
            raise ValueError("one exact query family received inconsistent verdicts")
        family.occurrences.append(occurrence)


def _fraction(numerator: int, denominator: int) -> float | None:
    return numerator / denominator if denominator else None


def _mean(values: Sequence[int]) -> float | None:
    return statistics.fmean(values) if values else None


def _median(values: Sequence[int]) -> float | None:
    return statistics.median(values) if values else None


def _quantile(values: Sequence[float], fraction: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = fraction * (len(ordered) - 1)
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return ordered[low]
    return ordered[low] + (ordered[high] - ordered[low]) * (position - low)


def _evidence_metrics(evidence: _RouteEvidence) -> dict[str, Any]:
    occurrences = evidence.occurrences
    families = tuple(evidence.families.values())
    known_occurrences = [item for item in occurrences if item[1] is not None]
    known_families = [item for item in families if item.reference_family is not None]
    occurrence_support = [
        family.reference_route_support
        for _, family in occurrences
        if family is not None
    ]
    [
        item.reference_family.reference_route_support
        for item in families
        if item.reference_family is not None
    ]
    result: dict[str, Any] = {
        "occurrence_count": len(occurrences),
        "unique_family_count": len(families),
        "known_occurrence_count": len(known_occurrences),
        "novel_occurrence_count": len(occurrences) - len(known_occurrences),
        "known_family_count": len(known_families),
        "novel_family_count": len(families) - len(known_families),
        "occurrence_coverage": _fraction(len(known_occurrences), len(occurrences)),
        "family_coverage": _fraction(len(known_families), len(families)),
        "reference_route_support_min": min(occurrence_support, default=None),
        "reference_route_support_max": max(occurrence_support, default=None),
        "reference_route_support_mean": _mean(occurrence_support),
        "reference_route_support_median": _median(occurrence_support),
    }
    occurrence_bins = Counter(
        support_bin(0 if family is None else family.reference_route_support)
        for _, family in occurrences
    )
    family_bins = Counter(
        support_bin(
            0
            if item.reference_family is None
            else item.reference_family.reference_route_support
        )
        for item in families
    )
    for label in SUPPORT_BINS:
        result[f"occurrence_support_{label}_fraction"] = _fraction(
            occurrence_bins[label], len(occurrences)
        )
        result[f"family_support_{label}_fraction"] = _fraction(
            family_bins[label], len(families)
        )
    return result


def _prefix_metrics(prefix: str, metrics: Mapping[str, Any]) -> dict[str, Any]:
    return {f"{prefix}_{key}": value for key, value in metrics.items()}


def _entity_metric_names() -> tuple[str, ...]:
    names = [
        "occurrence_count",
        "unique_family_count",
        "known_occurrence_count",
        "novel_occurrence_count",
        "known_family_count",
        "novel_family_count",
        "occurrence_coverage",
        "family_coverage",
        "reference_route_support_min",
        "reference_route_support_max",
        "reference_route_support_mean",
        "reference_route_support_median",
    ]
    for label in SUPPORT_BINS:
        names.extend(
            (
                f"occurrence_support_{label}_fraction",
                f"family_support_{label}_fraction",
            )
        )
    return tuple(names)


def _route_columns() -> tuple[str, ...]:
    columns = [
        "dataset_id",
        "source_identity",
        "route_id",
        "total_reaction_count",
        "longest_linear_route",
        "distinct_leaf_count",
        "topology",
    ]
    names = _entity_metric_names()
    for entity_type in ENTITY_TYPES:
        columns.extend(f"{entity_type}_{name}" for name in names)
    return tuple(columns)


def _topology_rows(
    route_rows: Sequence[Mapping[str, Any]],
    route_evidence: Mapping[tuple[str, EntityType], _RouteEvidence],
) -> list[dict[str, Any]]:
    dimensions = {
        "topology": lambda row: str(row["topology"]),
        "total_reaction_count": lambda row: str(row["total_reaction_count"]),
        "longest_linear_route": lambda row: str(row["longest_linear_route"]),
        "distinct_leaf_count": lambda row: str(row["distinct_leaf_count"]),
    }
    output: list[dict[str, Any]] = []
    for entity_type in ("rrsubtree_cons", "rrsubtree_gap"):
        for dimension, getter in dimensions.items():
            grouped: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
            for row in route_rows:
                grouped[getter(row)].append(row)
            for value, members in sorted(
                grouped.items(), key=lambda item: _numeric_aware(item[0])
            ):
                occurrences = 0
                known_occurrences = 0
                query_families: set[str] = set()
                known_families: set[str] = set()
                positive_routes = 0
                for row in members:
                    evidence = route_evidence[(str(row["route_id"]), entity_type)]
                    if evidence.occurrences:
                        positive_routes += 1
                    occurrences += len(evidence.occurrences)
                    known_occurrences += sum(
                        family is not None for _, family in evidence.occurrences
                    )
                    query_families.update(evidence.families)
                    known_families.update(
                        key
                        for key, family in evidence.families.items()
                        if family.reference_family is not None
                    )
                output.append(
                    {
                        "entity_type": entity_type,
                        "stratification": dimension,
                        "stratum": value,
                        "route_count": len(members),
                        "positive_route_count": positive_routes,
                        "route_prevalence": positive_routes / len(members),
                        "occurrence_count": occurrences,
                        "known_occurrence_count": known_occurrences,
                        "occurrences_per_route": occurrences / len(members),
                        "occurrence_coverage": _fraction(
                            known_occurrences, occurrences
                        ),
                        "unique_family_count": len(query_families),
                        "known_family_count": len(known_families),
                        "family_coverage": _fraction(
                            len(known_families), len(query_families)
                        ),
                    }
                )
    return output


def _dataset_entity_summary(
    entity_type: EntityType,
    route_evidence: Mapping[tuple[str, EntityType], _RouteEvidence],
    reference: RouteAssessmentReference,
) -> dict[str, Any]:
    evidences = [
        evidence
        for (route_id, kind), evidence in route_evidence.items()
        if kind == entity_type
    ]
    occurrence_count = sum(len(item.occurrences) for item in evidences)
    known_occurrence_count = sum(
        family is not None for item in evidences for _, family in item.occurrences
    )
    query_families = {
        identity_json: family
        for item in evidences
        for identity_json, family in item.families.items()
    }
    known_query_families = {
        identity_json: family
        for identity_json, family in query_families.items()
        if family.reference_family is not None
    }
    reference_family_count = len(reference.families(entity_type))
    route_occurrence_coverages = [
        value
        for evidence in evidences
        if (value := _evidence_metrics(evidence)["occurrence_coverage"]) is not None
    ]
    route_family_coverages = [
        value
        for evidence in evidences
        if (value := _evidence_metrics(evidence)["family_coverage"]) is not None
    ]
    occurrence_bins = Counter(
        support_bin(0 if family is None else family.reference_route_support)
        for evidence in evidences
        for _, family in evidence.occurrences
    )
    family_bins = Counter(
        support_bin(
            0
            if item.reference_family is None
            else item.reference_family.reference_route_support
        )
        for item in query_families.values()
    )
    return {
        "reference_family_count": reference_family_count,
        "query_occurrence_count": occurrence_count,
        "known_occurrence_count": known_occurrence_count,
        "novel_occurrence_count": occurrence_count - known_occurrence_count,
        "query_family_count": len(query_families),
        "shared_family_count": len(known_query_families),
        "query_only_family_count": len(query_families) - len(known_query_families),
        "reference_only_family_count": reference_family_count
        - len(known_query_families),
        "occurrence_weighted_coverage": _fraction(
            known_occurrence_count, occurrence_count
        ),
        "family_weighted_coverage": _fraction(
            len(known_query_families), len(query_families)
        ),
        "positive_route_count": sum(bool(item.occurrences) for item in evidences),
        "route_occurrence_coverage_distribution": _distribution(
            route_occurrence_coverages
        ),
        "route_family_coverage_distribution": _distribution(route_family_coverages),
        "occurrence_support_bin_fractions": {
            label: _fraction(occurrence_bins[label], occurrence_count)
            for label in SUPPORT_BINS
        },
        "family_support_bin_fractions": {
            label: _fraction(family_bins[label], len(query_families))
            for label in SUPPORT_BINS
        },
    }


def _distribution(values: Sequence[float]) -> dict[str, float | None]:
    return {
        "count": len(values),
        "mean": statistics.fmean(values) if values else None,
        "median": statistics.median(values) if values else None,
        "q05": _quantile(values, 0.05),
        "q25": _quantile(values, 0.25),
        "q75": _quantile(values, 0.75),
        "q95": _quantile(values, 0.95),
    }


def _length_two_evidence(
    evidence: _RouteEvidence,
) -> _RouteEvidence:
    output = _RouteEvidence()
    for occurrence, family in evidence.occurrences:
        if occurrence.identity.motif_length == 2:
            output.add(occurrence, family)
    return output


def assess_route_corpus(
    reference_assessment: str | Path,
    query_reference_library: str | Path,
    query_composite_library: str | Path,
    query_routes_json: str | Path,
    output_dir: str | Path,
    *,
    verification: Verification = "fast",
) -> Mapping[str, Any]:
    """Assess every query route against one frozen Reference precedent index."""

    destination = Path(output_dir).expanduser()
    temp_root = _atomic_directory(destination)
    try:
        with RouteAssessmentReference.load(
            reference_assessment, verification=verification
        ) as frozen:
            with open_reference_source(
                query_reference_library, verification=verification
            ) as query:
                if (
                    query.manifest.configuration_fingerprint
                    != frozen.processing_profile_fingerprint
                ):
                    raise ValueError("query and Reference processing profiles differ")
                if query.dataset_id == frozen.reference_dataset:
                    raise ValueError("query dataset must differ from Reference dataset")
                with open_composite_source(
                    query_composite_library,
                    reference=query,
                    verification=verification,
                ) as composites:
                    if frozen.manifest.get("source_schemas", {}).get(
                        "composite_library_format", 1
                    ) != composites.manifest.library_format_version or frozen.manifest[
                        "identity_contract"
                    ].get("composite") != composite_identity_contract(
                        composites.manifest.library_format_version
                    ):
                        raise ValueError(
                            "composite assessment identity policies differ; use matching "
                            "companion versions and rebuild the assessment Reference index"
                        )
                    routes_path = Path(query_routes_json).expanduser()
                    if _sha256_file(routes_path) != query.source_routes_sha256:
                        raise ValueError(
                            "query route JSON differs from its library source digest"
                        )
                    topology_by_route: dict[str, dict[str, Any]] = {}
                    for raw_route_id, route in iter_route_items_from_json_file(
                        routes_path, None
                    ):
                        route_id = str(raw_route_id)
                        if route_id in topology_by_route:
                            raise ValueError(f"duplicate query route ID: {route_id}")
                        topology_by_route[route_id] = route_topology_metrics(route)
                    if len(topology_by_route) != int(query.corpus["route_count"]):
                        raise ValueError(
                            "query route count differs from Reference-library corpus"
                        )

                    route_evidence = {
                        (route_id, entity_type): _RouteEvidence()
                        for route_id in topology_by_route
                        for entity_type in ENTITY_TYPES
                    }
                    occurrence_rows: list[dict[str, Any]] = []
                    observed_occurrence_ids: set[tuple[str, str]] = set()
                    for occurrence in iter_all_occurrences(query, composites):
                        if occurrence.route_id not in topology_by_route:
                            raise ValueError(
                                "query occurrence has an unknown route: "
                                f"{occurrence.occurrence_id}"
                            )
                        key = (
                            occurrence.identity.entity_type,
                            occurrence.occurrence_id,
                        )
                        if key in observed_occurrence_ids:
                            raise ValueError(f"duplicate query occurrence: {key}")
                        observed_occurrence_ids.add(key)
                        family = frozen.lookup(occurrence.identity)
                        route_evidence[
                            (occurrence.route_id, occurrence.identity.entity_type)
                        ].add(occurrence, family)
                        occurrence_rows.append(
                            {
                                "schema_version": ASSESSMENT_OUTPUT_SCHEMA_VERSION,
                                "query_dataset": query.dataset_id,
                                "reference_dataset": frozen.reference_dataset,
                                "route_id": occurrence.route_id,
                                "entity_type": occurrence.identity.entity_type,
                                "query_occurrence_id": occurrence.occurrence_id,
                                "native_occurrence_id": occurrence.native_occurrence_id,
                                "source_entry_id": occurrence.source_entry_id,
                                "source_kind": occurrence.source_kind,
                                "motif_length": occurrence.identity.motif_length,
                                "family_locator": occurrence.identity.identity_sha256,
                                "reference_family_id": (
                                    None if family is None else family.family_id
                                ),
                                "status": "novel" if family is None else "known",
                                "reference_route_support": (
                                    0
                                    if family is None
                                    else family.reference_route_support
                                ),
                                "reference_occurrence_support": (
                                    0
                                    if family is None
                                    else family.reference_occurrence_support
                                ),
                                "support_bin": support_bin(
                                    0
                                    if family is None
                                    else family.reference_route_support
                                ),
                                "selected_reaction_node_paths": [
                                    list(path)
                                    for path in occurrence.selected_reaction_node_paths
                                ],
                                "skipped_reaction_node_paths": [
                                    list(path)
                                    for path in occurrence.skipped_reaction_node_paths
                                ],
                            }
                        )

                    route_rows: list[dict[str, Any]] = []
                    for route_id in sorted(topology_by_route, key=_numeric_aware):
                        row: dict[str, Any] = {
                            "dataset_id": query.dataset_id,
                            "source_identity": query.source_identity,
                            "route_id": route_id,
                            **topology_by_route[route_id],
                        }
                        for entity_type in ENTITY_TYPES:
                            metrics = _evidence_metrics(
                                route_evidence[(route_id, entity_type)]
                            )
                            row.update(_prefix_metrics(entity_type, metrics))
                        route_rows.append(row)

                    summary_by_entity = {
                        entity_type: _dataset_entity_summary(
                            entity_type, route_evidence, frozen
                        )
                        for entity_type in ENTITY_TYPES
                    }
                    summary = {
                        "schema_version": ASSESSMENT_OUTPUT_SCHEMA_VERSION,
                        "reference_assessment_id": frozen.reference_id,
                        "reference_dataset": frozen.reference_dataset,
                        "query_dataset": query.dataset_id,
                        "query_route_count": len(route_rows),
                        "by_entity": summary_by_entity,
                    }
                    overlap_rows = [
                        {
                            "entity_type": entity_type,
                            "reference_only_family_count": values[
                                "reference_only_family_count"
                            ],
                            "shared_family_count": values["shared_family_count"],
                            "query_only_family_count": values[
                                "query_only_family_count"
                            ],
                            "union_family_count": (
                                values["reference_family_count"]
                                + values["query_only_family_count"]
                            ),
                        }
                        for entity_type, values in summary_by_entity.items()
                    ]

                    baseline_rows: list[dict[str, Any]] = []
                    baseline_by_route: dict[tuple[str, str], Mapping[str, Any]] = {}
                    for label, entity_type in (
                        ("rrseq_cons_length_2", "rrseq_cons"),
                        ("retro_bleu_bigram", "retro_bleu_bigram"),
                    ):
                        filtered = []
                        for route_id in topology_by_route:
                            evidence = route_evidence[(route_id, entity_type)]
                            if label == "rrseq_cons_length_2":
                                evidence = _length_two_evidence(evidence)
                            metrics = _evidence_metrics(evidence)
                            filtered.append(metrics)
                            baseline_by_route[(route_id, label)] = metrics
                        occurrence_count = sum(
                            int(row["occurrence_count"]) for row in filtered
                        )
                        known_occurrence_count = sum(
                            int(row["known_occurrence_count"]) for row in filtered
                        )
                        family_payloads: dict[str, bool] = {}
                        for route_id in topology_by_route:
                            evidence = route_evidence[(route_id, entity_type)]
                            if label == "rrseq_cons_length_2":
                                evidence = _length_two_evidence(evidence)
                            for key, family in evidence.families.items():
                                family_payloads[key] = (
                                    family.reference_family is not None
                                )
                        known_family_count = sum(family_payloads.values())
                        baseline_rows.append(
                            {
                                "channel": label,
                                "route_count": len(route_rows),
                                "positive_route_count": sum(
                                    int(row["occurrence_count"] > 0) for row in filtered
                                ),
                                "occurrence_count": occurrence_count,
                                "known_occurrence_count": known_occurrence_count,
                                "occurrence_coverage": _fraction(
                                    known_occurrence_count, occurrence_count
                                ),
                                "unique_family_count": len(family_payloads),
                                "known_family_count": known_family_count,
                                "family_coverage": _fraction(
                                    known_family_count, len(family_payloads)
                                ),
                            }
                        )
                    disagreement_rows = []
                    for route_id in sorted(topology_by_route, key=_numeric_aware):
                        rrseq = baseline_by_route[(route_id, "rrseq_cons_length_2")]
                        bigram = baseline_by_route[(route_id, "retro_bleu_bigram")]
                        rrseq_coverage = rrseq["occurrence_coverage"]
                        bigram_coverage = bigram["occurrence_coverage"]
                        disagreement_rows.append(
                            {
                                "route_id": route_id,
                                "topology": topology_by_route[route_id]["topology"],
                                "total_reaction_count": topology_by_route[route_id][
                                    "total_reaction_count"
                                ],
                                "rrseq_cons_length_2_occurrence_count": rrseq[
                                    "occurrence_count"
                                ],
                                "rrseq_cons_length_2_coverage": rrseq_coverage,
                                "bigram_occurrence_count": bigram["occurrence_count"],
                                "bigram_coverage": bigram_coverage,
                                "coverage_difference_bigram_minus_rrseq": (
                                    None
                                    if rrseq_coverage is None or bigram_coverage is None
                                    else bigram_coverage - rrseq_coverage
                                ),
                            }
                        )
                    topology_rows = _topology_rows(route_rows, route_evidence)

                    route_path = temp_root / "route_assessment.tsv"
                    occurrence_path = temp_root / "occurrences.jsonl"
                    summary_path = temp_root / "summary.json"
                    overlap_path = temp_root / "family_overlap.tsv"
                    baseline_path = temp_root / "rrseq_bigram_comparison.tsv"
                    disagreement_path = temp_root / "rrseq_bigram_disagreements.tsv"
                    topology_path = temp_root / "rrsubtree_topology.tsv"
                    errors_path = temp_root / "errors.tsv"
                    _write_tsv(route_path, route_rows, _route_columns())
                    _write_jsonl(
                        occurrence_path,
                        sorted(
                            occurrence_rows,
                            key=lambda row: (
                                _numeric_aware(str(row["route_id"])),
                                str(row["entity_type"]),
                                str(row["query_occurrence_id"]),
                            ),
                        ),
                    )
                    _write_json(summary_path, summary)
                    _write_tsv(
                        overlap_path,
                        overlap_rows,
                        (
                            "entity_type",
                            "reference_only_family_count",
                            "shared_family_count",
                            "query_only_family_count",
                            "union_family_count",
                        ),
                    )
                    _write_tsv(
                        baseline_path,
                        baseline_rows,
                        tuple(baseline_rows[0]),
                    )
                    _write_tsv(
                        disagreement_path,
                        disagreement_rows,
                        tuple(disagreement_rows[0]),
                    )
                    _write_tsv(
                        topology_path,
                        topology_rows,
                        tuple(topology_rows[0]),
                    )
                    _write_tsv(errors_path, (), ("route_id", "entity_type", "error"))
                    artifacts = {
                        "route_assessment": _artifact(route_path, temp_root),
                        "occurrences": _artifact(occurrence_path, temp_root),
                        "summary": _artifact(summary_path, temp_root),
                        "family_overlap": _artifact(overlap_path, temp_root),
                        "rrseq_bigram_comparison": _artifact(baseline_path, temp_root),
                        "rrseq_bigram_disagreements": _artifact(
                            disagreement_path, temp_root
                        ),
                        "rrsubtree_topology": _artifact(topology_path, temp_root),
                        "errors": _artifact(errors_path, temp_root),
                    }
                    assessment_id = (
                        "route_corpus_assessment_"
                        + hashlib.sha256(
                            canonical_json(
                                {
                                    "schema_version": ASSESSMENT_OUTPUT_SCHEMA_VERSION,
                                    "reference_assessment_id": frozen.reference_id,
                                    "query_reference_library_id": (
                                        query.manifest.library_id
                                    ),
                                    "query_composite_library_id": (
                                        composites.manifest.library_id
                                    ),
                                    "query_routes_sha256": query.source_routes_sha256,
                                    "summary": summary,
                                    "artifact_hashes": {
                                        name: descriptor["sha256"]
                                        for name, descriptor in artifacts.items()
                                    },
                                }
                            ).encode("utf-8")
                        ).hexdigest()
                    )
                    manifest = {
                        "schema_version": ASSESSMENT_OUTPUT_SCHEMA_VERSION,
                        "assessment_id": assessment_id,
                        "created_at": _created_at(),
                        "route_inspector_version": __version__,
                        "reference_assessment_id": frozen.reference_id,
                        "reference_dataset": frozen.reference_dataset,
                        "query_dataset": query.dataset_id,
                        "processing_profile_fingerprint": (
                            query.manifest.configuration_fingerprint
                        ),
                        "query_reference_library_id": query.manifest.library_id,
                        "query_composite_library_id": composites.manifest.library_id,
                        "query_routes_sha256": query.source_routes_sha256,
                        "identity_contract": dict(frozen.manifest["identity_contract"]),
                        "null_handling": (
                            "routes without an entity have zero counts and null "
                            "coverage/support statistics"
                        ),
                        "statistics": summary,
                        "artifacts": artifacts,
                    }
                    _write_json(temp_root / "manifest.json", manifest)
        _publish(temp_root, destination)
    except BaseException:
        shutil.rmtree(temp_root, ignore_errors=True)
        raise
    return manifest


__all__ = [
    "ASSESSMENT_OUTPUT_SCHEMA_VERSION",
    "SUPPORT_BINS",
    "assess_route_corpus",
    "build_route_assessment_reference",
    "route_topology_metrics",
]
