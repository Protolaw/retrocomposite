"""Compare n1/n5 tactic pools after Tier-3 reaction-class generalization.

The analysis consumes persisted occurrence provenance from two Reference tactic
libraries.  It classifies each distinct canonical, atom-map-free source reaction
once, then replaces the selected reaction in every RRSeq/RRSubtree occurrence by
its provider-specific Tier-3 code.  Composite rules are deliberately outside this
analysis because a net composite is not an elementary classifiable reaction."""

from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path
from typing import Any

from route_inspector import __version__
from route_inspector.chemistry.classification.common import (
    provider_metadata,
    result_accepted,
)
from route_inspector.chemistry.classification.providers import (
    ReactionClassProvider,
)
from route_inspector.reference_library import (
    ReferenceTacticLibrary,
)
from route_inspector.tactics.classification.overlap import (
    ANALYSIS_SCHEMA_VERSION,
    DEFAULT_CANONICALIZATION_TIMEOUT,
    TACTIC_KINDS,
    _aggregate_class_families,
    _classifier_key,
    _classify_unique_reactions,
    _collect_unique_reactions,
    _panel_counts,
    _report_rows,
)
from route_inspector.tactics.classification.overlap_reporting import (
    _artifact_descriptor,
    _classification_record,
    _write_json,
    _write_jsonl,
    _write_tsv,
)


def build_reaction_class_overlap_analysis(
    *,
    left_library_path: str | Path,
    right_library_path: str | Path,
    output_dir: str | Path,
    provider: ReactionClassProvider,
    left_label: str = "n1",
    right_label: str = "n5",
    verification: str = "fast",
    n_cpu: int = 1,
    batch_size: int = 5000,
    canonicalization_timeout: float = DEFAULT_CANONICALIZATION_TIMEOUT,
) -> dict[str, Any]:
    """Classify occurrence provenance and publish four generalized overlaps."""

    if verification not in {"fast", "full"}:
        raise ValueError("verification must be 'fast' or 'full'")
    if int(batch_size) < 1:
        raise ValueError("batch_size must be positive")
    if float(canonicalization_timeout) < 0:
        raise ValueError("canonicalization_timeout cannot be negative")
    destination = Path(output_dir).expanduser()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(
        tempfile.mkdtemp(
            prefix=f".{destination.name}.",
            suffix=".tmp",
            dir=destination.parent,
        )
    )
    try:
        with (
            ReferenceTacticLibrary.load(
                left_library_path,
                verification=verification,
            ) as left_library,
            ReferenceTacticLibrary.load(
                right_library_path,
                verification=verification,
            ) as right_library,
        ):
            left_profile = left_library.processing_profile.fingerprint
            right_profile = right_library.processing_profile.fingerprint
            if left_profile != right_profile:
                raise ValueError(
                    "Reference libraries use incompatible processing profiles"
                )
            libraries = {"left": left_library, "right": right_library}
            mapped_by_key, canonicalization_errors = _collect_unique_reactions(
                libraries,
                timeout_seconds=float(canonicalization_timeout),
            )
            classifications = _classify_unique_reactions(
                mapped_by_key,
                canonicalization_errors,
                provider=provider,
                n_cpu=max(1, int(n_cpu)),
                batch_size=int(batch_size),
            )
            provider_name, provider_version, taxonomy = provider_metadata(provider)
            result_metadata = {
                (
                    result.provider_name,
                    result.provider_version,
                    result.taxonomy_id,
                )
                for result in classifications.values()
            }
            if result_metadata and result_metadata != {
                (provider_name, provider_version, taxonomy)
            }:
                raise RuntimeError(
                    "reaction-class results disagree on provider provenance"
                )
            families, coverage = _aggregate_class_families(
                libraries,
                classifications,
                provider=provider_name,
                taxonomy=taxonomy,
                canonicalization_timeout=float(canonicalization_timeout),
            )
            reports = {kind: _report_rows(families[kind]) for kind in TACTIC_KINDS}

            report_paths: dict[str, Path] = {}
            for kind in TACTIC_KINDS:
                path = temporary / f"{kind}.tsv"
                _write_tsv(path, reports[kind])
                report_paths[kind] = path

            class_records = [
                _classification_record(
                    classifier_input,
                    mapped_by_key[classifier_input],
                    classifications[classifier_input],
                )
                for classifier_input in sorted(classifications)
            ]
            classifications_path = temporary / "reaction_classes.jsonl"
            _write_jsonl(classifications_path, class_records)
            diagnostics_path = temporary / "diagnostics.jsonl"
            _write_jsonl(
                diagnostics_path,
                (row for row in class_records if not bool(row["accepted"])),
            )

            summary = {
                "schema_version": ANALYSIS_SCHEMA_VERSION,
                "comparison": "provider_specific_ordered_tier3_class_identity",
                "labels": {"left": left_label, "right": right_label},
                "provider": {
                    "name": provider_name,
                    "version": provider_version,
                    "taxonomy": taxonomy,
                    "tier": 3,
                },
                "unclassified_policy": "exclude_incomplete_occurrences",
                "canonicalization_timeout_seconds": float(canonicalization_timeout),
                "popularity_definition": "distinct_supporting_routes",
                "class_identity_semantics": {
                    "rrseq": "ordered selected Tier-3 codes; gap widths excluded",
                    "rrsubtree": (
                        "rooted Tier-3 topology with unordered siblings and "
                        "skipped-reaction counts"
                    ),
                    "skipped_reactions": "spans only; not class-labelled nodes",
                },
                "libraries": {
                    "left": {
                        "reference_library_id": left_library.library_id,
                        "processing_profile_fingerprint": left_profile,
                    },
                    "right": {
                        "reference_library_id": right_library.library_id,
                        "processing_profile_fingerprint": right_profile,
                    },
                },
                "unique_source_reactions": len(classifications),
                "canonicalization_error_count": len(canonicalization_errors),
                "unique_classifier_inputs": (
                    len(classifications) - len(canonicalization_errors)
                ),
                "accepted_classifier_inputs": sum(
                    result_accepted(result) for result in classifications.values()
                ),
                "panels": {kind: _panel_counts(reports[kind]) for kind in TACTIC_KINDS},
                "classification_coverage": {
                    kind: {
                        side: coverage[kind][side].to_dict()
                        for side in ("left", "right")
                    }
                    for kind in TACTIC_KINDS
                },
            }
            summary_path = temporary / "summary.json"
            _write_json(summary_path, summary)
            artifacts = {
                **{
                    kind: _artifact_descriptor(path, temporary)
                    for kind, path in report_paths.items()
                },
                "reaction_classes": _artifact_descriptor(
                    classifications_path,
                    temporary,
                ),
                "diagnostics": _artifact_descriptor(
                    diagnostics_path,
                    temporary,
                ),
                "summary": _artifact_descriptor(summary_path, temporary),
            }
            manifest = {
                "schema_version": ANALYSIS_SCHEMA_VERSION,
                "route_inspector_version": __version__,
                "analysis": "n1_n5_reaction_class_tactic_overlap",
                "provider": summary["provider"],
                "identity_contract": summary["class_identity_semantics"],
                "unclassified_policy": summary["unclassified_policy"],
                "libraries": summary["libraries"],
                "artifacts": artifacts,
            }
            _write_json(temporary / "manifest.json", manifest)
        if destination.exists():
            raise FileExistsError(destination)
        os.rename(temporary, destination)
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise
    finally:
        _classifier_key.cache_clear()
    return summary
