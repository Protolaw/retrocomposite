"""Corpus execution and publication for gapped classification."""

from __future__ import annotations

from pathlib import Path

from route_inspector.infrastructure.artifacts import write_json, write_standard_sidecars
from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
from route_inspector.infrastructure.text import write_tsv
from route_inspector.tactics.rrseq.gapped_classification import (
    CLASSIFICATION_FIELDS,
    COMPLEMENTARY_MOTIF_FIELDS,
    GappedRRSeqClass,
    _dataset_prefix,
    classification_summary,
    classification_tsv_row,
    classify_gapped_occurrence,
    complementary_motif_rows,
    load_gapped_occurrences,
    load_protection_events,
    write_gapped_classification_json,
)
from route_inspector.workflows.requests import ClassifyGappedRrseqsRequest


def run(args: ClassifyGappedRrseqsRequest) -> int:
    """Classify gapped RRSeq occurrence sidecars and write deterministic artifacts."""

    setup_runtime_cache_dirs()
    occurrences, input_paths = load_gapped_occurrences(args.rrseq_gap_occurrences)
    detect_complementary = bool(getattr(args, "detect_complementary", False))
    protection_index = (
        load_protection_events(getattr(args, "protection_events", None))
        if detect_complementary
        else None
    )
    classified = []
    for occurrence in occurrences:
        result = classify_gapped_occurrence(
            occurrence,
            context_radius=int(getattr(args, "context_radius", 2)),
            max_replay_outcomes=int(getattr(args, "max_replay_outcomes", 256)),
            protection_index=protection_index,
            require_unique_replay=bool(getattr(args, "require_unique_replay", False)),
            detect_complementary=detect_complementary,
        )
        classified.append({**occurrence, **result.to_dict()})
    classified.sort(key=lambda record: str(record["occurrence_id"]))

    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    prefix = str(
        getattr(args, "output_prefix", None) or _dataset_prefix(input_paths[0])
    )
    compact_path = output_dir / f"{prefix}_gapped_rrseq_classification.tsv"
    detailed_path = output_dir / f"{prefix}_gapped_rrseq_classification.json"
    summary_path = output_dir / "summary.json"
    write_tsv(
        compact_path, CLASSIFICATION_FIELDS, map(classification_tsv_row, classified)
    )
    write_gapped_classification_json(detailed_path, classified)

    output_files: dict[str, Path] = {
        "classification_tsv": compact_path,
        "classification_json": detailed_path,
        "summary": summary_path,
    }
    for classification in GappedRRSeqClass:
        path = output_dir / f"{prefix}_{classification.value}_gapped_rrseqs.tsv"
        rows = [
            classification_tsv_row(record)
            for record in classified
            if record["classification"] == classification.value
        ]
        write_tsv(path, CLASSIFICATION_FIELDS, rows)
        output_files[classification.value] = path

    motif_path = output_dir / f"{prefix}_complementary_gapped_rrseq_motifs.tsv"
    motif_rows = complementary_motif_rows(classified)
    write_tsv(motif_path, COMPLEMENTARY_MOTIF_FIELDS, motif_rows)
    output_files["complementary_motifs"] = motif_path

    summary = classification_summary(
        classified,
        context_radius=int(getattr(args, "context_radius", 2)),
        max_replay_outcomes=int(getattr(args, "max_replay_outcomes", 256)),
        detect_complementary=detect_complementary,
    )
    summary["output_files"] = {key: str(value) for key, value in output_files.items()}
    write_json(summary_path, summary)
    write_standard_sidecars(
        output_dir,
        command_name="classify-gapped-rrseqs",
        summary=summary,
        input_files=[
            *input_paths,
            *(
                [args.protection_events]
                if detect_complementary and getattr(args, "protection_events", None)
                else []
            ),
        ],
        output_files=output_files,
        cli_args=args,
        extra_manifest={
            "classification_schema_version": 2,
            "factorability_scope": "normalized_mapped_route_structural",
        },
    )
    return 0
