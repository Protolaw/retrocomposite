"""Corpus execution and publication for protection classes."""

from __future__ import annotations

import sys

from route_inspector.protection.interval_rxnclass import (
    COMMAND_NAME,
    classify_protection_interval_reactions,
)
from route_inspector.workflows.requests import (
    ClassifyProtectionIntervalReactionsRequest,
)


def run(args: ClassifyProtectionIntervalReactionsRequest) -> int:
    """Run introduced-PG interval classification from the CLI."""

    summary = classify_protection_interval_reactions(
        args.routes_json,
        args.protection_events,
        output_dir=args.output_dir,
        rule_config=args.rule_config,
        backend=args.backend,
        reaction_classifier_path=args.reaction_classifier_path,
        namerxn_executable=args.namerxn_executable,
        tier=args.tier,
        label_policy=args.label_policy,
        n_cpu=args.n_cpu,
        worker_chunksize=args.worker_chunksize,
        torch_threads=args.torch_threads,
        device=args.device,
        limit_events=args.limit_events,
        ignore_errors=args.ignore_errors,
        progress_interval=args.progress_interval,
        cli_args=args,
    )
    print(
        f"[{COMMAND_NAME}] done: {summary['introduced_events']} introduced events, "
        f"{summary['interval_step_occurrences']} interval reactions",
        file=sys.stderr,
        flush=True,
    )
    return 0
