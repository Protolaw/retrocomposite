"""Extract topology-contiguous SynPlanner rule n-grams from route trees.

The traversal follows the parent-to-child reaction relationships used by Retro-BLEU,
but the tokens are Chython/SynPlanner rules rather than RDChiral templates.  Unlike an
RRseq_cons, a Retro-BLEU gram has no reaction-center continuity requirement.

Paper: https://doi.org/10.1039/D3DD00219E
Reference implementation: https://github.com/catalystforyou/Retro-BLEU
"""

from __future__ import annotations

import json
from copy import copy
from pathlib import Path

import route_inspector.rules.extraction as _owner_extraction
import route_inspector.workflows.rrseq as _owner_corpus
from route_inspector.infrastructure.artifacts import (
    dataset_prefix_from_path,
    stage_output_dir,
)
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.runtime import normalize_n_cpu
from route_inspector.infrastructure.text import read_json
from route_inspector.metrics.retro_bleu.grams import (
    _collect_unique_reaction_smiles,
    _extract_from_prepared_routes,
    _limited_routes,
    _prepare_route_items,
    _validate_lengths,
    write_retro_bleu_gram_outputs,
)
from route_inspector.workflows.requests import ExtractRetroBleuGramsRequest


def run(args: ExtractRetroBleuGramsRequest) -> int:
    """Run Retro-BLEU gram extraction from the CLI."""

    _validate_lengths(args.min_length, args.max_length)
    routes_path = resolve_existing_path(args.routes_json)
    dataset = dataset_prefix_from_path(routes_path)
    output_dir = (
        Path(args.output_dir).expanduser()
        if args.output_dir is not None
        else stage_output_dir(Path("outputs"), dataset, "retro_bleu")
    )
    routes_json = _limited_routes(read_json(routes_path), args.limit)
    prepared, preparation_errors, routes_seen = _prepare_route_items(
        routes_json,
        dataset=dataset,
    )
    unique_reactions = _collect_unique_reaction_smiles(prepared)
    worker_args = copy(args)
    worker_args.ignore_errors = True
    n_cpu = normalize_n_cpu(args.n_cpu)
    serialized_steps, extraction_errors, unique_stats = (
        _owner_corpus.extract_unique_reaction_rules(
            unique_reactions,
            worker_args,
            n_cpu=n_cpu,
            worker_chunksize=args.worker_chunksize,
        )
    )
    extractor = _owner_extraction.PrecomputedRuleExtractor(
        serialized_steps,
        extraction_errors,
    )
    result = _extract_from_prepared_routes(
        prepared,
        rule_extractor=extractor,
        dataset=dataset,
        min_length=args.min_length,
        max_length=args.max_length,
        preparation_errors=preparation_errors,
        routes_seen=routes_seen,
    )
    result.extra_summary.update(
        {
            **unique_stats,
            "n_cpu": n_cpu,
            "worker_chunksize": args.worker_chunksize if n_cpu > 1 else 1,
        }
    )
    output_files = write_retro_bleu_gram_outputs(
        result,
        output_dir,
        routes_json_path=routes_path,
        config_path=args.config,
        cli_args=args,
    )
    print(json.dumps({**result.summary(), "output_files": output_files}, indent=2))
    return 0
