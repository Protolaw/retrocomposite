"""Single prepared-route assessment service shared by interactive clients."""

from pathlib import Path

from route_inspector.reference_library.settings import ProcessorSettings
from route_inspector.workflows.reference_library import (
    _atomic_assessment_output,
    assess_routes,
    processing_profile_from_args,
    tactic_processor_from_profile,
)


def assess_prepared_route(
    library,
    route,
    *,
    route_id,
    source_sha256,
    config,
    output_dir: Path,
    verification="fast",
):
    """Preserve source collection identity and the existing assessment schema."""
    if library.processing_profile.input_state != "preprocessed":
        raise ValueError("interactive analysis requires a preprocessed-input library")
    profile, rule_config, protection_config = processing_profile_from_args(
        ProcessorSettings(config=config, input_state="preprocessed"),
        library_profile=library.processing_profile,
    )
    library.assert_compatible(profile)
    processor = tactic_processor_from_profile(
        profile,
        rule_config=rule_config,
        protection_config=protection_config,
        include_retro_bleu_bigrams=library.retro_bleu_bigram_catalog is not None,
        tactic_identity_version=library.tactic_identity_version,
    )
    assessments = assess_routes(
        [(str(route_id), route)],
        processor,
        library,
        dataset_id=f"query_{source_sha256[:16]}",
        source_identity=f"sha256:{source_sha256}",
    )
    _atomic_assessment_output(
        output_dir,
        assessments,
        library=library,
        query_input_sha256=source_sha256,
        selected_route_ids=(str(route_id),),
        library_verification_requested=verification,
    )
    return assessments[0]
