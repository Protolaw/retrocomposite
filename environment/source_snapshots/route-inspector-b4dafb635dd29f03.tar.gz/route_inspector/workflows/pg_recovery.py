"""Native PG removal / evidence transfer workflows; original recovery is held out."""

import json
import sqlite3
from collections import Counter, defaultdict
from dataclasses import dataclass
from functools import partial
from pathlib import Path
from time import perf_counter

from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.protection.recovery import retrieval
from route_inspector.protection.recovery.artifacts import (
    finish,
    portable,
    publication,
    publish_copy,
    stable_id,
    write_json,
)
from route_inspector.protection.recovery.boundaries import BOUNDARY_POLICY
from route_inspector.protection.recovery.eligibility import (
    ELIGIBILITY_POLICY,
    eligibility_reasons,
)
from route_inspector.protection.recovery.endpoints import (
    ENDPOINT_POLICY,
    build_bank,
    eligible_pairs,
    reference_record,
)
from route_inspector.protection.recovery.evaluation import evaluate
from route_inspector.protection.recovery.evidence import (
    build_evidence,
    equivalent,
    extract_steps,
    key,
    library_input,
    stored_steps,
    windows,
)
from route_inspector.protection.recovery.generation import generate, sites
from route_inspector.protection.recovery.lifetimes import LIFETIME_POLICY, extensions
from route_inspector.protection.recovery.performance import (
    BoundedRuleCache,
    proposal_gc_scope,
)
from route_inspector.protection.recovery.placement import (
    PLACEMENT_POLICY,
    generalized_endpoint,
    placements,
    relation,
    transfer_groups,
)
from route_inspector.protection.recovery.selectivity import (
    SELECTIVITY_POLICY,
    acceptance_failures,
    selectivity_warnings,
)
from route_inspector.protection.recovery.stripping import STRIPPING_POLICY, strip_route
from route_inspector.protection.recovery.trees import (
    COMPARISON_POLICY,
    compare_trees,
    fingerprint,
    primary,
    validate,
)
from route_inspector.routes.access import route_items


def strip_pg_routes(
    request, *, progress=lambda stage, message: print(message, flush=True)
):
    output = Path(request.output)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite {output}")
    if request.eligibility not in {"ngram", "all"}:
        raise ValueError("Unknown stripping eligibility policy")
    routes, events, processor, provenance = library_input(
        request.library, request.routes_json
    )
    protection_rules = getattr(processor, "protection_rules", None)
    stripped, ledger, diagnostics = {}, [], []
    all_events = defaultdict(list)
    with (Path(request.library) / "provenance/events.jsonl").open() as stream:
        for line in stream:
            event = json.loads(line)
            all_events[event["route"]["route_id"]].append(event)
    excluded, exclusion_counts = {}, Counter()
    for i, (rid, selected) in enumerate(
        sorted(
            events.items(),
            key=lambda p: (0, int(p[0])) if p[0].isdigit() else (1, p[0]),
        )
    ):
        try:
            reasons = eligibility_reasons(
                selected, all_events[rid], rules=protection_rules
            )
            if request.eligibility == "all" or not reasons:
                tree, record = strip_route(routes[rid], selected)
                reasons = eligibility_reasons(
                    selected, all_events[rid], stripping=record, rules=protection_rules
                )
            if request.eligibility == "ngram" and reasons:
                excluded[rid] = {"original_tree": routes[rid], "reasons": reasons}
                exclusion_counts.update({r["code"] for r in reasons})
                ledger.append(
                    {
                        "route_id": rid,
                        "status": "ineligible",
                        "event_ids": [e["occurrence_id"] for e in selected],
                        "reasons": reasons,
                    }
                )
                continue
            record["source_route_fingerprint"] = fingerprint(routes[rid])
            record["eligibility"] = {"policy": request.eligibility, "reasons": reasons}
            stripped[rid] = tree
            ledger.append(
                {
                    "route_id": rid,
                    "status": "stripped",
                    **{k: v for k, v in record.items() if k != "original_tree"},
                }
            )
        except Exception as exc:
            excluded[rid] = {
                "original_tree": routes[rid],
                "reasons": [{"code": "stripping_error", "message": str(exc)}],
            }
            diagnostics.append(
                {"stage": "stripping", "route_id": rid, "message": str(exc)}
            )
            ledger.append(
                {
                    "route_id": rid,
                    "status": "excluded",
                    "event_ids": [e["occurrence_id"] for e in selected],
                    "reason": str(exc),
                }
            )
        if i % 25 == 0:
            progress(
                "stripping",
                f"Processed {i + 1}/{len(events)} routes; {len(stripped)} published; {len(excluded)} excluded",
            )
    summary = {
        "selected_routes": len(events),
        "selected_events": sum(map(len, events.values())),
        "published_routes": len(stripped),
        "excluded_routes": len(excluded),
        "ineligible_routes": len(excluded) - len(diagnostics),
        "stripping_error_routes": len(diagnostics),
        "eligibility_exclusion_counts": dict(exclusion_counts),
        "stripped_events": sum(
            len(t["metadata"]["pg_stripping"]["events"]) for t in stripped.values()
        ),
        "zero_lifespan_events": sum(
            e["lifetime_steps"] == 0 for es in events.values() for e in es
        ),
        "steps_before": sum(
            t["metadata"]["pg_stripping"]["steps_before"] for t in stripped.values()
        ),
        "steps_after": sum(
            t["metadata"]["pg_stripping"]["steps_after"] for t in stripped.values()
        ),
    }
    assert (
        summary["published_routes"] + summary["excluded_routes"]
        == summary["selected_routes"]
    )
    with publication(request.output_dir) as root:
        write_json(root / "routes.json", stripped)
        write_json(root / "transformation_ledger.json", ledger)
        write_json(root / "excluded_routes.json", excluded)
        finish(
            root,
            summary,
            {
                **provenance,
                "operation": "strip_pg_routes",
                "stripping_policy": STRIPPING_POLICY,
                "source": portable(request.routes_json),
                "output": portable(output),
                "eligibility": request.eligibility,
                "eligibility_policy": ELIGIBILITY_POLICY,
            },
            diagnostics,
        )
    # Exclusive creation prevents overwriting a clean corpus even if a second
    # process published it while this workflow was running.
    publish_copy(Path(request.output_dir) / "routes.json", output)
    return summary


def _rank(group):
    support = group["support"]
    return (
        -len(group["paths"]),
        -len({r["route_id"] for r in support}),
        -len({r["event"]["occurrence_id"] for r in support}),
        group["pg_type"],
        group["mode"],
        group["paths"],
    )


@dataclass
class _SearchBudget:
    max_attempts: int
    max_proposals: int
    attempts: int = 0
    proposals: int = 0
    limited: bool = False

    @property
    def exhausted(self):
        return (
            self.attempts >= self.max_attempts or self.proposals >= self.max_proposals
        )


def _match_groups(
    query,
    steps,
    index,
    secondary,
    maximum,
    excluded_fingerprint,
    diagnostics,
    rid,
    counts,
    *,
    tertiary=None,
    additional_steps=(),
):
    groups = {}
    variants = [("native_resonance", steps), *additional_steps]
    passes = []
    for tier, projected_index, environment in (
        ("exact", index, None),
        ("reduced_context", secondary, 1),
        ("center_only", tertiary, 0),
    ):
        if projected_index is None:
            continue
        for representation, variant in variants:
            available = {}
            for path, rule in variant.items():
                try:
                    if environment is not None:
                        retrieval.step_key(rule, environment)
                    available[path] = rule
                except (ValueError, TypeError) as exc:
                    diagnostics.append(
                        {
                            "stage": "query_retrieval"
                            if environment == 1
                            else "query_center_retrieval",
                            "route_id": rid,
                            "path": list(path),
                            "message": str(exc),
                        }
                    )
            passes.append(
                (
                    tier,
                    projected_index,
                    available,
                    key
                    if environment is None
                    else partial(retrieval.key, environment=environment),
                    equivalent
                    if environment is None
                    else partial(retrieval.equivalent, environment=environment),
                    representation,
                )
            )
    for tier, lookup, available_steps, make_key, same, representation in passes:
        stronger_windows = {
            (g["paths"], g["pg_type"])
            for g in groups.values()
            if g["tier"] != "center_only"
        }
        suppressed = set()
        for paths, rules in windows(query, available_steps, maximum):
            for evidence in lookup.get(make_key(rules), []):
                if evidence["fingerprint"] == excluded_fingerprint:
                    counts[
                        "excluded_identical_reference_windows"
                        if tier == "exact"
                        else "excluded_identical_reduced_reference_windows"
                        if tier == "reduced_context"
                        else "excluded_identical_center_reference_windows"
                    ] += 1
                    continue
                if not same(rules, evidence["rules"]):
                    continue
                # Gate across both stored and normalized channels using only
                # query windows and reference PG types, never held-out outcomes.
                window_pg = (paths, evidence["event"]["pg_type"])
                if tier == "center_only" and window_pg in stronger_windows:
                    suppressed.add(window_pg)
                    continue
                # Exact pairs already have stronger evidence. A reduced window
                # must differ in at least one full rule, with every projected
                # step still matching in order within one reference event.
                if tier != "exact" and equivalent(rules, evidence["rules"]):
                    continue
                group_key = (paths, evidence["event"]["pg_type"], evidence["mode"])
                if group_key in groups and not equivalent(
                    groups[group_key]["rules"], rules
                ):
                    # Keep one executable query representation per evidence group.
                    continue
                group = groups.setdefault(
                    group_key,
                    {
                        "paths": paths,
                        "rules": rules,
                        "pg_type": evidence["event"]["pg_type"],
                        "mode": evidence["mode"],
                        "tier": tier,
                        "query_representation": representation,
                        "support": [],
                    },
                )
                if evidence not in group["support"]:
                    group["support"].append(evidence)
        if tier == "center_only":
            counts["center_only_suppressed_windows"] += len(suppressed)
    return groups


@proposal_gc_scope()
def propose_pg_strategies(
    request, *, progress=lambda stage, message: print(message, flush=True)
):
    started = perf_counter()
    if request.evidence_retrieval not in {
        "exact",
        "exact_then_reduced_context",
        "exact_then_reduced_context_then_center_only",
    }:
        raise ValueError("Unknown PG evidence retrieval policy")
    if request.lifetime_search not in {"expand", "matched_window"}:
        raise ValueError("Unknown PG lifetime search policy")
    if request.endpoint_search not in {"matched_event", "same_pg_library"}:
        raise ValueError("Unknown PG endpoint search policy")
    if request.placement_fallback not in {
        "off",
        "same_pg",
        "related_families",
        "query_groups",
    }:
        raise ValueError("Unknown placement fallback policy")
    if request.identical_source_policy not in {"exclude", "allow_diagnostic"}:
        raise ValueError("Unknown identical-source policy")
    if request.replay_selectivity not in {"warn_competing", "strict"}:
        raise ValueError("Unknown replay-selectivity policy")
    if request.boundary_search not in {"off", "reference_neighbors"}:
        raise ValueError("Unknown boundary search policy")
    if request.max_lifetime_extension < 0:
        raise ValueError("Lifetime extension limit must be nonnegative")
    if request.site_discovery not in {"functional_group_core", "reference_context"}:
        raise ValueError("Unknown PG site discovery policy")
    if (
        min(
            request.max_proposals,
            request.max_attempts,
            request.max_site_matches,
            request.max_selectivity_applications,
            request.max_center_attempts,
            request.max_center_proposals,
            request.max_endpoint_attempts,
            request.max_endpoint_proposals,
        )
        < 1
    ):
        raise ValueError(
            "Proposal, attempt, site, and selectivity limits must be positive"
        )
    if Path(request.output_dir).exists():
        raise FileExistsError(f"Refusing to overwrite {request.output_dir}")
    references, events, processor, provenance = library_input(
        request.library, request.reference_routes_json
    )
    # The complete corpus was hash-verified above. Only these event routes can
    # supply evidence/endpoints; release the remaining source trees from memory.
    references = {rid: references[rid] for rid in events}
    diagnostics = []
    endpoint_entries = []
    boundary_index = {} if request.boundary_search != "off" else None
    index, maximum, reference_zero = build_evidence(
        references,
        events,
        processor,
        diagnostics,
        progress,
        recorded_steps=stored_steps(request.library, events),
        endpoint_entries=endpoint_entries,
        boundary_index=boundary_index,
    )
    endpoint_bank, endpoint_events = build_bank(
        references,
        endpoint_entries,
        diagnostics,
        reverse_rule=processor.profile["rule_extraction_config"]["reverse_rule"],
        protection_rules=processor.protection_rules,
    )
    secondary = (
        retrieval.build_index(index, diagnostics)
        if request.evidence_retrieval != "exact"
        else None
    )
    tertiary = (
        retrieval.build_index(index, diagnostics, environment=0)
        if request.evidence_retrieval == "exact_then_reduced_context_then_center_only"
        else None
    )
    boundary_indices = {
        role: (
            exact,
            retrieval.build_index(exact, diagnostics)
            if secondary is not None
            else None,
            retrieval.build_index(exact, diagnostics, environment=0)
            if tertiary is not None
            else None,
        )
        for role, exact in (boundary_index or {}).items()
    }
    # Candidate endpoint rules carry large native molecule graphs. Retaining
    # every earlier query's extraction grows the cyclic-GC heap indefinitely.
    # Prepared reference evidence remains intact; evictions recompute on demand.
    rule_cache = getattr(processor.rule_extractor, "cache", None)
    if isinstance(rule_cache, dict):
        processor.rule_extractor.cache = BoundedRuleCache(rule_cache)
    del rule_cache
    queries = dict(
        (str(k), v)
        for k, v in route_items(json.loads(Path(request.routes_json).read_text()))
    )
    counts, recovery = Counter(), Counter()
    recovered_events = set()
    reference_seconds = perf_counter() - started
    route_timings = []
    generalized_endpoints = {}
    with publication(request.output_dir) as root:
        conn = sqlite3.connect(root / "catalog.sqlite")
        conn.executescript("""
            CREATE TABLE queries(route_id TEXT PRIMARY KEY, proposal_count INTEGER, best_recovery TEXT, truncated INTEGER, tree_json TEXT);
            CREATE TABLE proposals(proposal_id TEXT PRIMARY KEY, route_id TEXT, rank INTEGER, payload_json TEXT);
            CREATE INDEX proposal_route ON proposals(route_id,rank);
        """)
        try:
            with (
                (root / "proposals.jsonl").open("w") as proposals_file,
                (root / "matches.jsonl").open("w") as matches_file,
                (root / "candidate_audit.jsonl").open("w") as audit_file,
            ):
                for i, (rid, saved) in enumerate(queries.items()):
                    route_started = perf_counter()
                    held_out = saved.get("metadata", {}).get("pg_stripping", {})
                    excluded_fingerprint = (
                        # Recompute from the held-out tree for exclusion only:
                        # historical fingerprints used a different backend.
                        (
                            fingerprint(held_out["original_tree"])
                            if held_out.get("original_tree")
                            else held_out.get("source_route_fingerprint")
                        )
                        if request.identical_source_policy == "exclude"
                        else None
                    )
                    query = primary(saved)
                    accepted, attempts, truncated, seen = [], 0, False, set()
                    site_cache = {}
                    validation_cache = {}
                    fallback_needed = {}
                    budgets = {
                        "stronger": _SearchBudget(
                            request.max_attempts, request.max_proposals
                        ),
                        "center_only": _SearchBudget(
                            request.max_center_attempts, request.max_center_proposals
                        ),
                        "endpoint": _SearchBudget(
                            request.max_endpoint_attempts,
                            request.max_endpoint_proposals,
                        ),
                        "placement": _SearchBudget(
                            request.max_endpoint_attempts,
                            request.max_endpoint_proposals,
                        ),
                        "query_groups": _SearchBudget(
                            request.max_endpoint_attempts,
                            request.max_endpoint_proposals,
                        ),
                        "boundary": _SearchBudget(
                            request.max_endpoint_attempts,
                            request.max_endpoint_proposals,
                        ),
                    }
                    before_selectivity = set()
                    try:
                        validate(query, query["smiles"])
                        steps = extract_steps(
                            query, processor.rule_extractor, diagnostics, rid
                        )
                        aromatic_steps = extract_steps(
                            query,
                            processor.rule_extractor,
                            diagnostics,
                            rid,
                            preserve_aromatic=True,
                        )
                        additional_steps = (
                            (("recorded_aromatic", aromatic_steps),)
                            if aromatic_steps != steps
                            else ()
                        )
                        groups = _match_groups(
                            query,
                            steps,
                            index,
                            secondary,
                            maximum,
                            excluded_fingerprint,
                            diagnostics,
                            rid,
                            counts,
                            tertiary=tertiary,
                            additional_steps=additional_steps,
                        )
                        counts["matched_routes"] += bool(groups)
                        search_groups = []
                        for tier in ("exact", "reduced_context", "center_only"):
                            ordered = sorted(
                                (g for g in groups.values() if g["tier"] == tier),
                                key=_rank,
                            )
                            counts[tier + "_matched_routes"] += bool(ordered)
                            # Entire exact search, including lifetime extensions,
                            # precedes candidates from the secondary index.
                            search_groups += [(False, g) for g in ordered]
                            if request.lifetime_search == "expand":
                                search_groups += [(True, g) for g in ordered]
                        query_pairs = {
                            pg: eligible_pairs(
                                endpoint_bank,
                                pg,
                                excluded_fingerprint,
                            )
                            for pg in endpoint_bank
                        }
                        search_groups = [
                            (False, expand, g) for expand, g in search_groups
                        ] + (
                            [(True, expand, g) for expand, g in search_groups]
                            if request.endpoint_search == "same_pg_library"
                            else []
                        )
                        if request.placement_fallback != "off":
                            fallback_groups = []
                            for _, expand, group in search_groups:
                                if expand:
                                    continue
                                for pg in sorted(endpoint_bank):
                                    link = relation(group["pg_type"], pg)
                                    if link and (
                                        request.placement_fallback
                                        in {"related_families", "query_groups"}
                                        or link == "same_pg"
                                    ):
                                        fallback_groups.append(
                                            (
                                                "placement",
                                                False,
                                                {
                                                    **group,
                                                    "pg_type": pg,
                                                    "evidence_pg_type": group[
                                                        "pg_type"
                                                    ],
                                                    "evidence_transfer": link,
                                                },
                                            )
                                        )
                            # Each original evidence group occurs in both earlier
                            # endpoint phases. Keep one deterministic fallback.
                            unique = {}
                            for item in fallback_groups:
                                g = item[2]
                                unique.setdefault(
                                    (
                                        g["paths"],
                                        g["mode"],
                                        g["pg_type"],
                                        g["evidence_pg_type"],
                                    ),
                                    item,
                                )
                            priority = {
                                "same_pg": 0,
                                "nitrogen_mask_family": 1,
                                "functional_group_family": 2,
                            }
                            search_groups.extend(
                                sorted(
                                    unique.values(),
                                    key=lambda item: priority[
                                        item[2]["evidence_transfer"]
                                    ],
                                )
                            )

                        def searches():
                            yield from search_groups
                            if (
                                not accepted
                                and request.placement_fallback == "query_groups"
                            ):
                                for group in transfer_groups(
                                    groups.values(),
                                    endpoint_bank,
                                    only_cross_family=True,
                                ):
                                    yield "query_groups", False, group
                            if not accepted and boundary_indices:
                                for role, (
                                    exact,
                                    reduced,
                                    center,
                                ) in boundary_indices.items():
                                    boundary_groups = _match_groups(
                                        query,
                                        steps,
                                        exact,
                                        reduced,
                                        1,
                                        excluded_fingerprint,
                                        diagnostics,
                                        rid,
                                        Counter(),
                                        tertiary=center,
                                        additional_steps=additional_steps,
                                    )
                                    source_groups = [
                                        dict(g, evidence_role=role)
                                        for g in boundary_groups.values()
                                    ]
                                    nominated = transfer_groups(
                                        source_groups,
                                        endpoint_bank,
                                        cross_family=request.placement_fallback
                                        == "query_groups",
                                    )
                                    for group in nominated:
                                        if (
                                            request.placement_fallback
                                            in {"off", "same_pg"}
                                            and group["evidence_transfer"] != "same_pg"
                                        ):
                                            continue
                                        yield "boundary", False, group

                        for supplemental, expand, group in searches():
                            fallback = supplemental in {
                                "placement",
                                "query_groups",
                                "boundary",
                            }
                            if fallback:
                                fallback_needed.setdefault(supplemental, not accepted)
                                if not fallback_needed[supplemental]:
                                    continue
                            budget = budgets[
                                supplemental
                                if fallback
                                else "endpoint"
                                if supplemental
                                else "center_only"
                                if group["tier"] == "center_only"
                                else "stronger"
                            ]
                            support = group["support"]
                            support_rows = sorted({e["route_id"] for e in support})
                            support_events = sorted(
                                {e["event"]["occurrence_id"] for e in support}
                            )
                            match_record = {
                                "route_id": rid,
                                "paths": group["paths"],
                                "rules": group["rules"],
                                "pg_type": group["pg_type"],
                                "match_mode": group["mode"],
                                "query_representation": group.get(
                                    "query_representation", "native_resonance"
                                ),
                                "evidence_tier": group["tier"],
                                "support_route_ids": support_rows,
                                "support_event_ids": support_events,
                                "transferable_support_events": sorted(
                                    {
                                        e["event"]["occurrence_id"]
                                        for e in support
                                        if e["transferable"]
                                    }
                                ),
                                "available_endpoint_pairs": len(
                                    query_pairs.get(group["pg_type"], [])
                                )
                                if request.endpoint_search == "same_pg_library"
                                else 0,
                            }
                            if fallback:
                                match_record.update(
                                    {
                                        "evidence_pg_type": group["evidence_pg_type"],
                                        "evidence_transfer": group["evidence_transfer"],
                                    }
                                )
                            if group.get("evidence_role"):
                                match_record["evidence_role"] = group["evidence_role"]
                            if group["tier"] != "exact":
                                environment = 0 if group["tier"] == "center_only" else 1
                                match_record["projection_keys"] = retrieval.key(
                                    group["rules"], environment
                                )
                                match_record["projection_atom_counts"] = [
                                    len(
                                        retrieval.projection(rule, environment)["atoms"]
                                    )
                                    for rule in group["rules"]
                                ]
                                if group["tier"] == "center_only":
                                    match_record["projection_environment"] = 0
                                    match_record["fallback_reason"] = (
                                        "no_stronger_match_for_query_window_and_pg_type"
                                    )
                            if not expand and not supplemental:
                                counts[group["tier"] + "_matched_windows"] += 1
                                matches_file.write(json.dumps(match_record) + "\n")
                                counts["matched_windows"] += 1
                            elif fallback and (
                                supplemental != "placement"
                                or group["evidence_transfer"] != "same_pg"
                            ):
                                matches_file.write(json.dumps(match_record) + "\n")
                                counts[
                                    "family_matched_windows"
                                    if supplemental == "placement"
                                    else supplemental + "_matched_windows"
                                ] += 1
                                counts["matched_windows"] += 1
                            if budget.exhausted:
                                truncated = True
                                budget.limited = True
                                continue
                            ordered_support = sorted(
                                support,
                                key=lambda e: (
                                    e["route_id"],
                                    e["event"]["occurrence_id"],
                                    e["start"],
                                ),
                            )
                            choices = (
                                [
                                    (ordered_support[0], e)
                                    for e in query_pairs.get(group["pg_type"], [])
                                ]
                                if supplemental
                                else [
                                    (
                                        e,
                                        endpoint_events.get(
                                            e["event"]["occurrence_id"]
                                        ),
                                    )
                                    for e in ordered_support
                                ]
                            )
                            if fallback:
                                broader = []
                                for evidence, endpoint in choices:
                                    eid = endpoint["event"]["occurrence_id"]
                                    if eid not in generalized_endpoints:
                                        try:
                                            generalized_endpoints[eid] = (
                                                generalized_endpoint(
                                                    endpoint,
                                                    references[endpoint["route_id"]],
                                                    reverse_rule=processor.profile[
                                                        "rule_extraction_config"
                                                    ]["reverse_rule"],
                                                    limit=request.max_selectivity_applications,
                                                )
                                            )
                                        except Exception as exc:
                                            generalized_endpoints[eid] = None
                                            diagnostics.append(
                                                {
                                                    "stage": "reference_endpoint_context",
                                                    "route_id": endpoint["route_id"],
                                                    "event_id": eid,
                                                    "message": str(exc),
                                                }
                                            )
                                    if generalized_endpoints[eid] is not None:
                                        # Preserve this query's eligible equivalent sources.
                                        variant = {
                                            **generalized_endpoints[eid],
                                            "equivalent_references": endpoint[
                                                "equivalent_references"
                                            ],
                                        }
                                        broader.append((evidence, variant))
                                choices += broader
                            for evidence, endpoint in choices:
                                if budget.exhausted:
                                    truncated = True
                                    budget.limited = True
                                    break
                                if endpoint is None:
                                    if not expand:
                                        counts["nongeneratable_support_windows"] += 1
                                    continue
                                reference = references[endpoint["route_id"]]
                                event = endpoint["event"]
                                reference_window = {
                                    "route_id": evidence["route_id"],
                                    "paths": evidence["reference_paths"],
                                    "rules": evidence["rules"],
                                    "event_id": evidence["event"]["occurrence_id"],
                                    "representation": evidence.get(
                                        "representation", "stored"
                                    ),
                                }
                                if group.get("evidence_role"):
                                    reference_window["evidence_role"] = group[
                                        "evidence_role"
                                    ]
                                endpoint_reference = reference_record(endpoint)
                                try:
                                    if fallback:
                                        spans, capped = placements(
                                            query,
                                            steps,
                                            group["paths"],
                                            reference,
                                            endpoint,
                                            maximum=request.max_lifetime_extension
                                            if request.lifetime_search == "expand"
                                            else 0,
                                            limit=request.max_site_matches,
                                            reverse_rule=processor.profile[
                                                "rule_extraction_config"
                                            ]["reverse_rule"],
                                            cache=site_cache,
                                            evidence_role=group.get(
                                                "evidence_role", "interval"
                                            ),
                                        )
                                        candidates = [None]
                                    else:
                                        candidates, capped = sites(
                                            query,
                                            group["paths"],
                                            reference,
                                            event,
                                            limit=request.max_site_matches,
                                            generalized=request.site_discovery
                                            == "functional_group_core",
                                            reverse_rule=processor.profile[
                                                "rule_extraction_config"
                                            ]["reverse_rule"],
                                            cache=site_cache,
                                            mask=endpoint["mask_spec"],
                                        )
                                except Exception as exc:
                                    diagnostics.append(
                                        {
                                            "stage": "site_transfer",
                                            "route_id": rid,
                                            "event_id": evidence["event"][
                                                "occurrence_id"
                                            ],
                                            "message": str(exc),
                                        }
                                    )
                                    continue
                                truncated |= capped
                                for seed_site in candidates:
                                    if not fallback:
                                        spans = [(group["paths"], seed_site)]
                                    if expand:
                                        spans, capped = extensions(
                                            query,
                                            group["paths"],
                                            seed_site,
                                            reference,
                                            event,
                                            steps=steps,
                                            maximum=request.max_lifetime_extension,
                                            site_limit=request.max_site_matches,
                                            generalized=request.site_discovery
                                            == "functional_group_core",
                                            reverse_rule=processor.profile[
                                                "rule_extraction_config"
                                            ]["reverse_rule"],
                                            site_cache=site_cache,
                                            mask=endpoint["mask_spec"],
                                        )
                                        truncated |= capped
                                    for interval_paths, site in spans:
                                        # Different donor chemistry remains a separate candidate.
                                        signature = (
                                            interval_paths,
                                            group["pg_type"],
                                            tuple(
                                                sorted(
                                                    site[1][n]
                                                    for n in event["protected_atom_ids"]
                                                )
                                            ),
                                            endpoint["pair_id"],
                                        )
                                        if signature in seen:
                                            continue
                                        seen.add(signature)
                                        if budget.exhausted:
                                            truncated = True
                                            budget.limited = True
                                            break
                                        attempts += 1
                                        budget.attempts += 1
                                        counts[group["tier"] + "_attempts"] += 1
                                        counts[
                                            supplemental + "_attempts"
                                            if fallback
                                            else "endpoint_attempts"
                                            if supplemental
                                            else "matched_event_attempts"
                                        ] += 1
                                        counts[
                                            "extended_attempts"
                                            if expand
                                            or (
                                                fallback
                                                and len(interval_paths)
                                                > len(group["paths"])
                                            )
                                            else "matched_window_attempts"
                                        ] += 1
                                        try:
                                            proposed, checks, strategy = generate(
                                                query,
                                                interval_paths,
                                                site,
                                                reference,
                                                endpoint,
                                                processor,
                                                max_selectivity_applications=request.max_selectivity_applications,
                                                query_steps=steps,
                                                evidence_paths=group["paths"],
                                                evidence_role=group.get(
                                                    "evidence_role", "interval"
                                                ),
                                                validate_full_interval=supplemental
                                                or group["tier"] != "exact",
                                                validation_cache=validation_cache,
                                            )
                                            strategy["evidence_tier"] = group["tier"]
                                            strategy["endpoint_search"] = (
                                                supplemental
                                                if supplemental
                                                in {"query_groups", "boundary"}
                                                else "site_first"
                                                if fallback
                                                else "same_pg_library"
                                                if supplemental
                                                else "matched_event"
                                            )
                                            strategy["evidence_reference_event_id"] = (
                                                evidence["event"]["occurrence_id"]
                                            )
                                            strategy["endpoint_pair_id"] = endpoint[
                                                "pair_id"
                                            ]
                                            if fallback:
                                                strategy["evidence_pg_type"] = group[
                                                    "evidence_pg_type"
                                                ]
                                                strategy["evidence_transfer"] = group[
                                                    "evidence_transfer"
                                                ]
                                                strategy["endpoint_context_policy"] = (
                                                    event.get(
                                                        "endpoint_context_policy",
                                                        "recorded",
                                                    )
                                                )
                                            strategy["site_discovery"] = (
                                                request.site_discovery
                                            )
                                            failed_checks = acceptance_failures(
                                                checks["selectivity"],
                                                request.replay_selectivity,
                                            )
                                            checks["selectivity_warnings"] = (
                                                selectivity_warnings(
                                                    checks["selectivity"],
                                                    request.replay_selectivity,
                                                )
                                            )
                                            eligible = not failed_checks
                                            duplicate = eligible and any(
                                                compare_trees(proposed, p["tree"])
                                                == "equal"
                                                for p in accepted
                                            )
                                            # The acceptance decision precedes held-out evaluation.
                                            # Rejected candidates are audited to measure losses;
                                            # those labels never affect search, ranking or filtering.
                                            evaluation = evaluate(
                                                proposed, strategy, held_out
                                            )
                                            before_selectivity.add(evaluation["status"])
                                            audit_file.write(
                                                json.dumps(
                                                    {
                                                        "route_id": rid,
                                                        "strategy": strategy,
                                                        "reference_route_id": endpoint[
                                                            "route_id"
                                                        ],
                                                        "reference_window": reference_window,
                                                        "endpoint_reference": endpoint_reference,
                                                        "validation": checks,
                                                        "recovery": evaluation,
                                                        "accepted": eligible
                                                        and not duplicate,
                                                        "duplicate": duplicate,
                                                    }
                                                )
                                                + "\n"
                                            )
                                            counts["structurally_valid_candidates"] += 1
                                            truncated |= any(
                                                r.get("truncated", False)
                                                for r in failed_checks.values()
                                            )
                                            if failed_checks:
                                                counts[
                                                    "selectivity_rejected_candidates"
                                                ] += 1
                                                for (
                                                    name,
                                                    result,
                                                ) in failed_checks.items():
                                                    counts[
                                                        f"selectivity_{name}_{result['status']}"
                                                    ] += 1
                                                    diagnostics.append(
                                                        {
                                                            "stage": "selectivity_"
                                                            + name,
                                                            "route_id": rid,
                                                            "event_id": evidence[
                                                                "event"
                                                            ]["occurrence_id"],
                                                            "message": result["reason"],
                                                            "site_atom_maps": strategy[
                                                                "site_atom_maps"
                                                            ],
                                                            "query_interval_paths": strategy[
                                                                "query_interval_paths"
                                                            ],
                                                            "selectivity": result,
                                                        }
                                                    )
                                                continue
                                            if duplicate:
                                                counts[
                                                    "duplicate_valid_candidates"
                                                ] += 1
                                                continue
                                            record = {
                                                "route_id": rid,
                                                "rank": len(accepted) + 1,
                                                "tree": proposed,
                                                "strategy": strategy,
                                                "validation": checks,
                                                "match": match_record,
                                                "reference_window": reference_window,
                                                "endpoint_reference": endpoint_reference,
                                            }
                                            # Recovery labels never affect acceptance or rank.
                                            record["recovery"] = evaluation
                                            recovered_events.update(
                                                (rid, eid)
                                                for eid in record["recovery"].get(
                                                    "recovered_event_ids", []
                                                )
                                            )
                                            record["proposal_id"] = stable_id(
                                                {
                                                    "query": rid,
                                                    "tree": primary(proposed),
                                                    "strategy": strategy,
                                                }
                                            )
                                            accepted.append(record)
                                            budget.proposals += 1
                                            counts[group["tier"] + "_proposals"] += 1
                                            counts[
                                                supplemental + "_proposals"
                                                if fallback
                                                else "endpoint_proposals"
                                                if supplemental
                                                else "matched_event_proposals"
                                            ] += 1
                                            counts[
                                                "extended_proposals"
                                                if expand
                                                or (
                                                    fallback
                                                    and len(interval_paths)
                                                    > len(group["paths"])
                                                )
                                                else "matched_window_proposals"
                                            ] += 1
                                        except Exception as exc:
                                            diagnostics.append(
                                                {
                                                    "stage": "generation",
                                                    "route_id": rid,
                                                    "event_id": evidence["event"][
                                                        "occurrence_id"
                                                    ],
                                                    "message": str(exc),
                                                }
                                            )
                    except Exception as exc:
                        diagnostics.append(
                            {"stage": "query", "route_id": rid, "message": str(exc)}
                        )
                    counts["attempted_candidates"] += attempts
                    counts["proposal_count"] += len(accepted)
                    warning_count = sum(
                        bool(p["validation"].get("selectivity_warnings"))
                        for p in accepted
                    )
                    counts["proposals_with_selectivity_warnings"] += warning_count
                    counts["routes_with_selectivity_warnings"] += bool(warning_count)
                    counts["routes_with_proposals"] += bool(accepted)
                    counts["truncated_routes"] += truncated
                    for name, budget in budgets.items():
                        counts[name + "_budget_limited_routes"] += budget.limited
                    for status in before_selectivity:
                        counts["routes_before_selectivity_" + status] += 1
                    statuses = [r["recovery"]["status"] for r in accepted]
                    recovery.update(statuses)
                    best = next(
                        (
                            s
                            for s in (
                                "original_route_recovered",
                                "partial_strategy_recovery",
                                "different_valid_proposal",
                                "comparison_unresolved",
                            )
                            if s in statuses
                        ),
                        "no_proposal",
                    )
                    counts["routes_" + best] += 1
                    for record in accepted:
                        payload = json.dumps(record)
                        proposals_file.write(payload + "\n")
                        conn.execute(
                            "INSERT INTO proposals VALUES(?,?,?,?)",
                            (record["proposal_id"], rid, record["rank"], payload),
                        )
                    conn.execute(
                        "INSERT INTO queries VALUES(?,?,?,?,?)",
                        (rid, len(accepted), best, truncated, json.dumps(saved)),
                    )
                    conn.commit()
                    route_timings.append(
                        {"route_id": rid, "seconds": perf_counter() - route_started}
                    )
                    if i % 10 == 0:
                        progress(
                            "proposing",
                            f"Proposed {i + 1}/{len(queries)} routes; {counts['proposal_count']} validated candidates",
                        )
        finally:
            conn.close()
        query_event_count = 0
        query_evaluable_events = 0
        for tree in queries.values():
            metadata = tree.get("metadata", {}).get("pg_stripping", {})
            kept = {
                tuple(row["original_path"])
                for row in metadata.get("node_correspondence", [])
            }
            for row in metadata.get("events", []):
                query_event_count += 1
                query_evaluable_events += any(
                    tuple(p) in kept
                    for p in row["event"]["interval_reaction_node_paths"]
                )
        summary = {
            "reference_preparation_seconds": reference_seconds,
            "mean_query_seconds": sum(r["seconds"] for r in route_timings)
            / len(route_timings)
            if route_timings
            else 0,
            "processing_wall_seconds": perf_counter() - started,
            "query_routes": len(queries),
            "query_events": query_event_count,
            "query_ngram_evaluable_events": query_evaluable_events,
            "recovered_unique_events": len(recovered_events),
            "reference_routes": len(events),
            "reference_closed_events": sum(map(len, events.values())),
            "reference_zero_lifespan_events": reference_zero,
            "reference_endpoint_events": len(endpoint_events),
            "query_zero_lifespan_events": sum(
                r["event"]["lifetime_steps"] == 0
                for t in queries.values()
                for r in t.get("metadata", {}).get("pg_stripping", {}).get("events", [])
            ),
            "maximum_ngram_length": maximum,
            "diagnostic_count": len(diagnostics),
            "candidate_recovery": dict(recovery),
            **dict(counts),
        }
        write_json(root / "route_timings.json", route_timings)
        finish(
            root,
            summary,
            {
                **provenance,
                "operation": "propose_pg_strategies",
                "recovery_policy_version": 16,
                "chemistry_backend": "chython-synplan",
                "reference_stripping_policy": STRIPPING_POLICY,
                "comparison_policy": COMPARISON_POLICY,
                "candidate_audit_version": 6,
                "site_matching_policy": "substrate_role",
                "endpoint_search": request.endpoint_search,
                "identical_source_policy": request.identical_source_policy,
                "evaluation_mode": "self_reference_diagnostic"
                if request.identical_source_policy == "allow_diagnostic"
                else "source_excluded",
                "endpoint_policy": {
                    **ENDPOINT_POLICY,
                    "identical_source_exclusion": "disabled_for_diagnostic"
                    if request.identical_source_policy == "allow_diagnostic"
                    else ENDPOINT_POLICY["identical_source_exclusion"],
                },
                "placement_fallback": request.placement_fallback,
                "placement_policy": PLACEMENT_POLICY,
                "boundary_search": request.boundary_search,
                "boundary_policy": BOUNDARY_POLICY,
                "evidence_retrieval": request.evidence_retrieval,
                "retrieval_policy": retrieval.RETRIEVAL_POLICY,
                "lifetime_search": request.lifetime_search,
                "lifetime_policy": LIFETIME_POLICY,
                "site_discovery_policy": request.site_discovery,
                "selectivity_policy": {
                    **SELECTIVITY_POLICY,
                    "acceptance": request.replay_selectivity,
                },
                "query_source": portable(request.routes_json),
                "query_sha256": sha256_file(request.routes_json),
                "reference_source": portable(request.reference_routes_json),
                "limits": {
                    "max_lifetime_extension": request.max_lifetime_extension,
                    "max_proposals": request.max_proposals,
                    "max_attempts": request.max_attempts,
                    "max_center_attempts": request.max_center_attempts,
                    "max_center_proposals": request.max_center_proposals,
                    "max_endpoint_attempts": request.max_endpoint_attempts,
                    "max_endpoint_proposals": request.max_endpoint_proposals,
                    "max_placement_attempts": request.max_endpoint_attempts,
                    "max_placement_proposals": request.max_endpoint_proposals,
                    "max_query_groups_attempts": request.max_endpoint_attempts,
                    "max_query_groups_proposals": request.max_endpoint_proposals,
                    "max_boundary_attempts": request.max_endpoint_attempts,
                    "max_boundary_proposals": request.max_endpoint_proposals,
                    "max_site_matches": request.max_site_matches,
                    "max_selectivity_applications": request.max_selectivity_applications,
                },
                "extraction_representations": ["native_resonance", "recorded_aromatic"],
                "matching": ["stored_exact", "pg_normalized_exact"]
                + (
                    ["stored_reduced_context", "pg_normalized_reduced_context"]
                    if secondary is not None
                    else []
                )
                + (
                    ["stored_center_only", "pg_normalized_center_only"]
                    if tertiary is not None
                    else []
                ),
                "validation_scope": "Structural, mapping, stereochemical and lifecycle checks plus constitutional rule replay and site selectivity; no experimental feasibility prediction",
            },
            diagnostics,
        )
    return summary
