"""Corpus execution and publication for composite collection."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from route_inspector.composite_rules.composite import (
    CompositeRuleExtractor,
    GappedCompositeRuleExtractor,
    _gapped_occurrence_paths,
    collect_composite_rules,
    collect_gapped_composite_rules_from_occurrences,
    collect_validated_composite_rules,
    gapped_composite_occurrence_output_paths,
    write_selected_center_gapped_composite_rules,
)
from route_inspector.composite_rules.validation import (
    ABSTRACTION_BOUNDARY_POLICY,
    ATOM_LINEAGE_POLICY,
    CHEMICAL_EQUIVALENCE_POLICY,
    STEREOCHEMISTRY_POLICY,
)
from route_inspector.composite_rules.writers import (
    composite_rule_ids,
    resolve_composite_output_paths,
    resolve_composite_validation_output_paths,
    write_composite_errors,
    write_composite_rules_tsv,
    write_composite_validation_failures,
    write_composite_validation_records,
    write_pseudo_reactions_smi,
)
from route_inspector.infrastructure.artifacts import write_json, write_standard_sidecars
from route_inspector.infrastructure.runtime import (
    normalize_n_cpu,
    setup_runtime_cache_dirs,
)
from route_inspector.infrastructure.text import write_tsv
from route_inspector.tactics.rrseq import gapped_classification
from route_inspector.tactics.rrseq.artifacts import (
    discover_rrseq_occurrence_paths,
    expand_rrseq_occurrence_paths,
    expand_rrseq_tsv_paths,
)
from route_inspector.workflows.requests import (
    CollectGappedCompositeRulesRequest,
    ExtractCompositeRulesRequest,
)


def run(args: ExtractCompositeRulesRequest | CollectGappedCompositeRulesRequest) -> int:
    """Run this module command with parsed CLI arguments.

    This step supports composite rule extraction from rrseq applications and
    keeps duplicate rules merged by structural identity.
    """
    setup_runtime_cache_dirs()
    if getattr(args, "output", None) is None:
        if getattr(args, "output_dir", None) is None:
            raise ValueError("either --output or --output-dir is required")
        args.output = args.output_dir
    elif getattr(args, "output_dir", None) is not None:
        raise ValueError("--output and --output-dir cannot be used together")
    rrseq_tsvs = expand_rrseq_tsv_paths(args.rrseq_tsv)
    explicit_occurrences = getattr(args, "rrseq_occurrences", None)
    occurrence_paths = (
        expand_rrseq_occurrence_paths(explicit_occurrences)
        if explicit_occurrences
        else discover_rrseq_occurrence_paths(rrseq_tsvs)
    )
    if not occurrence_paths and not getattr(args, "allow_legacy_unvalidated", False):
        raise ValueError(
            "no RRseq_cons occurrence sidecar was found; rerun "
            "extract-rrseq-cons or pass --rrseq-cons-occurrences. Aggregate TSV "
            "fallback is lossy and requires --allow-legacy-unvalidated."
        )
    extractor = CompositeRuleExtractor.from_args(args)
    if occurrence_paths:
        collection = collect_validated_composite_rules(
            rrseq_tsvs,
            occurrence_paths,
            extractor,
            limit_rows=getattr(args, "limit_rows", None),
            limit_applications=getattr(args, "limit_applications", None),
            ignore_errors=getattr(args, "ignore_errors", False),
            progress_interval=getattr(args, "progress_interval", 250),
            n_cpu=getattr(args, "n_cpu", 1),
            extractor_args=args,
            max_replay_outcomes=getattr(
                args,
                "max_replay_outcomes",
                256,
            ),
            allow_ambiguous=getattr(args, "allow_ambiguous", True),
            application_timeout_seconds=getattr(
                args,
                "application_timeout_seconds",
                300.0,
            ),
        )
        aggregates = collection.aggregates
        certified_aggregates = collection.certified_aggregates
        pseudo_reactions = collection.pseudo_reactions
        stats = collection.stats
        errors = collection.errors
        validation_records = collection.validation_records
        input_occurrence_schema_versions = collection.input_occurrence_schema_versions
        processed_occurrence_schema_versions = (
            collection.processed_occurrence_schema_versions
        )
        provenance_mode = "exact_occurrences"
    else:
        aggregates, pseudo_reactions, stats, errors = collect_composite_rules(
            rrseq_tsvs,
            extractor,
            limit_rows=getattr(args, "limit_rows", None),
            limit_applications=getattr(args, "limit_applications", None),
            ignore_errors=getattr(args, "ignore_errors", False),
            progress_interval=getattr(args, "progress_interval", 250),
            n_cpu=getattr(args, "n_cpu", 1),
            extractor_args=args,
        )
        certified_aggregates = {}
        validation_records = []
        input_occurrence_schema_versions = ()
        processed_occurrence_schema_versions = ()
        stats.legacy_unvalidated = stats.applications_seen
        provenance_mode = "legacy_flattened"

    occurrence_schema_version = (
        processed_occurrence_schema_versions[0]
        if len(processed_occurrence_schema_versions) == 1
        else None
    )
    rules_path, smi_path, summary_path, error_path = resolve_composite_output_paths(
        args.output,
        rrseq_tsvs,
        output_smi=getattr(args, "output_smi", None),
        summary=getattr(args, "summary", None),
        errors=getattr(args, "errors", None),
    )
    (
        validation_path,
        validation_failures_path,
        certified_path,
    ) = resolve_composite_validation_output_paths(
        rules_path,
        validation=getattr(args, "validation_output", None),
        validation_errors=getattr(args, "validation_errors", None),
        certified=getattr(args, "certified_output", None),
    )

    public_composite_ids = composite_rule_ids(aggregates)
    output_stats = write_composite_rules_tsv(
        rules_path,
        aggregates,
        composite_ids=public_composite_ids,
    )
    write_pseudo_reactions_smi(
        smi_path,
        pseudo_reactions,
        aggregates,
        composite_ids=public_composite_ids,
    )
    certified_output_stats = write_composite_rules_tsv(
        certified_path,
        certified_aggregates,
        composite_ids=public_composite_ids,
    )
    write_composite_validation_records(
        validation_path,
        validation_records,
        composite_ids=public_composite_ids,
    )
    write_composite_validation_failures(
        validation_failures_path,
        validation_records,
    )
    write_composite_errors(error_path, errors)

    first_outcome_matches = sum(
        bool((record.get("representative_validation") or {}).get("first_outcome_match"))
        for record in validation_records
    )
    any_outcome_matches = sum(
        bool((record.get("representative_validation") or {}).get("any_outcome_match"))
        for record in validation_records
    )
    published_occurrences = sum(
        len(aggregate.occurrence_ids) for aggregate in certified_aggregates.values()
    )
    summary = {
        "rrseq_cons_tsv": [str(path) for path in rrseq_tsvs],
        "rrseq_cons_occurrences": [str(path) for path in occurrence_paths],
        "input_provenance_mode": provenance_mode,
        "output": str(rules_path),
        "certified_output": str(certified_path),
        "validation_output": str(validation_path),
        "validation_failures_file": (
            str(validation_failures_path) if validation_failures_path.exists() else None
        ),
        "pseudo_reactions_smi": str(smi_path),
        "errors_file": str(error_path) if errors else None,
        "rrseq_cons_rows_seen": stats.rrseq_rows_seen,
        "applications_seen": stats.applications_seen,
        "exact_occurrences_seen": stats.exact_occurrences_seen,
        "pseudo_reactions_built": stats.pseudo_reactions_built,
        "composite_rules_extracted": stats.composite_rules_extracted,
        "skipped_unwrap_applications": stats.skipped_unwrap_applications,
        "skipped_rule_extractions": stats.skipped_rule_extractions,
        "skipped_rule_extraction_errors": stats.skipped_rule_extraction_errors,
        "rrseq_cons_source_matches": stats.rrseq_source_matches,
        "rrseq_cons_source_mismatches": stats.rrseq_source_mismatches,
        "rrseq_cons_source_mapping_mismatches": (stats.rrseq_source_mapping_mismatches),
        "application_timeouts": stats.application_timeouts,
        "validated_unique": stats.validated_unique,
        "validated_ambiguous": stats.validated_ambiguous,
        "validation_rejected": stats.validation_rejected,
        "validation_inconclusive": stats.validation_inconclusive,
        "legacy_unvalidated": stats.legacy_unvalidated,
        "first_outcome_matches": first_outcome_matches,
        "any_outcome_matches": any_outcome_matches,
        "published_occurrences": published_occurrences,
        "errors": stats.errors,
        "unique_composite_rules": len(aggregates),
        "certified_composite_rules": len(certified_aggregates),
        "rrseq_cons_occurrence_schema_version": occurrence_schema_version,
        "rrseq_cons_processed_occurrence_schema_versions": list(
            processed_occurrence_schema_versions
        ),
        "rrseq_cons_input_occurrence_schema_versions": list(
            input_occurrence_schema_versions
        ),
        "validation_schema_version": 1,
        "leaf_identity_version": 1,
        "chemical_equivalence_policy": CHEMICAL_EQUIVALENCE_POLICY,
        "stereochemistry_policy": STEREOCHEMISTRY_POLICY,
        "atom_lineage_policy": ATOM_LINEAGE_POLICY,
        "composite_boundary_policy": ABSTRACTION_BOUNDARY_POLICY,
        "source_boundary_policy": "full_recorded_boundary",
        "max_replay_outcomes": getattr(args, "max_replay_outcomes", 256),
        "allow_ambiguous": getattr(args, "allow_ambiguous", True),
        "validation_policy": (
            (
                "strict_lineage_any_matching_outcome"
                + (
                    "_ambiguous_allowed"
                    if getattr(args, "allow_ambiguous", True)
                    else "_unique_only"
                )
            )
            if occurrence_paths
            else "unvalidated_legacy"
        ),
        "application_timeout_seconds": getattr(
            args,
            "application_timeout_seconds",
            300.0,
        ),
        "validation_accounting_complete": (
            stats.applications_seen
            == stats.validated_unique
            + stats.validated_ambiguous
            + stats.validation_rejected
            + stats.validation_inconclusive
            + stats.legacy_unvalidated
        ),
        "n_cpu": normalize_n_cpu(getattr(args, "n_cpu", 1)),
        "workers_used": min(
            normalize_n_cpu(getattr(args, "n_cpu", 1)),
            stats.applications_seen,
        )
        if stats.applications_seen
        else 0,
        "certified_output_rows": certified_output_stats["composite_rules"],
        **output_stats,
    }
    write_json(summary_path, summary)
    summary["summary_file"] = str(summary_path)
    write_json(summary_path, summary)
    manifest_outputs: dict[str, Path] = {
        "composite_rules": rules_path,
        "validated_composite_rules": certified_path,
        "composite_validation": validation_path,
        "pseudo_reactions_smi": smi_path,
        "summary": summary_path,
    }
    if validation_failures_path.exists():
        manifest_outputs["composite_validation_failures"] = validation_failures_path
    if error_path.exists():
        manifest_outputs["errors"] = error_path
    sidecars = write_standard_sidecars(
        rules_path.parent,
        command_name="extract-composite-rules",
        summary=summary,
        errors=errors,
        input_files=[*rrseq_tsvs, *occurrence_paths],
        output_files=manifest_outputs,
        config_path=getattr(args, "config", None),
        cli_args=args,
        extra_manifest={
            "input_provenance_mode": provenance_mode,
            "rrseq_cons_occurrence_schema_version": occurrence_schema_version,
            "rrseq_cons_processed_occurrence_schema_versions": list(
                processed_occurrence_schema_versions
            ),
            "rrseq_cons_input_occurrence_schema_versions": list(
                input_occurrence_schema_versions
            ),
            "validation_schema_version": 1,
            "validation_policy": summary["validation_policy"],
            "chemical_equivalence_policy": CHEMICAL_EQUIVALENCE_POLICY,
            "stereochemistry_policy": STEREOCHEMISTRY_POLICY,
            "atom_lineage_policy": ATOM_LINEAGE_POLICY,
            "max_replay_outcomes": getattr(
                args,
                "max_replay_outcomes",
                256,
            ),
        },
    )
    summary["sidecar_files"] = sidecars
    write_json(summary_path, summary)
    print(json.dumps(summary, indent=2), flush=True)
    return 0


def run_gapped(
    args: ExtractCompositeRulesRequest | CollectGappedCompositeRulesRequest,
) -> int:
    """Collect non-executable composite rules derived from RRseq_gap records."""
    setup_runtime_cache_dirs()
    if getattr(args, "output", None) is None:
        if getattr(args, "output_dir", None) is None:
            raise ValueError("either --output or --output-dir is required")
        args.output = args.output_dir
    elif getattr(args, "output_dir", None) is not None:
        raise ValueError("--output and --output-dir cannot be used together")
    occurrence_args = getattr(
        args,
        "rrseq_gap_occurrences",
        getattr(args, "separated_occurrences", None),
    )
    if not occurrence_args:
        raise ValueError("--rrseq-gap-occurrences is required")
    sidecars = _gapped_occurrence_paths(occurrence_args)
    n_cpu = normalize_n_cpu(args.n_cpu)
    extractor = GappedCompositeRuleExtractor.from_args(args)
    classification_records: list[dict[str, Any]] = []
    detect_complementary = bool(getattr(args, "detect_complementary", False))
    protection_index = (
        gapped_classification.load_protection_events(
            getattr(args, "protection_events", None)
        )
        if detect_complementary
        else None
    )
    aggregates, errors, occurrences_seen, no_net_selected_change = (
        collect_gapped_composite_rules_from_occurrences(
            sidecars,
            limit_occurrences=getattr(args, "limit_occurrences", None),
            extractor=extractor,
            n_cpu=n_cpu,
            extractor_args=args,
            context_radius=int(getattr(args, "context_radius", 2)),
            max_replay_outcomes=int(getattr(args, "max_replay_outcomes", 256)),
            require_unique_replay=bool(getattr(args, "require_unique_replay", False)),
            detect_complementary=detect_complementary,
            protection_index=protection_index,
            classification_sink=classification_records,
        )
    )
    rules_path, summary_path, error_path = gapped_composite_occurrence_output_paths(
        args.output, sidecars, getattr(args, "summary", None)
    )
    output_stats = write_selected_center_gapped_composite_rules(rules_path, aggregates)
    prefix = rules_path.stem.removesuffix("_gapped_composite_rules")
    classification_tsv_path = rules_path.with_name(
        f"{prefix}_gapped_rrseq_classification.tsv"
    )
    classification_json_path = rules_path.with_name(
        f"{prefix}_gapped_rrseq_classification.json"
    )
    write_tsv(
        classification_tsv_path,
        gapped_classification.CLASSIFICATION_FIELDS,
        (
            gapped_classification.classification_tsv_row(record)
            for record in classification_records
        ),
    )
    gapped_classification.write_gapped_classification_json(
        classification_json_path,
        classification_records,
    )
    class_paths: dict[str, Path] = {}
    for classification in gapped_classification.GappedRRSeqClass:
        path = rules_path.with_name(
            f"{prefix}_{classification.value}_gapped_rrseqs.tsv"
        )
        write_tsv(
            path,
            gapped_classification.CLASSIFICATION_FIELDS,
            (
                gapped_classification.classification_tsv_row(record)
                for record in classification_records
                if record.get("classification") == classification.value
            ),
        )
        class_paths[classification.value] = path
    motif_path = rules_path.with_name(f"{prefix}_complementary_gapped_rrseq_motifs.tsv")
    write_tsv(
        motif_path,
        gapped_classification.COMPLEMENTARY_MOTIF_FIELDS,
        gapped_classification.complementary_motif_rows(classification_records),
    )
    if errors:
        write_tsv(
            error_path,
            [
                "occurrence_id",
                "route_id",
                "RRseq_gap",
                "stage",
                "error_type",
                "message",
            ],
            errors,
        )
    elif error_path.exists():
        error_path.unlink()
    classification_stats = gapped_classification.classification_summary(
        classification_records,
        context_radius=int(getattr(args, "context_radius", 2)),
        max_replay_outcomes=int(getattr(args, "max_replay_outcomes", 256)),
        detect_complementary=detect_complementary,
    )
    constructed_occurrence_ids = {
        occurrence_id
        for aggregate in aggregates.values()
        for occurrence_id in aggregate.occurrence_ids
        if occurrence_id
    }
    factorable_count = sum(
        record.get("classification") == "factorable"
        for record in classification_records
    )
    summary = {
        "analysis_only": True,
        "non_executable_reason": (
            "gapped rules omit skipped chemistry and are not executable "
            "RRseq_cons chains"
        ),
        "rrseq_gap_occurrences": [str(path) for path in sidecars],
        "output": str(rules_path),
        "errors_file": str(error_path) if errors else None,
        "occurrences_seen": occurrences_seen,
        "factorable_occurrences_eligible": factorable_count,
        "occurrences_collected": len(constructed_occurrence_ids),
        "no_net_selected_change": no_net_selected_change,
        "unexpected_diagnostics": len(errors),
        "construction_errors": len(errors),
        "environment_atom_count": 2,
        "multicenter_rules": True,
        "n_cpu_requested": n_cpu,
        "workers_used": min(n_cpu, factorable_count) if factorable_count else 0,
        **classification_stats,
        **output_stats,
    }
    write_json(summary_path, summary)
    summary["summary_file"] = str(summary_path)
    sidecar_files = write_standard_sidecars(
        rules_path.parent,
        command_name="collect-gapped-composite-rules",
        summary=summary,
        errors=errors,
        input_files=sidecars,
        output_files={
            "gapped_composite_rules": rules_path,
            "gapped_classification_tsv": classification_tsv_path,
            "gapped_classification_json": classification_json_path,
            "complementary_motifs": motif_path,
            **{
                f"{classification}_gapped_rrseqs": path
                for classification, path in class_paths.items()
            },
            "summary": summary_path,
            **({"unexpected_diagnostics": error_path} if errors else {}),
        },
        config_path=getattr(args, "config", None),
        cli_args=args,
        extra_manifest={
            "gapped_classification_schema_version": 2,
            "factorability_scope": "normalized_mapped_route_structural",
        },
    )
    summary["sidecar_files"] = sidecar_files
    write_json(summary_path, summary)
    print(json.dumps(summary, indent=2), flush=True)
    return 0
