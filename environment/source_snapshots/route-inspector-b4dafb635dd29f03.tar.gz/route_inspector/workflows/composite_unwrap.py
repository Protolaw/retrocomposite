"""Corpus execution and publication for composite unwrap."""

from __future__ import annotations

import json

from route_inspector.composite_rules.artifacts import read_composite_rule_from_tsv
from route_inspector.composite_rules.unwrap_composite import (
    unwrap_composite_rule,
)
from route_inspector.infrastructure.artifacts import write_json
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
from route_inspector.workflows.requests import UnwrapCompositeRuleRequest


def run(args: UnwrapCompositeRuleRequest) -> int:
    """Run this module command with parsed CLI arguments.

    The composite rule is treated as a one-step retrosynthetic template so the
    generated route matches the reactants produced during extraction.
    """
    setup_runtime_cache_dirs()

    composite_rule = args.composite_rule
    if composite_rule is None:
        composite_rule = read_composite_rule_from_tsv(
            resolve_existing_path(args.composite_rule_tsv),
            args.row,
        )

    routes_json = unwrap_composite_rule(
        args.smiles,
        composite_rule,
        route_id=args.route_id,
        mark_leaves_in_stock=not args.do_not_mark_leaves_in_stock,
    )

    if args.output_json:
        write_json(args.output_json, routes_json)
    else:
        print(json.dumps(routes_json, indent=2))

    if args.output_svg:
        from route_inspector.visualization import get_route_svg_from_json

        svg = get_route_svg_from_json(routes_json, args.route_id, labeled=args.labeled)
        args.output_svg.parent.mkdir(parents=True, exist_ok=True)
        args.output_svg.write_text(svg, encoding="utf-8")

    return 0
