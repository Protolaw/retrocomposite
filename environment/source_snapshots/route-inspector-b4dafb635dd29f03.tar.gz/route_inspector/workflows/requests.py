"""Typed workflow inputs. CLI defaults are checked against these contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from route_inspector.rules.config import RuleExtractionSettings


@dataclass(kw_only=True)
class UpdateLibraryRoutesRequest:
    routes_json: Path
    changes_json: Path
    output_dir: Path
    reference_library: Path | None = None
    pg_library: Path | None = None
    composite_library: Path | None = None
    config: Path = Path("route_inspector/configs/rule_extraction_small.yaml")
    work_dir: Path | None = None
    resume: bool = False
    memory_budget_mb: int = 512
    n_cpu: int = 1
    progress_interval: int = 25
    ignore_errors: bool = False
    reaction_classifier_path: Path | None = None
    namerxn_executable: Path | None = None
    gui_dataset: str | None = None
    workspace: Path = Path(".")
    command: str | None = None


@dataclass(kw_only=True)
class AppendLibraryRoutesRequest(UpdateLibraryRoutesRequest):
    """Inputs for append-library-routes."""


@dataclass(kw_only=True)
class ReplaceLibraryRoutesRequest(UpdateLibraryRoutesRequest):
    """Inputs for replace-library-routes."""


@dataclass(kw_only=True)
class StripPgRoutesRequest:
    routes_json: Path
    library: Path
    output: Path
    output_dir: Path
    eligibility: str = "ngram"
    command: str | None = None


@dataclass(kw_only=True)
class ProposePgStrategiesRequest:
    routes_json: Path
    reference_routes_json: Path
    library: Path
    output_dir: Path
    max_proposals: int = 20
    max_attempts: int = 256
    max_site_matches: int = 256
    max_selectivity_applications: int = 256
    site_discovery: str = "functional_group_core"
    lifetime_search: str = "expand"
    max_lifetime_extension: int = 8
    evidence_retrieval: str = "exact_then_reduced_context_then_center_only"
    max_center_attempts: int = 256
    max_center_proposals: int = 20
    endpoint_search: str = "same_pg_library"
    max_endpoint_attempts: int = 256
    max_endpoint_proposals: int = 20
    placement_fallback: str = "query_groups"
    boundary_search: str = "reference_neighbors"
    identical_source_policy: str = "exclude"
    replay_selectivity: str = "warn_competing"
    command: str | None = None


@dataclass(kw_only=True)
class ExtractRrseqConsRequest(RuleExtractionSettings):
    """Inputs for extract-rrseq-cons."""

    routes_json: Path
    output: Path | None = None
    output_dir: Path | None = None
    source_id_adapter: str = "paroutes-semicolon-v1"
    dataset_id: str | None = None
    source_identity: str | None = None
    limit: int | None = None
    min_length: int = 2
    max_length: int = 20
    context_history: Path | None = None
    routes_without_rrseqs_output: Path | None = None
    skip_routes_without_rrseqs_output: bool = False
    unique_reactions_first: bool = False
    ignore_errors: bool = False
    progress_interval: int = 250
    n_cpu: int = 1
    worker_chunksize: int = 16
    max_pending_chunks: int | None = None
    command: str | None = None


@dataclass(kw_only=True)
class ExtractRrseqGapRequest(RuleExtractionSettings):
    """Inputs for extract-rrseq-gap."""

    routes_json: Path
    output: Path | None = None
    output_dir: Path | None = None
    source_id_adapter: str = "paroutes-semicolon-v1"
    dataset_id: str | None = None
    source_identity: str | None = None
    limit: int | None = None
    min_length: int = 2
    max_length: int = 20
    context_history: Path | None = None
    routes_without_rrseqs_output: Path | None = None
    skip_routes_without_rrseqs_output: bool = False
    unique_reactions_first: bool = False
    ignore_errors: bool = False
    progress_interval: int = 250
    n_cpu: int = 1
    worker_chunksize: int = 16
    max_pending_chunks: int | None = None
    command: str | None = None


@dataclass(kw_only=True)
class ExtractRouteMotifsRequest(RuleExtractionSettings):
    """Inputs for extract-route-motifs."""

    routes_json: Path
    output_dir: Path | None = None
    source_id_adapter: str = "paroutes-semicolon-v1"
    dataset_id: str | None = None
    source_identity: str | None = None
    context_history: Path | None = None
    limit: int | None = None
    rrseq_min_length: int = 2
    rrseq_max_length: int = 20
    rrsubtree_min_size: int = 3
    rrsubtree_max_size: int = 12
    rrsubtree_max_candidates_per_route: int = 100000
    skip_routes_without_rrseqs_output: bool = False
    ignore_errors: bool = False
    progress_interval: int = 250
    command: str | None = None


@dataclass(kw_only=True)
class ExtractCompositeRulesRequest(RuleExtractionSettings):
    """Inputs for extract-composite-rules."""

    rrseq_tsv: list[Path]
    rrseq_occurrences: list[Path] | None = None
    output: Path | None = None
    output_dir: Path | None = None
    output_smi: Path | None = None
    summary: Path | None = None
    errors: Path | None = None
    validation_output: Path | None = None
    validation_errors: Path | None = None
    certified_output: Path | None = None
    limit_rows: int | None = None
    limit_applications: int | None = None
    max_replay_outcomes: int = 256
    application_timeout_seconds: float = 300.0
    allow_ambiguous: bool = True
    allow_legacy_unvalidated: bool = False
    ignore_errors: bool = False
    progress_interval: int = 250
    n_cpu: int = 1
    command: str | None = None


@dataclass(kw_only=True)
class CollectGappedCompositeRulesRequest:
    """Inputs for collect-gapped-composite-rules."""

    rrseq_gap_occurrences: list[Path]
    output: Path | None = None
    output_dir: Path | None = None
    summary: Path | None = None
    limit_occurrences: int | None = None
    context_radius: int = 2
    max_replay_outcomes: int = 256
    require_unique_replay: bool = False
    protection_events: Path | None = None
    detect_complementary: bool = False
    config: Path | None = None
    n_cpu: int = 1
    command: str | None = None


@dataclass(kw_only=True)
class ClassifyGappedRrseqsRequest:
    """Inputs for classify-gapped-rrseqs."""

    rrseq_gap_occurrences: list[Path]
    output_dir: Path
    output_prefix: str | None = None
    context_radius: int = 2
    max_replay_outcomes: int = 256
    require_unique_replay: bool = False
    protection_events: Path | None = None
    detect_complementary: bool = False
    command: str | None = None


@dataclass(kw_only=True)
class ExtractRetroBleuGramsRequest(RuleExtractionSettings):
    """Inputs for extract-retro-bleu-grams."""

    routes_json: Path
    output_dir: Path | None = None
    limit: int | None = None
    min_length: int = 2
    max_length: int = 5
    progress_interval: int = 250
    n_cpu: int = 1
    worker_chunksize: int = 16
    command: str | None = None


@dataclass(kw_only=True)
class ClassifyCompositeRulesRequest:
    """Inputs for classify-composite-rules."""

    composite_rules_tsv: Path
    default_rules_tsv: Path
    output: Path | None = None
    output_dir: Path | None = None
    summary: Path | None = None
    n_cpu: int = 1
    command: str | None = None


@dataclass(kw_only=True)
class ClassifyRrseqConsReactionsRequest:
    """Inputs for classify-rrseq-cons-reactions."""

    rrseq_cons_tsv: list[Path]
    rrseq_cons_occurrences: list[Path] | None = None
    output_dir: Path | None = None
    mode: str = "dynamic"
    backend: str = "reactionclassifier"
    reaction_classifier_path: Path | None = None
    namerxn_executable: Path | None = None
    tier: int = 3
    label_policy: str = "confirmed-or-neural"
    n_cpu: int = 1
    worker_chunksize: int = 100
    torch_threads: int = 1
    device: str = "cpu"
    limit_rows: int | None = None
    ignore_errors: bool = False
    progress_interval: int = 250
    command: str | None = None


@dataclass(kw_only=True)
class ClassifyProtectionIntervalReactionsRequest:
    """Inputs for classify-protection-interval-reactions."""

    routes_json: Path
    protection_events: Path
    output_dir: Path | None = None
    rule_config: Path = Path(
        "route_inspector/configs/rule_extraction_functional_groups.yaml"
    )
    backend: str = "reactionclassifier"
    reaction_classifier_path: Path | None = None
    namerxn_executable: Path | None = None
    tier: int = 3
    label_policy: str = "confirmed-or-neural"
    n_cpu: int = 1
    worker_chunksize: int = 100
    torch_threads: int = 1
    device: str = "cpu"
    limit_events: int | None = None
    ignore_errors: bool = False
    progress_interval: int = 100
    command: str | None = None


@dataclass(kw_only=True)
class UnwrapRrseqConsRequest:
    """Inputs for unwrap-rrseq-cons."""

    smiles: str
    rrseq: str | None = None
    rrseq_tsv: Path | None = None
    row: int = 0
    route_id: int = 0
    output_json: Path | None = None
    output_svg: Path | None = None
    labeled: bool = False
    do_not_mark_leaves_in_stock: bool = False
    command: str | None = None


@dataclass(kw_only=True)
class UnwrapCompositeRuleRequest:
    """Inputs for unwrap-composite-rule."""

    smiles: str
    composite_rule: str | None = None
    composite_rule_tsv: Path | None = None
    row: int = 0
    route_id: int = 0
    output_json: Path | None = None
    output_svg: Path | None = None
    labeled: bool = False
    do_not_mark_leaves_in_stock: bool = False
    command: str | None = None


@dataclass(kw_only=True)
class ScoreRrseqConsOverlapRequest(RuleExtractionSettings):
    """Inputs for score-rrseq-cons-overlap."""

    extracted_tsv: list[Path]
    reference_routes_json: Path
    classification_tsv: list[Path] | None = None
    output: Path | None = None
    output_dir: Path | None = None
    limit: int | None = None
    min_length: int = 2
    max_length: int = 20
    ignore_errors: bool = False
    progress_interval: int = 250
    n_cpu: int = 1
    command: str | None = None


@dataclass(kw_only=True)
class AnalyzeProtectionRequest:
    """Inputs for analyze-protection."""

    routes_json: Path
    output_dir: Path
    rrseq_tsv: list[Path] | None = None
    composite_rules_tsv: list[Path] | None = None
    config: Path | None = None
    route_ids_file: Path | None = None
    limit: int | None = None
    min_rrseq_cons_size: int | None = None
    max_rrseq_cons_size: int | None = None
    similarity_threshold: float | None = None
    include_multicenter: bool = False
    deprotection_first: bool = False
    querycgr_compare: bool = False
    write_debug_json: bool = False
    write_debug_svg: bool = False
    ignore_errors: bool = False
    progress_interval: int = 100
    n_cpu: int = 1
    command: str | None = None


@dataclass(kw_only=True)
class PreprocessRoutesRequest(RuleExtractionSettings):
    """Inputs for preprocess-routes."""

    input_dir: Path = Path("data/raw")
    output_dir: Path = Path("data/clean")
    summary_dir: Path | None = None
    datasets: list[str] = field(
        default_factory=lambda: ["n1_routes.json", "n5_routes.json"]
    )
    protection_config: Path | None = None
    limit: int | None = None
    ignore_errors: bool = False
    compact_reports: bool = False
    cache_reset_interval: int = 0
    progress_interval: int = 100
    n_cpu: int = 1
    command: str | None = None


@dataclass(kw_only=True)
class AuditRouteProvenanceRequest:
    """Inputs for audit-route-provenance."""

    routes_json: Path
    output_dir: Path
    command: str | None = None


@dataclass(kw_only=True)
class AnnotateContextHistoryRequest:
    """Inputs for annotate-context-history."""

    routes_json: Path
    output_dir: Path
    dataset_id: str | None = None
    source_identity: str | None = None
    protection_events: Path | None = None
    protection_overlay_policy: str = "strict"
    write_enriched_routes: bool = False
    limit: int | None = None
    command: str | None = None


@dataclass(kw_only=True)
class MigrateOccurrenceContextRequest:
    """Inputs for migrate-occurrence-context."""

    routes_json: Path
    historical_occurrences: list[Path]
    context_history: Path
    output_dir: Path
    dataset_id: str
    source_identity: str | None = None
    source_id_adapter: str = "paroutes-semicolon-v1"
    config: Path
    command: str | None = None


@dataclass(kw_only=True)
class BuildReferenceIndexRequest:
    """Inputs for build-reference-index."""

    config: Path
    occurrences: list[Path]
    context_history: list[Path]
    composite_certificates: list[Path] = field(default_factory=lambda: [])
    output: Path
    dataset_id: str | None = None
    export_dir: Path | None = None
    batch_size: int = 1000
    command: str | None = None


@dataclass(kw_only=True)
class InspectGeneratedRoutesRequest:
    """Inputs for inspect-generated-routes."""

    routes_json: Path
    reference_index: Path
    output_dir: Path
    dataset_id: str | None = None
    source_identity: str | None = None
    source_id_adapter: str = "paroutes-semicolon-v1"
    context_history: Path | None = None
    write_enriched_routes: bool = False
    config: Path
    min_length: int = 2
    max_length: int = 20
    limit: int | None = None
    progress_interval: int = 250
    command: str | None = None


@dataclass(kw_only=True)
class BuildReferenceLibraryRequest:
    """Inputs for build-reference-library."""

    routes_json: Path
    output_dir: Path
    reference_id: str
    source_identity: str | None = None
    config: Path
    input_state: str = "preprocessed"
    protection_config: Path | None = None
    source_id_adapter: str = "paroutes-semicolon-v1"
    rrseq_min_length: int = 2
    rrseq_max_length: int = 20
    rrsubtree_min_size: int = 3
    rrsubtree_max_size: int = 12
    rrsubtree_max_candidates_per_route: int = 100000
    classify_gap_factorability: bool = False
    factorability_context_radius: int = 2
    factorability_max_replay_outcomes: int = 256
    factorability_require_unique_replay: bool = False
    n_cpu: int = 1
    sqlite_catalog: bool = True
    retro_bleu_bigrams: bool = True
    audit_key_isomorphism: bool = False
    limit: int | None = None
    progress_interval: int = 250
    command: str | None = None

    work_dir: Path | None = None
    resume: bool = False
    memory_budget_mb: int = 512


@dataclass(kw_only=True)
class BuildPgStrategyLibraryRequest:
    routes_json: Path
    output_dir: Path
    reference_id: str
    config: Path
    source_identity: str | None = None
    source_id_adapter: str = "paroutes-semicolon-v1"
    n_cpu: int = 1
    sqlite_catalog: bool = True
    limit: int | None = None
    progress_interval: int = 250
    pg_strategy_config: Path = Path("route_inspector/configs/protection_analysis.yaml")
    pg_reaction_class_backend: str = "reactionclassifier"
    reaction_classifier_path: Path | None = None
    namerxn_executable: Path | None = None
    pg_label_policy: str = "confirmed-or-neural"
    pg_worker_chunksize: int = 100
    pg_torch_threads: int = 1
    pg_device: str = "cpu"
    command: str | None = None

    work_dir: Path | None = None
    resume: bool = False
    memory_budget_mb: int = 512


@dataclass(kw_only=True)
class RepackPgStrategyLibraryRequest:
    library: Path
    output_dir: Path
    work_dir: Path | None = None
    resume: bool = False
    memory_budget_mb: int = 512
    command: str | None = None


@dataclass(kw_only=True)
class AssessPgStrategiesRequest:
    routes_json: Path
    library: Path
    output_dir: Path
    route_id: str | None = None
    dataset_id: str | None = None
    source_identity: str | None = None
    verification: str = "fast"
    n_cpu: int = 1
    progress_interval: int = 250
    command: str | None = None


@dataclass(kw_only=True)
class VerifyPgStrategyLibraryRequest:
    library: Path
    backend: str = "auto"
    command: str | None = None


@dataclass(kw_only=True)
class BuildCompositeLibraryRequest(RuleExtractionSettings):
    """Inputs for build-composite-library."""

    reference_library: Path
    routes_json: Path
    output_dir: Path
    kinds: list[str] = field(default_factory=lambda: ["rrsubtree_cons"])
    config: Path = Path("route_inspector/configs/rule_extraction_small.yaml")
    max_replay_outcomes: int = 256
    max_variants: int = 256
    application_timeout_seconds: float = 300.0
    allow_ambiguous: bool = True
    sqlite_catalog: bool = True
    extractor_cache_size: int = 16
    limit_occurrences: int | None = None
    progress_interval: int = 25
    n_cpu: int = 1
    ignore_errors: bool = False
    single_step_overlap: bool = True
    overlap_cache_dir: Path = Path("outputs/gui/single_step_overlap")
    command: str | None = None

    work_dir: Path | None = None
    resume: bool = False
    memory_budget_mb: int = 512


@dataclass(kw_only=True)
class ReclassifyPgStrategyLibraryRequest:
    """Inputs for reclassify-pg-strategy-library."""

    source_library: Path
    output_dir: Path
    namerxn_executable: Path | None = None
    worker_chunksize: int = 500
    command: str | None = None


@dataclass(kw_only=True)
class VerifyReferenceLibraryRequest:
    """Inputs for verify-reference-library."""

    library: Path
    backend: str = "auto"
    command: str | None = None


@dataclass(kw_only=True)
class BuildRouteAssessmentReferenceRequest:
    """Inputs for build-route-assessment-reference."""

    reference_library: Path
    composite_library: Path
    output_dir: Path
    verification: str = "fast"
    command: str | None = None


@dataclass(kw_only=True)
class AssessRoutesRequest:
    """Inputs for assess-routes."""

    reference_assessment: Path
    query_reference_library: Path
    query_composite_library: Path
    query_routes_json: Path
    output_dir: Path
    verification: str = "fast"
    command: str | None = None


@dataclass(kw_only=True)
class AssessRouteRequest:
    """Inputs for assess-route."""

    routes_json: Path
    library: Path
    output_dir: Path
    verification: str = "fast"
    route_id: str | None = None
    dataset_id: str | None = None
    source_identity: str | None = None
    config: Path
    input_state: str | None = None
    protection_config: Path | None = None
    source_id_adapter: str | None = None
    rrseq_min_length: int | None = None
    rrseq_max_length: int | None = None
    rrsubtree_min_size: int | None = None
    rrsubtree_max_size: int | None = None
    rrsubtree_max_candidates_per_route: int | None = None
    classify_gap_factorability: bool | None = None
    factorability_context_radius: int | None = None
    factorability_max_replay_outcomes: int | None = None
    factorability_require_unique_replay: bool | None = None
    pg_strategies: bool | None = None
    limit: int | None = None
    command: str | None = None


@dataclass(kw_only=True)
class CounterfactualReassemblyRrseqFreeRequest:
    """Inputs for counterfactual-reassembly-rrseq-free."""

    routes_json: Path
    reference_library: Path
    config: Path
    output_dir: Path
    max_replay_outcomes: int = 256
    max_counterfactuals_per_pair: int = 256
    pair_timeout_seconds: float = 300.0
    progress_interval: int = 25
    ignore_errors: bool = False
    reaction_class_backend: str = "none"
    reaction_classifier_path: Path | None = None
    namerxn_path: Path | None = None
    reaction_class_label_policy: str = "confirmed-or-neural"
    reaction_class_worker_chunksize: int = 100
    reaction_class_torch_threads: int = 1
    reaction_class_device: str = "cpu"
    n_cpu: int = 1
    command: str | None = None


__all__ = [
    "ExtractRrseqConsRequest",
    "ExtractRrseqGapRequest",
    "ExtractRouteMotifsRequest",
    "ExtractCompositeRulesRequest",
    "CollectGappedCompositeRulesRequest",
    "ClassifyGappedRrseqsRequest",
    "ExtractRetroBleuGramsRequest",
    "ClassifyCompositeRulesRequest",
    "ClassifyRrseqConsReactionsRequest",
    "ClassifyProtectionIntervalReactionsRequest",
    "UnwrapRrseqConsRequest",
    "UnwrapCompositeRuleRequest",
    "ScoreRrseqConsOverlapRequest",
    "AnalyzeProtectionRequest",
    "PreprocessRoutesRequest",
    "AuditRouteProvenanceRequest",
    "AnnotateContextHistoryRequest",
    "MigrateOccurrenceContextRequest",
    "BuildReferenceIndexRequest",
    "InspectGeneratedRoutesRequest",
    "BuildReferenceLibraryRequest",
    "BuildPgStrategyLibraryRequest",
    "RepackPgStrategyLibraryRequest",
    "AssessPgStrategiesRequest",
    "VerifyPgStrategyLibraryRequest",
    "BuildCompositeLibraryRequest",
    "ReclassifyPgStrategyLibraryRequest",
    "VerifyReferenceLibraryRequest",
    "BuildRouteAssessmentReferenceRequest",
    "AssessRoutesRequest",
    "AssessRouteRequest",
    "CounterfactualReassemblyRrseqFreeRequest",
]
