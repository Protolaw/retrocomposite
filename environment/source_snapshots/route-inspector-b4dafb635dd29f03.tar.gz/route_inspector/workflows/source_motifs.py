"""Execute source-bound tactic superclass analysis; preserve raw classifier evidence."""

from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from route_inspector.chemistry.classification.providers import (
    _parse_namerxn_output,
    _resolve_executable,
)
from route_inspector.chemistry.classification.taxonomy import taxonomy_names
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.reference_library import ReferenceTacticLibrary
from route_inspector.tactics.classification import source_motifs
from route_inspector.tactics.classification.source_motifs import (
    KINDS,
    collect,
    parse_class,
    reports,
)


@dataclass(frozen=True, kw_only=True)
class SourceMotifClassificationRequest:
    reference_library: Path
    routes_json: Path
    output_dir: Path
    kind: str = "rrsubtree_cons"
    namerxn_path: str = "outputs/NameRXN/HazELNut"
    namerxn_def: Path | None = None
    batch_size: int = 100
    prepare_only: bool = False


@dataclass(frozen=True)
class SourceMotifClassificationResult:
    output_dir: Path
    summary: dict[str, Any]
    manifest: dict[str, Any]

    @property
    def diagnostics_path(self) -> Path:
        return self.output_dir / "errors.tsv"


def classify(steps, executable, output, batch_size, *, progress=None):
    rawdir = output / "namerxn_raw"
    rawdir.mkdir()
    for offset in range(0, len(steps), batch_size):
        batch = steps[offset : offset + batch_size]
        inp = rawdir / f"{offset:06d}.input.smi"
        out = rawdir / f"{offset:06d}.output.smi"
        inp.write_text(
            "".join(f"{r['classifier_input']} {r['step_id']}\n" for r in batch)
        )
        run = subprocess.run(
            [str(executable), "-nomap", str(inp), str(out)],
            capture_output=True,
            text=True,
            timeout=300,
        )
        (rawdir / f"{offset:06d}.log").write_text(run.stdout + run.stderr)
        if run.returncode or not out.is_file():
            raise RuntimeError(f"NameRXN batch failed: {inp}")
        labels, errors, unexpected = _parse_namerxn_output(
            out, {r["step_id"] for r in batch}
        )
        if unexpected:
            raise ValueError("Unexpected NameRXN record IDs")
        for row in batch:
            error = "; ".join(errors.get(row["step_id"], []))
            if row["step_id"] not in labels:
                error = error or "NameRXN returned no record"
            row.update(parse_class("" if error else labels[row["step_id"]]))
            row["error"] = error
        if progress is not None:
            progress(offset + len(batch), len(steps))


def run(
    request: SourceMotifClassificationRequest,
    *,
    progress: Callable[[int, int], None] | None = None,
) -> SourceMotifClassificationResult:
    """Validate inputs, classify selected source nodes, and write audited reports.

    Existing destinations are never overwritten. An execution failure leaves
    its raw diagnostics and a manifest marked failed, never complete.
    """
    output = request.output_dir.expanduser().resolve()
    if output.exists():
        raise FileExistsError("Refusing to overwrite analysis directory")
    if request.kind not in KINDS:
        raise ValueError(f"Unsupported tactic kind: {request.kind}")
    if request.batch_size < 1:
        raise ValueError("batch_size must be positive")
    routes_path = request.routes_json.expanduser().resolve(strict=True)
    library_path = request.reference_library.expanduser().resolve(strict=True)
    definition = (
        request.namerxn_def.expanduser().resolve(strict=True)
        if request.namerxn_def
        else None
    )
    executable = (
        None if request.prepare_only else _resolve_executable(request.namerxn_path)
    )
    names = taxonomy_names(definition)
    inputs = [routes_path, library_path / "manifest.json"]
    if executable:
        inputs.append(executable)
    if definition:
        inputs.append(definition)
    hashes = {path: sha256_file(path) for path in inputs}
    implementations = [Path(__file__), Path(source_motifs.__file__)]
    implementation_hashes = {
        os.path.relpath(path): sha256_file(path) for path in implementations
    }
    with ReferenceTacticLibrary.load(library_path, verification="full") as library:
        steps, occurrences, links = collect(
            library,
            json.loads(routes_path.read_text()),
            hashes[routes_path],
            kind=request.kind,
        )
        library_id = library.manifest.library_id
    output.mkdir(parents=True)
    manifest = dict(
        status="running",
        library_id=library_id,
        inputs_sha256={
            os.path.relpath(path): digest for path, digest in hashes.items()
        },
        analysis="source_motif_namerxn_superclasses_v2",
        kind=request.kind,
        step_scope="selected",
        implementation_sha256=sha256_file(Path(__file__)),
        implementation_files_sha256=implementation_hashes,
        classifier_input="Recorded clean forward reaction, map-free serialization only; NameRXN -nomap. No new rule extraction.",
    )

    def save_manifest():
        (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

    save_manifest()
    try:
        if request.prepare_only:
            for row in steps:
                row.update(parse_class(""))
                row["error"] = "NameRXN not run (--prepare-only)"
        else:
            classify(steps, executable, output, request.batch_size, progress=progress)
        summary = reports(steps, occurrences, links, output, names)
        if any(sha256_file(path) != digest for path, digest in hashes.items()):
            raise ValueError("Input changed during analysis")
        manifest["status"] = "prepared" if request.prepare_only else summary["status"]
        save_manifest()
    except BaseException:
        manifest["status"] = "failed"
        save_manifest()
        raise
    return SourceMotifClassificationResult(output, summary, manifest)


def write_aggregate(
    analysis_root: Path,
    output: Path,
    *,
    examples: Path | None = None,
    replace: bool = False,
) -> Path:
    """Publish the combined Markdown atomically, protecting source reports."""
    from route_inspector.infrastructure.publication import atomic_text_path
    from route_inspector.tactics.classification.protection_statistics import (
        COHORTS,
        aggregate,
    )

    root = analysis_root.expanduser().resolve(strict=True)
    output = output.expanduser().resolve()
    if output.suffix.lower() != ".md":
        raise ValueError("Aggregate output must be a Markdown (.md) file")
    if any(output.is_relative_to(root / dirname) for _, _, dirname in COHORTS):
        raise ValueError("Aggregate output cannot overwrite a source analysis")
    if output.exists() and not replace:
        raise FileExistsError(
            "Output exists; pass --replace to regenerate the aggregate"
        )
    content = aggregate(root, output, examples)
    temporary, stream = atomic_text_path(output)
    try:
        with stream:
            stream.write(content)
        if replace:
            os.replace(temporary, output)
        else:
            os.link(
                temporary, output
            )  # Refuse a destination created during generation.
    finally:
        temporary.unlink(missing_ok=True)
    return output
