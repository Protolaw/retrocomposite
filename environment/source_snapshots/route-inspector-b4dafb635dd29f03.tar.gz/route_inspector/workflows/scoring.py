"""Corpus execution and publication for scoring."""

from __future__ import annotations

import traceback
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Any

from route_inspector.infrastructure.artifacts import write_json, write_standard_sidecars
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.runtime import (
    normalize_n_cpu,
    setup_runtime_cache_dirs,
)
from route_inspector.infrastructure.text import read_json, write_tsv
from route_inspector.metrics.rrseq_overlap import (
    RRseqSet,
    matched_rule_rows,
    overlap_score_row,
)
from route_inspector.routes.io import limited_route_items
from route_inspector.rules.config import rule_extractor_args_dict
from route_inspector.rules.extraction import SynPlannerRuleExtractor
from route_inspector.rules.models import RouteProcessingStats
from route_inspector.tactics.rrseq.execution import (
    _init_rrseq_worker,
    _rrseq_route_worker,
)
from route_inspector.tactics.rrseq.processing import (
    merge_route_processing_stats,
    process_route_for_rrseqs,
)
from route_inspector.tactics.rrseq.score_inputs import (
    load_extracted_rrseq_set,
    load_rrseq_classifications,
)
from route_inspector.workflows.requests import ScoreRrseqConsOverlapRequest


def reference_rrseqs_from_routes(
    routes_json_path: Path,
    rule_extractor: SynPlannerRuleExtractor,
    *,
    min_length: int,
    max_length: int | None,
    limit: int | None = None,
    ignore_errors: bool = False,
    progress_interval: int = 250,
    n_cpu: int = 1,
    extractor_args: Any | None = None,
) -> tuple[RRseqSet, RouteProcessingStats, list[dict[str, Any]]]:
    """Extract reference rrseqs directly from route JSON.

    Reference rules are extracted directly from the route JSON with the same SynPlanner
    settings used for the candidate rrseqs.
    """
    routes_json_path = resolve_existing_path(routes_json_path)
    routes_json = read_json(routes_json_path)
    route_work_items = limited_route_items(routes_json, limit)
    n_cpu = normalize_n_cpu(n_cpu)
    popularity_by_rule: dict[str, int] = defaultdict(int)
    references_by_rule: dict[str, set[str]] = defaultdict(set)
    errors: list[dict[str, Any]] = []
    stats = RouteProcessingStats()

    def consume_result(result: dict[str, Any], index: int) -> None:
        """Merge one worker result into the aggregate state.

        The scorer normalizes rule sequences before comparison so order-sensitive
        rrseqs can be matched exactly and weighted by popularity.
        """
        merge_route_processing_stats(stats, result["stats"])
        error = result.get("error")
        if error:
            errors.append(
                {
                    **error,
                    "stage": "extract_reference_rrseqs",
                }
            )
            if not ignore_errors:
                raise RuntimeError(
                    f"route {error['route_id']} failed during reference extraction: "
                    f"{error['error_type']}: {error['message']}"
                )
            return

        route_id = result["route_id"]
        for sequence in result["route_sequences"]:
            rule = "$".join(sequence)
            popularity_by_rule[rule] += 1
            references_by_rule[rule].add(str(route_id))

        if progress_interval and index % progress_interval == 0:
            print(
                f"processed reference routes={index} "
                f"reference_rrseqs={len(popularity_by_rule)} "
                f"errors={stats.errors}",
                flush=True,
            )

    if n_cpu > 1 and route_work_items:
        if extractor_args is None:
            raise ValueError("extractor_args is required when n_cpu > 1")
        with ProcessPoolExecutor(
            max_workers=n_cpu,
            initializer=_init_rrseq_worker,
            initargs=(
                rule_extractor_args_dict(extractor_args),
                min_length,
                max_length,
                False,
            ),
        ) as executor:
            for index, result in enumerate(
                executor.map(_rrseq_route_worker, route_work_items),
                start=1,
            ):
                consume_result(result, index)
    else:
        for index, (route_id, route) in enumerate(route_work_items, start=1):
            try:
                result = process_route_for_rrseqs(
                    route_id,
                    route,
                    rule_extractor,
                    min_length=min_length,
                    max_length=max_length,
                    store_route_without_rrseqs=False,
                )
            except Exception as exc:
                result = {
                    "route_id": route_id,
                    "route_sequences": {},
                    "single_rules": {},
                    "route_without_rrseqs": None,
                    "no_rrseq_reason": "",
                    "stats": RouteProcessingStats(routes_seen=1, errors=1),
                    "error": {
                        "route_id": route_id,
                        "stage": "extract_reference_rrseqs",
                        "error_type": type(exc).__qualname__,
                        "message": str(exc) or traceback.format_exc(limit=1).strip(),
                    },
                }
            consume_result(result, index)

    if progress_interval and len(route_work_items) % progress_interval:
        print(
            f"processed reference routes={len(route_work_items)} "
            f"reference_rrseqs={len(popularity_by_rule)} "
            f"errors={stats.errors}",
            flush=True,
        )

    return (
        RRseqSet(
            source=str(routes_json_path),
            popularity_by_rule=dict(popularity_by_rule),
            references_by_rule={
                rule: set(refs) for rule, refs in references_by_rule.items()
            },
            rows_seen=stats.routes_seen,
            parse_errors=stats.errors,
        ),
        stats,
        errors,
    )


def output_paths(output: Path) -> tuple[Path, Path, Path]:
    """Resolve output TSV and summary paths for overlap scoring.

    The scorer normalizes rule sequences before comparison so order-sensitive rrseq
    rules can be matched exactly and weighted by popularity.
    """
    if output.is_dir() or output.suffix == "":
        return (
            output / "rrseq_cons_overlap_scores.tsv",
            output / "rrseq_cons_overlap_matches.tsv",
            output / "summary.json",
        )
    prefix = output.with_suffix("")
    return (
        output,
        prefix.with_name(f"{prefix.name}_matches").with_suffix(".tsv"),
        output.parent / "summary.json",
    )


def score_rrseq_overlap(
    extracted_tsvs: list[Path],
    reference_routes_json: Path,
    output: Path,
    rule_extractor: SynPlannerRuleExtractor,
    *,
    min_length: int = 2,
    max_length: int | None = 20,
    limit: int | None = None,
    ignore_errors: bool = False,
    progress_interval: int = 250,
    classification_tsvs: list[Path] | None = None,
    n_cpu: int = 1,
    extractor_args: Any | None = None,
) -> dict[str, Any]:
    """Score rrseq rule overlap against reference routes.

    The scorer normalizes rule sequences before comparison so order-sensitive rrseq
    rules can be matched exactly and weighted by popularity.
    """
    extracted = load_extracted_rrseq_set(extracted_tsvs)
    classifications = load_rrseq_classifications(classification_tsvs)
    reference, reference_stats, errors = reference_rrseqs_from_routes(
        reference_routes_json,
        rule_extractor,
        min_length=min_length,
        max_length=max_length,
        limit=limit,
        ignore_errors=ignore_errors,
        progress_interval=progress_interval,
        n_cpu=n_cpu,
        extractor_args=extractor_args,
    )
    score_row = overlap_score_row(extracted, reference, classifications)
    score_path, matches_path, summary_path = output_paths(output)

    score_fieldnames = [
        "extracted_tsv",
        "reference_routes_json",
        "classification_tsv",
        "extracted_rows",
        "reference_routes",
        "classification_rows",
        "extracted_unique_rrseq_cons",
        "reference_unique_rrseq_cons",
        "overlap_unique_rrseq_cons",
        "classified_overlap_unique_rrseq_cons",
        "positive_overlap_unique_rrseq_cons",
        "negative_overlap_unique_rrseq_cons",
        "mixed_classification_overlap_unique_rrseq_cons",
        "extracted_overlap_ratio",
        "reference_coverage_ratio",
        "jaccard",
        "extracted_popularity",
        "overlapping_popularity",
        "popularity_overlap_ratio",
        "positive_overlapping_popularity",
        "negative_overlapping_popularity",
        "pos_overlap",
        "neg_overlap",
        "extracted_parse_errors",
        "reference_errors",
        "classification_parse_errors",
    ]
    write_tsv(score_path, score_fieldnames, [score_row])

    match_fieldnames = [
        "RRseq_cons",
        "present_in_reference",
        "classification",
        "classification_positive_weight",
        "classification_negative_weight",
        "classification_positive_share",
        "classification_negative_share",
        "extracted_popularity",
        "extracted_reference_ids",
        "reference_route_ids",
    ]
    write_tsv(
        matches_path,
        match_fieldnames,
        matched_rule_rows(extracted, reference, classifications),
    )

    summary = {
        "extracted_tsvs": [str(resolve_existing_path(path)) for path in extracted_tsvs],
        "reference_routes_json": str(resolve_existing_path(reference_routes_json)),
        "classification_tsvs": [
            str(resolve_existing_path(path)) for path in classification_tsvs or []
        ],
        "output": str(score_path),
        "matches_output": str(matches_path),
        "summary_file": str(summary_path),
        "min_length": min_length,
        "max_length": max_length,
        "n_cpu": normalize_n_cpu(n_cpu),
        "reference_routes_seen": reference_stats.routes_seen,
        "reference_routes_with_rrseq_cons": reference_stats.routes_with_rrseqs,
        "reference_reactions_seen": reference_stats.reactions_seen,
        "reference_skipped_reactions": reference_stats.skipped_reactions,
        "reference_errors": reference_stats.errors,
        "reference_error_examples": errors[:25],
        **score_row,
    }
    write_json(summary_path, summary)
    return summary


def score_reference_routes(args: ScoreRrseqConsOverlapRequest) -> dict[str, Any]:
    """Run this module command with parsed CLI arguments.

    The scorer normalizes rule sequences before comparison so order-sensitive rrseq
    rules can be matched exactly and weighted by popularity.
    """
    setup_runtime_cache_dirs()
    if args.min_length < 2:
        raise ValueError("--min-length must be at least 2")
    if args.max_length is not None and args.max_length <= 0:
        args.max_length = None
    if args.max_length is not None and args.max_length < args.min_length:
        raise ValueError("--max-length must be greater than or equal to --min-length")
    if getattr(args, "output", None) is None:
        if getattr(args, "output_dir", None) is None:
            raise ValueError("either --output or --output-dir is required")
        args.output = args.output_dir
    elif getattr(args, "output_dir", None) is not None:
        raise ValueError("--output and --output-dir cannot be used together")

    rule_extractor = SynPlannerRuleExtractor.from_args(args)
    summary = score_rrseq_overlap(
        [resolve_existing_path(path) for path in args.extracted_tsv],
        resolve_existing_path(args.reference_routes_json),
        args.output,
        rule_extractor,
        min_length=args.min_length,
        max_length=args.max_length,
        limit=args.limit,
        ignore_errors=args.ignore_errors,
        progress_interval=args.progress_interval,
        n_cpu=args.n_cpu,
        extractor_args=args,
        classification_tsvs=(
            [resolve_existing_path(path) for path in args.classification_tsv]
            if args.classification_tsv
            else None
        ),
    )
    sidecars = write_standard_sidecars(
        Path(summary["output"]).parent,
        command_name="score-rrseq-cons-overlap",
        summary=summary,
        errors=summary.get("reference_error_examples", []),
        input_files=[
            *args.extracted_tsv,
            args.reference_routes_json,
            *(args.classification_tsv or []),
        ],
        output_files={
            "scores": summary["output"],
            "matches": summary["matches_output"],
            "summary": summary["summary_file"],
        },
        config_path=getattr(args, "config", None),
        cli_args=args,
    )
    summary["sidecar_files"] = sidecars
    write_json(Path(summary["summary_file"]), summary)
    return summary


__all__ = ["score_reference_routes", "score_rrseq_overlap"]
