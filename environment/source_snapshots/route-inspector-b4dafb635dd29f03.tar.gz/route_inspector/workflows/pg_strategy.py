"""Typed standalone PG application workflows."""

from __future__ import annotations

import json
import shutil
import sqlite3
from collections import Counter

from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
from route_inspector.protection.strategies.catalog import ReferencePGStrategyLibrary
from route_inspector.protection.strategies.construction import (
    PGStrategyPublicationResult,
    _errors,
    _extract,
    _results,
    _stage_inputs,
    _temporary,
    build_pg_strategy_library,
)
from route_inspector.protection.strategies.processor import RoutePGStrategyProcessor
from route_inspector.reference_library.storage.artifacts import (
    _publish_directory_no_replace,
)
from route_inspector.rules.graph import canonical_json

__all__ = [
    "PGStrategyPublicationResult",
    "build_pg_strategy_library",
    "run_build_pg_strategy_library",
    "assess_pg_strategy_routes",
]


def run_build_pg_strategy_library(args):
    from route_inspector.chemistry.classification.providers import create_provider

    processor = RoutePGStrategyProcessor.from_config(
        args.config, args.pg_strategy_config, source_id_adapter=args.source_id_adapter
    )
    provider = None
    if args.pg_reaction_class_backend != "none":
        provider = create_provider(
            args.pg_reaction_class_backend,
            reaction_classifier_path=args.reaction_classifier_path,
            namerxn_executable=args.namerxn_executable,
            label_policy=args.pg_label_policy,
            torch_threads=args.pg_torch_threads,
            device=args.pg_device,
        )
        _ = provider.provider_version
    result = build_pg_strategy_library(
        args.routes_json,
        args.output_dir,
        processor,
        provider,
        work_dir=args.work_dir,
        resume=args.resume,
        memory_budget_mb=args.memory_budget_mb,
        reference_id=args.reference_id,
        source_identity=args.source_identity,
        n_cpu=args.n_cpu,
        limit=args.limit,
        progress_interval=args.progress_interval,
        include_sqlite=args.sqlite_catalog,
        worker_chunksize=args.pg_worker_chunksize,
        classifier_metadata={
            "label_policy": args.pg_label_policy,
            "tier": 3,
            "device": args.pg_device,
            "torch_threads": args.pg_torch_threads,
        },
    )
    print(
        f"built PG strategy library {result.manifest.library_id} at {result.output_path}"
    )
    return 0


def assess_pg_strategy_routes(args):
    from route_inspector.protection.strategies.assessment import assess_pg_strategies

    setup_runtime_cache_dirs()
    destination, temporary = _temporary(args.output_dir)
    try:
        with ReferencePGStrategyLibrary.load(
            args.library, verification=args.verification
        ) as library:
            processor = RoutePGStrategyProcessor.from_profile(
                library.manifest.processing_profile
            )
            digest = sha256_file(args.routes_json)
            dataset = args.dataset_id or f"query_{digest[:16]}"
            source = args.source_identity or f"sha256:{digest}"
            with sqlite3.connect(temporary / ".construction.sqlite") as connection:
                connection.row_factory = sqlite3.Row
                items = _stage_inputs(
                    connection, args.routes_json, route_id=args.route_id
                )
                count = _extract(
                    connection,
                    items,
                    processor,
                    dataset,
                    source,
                    args.n_cpu,
                    args.progress_interval,
                )
                if args.route_id is not None and not count:
                    raise ValueError(f"query route ID not found: {args.route_id}")
                assessments = [
                    assess_pg_strategies(p, library, route=p.route)
                    for p in _results(connection)
                ]
            (temporary / ".construction.sqlite").unlink()
            (temporary / "pg_strategy_assessments.json").write_text(
                json.dumps([a.to_dict() for a in assessments], indent=2) + "\n",
                encoding="utf-8",
            )
            for field, filename in (
                ("event_matches", "event"),
                ("interval_step_matches", "interval_step"),
                ("interval_sequence_matches", "interval_sequence"),
                ("interval_ngram_matches", "interval_ngram"),
            ):
                with (temporary / f"pg_strategy_{filename}_matches.jsonl").open(
                    "w", encoding="utf-8"
                ) as stream:
                    for a in assessments:
                        for match in getattr(a, field):
                            stream.write(canonical_json(match.to_dict()) + "\n")
            _errors(
                temporary / "errors.tsv",
                [d for a in assessments for d in a.diagnostics],
            )
            summary = {
                "route_count": count,
                "status_counts": dict(Counter(a.status for a in assessments)),
                "interval_ngram_occurrence_count": sum(
                    len(a.interval_ngram_matches) for a in assessments
                ),
            }
            (temporary / "summary.json").write_text(
                json.dumps(summary, indent=2) + "\n", encoding="utf-8"
            )
            manifest = {
                "schema_version": 2,
                "pg_strategy_library_id": library.library_id,
                "input_sha256": digest,
                "dataset_id": dataset,
                "source_identity": source,
                "processing_profile": dict(library.manifest.processing_profile),
                "artifacts": {
                    p.name: {
                        "path": p.name,
                        "sha256": sha256_file(p),
                        "size_bytes": p.stat().st_size,
                    }
                    for p in sorted(temporary.iterdir())
                },
            }
            (temporary / "manifest.json").write_text(
                json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
            )
        _publish_directory_no_replace(temporary, destination)
        print(f"assessed {count} PG routes at {destination}")
        return 0
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise
