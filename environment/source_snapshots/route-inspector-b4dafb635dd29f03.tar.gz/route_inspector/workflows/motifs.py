"""Sequential one-pass corpus extraction for route rule motifs.

The runner prepares each route once through :func:`extract_route_motifs`, then
projects the returned occurrences into the four existing kind-specific output
contracts.  Version 1 is deliberately sequential so one in-process rule cache
is shared across the complete corpus.
"""

from __future__ import annotations

import copy
import json
import traceback
from collections import defaultdict
from pathlib import Path
from typing import Any

from route_inspector.datasets.paroutes.source_ids import PAROUTES_SOURCE_ID_ADAPTER
from route_inspector.infrastructure.artifacts import (
    dataset_prefix_from_path,
    reference_sort_key,
    stage_output_dir,
    write_json,
    write_standard_sidecars,
)
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
from route_inspector.routes.io import iter_route_items_from_json_file
from route_inspector.rules.extraction import SynPlannerRuleExtractor
from route_inspector.rules.models import RouteProcessingStats
from route_inspector.rules.preparation import route_target_smiles
from route_inspector.tactics.extraction import extract_route_motifs
from route_inspector.tactics.rrseq.processing import merge_query_cgr_key_records
from route_inspector.tactics.rrseq.route_extraction import no_rrseq_reason
from route_inspector.tactics.rrsubtree.outputs import (
    RRSUBTREE_ERROR_FIELDS,
    write_rrsubtree_outputs,
)
from route_inspector.workflows.requests import ExtractRouteMotifsRequest
from route_inspector.workflows.rrseq import write_rrseq_extraction_outputs

RuleSequence = tuple[str, ...]


def _rrseq_error_record(error: dict[str, Any]) -> dict[str, Any]:
    """Project a root error into the unchanged RRSeq error schema."""

    return {key: error[key] for key in ("route_id", "stage", "error_type", "message")}


def _new_rrseq_aggregate() -> dict[str, Any]:
    return {
        "references": defaultdict(set),
        "targets": defaultdict(lambda: defaultdict(set)),
        "query_cgr_keys": {},
        "base_query_cgr_keys": {},
        "occurrences": [],
        "routes_without": {},
        "routes_without_by_reason": defaultdict(int),
        "routes_with": 0,
    }


def _merge_sequence_targets(
    aggregate: dict[str, Any],
    route_id: Any,
    sequences: dict[RuleSequence, set[str]],
) -> None:
    for sequence, targets in sequences.items():
        aggregate["references"][sequence].add(route_id)
        aggregate["targets"][sequence][route_id].update(targets)


def _remember_route_without_rrseqs(
    aggregate: dict[str, Any],
    *,
    route_id: Any,
    route: dict[str, Any],
    kind: str,
    preparation_stats: Any,
    min_length: int,
    store_route: bool,
) -> None:
    extracted_reaction_rules = (
        preparation_stats.reactions_seen - preparation_stats.skipped_reactions
    )
    reason = no_rrseq_reason(
        reactions_seen=preparation_stats.reactions_seen,
        extracted_reaction_rules=extracted_reaction_rules,
        skipped_reactions=preparation_stats.skipped_reactions,
        min_length=min_length,
        no_net_selected_change=(
            preparation_stats.no_net_selected_change if kind == "gap" else 0
        ),
    )
    aggregate["routes_without_by_reason"][reason] += 1
    if not store_route:
        return

    retained_route = copy.deepcopy(route)
    metadata = retained_route.setdefault("metadata", {})
    metadata[f"rrseq_{kind}_extraction"] = {
        "route_id": route_id,
        "target_smiles": route_target_smiles(route),
        "reactions_seen": preparation_stats.reactions_seen,
        "extracted_reaction_rules": extracted_reaction_rules,
        "skipped_reactions": preparation_stats.skipped_reactions,
        **(
            {"no_net_selected_change": (preparation_stats.no_net_selected_change)}
            if kind == "gap"
            else {}
        ),
        "reason": reason,
    }
    aggregate["routes_without"][route_id] = retained_route


def _rrseq_family_count(aggregate: dict[str, Any]) -> int:
    identities = {
        aggregate["query_cgr_keys"].get(sequence, sequence)
        for sequence in aggregate["references"]
    }
    return len(identities)


def _child_rrseq_args(
    args: ExtractRouteMotifsRequest,
    *,
    output: Path,
    min_length: int,
    max_length: int | None,
) -> ExtractRouteMotifsRequest:
    child = copy.copy(args)
    child.output = output
    child.output_dir = None
    child.min_length = min_length
    child.max_length = max_length
    child.routes_without_rrseqs_output = None
    return child


def _write_rrseq_kind(
    args: ExtractRouteMotifsRequest,
    *,
    output_dir: Path,
    dataset_id: str,
    kind: str,
    aggregate: dict[str, Any],
    single_rules: dict[str, Any],
    single_rule_occurrences: list[dict[str, Any]],
    stats: RouteProcessingStats,
    errors: list[dict[str, Any]],
    min_length: int,
    max_length: int | None,
    store_routes_without_rrseqs: bool,
) -> None:
    child_args = _child_rrseq_args(
        args,
        output=output_dir / f"{dataset_id}.tsv",
        min_length=min_length,
        max_length=max_length,
    )
    write_rrseq_extraction_outputs(
        child_args,
        stats=stats,
        references_by_sequence=aggregate["references"],
        target_molecules_by_sequence=aggregate["targets"],
        query_cgr_keys_by_sequence=aggregate["query_cgr_keys"],
        base_query_cgr_keys_by_sequence=aggregate["base_query_cgr_keys"],
        references_by_single_rule=single_rules["references"],
        target_molecules_by_single_rule=single_rules["targets"],
        query_cgr_keys_by_single_rule=single_rules["query_cgr_keys"],
        base_query_cgr_keys_by_single_rule=single_rules["base_query_cgr_keys"],
        single_rule_occurrences=single_rule_occurrences,
        errors=errors,
        routes_without_rrseqs=aggregate["routes_without"],
        routes_without_rrseqs_by_reason=(aggregate["routes_without_by_reason"]),
        n_cpu=1,
        worker_chunksize=1,
        max_pending_chunks=1,
        store_routes_without_rrseqs=store_routes_without_rrseqs,
        sequence_mode=kind,
        extraction_mode="shared_route_pass",
        extra_summary={"shared_route_preparation": True},
        rrseq_cons_occurrences=(aggregate["occurrences"] if kind == "cons" else None),
        rrseq_gap_occurrences=(aggregate["occurrences"] if kind == "gap" else None),
        sidecar_command_name="extract-route-motifs",
    )


def _validate_limits(
    args: ExtractRouteMotifsRequest,
) -> tuple[int, int | None, int, int, int]:
    rrseq_min_length = int(args.rrseq_min_length)
    rrseq_max_length = args.rrseq_max_length
    if rrseq_max_length is not None:
        rrseq_max_length = int(rrseq_max_length)
        if rrseq_max_length <= 0:
            rrseq_max_length = None
    rrsubtree_min_size = int(args.rrsubtree_min_size)
    rrsubtree_max_size = int(args.rrsubtree_max_size)
    rrsubtree_max_candidates = int(args.rrsubtree_max_candidates_per_route)

    if rrseq_min_length < 2:
        raise ValueError("--rrseq-min-length must be at least 2")
    if rrseq_max_length is not None and rrseq_max_length < rrseq_min_length:
        raise ValueError(
            "--rrseq-max-length must be greater than or equal to --rrseq-min-length"
        )
    if rrsubtree_min_size < 3:
        raise ValueError("--rrsubtree-min-size must be at least 3")
    if rrsubtree_max_size < rrsubtree_min_size:
        raise ValueError(
            "--rrsubtree-max-size must be greater than or equal to --rrsubtree-min-size"
        )
    if rrsubtree_max_candidates <= 0:
        raise ValueError("--rrsubtree-max-candidates-per-route must be positive")
    return (
        rrseq_min_length,
        rrseq_max_length,
        rrsubtree_min_size,
        rrsubtree_max_size,
        rrsubtree_max_candidates,
    )


def run(args: ExtractRouteMotifsRequest) -> int:
    """Extract all four motif kinds with one sequential pass over the routes."""

    setup_runtime_cache_dirs()
    requested_n_cpu = int(getattr(args, "n_cpu", 1) or 1)
    if requested_n_cpu != 1:
        raise ValueError("extract-route-motifs currently supports only --n-cpu 1")

    (
        rrseq_min_length,
        rrseq_max_length,
        rrsubtree_min_size,
        rrsubtree_max_size,
        rrsubtree_max_candidates,
    ) = _validate_limits(args)
    routes_json = Path(args.routes_json).expanduser()
    args.routes_json = routes_json
    context_history_value = getattr(args, "context_history", None)
    context_history_path = (
        resolve_existing_path(context_history_value)
        if context_history_value is not None
        else None
    )
    args.context_history = context_history_path
    dataset_id = str(
        getattr(args, "dataset_id", None) or dataset_prefix_from_path(routes_json)
    )
    output_dir_value = getattr(args, "output_dir", None)
    output_dir = (
        Path(output_dir_value).expanduser()
        if output_dir_value is not None
        else stage_output_dir(Path("outputs"), dataset_id, "route_motifs")
    )
    args.output_dir = output_dir

    rrseq = {kind: _new_rrseq_aggregate() for kind in ("cons", "gap")}
    single_rules = {
        kind: {
            "references": defaultdict(set),
            "targets": defaultdict(lambda: defaultdict(set)),
            "query_cgr_keys": {},
            "base_query_cgr_keys": {},
        }
        for kind in ("cons", "gap")
    }
    single_rule_occurrences: list[dict[str, Any]] = []
    rrsubtree_occurrences = {"cons": [], "gap": []}
    rrsubtree_routes = {"cons": set(), "gap": set()}
    rrsubtree_candidates = {"total": 0, "cons": 0, "gap": 0}
    rrsubtree_eligibility: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    rrseq_errors = {"cons": [], "gap": []}
    rrsubtree_errors: list[dict[str, Any]] = []
    routes_seen = 0
    routes_completed = 0
    rrseq_routes_completed = {"cons": 0, "gap": 0}
    rrsubtree_routes_completed = 0
    preparation_totals = {
        "reactions_seen": 0,
        "reaction_rule_cache_hits": 0,
        "reaction_rule_cache_misses": 0,
        "skipped_reactions": 0,
        "no_net_selected_change": 0,
    }

    extractor = SynPlannerRuleExtractor.from_args(args)
    source_identity = str(
        getattr(args, "source_identity", None) or routes_json.resolve()
    )
    source_id_adapter = str(
        getattr(args, "source_id_adapter", PAROUTES_SOURCE_ID_ADAPTER)
    )
    store_routes_without_rrseqs = not getattr(
        args,
        "skip_routes_without_rrseqs_output",
        False,
    )
    progress_interval = int(getattr(args, "progress_interval", 0) or 0)

    route_items = iter_route_items_from_json_file(
        routes_json,
        getattr(args, "limit", None),
    )
    for route_id, route in route_items:
        routes_seen += 1
        try:
            result = extract_route_motifs(
                route_id,
                route,
                extractor,
                source_identity=source_identity,
                dataset_id=dataset_id,
                source_id_adapter=source_id_adapter,
                rrseq_min_length=rrseq_min_length,
                rrseq_max_length=rrseq_max_length,
                rrsubtree_min_size=rrsubtree_min_size,
                rrsubtree_max_size=rrsubtree_max_size,
                rrsubtree_max_candidates_per_route=rrsubtree_max_candidates,
            )
        except Exception as exc:
            error = {
                "dataset": dataset_id,
                "route_id": route_id,
                "stage": "extract_route_motifs",
                "error_type": type(exc).__qualname__,
                "message": str(exc) or traceback.format_exc(limit=1).strip(),
            }
            if not getattr(args, "ignore_errors", False):
                raise RuntimeError(
                    f"route {route_id} failed during extract_route_motifs: "
                    f"{error['error_type']}: {error['message']}"
                ) from exc
            errors.append(error)
            rrseq_error = _rrseq_error_record(error)
            rrseq_errors["cons"].append(rrseq_error)
            rrseq_errors["gap"].append(rrseq_error)
            rrsubtree_errors.append(error)
            if progress_interval and routes_seen % progress_interval == 0:
                print(
                    f"processed routes={routes_seen} completed={routes_completed} "
                    f"errors={len(errors)}",
                    flush=True,
                )
            continue

        strict_path_error = getattr(result, "strict_path_error", None)
        if strict_path_error is not None:
            error = {
                "dataset": dataset_id,
                "route_id": route_id,
                "stage": "prepare_strict_route_paths",
                "error_type": strict_path_error.error_type,
                "message": strict_path_error.message,
            }
            if not getattr(args, "ignore_errors", False):
                raise RuntimeError(
                    f"route {route_id} failed during "
                    "prepare_strict_route_paths: "
                    f"{error['error_type']}: {error['message']}"
                )
            errors.append(error)
            rrseq_errors["cons"].append(_rrseq_error_record(error))
            rrsubtree_errors.append(error)
        else:
            routes_completed += 1
            rrseq_routes_completed["cons"] += 1
        rrseq_routes_completed["gap"] += 1

        for field in preparation_totals:
            preparation_totals[field] += int(getattr(result.preparation_stats, field))

        rrsubtree_error = getattr(result, "rrsubtree_error", None)
        if strict_path_error is not None:
            pass
        elif rrsubtree_error is not None:
            error = {
                "dataset": dataset_id,
                "route_id": route_id,
                "stage": "extract_rrsubtrees",
                "error_type": rrsubtree_error.error_type,
                "message": rrsubtree_error.message,
                "limit": rrsubtree_error.limit,
                "candidate_count": rrsubtree_error.candidate_count,
                "cons_candidate_count": rrsubtree_error.cons_candidate_count,
                "gap_candidate_count": rrsubtree_error.gap_candidate_count,
            }
            if not getattr(args, "ignore_errors", False):
                raise RuntimeError(
                    f"route {route_id} failed during "
                    "extract_rrsubtrees: "
                    f"{error['error_type']}: {error['message']}"
                )
            errors.append(error)
            rrsubtree_errors.append(error)
        else:
            rrsubtree_routes_completed += 1

        eligibility_record: dict[str, Any] = {"route_id": str(route_id)}
        for kind in ("cons", "gap"):
            witness = getattr(result, f"rrsubtree_{kind}_eligibility_witness", None)
            if witness is not None:
                eligibility_record[f"rrsubtree_{kind}_witness"] = witness.to_dict()
        if len(eligibility_record) > 1:
            rrsubtree_eligibility.append(eligibility_record)

        single_rule_occurrences.extend(getattr(result, "single_rule_occurrences", ()))
        for kind, sequences, keys, base_keys, occurrences in (
            (
                "cons",
                result.rrseq_cons_sequences,
                result.rrseq_cons_query_cgr_keys,
                getattr(result, "rrseq_cons_base_query_cgr_keys", {}),
                result.rrseq_cons_occurrences,
            ),
            (
                "gap",
                result.rrseq_gap_sequences,
                result.rrseq_gap_query_cgr_keys,
                getattr(result, "rrseq_gap_base_query_cgr_keys", {}),
                result.rrseq_gap_occurrences,
            ),
        ):
            if kind == "cons" and strict_path_error is not None:
                continue
            aggregate = rrseq[kind]
            _merge_sequence_targets(aggregate, route_id, sequences)
            merge_query_cgr_key_records(aggregate["query_cgr_keys"], keys)
            merge_query_cgr_key_records(
                aggregate["base_query_cgr_keys"],
                base_keys,
            )
            aggregate["occurrences"].extend(occurrences)
            if sequences:
                aggregate["routes_with"] += 1
            else:
                _remember_route_without_rrseqs(
                    aggregate,
                    route_id=route_id,
                    route=route,
                    kind=kind,
                    preparation_stats=result.preparation_stats,
                    min_length=rrseq_min_length,
                    store_route=store_routes_without_rrseqs,
                )

        successful_single_rule_kinds = (
            ("gap",) if strict_path_error is not None else ("cons", "gap")
        )
        for kind in successful_single_rule_kinds:
            _merge_sequence_targets(single_rules[kind], route_id, result.single_rules)
            merge_query_cgr_key_records(
                single_rules[kind]["query_cgr_keys"],
                result.single_rule_query_cgr_keys,
            )
            merge_query_cgr_key_records(
                single_rules[kind]["base_query_cgr_keys"],
                getattr(result, "single_rule_base_query_cgr_keys", {}),
            )

        for kind, occurrences in (
            ("cons", result.rrsubtree_cons_occurrences),
            ("gap", result.rrsubtree_gap_occurrences),
        ):
            rrsubtree_occurrences[kind].extend(occurrences)
            rrsubtree_routes[kind].update(
                occurrence.route_id for occurrence in occurrences
            )
        rrsubtree_candidates["total"] += result.rrsubtree_candidate_count
        rrsubtree_candidates["cons"] += result.rrsubtree_cons_candidate_count
        rrsubtree_candidates["gap"] += result.rrsubtree_gap_candidate_count

        if progress_interval and routes_seen % progress_interval == 0:
            print(
                f"processed routes={routes_seen} completed={routes_completed} "
                f"errors={len(errors)}",
                flush=True,
            )

    if progress_interval and routes_seen % progress_interval:
        print(
            f"processed routes={routes_seen} completed={routes_completed} "
            f"errors={len(errors)}",
            flush=True,
        )

    child_dirs = {
        "rrseq_cons": output_dir / "rrseq_cons",
        "rrseq_gap": output_dir / "rrseq_gap",
        "rrsubtree_cons": output_dir / "rrsubtree_cons",
        "rrsubtree_gap": output_dir / "rrsubtree_gap",
    }
    common_stats = {
        **{
            key: value
            for key, value in preparation_totals.items()
            if key != "no_net_selected_change"
        },
        "routes_seen": routes_seen,
    }
    for kind in ("cons", "gap"):
        stats = RouteProcessingStats(
            **common_stats,
            routes_with_rrseqs=rrseq[kind]["routes_with"],
            errors=len(rrseq_errors[kind]),
            no_net_selected_change=(
                preparation_totals["no_net_selected_change"] if kind == "gap" else 0
            ),
        )
        _write_rrseq_kind(
            args,
            output_dir=child_dirs[f"rrseq_{kind}"],
            dataset_id=dataset_id,
            kind=kind,
            aggregate=rrseq[kind],
            single_rules=single_rules[kind],
            single_rule_occurrences=single_rule_occurrences,
            stats=stats,
            errors=rrseq_errors[kind],
            min_length=rrseq_min_length,
            max_length=rrseq_max_length,
            store_routes_without_rrseqs=store_routes_without_rrseqs,
        )

    for kind in ("cons", "gap"):
        write_rrsubtree_outputs(
            child_dirs[f"rrsubtree_{kind}"],
            dataset_id=dataset_id,
            kind=kind,
            occurrences=rrsubtree_occurrences[kind],
            routes_seen=routes_seen,
            errors=rrsubtree_errors,
            config_path=getattr(args, "config", None),
            input_path=routes_json,
            cli_args=args,
        )

    rrsubtree_eligibility.sort(key=lambda row: reference_sort_key(row["route_id"]))
    eligibility_path = output_dir / f"{dataset_id}_rrsubtree_eligibility.json"
    eligible_route_counts = {
        kind: sum(
            f"rrsubtree_{kind}_witness" in record for record in rrsubtree_eligibility
        )
        for kind in ("cons", "gap")
    }
    write_json(
        eligibility_path,
        {
            "schema_version": 1,
            "dataset": dataset_id,
            "rrseq_eligibility_length": 2,
            "eligible_routes_by_kind": eligible_route_counts,
            "routes": rrsubtree_eligibility,
        },
    )

    motif_kinds = {
        "rrseq_cons": {
            "analysis_only": False,
            "routes_with_motifs": rrseq["cons"]["routes_with"],
            "occurrences": len(rrseq["cons"]["occurrences"]),
            "unique_families": _rrseq_family_count(rrseq["cons"]),
        },
        "rrseq_gap": {
            "analysis_only": True,
            "routes_with_motifs": rrseq["gap"]["routes_with"],
            "occurrences": len(rrseq["gap"]["occurrences"]),
            "unique_families": _rrseq_family_count(rrseq["gap"]),
        },
        "rrsubtree_cons": {
            "analysis_only": True,
            "routes_with_motifs": len(rrsubtree_routes["cons"]),
            "occurrences": len(rrsubtree_occurrences["cons"]),
            "unique_families": len(
                {occurrence.family_key for occurrence in rrsubtree_occurrences["cons"]}
            ),
            "strict_routes_with_motifs": len(
                {
                    occurrence.route_id
                    for occurrence in rrsubtree_occurrences["cons"]
                    if occurrence.all_edges_rrseq_connected
                }
            ),
            "strict_occurrences": sum(
                occurrence.all_edges_rrseq_connected
                for occurrence in rrsubtree_occurrences["cons"]
            ),
            "candidates": rrsubtree_candidates["cons"],
        },
        "rrsubtree_gap": {
            "analysis_only": True,
            "routes_with_motifs": len(rrsubtree_routes["gap"]),
            "occurrences": len(rrsubtree_occurrences["gap"]),
            "unique_families": len(
                {occurrence.family_key for occurrence in rrsubtree_occurrences["gap"]}
            ),
            "strict_routes_with_motifs": len(
                {
                    occurrence.route_id
                    for occurrence in rrsubtree_occurrences["gap"]
                    if occurrence.all_edges_rrseq_connected
                }
            ),
            "strict_occurrences": sum(
                occurrence.all_edges_rrseq_connected
                for occurrence in rrsubtree_occurrences["gap"]
            ),
            "candidates": rrsubtree_candidates["gap"],
        },
    }
    context_reference_counts = {
        "t1": len(single_rule_occurrences) if context_history_path is not None else 0,
        "rrseq_cons": (
            len(rrseq["cons"]["occurrences"]) if context_history_path is not None else 0
        ),
        "rrseq_gap": (
            len(rrseq["gap"]["occurrences"]) if context_history_path is not None else 0
        ),
    }
    rrseq_error_count = len(
        {
            (
                str(error["route_id"]),
                error["stage"],
                error["error_type"],
                error["message"],
            )
            for kind_errors in rrseq_errors.values()
            for error in kind_errors
        }
    )
    summary = {
        "dataset": dataset_id,
        "routes_json": str(routes_json),
        "extraction_mode": "shared_route_pass_sequential",
        "routes_seen": routes_seen,
        "routes_completed": routes_completed,
        "rrseq_cons_routes_completed": rrseq_routes_completed["cons"],
        "rrseq_gap_routes_completed": rrseq_routes_completed["gap"],
        "rrsubtree_routes_completed": rrsubtree_routes_completed,
        **preparation_totals,
        "errors": len(errors),
        "rrseq_errors": rrseq_error_count,
        "rrseq_cons_errors": len(rrseq_errors["cons"]),
        "rrseq_gap_errors": len(rrseq_errors["gap"]),
        "rrsubtree_errors": len(rrsubtree_errors),
        "rrsubtree_candidates": rrsubtree_candidates,
        "rrsubtree_eligible_routes": eligible_route_counts,
        "rrsubtree_eligibility_file": str(eligibility_path),
        "context_history_file": (
            str(context_history_path) if context_history_path is not None else None
        ),
        "context_history_references": context_reference_counts,
        "limits": {
            "rrseq_min_length": rrseq_min_length,
            "rrseq_max_length": rrseq_max_length,
            "rrsubtree_min_size": rrsubtree_min_size,
            "rrsubtree_max_size": rrsubtree_max_size,
            "rrsubtree_max_candidates_per_route": rrsubtree_max_candidates,
            "route_limit": getattr(args, "limit", None),
        },
        "motif_kinds": motif_kinds,
        "output_subdirectories": {key: str(path) for key, path in child_dirs.items()},
    }
    write_standard_sidecars(
        output_dir,
        command_name="extract-route-motifs",
        summary=summary,
        errors=errors,
        error_fieldnames=RRSUBTREE_ERROR_FIELDS,
        input_files=[
            routes_json,
            *([context_history_path] if context_history_path is not None else []),
        ],
        output_files={
            **child_dirs,
            "rrsubtree_eligibility": eligibility_path,
        },
        config_path=getattr(args, "config", None),
        cli_args=args,
        extra_manifest={
            "dataset": dataset_id,
            "extraction_mode": "shared_route_pass_sequential",
            "analysis_only_by_kind": {
                key: value["analysis_only"] for key, value in motif_kinds.items()
            },
            "context_history_file": (
                str(context_history_path) if context_history_path is not None else None
            ),
            "context_history_references": context_reference_counts,
        },
    )
    print(json.dumps(summary, indent=2), flush=True)
    return 0


__all__ = ["run"]
