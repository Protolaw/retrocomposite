"""Command orchestration for authoritative route-wide context histories."""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import replace
from pathlib import Path
from typing import Any, Iterable

from route_inspector.context.enrichment import enrich_collection
from route_inspector.context.history import (
    CONTEXT_HISTORY_IDENTITY_VERSION,
    CONTEXT_HISTORY_SCHEMA_VERSION,
    DEFAULT_CONTEXT_POLICY,
    RouteContextHistory,
    annotate_routes_context_history,
    canonical_context_policy_sha256,
    context_history_summary,
    read_context_histories_jsonl,
    validate_route_context_history_integrity,
    write_context_histories_jsonl,
)
from route_inspector.context.occurrences import (
    OCCURRENCE_CONTEXT_REFERENCE_SCHEMA_VERSION,
    backfill_legacy_interval_occurrences,
    enrich_occurrence_records,
    occurrence_kind,
)
from route_inspector.context.protection_overlay import (
    ProtectionOverlayResult,
    _event_records,
    _history_coverage_errors,
    _limited_collection,
    _normalized_protection_events,
    _overlay_protection_events_with_policy,
    _protection_overlay_error_rows,
    _trace_protection_events,
    _write_context_failure_sidecars,
    _write_protection_events_jsonl,
    _write_protection_overlay_rejections,
)
from route_inspector.context.vocabulary import load_functional_group_vocabulary
from route_inspector.infrastructure.artifacts import (
    dataset_prefix_from_path,
    write_json,
    write_standard_sidecars,
)
from route_inspector.infrastructure.hashing import sha256_file as _sha256
from route_inspector.infrastructure.occurrences import iter_occurrence_mappings
from route_inspector.infrastructure.paths import relative_path, resolve_existing_path
from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
from route_inspector.infrastructure.text import read_json
from route_inspector.protection.analysis import (
    PROTECTION_TRACE_EVENT_SCHEMA_VERSION,
)
from route_inspector.routes.validation import (
    RouteMappingValidationError,
    validate_routes_mapping,
    write_route_mapping_validation,
)
from route_inspector.rules.occurrences import (
    SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
    SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION,
    write_single_rule_occurrences,
)
from route_inspector.tactics.rrseq.gapped import (
    RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION,
)
from route_inspector.tactics.rrseq.occurrences import (
    RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION,
    write_rrseq_cons_occurrences,
)
from route_inspector.workflows.requests import MigrateOccurrenceContextRequest

REFERENCE_SCOPE = "all_data"
_CONTEXT_POLICY = DEFAULT_CONTEXT_POLICY
PROTECTION_OVERLAY_REJECTION_SCHEMA_VERSION = 1
_CONTEXT_STAGE_ARTIFACT_NAMES = (
    "context_history.jsonl.gz",
    "enriched_routes.json",
    "errors.tsv",
    "manifest.json",
    "mapping_validation.tsv",
    "protection_overlay_rejections.jsonl",
    "protection_trace_events.jsonl",
    "summary.json",
)


def _run_annotate_context_history(args: Any) -> int:
    """Build one route history per strictly mapping-validated route."""

    setup_runtime_cache_dirs()
    routes_path = resolve_existing_path(args.routes_json)
    protection_path = (
        None
        if args.protection_events is None
        else resolve_existing_path(args.protection_events)
    )
    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    dataset_id = str(args.dataset_id or dataset_prefix_from_path(routes_path))
    source_identity = str(args.source_identity or routes_path.resolve())
    collection = _limited_collection(read_json(routes_path), args.limit)

    mapping_result = validate_routes_mapping(collection, dataset=dataset_id)
    mapping_path = output_dir / "mapping_validation.tsv"
    mapping_summary = write_route_mapping_validation(mapping_result, mapping_path)
    input_paths = [routes_path]
    if protection_path is not None:
        input_paths.append(protection_path)
    input_hashes = {relative_path(path): _sha256(path) for path in input_paths}
    config_hash = canonical_context_policy_sha256(_CONTEXT_POLICY)
    if mapping_result.records:
        summary = {
            "command_name": "annotate-context-history",
            "status": "failed_mapping_validation",
            "dataset_id": dataset_id,
            "source_identity": source_identity,
            "reference_scope": REFERENCE_SCOPE,
            "config_hash": config_hash,
            "mapping_validation": mapping_summary,
            "errors": len(mapping_result.records),
            "protection_trace_event_schema_version": (
                PROTECTION_TRACE_EVENT_SCHEMA_VERSION
            ),
            "protection_trace_events": 0,
            "protection_trace_events_seen": 0,
            "protection_trace_events_embedded": 0,
            "protection_trace_events_rejected": 0,
            "protection_overlay_policy": str(
                getattr(args, "protection_overlay_policy", "strict")
            ),
            "protection_overlay_rejection_schema_version": (
                PROTECTION_OVERLAY_REJECTION_SCHEMA_VERSION
            ),
            "protection_overlay_rejections_by_reason": {},
            "input_sha256": input_hashes,
            "output_files": {"mapping_validation": relative_path(mapping_path)},
        }
        write_standard_sidecars(
            output_dir,
            command_name="annotate-context-history",
            summary=summary,
            errors=mapping_result.records,
            input_files=input_paths,
            output_files={"mapping_validation": mapping_path},
            cli_args=args,
            extra_manifest={
                "reference_scope": REFERENCE_SCOPE,
                "config_hash": config_hash,
                "mapping_validation": mapping_summary,
                "protection_trace_event_schema_version": (
                    PROTECTION_TRACE_EVENT_SCHEMA_VERSION
                ),
                "protection_trace_events_seen": 0,
                "protection_trace_events_embedded": 0,
                "protection_trace_events_rejected": 0,
                "protection_overlay_policy": str(
                    getattr(args, "protection_overlay_policy", "strict")
                ),
                "protection_overlay_rejection_schema_version": (
                    PROTECTION_OVERLAY_REJECTION_SCHEMA_VERSION
                ),
                "protection_overlay_rejections_by_reason": {},
                "input_sha256": input_hashes,
            },
        )
        raise RouteMappingValidationError(
            f"routes failed strict mapping validation; see {mapping_path}"
        )

    vocabulary = None
    histories: tuple[RouteContextHistory, ...] = ()
    try:
        vocabulary = load_functional_group_vocabulary()
        annotation = annotate_routes_context_history(
            collection,
            dataset_id=dataset_id,
            source_identity=source_identity,
            vocabulary=vocabulary,
            validate_mapping=False,
            context_policy_sha256=config_hash,
        )
        histories = tuple(
            history
            if history.mapping_validated
            else replace(history, mapping_validated=True)
            for history in annotation.histories
        )
    except Exception as exc:
        failure = {
            "dataset_id": dataset_id,
            "route_id": "*",
            "stage": "context_history_annotation",
            "error_type": type(exc).__qualname__,
            "message": str(exc),
        }
        _write_context_failure_sidecars(
            output_dir=output_dir,
            status="failed_context_annotation",
            dataset_id=dataset_id,
            source_identity=source_identity,
            histories=histories,
            errors=(failure,),
            input_paths=input_paths,
            output_files={"mapping_validation": mapping_path},
            mapping_summary=mapping_summary,
            input_hashes=input_hashes,
            config_hash=config_hash,
            vocabulary=vocabulary,
            args=args,
        )
        raise

    coverage_errors = _history_coverage_errors(
        collection,
        histories,
        dataset_id=dataset_id,
    )
    annotation_failures = (*annotation.errors, *coverage_errors)
    if annotation_failures:
        partial_history_path = write_context_histories_jsonl(
            output_dir / "context_history.jsonl.gz",
            histories,
        )
        _write_context_failure_sidecars(
            output_dir=output_dir,
            status="failed_context_annotation",
            dataset_id=dataset_id,
            source_identity=source_identity,
            histories=histories,
            errors=annotation_failures,
            input_paths=input_paths,
            output_files={
                "context_history": partial_history_path,
                "mapping_validation": mapping_path,
            },
            mapping_summary=mapping_summary,
            input_hashes=input_hashes,
            config_hash=config_hash,
            vocabulary=vocabulary,
            args=args,
        )
        raise RuntimeError(
            "context history annotation did not cover every route; see "
            f"{output_dir / 'errors.tsv'}"
        )

    trace_event_path = output_dir / "protection_trace_events.jsonl"
    rejection_path = output_dir / "protection_overlay_rejections.jsonl"
    protection_events: tuple[dict[str, Any], ...] = ()
    overlay_result = ProtectionOverlayResult(
        histories=histories, accepted_events=(), rejections=()
    )
    overlay_policy = str(getattr(args, "protection_overlay_policy", "strict"))
    try:
        protection_events = (
            _normalized_protection_events(_event_records(protection_path))
            if protection_path is not None
            else _trace_protection_events(collection)
        )
        _write_protection_events_jsonl(trace_event_path, protection_events)
        overlay_result = _overlay_protection_events_with_policy(
            histories,
            protection_events,
            dataset_id=dataset_id,
            policy=overlay_policy,
        )
        histories = overlay_result.histories
        _write_protection_overlay_rejections(
            rejection_path,
            overlay_result.rejections,
        )
    except Exception as exc:
        details = dict(getattr(exc, "details", {}))
        failure = {
            "dataset_id": dataset_id,
            "route_id": str(details.get("route_id", "*")),
            "event_id": str(details.get("event_id", "")),
            "stage": "protection_context_annotation",
            "reason_code": str(getattr(exc, "reason_code", "")),
            "error_type": type(exc).__qualname__,
            "message": str(exc),
            "details_json": json.dumps(
                details,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=True,
            ),
        }
        retained_errors = (
            *annotation.errors,
            *(error for history in histories for error in history.errors),
        )
        failure_outputs = {"mapping_validation": mapping_path}
        if trace_event_path.is_file():
            failure_outputs["protection_trace_events"] = trace_event_path
        _write_context_failure_sidecars(
            output_dir=output_dir,
            status="failed_context_annotation",
            dataset_id=dataset_id,
            source_identity=source_identity,
            histories=histories,
            errors=(*retained_errors, failure),
            input_paths=input_paths,
            output_files=failure_outputs,
            mapping_summary=mapping_summary,
            input_hashes=input_hashes,
            config_hash=config_hash,
            vocabulary=vocabulary,
            args=args,
            protection_events_seen=len(protection_events),
        )
        raise
    history_path = write_context_histories_jsonl(
        output_dir / "context_history.jsonl.gz",
        histories,
    )
    output_files: dict[str, Path] = {
        "context_history": history_path,
        "mapping_validation": mapping_path,
        "protection_trace_events": trace_event_path,
        "protection_overlay_rejections": rejection_path,
    }
    history_by_route = {history.route_id: history for history in histories}
    if args.write_enriched_routes:
        enriched_path = output_dir / "enriched_routes.json"
        write_json(
            enriched_path,
            enrich_collection(collection, history_by_route),
        )
        output_files["enriched_routes"] = enriched_path

    overlay_errors = _protection_overlay_error_rows(overlay_result.rejections)
    errors = [
        *annotation.errors,
        *(error for history in histories for error in history.errors),
        *overlay_errors,
    ]
    rejection_counts = dict(
        sorted(
            Counter(
                rejection["reason_code"] for rejection in overlay_result.rejections
            ).items()
        )
    )
    status = (
        "completed_with_rejections"
        if overlay_result.rejections
        else ("completed_with_errors" if errors else "completed")
    )
    summary = {
        "command_name": "annotate-context-history",
        "status": status,
        "dataset_id": dataset_id,
        "source_identity": source_identity,
        "reference_scope": REFERENCE_SCOPE,
        **context_history_summary(histories),
        "mapping_validation": mapping_summary,
        "errors": len(errors),
        "protection_trace_events": len(overlay_result.accepted_events),
        "protection_trace_events_seen": len(protection_events),
        "protection_trace_events_embedded": len(overlay_result.accepted_events),
        "protection_trace_events_rejected": len(overlay_result.rejections),
        "protection_overlay_rejections_by_reason": rejection_counts,
        "protection_overlay_policy": overlay_policy,
        "protection_overlay_rejection_schema_version": (
            PROTECTION_OVERLAY_REJECTION_SCHEMA_VERSION
        ),
        "protection_trace_event_schema_version": (
            PROTECTION_TRACE_EVENT_SCHEMA_VERSION
        ),
        "vocabulary_version": vocabulary.version_id,
        "vocabulary_source_sha256": vocabulary.source_sha256,
        "vocabulary_manifest_sha256": vocabulary.manifest_sha256,
        "config_hash": config_hash,
        "context_history_schema_version": CONTEXT_HISTORY_SCHEMA_VERSION,
        "context_history_identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
        "input_sha256": input_hashes,
        "output_files": {
            key: relative_path(path) for key, path in sorted(output_files.items())
        },
    }
    sidecars = write_standard_sidecars(
        output_dir,
        command_name="annotate-context-history",
        summary=summary,
        errors=errors,
        input_files=input_paths,
        output_files=output_files,
        cli_args=args,
        extra_manifest={
            "reference_scope": REFERENCE_SCOPE,
            "config_hash": config_hash,
            "mapping_validation": mapping_summary,
            "context_history_schema_version": CONTEXT_HISTORY_SCHEMA_VERSION,
            "context_history_identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
            "protection_trace_event_schema_version": (
                PROTECTION_TRACE_EVENT_SCHEMA_VERSION
            ),
            "protection_overlay_policy": overlay_policy,
            "protection_overlay_rejection_schema_version": (
                PROTECTION_OVERLAY_REJECTION_SCHEMA_VERSION
            ),
            "protection_trace_events_seen": len(protection_events),
            "protection_trace_events_embedded": len(overlay_result.accepted_events),
            "protection_trace_events_rejected": len(overlay_result.rejections),
            "protection_overlay_rejections_by_reason": rejection_counts,
            "vocabulary_version": vocabulary.version_id,
            "vocabulary_source_sha256": vocabulary.source_sha256,
            "vocabulary_manifest_sha256": vocabulary.manifest_sha256,
            "input_sha256": input_hashes,
        },
    )
    summary["sidecar_files"] = sidecars
    write_json(output_dir / "summary.json", summary)
    print(json.dumps(summary, indent=2), flush=True)
    return 0


def _clear_context_stage_artifacts(
    output_dir: Path,
    *,
    preserve_paths: Iterable[Path] = (),
) -> None:
    """Remove only this command's stable artifacts, never resolved inputs."""

    preserved = {Path(path).resolve() for path in preserve_paths}
    for name in _CONTEXT_STAGE_ARTIFACT_NAMES:
        path = output_dir / name
        if path.resolve() in preserved:
            continue
        if path.is_file() or path.is_symlink():
            path.unlink()


def run_annotate_context_history(args: Any) -> int:
    """Run annotation and retain standard sidecars for preflight failures."""

    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    resolved_inputs = tuple(
        resolve_existing_path(value)
        for value in (
            getattr(args, "routes_json", None),
            getattr(args, "protection_events", None),
        )
        if value is not None
    )
    _clear_context_stage_artifacts(
        output_dir,
        preserve_paths=resolved_inputs,
    )
    try:
        return _run_annotate_context_history(args)
    except Exception as exc:
        standard_paths = tuple(
            output_dir / name
            for name in ("summary.json", "errors.tsv", "manifest.json")
        )
        # Inner validation stages write richer diagnostics. Never replace any
        # part of that sidecar set with a generic preflight record.
        if any(path.exists() for path in standard_paths):
            raise
        raw_inputs = tuple(
            Path(value).expanduser()
            for value in (
                getattr(args, "routes_json", None),
                getattr(args, "protection_events", None),
            )
            if value is not None and Path(value).expanduser().is_file()
        )
        routes_value = getattr(args, "routes_json", "")
        routes_path = (
            Path(routes_value).expanduser() if routes_value else Path("routes")
        )
        dataset_id = str(
            getattr(args, "dataset_id", None) or dataset_prefix_from_path(routes_path)
        )
        source_identity = str(
            getattr(args, "source_identity", None) or routes_path.resolve()
        )
        error = {
            "dataset_id": dataset_id,
            "route_id": "*",
            "stage": "preflight_inputs",
            "error_type": type(exc).__qualname__,
            "message": str(exc),
        }
        summary = {
            "command_name": "annotate-context-history",
            "status": "failed_preflight",
            "dataset_id": dataset_id,
            "source_identity": source_identity,
            "reference_scope": REFERENCE_SCOPE,
            "config_hash": canonical_context_policy_sha256(_CONTEXT_POLICY),
            "errors": 1,
            "protection_trace_events": 0,
            "protection_trace_events_seen": 0,
            "protection_trace_events_embedded": 0,
            "protection_trace_events_rejected": 0,
            "protection_overlay_policy": str(
                getattr(args, "protection_overlay_policy", "strict")
            ),
            "protection_overlay_rejection_schema_version": (
                PROTECTION_OVERLAY_REJECTION_SCHEMA_VERSION
            ),
            "protection_overlay_rejections_by_reason": {},
            "output_files": {},
        }
        write_standard_sidecars(
            output_dir,
            command_name="annotate-context-history",
            summary=summary,
            errors=(error,),
            input_files=raw_inputs,
            output_files={},
            cli_args=args,
            extra_manifest={
                "reference_scope": REFERENCE_SCOPE,
                "failure_stage": "preflight_inputs",
            },
        )
        raise


def run_migrate_occurrence_context(args: MigrateOccurrenceContextRequest) -> int:
    """Reconstruct authoritative t1 evidence and enrich historical exact sidecars."""

    from route_inspector.rules.extraction import SynPlannerRuleExtractor
    from route_inspector.rules.preparation import (
        reconstruct_single_rule_occurrences_from_clean_routes,
    )

    dataset_id = str(args.dataset_id or "").strip()
    if not dataset_id:
        raise ValueError("--dataset-id is required and must not be empty")
    routes_path = resolve_existing_path(Path(args.routes_json))
    history_path = resolve_existing_path(Path(args.context_history))
    occurrence_paths = tuple(
        resolve_existing_path(Path(path)) for path in args.historical_occurrences
    )
    source_identity = str(args.source_identity or routes_path.resolve())
    historical = [
        record for path in occurrence_paths for record in iter_occurrence_mappings(path)
    ]
    histories = read_context_histories_jsonl(history_path)
    routes_json = read_json(routes_path)
    from route_inspector.routes.access import route_by_id

    for history in histories:
        if (
            history.dataset_id == dataset_id
            and history.source_identity == source_identity
        ):
            validate_route_context_history_integrity(
                history,
                route_by_id(routes_json, history.route_id),
                expected_context_policy_sha256=history.context_policy_sha256,
            )

    historical_counts = {"t1": 0, "rrseq_cons": 0, "rrseq_gap": 0}
    for record in historical:
        historical_counts[occurrence_kind(record)] += 1

    # Reconstruct every exact clean-route t1 first. Legacy interval payloads may
    # then receive only fields that are uniquely determined by dataset/source/
    # route/reaction-node provenance before current schema stamping or history
    # projection occurs.
    rule_extractor = SynPlannerRuleExtractor.from_args(args)
    reconstructed, reconstruction_summary = (
        reconstruct_single_rule_occurrences_from_clean_routes(
            routes_json,
            rule_extractor,
            dataset_id=dataset_id,
            source_identity=source_identity,
            historical_occurrences=historical,
            source_id_adapter=str(
                getattr(args, "source_id_adapter", "paroutes-semicolon-v1")
            ),
        )
    )
    migrated_intervals, backfill_summary = backfill_legacy_interval_occurrences(
        historical,
        reconstructed,
        dataset_id=dataset_id,
        source_identity=source_identity,
    )
    enriched_historical, _migrated_counts = enrich_occurrence_records(
        migrated_intervals,
        histories,
        dataset_id=dataset_id,
        source_identity=source_identity,
    )
    enriched_t1, t1_counts = enrich_occurrence_records(
        reconstructed,
        histories,
        dataset_id=dataset_id,
        source_identity=source_identity,
    )
    enriched_cons = [
        record
        for record in enriched_historical
        if occurrence_kind(record) == "rrseq_cons"
    ]
    enriched_gap = [
        record
        for record in enriched_historical
        if occurrence_kind(record) == "rrseq_gap"
    ]

    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    t1_path = output_dir / "t1_single_rule_occurrences.json"
    cons_path = output_dir / "rrseq_cons_occurrences.json"
    gap_path = output_dir / "rrseq_gap_occurrences.json"
    write_single_rule_occurrences(t1_path, enriched_t1)
    write_rrseq_cons_occurrences(cons_path, enriched_cons)
    write_json(gap_path, enriched_gap)
    summary = {
        "dataset_id": dataset_id,
        "source_identity": source_identity,
        "routes_json": str(routes_path),
        "context_history": str(history_path),
        "historical_occurrence_files": [str(path) for path in occurrence_paths],
        "historical_occurrences": len(historical),
        "historical_occurrence_counts": historical_counts,
        "reconstructed_t1_occurrences": t1_counts["t1"],
        "rrseq_cons_occurrences": len(enriched_cons),
        "rrseq_gap_occurrences": len(enriched_gap),
        "occurrence_context_reference_schema_version": (
            OCCURRENCE_CONTEXT_REFERENCE_SCHEMA_VERSION
        ),
        "occurrence_payload_schema_versions": {
            "t1": SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION,
            "rrseq_cons": RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION,
            "rrseq_gap": RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION,
        },
        "occurrence_identity_versions": {
            "t1": SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
            "rrseq_cons": RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
            "rrseq_gap": RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION,
        },
        "reconstruction": reconstruction_summary,
        "legacy_backfill": backfill_summary,
    }
    sidecars = write_standard_sidecars(
        output_dir,
        command_name="migrate-occurrence-context",
        summary=summary,
        errors=(),
        input_files=[routes_path, history_path, *occurrence_paths],
        output_files={
            "t1_occurrences": t1_path,
            "rrseq_cons_occurrences": cons_path,
            "rrseq_gap_occurrences": gap_path,
        },
        config_path=args.config,
        cli_args=args,
        extra_manifest={
            "dataset_id": dataset_id,
            "source_identity": source_identity,
            "occurrence_context_reference_schema_version": (
                OCCURRENCE_CONTEXT_REFERENCE_SCHEMA_VERSION
            ),
        },
    )
    summary["sidecar_files"] = sidecars
    write_json(output_dir / "summary.json", summary)
    print(json.dumps(summary, indent=2), flush=True)
    return 0
