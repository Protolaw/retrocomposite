"""Corpus execution and publication for preprocessing."""

from __future__ import annotations

import json
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import route_inspector.routes.access as route_access
from route_inspector.datasets.paroutes.source_corrections import correct_source_route
from route_inspector.infrastructure.artifacts import (
    dataset_prefix_from_path,
    stage_output_dir,
    write_json,
    write_standard_sidecars,
)
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.runtime import (
    normalize_n_cpu,
    setup_runtime_cache_dirs,
)
from route_inspector.infrastructure.text import read_json
from route_inspector.protection.analysis import (
    ProtectionAnalysisConfig,
    ReactionRecord,
    RouteIndex,
    analyze_route_protection,
    detect_deprotections,
)
from route_inspector.protection.chython_rules import (
    ProtectionRule,
    load_chython_protection_rules,
)
from route_inspector.routes.diagnostics import audit_atom_provenance
from route_inspector.routes.preprocessing.canonicalization import (
    canonicalize_route_tree,
)
from route_inspector.routes.preprocessing.core import (
    SynPlannerGranularityExtractor,
    add_route_to_collection,
    empty_collection_like,
    process_route,
    route_id_sort_key,
)
from route_inspector.routes.reports import (
    atom_provenance_output_paths,
    write_atom_provenance_outputs,
)
from route_inspector.routes.validation import (
    RouteMappingValidationError,
    validate_routes_mapping,
    write_route_mapping_validation,
)
from route_inspector.tactics.rrseq.unwrap import unwrap_rule_sequence
from route_inspector.workflows.requests import PreprocessRoutesRequest

"""route_inspector.workflows.preprocessing"""


def preprocess_routes_json(
    routes_json: Any,
    *,
    extractor: Any,
    protection_rules: dict[str, ProtectionRule],
    protection_config: ProtectionAnalysisConfig,
    normalizer: Callable[[dict[str, Any]], dict[str, Any]] = canonicalize_route_tree,
    protection_detector: Callable[
        [
            RouteIndex,
            ReactionRecord,
            dict[str, ProtectionRule],
            ProtectionAnalysisConfig,
        ],
        list[Any],
    ] = detect_deprotections,
    protection_event_analyzer: Callable[
        ..., tuple[list[Any], list[Any], RouteIndex]
    ] = (analyze_route_protection),
    unwrapper: Callable[..., Any] = unwrap_rule_sequence,
    ignore_errors: bool = False,
    limit: int | None = None,
    progress_interval: int = 0,
    compact_reports: bool = False,
    cache_reset_interval: int = 0,
) -> tuple[Any, dict[str, dict[str, Any]], dict[str, dict[str, Any]], dict[str, Any]]:
    cleaned_routes = empty_collection_like(routes_json)
    resolved_routes: dict[str, dict[str, Any]] = {}
    unresolved_routes: dict[str, dict[str, Any]] = {}
    errors: list[dict[str, Any]] = []
    modified_route_ids: list[str] = []
    unresolved_route_ids: list[str] = []
    all_changes: list[dict[str, Any]] = []
    source_corrections: list[dict[str, Any]] = []
    retained_coupled_reactions: list[dict[str, Any]] = []
    retained_coupled_count = 0
    total_routes = 0
    normalized_routes = 0
    multicenter_reactions = 0
    protection_multicenter_reactions = 0
    split_reactions = 0
    protection_split_reactions = 0
    modified_count = 0
    unresolved_count = 0
    error_count = 0
    fused_totals = dict(detected=0, split=0, unresolved=0, generated_reactions=0)

    for index, (route_id, route) in enumerate(
        route_access.route_items(routes_json), start=1
    ):
        if limit is not None and index > limit:
            break
        # Preserve exact-record guards before chemistry, including --ignore-errors.
        route = correct_source_route(route)
        result = process_route(
            route_id,
            route,
            extractor=extractor,
            protection_rules=protection_rules,
            protection_config=protection_config,
            normalizer=normalizer,
            protection_detector=protection_detector,
            protection_event_analyzer=protection_event_analyzer,
            unwrapper=unwrapper,
            ignore_errors=ignore_errors,
        )
        for key in fused_totals:
            fused_totals[key] += (
                result.route.get("metadata", {})
                .get("fused_pg_preprocessing", {})
                .get(key, 0)
            )
        total_routes += 1
        normalized_routes += int(result.normalized)
        multicenter_reactions += result.multicenter_reactions
        protection_multicenter_reactions += result.protection_multicenter_reactions
        split_reactions += result.split_reactions
        protection_split_reactions += result.protection_split_reactions
        error_count += len(result.errors)
        if not compact_reports:
            errors.extend(result.errors)
        add_route_to_collection(cleaned_routes, route_id, result.route)
        retained = (
            result.route.get("metadata", {})
            .get("route_preprocessing", {})
            .get("retained_coupled_reactions", [])
        )
        retained_coupled_count += len(retained)
        if not compact_reports:
            retained_coupled_reactions.extend(
                {"route_id": str(route_id), **row} for row in retained
            )
            if retained and not result.unresolved_reactions:
                resolved_routes[str(route_id)] = result.route
        for correction in result.route.get("metadata", {}).get(
            "source_corrections", []
        ):
            source_corrections.append(
                {
                    "route_id": str(route_id),
                    "correction_id": correction["correction_id"],
                    "source_record_id": correction["source_record_id"],
                    "removed_reaction_count": correction["removed_reaction_count"],
                }
            )

        route_id_text = str(route_id)
        if result.modified:
            modified_count += 1
            if not compact_reports:
                modified_route_ids.append(route_id_text)
                resolved_routes[route_id_text] = result.route
                all_changes.extend(
                    {"route_id": route_id_text, **change} for change in result.changes
                )
        if result.unresolved_reactions:
            unresolved_count += 1
            if not compact_reports:
                unresolved_route_ids.append(route_id_text)
                unresolved_routes[route_id_text] = result.route

        if cache_reset_interval and total_routes % cache_reset_interval == 0:
            cache = getattr(extractor, "cache", None)
            if isinstance(cache, dict):
                cache.clear()

        if progress_interval and total_routes % progress_interval == 0:
            print(
                "[preprocess-routes] processed "
                f"{total_routes} routes; modified={modified_count}; "
                f"unresolved={unresolved_count}; errors={error_count}",
                file=sys.stderr,
                flush=True,
            )

    summary = {
        "fused_pg_decomposition": fused_totals,
        "total_routes_processed": total_routes,
        "number_of_normalized_routes": normalized_routes,
        "number_of_routes_modified": modified_count,
        "number_of_multicenter_reactions_found": multicenter_reactions,
        "number_of_multicenter_reactions_split": split_reactions,
        "number_of_protection_related_multicenter_reactions_split": (
            protection_split_reactions
        ),
        "number_of_non_protection_multicenter_reactions_split": (
            split_reactions - protection_split_reactions
        ),
        "number_of_protection_related_multicenter_reactions_found": (
            protection_multicenter_reactions
        ),
        "number_of_unresolved_multicenter_routes": unresolved_count,
        "route_ids_for_modified_routes": sorted(
            modified_route_ids,
            key=route_id_sort_key,
        ),
        "route_ids_for_unresolved_routes": sorted(
            unresolved_route_ids,
            key=route_id_sort_key,
        ),
        "changes": all_changes,
        "errors": errors,
        "number_of_errors": error_count,
        "number_of_source_corrected_routes": len(
            {row["route_id"] for row in source_corrections}
        ),
        "source_corrections": source_corrections,
        "number_of_coupled_multicenter_reactions_retained": retained_coupled_count,
        "retained_coupled_reactions": retained_coupled_reactions,
    }
    return cleaned_routes, resolved_routes, unresolved_routes, summary


"""PaRoutes corpus preparation and publication using typed inputs."""


def dataset_output_paths(
    output_dir: Path,
    dataset_name: str,
    *,
    sidecar_dir: Path | None = None,
) -> dict[str, Path]:
    output_path = output_dir / dataset_name
    report_dir = sidecar_dir or output_dir
    stem = output_path.stem
    dataset = dataset_prefix_from_path(dataset_name)
    return {
        "cleaned": output_path,
        "resolved": report_dir / f"{stem}_multicenter_resolved.json",
        "unresolved": report_dir / f"{stem}_multicenter_unresolved.json",
        "summary": report_dir / "summary.json",
        "route_mapping_validation": (
            report_dir / f"{dataset}_route_mapping_validation.tsv"
        ),
        **atom_provenance_output_paths(report_dir, dataset),
    }


def resolve_dataset_path(input_dir: Path, dataset: str | Path) -> Path:
    dataset_path = Path(dataset)
    candidates = []
    if dataset_path.is_absolute():
        candidates.append(dataset_path)
    else:
        candidates.append(input_dir / dataset_path)
        name = dataset_path.name
        candidates.append(input_dir / name.replace("_", "-"))
        candidates.append(input_dir / name.replace("-", "_"))

    for candidate in candidates:
        resolved = resolve_existing_path(candidate)
        if resolved.exists():
            return resolved
    return candidates[0]


def preprocess_routes_file(
    input_path: Path,
    output_paths: dict[str, Path],
    *,
    extractor: Any,
    protection_rules: dict[str, ProtectionRule],
    protection_config: ProtectionAnalysisConfig,
    ignore_errors: bool,
    limit: int | None = None,
    progress_interval: int = 0,
    compact_reports: bool = False,
    cache_reset_interval: int = 0,
    normalizer: Callable[[dict[str, Any]], dict[str, Any]] = canonicalize_route_tree,
    protection_detector: Callable[
        [
            RouteIndex,
            ReactionRecord,
            dict[str, ProtectionRule],
            ProtectionAnalysisConfig,
        ],
        list[Any],
    ] = detect_deprotections,
    protection_event_analyzer: Callable[
        ..., tuple[list[Any], list[Any], RouteIndex]
    ] = (analyze_route_protection),
    unwrapper: Callable[..., Any] = unwrap_rule_sequence,
) -> dict[str, Any]:
    routes_json = read_json(input_path)
    dataset = dataset_prefix_from_path(input_path)
    audit_result = audit_atom_provenance(
        routes_json,
        dataset=dataset,
        limit=limit,
    )
    cleaned, resolved, unresolved, summary = preprocess_routes_json(
        routes_json,
        extractor=extractor,
        protection_rules=protection_rules,
        protection_config=protection_config,
        ignore_errors=ignore_errors,
        limit=limit,
        progress_interval=progress_interval,
        compact_reports=compact_reports,
        cache_reset_interval=cache_reset_interval,
        normalizer=normalizer,
        protection_detector=protection_detector,
        protection_event_analyzer=protection_event_analyzer,
        unwrapper=unwrapper,
    )
    summary = {
        "input_file": str(input_path),
        "output_files": {name: str(path) for name, path in output_paths.items()},
        **summary,
    }

    audit_paths = atom_provenance_output_paths(
        output_paths["summary"].parent,
        dataset,
    )
    mapping_result = validate_routes_mapping(
        cleaned,
        dataset=dataset,
    )
    summary["route_mapping_validation"] = write_route_mapping_validation(
        mapping_result,
        output_paths["route_mapping_validation"],
    )
    summary["atom_provenance_audit"] = write_atom_provenance_outputs(
        audit_result,
        audit_paths,
        input_file=input_path,
    )
    write_json(output_paths["cleaned"], cleaned)
    write_json(output_paths["resolved"], resolved)
    write_json(output_paths["unresolved"], unresolved)
    write_json(output_paths["summary"], summary)
    if mapping_result.records and not ignore_errors:
        raise RouteMappingValidationError(
            "strict preprocessing mapping validation failed for "
            f"{summary['route_mapping_validation']['routes_failed']} routes; "
            f"see {output_paths['route_mapping_validation']}"
        )
    return summary


def preprocess_datasets(args: PreprocessRoutesRequest) -> dict[str, Any]:
    setup_runtime_cache_dirs()
    input_dir = resolve_existing_path(args.input_dir)
    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    summary_root = (
        Path(args.summary_dir).expanduser()
        if getattr(args, "summary_dir", None)
        else None
    )
    protection_config_path = (
        resolve_existing_path(args.protection_config)
        if getattr(args, "protection_config", None)
        else None
    )
    protection_config = ProtectionAnalysisConfig.from_yaml(protection_config_path)
    protection_config.collect_interval_rules = False
    if getattr(args, "ignore_errors", False):
        protection_config.ignore_errors = True
    extractor = SynPlannerGranularityExtractor.from_args(args)
    protection_rules = load_chython_protection_rules()

    dataset_summaries = {}
    for dataset in args.datasets:
        input_path = resolve_dataset_path(input_dir, dataset)
        stage_dir = (
            stage_output_dir(
                summary_root,
                dataset_prefix_from_path(dataset),
                "preprocess",
            )
            if summary_root is not None
            else None
        )
        output_paths = dataset_output_paths(
            output_dir,
            Path(dataset).name,
            sidecar_dir=stage_dir,
        )
        print(
            f"[preprocess-routes] processing {input_path} -> {output_paths['cleaned']}",
            file=sys.stderr,
            flush=True,
        )
        dataset_summary = preprocess_routes_file(
            input_path,
            output_paths,
            extractor=extractor,
            protection_rules=protection_rules,
            protection_config=protection_config,
            ignore_errors=getattr(args, "ignore_errors", False),
            limit=getattr(args, "limit", None),
            progress_interval=getattr(args, "progress_interval", 0),
            compact_reports=getattr(args, "compact_reports", False),
            cache_reset_interval=getattr(args, "cache_reset_interval", 0),
        )
        write_standard_sidecars(
            output_paths["summary"].parent,
            command_name="preprocess-routes",
            summary=dataset_summary,
            errors=dataset_summary.get("errors", []),
            input_files=[input_path],
            output_files=dataset_summary["output_files"],
            config_path=getattr(args, "config", None),
            cli_args=args,
        )
        dataset_summaries[Path(dataset).name] = dataset_summary

    aggregate = {
        "datasets": dataset_summaries,
        "fused_pg_decomposition": {
            key: sum(
                s["fused_pg_decomposition"][key] for s in dataset_summaries.values()
            )
            for key in ("detected", "split", "unresolved", "generated_reactions")
        },
        "total_routes_processed": sum(
            summary["total_routes_processed"] for summary in dataset_summaries.values()
        ),
        "number_of_normalized_routes": sum(
            summary["number_of_normalized_routes"]
            for summary in dataset_summaries.values()
        ),
        "number_of_routes_modified": sum(
            summary["number_of_routes_modified"]
            for summary in dataset_summaries.values()
        ),
        "number_of_source_corrected_routes": sum(
            summary.get("number_of_source_corrected_routes", 0)
            for summary in dataset_summaries.values()
        ),
        "number_of_multicenter_reactions_found": sum(
            summary["number_of_multicenter_reactions_found"]
            for summary in dataset_summaries.values()
        ),
        "number_of_multicenter_reactions_split": sum(
            summary["number_of_multicenter_reactions_split"]
            for summary in dataset_summaries.values()
        ),
        "number_of_coupled_multicenter_reactions_retained": sum(
            summary["number_of_coupled_multicenter_reactions_retained"]
            for summary in dataset_summaries.values()
        ),
        "number_of_protection_related_multicenter_reactions_split": sum(
            summary["number_of_protection_related_multicenter_reactions_split"]
            for summary in dataset_summaries.values()
        ),
        "number_of_non_protection_multicenter_reactions_split": sum(
            summary["number_of_non_protection_multicenter_reactions_split"]
            for summary in dataset_summaries.values()
        ),
        "number_of_unresolved_multicenter_routes": sum(
            summary["number_of_unresolved_multicenter_routes"]
            for summary in dataset_summaries.values()
        ),
        "number_of_errors": sum(
            summary["number_of_errors"] for summary in dataset_summaries.values()
        ),
        "number_of_atom_provenance_events": sum(
            summary["atom_provenance_audit"][
                "reactions_with_product_only_non_hydrogen_atoms_without_input"
            ]
            for summary in dataset_summaries.values()
        ),
        "number_of_atom_provenance_parse_errors": sum(
            summary["atom_provenance_audit"]["parse_errors"]
            for summary in dataset_summaries.values()
        ),
        "number_of_routes_passing_mapping_validation": sum(
            summary["route_mapping_validation"]["routes_passed"]
            for summary in dataset_summaries.values()
        ),
        "number_of_routes_failing_mapping_validation": sum(
            summary["route_mapping_validation"]["routes_failed"]
            for summary in dataset_summaries.values()
        ),
        "number_of_mapping_validation_failures": sum(
            summary["route_mapping_validation"]["validation_failures"]
            for summary in dataset_summaries.values()
        ),
    }
    aggregate_path = (summary_root or output_dir) / "summary.json"
    aggregate["summary_file"] = str(aggregate_path)
    write_json(aggregate_path, aggregate)
    return aggregate


def run(args: PreprocessRoutesRequest) -> int:
    if normalize_n_cpu(getattr(args, "n_cpu", 1)) != 1:
        print(
            "[preprocess-routes] --n-cpu is accepted for CLI consistency, "
            "but preprocessing currently runs sequentially.",
            file=sys.stderr,
            flush=True,
        )
    summary = preprocess_datasets(args)
    print(json.dumps(summary, indent=2), flush=True)
    return 0


@dataclass(frozen=True)
class PreprocessingResult:
    summary: dict[str, Any]
    output_path: Path


def preprocess(request: PreprocessRoutesRequest) -> PreprocessingResult:
    """Prepare configured corpora and return their published summary."""
    summary = preprocess_datasets(request)
    return PreprocessingResult(summary, Path(summary["summary_file"]))


__all__ = [
    "PreprocessRoutesRequest",
    "PreprocessingResult",
    "preprocess",
    "preprocess_routes_json",
]
