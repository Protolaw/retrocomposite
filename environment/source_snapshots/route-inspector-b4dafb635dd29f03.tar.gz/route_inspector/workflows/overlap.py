"""Verified overlap preparation shared by publication and interactive workers."""

from __future__ import annotations

from concurrent.futures import CancelledError
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from route_inspector.composite_rules.overlap import DEFAULT_OVERLAP_CACHE_ROOT
from route_inspector.infrastructure.hashing import sha256_file


@dataclass(frozen=True, kw_only=True)
class OverlapRequest:
    source: Path
    cache_root: Path = DEFAULT_OVERLAP_CACHE_ROOT
    destination: Path | None = None
    expected_identity: Mapping[str, Any] | None = None


@dataclass(frozen=True)
class OverlapResult:
    directory: Path
    summary: Mapping[str, Any]


def prepare_overlap(
    request: OverlapRequest,
    library,
    composites,
    *,
    progress: Callable[[str, str], None] | None = None,
    cancelled: Callable[[], bool] | None = None,
) -> OverlapResult:
    from route_inspector.composite_rules.overlap import (
        build_overlap,
        cache_identity,
        prepare_overlap_cache,
    )

    def check_cancelled():
        if cancelled is not None and cancelled():
            raise CancelledError("Overlap preparation cancelled")

    def report(state, message):
        check_cancelled()
        if progress is not None:
            progress(state, message)

    check_cancelled()
    if request.expected_identity is not None:
        identity = cache_identity(library, composites, sha256_file(request.source))
        if identity != request.expected_identity:
            raise ValueError("Overlap inputs changed before preparation")
    if request.destination is None:
        directory, summary = prepare_overlap_cache(
            request.source,
            library,
            composites,
            cache_root=request.cache_root,
            progress=report,
        )
    else:
        directory = request.destination
        summary = build_overlap(
            request.source,
            library,
            composites,
            directory,
            progress=report,
        )
    return OverlapResult(Path(directory), summary)


__all__ = ["OverlapRequest", "OverlapResult", "prepare_overlap"]
