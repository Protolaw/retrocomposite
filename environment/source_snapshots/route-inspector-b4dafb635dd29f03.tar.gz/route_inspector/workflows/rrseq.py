"""Corpus-level streaming, multiprocessing, aggregation, and output orchestration."""

from __future__ import annotations

import json
import traceback
from collections import defaultdict
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from pathlib import Path
from typing import Any, Iterable

from route_inspector.datasets.paroutes.source_ids import PAROUTES_SOURCE_ID_ADAPTER
from route_inspector.infrastructure.artifacts import (
    dataset_prefix_from_path,
    write_json,
    write_standard_sidecars,
)
from route_inspector.infrastructure.paths import (
    resolve_existing_path,
    resolve_output_path,
)
from route_inspector.infrastructure.runtime import (
    normalize_n_cpu,
    setup_runtime_cache_dirs,
)
from route_inspector.routes import normalization as routes
from route_inspector.routes.io import (
    filtered_route_items_from_json_file,
    iter_route_items_from_json_file,
)
from route_inspector.rules.config import (
    rule_extractor_args_dict,
)
from route_inspector.rules.extraction import (
    PrecomputedRuleExtractor,
    SerializedReactionRuleStep,
    SynPlannerRuleExtractor,
    serialize_reaction_rule_step,
)
from route_inspector.rules.models import (
    RouteProcessingStats,
)
from route_inspector.rules.occurrences import (
    SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
    SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION,
    single_rule_occurrence_sidecar_path,
    write_single_rule_occurrences,
)
from route_inspector.rules.preparation import (
    collect_reaction_contexts,
)
from route_inspector.tactics.rrseq.execution import (
    _RRSEQ_MULTIPROCESSING_CONTEXT,
    _init_precomputed_rrseq_worker,
    _init_rrseq_worker,
    _rrseq_route_chunk_worker,
    _unique_reaction_worker,
)
from route_inspector.tactics.rrseq.gapped import (
    RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION,
)
from route_inspector.tactics.rrseq.identities import (
    merge_rrseq_sequences_by_querycgr,
    merge_single_rules_by_querycgr,
    raw_identity_evidence_by_representative,
)
from route_inspector.tactics.rrseq.naming import (
    RRSEQ_CONS_KIND,
    RRSEQ_GAP_KIND,
    normalize_rrseq_kind,
)
from route_inspector.tactics.rrseq.occurrences import (
    RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION,
    rrseq_cons_occurrence_sidecar_path,
    write_rrseq_cons_occurrences,
)
from route_inspector.tactics.rrseq.processing import (
    merge_query_cgr_key_records,
    merge_route_processing_stats,
    process_route_for_rrseqs,
)
from route_inspector.tactics.rrseq.writers import write_rrseq_errors as write_errors
from route_inspector.tactics.rrseq.writers import (
    write_rrseq_routes_without_rules,
    write_rrseqs,
)
from route_inspector.tactics.rrseq.writers import write_rrseq_summary as write_summary
from route_inspector.workflows.requests import (
    ExtractRrseqConsRequest,
    ExtractRrseqGapRequest,
)


def chunked_route_items(
    items: Iterable[tuple[Any, dict[str, Any]]],
    chunk_size: int,
) -> Iterable[list[tuple[Any, dict[str, Any]]]]:
    """Yield route items in chunks suitable for worker processes.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    chunk: list[tuple[Any, dict[str, Any]]] = []
    for item in items:
        chunk.append(item)
        if len(chunk) >= chunk_size:
            yield chunk
            chunk = []
    if chunk:
        yield chunk


def route_result_chunks_from_pool(
    executor: ProcessPoolExecutor,
    route_items_iter: Iterable[tuple[Any, dict[str, Any]]],
    *,
    worker_chunksize: int,
    max_pending_chunks: int,
) -> Iterable[list[dict[str, Any]]]:
    """Return route result chunks from pool from a normalized route tree.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    chunks = iter(chunked_route_items(route_items_iter, worker_chunksize))
    pending = set()

    def submit_until_full() -> None:
        """Submit route-processing jobs until the worker queue reaches capacity.

        The helper feeds rule extraction, center-overlap filtering, or final TSV
        aggregation without changing the original route JSON in place.
        """
        while len(pending) < max_pending_chunks:
            try:
                chunk = next(chunks)
            except StopIteration:
                return
            pending.add(executor.submit(_rrseq_route_chunk_worker, chunk))

    submit_until_full()
    while pending:
        done, pending_remaining = wait(pending, return_when=FIRST_COMPLETED)
        pending = pending_remaining
        for future in done:
            yield future.result()
        submit_until_full()


def collect_unique_normalized_reactions(
    args: ExtractRrseqConsRequest | ExtractRrseqGapRequest,
    *,
    stats: RouteProcessingStats,
    errors: list[dict[str, Any]],
) -> tuple[set[str], set[Any]]:
    """Collect unique normalized reactions from route-analysis input data.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    unique_reactions: set[str] = set()
    failed_route_ids: set[Any] = set()

    for index, (route_id, route) in enumerate(
        iter_route_items_from_json_file(args.routes_json, args.limit),
        start=1,
    ):
        try:
            normalized_route = routes.normalized_route_for_analysis(route)
            for reaction_smiles, _target_smiles in collect_reaction_contexts(
                normalized_route
            ):
                unique_reactions.add(reaction_smiles)
        except Exception as exc:
            failed_route_ids.add(route_id)
            stats.routes_seen += 1
            stats.errors += 1
            error = {
                "route_id": route_id,
                "stage": "collect_unique_reactions",
                "error_type": type(exc).__qualname__,
                "message": str(exc) or traceback.format_exc(limit=1).strip(),
            }
            if not args.ignore_errors:
                raise RuntimeError(
                    f"route {route_id} failed during collect_unique_reactions: "
                    f"{error['error_type']}: {error['message']}"
                ) from exc
            errors.append(error)

        if args.progress_interval and index % args.progress_interval == 0:
            print(
                f"scanned routes={index} unique_reactions={len(unique_reactions)} "
                f"errors={stats.errors}",
                flush=True,
            )

    if args.progress_interval and (stats.routes_seen + len(unique_reactions)) == 0:
        print("scanned routes=0 unique_reactions=0 errors=0", flush=True)

    return unique_reactions, failed_route_ids


def extract_unique_reaction_rules(
    reaction_smiles_values: Iterable[str],
    args: ExtractRrseqConsRequest | ExtractRrseqGapRequest,
    *,
    n_cpu: int,
    worker_chunksize: int,
) -> tuple[
    dict[str, SerializedReactionRuleStep | None],
    dict[str, dict[str, str]],
    dict[str, int],
]:
    """Extract unique reaction rules from mapped route data.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    reaction_smiles_list = sorted(reaction_smiles_values)
    serialized_steps_by_reaction: dict[str, SerializedReactionRuleStep | None] = {}
    errors_by_reaction: dict[str, dict[str, str]] = {}
    stats = {
        "unique_reactions_seen": len(reaction_smiles_list),
        "unique_reaction_rules_extracted": 0,
        "unique_reaction_rules_skipped": 0,
        "unique_reaction_rule_errors": 0,
    }

    def consume_result(result: dict[str, Any], index: int) -> None:
        """Merge one worker result into the aggregate state.

        The helper feeds rule extraction, center-overlap filtering, or final TSV
        aggregation without changing the original route JSON in place.
        """
        reaction_smiles = result["reaction_smiles"]
        error = result.get("error")
        if error:
            stats["unique_reaction_rule_errors"] += 1
            errors_by_reaction[reaction_smiles] = error
            if not args.ignore_errors:
                raise RuntimeError(
                    "unique reaction rule extraction failed: "
                    f"{error['error_type']}: {error['message']}"
                )
        else:
            serialized_steps_by_reaction[reaction_smiles] = result["step"]
            if result["skipped"]:
                stats["unique_reaction_rules_skipped"] += 1
            else:
                stats["unique_reaction_rules_extracted"] += 1

        if args.progress_interval and index % args.progress_interval == 0:
            print(
                f"extracted unique reactions={index}/{len(reaction_smiles_list)} "
                f"rules={stats['unique_reaction_rules_extracted']} "
                f"skipped={stats['unique_reaction_rules_skipped']} "
                f"errors={stats['unique_reaction_rule_errors']}",
                flush=True,
            )

    if n_cpu > 1 and reaction_smiles_list:
        with ProcessPoolExecutor(
            max_workers=n_cpu,
            mp_context=_RRSEQ_MULTIPROCESSING_CONTEXT,
            initializer=_init_rrseq_worker,
            initargs=(
                rule_extractor_args_dict(args),
                args.min_length,
                args.max_length,
                False,
                RRSEQ_CONS_KIND,
            ),
        ) as executor:
            for index, result in enumerate(
                executor.map(
                    _unique_reaction_worker,
                    reaction_smiles_list,
                    chunksize=worker_chunksize,
                ),
                start=1,
            ):
                consume_result(result, index)
    else:
        rule_extractor = SynPlannerRuleExtractor.from_args(args)
        for index, reaction_smiles in enumerate(reaction_smiles_list, start=1):
            try:
                step, _cache_hit = rule_extractor.extract(reaction_smiles)
                result = {
                    "reaction_smiles": reaction_smiles,
                    "step": (
                        serialize_reaction_rule_step(step) if step is not None else None
                    ),
                    "skipped": step is None,
                    "error": None,
                }
            except Exception as exc:
                result = {
                    "reaction_smiles": reaction_smiles,
                    "step": None,
                    "skipped": False,
                    "error": {
                        "error_type": type(exc).__qualname__,
                        "message": str(exc) or traceback.format_exc(limit=1).strip(),
                    },
                }
            consume_result(result, index)

    return serialized_steps_by_reaction, errors_by_reaction, stats


def consume_rrseq_route_result(
    result: dict[str, Any],
    index: int,
    *,
    args: ExtractRrseqConsRequest | ExtractRrseqGapRequest,
    stats: RouteProcessingStats,
    references_by_sequence: dict[tuple[str, ...], set[Any]],
    target_molecules_by_sequence: dict[tuple[str, ...], dict[Any, set[str]]],
    query_cgr_keys_by_sequence: dict[tuple[str, ...], tuple[str, ...]],
    base_query_cgr_keys_by_sequence: dict[tuple[str, ...], tuple[str, ...]],
    references_by_single_rule: dict[tuple[str, ...], set[Any]],
    target_molecules_by_single_rule: dict[tuple[str, ...], dict[Any, set[str]]],
    query_cgr_keys_by_single_rule: dict[tuple[str, ...], tuple[str, ...]],
    base_query_cgr_keys_by_single_rule: dict[tuple[str, ...], tuple[str, ...]],
    errors: list[dict[str, Any]],
    routes_without_rrseqs: dict[Any, dict[str, Any]],
    routes_without_rrseqs_by_reason: dict[str, int],
    rrseq_gap_occurrences: list[dict[str, Any]] | None = None,
    rrseq_cons_occurrences: list[dict[str, Any]] | None = None,
    single_rule_occurrences: list[dict[str, Any]] | None = None,
) -> None:
    """Explain the consume rrseq route result helper used by route analysis.

    The result preserves reaction order and the shared-center constraint used to decide
    whether adjacent route steps form a valid rrseq rule.
    """
    merge_route_processing_stats(stats, result["stats"])
    error = result.get("error")
    if error:
        if not args.ignore_errors:
            raise RuntimeError(
                f"route {error['route_id']} failed during {error['stage']}: "
                f"{error['error_type']}: {error['message']}"
            )
        errors.append(error)
        return

    route_id = result["route_id"]
    if rrseq_gap_occurrences is not None:
        rrseq_gap_occurrences.extend(result.get("rrseq_gap_occurrences", []))
    if rrseq_cons_occurrences is not None:
        rrseq_cons_occurrences.extend(result.get("rrseq_cons_occurrences", []))
    if single_rule_occurrences is not None:
        single_rule_occurrences.extend(result.get("single_rule_occurrences", []))
    route_sequences = result["route_sequences"]
    single_rules = result.get("single_rules", {})
    merge_query_cgr_key_records(
        query_cgr_keys_by_sequence,
        result.get("route_sequence_query_cgr_keys", {}),
    )
    merge_query_cgr_key_records(
        query_cgr_keys_by_single_rule,
        result.get("single_rule_query_cgr_keys", {}),
    )
    merge_query_cgr_key_records(
        base_query_cgr_keys_by_sequence,
        result.get("route_sequence_base_query_cgr_keys", {}),
    )
    merge_query_cgr_key_records(
        base_query_cgr_keys_by_single_rule,
        result.get("single_rule_base_query_cgr_keys", {}),
    )
    if result["no_rrseq_reason"]:
        reason = result["no_rrseq_reason"]
        routes_without_rrseqs_by_reason[reason] += 1
    if result["route_without_rrseqs"] is not None:
        routes_without_rrseqs[route_id] = result["route_without_rrseqs"]

    for sequence, target_molecules in single_rules.items():
        references_by_single_rule[sequence].add(route_id)
        target_molecules_by_single_rule[sequence][route_id].update(target_molecules)

    for sequence, target_molecules in route_sequences.items():
        references_by_sequence[sequence].add(route_id)
        target_molecules_by_sequence[sequence][route_id].update(target_molecules)

    if args.progress_interval and index % args.progress_interval == 0:
        print(
            f"processed routes={index} rrseqs={len(references_by_sequence)} "
            f"routes_without_rrseqs={sum(routes_without_rrseqs_by_reason.values())} "
            f"errors={stats.errors}",
            flush=True,
        )


def write_rrseq_extraction_outputs(
    args: ExtractRrseqConsRequest | ExtractRrseqGapRequest,
    *,
    stats: RouteProcessingStats,
    references_by_sequence: dict[tuple[str, ...], set[Any]],
    target_molecules_by_sequence: dict[tuple[str, ...], dict[Any, set[str]]],
    query_cgr_keys_by_sequence: dict[tuple[str, ...], tuple[str, ...]],
    base_query_cgr_keys_by_sequence: dict[tuple[str, ...], tuple[str, ...]],
    references_by_single_rule: dict[tuple[str, ...], set[Any]],
    target_molecules_by_single_rule: dict[tuple[str, ...], dict[Any, set[str]]],
    query_cgr_keys_by_single_rule: dict[tuple[str, ...], tuple[str, ...]],
    base_query_cgr_keys_by_single_rule: dict[tuple[str, ...], tuple[str, ...]],
    errors: list[dict[str, Any]],
    routes_without_rrseqs: dict[Any, dict[str, Any]],
    routes_without_rrseqs_by_reason: dict[str, int],
    n_cpu: int,
    worker_chunksize: int,
    max_pending_chunks: int,
    store_routes_without_rrseqs: bool,
    sequence_mode: str,
    extraction_mode: str,
    extra_summary: dict[str, Any] | None = None,
    rrseq_gap_occurrences: list[dict[str, Any]] | None = None,
    rrseq_cons_occurrences: list[dict[str, Any]] | None = None,
    single_rule_occurrences: list[dict[str, Any]] | None = None,
    sidecar_command_name: str | None = None,
) -> int:
    """Write rrseq extraction outputs to disk.

    The result preserves reaction order and the shared-center constraint used to decide
    whether adjacent route steps form a valid rrseq rule.
    """
    sequence_mode = normalize_rrseq_kind(sequence_mode)
    is_gap = sequence_mode == RRSEQ_GAP_KIND
    artifact_key = "rrseq_gap" if is_gap else "rrseq_cons"
    context_history_path = getattr(args, "context_history", None)
    context_reference_counts = {"t1": 0, "rrseq_cons": 0, "rrseq_gap": 0}
    if context_history_path is not None:
        from route_inspector.context import read_context_histories_jsonl
        from route_inspector.context.occurrences import (
            enrich_occurrence_records,
            occurrence_kind,
        )

        resolved_context_history_path = resolve_existing_path(context_history_path)
        histories = read_context_histories_jsonl(resolved_context_history_path)
        source_records = [
            *(single_rule_occurrences or ()),
            *((rrseq_gap_occurrences or ()) if is_gap else ()),
            *((rrseq_cons_occurrences or ()) if not is_gap else ()),
        ]
        enriched_records, context_reference_counts = enrich_occurrence_records(
            source_records,
            histories,
        )
        single_rule_occurrences = [
            record for record in enriched_records if occurrence_kind(record) == "t1"
        ]
        if is_gap:
            rrseq_gap_occurrences = [
                record
                for record in enriched_records
                if occurrence_kind(record) == "rrseq_gap"
            ]
        else:
            rrseq_cons_occurrences = [
                record
                for record in enriched_records
                if occurrence_kind(record) == "rrseq_cons"
            ]
        context_history_path = resolved_context_history_path
    references_for_output, target_molecules_for_output = (
        merge_rrseq_sequences_by_querycgr(
            references_by_sequence,
            target_molecules_by_sequence,
            query_cgr_keys_by_sequence,
        )
    )
    single_references_for_output, single_target_molecules_for_output = (
        merge_single_rules_by_querycgr(
            references_by_single_rule,
            target_molecules_by_single_rule,
            query_cgr_keys_by_single_rule,
        )
    )
    all_references_for_output = {
        **single_references_for_output,
        **references_for_output,
    }
    all_target_molecules_for_output = {
        **single_target_molecules_for_output,
        **target_molecules_for_output,
    }
    single_rule_evidence = raw_identity_evidence_by_representative(
        references_by_single_rule,
        query_cgr_keys_by_single_rule,
        base_query_cgr_keys_by_single_rule,
        single_rule_occurrences or (),
    )
    sequence_evidence = raw_identity_evidence_by_representative(
        references_by_sequence,
        query_cgr_keys_by_sequence,
        base_query_cgr_keys_by_sequence,
        (rrseq_gap_occurrences or () if is_gap else rrseq_cons_occurrences or ()),
    )
    if is_gap:
        from route_inspector.tactics.rrseq.gap_widths import aggregate_native_gaps

        references_for_output, target_molecules_for_output, sequence_evidence = (
            aggregate_native_gaps(
                rrseq_gap_occurrences or [],
                query_cgr_keys_by_sequence,
                base_query_cgr_keys_by_sequence,
            )
        )
        all_references_for_output = {
            **single_references_for_output,
            **references_for_output,
        }
        all_target_molecules_for_output = {
            **single_target_molecules_for_output,
            **target_molecules_for_output,
        }
    all_identity_evidence = {**single_rule_evidence, **sequence_evidence}

    single_rule_occurrences_path = single_rule_occurrence_sidecar_path(args.output)
    write_single_rule_occurrences(
        single_rule_occurrences_path,
        single_rule_occurrences or [],
    )

    occurrences_path = None
    if is_gap:
        occurrences_path = args.output.with_suffix("").with_name(
            f"{args.output.with_suffix('').name}_rrseq_gap_occurrences.json"
        )
        write_json(
            occurrences_path,
            sorted(
                rrseq_gap_occurrences or [],
                key=lambda occurrence: (
                    str(occurrence.get("route_id", "")),
                    str(occurrence.get("occurrence_id", "")),
                ),
            ),
        )
    rrseq_cons_occurrences_path = None
    if not is_gap:
        rrseq_cons_occurrences_path = rrseq_cons_occurrence_sidecar_path(args.output)
        write_rrseq_cons_occurrences(
            rrseq_cons_occurrences_path,
            rrseq_cons_occurrences or [],
        )
    output_summary = write_rrseqs(
        args.output,
        all_references_for_output,
        target_molecules_by_sequence=all_target_molecules_for_output,
        evidence_by_sequence=all_identity_evidence,
        sequence_kind=sequence_mode,
        include_single_rules=not is_gap,
    )
    write_errors(args.output, errors)
    routes_without_rrseqs_path = None
    if store_routes_without_rrseqs:
        routes_without_rrseqs_path = write_rrseq_routes_without_rules(
            args.output,
            routes_without_rrseqs,
            getattr(args, "routes_without_rrseqs_output", None)
            or (
                args.output.with_suffix("").with_name(
                    f"{args.output.with_suffix('').name}_routes_without_rrseq_gap.json"
                )
                if is_gap
                else None
            ),
            sequence_kind=sequence_mode,
        )
    routes_without_rrseqs_count = sum(routes_without_rrseqs_by_reason.values())
    dataset_id, source_identity = resolved_extraction_provenance(args)

    variant_key = f"rrseq_{sequence_mode}"
    summary = {
        "routes_json": str(args.routes_json),
        "dataset_id": dataset_id,
        "source_identity": source_identity,
        "extraction_mode": extraction_mode,
        "routes_seen": stats.routes_seen,
        f"routes_with_{variant_key}": stats.routes_with_rrseqs,
        f"routes_without_{variant_key}": routes_without_rrseqs_count,
        f"routes_without_{variant_key}_file": (
            str(routes_without_rrseqs_path)
            if routes_without_rrseqs_path is not None
            else None
        ),
        f"routes_without_{variant_key}_output_skipped": (
            not store_routes_without_rrseqs
        ),
        f"routes_without_{variant_key}_by_reason": dict(
            sorted(routes_without_rrseqs_by_reason.items())
        ),
        "reactions_seen": stats.reactions_seen,
        "reaction_rule_cache_hits": stats.reaction_rule_cache_hits,
        "reaction_rule_cache_misses": stats.reaction_rule_cache_misses,
        "skipped_reactions": stats.skipped_reactions,
        **({"no_net_selected_change": stats.no_net_selected_change} if is_gap else {}),
        "errors": stats.errors,
        f"unique_rrseq_{sequence_mode}": len(references_for_output),
        **({"total_unique_rrseq_gap": len(references_for_output)} if is_gap else {}),
        "unique_single_step_rules": len(single_references_for_output),
        f"raw_rrseq_{sequence_mode}_sequences": len(references_by_sequence),
        "raw_single_step_rules": len(references_by_single_rule),
        "target_molecule_occurrences": sum(
            len(targets)
            for route_targets in all_target_molecules_for_output.values()
            for targets in route_targets.values()
        ),
        "min_length": args.min_length,
        "max_length": args.max_length,
        "n_cpu": n_cpu,
        "worker_chunksize": worker_chunksize if n_cpu > 1 else 1,
        "max_pending_chunks": max_pending_chunks if n_cpu > 1 else 1,
        "output_prefix": str(args.output.with_suffix("")),
        "rrseq_kind": sequence_mode,
        "rrseq_gap_occurrences_file": str(occurrences_path)
        if occurrences_path
        else None,
        "rrseq_gap_occurrences": len(rrseq_gap_occurrences or []) if is_gap else 0,
        "rrseq_gap_occurrence_schema_version": (
            RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION if is_gap else None
        ),
        "rrseq_gap_occurrence_identity_version": (
            RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION if is_gap else None
        ),
        "rrseq_cons_occurrence_schema_version": (
            RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION if not is_gap else None
        ),
        "rrseq_cons_occurrence_identity_version": (
            RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION if not is_gap else None
        ),
        "rrseq_cons_occurrences_file": (
            str(rrseq_cons_occurrences_path)
            if rrseq_cons_occurrences_path is not None
            else None
        ),
        "rrseq_cons_occurrences": (
            len(rrseq_cons_occurrences or []) if not is_gap else 0
        ),
        "single_rule_occurrence_schema_version": (
            SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION
        ),
        "single_rule_occurrence_identity_version": (
            SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION
        ),
        "single_rule_occurrences_file": str(single_rule_occurrences_path),
        "single_rule_occurrences": len(single_rule_occurrences or []),
        "context_history_file": (
            str(context_history_path) if context_history_path is not None else None
        ),
        "context_history_references": context_reference_counts,
        **(extra_summary or {}),
        **output_summary,
    }
    summary_path = write_summary(
        args.output,
        summary,
        sequence_kind=sequence_mode,
    )
    summary["summary_file"] = str(summary_path)
    write_summary(args.output, summary, sequence_kind=sequence_mode)
    sidecars = write_standard_sidecars(
        args.output.parent,
        command_name=(
            sidecar_command_name
            or ("extract-rrseq-gap" if is_gap else "extract-rrseq-cons")
        ),
        summary=summary,
        errors=errors,
        input_files=[
            args.routes_json,
            *([context_history_path] if context_history_path is not None else []),
        ],
        output_files={
            **output_summary.get("output_files", {}),
            "summary": summary_path,
            f"routes_without_{artifact_key}": routes_without_rrseqs_path or "",
            "rrseq_gap_occurrences": occurrences_path or "",
            "rrseq_cons_occurrences": rrseq_cons_occurrences_path or "",
            "single_rule_occurrences": single_rule_occurrences_path,
        },
        config_path=getattr(args, "config", None),
        cli_args=args,
    )
    summary["sidecar_files"] = sidecars
    write_summary(args.output, summary, sequence_kind=sequence_mode)

    print(json.dumps(summary, indent=2), flush=True)
    return 0


def resolve_rrseq_output_args(
    args: ExtractRrseqConsRequest | ExtractRrseqGapRequest,
) -> None:
    """Resolve --output or --output-dir into the existing output-prefix argument."""
    if getattr(args, "output", None) is None:
        dataset = dataset_prefix_from_path(args.routes_json)
        args.output = resolve_output_path(
            output=None,
            output_dir=getattr(args, "output_dir", None),
            default_filename=f"{dataset}.tsv",
        )
    elif getattr(args, "output_dir", None) is not None:
        raise ValueError("--output and --output-dir cannot be used together")


def resolved_extraction_provenance(
    args: ExtractRrseqConsRequest | ExtractRrseqGapRequest,
) -> tuple[str, str]:
    """Resolve corpus/source identities exactly as context annotation does."""

    routes_path = Path(args.routes_json)
    dataset_id = str(
        getattr(args, "dataset_id", None) or dataset_prefix_from_path(routes_path)
    )
    source_identity = str(
        getattr(args, "source_identity", None) or routes_path.resolve()
    )
    return dataset_id, source_identity


def validate_extraction_context_history(
    args: ExtractRrseqConsRequest | ExtractRrseqGapRequest,
) -> None:
    """Fail closed when an optional history is stale or lacks route coverage."""

    context_history_path = getattr(args, "context_history", None)
    if context_history_path is None:
        return
    from route_inspector.context import (
        read_context_histories_jsonl,
        validate_route_context_history_integrity,
    )
    from route_inspector.context.occurrences import authoritative_history_lookup

    dataset_id, source_identity = resolved_extraction_provenance(args)
    histories = read_context_histories_jsonl(
        resolve_existing_path(context_history_path)
    )
    lookup = authoritative_history_lookup(histories)
    for route_id, route in iter_route_items_from_json_file(
        args.routes_json,
        args.limit,
    ):
        key = (dataset_id, source_identity, str(route_id))
        history = lookup.get(key)
        if history is None:
            raise ValueError(
                f"route extraction has no authoritative context history for {key!r}"
            )
        validate_route_context_history_integrity(
            history,
            route,
            expected_context_policy_sha256=history.context_policy_sha256,
        )


def empty_collection_state() -> dict[str, Any]:
    """Create empty aggregate containers for rrseq collection.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    return {
        "references_by_sequence": defaultdict(set),
        "target_molecules_by_sequence": defaultdict(lambda: defaultdict(set)),
        "query_cgr_keys_by_sequence": {},
        "base_query_cgr_keys_by_sequence": {},
        "references_by_single_rule": defaultdict(set),
        "target_molecules_by_single_rule": defaultdict(lambda: defaultdict(set)),
        "query_cgr_keys_by_single_rule": {},
        "base_query_cgr_keys_by_single_rule": {},
        "errors": [],
        "routes_without_rrseqs": {},
        "routes_without_rrseqs_by_reason": defaultdict(int),
        "rrseq_cons_occurrences": [],
        "rrseq_gap_occurrences": [],
        "single_rule_occurrences": [],
        "stats": RouteProcessingStats(),
    }


def run_unique_reactions_first(
    args: ExtractRrseqConsRequest | ExtractRrseqGapRequest,
    *,
    n_cpu: int,
    worker_chunksize: int,
    max_pending_chunks: int,
    store_routes_without_rrseqs: bool,
    sequence_mode: str,
) -> int:
    """Run unique reactions first using configured inputs.

    Worker-safe inputs and outputs are used here so large route collections can be
    processed either serially or with `--n_cpu` parallelism.
    """
    state = empty_collection_state()
    dataset_id, source_identity = resolved_extraction_provenance(args)
    source_id_adapter = str(
        getattr(args, "source_id_adapter", PAROUTES_SOURCE_ID_ADAPTER)
    )
    unique_reactions, failed_route_ids = collect_unique_normalized_reactions(
        args,
        stats=state["stats"],
        errors=state["errors"],
    )
    serialized_steps_by_reaction, errors_by_reaction, unique_stats = (
        extract_unique_reaction_rules(
            unique_reactions,
            args,
            n_cpu=n_cpu,
            worker_chunksize=worker_chunksize,
        )
    )

    route_items_iter = filtered_route_items_from_json_file(
        args.routes_json,
        args.limit,
        failed_route_ids,
    )
    rule_extractor = PrecomputedRuleExtractor(
        serialized_steps_by_reaction,
        errors_by_reaction,
    )

    if n_cpu > 1:
        with ProcessPoolExecutor(
            max_workers=n_cpu,
            mp_context=_RRSEQ_MULTIPROCESSING_CONTEXT,
            initializer=_init_precomputed_rrseq_worker,
            initargs=(
                serialized_steps_by_reaction,
                errors_by_reaction,
                args.min_length,
                args.max_length,
                store_routes_without_rrseqs,
                sequence_mode,
                source_identity,
                dataset_id,
                source_id_adapter,
            ),
        ) as executor:
            index = 0
            for result_chunk in route_result_chunks_from_pool(
                executor,
                route_items_iter,
                worker_chunksize=worker_chunksize,
                max_pending_chunks=max_pending_chunks,
            ):
                for result in result_chunk:
                    index += 1
                    consume_rrseq_route_result(
                        result,
                        index,
                        args=args,
                        stats=state["stats"],
                        references_by_sequence=state["references_by_sequence"],
                        target_molecules_by_sequence=state[
                            "target_molecules_by_sequence"
                        ],
                        query_cgr_keys_by_sequence=state["query_cgr_keys_by_sequence"],
                        base_query_cgr_keys_by_sequence=state[
                            "base_query_cgr_keys_by_sequence"
                        ],
                        references_by_single_rule=state["references_by_single_rule"],
                        target_molecules_by_single_rule=state[
                            "target_molecules_by_single_rule"
                        ],
                        query_cgr_keys_by_single_rule=state[
                            "query_cgr_keys_by_single_rule"
                        ],
                        base_query_cgr_keys_by_single_rule=state[
                            "base_query_cgr_keys_by_single_rule"
                        ],
                        errors=state["errors"],
                        routes_without_rrseqs=state["routes_without_rrseqs"],
                        routes_without_rrseqs_by_reason=state[
                            "routes_without_rrseqs_by_reason"
                        ],
                        rrseq_gap_occurrences=state["rrseq_gap_occurrences"],
                        rrseq_cons_occurrences=state["rrseq_cons_occurrences"],
                        single_rule_occurrences=state["single_rule_occurrences"],
                    )
    else:
        for index, (route_id, route) in enumerate(route_items_iter, start=1):
            try:
                result = process_route_for_rrseqs(
                    route_id,
                    route,
                    rule_extractor,
                    min_length=args.min_length,
                    max_length=args.max_length,
                    store_route_without_rrseqs=store_routes_without_rrseqs,
                    sequence_mode=sequence_mode,
                    source_identity=source_identity,
                    dataset_id=dataset_id,
                    source_id_adapter=source_id_adapter,
                )
            except Exception as exc:
                result = {
                    "route_id": route_id,
                    "route_sequences": {},
                    "single_rules": {},
                    "rrseq_cons_occurrences": [],
                    "rrseq_gap_occurrences": [],
                    "route_without_rrseqs": None,
                    "no_rrseq_reason": "",
                    "stats": RouteProcessingStats(routes_seen=1, errors=1),
                    "error": {
                        "route_id": route_id,
                        "stage": "extract_route_rrseq_cons",
                        "error_type": type(exc).__qualname__,
                        "message": str(exc) or traceback.format_exc(limit=1).strip(),
                    },
                }
            consume_rrseq_route_result(
                result,
                index,
                args=args,
                stats=state["stats"],
                references_by_sequence=state["references_by_sequence"],
                target_molecules_by_sequence=state["target_molecules_by_sequence"],
                query_cgr_keys_by_sequence=state["query_cgr_keys_by_sequence"],
                base_query_cgr_keys_by_sequence=state[
                    "base_query_cgr_keys_by_sequence"
                ],
                references_by_single_rule=state["references_by_single_rule"],
                target_molecules_by_single_rule=state[
                    "target_molecules_by_single_rule"
                ],
                query_cgr_keys_by_single_rule=state["query_cgr_keys_by_single_rule"],
                base_query_cgr_keys_by_single_rule=state[
                    "base_query_cgr_keys_by_single_rule"
                ],
                errors=state["errors"],
                routes_without_rrseqs=state["routes_without_rrseqs"],
                routes_without_rrseqs_by_reason=state[
                    "routes_without_rrseqs_by_reason"
                ],
                rrseq_gap_occurrences=state["rrseq_gap_occurrences"],
                rrseq_cons_occurrences=state["rrseq_cons_occurrences"],
                single_rule_occurrences=state["single_rule_occurrences"],
            )

    if args.progress_interval and state["stats"].routes_seen % args.progress_interval:
        print(
            f"processed routes={state['stats'].routes_seen} "
            f"rrseqs={len(state['references_by_sequence'])} "
            f"routes_without_rrseqs="
            f"{sum(state['routes_without_rrseqs_by_reason'].values())} "
            f"errors={state['stats'].errors}",
            flush=True,
        )

    return write_rrseq_extraction_outputs(
        args,
        stats=state["stats"],
        references_by_sequence=state["references_by_sequence"],
        target_molecules_by_sequence=state["target_molecules_by_sequence"],
        query_cgr_keys_by_sequence=state["query_cgr_keys_by_sequence"],
        base_query_cgr_keys_by_sequence=state["base_query_cgr_keys_by_sequence"],
        references_by_single_rule=state["references_by_single_rule"],
        target_molecules_by_single_rule=state["target_molecules_by_single_rule"],
        query_cgr_keys_by_single_rule=state["query_cgr_keys_by_single_rule"],
        base_query_cgr_keys_by_single_rule=state["base_query_cgr_keys_by_single_rule"],
        errors=state["errors"],
        routes_without_rrseqs=state["routes_without_rrseqs"],
        routes_without_rrseqs_by_reason=state["routes_without_rrseqs_by_reason"],
        n_cpu=n_cpu,
        worker_chunksize=worker_chunksize,
        max_pending_chunks=max_pending_chunks,
        store_routes_without_rrseqs=store_routes_without_rrseqs,
        sequence_mode=sequence_mode,
        extraction_mode="unique_reactions_first",
        extra_summary={
            **unique_stats,
            "routes_failed_during_unique_reaction_scan": len(failed_route_ids),
        },
        rrseq_gap_occurrences=state["rrseq_gap_occurrences"],
        rrseq_cons_occurrences=state["rrseq_cons_occurrences"],
        single_rule_occurrences=state["single_rule_occurrences"],
    )


def run(
    args: ExtractRrseqConsRequest | ExtractRrseqGapRequest,
    *,
    sequence_mode: str = RRSEQ_CONS_KIND,
) -> int:
    """Run this module command with parsed CLI arguments.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    sequence_mode = normalize_rrseq_kind(sequence_mode)
    setup_runtime_cache_dirs()
    resolve_rrseq_output_args(args)
    validate_extraction_context_history(args)
    if args.min_length < 2:
        raise ValueError("--min-length must be at least 2")
    if args.max_length is not None and args.max_length <= 0:
        args.max_length = None
    if args.max_length is not None and args.max_length < args.min_length:
        raise ValueError("--max-length must be greater than or equal to --min-length")

    route_items_iter = iter_route_items_from_json_file(args.routes_json, args.limit)
    n_cpu = normalize_n_cpu(getattr(args, "n_cpu", 1))
    worker_chunksize = max(1, int(getattr(args, "worker_chunksize", 16) or 16))
    max_pending_chunks = max(
        n_cpu,
        int(getattr(args, "max_pending_chunks", 0) or n_cpu * 2),
    )
    store_routes_without_rrseqs = not getattr(
        args,
        "skip_routes_without_rrseqs_output",
        False,
    )
    if getattr(args, "unique_reactions_first", False):
        return run_unique_reactions_first(
            args,
            n_cpu=n_cpu,
            worker_chunksize=worker_chunksize,
            max_pending_chunks=max_pending_chunks,
            store_routes_without_rrseqs=store_routes_without_rrseqs,
            sequence_mode=sequence_mode,
        )

    references_by_sequence: dict[tuple[str, ...], set[Any]] = defaultdict(set)
    target_molecules_by_sequence: dict[tuple[str, ...], dict[Any, set[str]]] = (
        defaultdict(lambda: defaultdict(set))
    )
    query_cgr_keys_by_sequence: dict[tuple[str, ...], tuple[str, ...]] = {}
    base_query_cgr_keys_by_sequence: dict[tuple[str, ...], tuple[str, ...]] = {}
    references_by_single_rule: dict[tuple[str, ...], set[Any]] = defaultdict(set)
    target_molecules_by_single_rule: dict[tuple[str, ...], dict[Any, set[str]]] = (
        defaultdict(lambda: defaultdict(set))
    )
    query_cgr_keys_by_single_rule: dict[tuple[str, ...], tuple[str, ...]] = {}
    base_query_cgr_keys_by_single_rule: dict[tuple[str, ...], tuple[str, ...]] = {}
    errors: list[dict[str, Any]] = []
    routes_without_rrseqs: dict[Any, dict[str, Any]] = {}
    routes_without_rrseqs_by_reason: dict[str, int] = defaultdict(int)
    stats = RouteProcessingStats()
    rrseq_cons_occurrences: list[dict[str, Any]] = []
    rrseq_gap_occurrences: list[dict[str, Any]] = []
    single_rule_occurrences: list[dict[str, Any]] = []

    def consume_result(result: dict[str, Any], index: int) -> None:
        """Merge one worker result into the aggregate state.

        The helper feeds rule extraction, center-overlap filtering, or final TSV
        aggregation without changing the original route JSON in place.
        """
        merge_route_processing_stats(stats, result["stats"])
        error = result.get("error")
        if error:
            if not args.ignore_errors:
                raise RuntimeError(
                    f"route {error['route_id']} failed during {error['stage']}: "
                    f"{error['error_type']}: {error['message']}"
                )
            errors.append(error)
            return

        route_id = result["route_id"]
        rrseq_cons_occurrences.extend(result.get("rrseq_cons_occurrences", []))
        rrseq_gap_occurrences.extend(result.get("rrseq_gap_occurrences", []))
        single_rule_occurrences.extend(result.get("single_rule_occurrences", []))
        route_sequences = result["route_sequences"]
        single_rules = result.get("single_rules", {})
        merge_query_cgr_key_records(
            query_cgr_keys_by_sequence,
            result.get("route_sequence_query_cgr_keys", {}),
        )
        merge_query_cgr_key_records(
            query_cgr_keys_by_single_rule,
            result.get("single_rule_query_cgr_keys", {}),
        )
        merge_query_cgr_key_records(
            base_query_cgr_keys_by_sequence,
            result.get("route_sequence_base_query_cgr_keys", {}),
        )
        merge_query_cgr_key_records(
            base_query_cgr_keys_by_single_rule,
            result.get("single_rule_base_query_cgr_keys", {}),
        )
        if result["no_rrseq_reason"]:
            reason = result["no_rrseq_reason"]
            routes_without_rrseqs_by_reason[reason] += 1
        if result["route_without_rrseqs"] is not None:
            routes_without_rrseqs[route_id] = result["route_without_rrseqs"]

        for sequence, target_molecules in single_rules.items():
            references_by_single_rule[sequence].add(route_id)
            target_molecules_by_single_rule[sequence][route_id].update(target_molecules)

        for sequence, target_molecules in route_sequences.items():
            references_by_sequence[sequence].add(route_id)
            target_molecules_by_sequence[sequence][route_id].update(target_molecules)

        if args.progress_interval and index % args.progress_interval == 0:
            print(
                f"processed routes={index} rrseqs={len(references_by_sequence)} "
                f"routes_without_rrseqs={sum(routes_without_rrseqs_by_reason.values())} "
                f"errors={stats.errors}",
                flush=True,
            )

    dataset_id, source_identity = resolved_extraction_provenance(args)
    source_id_adapter = str(
        getattr(args, "source_id_adapter", PAROUTES_SOURCE_ID_ADAPTER)
    )
    if n_cpu > 1:
        with ProcessPoolExecutor(
            max_workers=n_cpu,
            mp_context=_RRSEQ_MULTIPROCESSING_CONTEXT,
            initializer=_init_rrseq_worker,
            initargs=(
                rule_extractor_args_dict(args),
                args.min_length,
                args.max_length,
                store_routes_without_rrseqs,
                sequence_mode,
                source_identity,
                dataset_id,
                source_id_adapter,
            ),
        ) as executor:
            index = 0
            for result_chunk in route_result_chunks_from_pool(
                executor,
                route_items_iter,
                worker_chunksize=worker_chunksize,
                max_pending_chunks=max_pending_chunks,
            ):
                for result in result_chunk:
                    index += 1
                    consume_result(result, index)
    else:
        rule_extractor = SynPlannerRuleExtractor.from_args(args)
        for index, (route_id, route) in enumerate(route_items_iter, start=1):
            try:
                result = process_route_for_rrseqs(
                    route_id,
                    route,
                    rule_extractor,
                    min_length=args.min_length,
                    max_length=args.max_length,
                    store_route_without_rrseqs=(store_routes_without_rrseqs),
                    sequence_mode=sequence_mode,
                    source_identity=source_identity,
                    dataset_id=dataset_id,
                    source_id_adapter=source_id_adapter,
                )
            except Exception as exc:
                result = {
                    "route_id": route_id,
                    "route_sequences": {},
                    "route_sequence_query_cgr_keys": {},
                    "route_sequence_base_query_cgr_keys": {},
                    "single_rules": {},
                    "single_rule_query_cgr_keys": {},
                    "single_rule_base_query_cgr_keys": {},
                    "single_rule_occurrences": [],
                    "rrseq_cons_occurrences": [],
                    "rrseq_gap_occurrences": [],
                    "route_without_rrseqs": None,
                    "no_rrseq_reason": "",
                    "stats": RouteProcessingStats(routes_seen=1, errors=1),
                    "error": {
                        "route_id": route_id,
                        "stage": "extract_route_rrseq_cons",
                        "error_type": type(exc).__qualname__,
                        "message": str(exc) or traceback.format_exc(limit=1).strip(),
                    },
                }
            consume_result(result, index)

    if args.progress_interval and stats.routes_seen % args.progress_interval:
        print(
            f"processed routes={stats.routes_seen} "
            f"rrseqs={len(references_by_sequence)} "
            f"routes_without_rrseqs={sum(routes_without_rrseqs_by_reason.values())} "
            f"errors={stats.errors}",
            flush=True,
        )

    return write_rrseq_extraction_outputs(
        args,
        stats=stats,
        references_by_sequence=references_by_sequence,
        target_molecules_by_sequence=target_molecules_by_sequence,
        query_cgr_keys_by_sequence=query_cgr_keys_by_sequence,
        base_query_cgr_keys_by_sequence=base_query_cgr_keys_by_sequence,
        references_by_single_rule=references_by_single_rule,
        target_molecules_by_single_rule=target_molecules_by_single_rule,
        query_cgr_keys_by_single_rule=query_cgr_keys_by_single_rule,
        base_query_cgr_keys_by_single_rule=base_query_cgr_keys_by_single_rule,
        errors=errors,
        routes_without_rrseqs=routes_without_rrseqs,
        routes_without_rrseqs_by_reason=routes_without_rrseqs_by_reason,
        n_cpu=n_cpu,
        worker_chunksize=worker_chunksize,
        max_pending_chunks=max_pending_chunks,
        store_routes_without_rrseqs=store_routes_without_rrseqs,
        sequence_mode=sequence_mode,
        extraction_mode="route_streaming",
        rrseq_gap_occurrences=rrseq_gap_occurrences,
        rrseq_cons_occurrences=rrseq_cons_occurrences,
        single_rule_occurrences=single_rule_occurrences,
    )


def run_gapped(args: ExtractRrseqConsRequest | ExtractRrseqGapRequest) -> int:
    """Run analysis-only RRseq_gap extraction."""

    return run(args, sequence_mode=RRSEQ_GAP_KIND)
