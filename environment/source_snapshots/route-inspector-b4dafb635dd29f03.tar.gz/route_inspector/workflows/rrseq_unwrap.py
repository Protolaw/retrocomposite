"""Corpus execution and publication for rrseq unwrap."""

from __future__ import annotations

import json

from route_inspector.infrastructure.artifacts import write_json
from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
from route_inspector.tactics.rrseq.artifacts import read_rrseq_from_tsv
from route_inspector.tactics.rrseq.unwrap import (
    unwrap_rrseq_cons,
)
from route_inspector.workflows.requests import UnwrapRrseqConsRequest


def run(args: UnwrapRrseqConsRequest) -> int:
    """Run this module command with parsed CLI arguments.

    Rules are applied retrosynthetically in their encoded order; failures are raised as
    route unwrapping errors so callers can report the skipped target.
    """
    setup_runtime_cache_dirs()

    rrseq = args.rrseq
    if rrseq is None:
        rrseq = read_rrseq_from_tsv(args.rrseq_tsv, args.row)

    routes_json = unwrap_rrseq_cons(
        args.smiles,
        rrseq,
        route_id=args.route_id,
        mark_leaves_in_stock=not args.do_not_mark_leaves_in_stock,
    )

    if args.output_json:
        write_json(args.output_json, routes_json)
    else:
        print(json.dumps(routes_json, indent=2))

    if args.output_svg:
        from route_inspector.visualization import get_route_svg_from_json

        svg = get_route_svg_from_json(routes_json, args.route_id, labeled=args.labeled)
        args.output_svg.parent.mkdir(parents=True, exist_ok=True)
        args.output_svg.write_text(svg, encoding="utf-8")

    return 0
