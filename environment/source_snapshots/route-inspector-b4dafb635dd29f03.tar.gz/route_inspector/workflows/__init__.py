"""Typed application workflows; no command parsing or GUI dependencies."""
