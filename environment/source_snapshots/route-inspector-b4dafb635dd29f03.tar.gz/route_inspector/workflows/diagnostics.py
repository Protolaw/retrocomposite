"""Corpus publication for mapped-atom provenance diagnostics."""

from __future__ import annotations

import json
from pathlib import Path

from route_inspector.infrastructure.artifacts import (
    dataset_prefix_from_path,
    write_standard_sidecars,
)
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.text import read_json
from route_inspector.routes.diagnostics import audit_atom_provenance
from route_inspector.routes.reports import (
    atom_provenance_output_paths,
    write_atom_provenance_outputs,
)
from route_inspector.workflows.requests import AuditRouteProvenanceRequest


def run(args: AuditRouteProvenanceRequest) -> int:
    """Run the standalone route-provenance diagnostic command."""

    routes_path = resolve_existing_path(args.routes_json)
    dataset = dataset_prefix_from_path(routes_path)
    output_dir = Path(args.output_dir).expanduser()
    routes_json = read_json(routes_path)
    result = audit_atom_provenance(routes_json, dataset=dataset)
    paths = atom_provenance_output_paths(output_dir, dataset)
    summary = write_atom_provenance_outputs(result, paths, input_file=routes_path)
    write_standard_sidecars(
        output_dir,
        command_name="audit-route-provenance",
        summary=summary,
        errors=result.parse_errors,
        input_files=[routes_path],
        output_files=paths,
        cli_args=args,
    )
    print(json.dumps(summary, indent=2), flush=True)
    return 0
