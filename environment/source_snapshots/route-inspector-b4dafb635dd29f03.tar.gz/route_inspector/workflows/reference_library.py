"""End-to-end Reference library construction and route assessment workflows."""

from __future__ import annotations

import json
import shutil
import sys
import tempfile
import time
from collections import Counter
from collections.abc import Iterable, Mapping, Sequence
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

import route_inspector.routes.access as route_access
from route_inspector.datasets.paroutes.source_ids import PAROUTES_SOURCE_ID_ADAPTER
from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.progress import render_progress
from route_inspector.infrastructure.runtime import (
    normalize_n_cpu,
    setup_runtime_cache_dirs,
)
from route_inspector.infrastructure.text import read_json
from route_inspector.protection.strategies.assessment import (
    RoutePGStrategyAssessment,
    assess_pg_strategies,
)
from route_inspector.reference_library.assessment.bigrams import (
    assess_retro_bleu_bigrams,
)
from route_inspector.reference_library.assessment.tactics import (
    ROUTE_TACTIC_ASSESSMENT_SCHEMA_VERSION,
    RouteTacticAssessment,
    assess_tactic_occurrences,
)
from route_inspector.reference_library.bigram_catalog import (
    ReferenceBigramOccurrence,
    RetroBleuBigramCatalog,
    RetroBleuBigramIdentity,
)
from route_inspector.reference_library.build.component_profiles import (
    _protection_rule_configuration,
)
from route_inspector.reference_library.build.execution import (
    _init_reference_worker,
    _process_reference_item,
)
from route_inspector.reference_library.build.processing import (
    ProcessedRouteTactics,
    RouteTacticProcessingError,
    RouteTacticProcessor,
)
from route_inspector.reference_library.build.streaming import (
    ReferenceLibraryPublicationResult,
    build_reference_library_to_directory,
)
from route_inspector.reference_library.catalog import ReferenceTacticLibrary
from route_inspector.reference_library.models import (
    ReferenceRouteKey,
    TacticOccurrence,
)
from route_inspector.reference_library.profile import ReferenceProcessingProfile
from route_inspector.reference_library.settings import ProcessorSettings
from route_inspector.reference_library.storage.artifacts import (
    _publish_directory_no_replace,
)
from route_inspector.rules.config import dependency_version, resolved_config_mapping
from route_inspector.workflows.requests import (
    AssessRouteRequest,
    BuildReferenceLibraryRequest,
)


def _value_or_profile(
    value: Any,
    profile: ReferenceProcessingProfile | None,
    field_name: str,
) -> Any:
    if value is not None:
        return value
    if profile is None:
        raise ValueError(f"{field_name} is required")
    return getattr(profile, field_name)


def processing_profile_from_args(
    args: Any,
    *,
    library_profile: ReferenceProcessingProfile | None = None,
) -> tuple[ReferenceProcessingProfile, Any, Any]:
    """Resolve one scientific profile and its runtime chemistry configurations."""

    try:
        from synplan.chem.reaction.rules.config import RuleExtractionConfig
    except ImportError:  # SynPlanner releases before the public module move.
        from synplan.utils.config import RuleExtractionConfig

    from route_inspector.protection.analysis import ProtectionAnalysisConfig

    config_path = resolve_existing_path(args.config)
    rule_config = RuleExtractionConfig.from_yaml(str(config_path))
    rule_payload = resolved_config_mapping(rule_config)
    rule_payload["implementation_versions"] = {
        "synplanner": dependency_version("SynPlanner"),
        "chython": dependency_version("chython-synplan"),
    }

    from route_inspector.routes.synplanner import route_cgr_compatibility_policy

    policy = route_cgr_compatibility_policy()
    if policy != "native":
        rule_payload["implementation_versions"]["route_cgr_compatibility"] = policy

    protection_path_value = getattr(args, "protection_config", None)
    if protection_path_value is not None:
        protection_path = resolve_existing_path(protection_path_value)
        protection_config = ProtectionAnalysisConfig.from_yaml(protection_path)
        protection_config.collect_interval_rules = False
        protection_payload = resolved_config_mapping(protection_config)
    elif library_profile is not None:
        protection_payload = dict(library_profile.protection_config)
        protection_config = ProtectionAnalysisConfig(**protection_payload)
    else:
        protection_config = ProtectionAnalysisConfig(collect_interval_rules=False)
        protection_payload = resolved_config_mapping(protection_config)

    factorability_base = (
        dict(library_profile.factorability_config)
        if library_profile is not None
        else {
            "enabled": False,
            "context_radius": 2,
            "max_replay_outcomes": 256,
            "require_unique_replay": False,
        }
    )
    classify_factorability = getattr(args, "classify_gap_factorability", None)
    factorability_context_radius = getattr(args, "factorability_context_radius", None)
    factorability_max_replay_outcomes = getattr(
        args,
        "factorability_max_replay_outcomes",
        None,
    )
    factorability_require_unique_replay = getattr(
        args,
        "factorability_require_unique_replay",
        None,
    )
    factorability = {
        "enabled": (
            bool(factorability_base.get("enabled", False))
            if classify_factorability is None
            else bool(classify_factorability)
        ),
        "context_radius": int(
            factorability_base.get("context_radius", 2)
            if factorability_context_radius is None
            else factorability_context_radius
        ),
        "max_replay_outcomes": int(
            factorability_base.get("max_replay_outcomes", 256)
            if factorability_max_replay_outcomes is None
            else factorability_max_replay_outcomes
        ),
        "require_unique_replay": bool(
            factorability_base.get("require_unique_replay", False)
            if factorability_require_unique_replay is None
            else factorability_require_unique_replay
        ),
    }

    profile = ReferenceProcessingProfile(
        input_state=str(
            _value_or_profile(
                getattr(args, "input_state", None),
                library_profile,
                "input_state",
            )
        ),
        rule_extraction_config=rule_payload,
        protection_config=protection_payload,
        source_id_adapter=str(
            _value_or_profile(
                getattr(args, "source_id_adapter", None),
                library_profile,
                "source_id_adapter",
            )
        ),
        rrseq_min_length=int(
            _value_or_profile(
                getattr(args, "rrseq_min_length", None),
                library_profile,
                "rrseq_min_length",
            )
        ),
        rrseq_max_length=(
            None
            if _value_or_profile(
                getattr(args, "rrseq_max_length", None),
                library_profile,
                "rrseq_max_length",
            )
            is None
            else int(
                _value_or_profile(
                    getattr(args, "rrseq_max_length", None),
                    library_profile,
                    "rrseq_max_length",
                )
            )
        ),
        rrsubtree_min_size=int(
            _value_or_profile(
                getattr(args, "rrsubtree_min_size", None),
                library_profile,
                "rrsubtree_min_size",
            )
        ),
        rrsubtree_max_size=int(
            _value_or_profile(
                getattr(args, "rrsubtree_max_size", None),
                library_profile,
                "rrsubtree_max_size",
            )
        ),
        rrsubtree_max_candidates_per_route=int(
            _value_or_profile(
                getattr(args, "rrsubtree_max_candidates_per_route", None),
                library_profile,
                "rrsubtree_max_candidates_per_route",
            )
        ),
        factorability_config=factorability,
        mapping_validation=True,
    )
    return profile, rule_config, protection_config


def tactic_processor_from_profile(
    profile: ReferenceProcessingProfile,
    *,
    rule_config: Any,
    protection_config: Any,
    include_retro_bleu_bigrams: bool = False,
    include_pg_strategies: bool = False,
    pg_strategy_config: Any | None = None,
    tactic_identity_version: int = 4,
) -> RouteTacticProcessor:
    """Construct the shared processor from one resolved scientific profile."""

    from route_inspector.rules.extraction import SynPlannerRuleExtractor

    granularity_extractor = None
    protection_rules: Mapping[str, Any] = {}
    if profile.input_state == "raw" or include_pg_strategies:
        from route_inspector.protection.chython_rules import (
            load_chython_protection_rules,
        )

        protection_rules = load_chython_protection_rules()
    if profile.input_state == "raw":
        from route_inspector.routes.preprocessing.core import (
            SynPlannerGranularityExtractor,
        )

        granularity_extractor = SynPlannerGranularityExtractor(rule_config)
    return RouteTacticProcessor(
        profile,
        SynPlannerRuleExtractor(rule_config),
        granularity_extractor=granularity_extractor,
        protection_rules=protection_rules,
        protection_config=protection_config,
        include_retro_bleu_bigrams=include_retro_bleu_bigrams,
        include_pg_strategies=include_pg_strategies,
        pg_strategy_config=pg_strategy_config,
        tactic_identity_version=tactic_identity_version,
    )


def route_tactic_processor_from_config(
    config: str | Path,
    *,
    processing_profile: ReferenceProcessingProfile | None = None,
    input_state: str | None = None,
    protection_config: str | Path | None = None,
    source_id_adapter: str | None = None,
    rrseq_min_length: int | None = None,
    rrseq_max_length: int | None = None,
    rrsubtree_min_size: int | None = None,
    rrsubtree_max_size: int | None = None,
    rrsubtree_max_candidates_per_route: int | None = None,
    classify_gap_factorability: bool | None = None,
    factorability_context_radius: int | None = None,
    factorability_max_replay_outcomes: int | None = None,
    factorability_require_unique_replay: bool | None = None,
    include_retro_bleu_bigrams: bool = False,
    include_pg_strategies: bool = False,
    pg_strategy_config: str | Path | None = None,
    tactic_identity_version: int = 4,
) -> RouteTacticProcessor:
    """Build the public shared route processor from scientific configuration.

    Without ``processing_profile``, omitted options use the conservative library
    build defaults. With a persisted profile, omitted options inherit its exact
    scientific settings and every explicit override is compatibility-checked.
    """

    def build_value(value: Any, default: Any) -> Any:
        if value is None and processing_profile is None:
            return default
        return value

    args = ProcessorSettings(
        config=Path(config),
        input_state=build_value(input_state, "preprocessed"),
        protection_config=(
            None if protection_config is None else Path(protection_config)
        ),
        source_id_adapter=build_value(
            source_id_adapter,
            PAROUTES_SOURCE_ID_ADAPTER,
        ),
        rrseq_min_length=build_value(rrseq_min_length, 2),
        rrseq_max_length=build_value(rrseq_max_length, 20),
        rrsubtree_min_size=build_value(rrsubtree_min_size, 3),
        rrsubtree_max_size=build_value(rrsubtree_max_size, 12),
        rrsubtree_max_candidates_per_route=build_value(
            rrsubtree_max_candidates_per_route,
            100_000,
        ),
        classify_gap_factorability=build_value(
            classify_gap_factorability,
            False,
        ),
        factorability_context_radius=build_value(
            factorability_context_radius,
            2,
        ),
        factorability_max_replay_outcomes=build_value(
            factorability_max_replay_outcomes,
            256,
        ),
        factorability_require_unique_replay=build_value(
            factorability_require_unique_replay,
            False,
        ),
    )
    profile, rule_config, resolved_protection_config = processing_profile_from_args(
        args,
        library_profile=processing_profile,
    )
    if processing_profile is not None:
        processing_profile.assert_compatible(profile)
    resolved_pg_config = None
    if include_pg_strategies:
        from route_inspector.protection.analysis import ProtectionAnalysisConfig

        resolved_pg_config = ProtectionAnalysisConfig.from_yaml(
            None
            if pg_strategy_config is None
            else resolve_existing_path(pg_strategy_config)
        )
        resolved_pg_config.collect_interval_rules = False
    return tactic_processor_from_profile(
        profile,
        rule_config=rule_config,
        protection_config=resolved_protection_config,
        include_retro_bleu_bigrams=include_retro_bleu_bigrams,
        include_pg_strategies=include_pg_strategies,
        pg_strategy_config=resolved_pg_config,
        tactic_identity_version=tactic_identity_version,
    )


def route_collection(
    value: Any,
    *,
    route_id: Any | None = None,
) -> list[tuple[Any, dict[str, Any]]]:
    """Normalize a route root, list, or mapping into deterministic route items."""

    if isinstance(value, Mapping) and value.get("type") == "mol":
        metadata = value.get("metadata") or {}
        resolved_id = (
            route_id if route_id is not None else metadata.get("route_id", "0")
        )
        items = [(resolved_id, dict(value))]
    elif route_id is not None:
        items = [(route_id, route_access.route_by_id(value, route_id))]
    else:
        items = list(route_access.route_items(value))
    for current_id, route in items:
        if not isinstance(route, dict) or route.get("type") != "mol":
            raise ValueError(f"route {current_id!r} does not have a molecule root")

    def sort_key(item: tuple[Any, dict[str, Any]]) -> tuple[int, Any]:
        text = str(item[0])
        return (0, int(text)) if text.isdigit() else (1, text)

    return sorted(items, key=sort_key)


def process_route_collection(
    route_items: Iterable[tuple[Any, dict[str, Any]]],
    processor: RouteTacticProcessor,
    *,
    dataset_id: str,
    source_identity: str,
    limit: int | None = None,
    progress_interval: int = 0,
    n_cpu: int = 1,
) -> tuple[ProcessedRouteTactics, ...]:
    """Extract every selected route with deterministic process parallelism."""

    if limit is not None and limit < 0:
        raise ValueError("limit must be non-negative")
    workers = normalize_n_cpu(n_cpu)
    selected = tuple(
        item
        for index, item in enumerate(route_items, start=1)
        if limit is None or index <= limit
    )
    processed: list[ProcessedRouteTactics] = []
    started_at = time.monotonic()

    if workers > 1 and selected:
        with ProcessPoolExecutor(
            max_workers=workers,
            initializer=_init_reference_worker,
            initargs=(processor, str(dataset_id), str(source_identity)),
        ) as executor:
            results = executor.map(_process_reference_item, selected, chunksize=1)
            for index, result in enumerate(results, start=1):
                processed.append(result)
                processor.routes_processed += 1
                if progress_interval and (
                    index % progress_interval == 0 or index == len(selected)
                ):
                    render_progress(
                        "reference-library",
                        index,
                        len(selected),
                        started_at,
                        workers=workers,
                    )
    else:
        for index, (route_id, route) in enumerate(selected, start=1):
            processed.append(
                processor.process_route(
                    route_id,
                    route,
                    dataset_id=dataset_id,
                    source_identity=source_identity,
                )
            )
            if progress_interval and (
                index % progress_interval == 0 or index == len(selected)
            ):
                render_progress(
                    "reference-library",
                    index,
                    len(selected),
                    started_at,
                    workers=workers,
                )
    return tuple(processed)


@dataclass(frozen=True)
class ReferenceLibraryBuildResult:
    """In-memory result of a complete Reference-corpus build."""

    library: ReferenceTacticLibrary
    routes: tuple[ProcessedRouteTactics, ...]

    @property
    def occurrences(self) -> tuple[TacticOccurrence, ...]:
        return tuple(
            occurrence
            for route_result in self.routes
            for occurrence in route_result.occurrences
        )

    def summary(self) -> dict[str, Any]:
        no_tactic_routes = sum(not result.occurrences for result in self.routes)
        return {
            "library_id": self.library.library_id,
            "configuration_fingerprint": self.library.processing_profile.fingerprint,
            "reference_route_count_processed": len(self.routes),
            "reference_route_count_without_extracted_tactics": no_tactic_routes,
            **dict(self.library.manifest.statistics),
            **dict(self.library.manifest.supplementary_evidence),
        }


def build_reference_library(
    route_items: Iterable[tuple[Any, dict[str, Any]]],
    processor: RouteTacticProcessor,
    *,
    reference_id: str,
    source_identity: str,
    corpus_sha256: str = "",
    limit: int | None = None,
    progress_interval: int = 0,
    n_cpu: int = 1,
    pg_classification_provider: Any | None = None,
    pg_classifier_metadata: Mapping[str, Any] | None = None,
    pg_worker_chunksize: int = 100,
) -> ReferenceLibraryBuildResult:
    """Build an explicit tactic vocabulary from Reference routes in memory."""

    if (
        getattr(processor, "include_pg_strategies", False)
        or pg_classification_provider is not None
    ):
        raise ValueError("PG construction is separate; use build-pg-strategy-library")
    processed = process_route_collection(
        route_items,
        processor,
        dataset_id=reference_id,
        source_identity=source_identity,
        limit=limit,
        progress_interval=progress_interval,
        n_cpu=n_cpu,
    )
    occurrences = tuple(
        occurrence
        for route_result in processed
        for occurrence in route_result.occurrences
    )
    routes_with_tactics = sum(bool(result.occurrences) for result in processed)
    rrseq_presence: dict[ReferenceRouteKey, tuple[bool, bool]] = {}
    no_rrseq_route_count = 0
    for result in processed:
        kinds = {occurrence.identity.kind for occurrence in result.occurrences}
        presence = ("rrseq_cons" in kinds, "rrseq_gap" in kinds)
        rrseq_presence[result.route] = presence
        if not any(presence):
            no_rrseq_route_count += 1
    corpus = {
        "dataset_id": str(reference_id),
        "source_identity": str(source_identity),
        "route_count": len(processed),
        "route_count_with_tactics": routes_with_tactics,
        "route_count_without_extracted_tactics": len(processed) - routes_with_tactics,
        "route_ids": sorted(result.route.route_id for result in processed),
    }
    if corpus_sha256:
        corpus["input_sha256"] = str(corpus_sha256)
    bigram_catalog: RetroBleuBigramCatalog | None = None
    supplementary_evidence: dict[str, Any] = {}
    if bool(getattr(processor, "include_retro_bleu_bigrams", False)):
        failed_bigrams = [
            result for result in processed if result.retro_bleu_bigram_error is not None
        ]
        if failed_bigrams:
            first = failed_bigrams[0]
            raise RouteTacticProcessingError(
                first.route,
                "extract_retro_bleu_bigrams",
                "requested Reference bigram extraction was incomplete",
                details=dict(first.retro_bleu_bigram_error or {}),
            )
        reference_bigrams = tuple(
            ReferenceBigramOccurrence(
                identity=RetroBleuBigramIdentity.from_occurrence(occurrence),
                occurrence=occurrence,
                route=result.route,
                route_has_rrseq_cons=rrseq_presence[result.route][0],
                route_has_rrseq_gap=rrseq_presence[result.route][1],
            )
            for result in processed
            for occurrence in result.retro_bleu_bigram_occurrences
        )
        bigram_catalog = RetroBleuBigramCatalog.from_occurrences(reference_bigrams)
        supplementary_evidence = {
            "retro_bleu_bigrams": {
                **bigram_catalog.summary(),
                "reference_route_count_without_rrseq_cons_or_gap": no_rrseq_route_count,
                "no_rrseq_cohort_definition": (
                    "no extracted RRSeq_cons and no extracted RRSeq_gap under "
                    "the stored Reference processing profile"
                ),
            }
        }
    library = ReferenceTacticLibrary.from_occurrences(
        occurrences,
        tactic_identity_version=getattr(processor, "tactic_identity_version", None),
        processing_profile=processor.profile,
        reference_corpora=(corpus,),
        statistics_extra={
            "reference_route_count_processed": len(processed),
            "reference_route_count_without_extracted_tactics": (
                len(processed) - routes_with_tactics
            ),
        },
        retro_bleu_bigram_catalog=bigram_catalog,
        supplementary_evidence=supplementary_evidence,
    )
    return ReferenceLibraryBuildResult(library=library, routes=processed)


def assess_routes_with_pg(
    route_items: Iterable[tuple[Any, dict[str, Any]]],
    processor: RouteTacticProcessor,
    library: ReferenceTacticLibrary,
    *,
    dataset_id: str,
    source_identity: str,
    limit: int | None = None,
) -> tuple[tuple[RouteTacticAssessment, ...], tuple[RoutePGStrategyAssessment, ...]]:
    """Assess tactics and PG strategies from one shared query-route pass."""

    library.assert_compatible(processor.profile)
    if processor.tactic_identity_version != library.tactic_identity_version:
        raise ValueError(
            "query processor tactic identity version differs from the library"
        )
    if limit is not None and limit < 0:
        raise ValueError("limit must be non-negative")
    assessments: list[RouteTacticAssessment] = []
    pg_assessments: list[RoutePGStrategyAssessment] = []
    for index, (route_id, route) in enumerate(route_items, start=1):
        if limit is not None and index > limit:
            break
        route_key = ReferenceRouteKey(
            dataset_id=str(dataset_id),
            source_identity=str(source_identity),
            route_id=str(route_id),
        )
        try:
            processed = processor.process_route(
                route_id,
                route,
                dataset_id=dataset_id,
                source_identity=source_identity,
            )
        except RouteTacticProcessingError as exc:
            bigram_assessment = assess_retro_bleu_bigrams(
                (),
                library.retro_bleu_bigram_catalog,
                query_has_rrseq_cons=False,
                query_has_rrseq_gap=False,
                extraction_error=exc.to_dict(),
            )
            assessments.append(
                assess_tactic_occurrences(
                    (),
                    library,
                    route=route_key,
                    extraction_complete=False,
                    errors=(exc.to_dict(),),
                    retro_bleu_bigrams=bigram_assessment,
                )
            )
            pg_assessments.append(
                assess_pg_strategies(
                    None,
                    library.pg_strategy_library,
                    route=route_key,
                    extraction_error=exc.to_dict(),
                )
            )
        else:
            kinds = {occurrence.identity.kind for occurrence in processed.occurrences}
            bigram_assessment = assess_retro_bleu_bigrams(
                processed.retro_bleu_bigram_occurrences,
                library.retro_bleu_bigram_catalog,
                query_has_rrseq_cons="rrseq_cons" in kinds,
                query_has_rrseq_gap="rrseq_gap" in kinds,
                extraction_error=processed.retro_bleu_bigram_error,
            )
            assessments.append(
                assess_tactic_occurrences(
                    processed.occurrences,
                    library,
                    route=processed.route,
                    retro_bleu_bigrams=bigram_assessment,
                )
            )
            pg_error = processed.pg_strategy_error
            if (
                library.pg_strategy_library is not None
                and processed.pg_strategies is None
            ):
                pg_error = {
                    "route": processed.route.to_dict(),
                    "stage": "extract_pg_strategies",
                    "error_type": "PGStrategyExtractionNotRequested",
                    "message": (
                        "query PG extraction was not enabled for a PG-aware library"
                    ),
                }
            pg_assessments.append(
                assess_pg_strategies(
                    processed.pg_strategies,
                    library.pg_strategy_library,
                    route=processed.route,
                    extraction_error=pg_error,
                )
            )
    return tuple(assessments), tuple(pg_assessments)


def assess_routes(
    route_items: Iterable[tuple[Any, dict[str, Any]]],
    processor: RouteTacticProcessor,
    library: ReferenceTacticLibrary,
    *,
    dataset_id: str,
    source_identity: str,
    limit: int | None = None,
) -> tuple[RouteTacticAssessment, ...]:
    """Assess tactics while preserving the established public return type."""

    assessments, _pg_assessments = assess_routes_with_pg(
        route_items,
        processor,
        library,
        dataset_id=dataset_id,
        source_identity=source_identity,
        limit=limit,
    )
    return assessments


def _atomic_assessment_output(
    output_dir: Path,
    assessments: Sequence[RouteTacticAssessment],
    *,
    library: ReferenceTacticLibrary,
    query_input_sha256: str,
    selected_route_ids: Sequence[str],
    pg_assessments: Sequence[RoutePGStrategyAssessment] | None = None,
    library_verification_requested: Literal["fast", "full"] | None = None,
) -> None:
    if library_verification_requested not in {None, "fast", "full"}:
        raise ValueError("library_verification_requested must be fast, full or None")
    query_digest = str(query_input_sha256)
    if len(query_digest) != 64 or any(
        character not in "0123456789abcdef" for character in query_digest
    ):
        raise ValueError("query_input_sha256 must be a lowercase SHA-256 digest")
    normalized_route_ids = tuple(str(route_id) for route_id in selected_route_ids)
    assessed_route_ids = tuple(assessment.route.route_id for assessment in assessments)
    if len(normalized_route_ids) != len(set(normalized_route_ids)):
        raise ValueError("selected_route_ids must be unique")
    if len(assessed_route_ids) != len(set(assessed_route_ids)):
        raise ValueError("assessment route IDs must be unique")
    if sorted(normalized_route_ids) != sorted(assessed_route_ids):
        raise ValueError(
            "selected_route_ids must exactly match the published assessments"
        )
    if pg_assessments is not None:
        pg_route_ids = tuple(assessment.route.route_id for assessment in pg_assessments)
        if sorted(pg_route_ids) != sorted(normalized_route_ids):
            raise ValueError("PG assessments must exactly match the selected route IDs")
        if len(pg_route_ids) != len(set(pg_route_ids)):
            raise ValueError("PG assessment route IDs must be unique")
    if output_dir.exists():
        raise FileExistsError(f"assessment output already exists: {output_dir}")
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(
        tempfile.mkdtemp(
            prefix=f".{output_dir.name}.",
            suffix=".tmp",
            dir=output_dir.parent,
        )
    )
    try:
        (temporary / "assessments.json").write_text(
            json.dumps(
                [assessment.to_dict() for assessment in assessments],
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        with (temporary / "matches.jsonl").open(
            "w", encoding="utf-8", newline="\n"
        ) as stream:
            for assessment in assessments:
                for match in assessment.matches:
                    stream.write(
                        json.dumps(
                            {
                                "route": assessment.route.to_dict(),
                                **match.to_dict(),
                            },
                            sort_keys=True,
                            separators=(",", ":"),
                        )
                        + "\n"
                    )
        with (temporary / "retro_bleu_bigram_matches.jsonl").open(
            "w", encoding="utf-8", newline="\n"
        ) as stream:
            for assessment in assessments:
                for match in assessment.retro_bleu_bigrams.matches:
                    stream.write(
                        json.dumps(
                            {
                                "route": assessment.route.to_dict(),
                                **match.to_dict(),
                            },
                            sort_keys=True,
                            separators=(",", ":"),
                        )
                        + "\n"
                    )
        if pg_assessments is not None:
            (temporary / "pg_strategy_assessments.json").write_text(
                json.dumps(
                    [assessment.to_dict() for assessment in pg_assessments],
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
            )
            match_outputs = (
                (
                    "pg_strategy_event_matches.jsonl",
                    "event_matches",
                ),
                (
                    "pg_strategy_interval_step_matches.jsonl",
                    "interval_step_matches",
                ),
                (
                    "pg_strategy_interval_sequence_matches.jsonl",
                    "interval_sequence_matches",
                ),
            )
            for filename, attribute in match_outputs:
                with (temporary / filename).open(
                    "w", encoding="utf-8", newline="\n"
                ) as stream:
                    for assessment in pg_assessments:
                        for match in getattr(assessment, attribute):
                            stream.write(
                                json.dumps(
                                    {
                                        "route": assessment.route.to_dict(),
                                        **match.to_dict(),
                                    },
                                    sort_keys=True,
                                    separators=(",", ":"),
                                )
                                + "\n"
                            )
        statuses = Counter(assessment.status for assessment in assessments)
        bigram_availabilities = Counter(
            assessment.retro_bleu_bigrams.availability for assessment in assessments
        )
        pg_statuses = Counter(
            assessment.status for assessment in (pg_assessments or ())
        )
        pg_availabilities = Counter(
            assessment.availability for assessment in (pg_assessments or ())
        )
        summary = {
            "library_id": library.library_id,
            **(
                {"library_verification_requested": library_verification_requested}
                if library_verification_requested is not None
                else {}
            ),
            "configuration_fingerprint": library.processing_profile.fingerprint,
            "query_input_sha256": query_digest,
            "selected_route_ids": sorted(normalized_route_ids),
            "route_count": len(assessments),
            "status_counts": dict(sorted(statuses.items())),
            "extracted_occurrence_count": sum(
                assessment.overall.occurrence_count for assessment in assessments
            ),
            "known_occurrence_count": sum(
                assessment.overall.known_occurrence_count for assessment in assessments
            ),
            "novel_occurrence_count": sum(
                assessment.overall.novel_occurrence_count for assessment in assessments
            ),
            "retro_bleu_bigram_availability_counts": dict(
                sorted(bigram_availabilities.items())
            ),
            "retro_bleu_bigram_occurrence_count": sum(
                len(assessment.retro_bleu_bigrams.matches) for assessment in assessments
            ),
            "known_retro_bleu_bigram_occurrence_count": sum(
                sum(
                    match.known_in_all_reference
                    for match in assessment.retro_bleu_bigrams.matches
                )
                for assessment in assessments
            ),
            "known_no_rrseq_retro_bleu_bigram_occurrence_count": sum(
                sum(
                    match.known_in_reference_without_rrseq
                    for match in assessment.retro_bleu_bigrams.matches
                )
                for assessment in assessments
            ),
            **(
                {
                    "pg_strategy_library_id": (
                        None
                        if library.pg_strategy_library is None
                        else library.pg_strategy_library.library_id
                    ),
                    "pg_strategy_status_counts": dict(sorted(pg_statuses.items())),
                    "pg_strategy_availability_counts": dict(
                        sorted(pg_availabilities.items())
                    ),
                    "pg_strategy_event_count": sum(
                        len(assessment.event_matches) for assessment in pg_assessments
                    ),
                    "pg_strategy_interval_step_count": sum(
                        len(assessment.interval_step_matches)
                        for assessment in pg_assessments
                    ),
                    "pg_strategy_interval_sequence_count": sum(
                        len(assessment.interval_sequence_matches)
                        for assessment in pg_assessments
                    ),
                }
                if pg_assessments is not None
                else {}
            ),
            "assessment_schema_version": (
                assessments[0].schema_version
                if assessments
                else ROUTE_TACTIC_ASSESSMENT_SCHEMA_VERSION
            ),
        }
        (temporary / "summary.json").write_text(
            json.dumps(summary, indent=2) + "\n",
            encoding="utf-8",
        )
        _publish_directory_no_replace(temporary, output_dir)
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise


def publish_reference_library(
    args: BuildReferenceLibraryRequest,
) -> ReferenceLibraryPublicationResult:
    """CLI runner for bounded, streaming Reference-library publication."""

    output_dir = Path(args.output_dir).expanduser()
    if output_dir.exists():
        raise FileExistsError(f"reference tactic-library output exists: {output_dir}")
    setup_runtime_cache_dirs()
    routes_path = resolve_existing_path(args.routes_json)
    corpus_sha256 = _sha256_file(routes_path)
    source_identity = str(args.source_identity or f"sha256:{corpus_sha256}")
    profile, rule_config, protection_config = processing_profile_from_args(args)
    processor = tactic_processor_from_profile(
        profile,
        rule_config=rule_config,
        protection_config=protection_config,
        include_retro_bleu_bigrams=bool(getattr(args, "retro_bleu_bigrams", True)),
    )
    result = build_reference_library_to_directory(
        None,
        processor,
        work_dir=args.work_dir,
        resume=args.resume,
        memory_budget_mb=args.memory_budget_mb,
        output_dir=output_dir,
        reference_id=str(args.reference_id),
        source_identity=source_identity,
        corpus_sha256=corpus_sha256,
        routes_json_path=routes_path,
        limit=args.limit,
        progress_interval=args.progress_interval,
        n_cpu=getattr(args, "n_cpu", 1),
        include_sqlite=bool(args.sqlite_catalog),
        audit_key_isomorphism=bool(getattr(args, "audit_key_isomorphism", False)),
    )
    return result


def run_build_reference_library(args: BuildReferenceLibraryRequest) -> int:
    result = publish_reference_library(args)
    print(
        "[build-reference-library] wrote "
        f"{result.statistics['entry_count']} identities from "
        f"{result.statistics['occurrence_count']} occurrences to "
        f"{result.output_path} in {result.phase_timings['total_seconds']:.1f}s",
        file=sys.stderr,
        flush=True,
    )
    return 0


def run_assess_routes(args: AssessRouteRequest) -> int:
    """CLI runner for exact known/novel assessment of one or a few routes."""

    output_dir = Path(args.output_dir).expanduser()
    if output_dir.exists():
        raise FileExistsError(f"assessment output already exists: {output_dir}")
    setup_runtime_cache_dirs()
    verification = getattr(args, "verification", "fast")
    library = ReferenceTacticLibrary.load(
        args.library,
        verification=verification,
    )
    try:
        profile, rule_config, protection_config = processing_profile_from_args(
            args,
            library_profile=library.processing_profile,
        )
        library.assert_compatible(profile)
        assess_pg = getattr(args, "pg_strategies", None) is not False
        include_pg = assess_pg and library.pg_strategy_library is not None
        pg_strategy_config = None
        if include_pg:
            from route_inspector.protection.analysis import ProtectionAnalysisConfig

            pg_profile = library.pg_strategy_library.manifest.processing_profile
            raw_pg_config = pg_profile.get("protection_analysis_config")
            if not isinstance(raw_pg_config, Mapping):
                raise ValueError(
                    "PG strategy component lacks its resolved tracing configuration"
                )
            pg_strategy_config = ProtectionAnalysisConfig(**dict(raw_pg_config))
        processor = tactic_processor_from_profile(
            profile,
            rule_config=rule_config,
            protection_config=protection_config,
            include_retro_bleu_bigrams=(library.retro_bleu_bigram_catalog is not None),
            include_pg_strategies=include_pg,
            pg_strategy_config=pg_strategy_config,
            tactic_identity_version=library.tactic_identity_version,
        )
        if include_pg and _protection_rule_configuration(
            processor.protection_rules
        ) != library.pg_strategy_library.manifest.processing_profile.get(
            "protection_rules"
        ):
            raise ValueError(
                "installed protection rules differ from the Reference PG component"
            )
        routes_path = resolve_existing_path(args.routes_json)
        routes_json = read_json(routes_path)
        query_hash = _sha256_file(routes_path)
        dataset_id = str(args.dataset_id or f"query_{query_hash[:16]}")
        source_identity = str(args.source_identity or f"sha256:{query_hash}")
        selected_routes = route_collection(routes_json, route_id=args.route_id)
        assessments, all_pg_assessments = assess_routes_with_pg(
            selected_routes,
            processor,
            library,
            dataset_id=dataset_id,
            source_identity=source_identity,
            limit=args.limit,
        )
        pg_assessments = all_pg_assessments if assess_pg else None
        _atomic_assessment_output(
            output_dir,
            assessments,
            library=library,
            query_input_sha256=query_hash,
            selected_route_ids=tuple(
                assessment.route.route_id for assessment in assessments
            ),
            pg_assessments=pg_assessments,
            library_verification_requested=verification,
        )
    finally:
        library.close()
    print(
        f"[assess-route] wrote {len(assessments)} route assessment(s) "
        f"to {args.output_dir}",
        file=sys.stderr,
        flush=True,
    )
    return 0


__all__ = [
    "ReferenceLibraryBuildResult",
    "publish_reference_library",
    "assess_routes",
    "assess_routes_with_pg",
    "build_reference_library",
    "process_route_collection",
    "processing_profile_from_args",
    "route_collection",
    "route_tactic_processor_from_config",
    "run_assess_routes",
    "run_build_reference_library",
    "tactic_processor_from_profile",
]
