"""Composite construction and automatic overlap as one publication workflow."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.workflows.requests import BuildCompositeLibraryRequest


@dataclass(frozen=True)
class CompositePublicationResult:
    output_path: Path
    library_id: str
    certified_links: int
    errors: tuple[Any, ...]
    overlap: tuple[Path, dict[str, Any]] | None


def publish_composite_library(
    args: BuildCompositeLibraryRequest, *, progress=None
) -> CompositePublicationResult:
    """Build and atomically publish a certified composite companion library."""

    from route_inspector.composite_rules.composite import (
        CompositeRuleExtractor,
        composite_extractor_args_dict,
    )
    from route_inspector.composite_rules.library import (
        CompositeDecompositionLibrary,
        build_composite_library,
    )
    from route_inspector.infrastructure.build_workspace import BuildWorkspace
    from route_inspector.infrastructure.paths import resolve_existing_path
    from route_inspector.infrastructure.publication import publish_directory_no_replace
    from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
    from route_inspector.reference_library import ReferenceTacticLibrary
    from route_inspector.routes.disk_source import DiskRouteSource
    from route_inspector.workflows.overlap import OverlapRequest, prepare_overlap

    setup_runtime_cache_dirs()
    if args.output_dir.exists():
        raise FileExistsError(args.output_dir)
    routes_path = resolve_existing_path(args.routes_json)
    reference_path = resolve_existing_path(args.reference_library)
    routes_digest = _sha256_file(routes_path)
    with ReferenceTacticLibrary.load(
        reference_path,
        verification="fast",
    ) as reference_library:
        corpus_digests = {
            str(corpus.get("input_sha256"))
            for corpus in reference_library.manifest.reference_corpora
            if corpus.get("input_sha256") is not None
        }
        if corpus_digests and routes_digest not in corpus_digests:
            raise ValueError(
                "--routes-json content does not match a Reference-library corpus"
            )
        job = BuildWorkspace(
            args.output_dir,
            work_dir=args.work_dir,
            resume=args.resume,
            memory_budget_mb=args.memory_budget_mb,
            fingerprint=dict(
                builder="composites-bounded-v1",
                reference_id=reference_library.library_id,
                source=routes_digest,
                extraction=composite_extractor_args_dict(args),
                kinds=list(args.kinds),
                max_replay_outcomes=args.max_replay_outcomes,
                max_variants=args.max_variants,
                application_timeout_seconds=args.application_timeout_seconds,
                allow_ambiguous=args.allow_ambiguous,
                ignore_errors=args.ignore_errors,
                limit_occurrences=args.limit_occurrences,
                include_sqlite=args.sqlite_catalog,
                single_step_overlap=args.single_step_overlap,
            ),
        )
        with (
            job,
            DiskRouteSource(
                routes_path, job.root / "source.sqlite", routes_digest
            ) as routes_json,
        ):
            result = build_composite_library(
                reference_library,
                routes_json,
                work_dir=job.root,
                resume=args.resume,
                memory_budget_mb=args.memory_budget_mb,
                source_routes_sha256=routes_digest,
                extractor=CompositeRuleExtractor.from_args(
                    args,
                    retain_query_cgr=False,
                    max_cache_size=args.extractor_cache_size,
                ),
                kinds=args.kinds,
                max_replay_outcomes=args.max_replay_outcomes,
                max_variants=args.max_variants,
                application_timeout_seconds=args.application_timeout_seconds,
                allow_ambiguous=args.allow_ambiguous,
                ignore_errors=args.ignore_errors,
                limit_occurrences=args.limit_occurrences,
                n_cpu=args.n_cpu,
                extractor_args=composite_extractor_args_dict(args),
                extractor_cache_size=args.extractor_cache_size,
                progress_interval=args.progress_interval,
            )
            try:
                job.checkpoint("constructed")
                job.check_space()
                overlap_result = None
                if args.single_step_overlap:
                    notify = progress or (lambda state, message: None)
                    notify("preparing", "Preparing exact single-step overlap…")
                    prepared = prepare_overlap(
                        OverlapRequest(
                            source=routes_path, cache_root=args.overlap_cache_dir
                        ),
                        reference_library,
                        result.library,
                        progress=notify,
                    )
                    overlap_result = (prepared.directory, prepared.summary)
                if not job.done("serialized"):
                    # save() publishes atomically. A completed candidate can
                    # survive interruption before its phase checkpoint is saved.
                    if not (job.publication / "manifest.json").is_file():
                        job.publication.rmdir()
                        result.library.save(
                            job.publication, include_sqlite=args.sqlite_catalog
                        )
                    job.checkpoint("serialized")
                with CompositeDecompositionLibrary.load(
                    job.publication, verification="full"
                ) as verified:
                    if verified.library_id != result.library.library_id:
                        raise ValueError(
                            "resumed composite candidate differs from staged results"
                        )
                if _sha256_file(routes_path) != routes_digest:
                    raise ValueError("composite source changed during construction")
                job.checkpoint("verified")
                publish_directory_no_replace(job.publication, args.output_dir)
                job.checkpoint("published")
                result_errors = tuple(result.errors)
            finally:
                result.library.close()
    return CompositePublicationResult(
        args.output_dir,
        result.library.library_id,
        result.certified_links,
        result_errors,
        overlap_result,
    )


__all__ = [
    "BuildCompositeLibraryRequest",
    "CompositePublicationResult",
    "publish_composite_library",
]
