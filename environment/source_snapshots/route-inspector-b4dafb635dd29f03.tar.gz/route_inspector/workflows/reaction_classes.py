"""Corpus execution and publication for reaction classes."""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any, Iterable

from route_inspector.chemistry.classification.common import (
    provider_metadata as _provider_metadata,
)
from route_inspector.chemistry.classification.common import result_attr as _result_attr
from route_inspector.infrastructure.artifacts import (
    dataset_prefix_from_path,
    stage_output_dir,
    write_standard_sidecars,
)
from route_inspector.infrastructure.runtime import normalize_n_cpu
from route_inspector.tactics.classification.rrseq import (
    RXN_CLASS_ERROR_FIELDS,
    _annotate_aggregates,
    _applications_by_row,
    _classify_unique_reactions,
    _existing_files,
    _load_aggregate_rows,
    _steps_for_references,
)
from route_inspector.tactics.classification.rrseq_reporting import _write_outputs
from route_inspector.tactics.rrseq.artifacts import (
    discover_rrseq_occurrence_paths,
    expand_rrseq_occurrence_paths,
    expand_rrseq_tsv_paths,
)
from route_inspector.workflows.requests import ClassifyRrseqConsReactionsRequest


def classify_rrseq_cons_reactions(
    rrseq_cons_tsv: Iterable[str | Path],
    *,
    rrseq_cons_occurrences: Iterable[str | Path] | None = None,
    output_dir: str | Path | None = None,
    mode: str = "dynamic",
    backend: str = "reactionclassifier",
    reaction_classifier_path: str | Path | None = None,
    namerxn_executable: str | Path | None = None,
    tier: int = 3,
    label_policy: str = "confirmed-or-neural",
    n_cpu: int | None = 1,
    worker_chunksize: int = 100,
    torch_threads: int = 1,
    device: str = "cpu",
    limit_rows: int | None = None,
    ignore_errors: bool = False,
    progress_interval: int = 1000,
    provider: Any | None = None,
    cli_args: object | None = None,
    argv: list[str] | None = None,
) -> dict[str, Any]:
    """Classify one representative occurrence of every RRSeq_cons aggregate row."""

    if mode != "dynamic":
        raise ValueError("only --mode dynamic is implemented; static mode is a TODO")
    if int(tier) != 3:
        raise ValueError("only Tier 3 reaction-class sequences are implemented")
    if label_policy not in {"confirmed-only", "confirmed-or-neural"}:
        raise ValueError("--label-policy must be confirmed-only or confirmed-or-neural")
    if limit_rows is not None and int(limit_rows) < 0:
        raise ValueError("--limit-rows must be non-negative")
    if int(worker_chunksize) < 1:
        raise ValueError("--worker-chunksize must be positive")

    tsv_paths = _existing_files(
        expand_rrseq_tsv_paths(Path(path) for path in rrseq_cons_tsv),
        label="RRseq_cons TSV",
    )
    datasets = {dataset_prefix_from_path(path) for path in tsv_paths}
    if len(datasets) != 1:
        raise ValueError(
            "one reaction-classification run must contain exactly one dataset: "
            + ", ".join(sorted(datasets))
        )
    dataset = next(iter(datasets))
    if rrseq_cons_occurrences is None:
        occurrence_paths = discover_rrseq_occurrence_paths(tsv_paths)
    else:
        occurrence_paths = expand_rrseq_occurrence_paths(
            Path(path) for path in rrseq_cons_occurrences
        )
    occurrence_paths = _existing_files(
        occurrence_paths, label="RRseq_cons occurrence sidecar"
    )

    all_aggregates = _load_aggregate_rows(tsv_paths)
    aggregates = (
        all_aggregates if limit_rows is None else all_aggregates[: int(limit_rows)]
    )
    applications = _applications_by_row(
        tsv_paths,
        occurrence_paths,
        aggregates,
    )
    steps, selected = _steps_for_references(aggregates, applications)

    if provider is None:
        from route_inspector.chemistry.classification.providers import create_provider

        provider = create_provider(
            backend,
            reaction_classifier_path=reaction_classifier_path,
            namerxn_executable=namerxn_executable,
            tier=tier,
            label_policy=label_policy,
            torch_threads=torch_threads,
            device=device,
        )
    provider_name, provider_version, taxonomy = _provider_metadata(provider)
    workers = normalize_n_cpu(n_cpu)
    errors, unique_mapped_reactions, unique_classifier_inputs = (
        _classify_unique_reactions(
            steps,
            provider=provider,
            dataset=dataset,
            n_cpu=workers,
            worker_chunksize=int(worker_chunksize),
            progress_interval=int(progress_interval),
            ignore_errors=bool(ignore_errors),
        )
    )
    # Some external providers only learn their precise version while running.
    provider_name, provider_version, taxonomy = _provider_metadata(provider)
    annotated = _annotate_aggregates(
        aggregates,
        selected,
        steps,
        default_provider=provider_name,
        default_provider_version=provider_version,
        default_taxonomy=taxonomy,
    )

    output_path = (
        Path(output_dir).expanduser()
        if output_dir is not None
        else stage_output_dir(Path("outputs"), dataset, "rxnclass_rrseqs")
    )
    output_files, generalized_counts = _write_outputs(
        dataset=dataset,
        output_dir=output_path,
        annotated=annotated,
        applications=applications,
    )

    status_counts = Counter(
        str(
            _result_attr(
                step.result,
                "status",
                "error" if step.error else "unclassified",
            )
        )
        for step in steps
    )
    complete_rows = sum(item.complete for item in annotated)
    occurrence_ids = {
        str(application.occurrence_id)
        for row_applications in applications.values()
        for application in row_applications
        if application.occurrence_id is not None
    }
    summary: dict[str, Any] = {
        "dataset": dataset,
        "mode": mode,
        "backend": provider_name or backend,
        "provider_version": provider_version,
        "taxonomy": taxonomy,
        "tier": int(tier),
        "label_policy": label_policy,
        "reference_selection": [
            "numeric_aware_route_id",
            "root_index",
            "start_position",
            "reaction_node_paths",
            "branch_index",
            "occurrence_id",
        ],
        "aggregate_rrseq_rows_input": len(all_aggregates),
        "aggregate_rrseq_rows_linked": len(aggregates),
        "rrseq_occurrences_accounted": len(occurrence_ids),
        "reference_occurrences_selected": len(selected),
        "reference_steps_selected": len(steps),
        "unique_reference_reactions_mapped": unique_mapped_reactions,
        "unique_classifier_inputs": unique_classifier_inputs,
        "classification_status_counts": dict(sorted(status_counts.items())),
        "complete_rrseq_rows": complete_rows,
        "incomplete_rrseq_rows": len(annotated) - complete_rows,
        "annotated_rrseq_rows": len(annotated),
        "unique_class_sequences": sum(generalized_counts.values()),
        "unique_class_sequences_by_size": {
            str(size): generalized_counts[size] for size in sorted(generalized_counts)
        },
        "template_rows_collapsed": complete_rows - sum(generalized_counts.values()),
        "classification_errors": len(errors),
        "n_cpu": workers,
        "worker_chunksize": int(worker_chunksize),
        "progress_interval": int(progress_interval),
        "input_files": {
            "rrseq_cons_tsv": [str(path) for path in tsv_paths],
            "rrseq_cons_occurrences": [str(path) for path in occurrence_paths],
        },
        "output_directory": str(output_path),
        "output_files": {key: str(path) for key, path in sorted(output_files.items())},
        "sidecar_files": {
            "summary": str(output_path / "summary.json"),
            "errors": str(output_path / "errors.tsv"),
            "manifest": str(output_path / "manifest.json"),
        },
    }
    sidecars = write_standard_sidecars(
        output_path,
        command_name="classify-rrseq-cons-reactions",
        summary=summary,
        errors=errors,
        error_fieldnames=RXN_CLASS_ERROR_FIELDS,
        input_files=[*tsv_paths, *occurrence_paths],
        output_files=output_files,
        cli_args=cli_args,
        argv=argv,
        extra_manifest={
            "mode": mode,
            "backend": provider_name or backend,
            "taxonomy": taxonomy,
            "tier": int(tier),
            "label_policy": label_policy,
        },
    )
    return {**summary, "sidecar_files": sidecars}


def classify_reactions(args: ClassifyRrseqConsReactionsRequest) -> dict[str, Any]:
    """Run dynamic Tier-3 reaction-class sequence analysis from the CLI."""

    summary = classify_rrseq_cons_reactions(
        args.rrseq_cons_tsv,
        rrseq_cons_occurrences=args.rrseq_cons_occurrences,
        output_dir=args.output_dir,
        mode=args.mode,
        backend=args.backend,
        reaction_classifier_path=args.reaction_classifier_path,
        namerxn_executable=args.namerxn_executable,
        tier=args.tier,
        label_policy=args.label_policy,
        n_cpu=args.n_cpu,
        worker_chunksize=args.worker_chunksize,
        torch_threads=args.torch_threads,
        device=args.device,
        limit_rows=args.limit_rows,
        ignore_errors=args.ignore_errors,
        progress_interval=args.progress_interval,
        cli_args=args,
    )
    return summary


__all__ = ["classify_reactions", "classify_rrseq_cons_reactions"]
