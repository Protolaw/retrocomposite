"""Standalone boxed RRSeq diagrams from recorded rules and spacing evidence."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from route_inspector.rules.structure import RuleEdge, RuleNode, RuleTree
from route_inspector.visualization.rule_nodes import render_rule_tree


def _integers(values, name, *, size=None):
    if not isinstance(values, (list, tuple)) or (
        size is not None and len(values) != size
    ):
        raise ValueError(
            f"{name} must contain {size if size is not None else 'nonnegative'} integers"
        )
    if any(type(value) is not int or value < 0 for value in values):
        raise ValueError(f"{name} must contain nonnegative integers")
    return tuple(values)


def _paths(values, name, *, size=None):
    if not isinstance(values, (list, tuple)):
        raise ValueError(f"{name} must be a sequence of reaction-node paths")
    if size is not None and len(values) != size:
        raise ValueError(f"{name} must contain {size} reaction-node paths")
    paths = tuple(_integers(path, name) for path in values)
    if any(not path or len(path) % 2 != 1 for path in paths) or len(set(paths)) != len(
        paths
    ):
        raise ValueError(f"{name} must contain unique reaction-node paths")
    return paths


def _agree(candidates, name):
    if not candidates:
        return None
    first = candidates[0]
    if any(value != first for value in candidates[1:]):
        raise ValueError(f"{name} disagree with recorded occurrence evidence")
    return first


def _step_field(steps, field):
    present = [field in step for step in steps]
    if not any(present):
        return None
    if not all(present):
        raise ValueError(f"Incomplete selected-step {field} evidence")
    return [step[field] for step in steps]


def _sequence(value, separator):
    if isinstance(value, str):
        value = value.split(separator)
    if (
        not isinstance(value, (list, tuple))
        or not value
        or any(not isinstance(rule, str) or not rule.strip() for rule in value)
    ):
        raise ValueError("RRSeq requires a nonempty sequence of reaction SMARTS")
    return tuple(value)


def _prepare_sequence(value, separator, supplied_widths):
    if not isinstance(separator, str) or not separator:
        raise ValueError("RRSeq separator must be a nonempty string")
    if isinstance(value, str):
        payload, steps, gap = {}, (), False
        rules = _sequence(value, separator)
    elif isinstance(value, Mapping):
        payload = value
        gap = "selected_steps" in value or "RRseq_gap" in value
        steps = value.get("selected_steps" if gap else "source_matches", ())
        if not isinstance(steps, (list, tuple)) or any(
            not isinstance(step, Mapping) for step in steps
        ):
            raise ValueError("RRSeq selected steps must be a list of objects")
        raw = value.get("raw_sequence")
        if raw is None and gap and steps:
            raw = _step_field(steps, "rule_smarts")
        if raw is None:
            raw = value.get("RRseq_gap" if gap else "RRseq_cons")
        rules = _sequence(raw, separator)
        if steps and len(steps) != len(rules):
            raise ValueError("Selected-step count must match the rule sequence")
    else:
        raise ValueError(
            "RRSeq input must be an occurrence dictionary or serialized sequence"
        )
    count = len(rules)
    widths = []
    for vector in (supplied_widths, payload.get("inter_selection_gap_widths")):
        if vector is not None:
            widths.append(
                _integers(vector, "inter_selection_gap_widths", size=count - 1)
            )

    position_candidates = []
    for positions in (
        payload.get("selected_positions"),
        _step_field(steps, "position"),
        _step_field(steps, "path_position"),
    ):
        if positions is not None:
            position_candidates.append(
                _integers(positions, "selected positions", size=count)
            )
    positions = _agree(position_candidates, "Selected positions")
    if positions is not None:
        if any(b <= a for a, b in zip(positions, positions[1:])):
            raise ValueError("Selected positions must follow retrosynthetic order")
        widths.append(tuple(b - a - 1 for a, b in zip(positions, positions[1:])))

    path_candidates = []
    for paths in (
        payload.get("selected_reaction_node_paths"),
        _step_field(steps, "reaction_node_path"),
        # For gapped records this field covers the whole interval, not just boxes.
        payload.get("reaction_node_paths") if not gap else None,
    ):
        if paths is not None:
            path_candidates.append(_paths(paths, "Selected reaction paths", size=count))
    paths = _agree(path_candidates, "Selected reaction paths")
    edge_paths = None
    if paths is not None:
        edge_paths = []
        for parent, child in zip(paths, paths[1:]):
            if len(child) <= len(parent) or child[: len(parent)] != parent:
                raise ValueError(
                    "RRSeq reaction paths must follow one retrosynthetic chain"
                )
            edge_paths.append(
                tuple(
                    child[:length] for length in range(len(parent) + 2, len(child), 2)
                )
            )
        widths.append(tuple(map(len, edge_paths)))

    interval_paths = None
    if gap and payload.get("reaction_node_paths") is not None:
        interval_paths = _paths(
            payload["reaction_node_paths"], "Interval reaction paths"
        )
        if paths is None:
            raise ValueError("Interval reaction paths require selected reaction paths")
        expected_interval = (
            *(
                path
                for parent, between in zip(paths, edge_paths)
                for path in (parent, *between)
            ),
            paths[-1],
        )
        if interval_paths != expected_interval:
            raise ValueError("Interval reaction paths disagree with selected paths")

    spacing = _agree(widths, "Inter-selection gap widths")
    if spacing is None:
        if gap:
            raise ValueError(
                "RRSeq_gap requires full gap widths, selected positions, or exact reaction paths"
            )
        spacing = (0,) * (count - 1)
    if isinstance(value, str):
        gap = any(spacing)
    if gap != any(spacing):
        raise ValueError(
            "RRSeq_gap requires a positive gap; RRSeq_cons requires immediate steps"
        )
    if "gap_widths" in payload:
        recorded = _integers(payload["gap_widths"], "Historical gap_widths")
        if recorded != tuple(width for width in spacing if width):
            raise ValueError("Historical gap_widths disagree with full spacing")

    skipped = payload.get("skipped_steps")
    if skipped is not None:
        if not isinstance(skipped, (list, tuple)) or any(
            not isinstance(step, Mapping) for step in skipped
        ):
            raise ValueError("Skipped steps must be a list of objects")
        if len(skipped) != sum(spacing):
            raise ValueError("Skipped-step count disagrees with gap widths")
    skipped_path_candidates = []
    for skipped_paths in (
        payload.get("skipped_reaction_node_paths"),
        _step_field(skipped or (), "reaction_node_path"),
    ):
        if skipped_paths is not None:
            skipped_path_candidates.append(
                _paths(skipped_paths, "Skipped reaction paths", size=sum(spacing))
            )
    recorded_skipped = _agree(skipped_path_candidates, "Skipped reaction paths")
    skipped_positions = []
    for recorded in (
        payload.get("skipped_positions"),
        _step_field(skipped or (), "position"),
    ):
        if recorded is not None:
            numbers = _integers(recorded, "Skipped positions", size=sum(spacing))
            if len(set(numbers)) != len(numbers):
                raise ValueError("Skipped positions must be unique")
            skipped_positions.append(tuple(sorted(numbers)))
    recorded_positions = _agree(skipped_positions, "Skipped positions")
    if recorded_positions is not None and positions is not None:
        expected = tuple(
            n for a, b in zip(positions, positions[1:]) for n in range(a + 1, b)
        )
        if recorded_positions != expected:
            raise ValueError("Skipped positions disagree with selected positions")
    if recorded_skipped is not None and edge_paths is not None:
        if recorded_skipped != tuple(path for edge in edge_paths for path in edge):
            raise ValueError("Skipped reaction paths disagree with selected paths")
    elif interval_paths is None:
        edge_paths = None  # Width-only inputs do not invent recorded provenance.

    nodes = tuple(
        RuleNode(i, f"Step {i + 1}", rule, paths[i] if paths else None)
        for i, rule in enumerate(rules)
    )
    edges = tuple(
        RuleEdge(i, i + 1, width, edge_paths[i] if edge_paths is not None else None)
        for i, width in enumerate(spacing)
    )
    return RuleTree(nodes, edges), gap


def get_rrseq_svg(
    rrseq_occurrence: Mapping[str, Any] | str,
    *,
    separator: str = "$",
    inter_selection_gap_widths: Sequence[int] | None = None,
) -> str:
    """Draw selected rules top-to-bottom in their stored retrosynthetic order.

    Native gapped occurrences identify selected paths through selected steps or
    ``selected_reaction_node_paths``; ``reaction_node_paths`` covers the complete
    interval, including skipped steps, and is checked separately. Serialized strings
    default to consecutive; pass a complete inter-selection width vector for a
    gapped sequence, including zeros. Rule SMARTS are never reversed. Gap arrows
    show interrupting reaction counts; gapped sequences remain analysis-only.
    """
    tree, gap = _prepare_sequence(
        rrseq_occurrence, separator, inter_selection_gap_widths
    )
    captions = {
        node.key: node.label
        + (
            " · reaction " + "/".join(map(str, node.reaction_path))
            if node.reaction_path is not None
            else ""
        )
        for node in tree.nodes
    }
    title = f"RRSeq_{'gap' if gap else 'cons'} · retrosynthetic order"
    if gap:
        title += " · analysis-only"
    return render_rule_tree(
        tree,
        namespace="rrseq",
        title=title,
        positive_badge=not gap,
        gap_word="interrupting",
        captions=captions,
    )
