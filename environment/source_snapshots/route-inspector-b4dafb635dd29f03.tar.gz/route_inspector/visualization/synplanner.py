"""SynPlanner route geometry with Route Inspector's exact occurrence overlays.

The SVG presentation follows SynPlanner's MIT-licensed ``utils.routedraw``;
Tree packing, drawing copies and alignment are called upstream. Connected
row wrapping is a presentation-only Route Inspector layout.
No Route/RouteCGR reconstruction or modification of SynPlanner is required.
"""

# SVG presentation adapted from SynPlanner, distributed under the MIT License:
# Copyright (c) 2024 Laboratoire-de-Chemoinformatique
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import annotations

import copy
from functools import partial
from html import escape
from inspect import signature
from typing import Any, Mapping
from uuid import uuid4
from xml.etree import ElementTree as ET

import route_inspector.routes.access as route_access
from route_inspector.visualization import route as shared
from route_inspector.visualization.rule_nodes import _namespace_svg_ids
from route_inspector.visualization.synplanner_layers import (
    RouteScene,
    connected_layout,
    local_links,
    path_data,
    reaction_radius,
)


def _load_backend():
    """Load the SynPlanner drawing backend only when rendering a route."""
    try:
        from synplan.utils import align2d, routedraw, routelayout
    except ImportError as exc:
        raise RuntimeError(
            "Route visualization requires SynPlanner 1.8 drawing utilities "
            "(utils.routedraw, routelayout and align2d). Reinstall Route Inspector "
            "with its declared dependencies to install the pinned SynPlanner backend."
        ) from exc
    return routedraw, routelayout, align2d


def _require_compact_backend(backend):
    geometry = backend[1]
    if any(
        "compact" not in signature(function).parameters
        for function in (geometry.layout, geometry.edges)
    ):
        raise RuntimeError(
            "compact=True requires SynPlanner's compact-capable routelayout "
            "(as in SynPlanner-rescorer). Use that backend or set compact=False "
            "with an older renderer."
        )


def _depiction(molecule, prefix: str) -> tuple[str, tuple[float, ...]]:
    """Embed halos before bonds, using the final aligned molecule coordinates."""
    svg = molecule.depict()
    root = ET.fromstring(svg)
    box = tuple(float(value) for value in root.attrib["viewBox"].split())
    if len(box) != 4 or box[2] <= 0 or box[3] <= 0:
        raise ValueError("Chython molecule depiction has an invalid viewBox")
    halos = shared._atom_highlight_svg(molecule)
    # Include halos at boundary atoms in the molecule's viewport.
    x0, y0, width, height = box
    x1, y1 = x0 + width, y0 + height
    for halo in halos:
        attributes = ET.fromstring(halo).attrib
        x, y, radius = (float(attributes[key]) for key in ("cx", "cy", "r"))
        x0, x1 = min(x0, x - radius), max(x1, x + radius)
        y0, y1 = min(y0, y - radius), max(y1, y + radius)
    inner = svg[svg.index(">") + 1 : svg.rindex("</svg>")]
    return (
        _namespace_svg_ids("".join(halos) + inner, prefix),
        (x0, y0, x1 - x0, y1 - y0),
    )


def _drawing_tree(columns, pred, *, align: bool, backend, prefix: str, box_pad: float):
    draw, layout, align2d = backend
    molecules = [molecule for column in columns for molecule in column]
    copies = [draw.drawable_copy(molecule) for molecule in molecules]
    for original, drawing in zip(molecules, copies):
        drawing.meta.update(copy.deepcopy(original.meta))
    if align:
        # The prepared edges are parent-first, so each precursor inherits the
        # already aligned product's orientation. Never align parser-assigned IDs.
        for parent, child in pred:
            align2d.align_molecule(copies[child], copies[parent])
        draw.orient_route(copies)

    reaction_paths = []
    for molecule in copies:
        paths = molecule.meta["reaction_node_paths"]
        if len(paths) > 1:
            raise ValueError(
                "SynPlanner-style rendering requires one reaction per molecule; "
                f"multiple alternatives at path {list(molecule.meta['route_node_path'])}"
            )
        reaction_paths.extend(paths)
    numbers = {
        path: f"r{index}" for index, path in enumerate(sorted(reaction_paths), 1)
    }

    nodes, depictions = [], {}
    for index, molecule in enumerate(copies):
        path = molecule.meta["route_node_path"]
        inner, box = _depiction(molecule, f"{prefix}-mol{index}")
        node = layout.Node(
            key="/".join(map(str, path)),
            w=box[2] * draw.PX_PER_UNIT + 2 * box_pad,
            h=box[3] * draw.PX_PER_UNIT + 2 * box_pad,
        )
        node.molecule = molecule
        # Only explicit route-level maps establish atom contribution. Parser-
        # assigned IDs in an unmapped drawing are not correspondence evidence.
        node.mapped_atoms = (
            frozenset(
                (n, atom.atomic_number)
                for n, atom in molecule.atoms()
                if atom.atomic_number != 1
            )
            if align
            else frozenset()
        )
        paths = molecule.meta["reaction_node_paths"]
        node.reaction_path = paths[0] if paths else None
        node.number = numbers.get(node.reaction_path)
        node.label = molecule.meta.get("label", "")
        nodes.append(node)
        depictions[node.key] = inner, box
    for parent, child in pred:
        nodes[parent].children.append(nodes[child])
    for index, node in enumerate(nodes):
        node.role = (
            "target"
            if index == 0
            else "int"
            if node.reaction_path is not None
            else "bb"
            if node.molecule.meta["status"] == "instock"
            else "oos"
        )
    return nodes, depictions


def _panel_layout(nodes, *, backend, compact: bool, annotation_clearance: bool = False):
    draw, geometry, _align2d = backend
    root = nodes[0]
    # Reserve connector space for labels rather than covering molecule boxes.
    label_width = max((7 * len(str(node.label)) for node in nodes), default=0)
    # Match SynPlanner-rescorer's presets, preserving room for our rule labels.
    col_gap = 50.0 if compact else 74.0
    if annotation_clearance and label_width:
        # In wrapped drawings labels sit to the right of the vertical bus.
        col_gap = max(col_gap, (label_width + 48.0) / 0.58)
    row_gap = 20.0 if compact else draw.ROW_GAP
    # Omitting the keyword preserves compact=False support on older backends.
    layout_options = {"compact": True} if compact else {}
    width, height, col_x, col_w = geometry.layout(
        root,
        col_gap=max(col_gap, label_width + 48.0),
        row_gap=row_gap,
        **layout_options,
    )
    links = geometry.edges(root, col_x, col_w, **layout_options)
    return width, height, col_x, col_w, links


def _svg(
    nodes,
    depictions,
    *,
    backend,
    box_solid: bool,
    prefix: str,
    compact: bool,
    box_pad: float,
    scene: RouteScene | None = None,
) -> str:
    draw = backend[0]
    attributes = ""
    if scene is None:
        width, height, col_x, col_w, links = _panel_layout(
            nodes, backend=backend, compact=compact
        )
        links = local_links(links, col_x, col_w)
    else:
        nodes, links = scene.nodes, scene.links
        width, height = scene.width, scene.height
        spans = ",".join(str(row.reaction_span) for row in scene.rows)
        attributes = (
            f' data-layered="auto" data-layered-flow="{scene.flow}" data-row-count="{len(scene.rows)}"'
            f' data-row-spans="{spans}" data-longest-chain-length="{len(scene.chain) - 1}"'
        )
    margin, top = 14.0, 16.0
    canvas_width, canvas_height = width + 2 * margin, height + top + 2 * margin
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'xmlns:xlink="http://www.w3.org/1999/xlink" '
        f'width="{canvas_width:.1f}" height="{canvas_height:.1f}" '
        f'viewBox="0 0 {canvas_width:.1f} {canvas_height:.1f}"{attributes}>',
        f"<defs>{_namespace_svg_ids(draw.ARROW_DEFS, prefix)}</defs>",
        f"<style>{draw.ROUTE_CSS}</style>",
        f'<g transform="translate({margin},{top + margin})">',
    ]
    for edge in links:
        path = "/".join(map(str, edge.node.reaction_path))
        parts.append(
            f'<g class="ri-route-connection" data-reaction-path="{path}" '
            f'data-product-path="{edge.node.key}" '
            f'data-wrapped="{str(bool(edge.wrapped or edge.wrapped_inputs)).lower()}">'
        )
        # Forward layering wraps the lead; snake rows keep stock inputs local
        # and wrap only the incoming branch from the preceding row.
        dash = ' stroke-dasharray="6 4"' if scene is not None and edge.wrapped else ""
        for key, points in edge.inputs:
            input_dash = ' stroke-dasharray="6 4"' if key in edge.wrapped_inputs else ""
            parts.append(
                f'<path d="{path_data(points)}" class="sp-link" '
                f'data-reactant-path="{key}"{input_dash}/>'
            )
        parts.append(
            f'<path d="{path_data(edge.lead)}" class="sp-lead" '
            f'marker-end="url(#{prefix}-sp-arrow)"{dash}/>'
        )
        parts.append("</g>")

    for node in nodes:
        fill, stroke, stroke_width = draw.ROLE_STYLE[node.role]
        row_attribute = f' data-row="{node.row_index}"' if scene is not None else ""
        parts.append(
            f'<g class="ri-route-molecule" data-molecule-path="{node.key}" '
            f'data-molecule-role="{node.role}"{row_attribute}>'
            f'<rect x="{node.x:.1f}" y="{node.y:.1f}" width="{node.w:.1f}" '
            f'height="{node.h:.1f}" rx="5" fill="{fill if box_solid else "none"}" '
            f'stroke="{stroke}" stroke-width="{stroke_width}"/>'
        )
        inner, box = depictions[node.key]
        parts.append(
            f'<svg x="{node.x + box_pad:.1f}" y="{node.y + box_pad:.1f}" '
            f'width="{node.w - 2 * box_pad:.1f}" '
            f'height="{node.h - 2 * box_pad:.1f}" '
            f'viewBox="{" ".join(map(str, box))}">{inner}</svg>'
        )
        if node.role in draw.ROLE_CAPTION:
            caption, color = draw.ROLE_CAPTION[node.role]
            parts.append(
                f'<text x="{node.x + 1:.1f}" y="{node.y - 5:.1f}" '
                f'class="sp-tag" fill="{color}">{escape(caption)}</text>'
            )
        parts.append("</g>")

    for edge in links:
        node = edge.node
        lane, py = edge.junction
        path = "/".join(map(str, node.reaction_path))
        radius = reaction_radius(node)
        parts.append(
            f'<g class="ri-route-reaction" data-reaction-path="{path}" '
            f'data-reaction-step="{node.number}">'
            f'<circle cx="{lane:.1f}" cy="{py:.1f}" r="{radius:.1f}" '
            f'fill="#2b3440" stroke="#ffffff" stroke-width="2"/>'
            f'<text x="{lane:.1f}" y="{py:.1f}" class="sp-num">{node.number}</text>'
        )
        if node.label:
            label_x, label_y = edge.label_position
            parts.append(
                f'<text x="{label_x:.1f}" y="{label_y:.1f}" '
                'text-anchor="middle" font-family="monospace" font-size="11" '
                f'fill="#2b3440">{escape(str(node.label))}</text>'
            )
        parts.append("</g>")
    parts.append("</g></svg>")
    return "".join(parts)


def get_route_svg_from_json(
    routes_json: route_access.RouteCollection,
    route_id: Any,
    labeled: bool = False,
    box_solid: bool = True,
    *,
    compact: bool = True,
    layered: bool = False,
    layered_flow: str = "forward",
    rrseq_occurrence: Mapping[str, Any] | None = None,
    rrsubtree_occurrence: Mapping[str, Any] | None = None,
    retro_bleu_bigram_occurrence: Mapping[str, Any] | None = None,
    pg_strategy_occurrence: Mapping[str, Any] | None = None,
    highlight_skipped_steps: bool = False,
) -> str:
    """Render exact JSON paths using current SynPlanner geometry and motif halos.

    Current SynPlanner drawing utilities are required only when called. No
    RouteCGR is composed; neither the route nor global depiction settings change.
    Reaction markers always use Route Inspector's retrosynthetic rN positions;
    labeled controls rule keys, while recorded policy ranks remain visible.
    The single-tree compact layout uses 5 px box padding, 20 px row gaps and a minimum
    50 px column gap (expanded for labels), with contour-packed branches.
    Molecule scale and occurrence identity are unchanged. ``compact=False``
    restores the original spacious spacing and works with older drawing backends.
    ``layered=True`` measures boxes, labels and branch height to choose layer
    breaks automatically (usually 3–4 consecutive reactions, fewer for large
    structures). Rows read left-to-right, joined by continuous arrows, with the
    target on the bottom row. Each occurrence is drawn exactly once, without
    layout headings or continuation labels. Longest continuations stay on a
    horizontal baseline, with side inputs packed above or below using actual
    box/caption/label clearances. Only long wraparound leads between rows are
    dashed; within-row arrows and input branches remain solid. The default
    keeps the unchanged single-tree layout. Set ``layered_flow="snake"`` to
    alternate row direction, joining successive rows on the same side. Only
    geometry changes; molecule artwork and text are never mirrored.
    """
    if not isinstance(layered, bool):
        raise ValueError("layered must be True or False")
    if layered_flow not in ("forward", "snake"):
        raise ValueError("layered_flow must be 'forward' or 'snake'")
    root, columns, pred = shared._prepare_route_rendering(
        routes_json,
        route_id,
        labeled=labeled,
        rrseq_occurrence=rrseq_occurrence,
        rrsubtree_occurrence=rrsubtree_occurrence,
        retro_bleu_bigram_occurrence=retro_bleu_bigram_occurrence,
        pg_strategy_occurrence=pg_strategy_occurrence,
        highlight_skipped_steps=highlight_skipped_steps,
    )
    return _render_prepared_route(
        root,
        columns,
        pred,
        box_solid=box_solid,
        compact=compact,
        layered=layered,
        layered_flow=layered_flow,
    )


def _render_prepared_route(
    root,
    columns,
    pred,
    *,
    box_solid: bool,
    compact: bool = True,
    layered: bool = False,
    layered_flow: str = "forward",
) -> str:
    """Draw prepared molecules and exact highlights for route and dataset reports."""
    backend = _load_backend()
    if compact:
        _require_compact_backend(backend)
    box_pad = 5.0 if compact else backend[0].BOX_PAD
    prefix = f"ri-sp-{uuid4().hex}"
    nodes, depictions = _drawing_tree(
        columns,
        pred,
        align=shared._has_complete_mapped_molecule_nodes(root),
        backend=backend,
        prefix=prefix,
        box_pad=box_pad,
    )

    scene = (
        connected_layout(
            nodes[0],
            layered_flow=layered_flow,
            layout_tree=partial(
                _panel_layout, backend=backend, annotation_clearance=True
            ),
            compact=compact,
        )
        if layered
        else None
    )
    return _svg(
        nodes,
        depictions,
        backend=backend,
        box_solid=box_solid,
        prefix=prefix,
        compact=compact,
        box_pad=box_pad,
        scene=scene,
    )
