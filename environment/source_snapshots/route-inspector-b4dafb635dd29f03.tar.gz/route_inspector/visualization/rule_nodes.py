"""Shared boxed rule-node SVG layout for sequences and branched tactics."""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, replace
from html import escape
from typing import Mapping

from route_inspector.rules.structure import RuleNode, RuleTree
from route_inspector.visualization.depiction import depiction_settings

_RULE_MAX_WIDTH = 18.0
_RULE_MAX_HEIGHT = 7.0
_RULE_NODE_MIN_WIDTH = 6.0
_RULE_NODE_PADDING_X = 0.55
_RULE_NODE_PADDING_TOP = 0.25
_RULE_NODE_PADDING_BOTTOM = 0.40
_RULE_NODE_CAPTION_HEIGHT = 0.75
_RULE_SIBLING_GAP = 2.0
_RULE_LEVEL_GAP = 3.2
_RULE_CANVAS_MARGIN = 0.8
_RULE_HEADER_HEIGHT = 2.0
_RULE_LEGEND_HEIGHT = 1.2
_RULE_VIEWBOX_PATTERN = re.compile(r'\bviewBox="\s*([^\"]+)"')
_RULE_ID_PATTERN = re.compile(r'\bid="([^\"]+)"')


@dataclass(frozen=True)
class _RuleDepiction:
    """One namespaced Chython rule SVG and its outer node dimensions."""

    node_key: int
    inner_svg: str
    view_box: tuple[float, float, float, float]
    rendered_width: float
    rendered_height: float
    node_width: float
    node_height: float


def _reaction_path_text(path: tuple[int, ...]) -> str:
    return "/".join(str(index) for index in path)


def _namespace_svg_ids(svg_text: str, prefix: str) -> str:
    """Prefix local SVG identifiers and every supported local reference."""

    identifiers = sorted(
        set(_RULE_ID_PATTERN.findall(svg_text)),
        key=len,
        reverse=True,
    )
    for identifier in identifiers:
        replacement = f"{prefix}-{identifier}"
        svg_text = svg_text.replace(
            f'id="{identifier}"',
            f'id="{replacement}"',
        )
        svg_text = svg_text.replace(
            f"url(#{identifier})",
            f"url(#{replacement})",
        )
        svg_text = svg_text.replace(
            f'href="#{identifier}"',
            f'href="#{replacement}"',
        )
    return svg_text


def _rule_depiction(
    node: RuleNode,
    *,
    index: int,
    namespace: str,
) -> _RuleDepiction:
    from chython import smarts
    from chython.containers import ReactionContainer

    location = (
        f"reaction path {list(node.reaction_path)}"
        if node.reaction_path is not None
        else f"node {node.label}"
    )
    try:
        rule = smarts(node.rule_smarts)
        if (
            not isinstance(rule, ReactionContainer)
            or not rule.reactants
            or not rule.products
        ):
            raise ValueError(
                "expected reaction SMARTS with nonempty reactants and products"
            )
        svg_text = rule._repr_svg_()
    except Exception as exc:
        raise ValueError(
            f"could not render {namespace} rule at {location}: {exc}"
        ) from exc
    if not isinstance(svg_text, str):
        raise ValueError(
            f"could not render {namespace} rule at {location}: Chython returned no SVG"
        )

    opening_end = svg_text.find(">")
    closing_start = svg_text.rfind("</svg>")
    view_box_match = _RULE_VIEWBOX_PATTERN.search(svg_text[: opening_end + 1])
    if opening_end < 0 or closing_start <= opening_end or view_box_match is None:
        raise ValueError(
            f"could not render {namespace} rule at {location}: malformed Chython SVG"
        )
    try:
        view_box = tuple(float(value) for value in view_box_match.group(1).split())
    except ValueError as exc:
        raise ValueError(
            f"could not render {namespace} rule at {location}: invalid SVG viewBox"
        ) from exc
    if len(view_box) != 4 or view_box[2] <= 0 or view_box[3] <= 0:
        raise ValueError(
            f"could not render {namespace} rule at {location}: invalid SVG viewBox"
        )

    inner_svg = _namespace_svg_ids(
        svg_text[opening_end + 1 : closing_start],
        f"{namespace}-rule-{index}",
    )
    scale = min(
        1.0,
        _RULE_MAX_WIDTH / view_box[2],
        _RULE_MAX_HEIGHT / view_box[3],
    )
    rendered_width = view_box[2] * scale
    rendered_height = view_box[3] * scale
    node_width = max(
        _RULE_NODE_MIN_WIDTH,
        rendered_width + 2.0 * _RULE_NODE_PADDING_X,
    )
    node_height = (
        _RULE_NODE_PADDING_TOP
        + _RULE_NODE_CAPTION_HEIGHT
        + rendered_height
        + _RULE_NODE_PADDING_BOTTOM
    )
    return _RuleDepiction(
        node_key=node.key,
        inner_svg=inner_svg,
        view_box=view_box,
        rendered_width=rendered_width,
        rendered_height=rendered_height,
        node_width=node_width,
        node_height=node_height,
    )


def _rule_layout(
    tree: RuleTree,
    depictions: Mapping[int, _RuleDepiction],
) -> tuple[
    dict[int, tuple[float, float]],
    dict[int, tuple[int, ...]],
    float,
    float,
]:
    children: dict[int, list[int]] = {node.key: [] for node in tree.nodes}
    for edge in tree.edges:
        children[edge.parent].append(edge.child)
    ordered_children = {path: tuple(sorted(paths)) for path, paths in children.items()}

    depths = {0: 0}
    pending = [0]
    while pending:
        parent = pending.pop()
        for child in reversed(ordered_children[parent]):
            depths[child] = depths[parent] + 1
            pending.append(child)

    row_heights: dict[int, float] = defaultdict(float)
    for path, depth in depths.items():
        row_heights[depth] = max(row_heights[depth], depictions[path].node_height)
    row_y: dict[int, float] = {}
    y_cursor = _RULE_HEADER_HEIGHT
    for depth in range(max(row_heights) + 1):
        row_y[depth] = y_cursor
        y_cursor += row_heights[depth] + _RULE_LEVEL_GAP

    spans: dict[int, float] = {}

    def subtree_span(path: int) -> float:
        child_paths = ordered_children[path]
        child_span = sum(
            subtree_span(child) for child in child_paths
        ) + _RULE_SIBLING_GAP * max(0, len(child_paths) - 1)
        spans[path] = max(depictions[path].node_width, child_span)
        return spans[path]

    content_width = subtree_span(0)
    positions: dict[int, tuple[float, float]] = {}

    def place(path: int, left: float) -> None:
        span = spans[path]
        depiction = depictions[path]
        positions[path] = (
            left + (span - depiction.node_width) / 2.0,
            row_y[depths[path]],
        )
        child_paths = ordered_children[path]
        if not child_paths:
            return
        child_block_width = sum(
            spans[child] for child in child_paths
        ) + _RULE_SIBLING_GAP * (len(child_paths) - 1)
        child_left = left + (span - child_block_width) / 2.0
        for child in child_paths:
            place(child, child_left)
            child_left += spans[child] + _RULE_SIBLING_GAP

    place(0, _RULE_CANVAS_MARGIN)
    canvas_width = content_width + 2.0 * _RULE_CANVAS_MARGIN
    canvas_height = (
        y_cursor - _RULE_LEVEL_GAP + _RULE_LEGEND_HEIGHT + _RULE_CANVAS_MARGIN
    )
    return positions, ordered_children, canvas_width, canvas_height


@depiction_settings(aam=False, monochrome=False)
def render_rule_tree(
    tree: RuleTree,
    *,
    namespace: str,
    title: str,
    positive_badge: bool,
    view: str = "rules",
    gap_word: str = "skipped",
    captions: Mapping[int, str] | None = None,
) -> str:
    """Render a prepared tree or chain without changing its rule direction."""
    depictions = {
        node.key: _rule_depiction(node, index=index, namespace=namespace)
        for index, node in enumerate(tree.nodes)
    }
    if captions is not None:
        depictions = {
            key: replace(
                depiction,
                node_width=max(depiction.node_width, 0.20 * len(captions[key]) + 1.1),
            )
            for key, depiction in depictions.items()
        }
    layout_depictions = (
        {
            key: replace(depiction, node_width=3.0, node_height=1.3)
            for key, depiction in depictions.items()
        }
        if view == "compact"
        else depictions
    )
    positions, _children, content_width, content_height = _rule_layout(
        tree,
        layout_depictions,
    )

    badge_width = 0.23 * len(title) + 1.0
    legend_width = 16.0
    # Compact view includes one depiction per distinct legend label, in preorder.
    legend_by_label = {}
    for node in tree.nodes:
        legend_by_label.setdefault(node.label, node)
    legend_nodes = list(legend_by_label.values())
    rule_legend_width = (
        max(depictions[node.key].node_width for node in legend_nodes)
        + 2 * _RULE_CANVAS_MARGIN
        if view == "compact"
        else 0.0
    )
    canvas_width = max(
        content_width, badge_width + 1.0, legend_width, rule_legend_width
    )
    x_offset = (canvas_width - content_width) / 2.0
    canvas_height = content_height
    badge_fill, badge_stroke = (
        ("#E8F5E9", "#2E7D32") if positive_badge else ("#FFF4E5", "#B45309")
    )
    badge_x = (canvas_width - badge_width) / 2.0
    legend_y = canvas_height - _RULE_LEGEND_HEIGHT
    rule_legend_start = canvas_height + 0.5
    if view == "compact":
        canvas_height = (
            rule_legend_start
            + sum(depictions[node.key].node_height + 0.6 for node in legend_nodes)
            + _RULE_CANVAS_MARGIN
        )

    svg = [
        f'<svg width="{0.6 * canvas_width:.2f}cm" '
        f'height="{0.6 * canvas_height:.2f}cm" '
        f'viewBox="0 0 {canvas_width:.2f} {canvas_height:.2f}" '
        'xmlns="http://www.w3.org/2000/svg" '
        'xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1">',
        "  <defs>",
        f'    <marker id="{namespace}-logical-arrow" markerWidth="8" '
        'markerHeight="8" refX="7" refY="3" orient="auto" '
        'markerUnits="strokeWidth">',
        '      <path d="M0,0 L0,6 L8,3 z" fill="#334155"/>',
        "    </marker>",
        "  </defs>",
        f'  <rect class="{namespace}-continuity-badge" x="{badge_x:.2f}" '
        f'y="0.30" width="{badge_width:.2f}" height="0.85" rx="0.18" '
        f'fill="{badge_fill}" stroke="{badge_stroke}" stroke-width="0.04"/>',
        f'  <text class="{namespace}-continuity-label" '
        f'x="{canvas_width / 2.0:.2f}" y="0.73" text-anchor="middle" '
        'dominant-baseline="central" font-family="sans-serif" '
        f'font-size="0.38" fill="{badge_stroke}">{escape(title)}</text>',
    ]

    node_by_key = {node.key: node for node in tree.nodes}
    for edge in tree.edges:
        parent_path = edge.parent
        child_path = edge.child
        parent_depiction = layout_depictions[parent_path]
        child_depiction = layout_depictions[child_path]
        parent_x, parent_y = positions[parent_path]
        child_x, child_y = positions[child_path]
        start_x = x_offset + parent_x + parent_depiction.node_width / 2.0
        start_y = parent_y + parent_depiction.node_height
        end_x = x_offset + child_x + child_depiction.node_width / 2.0
        end_y = child_y
        middle_y = start_y + (end_y - start_y) / 2.0
        skipped_count = edge.skipped_count
        edge_class = "gapped" if skipped_count else "immediate"
        dash = ' stroke-dasharray="0.35 0.25"' if skipped_count else ""
        skipped_paths = ";".join(
            _reaction_path_text(path) for path in (edge.skipped_paths or ())
        )
        provenance = ""
        if edge.skipped_paths is not None:
            provenance = (
                f'data-parent-reaction-path="{_reaction_path_text(node_by_key[edge.parent].reaction_path)}" '
                f'data-child-reaction-path="{_reaction_path_text(node_by_key[edge.child].reaction_path)}" '
                f'data-skipped-reaction-paths="{escape(skipped_paths)}" '
            )
        svg.append(
            f'  <path class="{namespace}-edge {namespace}-edge-{edge_class}" '
            f"{provenance}"
            f'data-parent-node="{edge.parent}" data-child-node="{edge.child}" '
            f'data-skipped-count="{skipped_count}" '
            f'd="M {start_x:.2f} {start_y:.2f} V {middle_y:.2f} '
            f'H {end_x:.2f} V {end_y - 0.12:.2f}" fill="none" '
            f'stroke="#334155" stroke-width="0.07"{dash} '
            f'marker-end="url(#{namespace}-logical-arrow)">'
            f"<title>{skipped_count} {gap_word} reaction"
            f"{'s' if skipped_count != 1 else ''}: "
            f"{escape(skipped_paths) if skipped_paths else ('provenance unavailable' if edge.skipped_paths is None else 'none')}</title></path>"
        )
        if skipped_count:
            label = f"{skipped_count} {gap_word} reaction{'s' if skipped_count != 1 else ''}"
            label_width = 0.20 * len(label) + 0.45
            label_x = end_x
            label_y = middle_y + (end_y - middle_y) / 2.0
            svg.extend(
                [
                    f'  <rect class="{namespace}-gap-label-background" '
                    f'x="{label_x - label_width / 2.0:.2f}" '
                    f'y="{label_y - 0.28:.2f}" width="{label_width:.2f}" '
                    'height="0.56" rx="0.10" fill="white" '
                    'stroke="#64748B" stroke-width="0.025"/>',
                    f'  <text class="{namespace}-gap-label" '
                    f'x="{label_x:.2f}" y="{label_y:.2f}" '
                    'text-anchor="middle" dominant-baseline="central" '
                    'font-family="sans-serif" font-size="0.30" '
                    f'fill="#334155">{label}</text>',
                ]
            )

    def append_node(
        node: RuleNode, node_x: float, node_y: float, *, compact: bool = False
    ) -> None:
        depiction = layout_depictions[node.key] if compact else depictions[node.key]
        nested_x = (depiction.node_width - depiction.rendered_width) / 2.0
        nested_y = _RULE_NODE_PADDING_TOP + _RULE_NODE_CAPTION_HEIGHT
        view_x, view_y, view_width, view_height = depiction.view_box
        path_text = (
            _reaction_path_text(node.reaction_path)
            if node.reaction_path is not None
            else None
        )
        caption = (
            f"reaction {path_text}"
            if path_text is not None and view == "rules"
            else node.label
            + (
                f" · reaction {path_text}"
                if path_text is not None and not compact
                else ""
            )
        )
        if captions is not None:
            caption = captions[node.key]
        path_attribute = (
            f'data-reaction-path="{escape(path_text)}" '
            if path_text is not None
            else ""
        )
        if captions is not None:
            path_attribute += f'data-sequence-position="{node.key + 1}" '
        svg.extend(
            [
                f'  <g class="{namespace}-rule-node" '
                f"{path_attribute}"
                f'transform="translate({node_x:.2f} {node_y:.2f})" '
                f'data-node-id="{node.key}" data-rule-label="{escape(node.label)}" '
                f'data-rule-smarts="{escape(node.rule_smarts)}">',
                f'    <rect x="0" y="0" width="{depiction.node_width:.2f}" '
                f'height="{depiction.node_height:.2f}" rx="0.22" '
                'fill="#FFFFFF" stroke="#2563EB" stroke-width="0.06"/>',
                f'    <text class="{namespace}-reaction-path-label" '
                f'x="{depiction.node_width / 2.0:.2f}" y="0.50" '
                'text-anchor="middle" dominant-baseline="central" '
                'font-family="monospace" font-size="0.32" '
                f'fill="#1E3A8A">{escape(caption)}</text>',
            ]
        )
        if not compact:
            svg.extend(
                [
                    f'    <svg class="{namespace}-rule-svg" data-rule-index="{node.key}" '
                    f'x="{nested_x:.2f}" y="{nested_y:.2f}" '
                    f'width="{depiction.rendered_width:.2f}" '
                    f'height="{depiction.rendered_height:.2f}" '
                    f'viewBox="{view_x:.2f} {view_y:.2f} '
                    f'{view_width:.2f} {view_height:.2f}">',
                    depiction.inner_svg,
                    "    </svg>",
                ]
            )
        svg.append("  </g>")

    for node in tree.nodes:
        node_x, node_y = positions[node.key]
        append_node(node, node_x + x_offset, node_y, compact=view == "compact")

    if view == "compact":
        svg.append(f'  <g class="{namespace}-chemical-rule-legend">')
        y_cursor = rule_legend_start
        for node in legend_nodes:
            depiction = depictions[node.key]
            append_node(node, (canvas_width - depiction.node_width) / 2.0, y_cursor)
            y_cursor += depiction.node_height + 0.6
        svg.append("  </g>")

    immediate_x = (canvas_width - legend_width) / 2.0
    dashed_x = immediate_x + 7.6
    svg.extend(
        [
            f'  <line x1="{immediate_x:.2f}" y1="{legend_y + 0.45:.2f}" '
            f'x2="{immediate_x + 1.1:.2f}" y2="{legend_y + 0.45:.2f}" '
            'stroke="#334155" stroke-width="0.07"/>',
            f'  <text x="{immediate_x + 1.35:.2f}" '
            f'y="{legend_y + 0.45:.2f}" dominant-baseline="central" '
            'font-family="sans-serif" font-size="0.30" fill="#334155">'
            "immediate relation</text>",
            f'  <line x1="{dashed_x:.2f}" y1="{legend_y + 0.45:.2f}" '
            f'x2="{dashed_x + 1.1:.2f}" y2="{legend_y + 0.45:.2f}" '
            'stroke="#334155" stroke-width="0.07" '
            'stroke-dasharray="0.35 0.25"/>',
            f'  <text x="{dashed_x + 1.35:.2f}" '
            f'y="{legend_y + 0.45:.2f}" dominant-baseline="central" '
            'font-family="sans-serif" font-size="0.30" fill="#334155">'
            f"span with {gap_word} reactions</text>",
            "</svg>",
        ]
    )
    return "\n".join(svg)
