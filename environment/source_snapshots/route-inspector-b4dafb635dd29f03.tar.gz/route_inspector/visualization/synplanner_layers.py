"""Connected, automatically wrapped synthesis drawings (presentation only)."""

from __future__ import annotations

from copy import copy
from dataclasses import dataclass
from math import ceil
from typing import Any

ROW_WIDTH_TARGET = 1400.0
ROW_HEIGHT_TARGET = 900.0
PREFERRED_MAX_REACTIONS = 4
LANE_GAP = 20.0
Point = tuple[float, float]


@dataclass
class ReactionDrawing:
    node: Any
    inputs: list[tuple[str, list[Point]]]
    lead: list[Point]
    junction: Point
    label_position: Point
    wrapped: bool = False
    wrapped_inputs: frozenset[str] = frozenset()


@dataclass
class RouteForest:
    nodes: list[Any]
    links: list[ReactionDrawing]
    width: float
    height: float
    y: float = 0.0


@dataclass
class RouteRow:
    nodes: list[Any]
    links: list[ReactionDrawing]
    high_depth: int
    low_depth: int
    reaction_span: int
    width: float
    height: float
    left_pad: float
    forests: list[RouteForest]
    y: float = 0.0


@dataclass
class RouteScene:
    nodes: list[Any]
    links: list[ReactionDrawing]
    rows: list[RouteRow]
    chain: tuple[str, ...]
    width: float
    height: float
    flow: str = "forward"


def reaction_radius(node) -> float:
    return max(10.5, 3.5 * len(getattr(node, "number", "") or "") + 3)


def contribution(parent, child):
    """Retained mapped heavy atoms, not reactant size or rendered box area."""
    return len(
        getattr(parent, "mapped_atoms", frozenset())
        & getattr(child, "mapped_atoms", frozenset())
    )


def main_child(node, heights, *, contributors=False):
    return max(
        node.children,
        key=lambda c: (heights[c.key], contribution(node, c) if contributors else 0),
    )


def longest_chain(root, *, contributors=False) -> tuple[str, ...]:
    """Longest continuation, optionally resolving ties by atom contribution."""
    candidates = [
        (
            longest_chain(c, contributors=contributors),
            contribution(root, c) if contributors else 0,
        )
        for c in root.children
    ]
    suffix = max(candidates, key=lambda item: (len(item[0]), item[1]), default=((), 0))[
        0
    ]
    return (root.key, *suffix)


def local_links(links, col_x, col_w, *, after_junction=False) -> list[ReactionDrawing]:
    """Translate upstream connector geometry into the shared drawing format."""
    result = []
    for edge in links:
        node = edge["node"]
        lane, (px, py) = edge["lane"], edge["parent"]
        right = col_x[node.depth + 1] + col_w[node.depth + 1]
        result.append(
            ReactionDrawing(
                node,
                [
                    (child.key, [(cx, cy), (lane, cy), (lane, py)])
                    for child, (cx, cy) in zip(node.children, edge["children"])
                ],
                [(lane, py), (px, py)],
                (lane, py),
                (
                    (px + (lane if after_junction else right)) / 2,
                    py + reaction_radius(node) + 14,
                ),
            )
        )
    return result


def _translate(nodes, links, dx, dy):
    def shift(point):
        return point[0] + dx, point[1] + dy

    for node in nodes:
        node.x += dx
        node.y += dy
    for edge in links:
        edge.inputs = [(key, list(map(shift, path))) for key, path in edge.inputs]
        edge.lead = list(map(shift, edge.lead))
        edge.junction = shift(edge.junction)
        edge.label_position = shift(edge.label_position)


def _place_spines(root, heights, *, compact, side="greedy", contributors=False):
    """Keep each longest continuation level; pack side trees above or below.

    Even contour slots hold molecule/caption boxes; odd slots hold reaction
    buses and labels. Packing both keeps connectors out of other branches.
    All subtrees are returned with their root centre at zero, so adding a side
    input never displaces the main-chain baseline.
    """
    gap = 12.0 if compact else 20.0

    def deepest(node):
        return (
            max(node.depth, *(deepest(c) for c in node.children))
            if node.children
            else node.depth
        )

    last_depth = deepest(root)

    def merge(upper, lower, other_upper, other_lower, shift=0.0):
        for slot in other_upper:
            upper[slot] = min(upper.get(slot, float("inf")), other_upper[slot] + shift)
            lower[slot] = max(lower.get(slot, -float("inf")), other_lower[slot] + shift)

    def place(node):
        node.y = -node.h / 2
        caption = (
            16.0 if getattr(node, "role", None) in {"target", "bb", "oos"} else 0.0
        )
        upper = {2 * node.depth: node.y - caption}
        lower = {2 * node.depth: node.h / 2}
        if getattr(node, "carry_from_left", False):
            for slot in range(2 * node.depth, 2 * last_depth + 1):
                upper[slot], lower[slot] = 0.0, 0.0
        if node.children or node.incoming_reaction:
            radius = reaction_radius(node)
            upper[2 * node.depth + 1] = -radius
            lower[2 * node.depth + 1] = radius + (17 if node.label else 0)
        members = [node]
        if not node.children:
            return members, upper, lower
        main = main_child(node, heights, contributors=contributors)
        main_nodes, main_upper, main_lower = place(main)
        members.extend(main_nodes)
        merge(upper, lower, main_upper, main_lower)
        for child in node.children:
            if child is main:
                continue
            side_nodes, side_upper, side_lower = place(child)
            shared = upper.keys() & side_upper.keys()
            above = min(upper[s] - gap - side_lower[s] for s in shared)
            below = max(lower[s] + gap - side_upper[s] for s in shared)

            def score(shift):
                top = min(min(upper.values()), min(side_upper.values()) + shift)
                bottom = max(max(lower.values()), max(side_lower.values()) + shift)
                # Prefer below on exact ties; source order settles sibling ties.
                return bottom - top, abs(shift), shift < 0

            if len(node.children) == 2 and side != "greedy":
                shift = above if side == "above" else below
            else:
                shift = min((above, below), key=score)
            for descendant in side_nodes:
                descendant.y += shift
            members.extend(side_nodes)
            merge(upper, lower, side_upper, side_lower, shift)
            slot = 2 * node.depth + 1
            upper[slot] = min(upper[slot], shift)
            lower[slot] = max(lower[slot], shift)
        return members, upper, lower

    members, upper, lower = place(root)
    top = min(upper.values())
    for node in members:
        node.y -= top
    return max(lower.values()) - top


def _measure_row(columns, high, low, span, *, layout_tree, compact, heights):
    """Pack disjoint occurrence subtrees into a depth band.

    Only temporary layout copies omit boundary edges. The complete original
    topology reconnects the bands afterwards; no boundary molecule is repeated.
    """
    forests = []
    for source in columns[low]:
        copies = []

        def clip(node, depth):
            drawing = copy(node)
            drawing.children = []
            copies.append(drawing)
            drawing.incoming_reaction = depth == high and bool(node.children)
            if depth < high:
                drawing.children = [clip(child, depth + 1) for child in node.children]
            return drawing

        clip(source, low)
        width, _height, col_x, col_w, links = layout_tree(copies, compact=compact)
        height = _place_spines(copies[0], heights, compact=compact)
        for edge in links:
            node = edge["node"]
            edge["parent"] = (node.x, node.y + node.h / 2)
            edge["children"] = [(c.x + c.w, c.y + c.h / 2) for c in node.children]
        links = local_links(links, col_x, col_w, after_junction=True)
        forests.append(RouteForest(copies, links, width, height))

    incoming = [node for node in columns[high] if node.children]
    label_width = max((7 * len(str(node.label or "")) for node in incoming), default=0)
    left_pad = label_width + 70 + LANE_GAP * (len(incoming) - 1) if incoming else 0
    outgoing_count = (
        len([node for node in columns[low - 1] if node.children]) if low else 0
    )
    right_pad = 16 + LANE_GAP * outgoing_count if outgoing_count else 0
    content_width = max(forest.width for forest in forests)
    nodes, links, cursor = [], [], 0.0
    for forest in forests:
        forest.y = cursor
        _translate(
            forest.nodes, forest.links, left_pad + content_width - forest.width, cursor
        )
        nodes.extend(forest.nodes)
        links.extend(forest.links)
        cursor += forest.height + (12 if compact else 20)
    height = cursor - (12 if compact else 20)
    return RouteRow(
        nodes,
        links,
        high,
        low,
        span,
        left_pad + content_width + right_pad,
        height,
        left_pad,
        forests,
    )


def _reflect_row(row, width):
    """Reflect geometry only: molecule artwork and text remain upright."""

    def reflect(point):
        return width - point[0], point[1]

    for node in row.nodes:
        node.x = width - node.x - node.w
    for edge in row.links:
        edge.inputs = [(key, list(map(reflect, path))) for key, path in edge.inputs]
        edge.lead = list(map(reflect, edge.lead))
        edge.junction = reflect(edge.junction)
        edge.label_position = reflect(edge.label_position)


def connected_layout(
    root, *, layout_tree, compact=True, layered_flow="forward"
) -> RouteScene:
    """Place forward-synthesis rows top-to-bottom with optional alternating flow.

    Every occurrence belongs to exactly one row. Width/height targets are soft:
    an indivisible oversized step is allowed to overflow, never rescaled.
    Longest continuations retain a horizontal baseline; side inputs occupy the
    above/below position with the smaller height, with stable source-order ties.
    Forward flow retains the original depth-band layout. Snake flow additionally
    keeps stock with its consumer and jointly chooses row breaks; see
    :mod:`synplanner_snake`. Neither flow reflects molecule artwork.
    """
    if layered_flow not in ("forward", "snake"):
        raise ValueError("layered_flow must be 'forward' or 'snake'")
    columns, originals, heights, parents, sibling_order = {}, {}, {}, {}, {}

    def visit(node, depth):
        if node.key in originals:
            raise ValueError(f"Duplicate drawing occurrence: {node.key!r}")
        originals[node.key] = node
        columns.setdefault(depth, []).append(node)
        for index, child in enumerate(node.children):
            parents[child.key] = node.key
            sibling_order[child.key] = index
            visit(child, depth + 1)
        heights[node.key] = max((heights[c.key] + 1 for c in node.children), default=0)

    visit(root, 0)
    chain = longest_chain(root, contributors=layered_flow == "snake")
    if layered_flow == "snake":
        from .synplanner_snake import snake_layout

        return snake_layout(
            columns=columns,
            originals=originals,
            heights=heights,
            parents=parents,
            sibling_order=sibling_order,
            chain=chain,
            layout_tree=layout_tree,
            compact=compact,
        )
    high, first, rows = len(chain) - 1, True, []
    while high >= 0:
        remaining = high if first else high + 1
        ideal = (
            ceil(remaining / ceil(remaining / PREFERRED_MAX_REACTIONS))
            if remaining
            else 0
        )
        candidates = (
            sorted(
                range(1, min(PREFERRED_MAX_REACTIONS, remaining) + 1),
                key=lambda span: (abs(span - ideal), -span),
            )
            if remaining
            else [0]
        )
        measured = []
        for span in candidates:
            low = high - span + (0 if first else 1)
            row = _measure_row(
                columns,
                high,
                low,
                span,
                layout_tree=layout_tree,
                compact=compact,
                heights=heights,
            )
            measured.append(row)
            # Include margins and the outgoing connector gutter in the budget.
            gutter = 48 + LANE_GAP * len(columns.get(low - 1, [])) if low else 0
            if (
                row.width + 28 <= ROW_WIDTH_TARGET
                and row.height + gutter + 44 <= ROW_HEIGHT_TARGET
            ):
                break
        else:
            row = min(measured, key=lambda band: band.reaction_span)
        rows.append(row)
        high, first = row.low_depth - 1, False

    # Packing above/below can change the visual order of boundary consumers.
    # Reorder entire upstream forest blocks to match that order, working back
    # from the target. Thus wrapping never crosses unrelated reaction buses.
    for upper, lower in reversed(list(zip(rows, rows[1:]))):
        consumers = {node.key: node for node in lower.nodes}
        upper.forests.sort(
            key=lambda forest: (
                consumers[parents[forest.nodes[0].key]].y
                + consumers[parents[forest.nodes[0].key]].h / 2,
                sibling_order[forest.nodes[0].key],
            ),
        )
        cursor = 0.0
        for forest in upper.forests:
            _translate(forest.nodes, forest.links, 0, cursor - forest.y)
            forest.y = cursor
            cursor += forest.height + (12 if compact else 20)

    width = max(row.width for row in rows)
    nodes, links, y = [], [], 0.0
    for index, row in enumerate(rows):
        row.y = y
        _translate(row.nodes, row.links, 0, y)
        for node in row.nodes:
            node.row_index = index
        nodes.extend(row.nodes)
        links.extend(row.links)
        y += row.height
        if row.low_depth:
            y += 48 + LANE_GAP * len(columns[row.low_depth - 1])

    by_key = {node.key: node for node in nodes}
    for upper, lower in zip(rows, rows[1:]):
        products = [
            by_key[node.key] for node in columns[lower.high_depth] if node.children
        ]
        products.sort(key=lambda node: node.y + node.h / 2)
        right = max(node.x + node.w for node in upper.nodes)
        for index, node in enumerate(products):
            # Nested lanes preserve source order without false branch junctions.
            track = len(products) - index - 1
            exit_x = right + 16 + track * LANE_GAP
            entry_x = 16 + track * LANE_GAP
            gutter_y = upper.y + upper.height + 24 + track * LANE_GAP
            children = [by_key[child.key] for child in originals[node.key].children]
            centres = [child.y + child.h / 2 for child in children]
            exit_y = (min(centres) + max(centres)) / 2
            py = node.y + node.h / 2
            links.append(
                ReactionDrawing(
                    node,
                    [
                        (
                            child.key,
                            [(child.x + child.w, cy), (exit_x, cy), (exit_x, exit_y)],
                        )
                        for child, cy in zip(children, centres)
                    ],
                    [
                        (exit_x, exit_y),
                        (exit_x, gutter_y),
                        (entry_x, gutter_y),
                        (entry_x, py),
                        (node.x, py),
                    ],
                    (lower.left_pad - 24, py),
                    ((entry_x + node.x) / 2, py + reaction_radius(node) + 14),
                    wrapped=True,
                )
            )

    for node in nodes:
        node.children = [by_key[child.key] for child in originals[node.key].children]
    return RouteScene(nodes, links, rows, chain, width, y, layered_flow)


def path_data(points: list[Point]) -> str:
    """Rounded orthogonal polyline; keep endpoints at actual node ports."""
    distinct = []
    for point in points:
        if not distinct or point != distinct[-1]:
            distinct.append(point)
    parts = [f"M{distinct[0][0]:.1f} {distinct[0][1]:.1f}"]
    for before, corner, after in zip(distinct, distinct[1:], distinct[2:]):
        incoming = (corner[0] - before[0], corner[1] - before[1])
        outgoing = (after[0] - corner[0], after[1] - corner[1])
        len_in, len_out = sum(map(abs, incoming)), sum(map(abs, outgoing))
        if incoming[0] * outgoing[1] == incoming[1] * outgoing[0]:
            parts.append(f"L{corner[0]:.1f} {corner[1]:.1f}")
            continue
        radius = min(16.0, len_in / 2, len_out / 2)
        start = tuple(corner[i] - incoming[i] / len_in * radius for i in range(2))
        end = tuple(corner[i] + outgoing[i] / len_out * radius for i in range(2))
        parts.append(
            f"L{start[0]:.1f} {start[1]:.1f} Q{corner[0]:.1f} {corner[1]:.1f} {end[0]:.1f} {end[1]:.1f}"
        )
    if len(distinct) > 1:
        parts.append(f"L{distinct[-1][0]:.1f} {distinct[-1][1]:.1f}")
    return " ".join(parts)
