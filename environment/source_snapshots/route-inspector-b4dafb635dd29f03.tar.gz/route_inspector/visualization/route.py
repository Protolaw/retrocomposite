"""Route preparation, occurrence highlights, and HTML report generation."""

from __future__ import annotations

import copy
from collections import defaultdict, deque
from html import escape
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

from chython import smiles as read_smiles
from chython.algorithms.depict import _render_config

import route_inspector.routes.access as route_access
from route_inspector import chemistry
from route_inspector.metrics.retro_bleu.bigrams import RetroBleuBigramOccurrence
from route_inspector.protection.strategies.models import (
    ProtectingGroupStrategyOccurrence,
)
from route_inspector.routes import normalization as routes
from route_inspector.tactics.rrsubtree.models import RRSubtreeOccurrence

RRSEQ_ATOM_HIGHLIGHT_COLOR = "#FFD700"
RRSEQ_ATOM_HIGHLIGHT_OPACITY = 0.5
RRSEQ_SKIPPED_ATOM_HIGHLIGHT_COLOR = "#FF6B6B"
RRSEQ_SKIPPED_ATOM_HIGHLIGHT_OPACITY = 0.5
_RRSEQ_ATOM_HIGHLIGHT_CLASS = "rrseq-atom-highlight"
_RRSEQ_SKIPPED_ATOM_HIGHLIGHT_CLASS = "rrseq-skipped-atom-highlight"
_OVERLAPPING_SKIPPED_RADIUS_SCALE = 0.72
PG_STRATEGY_HIGHLIGHT_COLORS = {
    "protection": "#2563EB",
    "synthon_incorporation": "#0891B2",
    "interval": "#F59E0B",
    "deprotection": "#9333EA",
    "stock_origin": "#16A34A",
    "target_retained": "#DB2777",
}
_PG_STRATEGY_ATOM_HIGHLIGHT_CLASS = "pg-strategy-atom-highlight"
_PG_ROLE_RADIUS_SCALES = (1.0, 0.80, 0.62, 0.46)


def _route_id_text(value: Any) -> str:
    try:
        return str(int(value))
    except (TypeError, ValueError):
        return str(value)


def _path(value: Iterable[int], *, field: str) -> tuple[int, ...]:
    if isinstance(value, (str, bytes)):
        raise ValueError(f"{field} must be a sequence of child indexes")
    try:
        path = tuple(int(index) for index in value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field} contains a non-integer child index") from exc
    if any(index < 0 for index in path):
        raise ValueError(f"{field} contains a negative child index")
    return path


def _node_at_path(
    root: dict[str, Any],
    path: tuple[int, ...],
    *,
    field: str,
) -> dict[str, Any]:
    node: Any = root
    for depth, child_index in enumerate(path):
        children = node.get("children") if isinstance(node, dict) else None
        if not isinstance(children, list) or child_index >= len(children):
            raise ValueError(
                f"{field} {list(path)} does not resolve at child index {depth}"
            )
        node = children[child_index]
    if not isinstance(node, dict):
        raise ValueError(f"{field} {list(path)} does not resolve to a route node")
    return node


def _mapped_atom_ids(
    node: dict[str, Any],
    *,
    molecule_path: tuple[int, ...],
) -> set[int]:
    mapped_smiles = route_access.molecule_node_mapped_smiles(node)
    if not mapped_smiles:
        raise ValueError(
            "motif highlighting requires a normalized route with explicit "
            f"metadata.mapped_smiles at molecule path {list(molecule_path)}"
        )
    try:
        molecule = read_smiles(mapped_smiles)
    except Exception as exc:
        raise ValueError(
            f"could not parse mapped molecule at path {list(molecule_path)}: {exc}"
        ) from exc
    return {int(atom_map) for atom_map in molecule}


def _selected_occurrence_steps(
    occurrence: Mapping[str, Any],
) -> tuple[str, tuple[Mapping[str, Any], ...]]:
    source_matches = occurrence.get("source_matches")
    if source_matches is not None:
        if not isinstance(source_matches, list):
            raise ValueError("RRseq_cons source_matches must be a list")
        return "cons", tuple(source_matches)

    if (
        occurrence.get("RRseq_gap") is not None
        or occurrence.get("selected_steps") is not None
    ):
        schema_version = int(occurrence.get("schema_version", -1))
        # Schema v2 introduced the exact selected/skipped node provenance used
        # for highlighting. Later payload versions add analytical references.
        if schema_version < 2:
            raise ValueError(
                "RRseq_gap highlighting requires occurrence schema version "
                "2 or newer; rerun extract-rrseq-gap"
            )
        selected_steps = occurrence.get("selected_steps")
        if not isinstance(selected_steps, list):
            raise ValueError("RRseq_gap selected_steps must be a list")
        return "gap", tuple(selected_steps)

    raise ValueError(
        "rrseq_occurrence is neither an RRseq_cons occurrence nor an RRseq_gap occurrence"
    )


def _step_atom_highlights(
    root: dict[str, Any],
    steps: tuple[Mapping[str, Any], ...],
    *,
    role: str,
    target_path_field: str = "target_molecule_path",
    center_field: str = "center_atom_maps",
) -> dict[tuple[int, ...], frozenset[int]]:
    highlights: dict[tuple[int, ...], set[int]] = defaultdict(set)
    for step_number, step in enumerate(steps, start=1):
        if not isinstance(step, Mapping):
            raise ValueError(f"{role} motif step {step_number} is not an object")
        reaction_path = _path(
            step.get("reaction_node_path", ()),
            field=f"{role} step {step_number} reaction_node_path",
        )
        target_path = _path(
            step.get(target_path_field, ()),
            field=f"{role} step {step_number} {target_path_field}",
        )
        if not reaction_path or reaction_path[:-1] != target_path:
            raise ValueError(
                f"{role} step {step_number} reaction and target paths are inconsistent"
            )

        reaction_node = _node_at_path(
            root,
            reaction_path,
            field=f"{role} step {step_number} reaction_node_path",
        )
        target_node = _node_at_path(
            root,
            target_path,
            field=f"{role} step {step_number} {target_path_field}",
        )
        if reaction_node.get("type") != "reaction":
            raise ValueError(
                f"{role} step {step_number} reaction path does not resolve to a reaction"
            )
        if target_node.get("type") != "mol":
            raise ValueError(
                f"{role} step {step_number} target path does not resolve to a molecule"
            )

        expected_reaction = str(step.get("reaction_smiles") or "")
        if not expected_reaction:
            raise ValueError(f"{role} step {step_number} has no reaction_smiles")
        actual_reaction = route_access.reaction_smiles_from_node(reaction_node)
        try:
            provenance_matches = chemistry.exact_mapped_reactions_correspond(
                chemistry.parse_reaction(expected_reaction),
                chemistry.parse_reaction(actual_reaction),
            )
        except Exception as exc:
            raise ValueError(
                f"could not validate {role} step {step_number} reaction provenance "
                f"at path {list(reaction_path)}: {exc}"
            ) from exc
        if not provenance_matches:
            raise ValueError(
                f"{role} step {step_number} reaction provenance is stale at path "
                f"{list(reaction_path)}"
            )

        try:
            center_maps = {int(value) for value in step.get(center_field, ())}
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"{role} step {step_number} has non-integer reaction-center maps"
            ) from exc
        if not center_maps:
            raise ValueError(f"{role} step {step_number} has no reaction-center maps")

        adjacent_molecules = [(target_path, target_node)]
        for child_index, child in enumerate(reaction_node.get("children") or ()):
            if isinstance(child, dict) and child.get("type") == "mol":
                adjacent_molecules.append((reaction_path + (child_index,), child))

        found_maps: set[int] = set()
        for molecule_path, molecule_node in adjacent_molecules:
            present = center_maps & _mapped_atom_ids(
                molecule_node,
                molecule_path=molecule_path,
            )
            if present:
                highlights[molecule_path].update(present)
                found_maps.update(present)
        missing = center_maps - found_maps
        if missing:
            raise ValueError(
                f"{role} step {step_number} reaction-center maps are absent from both "
                f"route sides at path {list(reaction_path)}: {sorted(missing)}"
            )

    return {
        path: frozenset(atom_maps) for path, atom_maps in sorted(highlights.items())
    }


def _occurrence_atom_highlights(
    root: dict[str, Any],
    route_id: Any,
    occurrence: Mapping[str, Any],
    *,
    highlight_skipped_steps: bool,
) -> tuple[
    dict[tuple[int, ...], frozenset[int]],
    dict[tuple[int, ...], frozenset[int]],
]:
    occurrence_route_id = occurrence.get("route_id")
    if occurrence_route_id is None:
        raise ValueError("rrseq_occurrence has no route_id")
    if _route_id_text(occurrence_route_id) != _route_id_text(route_id):
        raise ValueError(
            "rrseq_occurrence route_id does not match the requested route: "
            f"{occurrence_route_id!r} != {route_id!r}"
        )

    rrseq_kind, selected_steps = _selected_occurrence_steps(occurrence)
    if not selected_steps:
        raise ValueError(f"RRseq_{rrseq_kind} occurrence has no selected steps")
    selected = _step_atom_highlights(
        root,
        selected_steps,
        role="selected",
        center_field="center_atom_maps" if rrseq_kind == "cons" else "center_atoms",
    )

    skipped: dict[tuple[int, ...], frozenset[int]] = {}
    if highlight_skipped_steps:
        if rrseq_kind != "gap":
            raise ValueError(
                "highlight_skipped_steps requires a schema-v2 RRseq_gap occurrence"
            )
        skipped_steps = occurrence.get("skipped_steps")
        if not isinstance(skipped_steps, list):
            raise ValueError("RRseq_gap skipped_steps must be a list")
        if not skipped_steps:
            raise ValueError("RRseq_gap occurrence has no skipped steps")
        skipped = _step_atom_highlights(
            root,
            tuple(skipped_steps),
            role="skipped",
            center_field="center_atoms",
        )

    return selected, skipped


def _rrsubtree_atom_highlights(
    root: dict[str, Any],
    route_id: Any,
    occurrence: Mapping[str, Any],
    *,
    highlight_skipped_steps: bool,
) -> tuple[
    dict[tuple[int, ...], frozenset[int]],
    dict[tuple[int, ...], frozenset[int]],
]:
    occurrence_route_id = occurrence.get("route_id")
    if occurrence_route_id is None:
        raise ValueError("rrsubtree_occurrence has no route_id")
    if _route_id_text(occurrence_route_id) != _route_id_text(route_id):
        raise ValueError(
            "rrsubtree_occurrence route_id does not match the requested "
            f"route: {occurrence_route_id!r} != {route_id!r}"
        )

    try:
        validated = RRSubtreeOccurrence.from_dict(occurrence)
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"invalid rrsubtree_occurrence: {exc}") from exc

    selected = _step_atom_highlights(
        root,
        tuple(node.to_dict() for node in validated.nodes),
        role="selected",
        target_path_field="target_molecule_node_path",
        center_field="center_atom_maps",
    )

    skipped: dict[tuple[int, ...], frozenset[int]] = {}
    if highlight_skipped_steps:
        if validated.kind != "gap":
            raise ValueError(
                "highlight_skipped_steps requires a RRSubtree_gap occurrence"
            )
        skipped = _step_atom_highlights(
            root,
            tuple(node.to_dict() for node in validated.skipped_nodes),
            role="skipped",
            target_path_field="target_molecule_node_path",
            center_field="center_atom_maps",
        )

    return selected, skipped


def _retro_bleu_bigram_atom_highlights(
    root: dict[str, Any],
    route_id: Any,
    occurrence: Mapping[str, Any],
) -> dict[tuple[int, ...], frozenset[int]]:
    """Validate and highlight two independently centered adjacent reactions."""

    try:
        validated = RetroBleuBigramOccurrence.from_dict(occurrence)
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"invalid retro_bleu_bigram_occurrence: {exc}") from exc
    if _route_id_text(validated.route_id) != _route_id_text(route_id):
        raise ValueError(
            "retro_bleu_bigram_occurrence route_id does not match the requested "
            f"route: {validated.route_id!r} != {route_id!r}"
        )
    return _step_atom_highlights(
        root,
        tuple(step.to_dict() for step in validated.steps),
        role="Retro-BLEU-like bigram selected",
    )


def _pg_reaction_step(
    root: dict[str, Any],
    reaction_path: tuple[int, ...],
    center_atom_maps: Iterable[int],
    *,
    expected_reaction_smiles: str = "",
) -> dict[str, Any]:
    if not reaction_path:
        raise ValueError("PG reaction path must not be empty")
    reaction_node = _node_at_path(root, reaction_path, field="PG reaction path")
    if reaction_node.get("type") != "reaction":
        raise ValueError("PG reaction path does not resolve to a reaction")
    recorded_reaction = route_access.reaction_smiles_from_node(reaction_node)
    return {
        "reaction_node_path": list(reaction_path),
        "target_molecule_path": list(reaction_path[:-1]),
        "reaction_smiles": expected_reaction_smiles or recorded_reaction,
        "center_atom_maps": list(center_atom_maps),
    }


def _pg_strategy_atom_highlights(
    root: dict[str, Any],
    route_id: Any,
    occurrence: Mapping[str, Any],
) -> dict[str, dict[tuple[int, ...], frozenset[int]]]:
    """Validate one PG event and return role-specific atom-map highlights."""

    try:
        validated = ProtectingGroupStrategyOccurrence.from_dict(occurrence)
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"invalid pg_strategy_occurrence: {exc}") from exc
    if _route_id_text(validated.route.route_id) != _route_id_text(route_id):
        raise ValueError(
            "pg_strategy_occurrence route_id does not match the requested route: "
            f"{validated.route.route_id!r} != {route_id!r}"
        )

    result: dict[str, dict[tuple[int, ...], frozenset[int]]] = {
        role: {} for role in PG_STRATEGY_HIGHLIGHT_COLORS
    }
    if validated.source_type in {"introduced", "protected_synthon"}:
        role = (
            "protection"
            if validated.source_type == "introduced"
            else "synthon_incorporation"
        )
        result[role] = _step_atom_highlights(
            root,
            (
                _pg_reaction_step(
                    root,
                    validated.protection_reaction_node_path,
                    validated.protection_center_atom_maps,
                    expected_reaction_smiles=validated.protection_reaction_smiles,
                ),
            ),
            role=(
                "PG protection endpoint"
                if validated.source_type == "introduced"
                else "protected-synthon incorporation endpoint"
            ),
        )
    interval_steps = tuple(
        _pg_reaction_step(root, path, centers)
        for path, centers in zip(
            validated.interval_reaction_node_paths,
            validated.interval_center_atom_maps,
        )
    )
    if interval_steps:
        result["interval"] = _step_atom_highlights(
            root,
            interval_steps,
            role="PG interval",
        )
    if validated.identity.endpoint_kind == "target":
        target_maps = set(validated.annotations.get("target_matched_atom_maps", ()))
        present = _mapped_atom_ids(root, molecule_path=())
        if not target_maps or not target_maps <= present:
            raise ValueError("target PG evidence disagrees with target atom maps")
        result["target_retained"] = {(): frozenset(target_maps)}
    else:
        result["deprotection"] = _step_atom_highlights(
            root,
            (
                _pg_reaction_step(
                    root,
                    validated.deprotection_reaction_node_path,
                    validated.deprotection_center_atom_maps,
                    expected_reaction_smiles=validated.deprotection_reaction_smiles,
                ),
            ),
            role="PG deprotection endpoint",
        )
    if validated.source_type in {"stock", "protected_synthon"}:
        stock_node = _node_at_path(
            root,
            validated.stock_molecule_node_path,
            field="PG stock molecule path",
        )
        if stock_node.get("type") != "mol":
            raise ValueError("PG stock path does not resolve to a molecule")
        source_maps = (
            validated.source_fragment_atom_maps
            if validated.source_type == "protected_synthon"
            else validated.protected_atom_ids
        )
        present = set(source_maps) & _mapped_atom_ids(
            stock_node,
            molecule_path=validated.stock_molecule_node_path,
        )
        if not present:
            raise ValueError("PG stock origin contains none of the source atom maps")
        result["stock_origin"] = {
            validated.stock_molecule_node_path: frozenset(present)
        }
    return result


def _extract_levels_and_parents(root: dict[str, Any]):
    levels: list[list[tuple[tuple[int, ...], dict[str, Any]]]] = []
    parent_of: dict[tuple[int, ...], tuple[int, ...] | None] = {}
    outgoing_reaction_of: dict[tuple[int, ...], dict[str, Any] | None] = {}
    queue = deque([(root, (), 0, None)])

    while queue:
        node, path, depth, parent = queue.popleft()
        if not isinstance(node, dict) or node.get("type") != "mol":
            continue
        if depth >= len(levels):
            levels.extend([] for _ in range(depth - len(levels) + 1))
        levels[depth].append((path, node))
        parent_of[path] = parent
        outgoing_reaction_of[path] = None

        for reaction_index, reaction in enumerate(node.get("children") or ()):
            if not isinstance(reaction, dict) or reaction.get("type") != "reaction":
                continue
            outgoing_reaction_of[path] = reaction
            reaction_path = path + (reaction_index,)
            for molecule_index, child in enumerate(reaction.get("children") or ()):
                if isinstance(child, dict) and child.get("type") == "mol":
                    queue.append(
                        (
                            child,
                            reaction_path + (molecule_index,),
                            depth + 1,
                            path,
                        )
                    )

    return levels, parent_of, outgoing_reaction_of


def _format_arrow_label(
    rule_key: str | None,
    policy_rank: int | None,
    *,
    include_rule_key: bool,
) -> str | None:
    parts: list[str] = []
    if include_rule_key and rule_key:
        parts.append(str(rule_key))
    if policy_rank is not None:
        parts.append(f"Top-{policy_rank}")
    return " | ".join(parts) if parts else None


def _prepare_json_route_svg_inputs(
    root: dict[str, Any],
    *,
    labeled: bool,
    highlights: Mapping[tuple[int, ...], frozenset[int]],
    skipped_highlights: Mapping[tuple[int, ...], frozenset[int]],
    pg_highlights: Mapping[str, Mapping[tuple[int, ...], frozenset[int]]],
):
    levels, parent_of, outgoing_reaction_of = _extract_levels_and_parents(root)
    molecule_containers: dict[tuple[int, ...], Any] = {}
    for depth, entries in enumerate(levels):
        for path, node in entries:
            molecule_smiles = route_access.molecule_node_mapped_smiles(
                node
            ) or route_access.molecule_node_smiles(node)
            container = read_smiles(molecule_smiles)
            container.meta["status"] = (
                "target"
                if depth == 0
                else "instock"
                if node.get("in_stock")
                else "mulecule"
            )
            container.meta["route_node_path"] = path
            container.meta["highlight_atom_maps"] = highlights.get(path, frozenset())
            container.meta["skipped_highlight_atom_maps"] = skipped_highlights.get(
                path, frozenset()
            )
            container.meta["pg_highlight_atom_maps"] = {
                role: role_highlights.get(path, frozenset())
                for role, role_highlights in pg_highlights.items()
            }

            reaction = outgoing_reaction_of.get(path)
            label = _format_arrow_label(
                reaction.get("rule_key") if reaction else None,
                reaction.get("policy_rank") if reaction else None,
                include_rule_key=labeled,
            )
            if label:
                container.meta["label"] = label
            container.meta["reaction_node_paths"] = tuple(
                path + (index,)
                for index, child in enumerate(node.get("children") or ())
                if isinstance(child, dict) and child.get("type") == "reaction"
            )
            molecule_containers[path] = container

    flat_paths = [path for level in levels for path, _node in level]
    index_map = {path: index for index, path in enumerate(flat_paths)}
    pred = []
    for path, parent in parent_of.items():
        if parent is not None:
            pred.append((index_map[parent], index_map[path]))
    columns = [[molecule_containers[path] for path, _node in level] for level in levels]
    return columns, tuple(pred)


def _atom_highlight_svg(molecule) -> list[str]:
    """Draw shared path-specific halos in the molecule depiction coordinates."""
    extras = []
    radius = 0.72 * float(_render_config["font_size"])
    route_path = "/".join(
        str(index) for index in molecule.meta.get("route_node_path", ())
    )
    selected_atom_maps = set(molecule.meta.get("highlight_atom_maps", ()))
    for atom_map in sorted(selected_atom_maps):
        atom = molecule.atom(atom_map)
        extras.append(
            f'  <circle class="{_RRSEQ_ATOM_HIGHLIGHT_CLASS}" '
            f'data-atom-map="{atom_map}" data-molecule-path="{route_path}" '
            f'cx="{atom.x:.2f}" cy="{-atom.y:.2f}" r="{radius:.2f}" '
            f'fill="{RRSEQ_ATOM_HIGHLIGHT_COLOR}" '
            f'fill-opacity="{RRSEQ_ATOM_HIGHLIGHT_OPACITY:.2f}"/>'
        )
    for atom_map in sorted(molecule.meta.get("skipped_highlight_atom_maps", ())):
        atom = molecule.atom(atom_map)
        skipped_radius = (
            radius * _OVERLAPPING_SKIPPED_RADIUS_SCALE
            if atom_map in selected_atom_maps
            else radius
        )
        extras.append(
            f'  <circle class="{_RRSEQ_SKIPPED_ATOM_HIGHLIGHT_CLASS}" '
            f'data-highlight-role="skipped" data-atom-map="{atom_map}" '
            f'data-molecule-path="{route_path}" cx="{atom.x:.2f}" '
            f'cy="{-atom.y:.2f}" r="{skipped_radius:.2f}" '
            f'fill="{RRSEQ_SKIPPED_ATOM_HIGHLIGHT_COLOR}" '
            f'fill-opacity="{RRSEQ_SKIPPED_ATOM_HIGHLIGHT_OPACITY:.2f}"/>'
        )
    pg_roles_by_atom: dict[int, list[str]] = defaultdict(list)
    for role, atom_maps in molecule.meta.get("pg_highlight_atom_maps", {}).items():
        for atom_map in atom_maps:
            pg_roles_by_atom[int(atom_map)].append(str(role))
    role_order = tuple(PG_STRATEGY_HIGHLIGHT_COLORS)
    for atom_map, roles in sorted(pg_roles_by_atom.items()):
        atom = molecule.atom(atom_map)
        ordered_roles = sorted(roles, key=role_order.index)
        for layer, role in enumerate(ordered_roles):
            scale = _PG_ROLE_RADIUS_SCALES[min(layer, len(_PG_ROLE_RADIUS_SCALES) - 1)]
            extras.append(
                f'  <circle class="{_PG_STRATEGY_ATOM_HIGHLIGHT_CLASS}" '
                f'data-highlight-role="{role}" data-atom-map="{atom_map}" '
                f'data-molecule-path="{route_path}" cx="{atom.x:.2f}" '
                f'cy="{-atom.y:.2f}" r="{radius * scale:.2f}" '
                f'fill="{PG_STRATEGY_HIGHLIGHT_COLORS[role]}" '
                'fill-opacity="0.52"/>'
            )
    return extras


def _has_complete_mapped_molecule_nodes(root: dict[str, Any]) -> bool:
    """Return whether every molecule node carries an explicit mapped SMILES."""

    molecule_seen = False
    stack = [root]
    while stack:
        node = stack.pop()
        if node.get("type") == "mol":
            molecule_seen = True
            if not route_access.molecule_node_mapped_smiles(node):
                return False
        stack.extend(
            child for child in node.get("children", ()) or () if isinstance(child, dict)
        )
    return molecule_seen


def _route_for_visualization(root: dict[str, Any]) -> dict[str, Any]:
    """Project recorded reaction maps onto raw molecule nodes when possible.

    Clean routes already carrying mapped molecule nodes are reused. For raw
    PaRoutes trees, recorded ``metadata.smiles`` is preferred, followed by
    ``metadata.mapped_reaction_smiles`` and ``metadata.rsmi``. If route-level
    projection cannot produce mapped molecule nodes, the untouched input route
    is returned for molecule-node depiction without map-based alignment.
    """

    if _has_complete_mapped_molecule_nodes(root):
        return root

    candidate = copy.deepcopy(root)
    stack = [candidate]
    while stack:
        node = stack.pop()
        if node.get("type") == "reaction":
            metadata = node.get("metadata") or {}
            recorded_reaction = (
                metadata.get("smiles")
                or metadata.get("mapped_reaction_smiles")
                or metadata.get("rsmi")
                or node.get("smiles")
            )
            if recorded_reaction:
                node["smiles"] = recorded_reaction
        stack.extend(
            child for child in node.get("children", ()) or () if isinstance(child, dict)
        )

    try:
        projected = routes.normalize_route_tree(candidate)
    except Exception:
        return root
    if not _has_complete_mapped_molecule_nodes(projected):
        return root
    return projected


def _prepare_route_rendering(
    routes_json: route_access.RouteCollection,
    route_id: Any,
    labeled: bool = False,
    *,
    rrseq_occurrence: Mapping[str, Any] | None = None,
    rrsubtree_occurrence: Mapping[str, Any] | None = None,
    retro_bleu_bigram_occurrence: Mapping[str, Any] | None = None,
    pg_strategy_occurrence: Mapping[str, Any] | None = None,
    highlight_skipped_steps: bool = False,
):
    """Prepare mapped drawing inputs and validate highlights for either renderer."""

    root = _route_for_visualization(route_access.route_by_id(routes_json, route_id))
    pg_highlights: dict[str, dict[tuple[int, ...], frozenset[int]]] = {}
    supplied_occurrences = sum(
        occurrence is not None
        for occurrence in (
            rrseq_occurrence,
            rrsubtree_occurrence,
            retro_bleu_bigram_occurrence,
            pg_strategy_occurrence,
        )
    )
    if supplied_occurrences > 1:
        raise ValueError(
            "provide either rrseq_occurrence, rrsubtree_occurrence, "
            "retro_bleu_bigram_occurrence, or pg_strategy_occurrence, not multiple"
        )
    if supplied_occurrences == 0:
        if highlight_skipped_steps:
            raise ValueError(
                "highlight_skipped_steps requires an rrseq_occurrence or "
                "rrsubtree_occurrence"
            )
        highlights, skipped_highlights = {}, {}
    elif rrseq_occurrence is not None:
        highlights, skipped_highlights = _occurrence_atom_highlights(
            root,
            route_id,
            rrseq_occurrence,
            highlight_skipped_steps=highlight_skipped_steps,
        )
    elif rrsubtree_occurrence is not None:
        tree_occurrence = rrsubtree_occurrence
        if tree_occurrence is None:
            raise RuntimeError("unreachable missing motif occurrence")
        highlights, skipped_highlights = _rrsubtree_atom_highlights(
            root,
            route_id,
            tree_occurrence,
            highlight_skipped_steps=highlight_skipped_steps,
        )
    elif pg_strategy_occurrence is not None:
        if highlight_skipped_steps:
            raise ValueError("PG strategy events contain no gapped selected span")
        highlights, skipped_highlights = {}, {}
        pg_highlights = _pg_strategy_atom_highlights(
            root,
            route_id,
            pg_strategy_occurrence,
        )
    else:
        if retro_bleu_bigram_occurrence is None:
            raise RuntimeError("unreachable missing bigram occurrence")
        if highlight_skipped_steps:
            raise ValueError("Retro-BLEU-like bigrams contain no skipped selected span")
        highlights = _retro_bleu_bigram_atom_highlights(
            root,
            route_id,
            retro_bleu_bigram_occurrence,
        )
        skipped_highlights = {}
    columns, pred = _prepare_json_route_svg_inputs(
        root,
        labeled=labeled,
        highlights=highlights,
        skipped_highlights=skipped_highlights,
        pg_highlights=pg_highlights,
    )
    return root, columns, pred


def _dotted_route_sort_key(value: Any) -> tuple[Any, ...]:
    parts = str(value).split(".")
    if parts and all(part.isdigit() for part in parts):
        return (0, *(int(part) for part in parts))
    return (1, str(value))


def write_routes_html(
    routes_json: route_access.RouteCollection,
    output_path: str | Path,
    *,
    route_renderer: Callable[..., str],
    labeled: bool = True,
    box_solid: bool = True,
    title: str = "Expanded RRseq Routes Report",
) -> Path:
    """Write a self-contained SVG report for route JSON, including dotted IDs."""

    route_entries = sorted(
        route_access.route_items(routes_json),
        key=lambda item: _dotted_route_sort_key(item[0]),
    )
    sections: list[str] = []
    for route_id, root in route_entries:
        source_route_id = root.get(
            "source_route_id", root.get("source_node_id", route_id)
        )
        assignments = root.get("composite_unwrap_assignments") or []
        alternatives = []
        for assignment in assignments:
            if not isinstance(assignment, Mapping):
                continue
            alternatives.append(
                "occurrence "
                f"{escape(str(assignment.get('original_tree_node_id') or assignment.get('original_reaction_path')))}"
                ": alternative "
                f"{escape(str(assignment.get('rrseq_alternative_index')))}"
                f"/{escape(str(assignment.get('rrseq_alternative_count')))}"
            )
        alternative_html = (
            f'<p class="alternatives">{"; ".join(alternatives)}</p>'
            if alternatives
            else ""
        )
        svg = route_renderer(
            routes_json,
            route_id,
            labeled=labeled,
            box_solid=box_solid,
        )
        sections.append(
            '<section class="route">'
            f"<h2>Route {escape(str(route_id))}</h2>"
            "<p>"
            f"Source route: {escape(str(source_route_id))}; "
            f"reactions: {route_access.count_reaction_nodes(root)}"
            "</p>"
            f"{alternative_html}{svg}</section>"
        )

    document = "\n".join(
        [
            "<!doctype html>",
            '<html lang="en"><head><meta charset="utf-8">',
            f"<title>{escape(title)}</title>",
            "<style>",
            "body{font-family:system-ui,sans-serif;margin:2rem;background:#fafafa;color:#222}",
            ".route{margin:0 0 2rem;padding:1rem;background:white;border:1px solid #ddd;border-radius:.5rem}",
            ".route h2{margin-top:0}.route svg{max-width:100%;height:auto}.alternatives{color:#555}",
            "</style></head><body>",
            f"<h1>{escape(title)}</h1>",
            f"<p>{len(route_entries)} route variant(s)</p>",
            *sections,
            "</body></html>",
        ]
    )
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(document, encoding="utf-8")
    return destination
