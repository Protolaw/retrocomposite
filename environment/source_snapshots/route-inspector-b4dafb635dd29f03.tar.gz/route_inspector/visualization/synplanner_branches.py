"""Pack variable-width branch drawings beside their consuming reaction."""

from .synplanner_layers import main_child, reaction_radius


def place_component(root, heights, *, compact, column_gap, side):
    """Use local reaction gaps and occupied rectangles instead of depth columns.

    Child outputs share a port corridor immediately before their consumer.
    All rectangles, including connector buses, participate in vertical packing.
    The returned geometry changes positions only, never molecule dimensions.
    """
    separation = 12.0 if compact else 20.0

    def horizontal(node, x):
        node.x = x
        for child in node.children:
            horizontal(child, x - column_gap - child.w)

    horizontal(root, 0.0)

    def leftmost(node):
        return (
            min(node.x, *(leftmost(c) for c in node.children))
            if node.children
            else node.x
        )

    entry_left = leftmost(root)

    def overlap(a, b):
        return a[0] <= b[2] and b[0] <= a[2]

    def move(box, dy):
        return box[0], box[1] + dy, box[2], box[3] + dy

    def place(node):
        node.y = -node.h / 2
        caption = 16 if getattr(node, "role", None) in {"target", "bb", "oos"} else 0
        boxes = [(node.x, node.y - caption, node.x + node.w, node.h / 2)]
        if getattr(node, "carry_from_left", False):
            boxes.append((entry_left, 0, node.x, 0))
        members = [node]
        if not node.children:
            return members, boxes
        lane = node.x - 0.58 * column_gap
        radius = reaction_radius(node)
        boxes.append((lane - radius, -radius, lane + radius, radius))
        if node.label:
            cx = (lane + node.x) / 2
            half = 3.5 * len(node.label)
            boxes.append((cx - half, radius + 4, cx + half, radius + 17))
        main = main_child(node, heights, contributors=True)
        main_nodes, main_boxes = place(main)
        members.extend(main_nodes)
        boxes.extend(main_boxes)
        boxes.append((main.x + main.w, -1, node.x, 1))
        for child in node.children:
            if child is main:
                continue
            side_nodes, side_boxes = place(child)
            side_boxes.append((child.x + child.w, -1, lane, 1))
            pairs = [(a, b) for a in side_boxes for b in boxes if overlap(a, b)]
            above = min(b[1] - separation - a[3] for a, b in pairs)
            below = max(b[3] + separation - a[1] for a, b in pairs)

            def score(shift):
                top = min(
                    min(b[1] for b in boxes), min(b[1] for b in side_boxes) + shift
                )
                bottom = max(
                    max(b[3] for b in boxes), max(b[3] for b in side_boxes) + shift
                )
                return bottom - top, abs(shift), shift < 0

            if len(node.children) == 2 and side != "greedy":
                shift = above if side == "above" else below
            else:
                shift = min((above, below), key=score)
            for n in side_nodes:
                n.y += shift
            members.extend(side_nodes)
            boxes.extend(move(b, shift) for b in side_boxes)
            boxes.append((lane - 1, min(0, shift), lane + 1, max(0, shift)))
        return members, boxes

    members, boxes = place(root)
    left = min(n.x for n in members)
    top = min(b[1] for b in boxes)
    width = root.w - left
    for node in members:
        node.x -= left
        node.y -= top
    return width, max(b[3] for b in boxes) - top
