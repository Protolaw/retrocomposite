"""Standalone boxed rendering for RRSubtree occurrences and notation."""

from __future__ import annotations

from typing import Any, Mapping

from route_inspector.tactics.rrsubtree.notation import _prepare_rule_tree
from route_inspector.visualization.rule_nodes import render_rule_tree


def get_rrsubtree_svg(
    rrsubtree_occurrence: Mapping[str, Any] | str,
    *,
    rule_legend: Mapping[str, str] | None = None,
    view: str = "rules",
) -> str:
    """Render an occurrence or chemical annotation as a standalone SVG tree.

    Shorthand requires a complete ``rule_legend``; quoted inline SMARTS do not.
    ``view='compact'`` places chemical depictions in a legend below label nodes.
    Solid edges are immediate and dashed edges carry skipped-reaction counts.
    Only occurrence inputs supply exact paths and continuity annotations; the
    string form carries chemistry and topology, not an occurrence certificate.
    """
    if view not in ("rules", "compact"):
        raise ValueError("RRSubtree view must be 'rules' or 'compact'")
    tree = _prepare_rule_tree(rrsubtree_occurrence, rule_legend=rule_legend)
    strict_text = (
        "all selected edges RRSeq-connected"
        if tree.all_edges_rrseq_connected
        else "topology motif; not all selected edges RRSeq-connected"
    )
    title = (
        f"RRSubtree_{tree.kind} · {strict_text}"
        if tree.all_edges_rrseq_connected is not None
        else f"Chemical rule topology ({tree.kind}) · occurrence provenance unavailable"
    )
    return render_rule_tree(
        tree,
        namespace="rrsubtree",
        title=title,
        positive_badge=bool(tree.all_edges_rrseq_connected),
        view=view,
    )
