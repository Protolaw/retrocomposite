"""Reaction-aware snake packing; never modifies route or molecule contents."""

from __future__ import annotations

from copy import copy, deepcopy
from functools import lru_cache

from .synplanner_branches import place_component
from .synplanner_layers import (
    LANE_GAP,
    PREFERRED_MAX_REACTIONS,
    ROW_HEIGHT_TARGET,
    ROW_WIDTH_TARGET,
    RouteForest,
    RouteRow,
    RouteScene,
    _place_spines,
    _reflect_row,
    _translate,
    local_links,
    main_child,
    reaction_radius,
)


def _occupied(forest, width):
    """Horizontal contours include labels, buses and reserved boundary ports."""
    boxes = []
    for node in forest.nodes:
        caption = 16 if getattr(node, "role", None) in {"target", "bb", "oos"} else 0
        boxes.append((node.x, node.y - caption, node.x + node.w, node.y + node.h))
    for edge in forest.links:
        x, y = edge.junction
        radius = reaction_radius(edge.node)
        boxes.append((x - radius, y - radius, x + radius, y + radius))
        if edge.node.label:
            x, y = edge.label_position
            half = 3.5 * len(edge.node.label)
            boxes.append((x - half, y - 10, x + half, y + 3))
        paths = [
            edge.lead,
            *(p for k, p in edge.inputs if k not in edge.wrapped_inputs),
        ]
        if edge.wrapped_inputs:
            # No other forest may obstruct an incoming horizontal connector.
            x, y = edge.lead[0]
            paths.append([(0, y), (x, y)])
        for path in paths:
            for a, b in zip(path, path[1:]):
                boxes.append(
                    (
                        min(a[0], b[0]) - 1,
                        min(a[1], b[1]) - 1,
                        max(a[0], b[0]) + 1,
                        max(a[1], b[1]) + 1,
                    )
                )
    root = forest.nodes[0]
    y = root.y + root.h / 2
    boxes.append((root.x + root.w, y - 1, width, y + 1))
    return boxes


def _pack_forests(row, *, compact):
    """Compact ordered forests by their occupied contours, not full rectangles."""
    placed = []
    gap = 12 if compact else 20
    for forest in row.forests:
        _translate(forest.nodes, forest.links, 0, -forest.y)
        boxes = _occupied(forest, row.width)
        shift = max(
            (
                b[3] + gap - a[1]
                for a in boxes
                for b in placed
                if a[0] <= b[2] and b[0] <= a[2]
            ),
            default=0,
        )
        shift = max(0, shift)
        _translate(forest.nodes, forest.links, 0, shift)
        forest.y = shift
        placed.extend((x0, y0 + shift, x1, y1 + shift) for x0, y0, x1, y1 in boxes)
    # Contours also reserve marker/label height, including empty carry ports.
    top = min(b[1] for b in placed)
    for forest in row.forests:
        _translate(forest.nodes, forest.links, 0, -top)
        forest.y -= top
    row.height = max(b[3] for b in placed) - top


def _measure(
    columns,
    high,
    low,
    span,
    *,
    layout_tree,
    compact,
    heights,
    members=None,
    local_branches=False,
):
    forests = []
    for source in columns[low]:
        # Leaf stock belongs to its consuming reaction, never a separate band.
        if low and not source.children:
            continue
        copies, external = [], {}

        def clip(node, depth):
            drawing = copy(node)
            drawing.children = []
            drawing.incoming_reaction = False
            copies.append(drawing)
            outside = (
                [c for c in node.children if c.key not in members]
                if members is not None
                else [c for c in node.children if c.children and depth == high]
            )
            if outside:
                # One zero-size layout anchor for the incoming branches. It is
                # neither a molecule occurrence nor exported SVG artwork.
                holder = copy(node)
                holder.children = outside
                anchor = copy(main_child(holder, heights, contributors=True))
                anchor.children = []
                anchor.w = anchor.h = 0.0
                anchor.label = anchor.number = ""
                anchor.role = None
                anchor.incoming_reaction = False
                anchor.carry_from_left = members is not None or local_branches
                copies.append(anchor)
                drawing.children.append(anchor)
                external[drawing.key] = (anchor.key, tuple(c.key for c in outside))
            drawing.children.extend(
                clip(c, depth + 1)
                for c in node.children
                if (
                    c.key in members
                    if members is not None
                    else depth < high or not c.children
                )
            )
            return drawing

        clip(source, low)
        width, _, col_x, col_w, raw_links = layout_tree(copies, compact=compact)
        column_gap = min(
            (col_x[d] - col_x[d + 1] - col_w[d + 1] for d in col_x if d + 1 in col_x),
            default=50.0,
        )
        # Evaluate whole-component choices: locally greedy decisions can put
        # stock on opposite sides of the same row and needlessly enlarge it.
        placements = []
        for priority, side in enumerate(("below", "above", "greedy")):
            if local_branches:
                width, height = place_component(
                    copies[0],
                    heights,
                    compact=compact,
                    column_gap=column_gap,
                    side=side,
                )
            else:
                height = _place_spines(
                    copies[0], heights, compact=compact, side=side, contributors=True
                )
            placements.append((height, priority, [(n.x, n.y) for n in copies]))
        height, _, positions = min(placements)
        for node, (x, y) in zip(copies, positions):
            node.x, node.y = x, y
        for edge in raw_links:
            node = edge["node"]
            edge["parent"] = (node.x, node.y + node.h / 2)
            edge["children"] = [(c.x + c.w, c.y + c.h / 2) for c in node.children]
            if local_branches:
                edge["lane"] = node.x - 0.58 * column_gap
        links = local_links(raw_links, col_x, col_w, after_junction=True)
        anchors = {anchor for anchor, _keys in external.values()}
        for edge in links:
            if edge.node.key in external:
                anchor, keys = external[edge.node.key]
                path = next(p for k, p in edge.inputs if k == anchor)
                edge.inputs = [(k, p) for k, p in edge.inputs if k != anchor]
                edge.inputs.extend((key, path[:]) for key in keys)
                edge.wrapped_inputs = frozenset(keys)
        forests.append(
            RouteForest(
                [n for n in copies if n.key not in anchors], links, width, height
            )
        )
    width = max(f.width for f in forests)
    nodes, links = [], []
    for forest in forests:
        _translate(forest.nodes, forest.links, width - forest.width, 0)
        nodes.extend(forest.nodes)
        links.extend(forest.links)
    row = RouteRow(nodes, links, high, low, span, width, 0, 0, forests)
    _pack_forests(row, compact=compact)
    return row


def _plan_rows(
    *,
    columns,
    heights,
    chain,
    layout_tree,
    compact,
    local_branches=False,
    last_span=None,
):
    """Choose depth-band breaks jointly, then nest and compact branch contours.

    Costs use measured geometry at a fixed molecular scale. Width may exceed
    the soft target by up to 10%, with a pixel-for-pixel height penalty. An
    indivisible oversized single step can exceed either target further.
    Break costs precede final branch reordering, so this is not a globally
    minimal two-dimensional layout.
    """
    deepest = len(chain) - 1

    @lru_cache(maxsize=None)
    def measure(high, low, span):
        return _measure(
            columns,
            high,
            low,
            span,
            layout_tree=layout_tree,
            compact=compact,
            heights=heights,
            local_branches=local_branches,
        )

    @lru_cache(maxsize=None)
    def plan(high, first=False):
        if high < 0:
            return (0, 0.0, 0), ()
        remaining = high if first else high + 1
        candidates = []
        for span in (
            range(min(PREFERRED_MAX_REACTIONS, remaining), 0, -1) if remaining else [0]
        ):
            low = high - span + (0 if first else 1)
            if low == 0 and last_span is not None and span != last_span:
                continue
            row = measure(high, low, span)
            gap = (
                48 + LANE_GAP * sum(bool(n.children) for n in columns[low - 1])
                if low
                else 0
            )
            width_excess = max(0, row.width + 28 - ROW_WIDTH_TARGET)
            overflow = max(0, row.width + 28 - ROW_WIDTH_TARGET * 1.1)
            overflow += max(0, row.height + gap + 44 - ROW_HEIGHT_TARGET)
            # Do not choose an overflowing multi-step row when it can be split.
            if overflow and span > 1:
                continue
            suffix_plan = plan(low - 1)
            if suffix_plan is None:
                continue
            cost, suffix = suffix_plan
            score = (
                cost[0] + bool(overflow),
                cost[1] + row.height + gap + width_excess,
                cost[2] + span * span,
            )
            candidates.append((score, ((high, low, span), *suffix)))
        return min(candidates, key=lambda item: item[0]) if candidates else None

    chosen = plan(deepest, True)
    if chosen is None:
        return None
    _, bands = chosen
    return [measure(*band) for band in bands]


def _assemble(rows, *, columns, originals, parents, sibling_order, chain, compact):
    # Keep cached/candidate geometry reusable; molecule artwork is immutable.
    rows = deepcopy(
        rows,
        {
            id(n.molecule): n.molecule
            for r in rows
            for n in r.nodes
            if hasattr(n, "molecule")
        },
    )
    # Same-side turns require the upstream forest order to be the reverse of
    # their downstream consumers, so the external connector lanes nest.
    for upper, lower in reversed(list(zip(rows, rows[1:]))):
        consumers = {node.key: node for node in lower.nodes}
        upper.forests.sort(
            key=lambda f: (
                consumers[parents[f.nodes[0].key]].y
                + consumers[parents[f.nodes[0].key]].h / 2,
                sibling_order[f.nodes[0].key],
            ),
            reverse=True,
        )
        _pack_forests(upper, compact=compact)

    width = max(row.width for row in rows)
    side_pad = 24 + LANE_GAP * max(map(len, columns.values()))
    nodes, links, y = [], [], 0.0
    for index, row in enumerate(rows):
        if index % 2:
            _reflect_row(row, width)
        row.y = y
        _translate(row.nodes, row.links, side_pad, y)
        for node in row.nodes:
            node.row_index = index
        nodes.extend(row.nodes)
        links.extend(row.links)
        y += row.height
        if index + 1 < len(rows):
            y += 48 + LANE_GAP * sum(
                bool(e.wrapped_inputs) for e in rows[index + 1].links
            )

    by_key = {node.key: node for node in nodes}
    for row in rows:
        boundary = sorted(
            (e for e in row.links if e.wrapped_inputs),
            key=lambda e: e.node.y + e.node.h / 2,
        )
        for index, edge in enumerate(boundary):
            right = edge.node.row_index % 2
            sign = 1 if right else -1
            outer = side_pad + width if right else side_pad
            lane = outer + sign * (16 + index * LANE_GAP)
            jx, jy = edge.lead[0]
            inputs = dict(edge.inputs)
            for key in edge.wrapped_inputs:
                child = by_key[key]
                cy = child.y + child.h / 2
                inputs[key] = [
                    (child.x + child.w if right else child.x, cy),
                    (lane, cy),
                    (lane, jy),
                    (jx, jy),
                ]
            edge.inputs = [
                (c.key, inputs[c.key]) for c in originals[edge.node.key].children
            ]
    for node in nodes:
        node.children = [by_key[c.key] for c in originals[node.key].children]
    return RouteScene(nodes, links, rows, chain, width + 2 * side_pad, y, "snake")


def _score(scene):
    length = sum(
        abs(b[0] - a[0]) + abs(b[1] - a[1])
        for edge in scene.links
        for path in [edge.lead, *(p for _, p in edge.inputs)]
        for a, b in zip(path, path[1:])
    )
    return scene.height + 0.25 * scene.width, scene.height * scene.width, length


def _improves(candidate, current, budget):
    """Trade modest width for height within a fixed 5% initial-area allowance.

    The allowance is relative to the initial scene, never compounded across
    moves. Height cannot increase and the soft content-width bound still applies.
    """
    pad = budget.width - max(r.width for r in budget.rows)
    return (
        candidate.width <= max(budget.width, ROW_WIDTH_TARGET * 1.1 + pad) + 1e-8
        and candidate.height <= current.height + 1e-8
        and candidate.width * candidate.height
        <= 1.05 * budget.width * budget.height + 1e-8
        and max(r.height for r in candidate.rows)
        <= max(ROW_HEIGHT_TARGET, max(r.height for r in budget.rows)) + 1e-8
        and _score(candidate) < _score(current)
    )


def snake_layout(
    *, columns, originals, heights, parents, sibling_order, chain, layout_tree, compact
):
    """Try short branches near their join, retaining only measured improvements.

    Branches of up to four reactions may move wholly onto their consumer's row.
    Alternative final-row spans are tried before relocation; backbone row
    membership stays fixed within each relocation search. Candidate geometry
    includes completed lane routing; deterministic best-first moves stop when
    no improvement remains.
    """
    assemble = dict(
        columns=columns,
        originals=originals,
        parents=parents,
        sibling_order=sibling_order,
        chain=chain,
        compact=compact,
    )

    def descendants(node):
        return (
            node.key,
            *(key for child in node.children for key in descendants(child)),
        )

    branches = []
    for node in originals.values():
        if len(node.children) < 2:
            continue
        main = main_child(node, heights, contributors=True)
        for child in node.children:
            if child is main or not child.children:
                continue
            keys = descendants(child)
            if (
                sum(bool(originals[key].children) for key in keys)
                <= PREFERRED_MAX_REACTIONS
            ):
                branches.append((node.key, keys))

    def relocate(current, bands, budget):
        while branches:
            assignment = {n.key: n.row_index for n in current.nodes}
            winner = current
            for parent, keys in branches:
                destination = assignment[parent]
                if all(assignment[k] == destination for k in keys):
                    continue
                candidate_assignment = {
                    **assignment,
                    **dict.fromkeys(keys, destination),
                }
                for local in (False, True):
                    rows = []
                    for index, band in enumerate(bands):
                        members = {
                            k for k, r in candidate_assignment.items() if r == index
                        }
                        roots = [
                            n
                            for k, n in originals.items()
                            if k in members and parents.get(k) not in members
                        ]
                        rows.append(
                            _measure(
                                {band.low_depth: roots},
                                band.high_depth,
                                band.low_depth,
                                band.reaction_span,
                                layout_tree=layout_tree,
                                compact=compact,
                                heights=heights,
                                members=members,
                                local_branches=local,
                            )
                        )
                    candidate = _assemble(rows, **assemble)
                    if _improves(candidate, winner, budget):
                        winner = candidate
            if winner is current:
                break
            current = winner
        return current

    best = budget = None
    seen = set()
    # A different final-row span can make room for a complete short branch.
    # Keep one DP optimum per span, rather than enumerating every partition.
    endings = (None, *range(1, PREFERRED_MAX_REACTIONS + 1)) if branches else (None,)
    for ending in endings:
        for local in (False, True):
            rows = _plan_rows(
                columns=columns,
                heights=heights,
                chain=chain,
                layout_tree=layout_tree,
                compact=compact,
                local_branches=local,
                last_span=ending,
            )
            if rows is None:
                continue
            key = (local, tuple((r.high_depth, r.low_depth) for r in rows))
            if key in seen:
                continue
            seen.add(key)
            scene = _assemble(rows, **assemble)
            if budget is None:
                budget = scene
            if best is None or _improves(scene, best, budget):
                best = scene
            relocated = relocate(scene, rows, budget)
            if _improves(relocated, best, budget):
                best = relocated
    return best
