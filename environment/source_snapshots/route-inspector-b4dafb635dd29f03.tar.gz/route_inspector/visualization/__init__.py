"""Route and tactic rendering with a curated notebook display API.

Route rendering, standalone tactic rendering, and notebook display live in
dedicated submodules. Package exports provide the documented API and keep
interactive dependencies lazy.
"""

from __future__ import annotations

from functools import partial
from pathlib import Path
from typing import Any, Mapping, Sequence

import route_inspector.routes.access as route_access
from route_inspector.visualization import notebook as _notebook
from route_inspector.visualization.route import (
    PG_STRATEGY_HIGHLIGHT_COLORS,
    RRSEQ_ATOM_HIGHLIGHT_COLOR,
    RRSEQ_ATOM_HIGHLIGHT_OPACITY,
    RRSEQ_SKIPPED_ATOM_HIGHLIGHT_COLOR,
    RRSEQ_SKIPPED_ATOM_HIGHLIGHT_OPACITY,
)
from route_inspector.visualization.route import (
    write_routes_html as _write_routes_html,
)
from route_inspector.visualization.rrseq import get_rrseq_svg
from route_inspector.visualization.rrsubtree import get_rrsubtree_svg
from route_inspector.visualization.synplanner import get_route_svg_from_json


def _ipython_display():
    """Load notebook display primitives only when a helper is used."""

    return _notebook.load_ipython_display()


def show_route(
    routes_json: route_access.RouteCollection,
    route_id: Any,
    *,
    labeled: bool = True,
    box_solid: bool = False,
    compact: bool = True,
    layered: bool = False,
    layered_flow: str = "forward",
    rrseq_occurrence: Mapping[str, Any] | None = None,
    rrsubtree_occurrence: Mapping[str, Any] | None = None,
    retro_bleu_bigram_occurrence: Mapping[str, Any] | None = None,
    pg_strategy_occurrence: Mapping[str, Any] | None = None,
    highlight_skipped_steps: bool = False,
) -> None:
    """Display a SynPlanner-style route with the existing occurrence overlays.

    Compact branch packing and spacing are enabled by default, without changing
    molecule scale. Set ``compact=False`` to restore the spacious layout.
    ``layered=True`` automatically chooses breaks from molecule/label sizes
    and branch height. Connected rows read left-to-right toward the bottom-row
    target, without repeating intermediates or adding layout labels. No manual
    reaction count or route-data changes are needed. Main-chain intermediates
    share a horizontal baseline; side inputs are packed above or below it.
    Only long between-row connectors are dashed; within-row arrows and input
    branches remain solid. Set ``layered_flow="snake"`` to alternate row
    direction and turn on the same side, without mirroring molecules or text.
    """
    _notebook.display_route(
        routes_json,
        route_id,
        labeled=labeled,
        box_solid=box_solid,
        rrseq_occurrence=rrseq_occurrence,
        rrsubtree_occurrence=rrsubtree_occurrence,
        retro_bleu_bigram_occurrence=retro_bleu_bigram_occurrence,
        pg_strategy_occurrence=pg_strategy_occurrence,
        highlight_skipped_steps=highlight_skipped_steps,
        route_renderer=partial(
            get_route_svg_from_json,
            compact=compact,
            layered=layered,
            layered_flow=layered_flow,
        ),
        display_loader=_ipython_display,
    )


def show_rrsubtree(
    rrsubtree_occurrence: Mapping[str, Any] | str,
    *,
    rule_legend: Mapping[str, str] | None = None,
    view: str = "rules",
) -> None:
    """Display a chemical RRSubtree occurrence or encoded rule tree.

    ``view='compact'`` shows a label tree plus a depicted rule legend. Shorthand
    strings require a complete ``rule_legend``; quoted inline strings do not.
    """

    _notebook.display_rrsubtree(
        rrsubtree_occurrence,
        rule_legend=rule_legend,
        view=view,
        rrsubtree_renderer=get_rrsubtree_svg,
        display_loader=_ipython_display,
    )


def show_rrseq(
    rrseq_occurrence: Mapping[str, Any] | str,
    *,
    separator: str = "$",
    inter_selection_gap_widths: Sequence[int] | None = None,
) -> None:
    """Display a boxed RRSeq in retrosynthetic order, with per-edge gap widths."""
    SVG, display = _ipython_display()
    display(
        SVG(
            get_rrseq_svg(
                rrseq_occurrence,
                separator=separator,
                inter_selection_gap_widths=inter_selection_gap_widths,
            )
        )
    )


def show_rule_sequence(sequence: str, *, separator: str = "$") -> None:
    """Display each SMARTS rule in a serialized RRSeq."""

    _notebook.display_rule_sequence(
        sequence,
        separator=separator,
        display_loader=_ipython_display,
    )


def write_routes_html(
    routes_json: route_access.RouteCollection,
    output_path: str | Path,
    *,
    labeled: bool = True,
    box_solid: bool = True,
    title: str = "Expanded RRseq Routes Report",
) -> Path:
    """Write a self-contained SVG report for route JSON, including dotted IDs."""

    return _write_routes_html(
        routes_json,
        output_path,
        route_renderer=get_route_svg_from_json,
        labeled=labeled,
        box_solid=box_solid,
        title=title,
    )


__all__ = [
    "PG_STRATEGY_HIGHLIGHT_COLORS",
    "RRSEQ_ATOM_HIGHLIGHT_COLOR",
    "RRSEQ_ATOM_HIGHLIGHT_OPACITY",
    "RRSEQ_SKIPPED_ATOM_HIGHLIGHT_COLOR",
    "RRSEQ_SKIPPED_ATOM_HIGHLIGHT_OPACITY",
    "get_route_svg_from_json",
    "get_rrsubtree_svg",
    "get_rrseq_svg",
    "show_route",
    "show_rrsubtree",
    "show_rrseq",
    "show_rule_sequence",
    "write_routes_html",
]
