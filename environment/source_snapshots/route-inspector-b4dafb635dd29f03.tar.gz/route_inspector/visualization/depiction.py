"""Isolate Chython's process-wide depiction settings across rendering callers."""

from contextlib import contextmanager
from threading import RLock

_LOCK = RLock()


@contextmanager
def depiction_settings(*, aam: bool, monochrome: bool | None = None):
    """Serialize drawing and restore all settings, even on renderer errors."""
    from chython import depict_settings
    from chython.algorithms.depict import _render_config

    with _LOCK:
        previous = dict(_render_config)
        try:
            depict_settings(
                aam=aam,
                **({"monochrome": monochrome} if monochrome is not None else {}),
            )
            yield
        finally:
            _render_config.clear()
            _render_config.update(previous)
