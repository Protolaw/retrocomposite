"""Internal notebook display adapters for visualization SVG producers."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

import route_inspector.routes.access as route_access

DisplayLoader = Callable[[], tuple[Any, Callable[[Any], Any]]]
RouteRenderer = Callable[..., str]
RRSubtreeRenderer = Callable[..., str]


def load_ipython_display() -> tuple[Any, Callable[[Any], Any]]:
    """Load notebook display primitives only for interactive helpers."""

    try:
        from IPython.display import SVG, display
    except ImportError as exc:  # pragma: no cover - optional environment
        raise RuntimeError("notebook visualization helpers require IPython") from exc
    return SVG, display


def display_route(
    routes_json: route_access.RouteCollection,
    route_id: Any,
    *,
    labeled: bool,
    box_solid: bool,
    rrseq_occurrence: Mapping[str, Any] | None,
    rrsubtree_occurrence: Mapping[str, Any] | None,
    retro_bleu_bigram_occurrence: Mapping[str, Any] | None,
    pg_strategy_occurrence: Mapping[str, Any] | None,
    highlight_skipped_steps: bool,
    route_renderer: RouteRenderer,
    display_loader: DisplayLoader,
) -> None:
    """Display a route SVG produced through the public rendering seam."""

    SVG, display = display_loader()
    renderer_kwargs = {
        "labeled": labeled,
        "box_solid": box_solid,
        "rrseq_occurrence": rrseq_occurrence,
        "rrsubtree_occurrence": rrsubtree_occurrence,
        "highlight_skipped_steps": highlight_skipped_steps,
    }
    if retro_bleu_bigram_occurrence is not None:
        renderer_kwargs["retro_bleu_bigram_occurrence"] = retro_bleu_bigram_occurrence
    if pg_strategy_occurrence is not None:
        renderer_kwargs["pg_strategy_occurrence"] = pg_strategy_occurrence
    display(SVG(route_renderer(routes_json, route_id, **renderer_kwargs)))


def display_rrsubtree(
    rrsubtree_occurrence: Mapping[str, Any] | str,
    *,
    rule_legend: Mapping[str, str] | None = None,
    view: str = "rules",
    rrsubtree_renderer: RRSubtreeRenderer,
    display_loader: DisplayLoader,
) -> None:
    """Display a standalone RRSubtree SVG through the public rendering seam."""

    SVG, display = display_loader()
    options = {}
    if rule_legend is not None:
        options["rule_legend"] = rule_legend
    if view != "rules":
        options["view"] = view
    display(SVG(rrsubtree_renderer(rrsubtree_occurrence, **options)))


def display_rule_sequence(
    sequence: str,
    *,
    separator: str,
    display_loader: DisplayLoader,
) -> None:
    """Display each SMARTS rule in a serialized sequence."""

    from chython import depict_settings, smarts

    _SVG, display = display_loader()
    depict_settings(aam=False, monochrome=False)
    for rule in str(sequence).split(separator):
        display(smarts(rule))
