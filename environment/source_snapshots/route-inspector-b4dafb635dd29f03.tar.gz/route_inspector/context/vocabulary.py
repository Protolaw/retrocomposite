"""Pinned open functional-group vocabulary and fail-closed curation manifest.

The upstream Chython rule table is deliberately kept byte-for-byte intact under
``context/vendor``.  This module is Route Inspector's independently designed
adapter: it checks the pinned source hash, compiles the rules with the installed
``chython-synplan`` parser, and attaches an owned statistical manifest.

The manifest is exhaustive at runtime. A new upstream rule makes loading fail
until it receives an explicit family, one of the five strata, nonempty anchors,
overlap precedence, and a context-statistics eligibility decision.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from enum import StrEnum
from functools import lru_cache
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

from route_inspector.context.vendor.chython import SMARTS_COMPATIBILITY_ADAPTER_VERSION
from route_inspector.infrastructure.hashing import sha256_file as _sha256

VOCABULARY_SCHEMA_VERSION = 1
UPSTREAM_COMMIT = "20afdbab7040f8d08a899938b8dab15e8d956f49"
UPSTREAM_SOURCE_SHA256 = (
    "4693b9ca7c461ed2fa0216f42b3475fcde1b826662394f2d9d236ea7abeca09a"
)
UPSTREAM_SOURCE_GIT_BLOB = "c1f66566bd8bc6b6d7df06d1c980f2ca20488ebb"
UPSTREAM_LICENSE_SHA256 = (
    "e3a994d82e644b03a792a930f574002658412f62407f5fee083f2555c5f23118"
)
UPSTREAM_SOURCE_URL = (
    "https://github.com/chython/chython/blob/"
    f"{UPSTREAM_COMMIT}/chython/algorithms/groups/_functional.py"
)

_VENDOR_ROOT = Path(__file__).with_name("vendor") / "chython"
_SOURCE_PATH = _VENDOR_ROOT / "algorithms" / "groups" / "_functional.py"
_LICENSE_PATH = _VENDOR_ROOT / "COPYING.LESSER"


class VocabularyIntegrityError(RuntimeError):
    """Raised when the pinned source or its owned manifest is inconsistent."""


class PatternStratum(StrEnum):
    """Scientific role assigned by the Route Inspector manifest."""

    PRIMARY_FUNCTIONAL_GROUP = "primary_functional_group"
    REACTIVE_HANDLE = "reactive_handle"
    COMPOSITE_MOTIF = "composite_motif"
    SCAFFOLD_DESCRIPTOR = "scaffold_descriptor"
    ALERT = "alert"


@dataclass(frozen=True)
class FunctionalPattern:
    """One upstream SMARTS query plus Route Inspector-owned semantics."""

    name: str
    family_id: str
    stratum: PatternStratum
    context_eligible: bool
    anchor_query_atoms: tuple[int, ...]
    overlap_precedence: int
    alias_of: str | None = None
    suppresses: tuple[str, ...] = ()
    curation_status: str = "curated"

    def __post_init__(self) -> None:
        if not self.name or not self.family_id:
            raise ValueError("pattern name and family_id must be non-empty")
        if len(set(self.anchor_query_atoms)) != len(self.anchor_query_atoms):
            raise ValueError(f"duplicate anchor query atoms for {self.name}")
        if self.context_eligible and not self.anchor_query_atoms:
            raise ValueError(
                f"context-eligible pattern {self.name!r} has no explicit anchors"
            )
        if self.context_eligible and self.stratum not in {
            PatternStratum.PRIMARY_FUNCTIONAL_GROUP,
            PatternStratum.REACTIVE_HANDLE,
        }:
            raise ValueError(
                "only primary functional groups and reactive handles may be "
                f"context-eligible: {self.name}"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "family_id": self.family_id,
            "stratum": self.stratum.value,
            "context_eligible": self.context_eligible,
            "anchor_query_atoms": list(self.anchor_query_atoms),
            "overlap_precedence": self.overlap_precedence,
            "alias_of": self.alias_of,
            "suppresses": list(self.suppresses),
            "curation_status": self.curation_status,
        }


@dataclass(frozen=True)
class FunctionalGroupVocabulary:
    """Compiled upstream queries and the exhaustive owned manifest."""

    patterns: Mapping[str, FunctionalPattern]
    queries: Mapping[str, Any]
    schema_version: int = VOCABULARY_SCHEMA_VERSION
    upstream_commit: str = UPSTREAM_COMMIT
    source_sha256: str = UPSTREAM_SOURCE_SHA256

    def __post_init__(self) -> None:
        pattern_names = set(self.patterns)
        query_names = set(self.queries)
        if pattern_names != query_names:
            missing = sorted(query_names - pattern_names)
            extra = sorted(pattern_names - query_names)
            raise VocabularyIntegrityError(
                "manifest/query names differ; "
                f"missing_manifest={missing}, extra_manifest={extra}"
            )

    @property
    def version_id(self) -> str:
        return f"chython-functional-{self.upstream_commit[:12]}-manifest-v{self.schema_version}"

    @property
    def manifest_sha256(self) -> str:
        encoded = json.dumps(
            self.manifest_dict(),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
        ).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()

    def manifest_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "vocabulary_version": self.version_id,
            "upstream_commit": self.upstream_commit,
            "upstream_source_url": UPSTREAM_SOURCE_URL,
            "upstream_source_git_blob": UPSTREAM_SOURCE_GIT_BLOB,
            "source_sha256": self.source_sha256,
            "license": "LGPL-3.0-or-later",
            "license_sha256": UPSTREAM_LICENSE_SHA256,
            "smarts_compatibility": {
                "adapter_version": SMARTS_COMPATIBILITY_ADAPTER_VERSION,
                "pinned_x_semantics": "heteroatom_neighbor_count",
                "daylight_runtime_primitive": "y",
            },
            "fail_closed": True,
            "patterns": {
                name: self.patterns[name].to_dict() for name in sorted(self.patterns)
            },
        }


@dataclass(frozen=True)
class _Curated:
    family: str
    stratum: PatternStratum
    anchors: tuple[int, ...]
    precedence: int = 100
    alias_of: str | None = None
    suppresses: tuple[str, ...] = ()
    eligible: bool | None = None


def _primary(
    family: str,
    *anchors: int,
    precedence: int = 100,
    alias_of: str | None = None,
    suppresses: tuple[str, ...] = (),
) -> _Curated:
    return _Curated(
        family,
        PatternStratum.PRIMARY_FUNCTIONAL_GROUP,
        tuple(anchors),
        precedence,
        alias_of,
        suppresses,
    )


def _handle(
    family: str,
    *anchors: int,
    precedence: int = 100,
    alias_of: str | None = None,
) -> _Curated:
    return _Curated(
        family,
        PatternStratum.REACTIVE_HANDLE,
        tuple(anchors),
        precedence,
        alias_of,
    )


def _descriptor(
    family: str,
    stratum: PatternStratum,
    *anchors: int,
    suppresses: tuple[str, ...] = (),
) -> _Curated:
    return _Curated(
        family,
        stratum,
        tuple(anchors),
        200,
        suppresses=suppresses,
        eligible=False,
    )


# Explicit chemistry curation. The loader rejects any pinned name absent here.
_CURATED: dict[str, _Curated] = {
    "terminal_alkene": _primary("carbon.unsaturation.alkene", 1, 2),
    "alkene": _primary("carbon.unsaturation.alkene", 1, 2),
    "terminal_alkyne": _primary("carbon.unsaturation.alkyne", 1, 2),
    "alkyne": _primary("carbon.unsaturation.alkyne", 1, 2),
    "vicinal_diol": _primary("oxygen.vicinal_diol", 1, 2),
    "primary_alcohol": _primary("oxygen.alcohol", 1),
    "secondary_alcohol": _primary("oxygen.alcohol", 1),
    "tertiary_alcohol": _primary("oxygen.alcohol", 1),
    "phenol": _primary("oxygen.phenol", 1),
    "aldehyde": _primary("carbonyl.aldehyde", 1, 2),
    "ketone": _primary("carbonyl.ketone", 1, 2),
    "carboxylic_acid": _primary("carbonyl.carboxylic_acid", 1, 2, 100, precedence=50),
    "alkyl_carboxylic_acid": _primary(
        "carbonyl.carboxylic_acid",
        1,
        2,
        100,
        precedence=100,
        alias_of="carboxylic_acid",
    ),
    "aryl_carboxylic_acid": _primary(
        "carbonyl.carboxylic_acid",
        1,
        2,
        100,
        precedence=100,
        alias_of="carboxylic_acid",
    ),
    "alkenyl_carboxylic_acid": _primary(
        "carbonyl.carboxylic_acid",
        1,
        2,
        100,
        precedence=100,
        alias_of="carboxylic_acid",
    ),
    "alkynyl_carboxylic_acid": _primary(
        "carbonyl.carboxylic_acid",
        1,
        2,
        100,
        precedence=100,
        alias_of="carboxylic_acid",
    ),
    "cyclic_carboxylic_acid": _primary(
        "carbonyl.carboxylic_acid",
        1,
        2,
        100,
        precedence=100,
        alias_of="carboxylic_acid",
    ),
    "primary_amine": _primary("nitrogen.amine.primary", 1),
    "primary_aniline": _primary("nitrogen.amine.primary", 1),
    "secondary_amine": _primary("nitrogen.amine.secondary", 1),
    "secondary_aniline": _primary("nitrogen.amine.secondary", 1),
    "biaryl_aniline": _primary("nitrogen.amine.secondary", 1),
    "tertiary_amine": _primary("nitrogen.amine.tertiary", 1),
    "ester": _primary("carbonyl.ester", 1, 2, 100),
    "primary_amide": _primary("carbonyl.amide.primary", 1, 2, 3),
    "secondary_amide": _primary("carbonyl.amide.secondary", 1, 2, 3),
    "sulfo": _primary("sulfur.sulfonic_acid", 1, 2, 3, 4),
    "sulfonamide": _primary("sulfur.sulfonamide", 1, 2, 3, 100),
    "nitrile": _primary("nitrogen.nitrile", 1, 2),
    "azide": _primary("nitrogen.azide", 1, 2, 3),
    "diazo": _primary("nitrogen.diazo", 1, 2, 3),
    "diazonium": _primary("nitrogen.diazonium", 1, 2, 3),
    "azo": _primary("nitrogen.azo", 1, 2),
    "isocyanate": _primary("nitrogen.isocyanate", 1, 2, 3),
    "isocyano": _primary("nitrogen.isocyanide", 1, 2),
    "guanidine": _primary("nitrogen.guanidine", 1, 2, 3, 4),
    "nitro": _primary("nitrogen.nitro", 1, 2, 3),
    "thiol": _primary("sulfur.thiol", 1),
    "aryl_thiol": _primary("sulfur.thiol", 1),
    "thioether": _primary("sulfur.thioether", 1),
    "sulfoxide": _primary("sulfur.sulfoxide", 1, 2),
    "sulfone": _primary("sulfur.sulfone", 1, 2, 3),
    "thioamide": _primary("carbonyl.thioamide", 1, 2, 3),
    "amidine": _primary("nitrogen.amidine", 1, 2, 3),
    "amidoxime": _primary("nitrogen.amidoxime", 1, 2, 3, 4),
    "urea": _primary("carbonyl.urea", 1, 2, 3, 4),
    "thiourea": _primary("carbonyl.thiourea", 1, 2, 3, 4),
    "hydroxamic_acid": _primary("carbonyl.hydroxamic_acid", 1, 2, 3, 4),
    "hydrazide": _primary("carbonyl.hydrazide", 1, 2, 3, 4),
    "oxime": _primary("nitrogen.oxime", 1, 2, 3),
    "thioester": _primary("carbonyl.thioester", 1, 2, 100),
    "epoxide": _primary("oxygen.epoxide", 1, 2, 3),
    "nitroso": _primary("nitrogen.nitroso", 1, 2),
    "isothiocyanate": _primary("nitrogen.isothiocyanate", 1, 2, 3),
    "peroxide": _primary("oxygen.peroxide", 1, 2),
    "disulfide": _primary("sulfur.disulfide", 1, 2),
    "aryl_fluoride": _handle("halide.aryl.fluoride", 1, 100),
    "aryl_chloride": _handle("halide.aryl.chloride", 1, 100),
    "aryl_bromide": _handle("halide.aryl.bromide", 1, 100),
    "aryl_iodide": _handle("halide.aryl.iodide", 1, 100),
    "alkyl_fluoride": _handle("halide.alkyl.fluoride", 1, 100),
    "alkyl_chloride": _handle("halide.alkyl.chloride", 1, 100),
    "alkyl_bromide": _handle("halide.alkyl.bromide", 1, 100),
    "alkyl_iodide": _handle("halide.alkyl.iodide", 1, 100),
    "alkenyl_fluoride": _handle("halide.alkenyl.fluoride", 1, 100),
    "alkenyl_chloride": _handle("halide.alkenyl.chloride", 1, 100),
    "alkenyl_bromide": _handle("halide.alkenyl.bromide", 1, 100),
    "alkenyl_iodide": _handle("halide.alkenyl.iodide", 1, 100),
    "alkynyl_fluoride": _handle("halide.alkynyl.fluoride", 1, 100),
    "alkynyl_chloride": _handle("halide.alkynyl.chloride", 1, 100),
    "alkynyl_bromide": _handle("halide.alkynyl.bromide", 1, 100),
    "alkynyl_iodide": _handle("halide.alkynyl.iodide", 1, 100),
    "aryl_triflate": _handle("pseudohalide.aryl.triflate", 1, 100),
    "aryl_mesylate": _handle("pseudohalide.aryl.mesylate", 1, 100),
    "aryl_tosylate": _handle("pseudohalide.aryl.tosylate", 1, 100),
    "alkyl_triflate": _handle("pseudohalide.alkyl.triflate", 1, 100),
    "alkyl_mesylate": _handle("pseudohalide.alkyl.mesylate", 1, 100),
    "alkyl_tosylate": _handle("pseudohalide.alkyl.tosylate", 1, 100),
    "aryl_boronic_acid": _handle("organoboron.aryl", 1, 100),
    "aryl_boronic_ester": _handle("organoboron.aryl", 1, 100),
    "alkyl_boronic_acid": _handle("organoboron.alkyl", 1, 100),
    "alkyl_boronic_ester": _handle("organoboron.alkyl", 1, 100),
    "alkenyl_boronic_acid": _handle("organoboron.alkenyl", 1, 100),
    "alkenyl_boronic_ester": _handle("organoboron.alkenyl", 1, 100),
    "alkynyl_boronic_acid": _handle("organoboron.alkynyl", 1, 100),
    "alkynyl_boronic_ester": _handle("organoboron.alkynyl", 1, 100),
    "aryl_molander_salt": _handle("organoboron.aryl", 1, 100),
    "alkyl_molander_salt": _handle("organoboron.alkyl", 1, 100),
    "alkenyl_molander_salt": _handle("organoboron.alkenyl", 1, 100),
    "alkynyl_molander_salt": _handle("organoboron.alkynyl", 1, 100),
    "acyl_chloride": _handle("acyl_halide.chloride", 1, 100),
    "acyl_bromide": _handle("acyl_halide.bromide", 1, 100),
    "acyl_fluoride": _handle("acyl_halide.fluoride", 1, 100),
    "sulfonyl_chloride": _handle("sulfonyl_halide.chloride", 1, 100),
    "sulfonyl_fluoride": _handle("sulfonyl_halide.fluoride", 1, 100),
    "alkyl_grignard": _handle("organomagnesium.alkyl", 1, 100),
    "aryl_grignard": _handle("organomagnesium.aryl", 1, 100),
    "alkenyl_grignard": _handle("organomagnesium.alkenyl", 1, 100),
    "alkyl_zinc": _handle("organozinc.alkyl", 1, 100),
    "aryl_zinc": _handle("organozinc.aryl", 1, 100),
    "alkenyl_zinc": _handle("organozinc.alkenyl", 1, 100),
    "aryl_stannane": _handle("organotin.aryl", 1, 100),
    "alkenyl_stannane": _handle("organotin.alkenyl", 1, 100),
    "alkyl_stannane": _handle("organotin.alkyl", 1, 100),
    "aryl_silane": _handle("organosilicon.aryl", 1, 100),
    "alkenyl_silane": _handle("organosilicon.alkenyl", 1, 100),
    "alkynyl_silane": _handle("organosilicon.alkynyl", 1, 100),
    "phosphonium_ylide": _handle("phosphorus.ylide", 1, 100),
    "phosphonate": _handle("phosphorus.phosphonate", 1, 100),
    "anhydride": _descriptor(
        "carbonyl.anhydride",
        PatternStratum.COMPOSITE_MOTIF,
        1,
        2,
        3,
        4,
        100,
        suppresses=("ester",),
    ),
    "fused_aromatic": _descriptor(
        "scaffold.fused_aromatic", PatternStratum.SCAFFOLD_DESCRIPTOR, 1
    ),
    "polyarene": _descriptor(
        "scaffold.polyarene", PatternStratum.SCAFFOLD_DESCRIPTOR, 1, 2, 3, 4, 5, 6, 7
    ),
    "diaryl": _descriptor("scaffold.diaryl", PatternStratum.SCAFFOLD_DESCRIPTOR, 1, 2),
    "bridged_diaryl": _descriptor(
        "scaffold.bridged_diaryl", PatternStratum.SCAFFOLD_DESCRIPTOR, 1, 2, 3
    ),
    "catechol": _descriptor("alert.catechol", PatternStratum.ALERT, 1, 2, 3, 4),
    "vinyl_sulfone": _descriptor(
        "alert.vinyl_sulfone", PatternStratum.ALERT, 1, 2, 3, 4, 5, 100
    ),
    "maleimide": _descriptor(
        "alert.maleimide", PatternStratum.ALERT, 1, 2, 3, 4, 5, 6, 7
    ),
}

_CURATED.update(
    {
        "1_2_diketone": _descriptor(
            "motif.1_2_diketone", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 4
        ),
        "1_3_diketone": _descriptor(
            "motif.1_3_diketone", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 4, 5
        ),
        "1_4_diketone": _descriptor(
            "motif.1_4_diketone", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 4, 5, 6
        ),
        "NO_dialkylhydroxylamine": _primary(
            "nitrogen.hydroxylamine.no_dialkyl", 1, 2, 3, 4
        ),
        "O_alkylhydroxylamine": _primary("nitrogen.hydroxylamine.o_alkyl", 1, 2, 3),
        "activated_isocyanide": _handle("isocyanide.activated", 1, 2, 3),
        "active_methylene": _descriptor(
            "motif.active_methylene", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3
        ),
        "alkyl_hydrazine": _primary("nitrogen.hydrazine.alkyl", 1, 2, 3),
        "alpha_haloester": _descriptor(
            "motif.alpha_haloester", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 100
        ),
        "alpha_haloketone": _descriptor(
            "motif.alpha_haloketone", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 100
        ),
        "alpha_ketone": _descriptor(
            "motif.alpha_ketone", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3
        ),
        "amino_alcohol": _descriptor(
            "motif.amino_alcohol", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 4
        ),
        "aminopyridine": _descriptor(
            "motif.aminopyridine", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3
        ),
        "aniline_ortho_ch": _descriptor(
            "motif.aniline_ortho_ch", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3
        ),
        "anthranilic_acid": _descriptor(
            "motif.anthranilic_acid", PatternStratum.COMPOSITE_MOTIF, 1, 3, 4, 5, 6, 100
        ),
        "arene_ch": _descriptor(
            "scaffold.arene_ch", PatternStratum.SCAFFOLD_DESCRIPTOR, 1
        ),
        "aryl_carbonate": _handle("carbonate.aryl", 1, 2, 3, 100),
        "aryl_hydrazine": _primary("nitrogen.hydrazine.aryl", 1, 2, 3),
        "aryl_hydrazine_ortho_ch": _descriptor(
            "motif.aryl_hydrazine_ortho_ch", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 4
        ),
        "azinone": _primary("carbonyl.azinone", 1, 2, 3),
        "aziridine_nh": _primary("nitrogen.aziridine_nh", 1),
        "benzylic_ch": _descriptor(
            "scaffold.benzylic_ch", PatternStratum.SCAFFOLD_DESCRIPTOR, 1, 2
        ),
        "beta_arylethylamine": _descriptor(
            "motif.beta_arylethylamine", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 4, 5
        ),
        "beta_ketoester": _descriptor(
            "motif.beta_ketoester", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 4, 5, 100
        ),
        "boronate_alkyl_bromide": _handle("halide.boronate_alkyl.bromide", 1, 100),
        "boronate_alkyl_chloride": _handle("halide.boronate_alkyl.chloride", 1, 100),
        "boronate_alkyl_iodide": _handle("halide.boronate_alkyl.iodide", 1, 100),
        "carbamoyl_chloride": _handle("carbamoyl_halide.chloride", 1, 2, 3, 100),
        "carbamoyl_fluoride": _handle("carbamoyl_halide.fluoride", 1, 2, 3, 100),
        "chloroazine": _handle("halide.chloroazine", 1, 3, 100),
        "chloroformate": _handle("carbonate.chloroformate", 1, 2, 3, 100),
        "difluoromethyl": _descriptor(
            "descriptor.difluoromethyl", PatternStratum.SCAFFOLD_DESCRIPTOR, 1, 2, 3
        ),
        "enal": _descriptor("motif.enal", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 4),
        "enamine": _primary("nitrogen.enamine", 1, 2, 3),
        "enol_ether": _primary("oxygen.enol_ether", 1, 2, 3),
        "fluoroformate": _handle("carbonate.fluoroformate", 1, 2, 3, 100),
        "hydrazone": _primary("nitrogen.hydrazone", 1, 2, 3),
        "imidazole": _descriptor(
            "scaffold.imidazole", PatternStratum.SCAFFOLD_DESCRIPTOR, 1, 2, 3
        ),
        "imidazolyl_carbonate": _handle("carbonate.imidazolyl", 1, 2, 3, 100),
        "isoxazole": _descriptor(
            "scaffold.isoxazole", PatternStratum.SCAFFOLD_DESCRIPTOR, 1, 2
        ),
        "methyl_ester": _primary(
            "carbonyl.ester", 1, 2, 3, precedence=200, alias_of="ester"
        ),
        "nh_thiourea": _primary(
            "carbonyl.thiourea", 1, 2, 3, 4, precedence=200, alias_of="thiourea"
        ),
        "nh_urea": _primary(
            "carbonyl.urea", 1, 2, 3, 4, precedence=200, alias_of="urea"
        ),
        "o_aminobenzaldehyde": _descriptor(
            "motif.o_aminobenzaldehyde", PatternStratum.COMPOSITE_MOTIF, 1, 3, 4, 5, 6
        ),
        "o_aminophenol": _descriptor(
            "motif.o_aminophenol", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 4
        ),
        "o_aminothiophenol": _descriptor(
            "motif.o_aminothiophenol", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 4
        ),
        "o_diaminoarene": _descriptor(
            "motif.o_diaminoarene", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 4
        ),
        "o_haloaniline": _descriptor(
            "motif.o_haloaniline", PatternStratum.COMPOSITE_MOTIF, 1, 2, 3, 100
        ),
        "primary_amidine_amine": _primary("nitrogen.amine.amidine", 1, 2),
        "pyrazole": _descriptor(
            "scaffold.pyrazole", PatternStratum.SCAFFOLD_DESCRIPTOR, 1, 2
        ),
        "pyridazine": _descriptor(
            "scaffold.pyridazine", PatternStratum.SCAFFOLD_DESCRIPTOR, 1, 2
        ),
        "pyridine_n": _primary("nitrogen.pyridine", 1),
        "pyrrole": _primary("nitrogen.pyrrole", 1),
        "redox_active_ester": _handle("ester.redox_active", 1, 2, 3, 100),
        "succinimidyl_carbonate": _handle("carbonate.succinimidyl", 1, 2, 3, 100),
        "sulfonyl_anhydride": _handle("sulfonyl.anhydride", 1, 2, 3, 100),
        "sulfonylhydrazide": _primary("sulfur.sulfonylhydrazide", 1, 2, 3, 4, 5),
        "sulfonylhydrazone": _primary("sulfur.sulfonylhydrazone", 1, 2, 3, 100),
        "terminal_epoxide": _primary(
            "oxygen.epoxide", 1, 2, 3, precedence=200, alias_of="epoxide"
        ),
        "tertiary_alcohol_with_alpha_h": _primary(
            "oxygen.alcohol", 1, precedence=200, alias_of="tertiary_alcohol"
        ),
        "tosyl_isocyanide": _handle("isocyanide.tosyl", 1, 2, 3, 100),
        "trifluoromethyl": _descriptor(
            "descriptor.trifluoromethyl", PatternStratum.SCAFFOLD_DESCRIPTOR, 1, 2, 3, 4
        ),
        "weinreb_amide": _handle("amide.weinreb", 1, 2, 100),
    }
)

for _lactam_position in range(1, 7):
    for _halide in ("fluoride", "chloride", "bromide", "iodide"):
        _name = f"lactam_{_lactam_position}_{_halide}"
        _CURATED[_name] = _handle(
            f"halide.lactam.{_halide}",
            1,
            100,
            alias_of=f"aryl_{_halide}",
        )


def verify_vendored_vocabulary() -> None:
    """Fail if the source or license differs from the reviewed snapshot."""

    checks = (
        (_SOURCE_PATH, UPSTREAM_SOURCE_SHA256, "source"),
        (_LICENSE_PATH, UPSTREAM_LICENSE_SHA256, "license"),
    )
    for path, expected, role in checks:
        actual = _sha256(path)
        if actual != expected:
            raise VocabularyIntegrityError(
                f"pinned Chython {role} hash mismatch: expected {expected}, got {actual}"
            )


def _compiled_queries() -> dict[str, Any]:
    # Import only after integrity verification.  ``_rules`` is used instead of the
    # public count-only helper so exact query-to-route mappings remain available.
    from route_inspector.context.vendor.chython.algorithms.groups._functional import (
        _rules,
    )

    return dict(_rules())


def _manifest_for(queries: Mapping[str, Any]) -> dict[str, FunctionalPattern]:
    unknown_curated = sorted(set(_CURATED) - set(queries))
    if unknown_curated:
        raise VocabularyIntegrityError(
            f"curated manifest names absent from pinned vocabulary: {unknown_curated}"
        )

    manifest: dict[str, FunctionalPattern] = {}
    for name in sorted(queries):
        curated = _CURATED.get(name)
        if curated is None:
            raise VocabularyIntegrityError(
                f"pinned functional pattern {name!r} has no manifest assignment"
            )
        eligible = (
            curated.eligible
            if curated.eligible is not None
            else curated.stratum
            in {
                PatternStratum.PRIMARY_FUNCTIONAL_GROUP,
                PatternStratum.REACTIVE_HANDLE,
            }
        )
        query_atoms = {int(atom) for atom in queries[name]}
        missing_anchors = sorted(set(curated.anchors) - query_atoms)
        if missing_anchors:
            raise VocabularyIntegrityError(
                f"manifest anchors absent from {name!r} query: {missing_anchors}"
            )
        manifest[name] = FunctionalPattern(
            name=name,
            family_id=curated.family,
            stratum=curated.stratum,
            context_eligible=eligible,
            anchor_query_atoms=curated.anchors,
            overlap_precedence=curated.precedence,
            alias_of=curated.alias_of,
            suppresses=curated.suppresses,
        )
    return manifest


@lru_cache(maxsize=1)
def load_functional_group_vocabulary() -> FunctionalGroupVocabulary:
    """Load and validate the pinned vocabulary exactly once per process."""

    verify_vendored_vocabulary()
    queries = _compiled_queries()
    manifest = _manifest_for(queries)
    return FunctionalGroupVocabulary(
        patterns=MappingProxyType(manifest),
        queries=MappingProxyType(queries),
    )


__all__ = [
    "FunctionalGroupVocabulary",
    "FunctionalPattern",
    "PatternStratum",
    "UPSTREAM_COMMIT",
    "UPSTREAM_LICENSE_SHA256",
    "UPSTREAM_SOURCE_SHA256",
    "UPSTREAM_SOURCE_URL",
    "VOCABULARY_SCHEMA_VERSION",
    "VocabularyIntegrityError",
    "load_functional_group_vocabulary",
    "verify_vendored_vocabulary",
]
