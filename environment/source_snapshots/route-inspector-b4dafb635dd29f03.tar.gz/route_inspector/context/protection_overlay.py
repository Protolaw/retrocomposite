"""Command orchestration for authoritative route-wide context histories."""

from __future__ import annotations

import csv
import json
from collections import defaultdict
from dataclasses import dataclass, replace
from itertools import islice
from pathlib import Path
from typing import Any, Iterable, Mapping

import route_inspector.routes.access as route_access
from route_inspector import chemistry
from route_inspector.context.history import (
    CONTEXT_HISTORY_IDENTITY_VERSION,
    CONTEXT_HISTORY_SCHEMA_VERSION,
    DEFAULT_CONTEXT_POLICY,
    ContextHistoryError,
    ProtectionAnnotation,
    ProtectionState,
    ProtectionTraceEventValidationError,
    RouteContextHistory,
    _merge_protection_annotations,
    _validate_native_protection_trace_event,
    annotate_route_context,
    context_history_summary,
)
from route_inspector.infrastructure.artifacts import write_json, write_standard_sidecars
from route_inspector.infrastructure.paths import relative_path
from route_inspector.infrastructure.text import read_json
from route_inspector.protection.analysis import (
    PROTECTION_TRACE_EVENT_SCHEMA_VERSION,
    ProtectionAnalysisConfig,
    analyze_protection_in_routes,
)

REFERENCE_SCOPE = "all_data"
_CONTEXT_POLICY = DEFAULT_CONTEXT_POLICY
PROTECTION_OVERLAY_REJECTION_SCHEMA_VERSION = 1
_CONTEXT_STAGE_ARTIFACT_NAMES = (
    "context_history.jsonl.gz",
    "enriched_routes.json",
    "errors.tsv",
    "manifest.json",
    "mapping_validation.tsv",
    "protection_overlay_rejections.jsonl",
    "protection_trace_events.jsonl",
    "summary.json",
)


class ProtectionEventAssociationError(ValueError):
    def __init__(
        self,
        reason_code: str,
        message: str,
        **details: Any,
    ) -> None:
        super().__init__(message)
        self.reason_code = reason_code
        self.details = dict(details)


class ProtectionEventCompatibilityError(ProtectionEventAssociationError):
    """A scientifically incompatible event that can be rejected locally."""


@dataclass(frozen=True)
class ProtectionOverlayResult:
    histories: tuple[RouteContextHistory, ...]
    accepted_events: tuple[dict[str, Any], ...]
    rejections: tuple[dict[str, Any], ...]


def _limited_collection(collection: Any, limit: int | None) -> Any:
    if limit is None:
        return collection
    if limit < 0:
        raise ValueError("--limit must be non-negative")
    items = list(islice(route_access.route_items(collection), limit))
    if isinstance(collection, list):
        return [route for _route_id, route in items]
    return {route_id: route for route_id, route in items}


def _event_records(path: Path) -> list[dict[str, Any]]:
    """Read mapped tracer events from TSV, JSON, or JSONL."""

    suffixes = path.suffixes
    if path.suffix.lower() == ".tsv":
        with path.open(encoding="utf-8", newline="") as stream:
            return [dict(row) for row in csv.DictReader(stream, delimiter="\t")]
    if ".jsonl" in suffixes:
        import gzip

        opener = gzip.open if path.suffix == ".gz" else open
        with opener(path, "rt", encoding="utf-8") as stream:
            return [json.loads(line) for line in stream if line.strip()]
    value = read_json(path)
    if isinstance(value, list):
        return [dict(item) for item in value]
    if isinstance(value, Mapping):
        records = value.get("events", value.get("protection_events", ()))
        if isinstance(records, list):
            return [dict(item) for item in records]
    raise ValueError(f"unsupported protection-event payload: {path}")


def _atom_maps(value: Any) -> tuple[int, ...]:
    if value in (None, ""):
        return ()
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return ()
        if text.startswith("["):
            value = json.loads(text)
        else:
            value = [part for part in text.split(",") if part.strip()]
    return tuple(sorted({int(atom) for atom in value}))


def _node_path(value: Any, *, field: str) -> tuple[int, ...]:
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return ()
        try:
            value = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"{field} must be a JSON path array") from exc
    if value is None:
        return ()
    if not isinstance(value, (list, tuple)):
        raise ValueError(f"{field} must be a path array")
    return tuple(int(index) for index in value)


def _node_paths(value: Any, *, field: str) -> tuple[tuple[int, ...], ...]:
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return ()
        try:
            value = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"{field} must be a JSON array of path arrays") from exc
    if value is None:
        return ()
    if not isinstance(value, (list, tuple)):
        raise ValueError(f"{field} must be an array of path arrays")
    paths = tuple(_node_path(path, field=field) for path in value)
    if len(set(paths)) != len(paths):
        raise ValueError(f"{field} contains duplicate paths")
    return paths


def _string_tuple(value: Any) -> tuple[str, ...]:
    if value in (None, ""):
        return ()
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return ()
        if text.startswith("["):
            value = json.loads(text)
        else:
            value = [item for item in text.split(",") if item.strip()]
    return tuple(str(item) for item in value)


_SINGLE_PATH_FIELDS = (
    "deprotection_reaction_node_path",
    "protected_precursor_molecule_node_path",
    "protection_reaction_node_path",
    "stock_molecule_node_path",
    "trace_last_successful_node_path",
)
_MULTI_PATH_FIELDS = (
    "interval_reaction_node_paths",
    "protected_molecule_node_paths",
)


def _normalize_protection_event(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Normalize one tracer event while retaining its exact temporal provenance."""

    schema_version = int(
        raw.get("schema_version", PROTECTION_TRACE_EVENT_SCHEMA_VERSION)
    )
    if schema_version != PROTECTION_TRACE_EVENT_SCHEMA_VERSION:
        raise ValueError(
            f"unsupported protection trace-event schema version: {schema_version}"
        )
    route_id = str(raw.get("route_id") or "")
    event_id = str(raw.get("event_id") or "")
    pg_type = str(raw.get("pg_type") or "")
    atom_maps = _atom_maps(
        raw.get("protected_atom_maps", raw.get("protected_atom_ids"))
    )
    protected_paths = _node_paths(
        raw.get("protected_molecule_node_paths"),
        field="protected_molecule_node_paths",
    )
    if not route_id or not event_id or not pg_type or not atom_maps:
        raise ValueError(
            "each protection event requires route_id, event_id, pg_type, and "
            "mapped protected_atom_ids/protected_atom_maps"
        )
    if any(atom <= 0 for atom in atom_maps):
        raise ValueError(
            f"protection event {event_id} requires positive protected atom maps"
        )
    normalized = dict(raw)
    normalized.update(
        {
            "schema_version": schema_version,
            "route_id": route_id,
            "event_id": event_id,
            "pg_type": pg_type,
            "source_type": str(raw.get("source_type") or ""),
            "trace_status": str(raw.get("trace_status") or ""),
            "protected_atom_ids": list(atom_maps),
            "protected_atom_maps": list(atom_maps),
            "matched_deprotection_rules": list(
                _string_tuple(raw.get("matched_deprotection_rules"))
            ),
            "interval_reaction_ids": list(
                _string_tuple(raw.get("interval_reaction_ids"))
            ),
        }
    )
    for field in _SINGLE_PATH_FIELDS:
        normalized[field] = list(_node_path(raw.get(field), field=field))
    for field in _MULTI_PATH_FIELDS:
        paths = (
            protected_paths
            if field == "protected_molecule_node_paths"
            else _node_paths(
                raw.get(field),
                field=field,
            )
        )
        normalized[field] = [list(path) for path in paths]
    return normalized


def _normalized_protection_events(
    events: Iterable[Mapping[str, Any]],
) -> tuple[dict[str, Any], ...]:
    normalized = tuple(_normalize_protection_event(event) for event in events)
    identities = [(event["route_id"], event["event_id"]) for event in normalized]
    if len(set(identities)) != len(identities):
        raise ValueError("duplicate route/event identity in protection trace evidence")
    return tuple(
        sorted(
            normalized,
            key=lambda event: (event["route_id"], event["event_id"]),
        )
    )


def _trace_protection_events(collection: Any) -> tuple[dict[str, Any], ...]:
    """Run the existing mapped tracer once without interval-rule extraction."""

    if not any(True for _route_id, _route in route_access.route_items(collection)):
        return ()
    result = analyze_protection_in_routes(
        collection,
        config=ProtectionAnalysisConfig(
            collect_interval_rules=False,
            ignore_errors=False,
        ),
        collect_interval_rules=False,
        n_cpu=1,
    )
    return _normalized_protection_events(result.trace_event_records)


def _write_protection_events_jsonl(
    path: Path,
    events: Iterable[Mapping[str, Any]],
) -> Path:
    """Write canonical tracer evidence in deterministic route/event order."""

    normalized = _normalized_protection_events(events)
    payload = "".join(
        json.dumps(
            event,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
        )
        + "\n"
        for event in normalized
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload, encoding="utf-8", newline="\n")
    return path


def _overlay_protection_events(
    histories: Iterable[RouteContextHistory],
    events: Iterable[Mapping[str, Any]],
) -> tuple[RouteContextHistory, ...]:
    """Associate tracer events at exact nodes to one persistent FG lineage."""

    histories = tuple(histories)
    events_by_route: dict[str, list[dict[str, Any]]] = defaultdict(list)
    normalized_events = _normalized_protection_events(events)
    for event in normalized_events:
        _validate_native_protection_trace_event(event)
        events_by_route[event["route_id"]].append(event)

    history_route_ids = {history.route_id for history in histories}
    unknown_routes = sorted(set(events_by_route) - history_route_ids)
    if unknown_routes:
        raise ValueError(
            "protection events reference routes absent from context histories: "
            f"{unknown_routes}"
        )

    output: list[RouteContextHistory] = []
    for history in histories:
        route_events = events_by_route.get(history.route_id, ())
        if not route_events:
            output.append(history)
            continue

        records_by_path = {
            record.node_path: record for record in history.molecule_records
        }
        record_atom_maps: dict[tuple[int, ...], set[int]] = {}

        def mapped_atom_ids(record: Any) -> set[int]:
            retained = record_atom_maps.get(record.node_path)
            if retained is None:
                molecule = chemistry.parse_molecule(record.mapped_smiles)
                retained = {int(atom) for atom in molecule}
                record_atom_maps[record.node_path] = retained
            return retained

        lineage_by_observation = {
            observation_id: lineage.lineage_id
            for lineage in history.lineages
            for observation_id in lineage.observation_ids
        }
        observations = history.observation_by_id()
        lineage_observations: dict[str, tuple[Any, ...]] = {
            lineage.lineage_id: tuple(
                observations[observation_id]
                for observation_id in lineage.observation_ids
            )
            for lineage in history.lineages
        }
        matched_events: dict[str, list[dict[str, Any]]] = defaultdict(list)
        linked_events: list[dict[str, Any]] = []
        for event in route_events:
            atom_maps = set(event["protected_atom_maps"])
            path_candidate_sets: list[set[str]] = []
            protected_observations: list[Any] = []
            matching_sites_by_path: list[tuple[Any, ...]] = []

            def site_lineages(site: Any) -> set[str]:
                candidates = set(site.ambiguous_lineage_ids)
                if site.linked_lineage_id is not None:
                    candidates.add(site.linked_lineage_id)
                return candidates

            for raw_path in event["protected_molecule_node_paths"]:
                node_path = tuple(int(index) for index in raw_path)
                record = records_by_path.get(node_path)
                if record is None:
                    raise ProtectionEventAssociationError(
                        "missing_molecule_node_path",
                        f"protection event {event['event_id']} references missing "
                        f"molecule node path {list(node_path)}",
                        node_path=list(node_path),
                    )
                missing_atom_maps = atom_maps - mapped_atom_ids(record)
                if missing_atom_maps:
                    raise ProtectionEventAssociationError(
                        "protected_atom_maps_absent_from_path",
                        f"protection event {event['event_id']} references protected "
                        f"atom maps absent from molecule path {list(node_path)}: "
                        f"{sorted(missing_atom_maps)}",
                        node_path=list(node_path),
                        protected_atom_maps=sorted(atom_maps),
                        missing_atom_maps=sorted(missing_atom_maps),
                    )
                matching_observations = tuple(
                    observation
                    for observation in record.observations
                    if atom_maps.issubset(observation.atom_maps)
                )
                direct_lineages = {
                    lineage_by_observation[observation.observation_id]
                    for observation in matching_observations
                    if observation.observation_id in lineage_by_observation
                }
                atom_matching_sites = tuple(
                    site
                    for site in record.protection_sites
                    if atom_maps == set(site.protected_atom_maps)
                )
                matching_sites = tuple(
                    site
                    for site in atom_matching_sites
                    if event["pg_type"] in site.group_type.split("|")
                )
                if atom_matching_sites and not matching_sites:
                    raise ProtectionEventAssociationError(
                        "conflicting_protection_site_group",
                        f"protection event {event['event_id']} group type differs "
                        f"from exact protection-site evidence at molecule path "
                        f"{list(node_path)}",
                        node_path=list(node_path),
                        event_pg_type=event["pg_type"],
                        site_group_types=sorted(
                            {site.group_type for site in atom_matching_sites}
                        ),
                        protection_site_ids=[
                            site.site_id for site in atom_matching_sites
                        ],
                    )
                site_candidates = {
                    lineage_id
                    for site in matching_sites
                    for lineage_id in site_lineages(site)
                }
                path_candidates = direct_lineages | site_candidates
                if not path_candidates:
                    raise ProtectionEventAssociationError(
                        "missing_protected_path_lineage",
                        f"missing FG-lineage association for protection event "
                        f"{event['event_id']} at molecule node path "
                        f"{list(node_path)}",
                        node_path=list(node_path),
                        observation_ids=[
                            observation.observation_id
                            for observation in matching_observations
                        ],
                        protection_site_ids=[site.site_id for site in matching_sites],
                    )
                path_candidate_sets.append(path_candidates)
                protected_observations.extend(matching_observations)
                matching_sites_by_path.append(matching_sites)

            endpoint_observations: tuple[Any, ...] = ()
            deprotection_path = tuple(
                int(index) for index in event["deprotection_reaction_node_path"]
            )
            if deprotection_path:
                product_record = records_by_path.get(deprotection_path[:-1])
                if product_record is not None:
                    endpoint_observations = tuple(
                        observation
                        for observation in product_record.observations
                        if atom_maps.issubset(observation.atom_maps)
                    )
            endpoint_lineages = {
                lineage_by_observation[observation.observation_id]
                for observation in endpoint_observations
                if observation.observation_id in lineage_by_observation
            }
            evidence_sets = [
                *path_candidate_sets,
                *([endpoint_lineages] if endpoint_lineages else []),
            ]
            candidate_lineages = set.intersection(*evidence_sets)
            if not candidate_lineages:
                raise ProtectionEventAssociationError(
                    "conflicting_lineages_across_event",
                    f"protection event {event['event_id']} has conflicting "
                    "FG-lineage evidence across its protected trace",
                    protected_path_candidate_lineages=[
                        sorted(candidates) for candidates in path_candidate_sets
                    ],
                    endpoint_candidate_lineages=sorted(endpoint_lineages),
                )
            if len(candidate_lineages) > 1:
                raise ProtectionEventAssociationError(
                    "ambiguous_lineage_after_all_evidence",
                    f"ambiguous FG-lineage association for protection event "
                    f"{event['event_id']} after all event evidence; "
                    f"candidate_lineages={sorted(candidate_lineages)}",
                    candidate_lineages=sorted(candidate_lineages),
                )
            lineage_id = next(iter(candidate_lineages))
            event_observation_ids = {
                observation.observation_id
                for observation in (
                    *protected_observations,
                    *endpoint_observations,
                )
                if lineage_by_observation.get(observation.observation_id) == lineage_id
            }
            if not event_observation_ids:
                event_observation_ids.update(
                    observation.observation_id
                    for observation in lineage_observations[lineage_id]
                    if atom_maps.issubset(observation.atom_maps)
                )
            if not event_observation_ids:
                raise ProtectionEventAssociationError(
                    "missing_observation_witness",
                    f"protection event {event['event_id']} has no exact FG "
                    f"observation evidence for lineage {lineage_id}",
                    lineage_id=lineage_id,
                )
            matched_site_ids = {
                site.site_id
                for matching_sites in matching_sites_by_path
                for site in matching_sites
                if lineage_id in site_lineages(site)
            }
            for observation in protected_observations:
                if lineage_by_observation.get(observation.observation_id) == lineage_id:
                    matched_events[observation.observation_id].append(event)
            linked_events.append(
                {
                    **event,
                    "linked_lineage_id": lineage_id,
                    "linked_observation_ids": sorted(event_observation_ids),
                    "matched_protection_site_ids": sorted(matched_site_ids),
                }
            )

        annotations: dict[str, ProtectionAnnotation] = {}
        for observation_id, matches in matched_events.items():
            observation = observations[observation_id]
            tracer_annotation = ProtectionAnnotation(
                state=ProtectionState.PROTECTED,
                group_type="|".join(sorted({event["pg_type"] for event in matches})),
                event_id="|".join(sorted({event["event_id"] for event in matches})),
                rule_ids=tuple(
                    sorted(
                        {
                            rule_id
                            for event in matches
                            for rule_id in event["matched_deprotection_rules"]
                        }
                    )
                ),
                protected_atom_maps=tuple(
                    sorted(
                        {
                            atom
                            for event in matches
                            for atom in event["protected_atom_maps"]
                        }
                    )
                ),
            )
            merged_annotation = _merge_protection_annotations(
                observation.protection,
                tracer_annotation,
            )
            if merged_annotation is None:
                raise RuntimeError(
                    "protection annotation merge unexpectedly produced no evidence"
                )
            annotations[observation_id] = merged_annotation

        annotated = annotate_route_context(history, annotations)
        site_by_id = {
            site.site_id: site
            for record in annotated.molecule_records
            for site in record.protection_sites
        }
        events_by_path_and_lineage: dict[
            tuple[tuple[int, ...], str], list[dict[str, Any]]
        ] = defaultdict(list)
        for event in linked_events:
            lineage_id = event["linked_lineage_id"]
            for raw_path in event["protected_molecule_node_paths"]:
                events_by_path_and_lineage[
                    (tuple(int(index) for index in raw_path), lineage_id)
                ].append(event)

        def mapped_event_annotation(
            node_paths: Iterable[tuple[int, ...]],
            lineage_id: str,
        ) -> ProtectionAnnotation | None:
            node_paths = tuple(node_paths)
            events = {
                event["event_id"]: event
                for node_path in node_paths
                for event in events_by_path_and_lineage.get(
                    (node_path, lineage_id),
                    (),
                )
            }
            if not events:
                return None
            sites = tuple(
                site_by_id[site_id]
                for event in events.values()
                for site_id in event["matched_protection_site_ids"]
                if site_id in site_by_id and site_by_id[site_id].node_path in node_paths
            )
            return ProtectionAnnotation(
                state=ProtectionState.PROTECTED,
                group_type="|".join(
                    sorted({event["pg_type"] for event in events.values()})
                ),
                event_id="|".join(sorted(events)),
                rule_ids=tuple(
                    sorted(
                        {
                            rule_id
                            for event in events.values()
                            for rule_id in event["matched_deprotection_rules"]
                        }
                    )
                ),
                protected_atom_maps=tuple(
                    sorted(
                        {
                            atom
                            for event in events.values()
                            for atom in event["protected_atom_maps"]
                        }
                    )
                ),
                raw_query_mappings=tuple(
                    sorted(
                        {
                            mapping
                            for site in sites
                            for mapping in site.raw_query_mappings
                        }
                    )
                ),
            )

        record_paths = set(records_by_path)
        transitions = []
        for transition in annotated.transitions:
            after_path = transition.reaction_node_path[:-1]
            before_paths = tuple(
                node_path
                for node_path in record_paths
                if len(node_path) == len(transition.reaction_node_path) + 1
                and node_path[:-1] == transition.reaction_node_path
            )
            transitions.append(
                replace(
                    transition,
                    before_protection=_merge_protection_annotations(
                        transition.before_protection,
                        mapped_event_annotation(
                            before_paths,
                            transition.lineage_id,
                        ),
                    ),
                    after_protection=_merge_protection_annotations(
                        transition.after_protection,
                        mapped_event_annotation(
                            (after_path,),
                            transition.lineage_id,
                        ),
                    ),
                )
            )
        annotated = replace(annotated, transitions=tuple(transitions))
        output.append(
            replace(
                annotated,
                protection_trace_events=tuple(
                    sorted(
                        (
                            *annotated.protection_trace_events,
                            *linked_events,
                        ),
                        key=lambda event: event["event_id"],
                    )
                ),
                schema_version=CONTEXT_HISTORY_SCHEMA_VERSION,
                identity_version=CONTEXT_HISTORY_IDENTITY_VERSION,
            )
        )
    return tuple(output)


def _event_overlay_rejection(
    event: Mapping[str, Any],
    *,
    dataset_id: str,
    error: ProtectionEventAssociationError,
) -> dict[str, Any]:
    return {
        "schema_version": PROTECTION_OVERLAY_REJECTION_SCHEMA_VERSION,
        "dataset_id": dataset_id,
        "route_id": event["route_id"],
        "event_id": event["event_id"],
        "reason_code": error.reason_code,
        "error_type": type(error).__qualname__,
        "message": str(error),
        "details": dict(error.details),
        "event": dict(event),
    }


def _validate_single_event_overlay(
    history: RouteContextHistory,
    event: Mapping[str, Any],
) -> None:
    try:
        _overlay_protection_events((history,), (event,))
    except ProtectionEventAssociationError as exc:
        details = {
            **exc.details,
            "route_id": event["route_id"],
            "event_id": event["event_id"],
        }
        raise type(exc)(exc.reason_code, str(exc), **details) from exc
    except ProtectionTraceEventValidationError as exc:
        raise ProtectionEventCompatibilityError(
            exc.reason_code,
            str(exc),
            underlying_error_type=type(exc).__qualname__,
            route_id=event["route_id"],
            event_id=event["event_id"],
            **exc.details,
        ) from exc
    except ContextHistoryError as exc:
        reason_code = (
            "conflicting_protection_state"
            if "conflicting protection states" in str(exc)
            else "incompatible_context_history"
        )
        raise ProtectionEventCompatibilityError(
            reason_code,
            f"protection event {event['event_id']} is incompatible with its "
            f"route context history: {exc}",
            underlying_error_type=type(exc).__qualname__,
            route_id=event["route_id"],
            event_id=event["event_id"],
        ) from exc


def _overlay_protection_events_with_policy(
    histories: Iterable[RouteContextHistory],
    events: Iterable[Mapping[str, Any]],
    *,
    dataset_id: str,
    policy: str,
) -> ProtectionOverlayResult:
    histories = tuple(histories)
    normalized_events = _normalized_protection_events(events)
    history_by_route = {history.route_id: history for history in histories}
    if policy not in {"strict", "reject-unlinked"}:
        raise ValueError(f"unsupported protection overlay policy: {policy}")

    accepted: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []
    for event in normalized_events:
        history = history_by_route.get(event["route_id"])
        try:
            if history is None:
                raise ProtectionEventAssociationError(
                    "missing_route_history",
                    f"protection event {event['event_id']} references route "
                    f"{event['route_id']} absent from context histories",
                    route_id=event["route_id"],
                    event_id=event["event_id"],
                )
            _validate_single_event_overlay(history, event)
        except ProtectionEventAssociationError as exc:
            if policy == "strict":
                raise
            rejected.append(
                _event_overlay_rejection(
                    event,
                    dataset_id=dataset_id,
                    error=exc,
                )
            )
        else:
            accepted.append(event)

    updated = _overlay_protection_events(histories, accepted)
    return ProtectionOverlayResult(
        histories=updated,
        accepted_events=tuple(accepted),
        rejections=tuple(
            sorted(
                rejected,
                key=lambda item: (item["route_id"], item["event_id"]),
            )
        ),
    )


def _write_protection_overlay_rejections(
    path: Path,
    rejections: Iterable[Mapping[str, Any]],
) -> Path:
    payload = "".join(
        json.dumps(
            rejection,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
        )
        + "\n"
        for rejection in rejections
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload, encoding="utf-8", newline="\n")
    return path


def _protection_overlay_error_rows(
    rejections: Iterable[Mapping[str, Any]],
) -> tuple[dict[str, Any], ...]:
    return tuple(
        {
            "dataset_id": rejection["dataset_id"],
            "route_id": rejection["route_id"],
            "event_id": rejection["event_id"],
            "stage": "protection_context_annotation",
            "reason_code": rejection["reason_code"],
            "error_type": rejection["error_type"],
            "message": rejection["message"],
            "details_json": json.dumps(
                rejection["details"],
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=True,
            ),
            "event_json": json.dumps(
                rejection["event"],
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=True,
            ),
        }
        for rejection in rejections
    )


def _history_coverage_errors(
    collection: Any,
    histories: Iterable[RouteContextHistory],
    *,
    dataset_id: str,
) -> tuple[dict[str, Any], ...]:
    """Describe incomplete/duplicate route histories without indexing by accident."""

    expected = [
        str(route_id) for route_id, _route in route_access.route_items(collection)
    ]
    actual = [history.route_id for history in histories]
    counts = defaultdict(int)
    for route_id in actual:
        counts[route_id] += 1
    records: list[dict[str, Any]] = []
    for route_id in sorted(set(expected) - set(actual)):
        records.append(
            {
                "dataset_id": dataset_id,
                "route_id": route_id,
                "stage": "context_history_coverage",
                "error_type": "MissingRouteContextHistory",
                "message": "no context history was produced for this route",
            }
        )
    for route_id in sorted(set(actual) - set(expected)):
        records.append(
            {
                "dataset_id": dataset_id,
                "route_id": route_id,
                "stage": "context_history_coverage",
                "error_type": "UnexpectedRouteContextHistory",
                "message": "context history does not belong to the input collection",
            }
        )
    for route_id in sorted(route_id for route_id, count in counts.items() if count > 1):
        records.append(
            {
                "dataset_id": dataset_id,
                "route_id": route_id,
                "stage": "context_history_coverage",
                "error_type": "DuplicateRouteContextHistory",
                "message": f"context history occurs {counts[route_id]} times",
            }
        )
    return tuple(records)


def _write_context_failure_sidecars(
    *,
    output_dir: Path,
    status: str,
    dataset_id: str,
    source_identity: str,
    histories: Iterable[RouteContextHistory],
    errors: Iterable[Mapping[str, Any]],
    input_paths: Iterable[Path],
    output_files: Mapping[str, Path],
    mapping_summary: Mapping[str, Any],
    input_hashes: Mapping[str, str],
    config_hash: str,
    vocabulary: Any | None,
    args: Any,
    protection_events_seen: int = 0,
    protection_events_embedded: int = 0,
    protection_events_rejected: int = 0,
    rejection_counts: Mapping[str, int] | None = None,
) -> None:
    histories = tuple(histories)
    errors = tuple(dict(error) for error in errors)
    summary = {
        "command_name": "annotate-context-history",
        "status": status,
        "dataset_id": dataset_id,
        "source_identity": source_identity,
        "reference_scope": REFERENCE_SCOPE,
        **context_history_summary(histories),
        "mapping_validation": dict(mapping_summary),
        "errors": len(errors),
        "config_hash": config_hash,
        "context_history_schema_version": CONTEXT_HISTORY_SCHEMA_VERSION,
        "context_history_identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
        "protection_trace_event_schema_version": (
            PROTECTION_TRACE_EVENT_SCHEMA_VERSION
        ),
        "protection_trace_events": protection_events_embedded,
        "protection_trace_events_seen": protection_events_seen,
        "protection_trace_events_embedded": protection_events_embedded,
        "protection_trace_events_rejected": protection_events_rejected,
        "protection_overlay_policy": str(
            getattr(args, "protection_overlay_policy", "strict")
        ),
        "protection_overlay_rejection_schema_version": (
            PROTECTION_OVERLAY_REJECTION_SCHEMA_VERSION
        ),
        "protection_overlay_rejections_by_reason": dict(
            sorted((rejection_counts or {}).items())
        ),
        "input_sha256": dict(input_hashes),
        "output_files": {
            key: relative_path(path) for key, path in sorted(output_files.items())
        },
    }
    vocabulary_manifest: dict[str, Any] = {}
    if vocabulary is not None:
        vocabulary_manifest = {
            "vocabulary_version": vocabulary.version_id,
            "vocabulary_source_sha256": vocabulary.source_sha256,
            "vocabulary_manifest_sha256": vocabulary.manifest_sha256,
        }
        summary.update(vocabulary_manifest)
    sidecars = write_standard_sidecars(
        output_dir,
        command_name="annotate-context-history",
        summary=summary,
        errors=errors,
        input_files=input_paths,
        output_files=output_files,
        cli_args=args,
        extra_manifest={
            "reference_scope": REFERENCE_SCOPE,
            "config_hash": config_hash,
            "mapping_validation": dict(mapping_summary),
            "context_history_schema_version": CONTEXT_HISTORY_SCHEMA_VERSION,
            "context_history_identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
            "protection_trace_event_schema_version": (
                PROTECTION_TRACE_EVENT_SCHEMA_VERSION
            ),
            "protection_trace_events_seen": protection_events_seen,
            "protection_trace_events_embedded": protection_events_embedded,
            "protection_trace_events_rejected": protection_events_rejected,
            "protection_overlay_policy": str(
                getattr(args, "protection_overlay_policy", "strict")
            ),
            "protection_overlay_rejection_schema_version": (
                PROTECTION_OVERLAY_REJECTION_SCHEMA_VERSION
            ),
            "protection_overlay_rejections_by_reason": dict(
                sorted((rejection_counts or {}).items())
            ),
            "input_sha256": dict(input_hashes),
            **vocabulary_manifest,
        },
    )
    summary["sidecar_files"] = sidecars
    write_json(output_dir / "summary.json", summary)
