"""Route-wide functional-group observations, edge transitions, and lineages.

Functional groups are detected once on each mapped molecule node and linked over
reaction edges with persistent atom-map identities. RRSeq consumers project an
interval from this history instead of repeating independent per-step detection.
"""

from __future__ import annotations

import copy
import gzip
import hashlib
import json
import os
import re
import tempfile
from collections import Counter, defaultdict, deque
from collections.abc import Callable, Iterable, Mapping
from dataclasses import asdict, dataclass, replace
from enum import Enum, StrEnum
from pathlib import Path
from typing import Any

import route_inspector.routes.access as route_access
from route_inspector import chemistry
from route_inspector.context.vocabulary import (
    FunctionalGroupVocabulary,
    PatternStratum,
    load_functional_group_vocabulary,
)

CONTEXT_HISTORY_SCHEMA_VERSION = 3
CONTEXT_HISTORY_IDENTITY_VERSION = 3
_SUPPORTED_CONTEXT_HISTORY_SCHEMA_VERSIONS = frozenset((1, 2, 3))
_SUPPORTED_CONTEXT_HISTORY_IDENTITY_VERSIONS = frozenset((1, 2, 3))
_EXPLICIT_MAP_RE = re.compile(r":([1-9][0-9]*)\]")
_SHA256_RE = re.compile(r"[0-9a-f]{64}")

# This is an implementation-owned policy description, not a borrowed chemistry
# vocabulary. Its digest binds histories to the interpretation used for
# distance, aromatic promotion, lineage chronology, and protection overlay.
DEFAULT_CONTEXT_POLICY: Mapping[str, Any] = {
    "context_history_algorithm_version": 3,
    "center": "anchor_intersects_reaction_center",
    "near_max_graph_distance": 2,
    "remote_min_graph_distance": 3,
    "disconnected_location": "remote",
    "aromatic_center_component_promotion": True,
    "lineage_timeline_order": "precursor_to_product",
    "joint_context_token_version": 1,
    "detect_protection": True,
    "mapped_protection_tracer": True,
    "protection_trace_event_schema_version": 1,
    "embedded_protection_trace_events": True,
}


class ContextHistoryError(ValueError):
    """Raised when annotation would lose route or mapping provenance."""

    def __init__(
        self,
        message: str,
        *,
        errors: Iterable[Mapping[str, Any]] = (),
    ) -> None:
        super().__init__(message)
        self.errors = tuple(dict(error) for error in errors)


class ProtectionTraceEventValidationError(ContextHistoryError):
    """Raised when embedded tracer provenance contradicts its route history."""

    def __init__(
        self,
        reason_code: str,
        message: str | None = None,
        **details: Any,
    ) -> None:
        if message is None:
            message = reason_code
            reason_code = "invalid_embedded_trace_event"
        super().__init__(message)
        self.reason_code = reason_code
        self.details = dict(details)


class TransitionStatus(StrEnum):
    PERSISTENT = "persistent"
    CHANGED = "changed"
    INTRODUCED = "introduced"
    REMOVED = "removed"


class LocationClass(StrEnum):
    CENTER = "center"
    NEAR = "near"
    REMOTE = "remote"


class ProtectionState(StrEnum):
    PROTECTED = "protected"
    UNPROTECTED = "unprotected"
    UNKNOWN = "unknown"


def _path(value: Iterable[int]) -> tuple[int, ...]:
    return tuple(int(index) for index in value)


def _mapping(value: Iterable[Iterable[int]]) -> tuple[tuple[int, int], ...]:
    return tuple(
        sorted((int(query_atom), int(route_atom)) for query_atom, route_atom in value)
    )


def _stable_id(prefix: str, payload: Mapping[str, Any]) -> str:
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")
    return f"{prefix}_{hashlib.sha256(encoded).hexdigest()[:24]}"


def canonical_protection_trace_events_sha256(
    events: Iterable[Mapping[str, Any]],
) -> str:
    """Return the content binding for one route's normalized tracer events."""

    normalized = sorted(
        (_jsonable(dict(event)) for event in events),
        key=lambda event: (
            str(event.get("event_id") or ""),
            json.dumps(event, sort_keys=True, separators=(",", ":")),
        ),
    )
    encoded = json.dumps(
        normalized,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def canonical_route_content_sha256(route: Mapping[str, Any]) -> str:
    """Return a deterministic digest of the complete canonical route payload."""

    encoded = json.dumps(
        _jsonable(route),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def canonical_context_policy_sha256(policy: Mapping[str, Any]) -> str:
    """Return the canonical digest used to bind histories to context policy."""

    encoded = json.dumps(
        _jsonable(policy),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _valid_sha256(value: str) -> bool:
    return _SHA256_RE.fullmatch(value) is not None


def validate_context_history_integrity_metadata(
    history: RouteContextHistory | Mapping[str, Any],
    *,
    expected_context_policy_sha256: str | None = None,
) -> None:
    """Fail closed unless a history carries current integrity metadata."""

    def field(name: str, default: Any = None) -> Any:
        if isinstance(history, Mapping):
            return history.get(name, default)
        return getattr(history, name, default)

    schema_version = int(field("schema_version", 1))
    identity_version = int(field("identity_version", 1))
    route_hash = str(field("route_content_sha256", "") or "")
    policy_hash = str(field("context_policy_sha256", "") or "")
    if schema_version < 2 or identity_version < 2:
        raise ContextHistoryError(
            "context history lacks current route/policy integrity metadata"
        )
    if (schema_version >= 3) != (identity_version >= 3):
        raise ContextHistoryError(
            "context-history schema v3 and identity v3 must be used together"
        )
    if not _valid_sha256(route_hash):
        raise ContextHistoryError(
            "context history has a missing or invalid route-content SHA-256"
        )
    if not _valid_sha256(policy_hash):
        raise ContextHistoryError(
            "context history has a missing or invalid context-policy SHA-256"
        )
    if (
        expected_context_policy_sha256 is not None
        and policy_hash != expected_context_policy_sha256
    ):
        raise ContextHistoryError(
            "context history policy hash differs from the current context policy"
        )
    if schema_version >= 3:
        events = field("protection_trace_events", ()) or ()
        if not all(isinstance(event, Mapping) for event in events):
            raise ContextHistoryError(
                "context history has malformed protection trace-event payloads"
            )
        actual_events_hash = canonical_protection_trace_events_sha256(events)
        declared_events_hash = str(field("protection_trace_events_sha256", "") or "")
        if declared_events_hash != actual_events_hash:
            raise ContextHistoryError(
                "context history protection trace-event digest mismatch"
            )


def validate_route_context_history_integrity(
    history: RouteContextHistory,
    route: Mapping[str, Any],
    *,
    expected_context_policy_sha256: str,
) -> None:
    """Validate one persisted history against one exact current route."""

    validate_context_history_integrity_metadata(
        history,
        expected_context_policy_sha256=expected_context_policy_sha256,
    )
    current_hash = canonical_route_content_sha256(route)
    if history.route_content_sha256 != current_hash:
        raise ContextHistoryError(
            "context history route-content hash differs from the current exact route"
        )


def _jsonable(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    return value


@dataclass(frozen=True)
class ProtectionAnnotation:
    """Orthogonal protection overlay supplied by the mapped PG tracer."""

    state: ProtectionState = ProtectionState.UNKNOWN
    group_type: str | None = None
    event_id: str | None = None
    rule_ids: tuple[str, ...] = ()
    protected_atom_maps: tuple[int, ...] = ()
    raw_query_mappings: tuple[tuple[tuple[int, int], ...], ...] = ()

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ProtectionAnnotation":
        return cls(
            state=ProtectionState(value.get("state", ProtectionState.UNKNOWN)),
            group_type=(
                None if value.get("group_type") is None else str(value["group_type"])
            ),
            event_id=None if value.get("event_id") is None else str(value["event_id"]),
            rule_ids=tuple(str(item) for item in value.get("rule_ids", ())),
            protected_atom_maps=tuple(
                int(atom) for atom in value.get("protected_atom_maps", ())
            ),
            raw_query_mappings=tuple(
                _mapping(mapping) for mapping in value.get("raw_query_mappings", ())
            ),
        )


def _merge_protection_annotations(
    *annotations: ProtectionAnnotation | None,
) -> ProtectionAnnotation | None:
    retained = tuple(annotation for annotation in annotations if annotation is not None)
    if not retained:
        return None
    concrete_states = {
        annotation.state
        for annotation in retained
        if annotation.state is not ProtectionState.UNKNOWN
    }
    if len(concrete_states) > 1:
        raise ContextHistoryError(
            "conflicting protection states describe one route-side lineage"
        )
    state = next(iter(concrete_states)) if concrete_states else ProtectionState.UNKNOWN

    def joined_values(values: Iterable[str | None]) -> str | None:
        items = {
            item for value in values if value for item in str(value).split("|") if item
        }
        return "|".join(sorted(items)) or None

    return ProtectionAnnotation(
        state=state,
        group_type=joined_values(annotation.group_type for annotation in retained),
        event_id=joined_values(annotation.event_id for annotation in retained),
        rule_ids=tuple(
            sorted(
                {rule_id for annotation in retained for rule_id in annotation.rule_ids}
            )
        ),
        protected_atom_maps=tuple(
            sorted(
                {
                    atom
                    for annotation in retained
                    for atom in annotation.protected_atom_maps
                }
            )
        ),
        raw_query_mappings=tuple(
            sorted(
                {
                    mapping
                    for annotation in retained
                    for mapping in annotation.raw_query_mappings
                }
            )
        ),
    )


@dataclass(frozen=True)
class ProtectionSiteObservation:
    """One mapped protected-site match, independent of FG detection."""

    site_id: str
    node_path: tuple[int, ...]
    group_type: str
    rule_ids: tuple[str, ...]
    protected_atom_maps: tuple[int, ...]
    raw_query_mappings: tuple[tuple[tuple[int, int], ...], ...]
    linked_lineage_id: str | None = None
    ambiguous_lineage_ids: tuple[str, ...] = ()

    def as_annotation(self) -> ProtectionAnnotation:
        return ProtectionAnnotation(
            state=ProtectionState.PROTECTED,
            group_type=self.group_type,
            event_id=self.site_id,
            rule_ids=self.rule_ids,
            protected_atom_maps=self.protected_atom_maps,
            raw_query_mappings=self.raw_query_mappings,
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ProtectionSiteObservation":
        return cls(
            site_id=str(value["site_id"]),
            node_path=_path(value["node_path"]),
            group_type=str(value["group_type"]),
            rule_ids=tuple(str(item) for item in value.get("rule_ids", ())),
            protected_atom_maps=tuple(
                int(atom) for atom in value.get("protected_atom_maps", ())
            ),
            raw_query_mappings=tuple(
                _mapping(mapping) for mapping in value.get("raw_query_mappings", ())
            ),
            linked_lineage_id=(
                None
                if value.get("linked_lineage_id") is None
                else str(value["linked_lineage_id"])
            ),
            ambiguous_lineage_ids=tuple(
                str(item) for item in value.get("ambiguous_lineage_ids", ())
            ),
        )


@dataclass(frozen=True)
class RawFunctionalGroupMatch:
    """One exact upstream query occurrence, preserving every raw mapping."""

    match_id: str
    pattern_name: str
    family_id: str
    stratum: PatternStratum
    context_eligible: bool
    atom_maps: tuple[int, ...]
    anchor_atom_maps: tuple[int, ...]
    raw_query_mappings: tuple[tuple[tuple[int, int], ...], ...]
    suppressed_by: tuple[str, ...] = ()
    normalized_observation_id: str | None = None
    curation_status: str = "curated"

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RawFunctionalGroupMatch":
        return cls(
            match_id=str(value["match_id"]),
            pattern_name=str(value["pattern_name"]),
            family_id=str(value["family_id"]),
            stratum=PatternStratum(value["stratum"]),
            context_eligible=bool(value["context_eligible"]),
            atom_maps=tuple(int(atom) for atom in value.get("atom_maps", ())),
            anchor_atom_maps=tuple(
                int(atom) for atom in value.get("anchor_atom_maps", ())
            ),
            raw_query_mappings=tuple(
                _mapping(mapping) for mapping in value.get("raw_query_mappings", ())
            ),
            suppressed_by=tuple(str(item) for item in value.get("suppressed_by", ())),
            normalized_observation_id=(
                None
                if value.get("normalized_observation_id") is None
                else str(value["normalized_observation_id"])
            ),
            curation_status=str(value.get("curation_status", "curated")),
        )


@dataclass(frozen=True)
class FunctionalGroupObservation:
    """One normalized primary FG or reactive-handle occurrence."""

    observation_id: str
    node_path: tuple[int, ...]
    family_id: str
    stratum: PatternStratum
    pattern_names: tuple[str, ...]
    atom_maps: tuple[int, ...]
    anchor_atom_maps: tuple[int, ...]
    raw_match_ids: tuple[str, ...]
    structure_signature: str
    protection: ProtectionAnnotation = ProtectionAnnotation()

    @property
    def context_token(self) -> str:
        return f"{self.family_id}:" + ",".join(
            str(atom) for atom in self.anchor_atom_maps
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "FunctionalGroupObservation":
        return cls(
            observation_id=str(value["observation_id"]),
            node_path=_path(value["node_path"]),
            family_id=str(value["family_id"]),
            stratum=PatternStratum(value["stratum"]),
            pattern_names=tuple(str(item) for item in value["pattern_names"]),
            atom_maps=tuple(int(atom) for atom in value["atom_maps"]),
            anchor_atom_maps=tuple(int(atom) for atom in value["anchor_atom_maps"]),
            raw_match_ids=tuple(str(item) for item in value["raw_match_ids"]),
            structure_signature=str(value["structure_signature"]),
            protection=ProtectionAnnotation.from_dict(value.get("protection", {})),
        )


@dataclass(frozen=True)
class MoleculeContextRecord:
    """Raw and normalized matches detected once on one mapped molecule node."""

    node_path: tuple[int, ...]
    mapped_smiles: str
    raw_matches: tuple[RawFunctionalGroupMatch, ...]
    observations: tuple[FunctionalGroupObservation, ...]
    protection_sites: tuple[ProtectionSiteObservation, ...] = ()

    @property
    def context_tokens(self) -> tuple[str, ...]:
        return tuple(sorted(item.context_token for item in self.observations))

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "MoleculeContextRecord":
        return cls(
            node_path=_path(value["node_path"]),
            mapped_smiles=str(value["mapped_smiles"]),
            raw_matches=tuple(
                RawFunctionalGroupMatch.from_dict(item)
                for item in value.get("raw_matches", ())
            ),
            observations=tuple(
                FunctionalGroupObservation.from_dict(item)
                for item in value.get("observations", ())
            ),
            protection_sites=tuple(
                ProtectionSiteObservation.from_dict(item)
                for item in value.get("protection_sites", ())
            ),
        )


@dataclass(frozen=True)
class ContextLocation:
    """FG location relative to one reaction center and molecule state."""

    location_class: LocationClass
    distance: int | None
    aromatic_promoted: bool = False
    aromatic_component_atom_maps: tuple[int, ...] = ()
    aromatic_promotion_reason: str | None = None

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ContextLocation":
        distance = value.get("distance")
        return cls(
            location_class=LocationClass(value["location_class"]),
            distance=None if distance is None else int(distance),
            aromatic_promoted=bool(value.get("aromatic_promoted", False)),
            aromatic_component_atom_maps=tuple(
                int(atom) for atom in value.get("aromatic_component_atom_maps", ())
            ),
            aromatic_promotion_reason=(
                None
                if value.get("aromatic_promotion_reason") is None
                else str(value["aromatic_promotion_reason"])
            ),
        )


@dataclass(frozen=True)
class FunctionalGroupTransition:
    """One normalized FG transition across a forward synthetic edge."""

    transition_id: str
    reaction_node_path: tuple[int, ...]
    center_atom_maps: tuple[int, ...]
    status: TransitionStatus
    before_observation_id: str | None
    after_observation_id: str | None
    before_family_id: str | None
    after_family_id: str | None
    before_location: ContextLocation | None
    after_location: ContextLocation | None
    before_protection: ProtectionAnnotation | None
    after_protection: ProtectionAnnotation | None
    lineage_id: str = ""

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "FunctionalGroupTransition":
        return cls(
            transition_id=str(value["transition_id"]),
            reaction_node_path=_path(value["reaction_node_path"]),
            center_atom_maps=tuple(
                int(atom) for atom in value.get("center_atom_maps", ())
            ),
            status=TransitionStatus(value["status"]),
            before_observation_id=(
                None
                if value.get("before_observation_id") is None
                else str(value["before_observation_id"])
            ),
            after_observation_id=(
                None
                if value.get("after_observation_id") is None
                else str(value["after_observation_id"])
            ),
            before_family_id=(
                None
                if value.get("before_family_id") is None
                else str(value["before_family_id"])
            ),
            after_family_id=(
                None
                if value.get("after_family_id") is None
                else str(value["after_family_id"])
            ),
            before_location=(
                None
                if value.get("before_location") is None
                else ContextLocation.from_dict(value["before_location"])
            ),
            after_location=(
                None
                if value.get("after_location") is None
                else ContextLocation.from_dict(value["after_location"])
            ),
            before_protection=(
                None
                if value.get("before_protection") is None
                else ProtectionAnnotation.from_dict(value["before_protection"])
            ),
            after_protection=(
                None
                if value.get("after_protection") is None
                else ProtectionAnnotation.from_dict(value["after_protection"])
            ),
            lineage_id=str(value.get("lineage_id", "")),
        )


@dataclass(frozen=True)
class FunctionalGroupLineage:
    """Route-tree history preserving observation and transition topology."""

    lineage_id: str
    observation_ids: tuple[str, ...]
    transition_ids: tuple[str, ...]

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "FunctionalGroupLineage":
        return cls(
            lineage_id=str(value["lineage_id"]),
            observation_ids=tuple(str(item) for item in value["observation_ids"]),
            transition_ids=tuple(str(item) for item in value["transition_ids"]),
        )


def _is_direct_route_child(
    parent_path: tuple[int, ...],
    child_path: tuple[int, ...],
) -> bool:
    return len(child_path) == len(parent_path) + 1 and child_path[:-1] == parent_path


def _validate_native_protection_trace_event(
    event: Mapping[str, Any],
) -> None:
    """Require one completed native stock or introduced tracer event."""

    from route_inspector.protection.analysis import (
        PROTECTION_TRACE_EVENT_SCHEMA_VERSION,
    )

    event_id = str(event.get("event_id") or "")
    try:
        schema_version = int(event.get("schema_version"))
    except (TypeError, ValueError) as exc:
        raise ProtectionTraceEventValidationError(
            "unsupported_trace_event_schema",
            f"protection trace event {event_id} requires schema version "
            f"{PROTECTION_TRACE_EVENT_SCHEMA_VERSION}",
        ) from exc
    if schema_version != PROTECTION_TRACE_EVENT_SCHEMA_VERSION:
        raise ProtectionTraceEventValidationError(
            "unsupported_trace_event_schema",
            f"protection trace event {event_id} uses unsupported schema version "
            f"{schema_version}",
            schema_version=schema_version,
        )

    trace_status = str(event.get("trace_status") or "")
    source_type = str(event.get("source_type") or "")
    if (trace_status, source_type) not in {
        ("stock", "stock"),
        ("introduced", "introduced"),
    } or str(event.get("failure_reason") or ""):
        raise ProtectionTraceEventValidationError(
            "unsupported_trace_state",
            f"protection trace event {event_id} is not one completed, "
            "unambiguous native stock or introduced trace",
            trace_status=trace_status,
            source_type=source_type,
            failure_reason=str(event.get("failure_reason") or ""),
        )

    protected_paths = tuple(
        _path(path) for path in event.get("protected_molecule_node_paths", ())
    )
    deprotection_path = _path(event.get("deprotection_reaction_node_path") or ())
    precursor_path = _path(event.get("protected_precursor_molecule_node_path") or ())
    protection_path = _path(event.get("protection_reaction_node_path") or ())
    stock_path = _path(event.get("stock_molecule_node_path") or ())
    last_successful_path = _path(event.get("trace_last_successful_node_path") or ())
    if (
        not protected_paths
        or not deprotection_path
        or not precursor_path
        or not last_successful_path
    ):
        raise ProtectionTraceEventValidationError(
            "missing_trace_endpoint",
            f"protection trace event {event_id} lacks required deprotection, "
            "protected-precursor, protected-trace, or last-successful provenance",
        )
    if (
        precursor_path != protected_paths[0]
        or last_successful_path != protected_paths[-1]
    ):
        raise ProtectionTraceEventValidationError(
            "invalid_trace_chronology",
            f"protection trace event {event_id} endpoint paths disagree with its "
            "protected molecule trace",
        )

    if trace_status == "stock":
        if not stock_path or protection_path or stock_path != protected_paths[-1]:
            raise ProtectionTraceEventValidationError(
                "invalid_trace_endpoint_type",
                f"stock protection trace event {event_id} requires its final "
                "protected molecule as the stock endpoint and no protection "
                "reaction endpoint",
            )
    elif not protection_path or stock_path:
        raise ProtectionTraceEventValidationError(
            "invalid_trace_endpoint_type",
            f"introduced protection trace event {event_id} requires a protection "
            "reaction endpoint and no stock endpoint",
        )


def _validate_protection_trace_event_paths(
    event: Mapping[str, Any],
    *,
    molecule_paths: set[tuple[int, ...]],
    reaction_paths: set[tuple[int, ...]],
    exact_chain: bool,
) -> None:
    """Validate one tracer event as one exact alternating route-tree chain."""

    event_id = str(event.get("event_id") or "")
    protected_paths = tuple(
        _path(path) for path in event.get("protected_molecule_node_paths", ())
    )
    interval_paths = tuple(
        _path(path) for path in event.get("interval_reaction_node_paths", ())
    )
    if not protected_paths:
        raise ProtectionTraceEventValidationError(
            "missing_protected_trace_paths",
            f"protection trace event {event_id} has no protected molecule paths",
        )
    if len(set(protected_paths)) != len(protected_paths):
        raise ProtectionTraceEventValidationError(
            "duplicate_protected_trace_path",
            f"protection trace event {event_id} repeats a protected molecule path",
        )
    if len(set(interval_paths)) != len(interval_paths):
        raise ProtectionTraceEventValidationError(
            "duplicate_interval_trace_path",
            f"protection trace event {event_id} repeats an interval reaction path",
        )
    if not set(protected_paths).issubset(molecule_paths):
        raise ProtectionTraceEventValidationError(
            "missing_protected_trace_path",
            f"protection trace event {event_id} references a protected molecule "
            "path absent from its route history",
            protected_molecule_node_paths=[list(path) for path in protected_paths],
        )
    if not set(interval_paths).issubset(reaction_paths):
        raise ProtectionTraceEventValidationError(
            "missing_interval_trace_path",
            f"protection trace event {event_id} references an interval reaction "
            "path absent from its route history",
            interval_reaction_node_paths=[list(path) for path in interval_paths],
        )

    deprotection_path = _path(event.get("deprotection_reaction_node_path") or ())
    precursor_path = _path(event.get("protected_precursor_molecule_node_path") or ())
    protection_path = _path(event.get("protection_reaction_node_path") or ())
    stock_path = _path(event.get("stock_molecule_node_path") or ())
    last_successful_path = _path(event.get("trace_last_successful_node_path") or ())

    for field, path, valid_paths in (
        ("deprotection_reaction_node_path", deprotection_path, reaction_paths),
        ("protection_reaction_node_path", protection_path, reaction_paths),
        ("protected_precursor_molecule_node_path", precursor_path, molecule_paths),
        ("stock_molecule_node_path", stock_path, molecule_paths),
    ):
        if path and path not in valid_paths:
            raise ProtectionTraceEventValidationError(
                "missing_trace_endpoint_path",
                f"protection trace event {event_id} {field} is absent from its "
                "route history",
                field=field,
                node_path=list(path),
            )

    if not exact_chain:
        if (
            last_successful_path
            and last_successful_path not in molecule_paths | reaction_paths
        ):
            raise ProtectionTraceEventValidationError(
                "protection trace event last-successful path is absent from route"
            )
        return

    first_protected_path = protected_paths[0]
    last_protected_path = protected_paths[-1]
    if deprotection_path and not _is_direct_route_child(
        deprotection_path, first_protected_path
    ):
        raise ProtectionTraceEventValidationError(
            "invalid_trace_chronology",
            f"protection trace event {event_id} protected precursor is not a "
            "direct child of its deprotection reaction",
        )
    if precursor_path and precursor_path != first_protected_path:
        raise ProtectionTraceEventValidationError(
            "invalid_trace_chronology",
            f"protection trace event {event_id} protected precursor differs from "
            "the first protected trace molecule",
        )
    expected_interval_count = len(protected_paths) - 1
    interval_reaction_ids = tuple(event.get("interval_reaction_ids", ()))
    if len(interval_paths) != expected_interval_count or len(
        interval_reaction_ids
    ) != len(interval_paths):
        raise ProtectionTraceEventValidationError(
            "invalid_trace_chronology",
            f"protection trace event {event_id} interval reactions do not exactly "
            "connect its protected molecule trace",
            expected_interval_reactions=expected_interval_count,
            observed_interval_reaction_paths=len(interval_paths),
            observed_interval_reaction_ids=len(interval_reaction_ids),
        )
    for before_path, reaction_path, after_path in zip(
        protected_paths[:-1], interval_paths, protected_paths[1:], strict=True
    ):
        if not _is_direct_route_child(
            before_path, reaction_path
        ) or not _is_direct_route_child(reaction_path, after_path):
            raise ProtectionTraceEventValidationError(
                "invalid_trace_chronology",
                f"protection trace event {event_id} interval does not follow one "
                "continuous molecule-reaction-molecule route-tree segment",
                before_molecule_node_path=list(before_path),
                interval_reaction_node_path=list(reaction_path),
                after_molecule_node_path=list(after_path),
            )
    if protection_path and not _is_direct_route_child(
        last_protected_path, protection_path
    ):
        raise ProtectionTraceEventValidationError(
            "invalid_trace_chronology",
            f"protection trace event {event_id} protection reaction is not a "
            "direct child of the final protected trace molecule",
        )
    if stock_path and stock_path != last_protected_path:
        raise ProtectionTraceEventValidationError(
            "invalid_trace_chronology",
            f"protection trace event {event_id} stock molecule differs from the "
            "final protected trace molecule",
        )
    if protection_path and stock_path:
        raise ProtectionTraceEventValidationError(
            "invalid_trace_chronology",
            f"protection trace event {event_id} cannot terminate at both a "
            "protection reaction and a stock molecule",
        )
    if last_successful_path and last_successful_path != last_protected_path:
        raise ProtectionTraceEventValidationError(
            "invalid_trace_chronology",
            f"protection trace event {event_id} last-successful path differs from "
            "the final protected trace molecule",
        )


@dataclass(frozen=True)
class RouteContextHistory:
    """Complete functional-group history for one mapped route."""

    dataset_id: str
    route_id: str
    source_identity: str
    vocabulary_version: str
    vocabulary_source_sha256: str
    vocabulary_manifest_sha256: str
    mapping_validated: bool
    molecule_records: tuple[MoleculeContextRecord, ...]
    reaction_node_paths: tuple[tuple[int, ...], ...]
    transitions: tuple[FunctionalGroupTransition, ...]
    lineages: tuple[FunctionalGroupLineage, ...]
    protection_trace_events: tuple[Mapping[str, Any], ...] = ()
    route_content_sha256: str = ""
    context_policy_sha256: str = ""
    errors: tuple[dict[str, Any], ...] = ()
    schema_version: int = CONTEXT_HISTORY_SCHEMA_VERSION
    identity_version: int = CONTEXT_HISTORY_IDENTITY_VERSION

    def __post_init__(self) -> None:
        if self.schema_version not in _SUPPORTED_CONTEXT_HISTORY_SCHEMA_VERSIONS:
            raise ValueError(
                f"unsupported context-history schema version: {self.schema_version}"
            )
        if self.identity_version not in _SUPPORTED_CONTEXT_HISTORY_IDENTITY_VERSIONS:
            raise ValueError(
                f"unsupported context-history identity version: {self.identity_version}"
            )
        if (self.schema_version >= 3) != (self.identity_version >= 3):
            raise ValueError(
                "context-history schema v3 and identity v3 must be used together"
            )
        if self.schema_version >= 2 or self.identity_version >= 2:
            if not _valid_sha256(self.route_content_sha256):
                raise ValueError(
                    "context history requires a canonical route-content SHA-256"
                )
            if not _valid_sha256(self.context_policy_sha256):
                raise ValueError(
                    "context history requires a canonical context-policy SHA-256"
                )
        observation_by_id = {
            observation.observation_id: observation
            for record in self.molecule_records
            for observation in record.observations
        }
        observation_ids = set(observation_by_id)
        transition_ids = {item.transition_id for item in self.transitions}
        lineage_by_id = {item.lineage_id: item for item in self.lineages}
        lineage_ids = set(lineage_by_id)
        reaction_paths = set(self.reaction_node_paths)
        if len(reaction_paths) != len(self.reaction_node_paths):
            raise ValueError("duplicate reaction node paths in context history")
        if len(transition_ids) != len(self.transitions):
            raise ValueError("duplicate context transition IDs")
        for transition in self.transitions:
            references = (
                transition.before_observation_id,
                transition.after_observation_id,
            )
            if any(
                reference is not None and reference not in observation_ids
                for reference in references
            ):
                raise ValueError("transition references an unknown observation")
            if transition.lineage_id not in lineage_ids:
                raise ValueError("transition references an unknown lineage")
            if transition.reaction_node_path not in reaction_paths:
                raise ValueError("transition references an unknown reaction path")
        for lineage in self.lineages:
            if not set(lineage.observation_ids).issubset(observation_ids):
                raise ValueError("lineage references an unknown observation")
            if not set(lineage.transition_ids).issubset(transition_ids):
                raise ValueError("lineage references an unknown transition")
        protection_sites = self.protection_sites
        protection_site_by_id = {site.site_id: site for site in protection_sites}
        if len(protection_site_by_id) != len(protection_sites):
            raise ValueError("duplicate protection site IDs in context history")
        for site in protection_site_by_id.values():
            if (
                site.linked_lineage_id is not None
                and site.linked_lineage_id not in lineage_ids
            ):
                raise ValueError("protection site references an unknown lineage")
            if not set(site.ambiguous_lineage_ids).issubset(lineage_ids):
                raise ValueError(
                    "protection site ambiguity references an unknown lineage"
                )
        event_ids: set[str] = set()
        molecule_record_by_path = {
            record.node_path: record for record in self.molecule_records
        }
        molecule_paths = set(molecule_record_by_path)
        for event in self.protection_trace_events:
            event_id = str(event.get("event_id") or "")
            if not event_id:
                raise ProtectionTraceEventValidationError(
                    "protection trace event requires event_id"
                )
            if event_id in event_ids:
                raise ProtectionTraceEventValidationError(
                    "duplicate protection trace event ID in route history"
                )
            event_ids.add(event_id)
            if str(event.get("route_id") or "") != self.route_id:
                raise ProtectionTraceEventValidationError(
                    "protection trace event route_id mismatch"
                )
            _validate_native_protection_trace_event(event)
            _validate_protection_trace_event_paths(
                event,
                molecule_paths=molecule_paths,
                reaction_paths=reaction_paths,
                exact_chain=self.schema_version >= 3,
            )
            lineage_id = str(event.get("linked_lineage_id") or "")
            if not lineage_id or lineage_id not in lineage_ids:
                raise ProtectionTraceEventValidationError(
                    "protection trace event requires one known linked FG lineage"
                )
            linked_observation_ids = {
                str(observation_id)
                for observation_id in event.get("linked_observation_ids", ())
            }
            if not linked_observation_ids:
                raise ProtectionTraceEventValidationError(
                    "protection trace event requires exact linked observations"
                )
            if not linked_observation_ids.issubset(observation_ids):
                raise ProtectionTraceEventValidationError(
                    "protection trace event references an unknown observation"
                )
            if not linked_observation_ids.issubset(
                set(lineage_by_id[lineage_id].observation_ids)
            ):
                raise ProtectionTraceEventValidationError(
                    "protection trace event observations differ from its FG lineage"
                )
            matched_site_ids = {
                str(site_id) for site_id in event.get("matched_protection_site_ids", ())
            }
            if not matched_site_ids.issubset(protection_site_by_id):
                raise ProtectionTraceEventValidationError(
                    "protection trace event references an unknown protection site"
                )
            protected_paths = {
                _path(path) for path in event.get("protected_molecule_node_paths", ())
            }
            protected_atom_maps = {
                int(atom) for atom in event.get("protected_atom_maps", ())
            }
            if self.schema_version >= 3:
                if not protected_atom_maps or any(
                    atom <= 0 for atom in protected_atom_maps
                ):
                    raise ProtectionTraceEventValidationError(
                        "protection trace event requires positive protected atom maps"
                    )
                for protected_path in protected_paths:
                    record = molecule_record_by_path[protected_path]
                    molecule = chemistry.parse_molecule(record.mapped_smiles)
                    missing_atom_maps = protected_atom_maps - {
                        int(atom) for atom in molecule
                    }
                    if missing_atom_maps:
                        raise ProtectionTraceEventValidationError(
                            "protected_atom_maps_absent_from_path",
                            "protection trace event references protected atom maps "
                            "absent from a protected molecule path",
                            node_path=list(protected_path),
                            missing_atom_maps=sorted(missing_atom_maps),
                        )
                    exact_sites = tuple(
                        site
                        for site in record.protection_sites
                        if set(site.protected_atom_maps) == protected_atom_maps
                    )
                    if exact_sites and not any(
                        str(event.get("pg_type") or "") in site.group_type.split("|")
                        for site in exact_sites
                    ):
                        raise ProtectionTraceEventValidationError(
                            "conflicting_protection_site_group",
                            "protection trace event group type differs from exact "
                            "protection-site evidence",
                            node_path=list(protected_path),
                        )
                    has_path_observation = any(
                        observation_by_id[observation_id].node_path == protected_path
                        and protected_atom_maps.issubset(
                            observation_by_id[observation_id].atom_maps
                        )
                        for observation_id in linked_observation_ids
                    )
                    has_path_site = False
                    for site_id in matched_site_ids:
                        site = protection_site_by_id[site_id]
                        site_lineages = set(site.ambiguous_lineage_ids)
                        if site.linked_lineage_id is not None:
                            site_lineages.add(site.linked_lineage_id)
                        if (
                            site.node_path == protected_path
                            and set(site.protected_atom_maps) == protected_atom_maps
                            and str(event.get("pg_type") or "")
                            in site.group_type.split("|")
                            and lineage_id in site_lineages
                        ):
                            has_path_site = True
                            break
                    if not has_path_observation and not has_path_site:
                        raise ProtectionTraceEventValidationError(
                            "missing_protected_path_evidence",
                            "protection trace event has no path-local linked "
                            "observation or matched exact protection site",
                            node_path=list(protected_path),
                            linked_lineage_id=lineage_id,
                        )
                if not any(
                    protected_atom_maps.issubset(
                        observation_by_id[observation_id].atom_maps
                    )
                    for observation_id in linked_observation_ids
                ):
                    raise ProtectionTraceEventValidationError(
                        "missing_observation_witness",
                        "protection trace event linked observations do not fully "
                        "contain its protected atom maps",
                    )
            for site_id in matched_site_ids:
                site = protection_site_by_id[site_id]
                site_lineages = set(site.ambiguous_lineage_ids)
                if site.linked_lineage_id is not None:
                    site_lineages.add(site.linked_lineage_id)
                if lineage_id not in site_lineages:
                    raise ProtectionTraceEventValidationError(
                        "protection trace event site evidence differs from its "
                        "FG lineage"
                    )
                if site.node_path not in protected_paths:
                    raise ProtectionTraceEventValidationError(
                        "protection trace event site is outside its protected path"
                    )
                if set(site.protected_atom_maps) != protected_atom_maps:
                    raise ProtectionTraceEventValidationError(
                        "protection trace event site has different protected atoms"
                    )
                if str(event.get("pg_type") or "") not in site.group_type.split("|"):
                    raise ProtectionTraceEventValidationError(
                        "protection trace event site has a different group type"
                    )

    @property
    def observations(self) -> tuple[FunctionalGroupObservation, ...]:
        return tuple(
            observation
            for record in self.molecule_records
            for observation in record.observations
        )

    @property
    def protection_sites(self) -> tuple[ProtectionSiteObservation, ...]:
        return tuple(
            site for record in self.molecule_records for site in record.protection_sites
        )

    def observation_by_id(self) -> dict[str, FunctionalGroupObservation]:
        return {item.observation_id: item for item in self.observations}

    @property
    def protection_trace_events_sha256(self) -> str:
        return canonical_protection_trace_events_sha256(self.protection_trace_events)

    @property
    def history_id(self) -> str:
        payload: dict[str, Any] = {
            "identity_version": self.identity_version,
            "dataset_id": self.dataset_id,
            "source_identity": self.source_identity,
            "route_id": self.route_id,
            "vocabulary_version": self.vocabulary_version,
            "vocabulary_manifest_sha256": self.vocabulary_manifest_sha256,
        }
        if self.identity_version >= 2:
            payload.update(
                {
                    "route_content_sha256": self.route_content_sha256,
                    "context_policy_sha256": self.context_policy_sha256,
                }
            )
        if self.identity_version >= 3:
            payload["protection_trace_events_sha256"] = (
                self.protection_trace_events_sha256
            )
        return _stable_id(
            "fgh",
            payload,
        )

    def transitions_for_reactions(
        self,
        reaction_node_paths: Iterable[Iterable[int]],
    ) -> tuple[FunctionalGroupTransition, ...]:
        selected = {_path(path) for path in reaction_node_paths}
        return tuple(
            transition
            for transition in self.transitions
            if transition.reaction_node_path in selected
        )

    def interval_lineages(
        self,
        reaction_node_paths: Iterable[Iterable[int]],
    ) -> tuple[dict[str, Any], ...]:
        """Project full lineage timelines over explicitly supplied route edges."""

        # RRSeq paths are retrosynthetic target-to-leaf, whereas transitions are
        # forward synthetic (before=precursor, after=product). Reverse once so
        # state consumers see a coherent precursor-to-product timeline.
        route_paths = tuple(_path(path) for path in reaction_node_paths)
        chronological_paths = tuple(reversed(route_paths))
        selected = set(route_paths)
        route_path_position = {path: index for index, path in enumerate(route_paths)}
        timeline_position = {
            path: index for index, path in enumerate(chronological_paths)
        }
        transitions = {
            transition.transition_id: transition for transition in self.transitions
        }
        records: list[dict[str, Any]] = []
        for lineage in self.lineages:
            timeline = tuple(
                sorted(
                    (
                        transitions[transition_id]
                        for transition_id in lineage.transition_ids
                        if transitions[transition_id].reaction_node_path in selected
                    ),
                    key=lambda item: (
                        timeline_position[item.reaction_node_path],
                        item.transition_id,
                    ),
                )
            )
            if not timeline:
                continue
            timeline_paths = [item.reaction_node_path for item in timeline]
            if len(set(timeline_paths)) != len(timeline_paths):
                raise ContextHistoryError(
                    f"lineage {lineage.lineage_id} has multiple transitions on "
                    "one selected reaction edge"
                )
            statuses = tuple(item.status for item in timeline)
            if tuple(timeline_paths) == chronological_paths and all(
                status is TransitionStatus.PERSISTENT for status in statuses
            ):
                interval_status = TransitionStatus.PERSISTENT
            elif TransitionStatus.CHANGED in statuses or (
                TransitionStatus.INTRODUCED in statuses
                and TransitionStatus.REMOVED in statuses
            ):
                interval_status = TransitionStatus.CHANGED
            elif TransitionStatus.INTRODUCED in statuses:
                interval_status = TransitionStatus.INTRODUCED
            elif TransitionStatus.REMOVED in statuses:
                interval_status = TransitionStatus.REMOVED
            else:
                interval_status = TransitionStatus.CHANGED
            records.append(
                {
                    "lineage_id": lineage.lineage_id,
                    "interval_status": interval_status.value,
                    "transition_ids": [item.transition_id for item in timeline],
                    "reaction_node_paths": [
                        list(item.reaction_node_path) for item in timeline
                    ],
                    "transition_timeline": [
                        {
                            "path_position": timeline_position[item.reaction_node_path],
                            "route_path_position": route_path_position[
                                item.reaction_node_path
                            ],
                            "reaction_node_path": list(item.reaction_node_path),
                            "transition_id": item.transition_id,
                            "status": item.status.value,
                            "before_family_id": item.before_family_id,
                            "after_family_id": item.after_family_id,
                            "before_location": (
                                None
                                if item.before_location is None
                                else item.before_location.location_class.value
                            ),
                            "after_location": (
                                None
                                if item.after_location is None
                                else item.after_location.location_class.value
                            ),
                            "before_location_detail": _joint_location_payload(
                                item.before_location
                            ),
                            "after_location_detail": _joint_location_payload(
                                item.after_location
                            ),
                            "protection_transition": _protection_transition(
                                item.before_protection,
                                item.after_protection,
                            ),
                            "before_protection_state": (
                                None
                                if item.before_protection is None
                                else item.before_protection.state.value
                            ),
                            "after_protection_state": (
                                None
                                if item.after_protection is None
                                else item.after_protection.state.value
                            ),
                        }
                        for item in timeline
                    ],
                }
            )
        return tuple(sorted(records, key=lambda item: item["lineage_id"]))

    def to_dict(self) -> dict[str, Any]:
        value = _jsonable(asdict(self))
        value["protection_trace_events_sha256"] = self.protection_trace_events_sha256
        value["context_history_id"] = self.history_id
        return value

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RouteContextHistory":
        history = cls(
            dataset_id=str(value.get("dataset_id", "")),
            route_id=str(value["route_id"]),
            source_identity=str(value.get("source_identity", "")),
            vocabulary_version=str(value["vocabulary_version"]),
            vocabulary_source_sha256=str(value["vocabulary_source_sha256"]),
            vocabulary_manifest_sha256=str(value["vocabulary_manifest_sha256"]),
            mapping_validated=bool(value["mapping_validated"]),
            molecule_records=tuple(
                MoleculeContextRecord.from_dict(item)
                for item in value.get("molecule_records", ())
            ),
            reaction_node_paths=tuple(
                _path(path) for path in value.get("reaction_node_paths", ())
            ),
            transitions=tuple(
                FunctionalGroupTransition.from_dict(item)
                for item in value.get("transitions", ())
            ),
            lineages=tuple(
                FunctionalGroupLineage.from_dict(item)
                for item in value.get("lineages", ())
            ),
            protection_trace_events=tuple(
                dict(item) for item in value.get("protection_trace_events", ())
            ),
            route_content_sha256=str(value.get("route_content_sha256") or ""),
            context_policy_sha256=str(value.get("context_policy_sha256") or ""),
            errors=tuple(dict(item) for item in value.get("errors", ())),
            schema_version=int(value.get("schema_version", 1)),
            identity_version=int(value.get("identity_version", 1)),
        )
        if history.schema_version >= 3:
            expected_digest = str(value.get("protection_trace_events_sha256") or "")
            if expected_digest != history.protection_trace_events_sha256:
                raise ValueError(
                    "context history protection trace-event digest mismatch"
                )
            expected_history_id = str(value.get("context_history_id") or "")
            if expected_history_id and expected_history_id != history.history_id:
                raise ValueError("context history identity digest mismatch")
        return history


@dataclass(frozen=True)
class ContextAnnotationResult:
    """Batch API consumed by CLI and reference-index stages."""

    histories: tuple[RouteContextHistory, ...]
    errors: tuple[dict[str, Any], ...]
    routes_seen: int

    @property
    def routes_annotated(self) -> int:
        return len(self.histories)


ProtectionAnnotator = Callable[
    [tuple[int, ...], FunctionalGroupObservation],
    ProtectionAnnotation | None,
]


def _atom_signature(atom: Any) -> tuple[Any, ...]:
    return (
        int(atom.atomic_number),
        atom.isotope,
        int(atom.charge),
        bool(atom.is_radical),
        atom.implicit_hydrogens,
        int(atom.hybridization),
    )


def _structure_signature(molecule: Any, atom_maps: Iterable[int]) -> str:
    atoms = frozenset(int(atom) for atom in atom_maps)
    payload: dict[str, Any] = {
        "atoms": [
            [atom, *_atom_signature(molecule.atom(atom))] for atom in sorted(atoms)
        ],
        "internal_bonds": [],
        "boundary_bonds": [],
    }
    for atom1, atom2, bond in molecule.bonds():
        atom1 = int(atom1)
        atom2 = int(atom2)
        if atom1 in atoms and atom2 in atoms:
            payload["internal_bonds"].append(
                [min(atom1, atom2), max(atom1, atom2), int(bond)]
            )
        elif (atom1 in atoms) != (atom2 in atoms):
            inside, outside = (atom1, atom2) if atom1 in atoms else (atom2, atom1)
            payload["boundary_bonds"].append(
                [
                    inside,
                    outside,
                    int(bond),
                    int(molecule.atom(outside).atomic_number),
                ]
            )
    payload["internal_bonds"].sort()
    payload["boundary_bonds"].sort()
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def _raw_matches(
    molecule: Any,
    *,
    node_path: tuple[int, ...],
    vocabulary: FunctionalGroupVocabulary,
) -> tuple[RawFunctionalGroupMatch, ...]:
    matches: list[RawFunctionalGroupMatch] = []
    for name in sorted(vocabulary.queries):
        pattern = vocabulary.patterns[name]
        query = vocabulary.queries[name]
        raw_mappings = {
            _mapping(mapping.items())
            for mapping in query.get_mapping(
                molecule,
                automorphism_filter=False,
            )
        }
        grouped: dict[
            tuple[tuple[int, ...], tuple[int, ...]],
            list[tuple[tuple[int, int], ...]],
        ] = defaultdict(list)
        for mapping in sorted(raw_mappings):
            mapped = dict(mapping)
            atom_maps = tuple(sorted(mapped.values()))
            anchors = tuple(
                sorted(mapped[query_atom] for query_atom in pattern.anchor_query_atoms)
            )
            grouped[(atom_maps, anchors)].append(mapping)
        for (atom_maps, anchors), mappings in sorted(grouped.items()):
            match_id = _stable_id(
                "fgm",
                {
                    "identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
                    "node_path": list(node_path),
                    "pattern": name,
                    "atom_maps": list(atom_maps),
                    "anchor_atom_maps": list(anchors),
                },
            )
            matches.append(
                RawFunctionalGroupMatch(
                    match_id=match_id,
                    pattern_name=name,
                    family_id=pattern.family_id,
                    stratum=pattern.stratum,
                    context_eligible=pattern.context_eligible,
                    atom_maps=atom_maps,
                    anchor_atom_maps=anchors,
                    raw_query_mappings=tuple(sorted(mappings)),
                    curation_status=pattern.curation_status,
                )
            )
    return tuple(sorted(matches, key=lambda item: item.match_id))


def _normalize_matches(
    molecule: Any,
    *,
    node_path: tuple[int, ...],
    raw_matches: tuple[RawFunctionalGroupMatch, ...],
    vocabulary: FunctionalGroupVocabulary,
) -> tuple[
    tuple[RawFunctionalGroupMatch, ...],
    tuple[FunctionalGroupObservation, ...],
]:
    suppressed: dict[str, set[str]] = defaultdict(set)
    by_pattern: dict[str, list[RawFunctionalGroupMatch]] = defaultdict(list)
    for match in raw_matches:
        by_pattern[match.pattern_name].append(match)
    for suppressor in raw_matches:
        for target_name in vocabulary.patterns[suppressor.pattern_name].suppresses:
            for target in by_pattern.get(target_name, ()):
                if set(target.atom_maps).issubset(suppressor.atom_maps):
                    suppressed[target.match_id].add(suppressor.match_id)
    updated_raw = tuple(
        replace(
            match,
            suppressed_by=tuple(sorted(suppressed.get(match.match_id, ()))),
        )
        for match in raw_matches
    )
    buckets: dict[
        tuple[str, tuple[int, ...]],
        list[RawFunctionalGroupMatch],
    ] = defaultdict(list)
    for match in updated_raw:
        if match.context_eligible and not match.suppressed_by:
            buckets[(match.family_id, match.anchor_atom_maps)].append(match)

    observations: list[FunctionalGroupObservation] = []
    raw_to_observation: dict[str, str] = {}
    for (family_id, anchors), bucket in sorted(buckets.items()):
        bucket.sort(
            key=lambda match: (
                -vocabulary.patterns[match.pattern_name].overlap_precedence,
                -len(match.atom_maps),
                match.pattern_name,
                match.match_id,
            )
        )
        representative = bucket[0]
        observation_id = _stable_id(
            "fgo",
            {
                "identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
                "node_path": list(node_path),
                "family_id": family_id,
                "anchor_atom_maps": list(anchors),
            },
        )
        observations.append(
            FunctionalGroupObservation(
                observation_id=observation_id,
                node_path=node_path,
                family_id=family_id,
                stratum=representative.stratum,
                pattern_names=tuple(sorted({match.pattern_name for match in bucket})),
                atom_maps=representative.atom_maps,
                anchor_atom_maps=anchors,
                raw_match_ids=tuple(sorted(match.match_id for match in bucket)),
                structure_signature=_structure_signature(
                    molecule,
                    representative.atom_maps,
                ),
            )
        )
        for match in bucket:
            raw_to_observation[match.match_id] = observation_id
    return (
        tuple(
            sorted(
                (
                    replace(
                        match,
                        normalized_observation_id=raw_to_observation.get(
                            match.match_id
                        ),
                    )
                    for match in updated_raw
                ),
                key=lambda item: item.match_id,
            )
        ),
        tuple(sorted(observations, key=lambda item: item.observation_id)),
    )


def detect_functional_groups(
    molecule: Any,
    *,
    node_path: Iterable[int] = (),
    vocabulary: FunctionalGroupVocabulary | None = None,
    protection_annotator: ProtectionAnnotator | None = None,
) -> tuple[
    tuple[RawFunctionalGroupMatch, ...],
    tuple[FunctionalGroupObservation, ...],
]:
    """Detect raw matches and normalize only curated statistical tokens."""

    node_path = _path(node_path)
    vocabulary = vocabulary or load_functional_group_vocabulary()
    raw = _raw_matches(molecule, node_path=node_path, vocabulary=vocabulary)
    raw, observations = _normalize_matches(
        molecule,
        node_path=node_path,
        raw_matches=raw,
        vocabulary=vocabulary,
    )
    if protection_annotator is not None:
        observations = tuple(
            replace(
                observation,
                protection=(
                    protection_annotator(node_path, observation)
                    or ProtectionAnnotation()
                ),
            )
            for observation in observations
        )
    return raw, observations


def detect_chython_protection_sites(
    molecule: Any,
    *,
    node_path: Iterable[int] = (),
    protection_rules: Mapping[str, Any] | None = None,
) -> tuple[ProtectionSiteObservation, ...]:
    """Detect every mapped protected site with the existing protection matcher."""

    from route_inspector.protection.analysis import matching_site_mappings
    from route_inspector.protection.chython_rules import (
        load_chython_protection_rules,
    )

    rules = (
        load_chython_protection_rules()
        if protection_rules is None
        else protection_rules
    )
    raw_sites: list[tuple[str, str, tuple[int, ...], tuple[tuple[int, int], ...]]] = []
    for rule_id, rule in sorted(rules.items()):
        for protected_atom_maps, raw_mapping in matching_site_mappings(
            molecule,
            rule,
        ):
            raw_sites.append(
                (
                    str(rule_id),
                    str(rule.name),
                    tuple(sorted(int(atom) for atom in protected_atom_maps)),
                    _mapping(raw_mapping.items()),
                )
            )
    node_path = _path(node_path)
    grouped: dict[
        tuple[int, ...],
        list[tuple[str, str, tuple[tuple[int, int], ...]]],
    ] = defaultdict(list)
    for rule_id, group_type, atom_maps, raw_mapping in sorted(set(raw_sites)):
        grouped[atom_maps].append((rule_id, group_type, raw_mapping))
    sites: list[ProtectionSiteObservation] = []
    for protected_atom_maps, matches in sorted(grouped.items()):
        rule_ids = tuple(sorted({item[0] for item in matches}))
        group_types = tuple(sorted({item[1] for item in matches}))
        raw_query_mappings = tuple(sorted({item[2] for item in matches}))
        site_id = _stable_id(
            "pgs",
            {
                "identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
                "node_path": list(node_path),
                "rule_ids": list(rule_ids),
                "protected_atom_maps": list(protected_atom_maps),
            },
        )
        sites.append(
            ProtectionSiteObservation(
                site_id=site_id,
                node_path=node_path,
                group_type="|".join(group_types),
                rule_ids=rule_ids,
                protected_atom_maps=protected_atom_maps,
                raw_query_mappings=raw_query_mappings,
            )
        )
    return tuple(sorted(sites, key=lambda item: item.site_id))


def _annotate_observations_from_protection_sites(
    observations: Iterable[FunctionalGroupObservation],
    sites: Iterable[ProtectionSiteObservation],
) -> tuple[FunctionalGroupObservation, ...]:
    sites = tuple(sites)
    annotated: list[FunctionalGroupObservation] = []
    for observation in observations:
        anchors = set(observation.anchor_atom_maps)
        atoms = set(observation.atom_maps)
        matches = [
            site
            for site in sites
            if set(site.protected_atom_maps) & anchors
            or set(site.protected_atom_maps).issubset(atoms)
        ]
        if not matches:
            annotated.append(
                replace(
                    observation,
                    protection=ProtectionAnnotation(state=ProtectionState.UNPROTECTED),
                )
            )
            continue
        rule_ids = tuple(
            sorted({rule_id for site in matches for rule_id in site.rule_ids})
        )
        group_types = tuple(sorted({site.group_type for site in matches}))
        protected_atom_maps = tuple(
            sorted({atom for site in matches for atom in site.protected_atom_maps})
        )
        raw_query_mappings = tuple(
            sorted({mapping for site in matches for mapping in site.raw_query_mappings})
        )
        annotated.append(
            replace(
                observation,
                protection=ProtectionAnnotation(
                    state=ProtectionState.PROTECTED,
                    group_type="|".join(group_types),
                    event_id="|".join(sorted(site.site_id for site in matches)),
                    rule_ids=rule_ids,
                    protected_atom_maps=protected_atom_maps,
                    raw_query_mappings=raw_query_mappings,
                ),
            )
        )
    return tuple(annotated)


def annotate_observations_with_chython_protection(
    molecule: Any,
    observations: Iterable[FunctionalGroupObservation],
    *,
    node_path: Iterable[int] = (),
    protection_rules: Mapping[str, Any] | None = None,
) -> tuple[FunctionalGroupObservation, ...]:
    """Overlay exact mapped PG sites using the existing protection matcher."""

    sites = detect_chython_protection_sites(
        molecule,
        node_path=node_path,
        protection_rules=protection_rules,
    )
    return _annotate_observations_from_protection_sites(observations, sites)


def _aromatic_components(molecule: Any) -> tuple[frozenset[int], ...]:
    adjacency: dict[int, set[int]] = defaultdict(set)
    for atom1, atom2, bond in molecule.bonds():
        if int(bond) == 4:
            atom1 = int(atom1)
            atom2 = int(atom2)
            adjacency[atom1].add(atom2)
            adjacency[atom2].add(atom1)
    components: list[frozenset[int]] = []
    unseen = set(adjacency)
    while unseen:
        queue = [min(unseen)]
        component: set[int] = set()
        while queue:
            atom = queue.pop()
            if atom in component:
                continue
            component.add(atom)
            queue.extend(sorted(adjacency[atom] - component, reverse=True))
        unseen -= component
        components.append(frozenset(component))
    return tuple(sorted(components, key=lambda item: tuple(sorted(item))))


def _minimum_distance(
    molecule: Any,
    starts: Iterable[int],
    targets: Iterable[int],
) -> int | None:
    molecule_atoms = {int(atom) for atom in molecule}
    starts = {int(atom) for atom in starts if int(atom) in molecule_atoms}
    targets = {int(atom) for atom in targets if int(atom) in molecule_atoms}
    if not starts or not targets:
        return None
    if starts & targets:
        return 0
    queue = deque((atom, 0) for atom in sorted(starts))
    seen = set(starts)
    while queue:
        atom, distance = queue.popleft()
        for neighbor in sorted(int(item) for item in molecule._bonds[atom]):
            if neighbor in seen:
                continue
            if neighbor in targets:
                return distance + 1
            seen.add(neighbor)
            queue.append((neighbor, distance + 1))
    return None


def classify_functional_group_location(
    molecule: Any,
    *,
    anchor_atom_maps: Iterable[int],
    group_atom_maps: Iterable[int],
    center_atom_maps: Iterable[int],
) -> ContextLocation:
    """Classify center, near (distance at most two), or remote context."""

    anchors = frozenset(int(atom) for atom in anchor_atom_maps)
    group_atoms = frozenset(int(atom) for atom in group_atom_maps)
    center = frozenset(int(atom) for atom in center_atom_maps)
    distance = _minimum_distance(molecule, anchors, center)
    if anchors & center:
        return ContextLocation(LocationClass.CENTER, distance)
    for component in _aromatic_components(molecule):
        if component & center and component & group_atoms:
            return ContextLocation(
                LocationClass.NEAR,
                distance,
                aromatic_promoted=True,
                aromatic_component_atom_maps=tuple(sorted(component)),
                aromatic_promotion_reason=(
                    "functional_group_intersects_center_aromatic_component"
                ),
            )
    if distance is not None and distance <= 2:
        return ContextLocation(LocationClass.NEAR, distance)
    return ContextLocation(LocationClass.REMOTE, distance)


def _linked_transition(
    *,
    reaction_path: tuple[int, ...],
    center: tuple[int, ...],
    before: FunctionalGroupObservation | None,
    after: FunctionalGroupObservation | None,
    molecule_by_path: Mapping[tuple[int, ...], Any],
    status: TransitionStatus,
) -> FunctionalGroupTransition:
    def location(item: FunctionalGroupObservation | None) -> ContextLocation | None:
        if item is None:
            return None
        return classify_functional_group_location(
            molecule_by_path[item.node_path],
            anchor_atom_maps=item.anchor_atom_maps,
            group_atom_maps=item.atom_maps,
            center_atom_maps=center,
        )

    transition_id = _stable_id(
        "fgt",
        {
            "identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
            "reaction_node_path": list(reaction_path),
            "before": None if before is None else before.observation_id,
            "after": None if after is None else after.observation_id,
        },
    )
    return FunctionalGroupTransition(
        transition_id=transition_id,
        reaction_node_path=reaction_path,
        center_atom_maps=center,
        status=status,
        before_observation_id=(None if before is None else before.observation_id),
        after_observation_id=None if after is None else after.observation_id,
        before_family_id=None if before is None else before.family_id,
        after_family_id=None if after is None else after.family_id,
        before_location=location(before),
        after_location=location(after),
        before_protection=None if before is None else before.protection,
        after_protection=None if after is None else after.protection,
    )


def _edge_transitions(
    *,
    reaction_path: tuple[int, ...],
    center: tuple[int, ...],
    before: tuple[FunctionalGroupObservation, ...],
    after: tuple[FunctionalGroupObservation, ...],
    molecule_by_path: Mapping[tuple[int, ...], Any],
) -> tuple[
    tuple[FunctionalGroupTransition, ...],
    tuple[dict[str, Any], ...],
]:
    before_by_id = {item.observation_id: item for item in before}
    after_by_id = {item.observation_id: item for item in after}
    remaining_before = set(before_by_id)
    remaining_after = set(after_by_id)
    excluded: set[str] = set()
    pairs: list[tuple[str, str, TransitionStatus]] = []
    errors: list[dict[str, Any]] = []

    exact_after: dict[
        tuple[str, tuple[int, ...], tuple[int, ...]],
        list[str],
    ] = defaultdict(list)
    for item in after:
        exact_after[(item.family_id, item.atom_maps, item.anchor_atom_maps)].append(
            item.observation_id
        )
    for before_id in sorted(tuple(remaining_before)):
        item = before_by_id[before_id]
        candidates = [
            after_id
            for after_id in exact_after.get(
                (item.family_id, item.atom_maps, item.anchor_atom_maps),
                (),
            )
            if after_id in remaining_after
        ]
        if len(candidates) == 1:
            after_id = candidates[0]
            after_item = after_by_id[after_id]
            status = (
                TransitionStatus.PERSISTENT
                if item.structure_signature == after_item.structure_signature
                else TransitionStatus.CHANGED
            )
            pairs.append((before_id, after_id, status))
            remaining_before.remove(before_id)
            remaining_after.remove(after_id)
        elif len(candidates) > 1:
            excluded.add(before_id)
            excluded.update(candidates)
            errors.append(
                {
                    "stage": "exact_lineage_pairing",
                    "reaction_node_path": list(reaction_path),
                    "error_type": "AmbiguousFunctionalGroupLineage",
                    "message": "multiple exact product observations match one precursor",
                    "observation_ids": [before_id, *sorted(candidates)],
                }
            )

    remaining_before -= excluded
    remaining_after -= excluded
    proposals: dict[str, tuple[str, tuple[int, int, int, int]]] = {}
    for before_id in sorted(remaining_before):
        before_item = before_by_id[before_id]
        candidates: list[tuple[tuple[int, int, int, int], str]] = []
        for after_id in sorted(remaining_after):
            after_item = after_by_id[after_id]
            anchor_overlap = len(
                set(before_item.anchor_atom_maps) & set(after_item.anchor_atom_maps)
            )
            if not anchor_overlap:
                continue
            atom_overlap = len(set(before_item.atom_maps) & set(after_item.atom_maps))
            candidates.append(
                (
                    (
                        int(before_item.family_id == after_item.family_id),
                        anchor_overlap,
                        atom_overlap,
                        -abs(len(before_item.atom_maps) - len(after_item.atom_maps)),
                    ),
                    after_id,
                )
            )
        if not candidates:
            continue
        candidates.sort(reverse=True)
        best_score = candidates[0][0]
        best = sorted(after_id for score, after_id in candidates if score == best_score)
        if len(best) != 1:
            excluded.add(before_id)
            excluded.update(best)
            errors.append(
                {
                    "stage": "anchor_lineage_pairing",
                    "reaction_node_path": list(reaction_path),
                    "error_type": "AmbiguousFunctionalGroupLineage",
                    "message": "anchor overlap has no unique best product observation",
                    "observation_ids": [before_id, *best],
                }
            )
        else:
            proposals[before_id] = (best[0], best_score)

    proposals_by_after: dict[
        str,
        list[tuple[str, tuple[int, int, int, int]]],
    ] = defaultdict(list)
    for before_id, (after_id, score) in proposals.items():
        if before_id not in excluded and after_id not in excluded:
            proposals_by_after[after_id].append((before_id, score))
    for after_id, candidates in sorted(proposals_by_after.items()):
        candidates.sort(key=lambda item: (item[1], item[0]), reverse=True)
        best_score = candidates[0][1]
        best = sorted(
            before_id for before_id, score in candidates if score == best_score
        )
        if len(best) != 1:
            excluded.add(after_id)
            excluded.update(best)
            errors.append(
                {
                    "stage": "anchor_lineage_pairing",
                    "reaction_node_path": list(reaction_path),
                    "error_type": "AmbiguousFunctionalGroupLineage",
                    "message": "multiple precursors have equal anchor-overlap support",
                    "observation_ids": [*best, after_id],
                }
            )
            continue
        before_id = best[0]
        if before_id in remaining_before and after_id in remaining_after:
            pairs.append((before_id, after_id, TransitionStatus.CHANGED))
            remaining_before.remove(before_id)
            remaining_after.remove(after_id)

    remaining_before -= excluded
    remaining_after -= excluded
    transitions = [
        _linked_transition(
            reaction_path=reaction_path,
            center=center,
            before=before_by_id[before_id],
            after=after_by_id[after_id],
            molecule_by_path=molecule_by_path,
            status=status,
        )
        for before_id, after_id, status in pairs
    ]
    transitions.extend(
        _linked_transition(
            reaction_path=reaction_path,
            center=center,
            before=before_by_id[before_id],
            after=None,
            molecule_by_path=molecule_by_path,
            status=TransitionStatus.REMOVED,
        )
        for before_id in sorted(remaining_before)
    )
    transitions.extend(
        _linked_transition(
            reaction_path=reaction_path,
            center=center,
            before=None,
            after=after_by_id[after_id],
            molecule_by_path=molecule_by_path,
            status=TransitionStatus.INTRODUCED,
        )
        for after_id in sorted(remaining_after)
    )
    return (
        tuple(sorted(transitions, key=lambda item: item.transition_id)),
        tuple(errors),
    )


class _UnionFind:
    def __init__(self, values: Iterable[str]) -> None:
        self.parent = {value: value for value in values}

    def find(self, value: str) -> str:
        if self.parent[value] != value:
            self.parent[value] = self.find(self.parent[value])
        return self.parent[value]

    def union(self, left: str, right: str) -> None:
        left_root = self.find(left)
        right_root = self.find(right)
        if left_root != right_root:
            smaller, larger = sorted((left_root, right_root))
            self.parent[larger] = smaller


def _assign_lineages(
    transitions: tuple[FunctionalGroupTransition, ...],
    observations: tuple[FunctionalGroupObservation, ...],
    *,
    source_identity: str,
    route_id: str,
) -> tuple[
    tuple[FunctionalGroupTransition, ...],
    tuple[FunctionalGroupLineage, ...],
]:
    union = _UnionFind(item.observation_id for item in observations)
    for transition in transitions:
        if (
            transition.before_observation_id is not None
            and transition.after_observation_id is not None
        ):
            union.union(
                transition.before_observation_id,
                transition.after_observation_id,
            )
    observations_by_root: dict[str, list[str]] = defaultdict(list)
    for observation in observations:
        observations_by_root[union.find(observation.observation_id)].append(
            observation.observation_id
        )
    lineage_by_observation: dict[str, str] = {}
    for members in observations_by_root.values():
        members.sort()
        lineage_id = _stable_id(
            "fgl",
            {
                "identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
                "source_identity": source_identity,
                "route_id": route_id,
                "observation_ids": members,
            },
        )
        for observation_id in members:
            lineage_by_observation[observation_id] = lineage_id
    updated: list[FunctionalGroupTransition] = []
    transitions_by_lineage: dict[str, list[str]] = defaultdict(list)
    for transition in transitions:
        observation_id = (
            transition.before_observation_id or transition.after_observation_id
        )
        if observation_id is None:
            raise ValueError("transition has neither before nor after observation")
        lineage_id = lineage_by_observation[observation_id]
        updated.append(replace(transition, lineage_id=lineage_id))
        transitions_by_lineage[lineage_id].append(transition.transition_id)
    lineages = [
        FunctionalGroupLineage(
            lineage_id=lineage_by_observation[members[0]],
            observation_ids=tuple(sorted(members)),
            transition_ids=tuple(
                sorted(transitions_by_lineage[lineage_by_observation[members[0]]])
            ),
        )
        for members in observations_by_root.values()
    ]
    return (
        tuple(sorted(updated, key=lambda item: item.transition_id)),
        tuple(sorted(lineages, key=lambda item: item.lineage_id)),
    )


def _annotation_from_sites(
    sites: Iterable[ProtectionSiteObservation],
) -> ProtectionAnnotation | None:
    sites = tuple(sites)
    if not sites:
        return None
    site_ids = tuple(sorted(site.site_id for site in sites))
    return ProtectionAnnotation(
        state=ProtectionState.PROTECTED,
        group_type="|".join(sorted({site.group_type for site in sites})),
        event_id="|".join(site_ids),
        rule_ids=tuple(
            sorted({rule_id for site in sites for rule_id in site.rule_ids})
        ),
        protected_atom_maps=tuple(
            sorted({atom for site in sites for atom in site.protected_atom_maps})
        ),
        raw_query_mappings=tuple(
            sorted({mapping for site in sites for mapping in site.raw_query_mappings})
        ),
    )


def _associate_protection_sites(
    records: tuple[MoleculeContextRecord, ...],
    transitions: tuple[FunctionalGroupTransition, ...],
    lineages: tuple[FunctionalGroupLineage, ...],
) -> tuple[
    tuple[MoleculeContextRecord, ...],
    tuple[FunctionalGroupTransition, ...],
    tuple[dict[str, Any], ...],
]:
    """Link independent PG sites to FG lineages by persistent mapped anchors."""

    observations = {
        observation.observation_id: observation
        for record in records
        for observation in record.observations
    }
    lineage_by_observation = {
        observation_id: lineage.lineage_id
        for lineage in lineages
        for observation_id in lineage.observation_ids
    }
    anchors_by_lineage: dict[str, set[int]] = defaultdict(set)
    atoms_by_lineage: dict[str, set[int]] = defaultdict(set)
    for observation_id, lineage_id in lineage_by_observation.items():
        observation = observations[observation_id]
        anchors_by_lineage[lineage_id].update(observation.anchor_atom_maps)
        atoms_by_lineage[lineage_id].update(observation.atom_maps)

    errors: list[dict[str, Any]] = []
    updated_records: list[MoleculeContextRecord] = []
    for record in records:
        direct_lineages = {
            observation.observation_id: lineage_by_observation[
                observation.observation_id
            ]
            for observation in record.observations
        }
        linked_sites: list[ProtectionSiteObservation] = []
        for site in record.protection_sites:
            site_atoms = set(site.protected_atom_maps)
            candidates = {
                lineage_id
                for observation_id, lineage_id in direct_lineages.items()
                if site_atoms & set(observations[observation_id].anchor_atom_maps)
                or site_atoms.issubset(observations[observation_id].atom_maps)
            }
            if not candidates:
                candidates = {
                    lineage_id
                    for lineage_id, anchors in anchors_by_lineage.items()
                    if site_atoms & anchors
                    or site_atoms.issubset(atoms_by_lineage[lineage_id])
                }
            if len(candidates) == 1:
                linked_sites.append(
                    replace(site, linked_lineage_id=next(iter(candidates)))
                )
            elif len(candidates) > 1:
                ambiguity = tuple(sorted(candidates))
                linked_sites.append(replace(site, ambiguous_lineage_ids=ambiguity))
                errors.append(
                    {
                        "stage": "protection_site_lineage_pairing",
                        "error_type": "AmbiguousProtectionSiteLineage",
                        "message": (
                            "mapped protection site overlaps multiple FG lineages"
                        ),
                        "site_id": site.site_id,
                        "node_path": list(site.node_path),
                        "lineage_ids": list(ambiguity),
                    }
                )
            else:
                linked_sites.append(site)
        updated_records.append(
            replace(
                record,
                protection_sites=tuple(
                    sorted(linked_sites, key=lambda item: item.site_id)
                ),
            )
        )

    sites_by_node_and_lineage: dict[
        tuple[tuple[int, ...], str],
        list[ProtectionSiteObservation],
    ] = defaultdict(list)
    for record in updated_records:
        for site in record.protection_sites:
            if site.linked_lineage_id is not None:
                sites_by_node_and_lineage[
                    (record.node_path, site.linked_lineage_id)
                ].append(site)

    updated_transitions: list[FunctionalGroupTransition] = []
    record_paths = {record.node_path for record in updated_records}
    for transition in transitions:
        after_path = transition.reaction_node_path[:-1]
        before_paths = tuple(
            path
            for path in record_paths
            if len(path) == len(transition.reaction_node_path) + 1
            and path[:-1] == transition.reaction_node_path
        )
        before_site_annotation = _annotation_from_sites(
            site
            for path in before_paths
            for site in sites_by_node_and_lineage.get(
                (path, transition.lineage_id),
                (),
            )
        )
        after_site_annotation = _annotation_from_sites(
            sites_by_node_and_lineage.get(
                (after_path, transition.lineage_id),
                (),
            )
        )
        updated_transitions.append(
            replace(
                transition,
                before_protection=(
                    before_site_annotation or transition.before_protection
                ),
                after_protection=(after_site_annotation or transition.after_protection),
            )
        )
    return (
        tuple(sorted(updated_records, key=lambda item: item.node_path)),
        tuple(sorted(updated_transitions, key=lambda item: item.transition_id)),
        tuple(errors),
    )


def _require_explicit_mapping(
    molecule: Any,
    smiles_text: str,
    *,
    node_path: tuple[int, ...],
) -> None:
    explicit = tuple(int(value) for value in _EXPLICIT_MAP_RE.findall(smiles_text))
    actual = tuple(sorted(int(atom) for atom in molecule))
    if len(explicit) != len(actual) or tuple(sorted(explicit)) != actual:
        raise ContextHistoryError(
            "every molecule atom requires one explicit positive map ID at node "
            f"path {list(node_path)}"
        )


def _mapping_validation_issues(
    *,
    dataset_id: str,
    route_id: str,
    route: dict[str, Any],
) -> tuple[dict[str, Any], ...]:
    from route_inspector.routes.validation import validate_route_edges

    issues, _reaction_count = validate_route_edges(
        route_id,
        route,
        dataset=dataset_id,
    )
    return tuple(dict(issue) for issue in issues)


def build_route_context_history(
    route: dict[str, Any],
    *,
    dataset_id: str,
    route_id: str | int,
    source_identity: str,
    vocabulary: FunctionalGroupVocabulary | None = None,
    protection_annotator: ProtectionAnnotator | None = None,
    protection_rules: Mapping[str, Any] | None = None,
    detect_protection: bool = True,
    validate_mapping: bool = True,
    context_policy_sha256: str | None = None,
) -> RouteContextHistory:
    """Build one immutable history from a normalized mapped route tree."""

    if not isinstance(route, dict) or route.get("type") != "mol":
        raise ContextHistoryError("context history requires a molecule-root route")
    route_id = str(route_id)
    if validate_mapping:
        issues = _mapping_validation_issues(
            dataset_id=dataset_id,
            route_id=route_id,
            route=route,
        )
        if issues:
            raise ContextHistoryError(
                f"route {route_id!r} failed strict mapping validation",
                errors=issues,
            )
    vocabulary = vocabulary or load_functional_group_vocabulary()
    if detect_protection and protection_annotator is None:
        if protection_rules is None:
            from route_inspector.protection.chython_rules import (
                load_chython_protection_rules,
            )

            protection_rules = load_chython_protection_rules()
    if context_policy_sha256 is None:
        local_policy = {
            **DEFAULT_CONTEXT_POLICY,
            "detect_protection": bool(detect_protection),
            "mapped_protection_tracer": False,
            "protection_annotation_mode": (
                "callback"
                if protection_annotator is not None
                else "per_node_chython"
                if detect_protection
                else "disabled"
            ),
            "protection_rule_ids": sorted(str(key) for key in (protection_rules or {})),
        }
        context_policy_sha256 = canonical_context_policy_sha256(local_policy)
    elif not _valid_sha256(context_policy_sha256):
        raise ContextHistoryError("context policy hash must be a lowercase SHA-256")
    molecule_by_path: dict[tuple[int, ...], Any] = {}
    records_by_path: dict[tuple[int, ...], MoleculeContextRecord] = {}
    reaction_nodes: list[tuple[tuple[int, ...], tuple[int, ...], dict[str, Any]]] = []

    def visit_molecule(node: dict[str, Any], path: tuple[int, ...]) -> None:
        mapped_smiles = route_access.molecule_node_mapped_smiles(
            node
        ) or route_access.molecule_node_smiles(node)
        try:
            molecule = chemistry.parse_molecule(mapped_smiles)
        except Exception as exc:
            raise ContextHistoryError(
                f"could not parse molecule at node path {list(path)}: {exc}"
            ) from exc
        _require_explicit_mapping(molecule, mapped_smiles, node_path=path)
        raw_matches, observations = detect_functional_groups(
            molecule,
            node_path=path,
            vocabulary=vocabulary,
            protection_annotator=protection_annotator,
        )
        protection_sites: tuple[ProtectionSiteObservation, ...] = ()
        if detect_protection and protection_annotator is None:
            protection_sites = detect_chython_protection_sites(
                molecule,
                node_path=path,
                protection_rules=protection_rules,
            )
            observations = _annotate_observations_from_protection_sites(
                observations,
                protection_sites,
            )
        molecule_by_path[path] = molecule
        records_by_path[path] = MoleculeContextRecord(
            node_path=path,
            mapped_smiles=mapped_smiles,
            raw_matches=raw_matches,
            observations=observations,
            protection_sites=protection_sites,
        )
        for reaction_index, reaction_node in enumerate(node.get("children") or ()):
            if (
                not isinstance(reaction_node, dict)
                or reaction_node.get("type") != "reaction"
            ):
                continue
            reaction_path = path + (reaction_index,)
            reaction_nodes.append((reaction_path, path, reaction_node))
            for molecule_index, child in enumerate(reaction_node.get("children") or ()):
                if isinstance(child, dict) and child.get("type") == "mol":
                    visit_molecule(child, reaction_path + (molecule_index,))

    visit_molecule(route, ())
    transitions: list[FunctionalGroupTransition] = []
    errors: list[dict[str, Any]] = []
    for reaction_path, parent_path, reaction_node in sorted(reaction_nodes):
        try:
            reaction = chemistry.parse_reaction(
                route_access.reaction_smiles_from_node(reaction_node)
            )
            center = tuple(sorted(int(atom) for atom in (~reaction).center_atoms))
        except Exception as exc:
            raise ContextHistoryError(
                f"could not parse reaction at node path {list(reaction_path)}: {exc}"
            ) from exc
        child_paths = tuple(
            reaction_path + (index,)
            for index, child in enumerate(reaction_node.get("children") or ())
            if isinstance(child, dict) and child.get("type") == "mol"
        )
        before = tuple(
            observation
            for child_path in child_paths
            for observation in records_by_path[child_path].observations
        )
        edge_transitions, edge_errors = _edge_transitions(
            reaction_path=reaction_path,
            center=center,
            before=before,
            after=records_by_path[parent_path].observations,
            molecule_by_path=molecule_by_path,
        )
        transitions.extend(edge_transitions)
        errors.extend(
            {
                "dataset_id": dataset_id,
                "route_id": route_id,
                **error,
            }
            for error in edge_errors
        )
    records = tuple(records_by_path[path] for path in sorted(records_by_path))
    observations = tuple(
        observation for record in records for observation in record.observations
    )
    assigned_transitions, lineages = _assign_lineages(
        tuple(transitions),
        observations,
        source_identity=source_identity,
        route_id=route_id,
    )
    if detect_protection and protection_annotator is None:
        records, assigned_transitions, protection_errors = _associate_protection_sites(
            records,
            assigned_transitions,
            lineages,
        )
        errors.extend(
            {
                "dataset_id": dataset_id,
                "route_id": route_id,
                **error,
            }
            for error in protection_errors
        )
    return RouteContextHistory(
        dataset_id=dataset_id,
        route_id=route_id,
        source_identity=source_identity,
        vocabulary_version=vocabulary.version_id,
        vocabulary_source_sha256=vocabulary.source_sha256,
        vocabulary_manifest_sha256=vocabulary.manifest_sha256,
        mapping_validated=validate_mapping,
        molecule_records=records,
        reaction_node_paths=tuple(
            reaction_path
            for reaction_path, _parent_path, _reaction_node in sorted(reaction_nodes)
        ),
        transitions=assigned_transitions,
        lineages=lineages,
        route_content_sha256=canonical_route_content_sha256(route),
        context_policy_sha256=context_policy_sha256,
        errors=tuple(errors),
    )


def annotate_routes_context_history(
    routes_json: route_access.RouteCollection,
    *,
    dataset_id: str,
    source_identity: str,
    protection_annotator: ProtectionAnnotator | None = None,
    protection_rules: Mapping[str, Any] | None = None,
    detect_protection: bool = True,
    vocabulary: FunctionalGroupVocabulary | None = None,
    validate_mapping: bool = False,
    context_policy_sha256: str | None = None,
) -> ContextAnnotationResult:
    """Annotate a collection and retain route-scoped failures.

    The stable batch contract assumes the caller already ran strict preprocessing
    validation. Enable validation for standalone or generated-route use.
    """

    vocabulary = vocabulary or load_functional_group_vocabulary()
    histories: list[RouteContextHistory] = []
    errors: list[dict[str, Any]] = []
    routes_seen = 0
    for route_id, route in route_access.route_items(routes_json):
        routes_seen += 1
        try:
            histories.append(
                build_route_context_history(
                    route,
                    dataset_id=dataset_id,
                    route_id=route_id,
                    source_identity=source_identity,
                    vocabulary=vocabulary,
                    protection_annotator=protection_annotator,
                    protection_rules=protection_rules,
                    detect_protection=detect_protection,
                    validate_mapping=validate_mapping,
                    context_policy_sha256=context_policy_sha256,
                )
            )
        except Exception as exc:
            retained = getattr(exc, "errors", ())
            if retained:
                errors.extend(dict(error) for error in retained)
            else:
                errors.append(
                    {
                        "dataset_id": dataset_id,
                        "route_id": str(route_id),
                        "stage": "context_history",
                        "error_type": type(exc).__qualname__,
                        "message": str(exc),
                    }
                )
    return ContextAnnotationResult(
        histories=tuple(sorted(histories, key=_history_sort_key)),
        errors=tuple(errors),
        routes_seen=routes_seen,
    )


def annotate_route_context(
    history: RouteContextHistory,
    annotations: (
        Mapping[str, ProtectionAnnotation]
        | Callable[[FunctionalGroupObservation], ProtectionAnnotation | None]
    ),
) -> RouteContextHistory:
    """Return a history copy carrying an orthogonal protection overlay."""

    def annotation_for(
        observation: FunctionalGroupObservation,
    ) -> ProtectionAnnotation:
        if callable(annotations):
            return annotations(observation) or observation.protection
        return annotations.get(observation.observation_id, observation.protection)

    records = tuple(
        replace(
            record,
            observations=tuple(
                replace(observation, protection=annotation_for(observation))
                for observation in record.observations
            ),
        )
        for record in history.molecule_records
    )
    observations = {
        observation.observation_id: observation
        for record in records
        for observation in record.observations
    }
    transitions = tuple(
        replace(
            transition,
            before_protection=_merge_protection_annotations(
                transition.before_protection,
                (
                    None
                    if transition.before_observation_id is None
                    else observations[transition.before_observation_id].protection
                ),
            ),
            after_protection=_merge_protection_annotations(
                transition.after_protection,
                (
                    None
                    if transition.after_observation_id is None
                    else observations[transition.after_observation_id].protection
                ),
            ),
        )
        for transition in history.transitions
    )
    return replace(history, molecule_records=records, transitions=transitions)


def enrich_route_with_context_history(
    route: dict[str, Any],
    history: RouteContextHistory,
) -> dict[str, Any]:
    """Return an enriched deep copy; never mutate the canonical clean route."""

    enriched = copy.deepcopy(route)
    records = {record.node_path: record for record in history.molecule_records}
    transitions: dict[tuple[int, ...], list[FunctionalGroupTransition]] = defaultdict(
        list
    )
    for transition in history.transitions:
        transitions[transition.reaction_node_path].append(transition)

    def visit(node: dict[str, Any], path: tuple[int, ...]) -> None:
        metadata = node.setdefault("metadata", {})
        if node.get("type") == "mol" and path in records:
            record = records[path]
            metadata["route_context_history"] = {
                "schema_version": history.schema_version,
                "observation_ids": [
                    observation.observation_id for observation in record.observations
                ],
                "context_tokens": list(record.context_tokens),
            }
        elif node.get("type") == "reaction" and path in transitions:
            metadata["route_context_history"] = {
                "schema_version": history.schema_version,
                "transition_ids": [
                    transition.transition_id
                    for transition in sorted(
                        transitions[path],
                        key=lambda item: item.transition_id,
                    )
                ],
            }
        for index, child in enumerate(node.get("children") or ()):
            if isinstance(child, dict):
                visit(child, path + (index,))

    visit(enriched, ())
    return enriched


def _history_sort_key(history: RouteContextHistory) -> tuple[Any, ...]:
    route_id = history.route_id
    return (
        history.dataset_id,
        history.source_identity,
        0 if route_id.isdigit() else 1,
        int(route_id) if route_id.isdigit() else route_id,
    )


def _path_list(value: Any, *, field: str) -> tuple[tuple[int, ...], ...]:
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ContextHistoryError(f"{field} is not valid JSON") from exc
    if not isinstance(value, (tuple, list)):
        raise ContextHistoryError(f"{field} must be a list of node paths")
    return tuple(_path(path) for path in value)


def _occurrence_reaction_paths(
    occurrence: Mapping[str, Any],
) -> tuple[tuple[int, ...], ...]:
    for field in ("interval_reaction_node_paths", "reaction_node_paths"):
        value = occurrence.get(field)
        if value not in (None, "", (), []):
            return _path_list(value, field=field)
    if occurrence.get("reaction_node_path") not in (None, ""):
        value = occurrence["reaction_node_path"]
        if isinstance(value, str):
            value = json.loads(value)
        return (_path(value),)
    source_matches = occurrence.get("source_matches")
    if source_matches:
        if isinstance(source_matches, str):
            source_matches = json.loads(source_matches)
        return tuple(_path(item["reaction_node_path"]) for item in source_matches)

    interval_steps: list[tuple[int, int, tuple[int, ...]]] = []
    for role, field in enumerate(("selected_steps", "skipped_steps")):
        steps = occurrence.get(field) or ()
        if isinstance(steps, str):
            steps = json.loads(steps)
        for item_index, item in enumerate(steps):
            if "reaction_node_path" not in item:
                raise ContextHistoryError(
                    f"{field}[{item_index}] has no reaction_node_path"
                )
            position: int | None = None
            for position_field in (
                "path_position",
                "reaction_index",
                "step_index",
                "position",
            ):
                if item.get(position_field) is not None:
                    position = int(item[position_field])
                    break
            if position is None:
                raise ContextHistoryError(
                    "selected/skipped step projection requires an explicit "
                    "path_position, reaction_index, step_index, or position"
                )
            interval_steps.append((position, role, _path(item["reaction_node_path"])))
    if interval_steps:
        interval_steps.sort()
        return tuple(path for _position, _role, path in interval_steps)
    raise ContextHistoryError("occurrence has no ordered reaction-node-path provenance")


def _protection_transition(
    before: ProtectionAnnotation | None,
    after: ProtectionAnnotation | None,
) -> str:
    before_state = ProtectionState.UNKNOWN if before is None else before.state
    after_state = ProtectionState.UNKNOWN if after is None else after.state
    if before_state is after_state:
        return (
            "persistent" if before_state is ProtectionState.PROTECTED else "unchanged"
        )
    if after_state is ProtectionState.PROTECTED:
        return "introduced"
    if before_state is ProtectionState.PROTECTED:
        return "removed"
    return "changed"


def _joint_location_payload(
    location: ContextLocation | None,
) -> dict[str, Any] | None:
    """Return route-independent raw location evidence for joint identity."""

    if location is None:
        return None
    return {
        "location_class": location.location_class.value,
        "distance": location.distance,
        "aromatic_promoted": location.aromatic_promoted,
        "aromatic_promotion_reason": location.aromatic_promotion_reason,
        "aromatic_component_size": len(location.aromatic_component_atom_maps),
    }


def _lineage_joint_context_token(
    timeline: Iterable[FunctionalGroupTransition],
    *,
    interval_status: str,
    stratum: PatternStratum,
) -> str:
    """Canonical full-lineage token excluding route and protection identity."""

    return json.dumps(
        {
            "joint_context_token_version": 1,
            "stratum": stratum.value,
            "interval_status": interval_status,
            "timeline": [
                {
                    "before_family_id": transition.before_family_id,
                    "after_family_id": transition.after_family_id,
                    "status": transition.status.value,
                    "before_location": _joint_location_payload(
                        transition.before_location
                    ),
                    "after_location": _joint_location_payload(
                        transition.after_location
                    ),
                }
                for transition in timeline
            ],
        },
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )


def project_context_history_to_occurrence(
    history: RouteContextHistory,
    occurrence: Mapping[str, Any],
) -> dict[str, Any]:
    """Project exact occurrence-local context and fail closed on bad provenance."""

    aliases = (
        ("dataset_id", ("dataset_id", "dataset")),
        ("source_identity", ("source_identity",)),
        ("route_id", ("route_id",)),
    )
    for history_field, occurrence_fields in aliases:
        expected = str(getattr(history, history_field))
        supplied = next(
            (
                occurrence.get(field)
                for field in occurrence_fields
                if occurrence.get(field) not in (None, "")
            ),
            None,
        )
        if supplied is not None and str(supplied) != expected:
            raise ContextHistoryError(
                f"occurrence {history_field} does not match context history"
            )

    reaction_paths = _occurrence_reaction_paths(occurrence)
    if not reaction_paths:
        raise ContextHistoryError("occurrence reaction path list is empty")
    if len(set(reaction_paths)) != len(reaction_paths):
        raise ContextHistoryError("occurrence reaction paths are not unique")
    unknown = [
        path for path in reaction_paths if path not in set(history.reaction_node_paths)
    ]
    if unknown:
        raise ContextHistoryError(
            "occurrence paths are absent from context history: "
            + json.dumps([list(path) for path in unknown], separators=(",", ":"))
        )

    source_occurrence_id = occurrence.get("occurrence_id")
    context_history_id = _stable_id(
        "fgho",
        {
            "identity_version": history.identity_version,
            "route_context_history_id": history.history_id,
            "source_occurrence_id": source_occurrence_id,
            "reaction_node_paths": [list(path) for path in reaction_paths],
        },
    )
    observation_by_id = history.observation_by_id()
    transition_by_id = {
        transition.transition_id: transition for transition in history.transitions
    }
    interval_lineages = history.interval_lineages(reaction_paths)
    trace_event_by_id = {
        str(event["event_id"]): dict(event) for event in history.protection_trace_events
    }
    projected_trace_event_by_id: dict[str, dict[str, Any]] = {}
    rows: list[dict[str, Any]] = []
    protection_evidence: list[dict[str, Any]] = []
    for interval in interval_lineages:
        timeline = tuple(
            transition_by_id[transition_id]
            for transition_id in interval["transition_ids"]
        )
        observation_ids: list[str] = []
        family_timeline: list[str] = []
        locations: list[ContextLocation] = []
        protections: list[ProtectionAnnotation] = []
        protection_transitions: list[str] = []
        for transition in timeline:
            for observation_id in (
                transition.before_observation_id,
                transition.after_observation_id,
            ):
                if observation_id is not None and observation_id not in observation_ids:
                    observation_ids.append(observation_id)
                    family = observation_by_id[observation_id].family_id
                    if not family_timeline or family_timeline[-1] != family:
                        family_timeline.append(family)
            for location in (
                transition.before_location,
                transition.after_location,
            ):
                if location is not None:
                    locations.append(location)
            for protection in (
                transition.before_protection,
                transition.after_protection,
            ):
                if protection is not None:
                    protections.append(protection)
            protection_transitions.append(
                _protection_transition(
                    transition.before_protection,
                    transition.after_protection,
                )
            )
        if not observation_ids or not locations or not protections:
            raise ContextHistoryError(
                f"lineage {interval['lineage_id']} lacks a complete context state"
            )
        endpoint_observation_id = (
            timeline[-1].after_observation_id or timeline[-1].before_observation_id
        )
        if endpoint_observation_id is None:
            raise ContextHistoryError(
                f"lineage {interval['lineage_id']} has no endpoint observation"
            )
        representative = observation_by_id[endpoint_observation_id]
        has_center = any(
            location.location_class is LocationClass.CENTER for location in locations
        )
        if has_center:
            location_class = LocationClass.CENTER
        elif any(
            location.location_class is LocationClass.NEAR for location in locations
        ):
            location_class = LocationClass.NEAR
        else:
            location_class = LocationClass.REMOTE
        pg_types = tuple(
            sorted(
                {
                    protection.group_type
                    for protection in protections
                    if protection.group_type
                }
            )
        )
        pg_event_ids = tuple(
            sorted(
                {
                    event_id
                    for protection in protections
                    if protection.event_id
                    for event_id in str(protection.event_id).split("|")
                    if event_id
                }
            )
        )
        lineage_trace_events: list[dict[str, Any]] = []
        for event_id in pg_event_ids:
            event = trace_event_by_id.get(event_id)
            if event is None:
                # Protection-site detector IDs are valid evidence but are not
                # mapped tracer events and therefore have no tracer payload.
                continue
            if str(event.get("linked_lineage_id") or "") != interval["lineage_id"]:
                raise ContextHistoryError(
                    f"protection event {event_id} is linked to a different FG lineage"
                )
            projected_event = {
                **event,
                "context_history_id": context_history_id,
                "source_occurrence_id": source_occurrence_id,
            }
            lineage_trace_events.append(projected_event)
            projected_trace_event_by_id[event_id] = projected_event
        if "changed" in protection_transitions or (
            "introduced" in protection_transitions
            and "removed" in protection_transitions
        ):
            protection_transition = "changed"
        elif "introduced" in protection_transitions:
            protection_transition = "introduced"
        elif "removed" in protection_transitions:
            protection_transition = "removed"
        elif "persistent" in protection_transitions:
            protection_transition = "persistent"
        else:
            protection_transition = "unchanged"
        # A protection site can remain linked to a lineage even when the
        # normalized FG vocabulary has no product observation (for example a
        # terminal ether protection). Prefer that explicit product-side overlay.
        endpoint_protection = (
            timeline[-1].after_protection or timeline[-1].before_protection
        )
        if endpoint_protection is None:
            raise ContextHistoryError(
                f"lineage {interval['lineage_id']} has no endpoint protection state"
            )
        protection_state = endpoint_protection.state
        family_id = representative.family_id
        site_token = f"{family_id}|{location_class.value}"
        summary_token = "|".join(
            (
                ">".join(family_timeline),
                interval["interval_status"],
                location_class.value,
            )
        )
        joint_token = _lineage_joint_context_token(
            timeline,
            interval_status=interval["interval_status"],
            stratum=representative.stratum,
        )
        row = {
            "context_history_id": context_history_id,
            "source_occurrence_id": source_occurrence_id,
            "lineage_id": interval["lineage_id"],
            "observation_ids": observation_ids,
            "family_id": family_id,
            "site_token": site_token,
            "family_timeline": family_timeline,
            "stratum": representative.stratum.value,
            "token": summary_token,
            "summary_token": summary_token,
            "joint_token": joint_token,
            "transition_status": interval["interval_status"],
            "location_class": location_class.value,
            "location_timeline": [
                {
                    "transition_id": transition.transition_id,
                    "reaction_node_path": list(transition.reaction_node_path),
                    "before": (
                        None
                        if transition.before_location is None
                        else _jsonable(asdict(transition.before_location))
                    ),
                    "after": (
                        None
                        if transition.after_location is None
                        else _jsonable(asdict(transition.after_location))
                    ),
                }
                for transition in timeline
            ],
            "transition_timeline": interval["transition_timeline"],
            "atom_maps": list(representative.atom_maps),
            "anchor_atom_maps": list(representative.anchor_atom_maps),
            "protection_state": protection_state.value,
            "protection_group_type": "|".join(pg_types) if pg_types else None,
            "protection_event_ids": list(pg_event_ids),
            "protection_transition": protection_transition,
            "include_in_context_statistics": not has_center,
        }
        rows.append(row)
        protection_evidence.append(
            {
                "context_history_id": context_history_id,
                "source_occurrence_id": source_occurrence_id,
                "lineage_id": interval["lineage_id"],
                "family_id": family_id,
                "site_token": site_token,
                "pg_type": "|".join(pg_types) if pg_types else None,
                "protection_state": protection_state.value,
                "protection_transition": protection_transition,
                "protection_event_ids": list(pg_event_ids),
                "protection_trace_events": lineage_trace_events,
                "transition_timeline": interval["transition_timeline"],
                "include_in_context_statistics": not has_center,
            }
        )
    projected_trace_events = [
        projected_trace_event_by_id[event_id]
        for event_id in sorted(projected_trace_event_by_id)
    ]
    return {
        "schema_version": history.schema_version,
        "identity_version": history.identity_version,
        "context_history_id": context_history_id,
        "route_context_history_id": history.history_id,
        "occurrence_id": source_occurrence_id,
        "dataset_id": history.dataset_id,
        "source_identity": history.source_identity,
        "route_id": history.route_id,
        "reaction_node_paths": [list(path) for path in reaction_paths],
        "functional_group_observations": rows,
        "protection_evidence": protection_evidence,
        "protection_trace_events": projected_trace_events,
        "protection_trace_events_sha256": (
            canonical_protection_trace_events_sha256(projected_trace_events)
        ),
        "interval_lineages": list(interval_lineages),
        "vocabulary_version": history.vocabulary_version,
        "vocabulary_source_sha256": history.vocabulary_source_sha256,
        "vocabulary_manifest_sha256": history.vocabulary_manifest_sha256,
        "route_content_sha256": history.route_content_sha256,
        "context_policy_sha256": history.context_policy_sha256,
    }


def write_context_histories_jsonl(
    path: str | Path,
    histories: Iterable[RouteContextHistory],
) -> Path:
    """Atomically write deterministic plain or gzip JSONL."""

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        json.dumps(
            history.to_dict(),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
        )
        for history in sorted(histories, key=_history_sort_key)
    ]
    payload = (("\n".join(lines) + "\n") if lines else "").encode("utf-8")
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.",
        dir=path.parent,
    )
    try:
        with os.fdopen(descriptor, "wb") as raw:
            if path.suffix == ".gz":
                with gzip.GzipFile(
                    filename="",
                    mode="wb",
                    fileobj=raw,
                    mtime=0,
                ) as compressed:
                    compressed.write(payload)
            else:
                raw.write(payload)
        os.replace(temporary_name, path)
    except Exception:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass
        raise
    return path


def read_context_histories_jsonl(
    path: str | Path,
    *,
    validate_vocabulary: bool = True,
    vocabulary: FunctionalGroupVocabulary | None = None,
) -> tuple[RouteContextHistory, ...]:
    """Read context-history JSONL or JSONL.gz."""

    path = Path(path)
    opener = gzip.open if path.suffix == ".gz" else open
    histories: list[RouteContextHistory] = []
    with opener(path, "rt", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            if not line.strip():
                continue
            try:
                history = RouteContextHistory.from_dict(json.loads(line))
                if validate_vocabulary:
                    vocabulary = vocabulary or load_functional_group_vocabulary()
                    expected = (
                        vocabulary.version_id,
                        vocabulary.source_sha256,
                        vocabulary.manifest_sha256,
                    )
                    actual = (
                        history.vocabulary_version,
                        history.vocabulary_source_sha256,
                        history.vocabulary_manifest_sha256,
                    )
                    if actual != expected:
                        raise ContextHistoryError(
                            "context-history vocabulary identity differs from "
                            "the current pinned vocabulary"
                        )
                histories.append(history)
            except Exception as exc:
                raise ValueError(
                    f"invalid context history at {path}:{line_number}: {exc}"
                ) from exc
    return tuple(histories)


def context_history_summary(
    histories: Iterable[RouteContextHistory],
) -> dict[str, Any]:
    histories = tuple(histories)
    status_counts = Counter(
        transition.status.value
        for history in histories
        for transition in history.transitions
    )
    location_counts = Counter(
        location.location_class.value
        for history in histories
        for transition in history.transitions
        for location in (transition.before_location, transition.after_location)
        if location is not None
    )
    return {
        "schema_version": CONTEXT_HISTORY_SCHEMA_VERSION,
        "routes_written": len(histories),
        "mapping_validated_routes": sum(
            history.mapping_validated for history in histories
        ),
        "molecule_nodes": sum(len(history.molecule_records) for history in histories),
        "raw_functional_group_matches": sum(
            len(record.raw_matches)
            for history in histories
            for record in history.molecule_records
        ),
        "normalized_functional_group_observations": sum(
            len(record.observations)
            for history in histories
            for record in history.molecule_records
        ),
        "protection_sites": sum(
            len(record.protection_sites)
            for history in histories
            for record in history.molecule_records
        ),
        "linked_protection_sites": sum(
            site.linked_lineage_id is not None
            for history in histories
            for site in history.protection_sites
        ),
        "ambiguous_protection_sites": sum(
            bool(site.ambiguous_lineage_ids)
            for history in histories
            for site in history.protection_sites
        ),
        "lineages": sum(len(history.lineages) for history in histories),
        "transitions": sum(len(history.transitions) for history in histories),
        "transitions_by_status": dict(sorted(status_counts.items())),
        "locations": dict(sorted(location_counts.items())),
        "retained_errors": sum(len(history.errors) for history in histories),
    }


def write_context_history_stage_artifacts(
    output_dir: str | Path,
    histories: Iterable[RouteContextHistory],
    *,
    input_files: Iterable[str | Path] = (),
    errors: Iterable[Mapping[str, Any]] = (),
    output_name: str = "context_history.jsonl.gz",
    command_name: str = "annotate-context-history",
    argv: list[str] | None = None,
) -> dict[str, Path]:
    """Write history JSONL plus standard summary/errors/manifest sidecars."""

    from route_inspector.infrastructure.artifacts import write_standard_sidecars

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    histories = tuple(histories)
    history_path = write_context_histories_jsonl(
        output_dir / output_name,
        histories,
    )
    retained_errors = [dict(error) for history in histories for error in history.errors]
    retained_errors.extend(dict(error) for error in errors)
    sidecars = write_standard_sidecars(
        output_dir,
        command_name=command_name,
        summary={
            **context_history_summary(histories),
            "context_history": str(history_path),
        },
        errors=retained_errors,
        input_files=input_files,
        output_files={"context_history": history_path},
        argv=argv,
        extra_manifest={
            "context_history_schema_version": CONTEXT_HISTORY_SCHEMA_VERSION,
            "context_history_identity_version": CONTEXT_HISTORY_IDENTITY_VERSION,
            "vocabulary_versions": sorted(
                {history.vocabulary_version for history in histories}
            ),
            "vocabulary_source_sha256": sorted(
                {history.vocabulary_source_sha256 for history in histories}
            ),
            "vocabulary_manifest_sha256": sorted(
                {history.vocabulary_manifest_sha256 for history in histories}
            ),
            "mapping_validation_required": True,
        },
    )
    return {
        "context_history": history_path,
        **{name: output_dir / Path(value).name for name, value in sidecars.items()},
    }


__all__ = [
    "CONTEXT_HISTORY_IDENTITY_VERSION",
    "CONTEXT_HISTORY_SCHEMA_VERSION",
    "DEFAULT_CONTEXT_POLICY",
    "ContextAnnotationResult",
    "ContextHistoryError",
    "ContextLocation",
    "FunctionalGroupLineage",
    "FunctionalGroupObservation",
    "FunctionalGroupTransition",
    "LocationClass",
    "MoleculeContextRecord",
    "ProtectionAnnotation",
    "ProtectionSiteObservation",
    "ProtectionState",
    "RawFunctionalGroupMatch",
    "RouteContextHistory",
    "TransitionStatus",
    "annotate_route_context",
    "annotate_observations_with_chython_protection",
    "annotate_routes_context_history",
    "build_route_context_history",
    "canonical_context_policy_sha256",
    "canonical_protection_trace_events_sha256",
    "canonical_route_content_sha256",
    "classify_functional_group_location",
    "context_history_summary",
    "detect_chython_protection_sites",
    "detect_functional_groups",
    "enrich_route_with_context_history",
    "project_context_history_to_occurrence",
    "read_context_histories_jsonl",
    "validate_context_history_integrity_metadata",
    "validate_route_context_history_integrity",
    "write_context_histories_jsonl",
    "write_context_history_stage_artifacts",
]
