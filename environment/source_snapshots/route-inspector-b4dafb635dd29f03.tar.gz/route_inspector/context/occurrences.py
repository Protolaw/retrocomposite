"""Attach authoritative route-context references to exact occurrence payloads.

The route history remains the sole persisted source of functional-group state.
Occurrence sidecars carry stable references and an occurrence-local projection ID;
they do not duplicate the potentially large projected history payload.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

from route_inspector.context import (
    RouteContextHistory,
    project_context_history_to_occurrence,
    read_context_histories_jsonl,
    validate_context_history_integrity_metadata,
)
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.rules.occurrences import (
    SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
    SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION,
)
from route_inspector.tactics.rrseq.gapped import (
    RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION,
)
from route_inspector.tactics.rrseq.occurrences import (
    RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION,
)

OCCURRENCE_CONTEXT_REFERENCE_SCHEMA_VERSION = 1


def occurrence_kind(value: Mapping[str, Any]) -> str:
    """Classify one exact occurrence payload without parsing structural keys."""

    if value.get("selected_steps") is not None or value.get("RRseq_gap") is not None:
        return "rrseq_gap"
    if value.get("source_matches") is not None or value.get("RRseq_cons") is not None:
        return "rrseq_cons"
    if value.get("reaction_node_path") is not None:
        return "t1"
    raise ValueError(
        f"occurrence {value.get('occurrence_id')!r} has no exact reaction-node provenance"
    )


def _current_payload_schema(kind: str) -> int:
    return {
        "t1": SINGLE_RULE_OCCURRENCE_SCHEMA_VERSION,
        "rrseq_cons": RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION,
        "rrseq_gap": RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION,
    }[kind]


def _current_identity_version(kind: str) -> int:
    return {
        "t1": SINGLE_RULE_OCCURRENCE_IDENTITY_VERSION,
        "rrseq_cons": RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
        "rrseq_gap": RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION,
    }[kind]


def _history_key(
    *, dataset_id: str, source_identity: str, route_id: str
) -> tuple[str, str, str]:
    return str(dataset_id), str(source_identity), str(route_id)


def authoritative_history_lookup(
    histories: Iterable[RouteContextHistory],
) -> dict[tuple[str, str, str], RouteContextHistory]:
    """Index mapping-certified histories by their exact provenance triple."""

    lookup: dict[tuple[str, str, str], RouteContextHistory] = {}
    for history in histories:
        validate_context_history_integrity_metadata(history)
        if not history.mapping_validated:
            raise ValueError(
                f"context history {history.history_id} is not mapping validated"
            )
        if (
            not history.dataset_id
            or not history.source_identity
            or not history.route_id
        ):
            raise ValueError(
                f"context history {history.history_id} lacks dataset/source/route identity"
            )
        key = _history_key(
            dataset_id=history.dataset_id,
            source_identity=history.source_identity,
            route_id=history.route_id,
        )
        previous = lookup.get(key)
        if previous is not None and previous.to_dict() != history.to_dict():
            raise ValueError(f"conflicting authoritative context histories for {key!r}")
        lookup[key] = history
    return lookup


def _validate_existing_reference(
    occurrence: Mapping[str, Any],
    *,
    route_history_id: str,
    projection_id: str,
) -> None:
    for field in ("context_history_ref", "route_context_history_id"):
        existing = occurrence.get(field)
        if existing not in (None, "") and str(existing) != route_history_id:
            raise ValueError(
                f"occurrence {occurrence.get('occurrence_id')!r} has stale {field}"
            )
    existing_projection = occurrence.get("context_history_projection_id")
    if (
        existing_projection not in (None, "")
        and str(existing_projection) != projection_id
    ):
        raise ValueError(
            f"occurrence {occurrence.get('occurrence_id')!r} has stale "
            "context_history_projection_id"
        )
    legacy_ambiguous_id = occurrence.get("context_history_id")
    if legacy_ambiguous_id not in (None, "") and str(legacy_ambiguous_id) not in {
        route_history_id,
        projection_id,
    }:
        raise ValueError(
            f"occurrence {occurrence.get('occurrence_id')!r} has stale "
            "context_history_id"
        )


def enrich_occurrence_records(
    occurrences: Iterable[Mapping[str, Any]],
    histories: Iterable[RouteContextHistory],
    *,
    dataset_id: str | None = None,
    source_identity: str | None = None,
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    """Attach exact route/projection references, failing closed on any mismatch."""

    expected_dataset = str(dataset_id or "")
    expected_source = str(source_identity or "")
    lookup = authoritative_history_lookup(histories)
    enriched: list[dict[str, Any]] = []
    counts = {"t1": 0, "rrseq_cons": 0, "rrseq_gap": 0}
    seen_occurrence_ids: dict[str, str] = {}
    for record_index, source_record in enumerate(occurrences):
        record = dict(source_record)
        occurrence_id = str(record.get("occurrence_id") or "")
        if not occurrence_id:
            raise ValueError(f"occurrence at index {record_index} has no occurrence_id")
        actual_dataset = str(record.get("dataset_id") or expected_dataset)
        if not actual_dataset:
            raise ValueError(f"occurrence {occurrence_id!r} has no dataset_id")
        if expected_dataset and actual_dataset != expected_dataset:
            raise ValueError(
                f"occurrence {occurrence_id!r} dataset_id differs from {expected_dataset!r}"
            )
        actual_source = str(record.get("source_identity") or "")
        if not actual_source:
            raise ValueError(f"occurrence {occurrence_id!r} has no source_identity")
        if expected_source and actual_source != expected_source:
            raise ValueError(
                f"occurrence {occurrence_id!r} source_identity differs from "
                f"{expected_source!r}"
            )
        route_id = str(record.get("route_id") or "")
        if not route_id:
            raise ValueError(f"occurrence {occurrence_id!r} has no route_id")
        key = _history_key(
            dataset_id=actual_dataset,
            source_identity=actual_source,
            route_id=route_id,
        )
        history = lookup.get(key)
        if history is None:
            raise ValueError(
                f"occurrence {occurrence_id!r} has no authoritative context history "
                f"for {key!r}"
            )

        record["dataset_id"] = actual_dataset
        projection = project_context_history_to_occurrence(history, record)
        projection_id = str(projection["context_history_id"])
        route_history_id = str(projection["route_context_history_id"])
        _validate_existing_reference(
            record,
            route_history_id=route_history_id,
            projection_id=projection_id,
        )
        # Older prototypes used this name for either a route record or an
        # occurrence projection. Remove the ambiguous spelling after validating
        # it so downstream readers cannot select the wrong identity.
        record.pop("context_history_id", None)
        kind = occurrence_kind(record)
        identity_version = _current_identity_version(kind)
        existing_identity_version = record.get("identity_version")
        if (
            existing_identity_version is not None
            and int(existing_identity_version) != identity_version
        ):
            raise ValueError(
                f"occurrence {occurrence_id!r} has unsupported {kind} identity "
                f"version {existing_identity_version}"
            )
        record.update(
            {
                "schema_version": _current_payload_schema(kind),
                "identity_version": identity_version,
                "context_history_reference_schema_version": (
                    OCCURRENCE_CONTEXT_REFERENCE_SCHEMA_VERSION
                ),
                "context_history_ref": route_history_id,
                "route_context_history_id": route_history_id,
                "context_history_projection_id": projection_id,
            }
        )
        from route_inspector.reference_library.context_index.models import (
            validate_native_occurrence_payload,
        )

        validate_native_occurrence_payload(record, kind=kind)
        canonical = json.dumps(record, sort_keys=True, separators=(",", ":"))
        previous = seen_occurrence_ids.get(occurrence_id)
        if previous is not None and previous != canonical:
            raise ValueError(f"conflicting duplicate occurrence ID {occurrence_id!r}")
        if previous is None:
            enriched.append(record)
            counts[kind] += 1
            seen_occurrence_ids[occurrence_id] = canonical

    enriched.sort(key=lambda item: str(item["occurrence_id"]))
    return enriched, counts


def enrich_occurrences_from_history_path(
    occurrences: Iterable[Mapping[str, Any]],
    context_history_path: str | Path,
    *,
    dataset_id: str | None = None,
    source_identity: str | None = None,
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    """Read one authoritative sidecar and enrich occurrence mappings."""

    path = resolve_existing_path(Path(context_history_path))
    histories = read_context_histories_jsonl(path)
    return enrich_occurrence_records(
        occurrences,
        histories,
        dataset_id=dataset_id,
        source_identity=source_identity,
    )


T1LookupKey = tuple[str, str, str, tuple[int, ...]]


def _path(value: Any, *, label: str) -> tuple[int, ...]:
    try:
        path = tuple(int(index) for index in value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be an integer node path") from exc
    if not path or any(index < 0 for index in path):
        raise ValueError(f"{label} must be a non-empty non-negative node path")
    return path


def _canonical_value(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _is_empty_legacy_value(value: Any) -> bool:
    """Return whether an optional legacy field carries no usable evidence."""

    return value == "" or value == () or value == []


def _merge_reconstructed_field(
    destination: dict[str, Any],
    field: str,
    expected: Any,
    *,
    occurrence_id: str,
    location: str,
) -> bool:
    """Fill one exact t1-derived field or reject conflicting historical data."""

    current = destination.get(field)
    if (
        field not in destination
        or current is None
        or (_is_empty_legacy_value(current) and not _is_empty_legacy_value(expected))
    ):
        destination[field] = expected
        return True
    if _canonical_value(current) != _canonical_value(expected):
        raise ValueError(
            f"legacy occurrence {occurrence_id!r} {location}.{field} differs "
            "from the exact reconstructed t1 occurrence"
        )
    return False


def _require_irreducible_fields(
    value: Mapping[str, Any],
    fields: set[str],
    *,
    occurrence_id: str,
    location: str,
) -> None:
    missing = sorted(field for field in fields if field not in value)
    if missing:
        raise ValueError(
            f"legacy occurrence {occurrence_id!r} {location} is irreparably "
            "partial; these fields are not derivable from exact t1 evidence: "
            + ", ".join(missing)
        )


def reconstructed_t1_lookup(
    records: Iterable[Mapping[str, Any]],
) -> dict[T1LookupKey, dict[str, Any]]:
    """Index reconstructed t1 records by exact corpus/source/route/node provenance."""

    lookup: dict[T1LookupKey, dict[str, Any]] = {}
    digests: dict[T1LookupKey, str] = {}
    for index, source_record in enumerate(records):
        record = dict(source_record)
        required = {
            "dataset_id",
            "source_identity",
            "route_id",
            "reaction_node_path",
            "occurrence_id",
        }
        missing = sorted(required - record.keys())
        if missing:
            raise ValueError(
                f"reconstructed t1 record {index} is missing: " + ", ".join(missing)
            )
        key = (
            str(record["dataset_id"]),
            str(record["source_identity"]),
            str(record["route_id"]),
            _path(
                record["reaction_node_path"],
                label=f"reconstructed t1 {record['occurrence_id']!r} reaction path",
            ),
        )
        digest = _canonical_value(record)
        previous = digests.get(key)
        if previous is not None and previous != digest:
            raise ValueError(f"conflicting reconstructed t1 records for {key!r}")
        lookup[key] = record
        digests[key] = digest
    return lookup


def _exact_t1_for_step(
    lookup: Mapping[T1LookupKey, Mapping[str, Any]],
    *,
    dataset_id: str,
    source_identity: str,
    route_id: str,
    step: Mapping[str, Any],
    occurrence_id: str,
    location: str,
) -> Mapping[str, Any]:
    if "reaction_node_path" not in step:
        raise ValueError(
            f"legacy occurrence {occurrence_id!r} {location} has no exact "
            "reaction_node_path"
        )
    reaction_path = _path(
        step["reaction_node_path"],
        label=f"legacy occurrence {occurrence_id!r} {location} reaction path",
    )
    key = (dataset_id, source_identity, route_id, reaction_path)
    reconstructed = lookup.get(key)
    if reconstructed is None:
        raise ValueError(
            f"legacy occurrence {occurrence_id!r} {location} has no reconstructed "
            "t1 match for dataset_id="
            f"{dataset_id!r} source_identity={source_identity!r} "
            f"route_id={route_id!r} reaction_node_path={list(reaction_path)!r}"
        )
    return reconstructed


def _backfill_step_from_t1(
    step: Mapping[str, Any],
    reconstructed: Mapping[str, Any],
    *,
    kind: str,
    occurrence_id: str,
    location: str,
) -> tuple[dict[str, Any], int]:
    migrated = dict(step)
    field_map = {
        "target_molecule_path": "target_molecule_path",
        "rule_smarts": "rule_smarts",
        "reaction_smiles": "reaction_smiles",
        "query_cgr_key": "query_cgr_key",
        "base_query_cgr_key": "base_query_cgr_key",
        "base_rule_atom_maps": "base_rule_atom_maps",
        "raw_source_id": "raw_source_record_id",
        "raw_source_record_id": "raw_source_record_id",
        "source_record_id": "source_record_id",
        "source_document_id": "source_document_id",
        "source_id_adapter": "source_id_adapter",
    }
    if kind == "rrseq_cons":
        field_map.update(
            {
                "target_smiles": "target_smiles",
                "center_atom_maps": "center_atom_maps",
            }
        )
    else:
        field_map.update(
            {
                "target_molecule": "target_smiles",
                "center_atoms": "center_atom_maps",
            }
        )
    backfilled = 0
    for destination_field, source_field in field_map.items():
        backfilled += int(
            _merge_reconstructed_field(
                migrated,
                destination_field,
                reconstructed[source_field],
                occurrence_id=occurrence_id,
                location=location,
            )
        )
    return migrated, backfilled


def _legacy_provenance(
    record: dict[str, Any],
    *,
    dataset_id: str,
    source_identity: str,
) -> tuple[str, str, str, str, int]:
    occurrence_id = str(record.get("occurrence_id") or "")
    if not occurrence_id:
        raise ValueError("legacy occurrence has no occurrence_id")
    backfilled = 0
    for field, expected in (
        ("dataset_id", dataset_id),
        ("source_identity", source_identity),
    ):
        backfilled += int(
            _merge_reconstructed_field(
                record,
                field,
                expected,
                occurrence_id=occurrence_id,
                location="provenance",
            )
        )
    route_id = str(record.get("route_id") or "")
    if not route_id:
        raise ValueError(f"legacy occurrence {occurrence_id!r} has no route_id")
    return occurrence_id, dataset_id, source_identity, route_id, backfilled


def _backfill_legacy_cons(
    source_record: Mapping[str, Any],
    lookup: Mapping[T1LookupKey, Mapping[str, Any]],
    *,
    dataset_id: str,
    source_identity: str,
) -> tuple[dict[str, Any], int]:
    record = dict(source_record)
    occurrence_id, dataset_id, source_identity, route_id, backfilled = (
        _legacy_provenance(
            record,
            dataset_id=dataset_id,
            source_identity=source_identity,
        )
    )
    _require_irreducible_fields(
        record,
        {
            "start_position",
            "end_position",
            "root_index",
            "branch_index",
            "branch_indices",
            "source_matches",
            "source_route_leaves",
        },
        occurrence_id=occurrence_id,
        location="RRseq_cons",
    )
    source_matches = record["source_matches"]
    if not isinstance(source_matches, (list, tuple)) or not all(
        isinstance(match, Mapping) for match in source_matches
    ):
        raise ValueError(
            f"legacy occurrence {occurrence_id!r} source_matches must be objects"
        )
    expected_length = int(record["end_position"]) - int(record["start_position"])
    if expected_length <= 0 or len(source_matches) != expected_length:
        raise ValueError(
            f"legacy occurrence {occurrence_id!r} source_matches do not match "
            "the consecutive interval bounds"
        )
    source_route_leaves = record["source_route_leaves"]
    if not isinstance(source_route_leaves, (list, tuple)) or not all(
        isinstance(leaf, Mapping) for leaf in source_route_leaves
    ):
        raise ValueError(
            f"legacy occurrence {occurrence_id!r} source_route_leaves must be objects"
        )
    for leaf_index, leaf in enumerate(source_route_leaves):
        _require_irreducible_fields(
            leaf,
            {
                "mapped_smiles",
                "step_index",
                "path_position",
                "reactant_index",
                "molecule_node_path",
            },
            occurrence_id=occurrence_id,
            location=f"source_route_leaves[{leaf_index}]",
        )

    migrated_matches: list[dict[str, Any]] = []
    reconstructed_steps: list[Mapping[str, Any]] = []
    irreducible_match_fields = {
        "step_index",
        "path_position",
        "reaction_node_path",
        "product_index",
        "product_to_target_atom_map",
        "continuation_reactant_index",
        "continuation_molecule_path",
        "continuation_to_next_target_atom_map",
    }
    for match_index, match in enumerate(source_matches):
        location = f"source_matches[{match_index}]"
        _require_irreducible_fields(
            match,
            irreducible_match_fields,
            occurrence_id=occurrence_id,
            location=location,
        )
        reconstructed = _exact_t1_for_step(
            lookup,
            dataset_id=dataset_id,
            source_identity=source_identity,
            route_id=route_id,
            step=match,
            occurrence_id=occurrence_id,
            location=location,
        )
        migrated, count = _backfill_step_from_t1(
            match,
            reconstructed,
            kind="rrseq_cons",
            occurrence_id=occurrence_id,
            location=location,
        )
        migrated_matches.append(migrated)
        reconstructed_steps.append(reconstructed)
        backfilled += count
    record["source_matches"] = migrated_matches

    reaction_paths = [match["reaction_node_path"] for match in migrated_matches]
    for field, expected in (
        ("reaction_node_paths", reaction_paths),
        ("raw_sequence", [step["rule_smarts"] for step in reconstructed_steps]),
        ("query_cgr_keys", [step["query_cgr_key"] for step in reconstructed_steps]),
        (
            "base_query_cgr_keys",
            [step["base_query_cgr_key"] for step in reconstructed_steps],
        ),
        ("route_target_smiles", reconstructed_steps[0]["route_target_smiles"]),
        ("segment_target_smiles", reconstructed_steps[0]["target_smiles"]),
        (
            "RRseq_cons",
            "$".join(str(step["rule_smarts"]) for step in reconstructed_steps),
        ),
        ("rrseq_cons_size", len(reconstructed_steps)),
    ):
        backfilled += int(
            _merge_reconstructed_field(
                record,
                field,
                expected,
                occurrence_id=occurrence_id,
                location="RRseq_cons",
            )
        )
    return record, backfilled


def _backfill_legacy_gap(
    source_record: Mapping[str, Any],
    lookup: Mapping[T1LookupKey, Mapping[str, Any]],
    *,
    dataset_id: str,
    source_identity: str,
) -> tuple[dict[str, Any], int]:
    record = dict(source_record)
    occurrence_id, dataset_id, source_identity, route_id, backfilled = (
        _legacy_provenance(
            record,
            dataset_id=dataset_id,
            source_identity=source_identity,
        )
    )
    _require_irreducible_fields(
        record,
        {
            "start_position",
            "selected_positions",
            "selected_steps",
            "skipped_positions",
            "skipped_steps",
            "connector_maps",
            "skipped_center_maps",
            "selected_center_maps",
            "accumulated_history_maps",
            "selected_center_maps_by_step",
            "selected_rule_context_maps_by_step",
            "selected_rule_context_maps",
            "gap_contexts",
            "has_persistent_net_change",
            "route_cgr_provenance",
            "root_index",
            "branch_index",
        },
        occurrence_id=occurrence_id,
        location="RRseq_gap",
    )
    positions_by_collection = {
        "selected_steps": tuple(int(value) for value in record["selected_positions"]),
        "skipped_steps": tuple(int(value) for value in record["skipped_positions"]),
    }
    if len(positions_by_collection["selected_steps"]) < 2:
        raise ValueError(
            f"legacy occurrence {occurrence_id!r} RRseq_gap is irreparably "
            "partial; at least two exact selected steps are required"
        )
    reconstructed_by_collection: dict[str, list[Mapping[str, Any]]] = {}
    for collection, positions in positions_by_collection.items():
        steps = record[collection]
        if not isinstance(steps, (list, tuple)) or not all(
            isinstance(step, Mapping) for step in steps
        ):
            raise ValueError(
                f"legacy occurrence {occurrence_id!r} {collection} must be objects"
            )
        if len(steps) != len(positions):
            raise ValueError(
                f"legacy occurrence {occurrence_id!r} {collection} does not match "
                "its position list"
            )
        migrated_steps: list[dict[str, Any]] = []
        reconstructed_steps: list[Mapping[str, Any]] = []
        for step_index, (position, step) in enumerate(zip(positions, steps)):
            location = f"{collection}[{step_index}]"
            _require_irreducible_fields(
                step,
                {
                    "position",
                    "reaction_node_path",
                    "reactant_center_molecules",
                    "product_center_molecules",
                },
                occurrence_id=occurrence_id,
                location=location,
            )
            if int(step["position"]) != position:
                raise ValueError(
                    f"legacy occurrence {occurrence_id!r} {location}.position "
                    "differs from its exact interval position"
                )
            reconstructed = _exact_t1_for_step(
                lookup,
                dataset_id=dataset_id,
                source_identity=source_identity,
                route_id=route_id,
                step=step,
                occurrence_id=occurrence_id,
                location=location,
            )
            migrated, count = _backfill_step_from_t1(
                step,
                reconstructed,
                kind="rrseq_gap",
                occurrence_id=occurrence_id,
                location=location,
            )
            migrated_steps.append(migrated)
            reconstructed_steps.append(reconstructed)
            backfilled += count
        record[collection] = migrated_steps
        reconstructed_by_collection[collection] = reconstructed_steps

    selected = reconstructed_by_collection["selected_steps"]
    selected_positions = list(positions_by_collection["selected_steps"])
    for field, expected in (
        ("query_cgr_keys", [step["query_cgr_key"] for step in selected]),
        ("base_query_cgr_keys", [step["base_query_cgr_key"] for step in selected]),
        ("RRseq_gap", "$".join(str(step["rule_smarts"]) for step in selected)),
        ("RRseq", "$".join(str(step["rule_smarts"]) for step in selected)),
        ("selected_step_ids", selected_positions),
        ("route_target_smiles", selected[0]["route_target_smiles"]),
        ("target_molecule", selected[0]["target_smiles"]),
    ):
        backfilled += int(
            _merge_reconstructed_field(
                record,
                field,
                expected,
                occurrence_id=occurrence_id,
                location="RRseq_gap",
            )
        )
    return record, backfilled


def backfill_legacy_interval_occurrences(
    records: Iterable[Mapping[str, Any]],
    reconstructed_t1: Iterable[Mapping[str, Any]],
    *,
    dataset_id: str,
    source_identity: str,
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    """Backfill only exact t1-derived fields on legacy cons/gap occurrences."""

    lookup = reconstructed_t1_lookup(reconstructed_t1)
    migrated: list[dict[str, Any]] = []
    counts = {"rrseq_cons": 0, "rrseq_gap": 0, "fields_backfilled": 0}
    for source_record in records:
        kind = occurrence_kind(source_record)
        if kind == "t1":
            continue
        if kind == "rrseq_cons":
            record, backfilled = _backfill_legacy_cons(
                source_record,
                lookup,
                dataset_id=dataset_id,
                source_identity=source_identity,
            )
        else:
            record, backfilled = _backfill_legacy_gap(
                source_record,
                lookup,
                dataset_id=dataset_id,
                source_identity=source_identity,
            )
        migrated.append(record)
        counts[kind] += 1
        counts["fields_backfilled"] += backfilled
    return migrated, counts


__all__ = [
    "OCCURRENCE_CONTEXT_REFERENCE_SCHEMA_VERSION",
    "authoritative_history_lookup",
    "backfill_legacy_interval_occurrences",
    "enrich_occurrence_records",
    "enrich_occurrences_from_history_path",
    "occurrence_kind",
    "reconstructed_t1_lookup",
]
