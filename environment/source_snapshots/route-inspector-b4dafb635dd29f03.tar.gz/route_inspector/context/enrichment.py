"""Attach complete context histories to an occurrence-preserving collection."""

from typing import Any, Mapping

from route_inspector.context.history import (
    RouteContextHistory,
    enrich_route_with_context_history,
)
from route_inspector.routes import access as route_access


def enrich_collection(
    collection: Any,
    histories: Mapping[str, RouteContextHistory],
) -> Any:
    missing = [
        str(route_id)
        for route_id, _route in route_access.route_items(collection)
        if str(route_id) not in histories
    ]
    if missing:
        raise ValueError(
            "cannot write enriched routes without complete context histories: "
            f"missing={sorted(missing)}"
        )
    if isinstance(collection, list):
        return [
            enrich_route_with_context_history(route, histories[str(route_id)])
            for route_id, route in route_access.route_items(collection)
        ]
    return {
        route_id: enrich_route_with_context_history(route, histories[str(route_id)])
        for route_id, route in route_access.route_items(collection)
    }
