"""Packaged runtime configuration resources."""
