"""Resolve the shared reagent standardizer from the supported SynPlanner layout."""

from __future__ import annotations

import importlib
from typing import Any

_STANDARDIZING_MODULE = "synplan.chem.reaction.curation.standardizing"


def resolve_remove_reagents_standardizer() -> type[Any]:
    """Return ``RemoveReagentsStandardizer`` from the installed SynPlanner."""

    module = importlib.import_module(_STANDARDIZING_MODULE)
    return module.RemoveReagentsStandardizer
