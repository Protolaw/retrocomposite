"""Optional reaction-classification provider adapters.

The adapters deliberately expose one small, serializable result contract.  A
confirmed ReactionClassifier label and a recognized NameRXN label can therefore
be processed by the same RRSeq aggregation code without treating the two
providers' taxonomies as interchangeable.
"""

from __future__ import annotations

import importlib
import importlib.metadata
import multiprocessing
import os
import re
import shutil
import subprocess
import sys
import tempfile
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Mapping, Protocol, Sequence, runtime_checkable

REACTIONCLASSIFIER_TAXONOMY = "reactionclassifier"
NAMERXN_TAXONOMY = "namerxn"
SUPPORTED_TIER = 3
DEFAULT_LABEL_POLICY = "confirmed-or-neural"
SUPPORTED_LABEL_POLICIES = frozenset({"confirmed-only", DEFAULT_LABEL_POLICY})


class ProviderUnavailableError(RuntimeError):
    """Raised when an optional classification backend cannot be loaded."""


class ProviderExecutionError(RuntimeError):
    """Raised when a classification backend fails at batch level."""


@dataclass(frozen=True, slots=True)
class ReactionRecord:
    """One reaction submitted to a classification provider.

    ``mapped_reaction`` is retained for provenance. ``classifier_input`` is the
    canonical, atom-map-free forward reaction string sent to the provider.
    """

    record_id: str
    mapped_reaction: str
    classifier_input: str


@dataclass(frozen=True, slots=True)
class ReactionClassResult:
    """Normalized result returned by every reaction-class provider."""

    record_id: str
    provider_name: str
    provider_version: str
    taxonomy_id: str
    raw_code: str | None = None
    raw_name: str | None = None
    tier3_code: str | None = None
    tier3_name: str | None = None
    confidence: float | None = None
    status: str = "unclassified"
    diagnostics: Mapping[str, Any] = field(default_factory=dict)
    accepted: bool = False
    error: str = ""

    @property
    def provider(self) -> str:
        """Compatibility spelling for provider-neutral consumers."""

        return self.provider_name

    @property
    def taxonomy(self) -> str:
        """Compatibility spelling for provider-neutral consumers."""

        return self.taxonomy_id


@runtime_checkable
class ReactionClassProvider(Protocol):
    """Provider-neutral batch-classification interface."""

    provider_name: str
    taxonomy_id: str

    @property
    def provider_version(self) -> str: ...

    def classify_many(
        self,
        records: Sequence[ReactionRecord],
        *,
        n_cpu: int = 1,
        worker_chunksize: int = 100,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> list[ReactionClassResult]: ...


def _validate_supported_options(tier: int, label_policy: str) -> None:
    if int(tier) != SUPPORTED_TIER:
        raise ValueError("only Tier-3 reaction classification is implemented")
    if label_policy not in SUPPORTED_LABEL_POLICIES:
        choices = ", ".join(sorted(SUPPORTED_LABEL_POLICIES))
        raise ValueError(f"label policy must be one of: {choices}")


def project_tier3_code(code: Any) -> str | None:
    """Project a numeric hierarchical code to exactly three components.

    ``None``, shallow labels, and labels containing non-numeric components are
    rejected.  Component spelling is retained so provider output remains fully
    auditable.
    """

    if code is None:
        return None
    text = str(code).strip()
    if not text:
        return None
    components = [component.strip() for component in text.split(".")]
    if len(components) < SUPPORTED_TIER:
        return None
    tier3 = components[:SUPPORTED_TIER]
    if not all(component.isdigit() for component in tier3):
        return None
    return ".".join(tier3)


def _value(result: Any, key: str, default: Any = None) -> Any:
    if isinstance(result, Mapping):
        return result.get(key, default)
    return getattr(result, key, default)


def _reactionclassifier_source_root(package_path: str | os.PathLike[str]) -> Path:
    supplied = Path(package_path).expanduser().resolve()
    candidates = (supplied, supplied / "src")
    for candidate in candidates:
        if (candidate / "reactionclassifier" / "__init__.py").is_file():
            return candidate
    if supplied.name == "reactionclassifier" and (supplied / "__init__.py").is_file():
        return supplied.parent
    raise ProviderUnavailableError(
        "ReactionClassifier package path must contain "
        "reactionclassifier/__init__.py directly or below src/: "
        f"{supplied}"
    )


def _import_reactionclassifier_from(source_root: Path) -> ModuleType:
    source_text = str(source_root)
    if source_text not in sys.path:
        sys.path.insert(0, source_text)
    try:
        return importlib.import_module("reactionclassifier")
    except Exception as exc:
        raise ProviderUnavailableError(
            f"could not import ReactionClassifier from {source_root}: {exc}"
        ) from exc


def _load_reactionclassifier_module(
    package_path: str | os.PathLike[str] | None,
) -> ModuleType:
    """Load ReactionClassifier from an explicit, installed, or local source."""

    if package_path is not None:
        return _import_reactionclassifier_from(
            _reactionclassifier_source_root(package_path)
        )

    try:
        return importlib.import_module("reactionclassifier")
    except ModuleNotFoundError as exc:
        if exc.name not in {"reactionclassifier", None}:
            raise ProviderUnavailableError(
                f"ReactionClassifier dependency {exc.name!r} is unavailable"
            ) from exc
    except Exception as exc:
        raise ProviderUnavailableError(
            f"could not import installed ReactionClassifier: {exc}"
        ) from exc

    repository_root = Path(__file__).resolve().parents[3]
    local_project = repository_root / "ReactionClassifier"
    if local_project.exists():
        return _import_reactionclassifier_from(
            _reactionclassifier_source_root(local_project)
        )
    raise ProviderUnavailableError(
        "ReactionClassifier is not installed and no repository-local "
        "ReactionClassifier/src package was found; install the 'rxnclass' "
        "optional dependency or pass --reaction-classifier-path"
    )


def _module_version(module: ModuleType, distribution: str) -> str:
    version = getattr(module, "__version__", None)
    if version:
        return str(version)
    try:
        return importlib.metadata.version(distribution)
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


def _set_torch_threads(thread_count: int) -> None:
    try:
        torch = importlib.import_module("torch")
        torch.set_num_threads(int(thread_count))
        set_interop_threads = getattr(torch, "set_num_interop_threads", None)
        if set_interop_threads is not None:
            try:
                set_interop_threads(1)
            except RuntimeError:
                # PyTorch permits setting inter-op threads only before parallel
                # work starts.  A reused single-process provider may be too late.
                pass
    except ModuleNotFoundError as exc:
        raise ProviderUnavailableError(
            "ReactionClassifier requires PyTorch, but torch is unavailable"
        ) from exc


def _reactionclassifier_tier3_name(module: ModuleType, code: str) -> str | None:
    name_for = getattr(module, "name_for", None)
    if callable(name_for):
        try:
            return name_for(code)
        except Exception:
            return None
    return None


def _normalize_reactionclassifier_result(
    record: ReactionRecord,
    raw_result: Any,
    *,
    module: ModuleType,
    provider_version: str,
    label_policy: str,
) -> ReactionClassResult:
    raw_code_value = _value(raw_result, "reaction_code")
    raw_name_value = _value(raw_result, "reaction_name")
    neural_code_value = _value(raw_result, "neural_code")
    neural_name_value = _value(raw_result, "neural_name")
    raw_code = None if raw_code_value is None else str(raw_code_value).strip() or None
    raw_name = None if raw_name_value is None else str(raw_name_value).strip() or None
    neural_code = (
        None if neural_code_value is None else str(neural_code_value).strip() or None
    )
    neural_name = (
        None if neural_name_value is None else str(neural_name_value).strip() or None
    )
    confidence_value = _value(raw_result, "confidence")
    try:
        confidence = None if confidence_value is None else float(confidence_value)
    except (TypeError, ValueError):
        confidence = None
    tier_path_value = _value(raw_result, "tier_path", [])
    try:
        tier_path = list(tier_path_value or [])
    except TypeError:
        tier_path = []

    tier3_code = project_tier3_code(raw_code)
    neural_tier3 = project_tier3_code(neural_code)
    diagnostics = {
        "neural_code": neural_code,
        "neural_name": neural_name,
        "neural_tier3_code": neural_tier3,
        "tier_path": tier_path,
    }
    if raw_code is not None and tier3_code is not None:
        return ReactionClassResult(
            record_id=record.record_id,
            provider_name="reactionclassifier",
            provider_version=provider_version,
            taxonomy_id=REACTIONCLASSIFIER_TAXONOMY,
            raw_code=raw_code,
            raw_name=raw_name,
            tier3_code=tier3_code,
            tier3_name=_reactionclassifier_tier3_name(module, tier3_code) or raw_name,
            confidence=confidence,
            status="confirmed",
            diagnostics=diagnostics,
            accepted=True,
        )
    if (
        raw_code is None
        and neural_tier3 is not None
        and label_policy == "confirmed-or-neural"
    ):
        return ReactionClassResult(
            record_id=record.record_id,
            provider_name="reactionclassifier",
            provider_version=provider_version,
            taxonomy_id=REACTIONCLASSIFIER_TAXONOMY,
            tier3_code=neural_tier3,
            tier3_name=(
                _reactionclassifier_tier3_name(module, neural_tier3) or neural_name
            ),
            confidence=confidence,
            status="neural_only",
            diagnostics=diagnostics,
            accepted=True,
        )
    if raw_code is not None:
        status = "invalid_tier3"
    elif neural_code is not None:
        status = "neural_only"
    else:
        status = "unclassified"
    return ReactionClassResult(
        record_id=record.record_id,
        provider_name="reactionclassifier",
        provider_version=provider_version,
        taxonomy_id=REACTIONCLASSIFIER_TAXONOMY,
        raw_code=raw_code,
        raw_name=raw_name,
        confidence=confidence,
        status=status,
        diagnostics=diagnostics,
        accepted=False,
    )


def _reactionclassifier_error_result(
    record: ReactionRecord,
    provider_version: str,
    error: Exception | str,
) -> ReactionClassResult:
    return ReactionClassResult(
        record_id=record.record_id,
        provider_name="reactionclassifier",
        provider_version=provider_version,
        taxonomy_id=REACTIONCLASSIFIER_TAXONOMY,
        status="error",
        accepted=False,
        error=str(error),
    )


_RC_WORKER_CLASSIFIER: Any | None = None
_RC_WORKER_MODULE: ModuleType | None = None
_RC_WORKER_VERSION = "unknown"
_RC_WORKER_LABEL_POLICY = DEFAULT_LABEL_POLICY


def _init_reactionclassifier_worker(
    package_path: str | None,
    device: str,
    tier: int,
    torch_threads: int,
    label_policy: str,
) -> None:
    global _RC_WORKER_CLASSIFIER, _RC_WORKER_MODULE, _RC_WORKER_VERSION
    global _RC_WORKER_LABEL_POLICY
    _set_torch_threads(torch_threads)
    module = _load_reactionclassifier_module(package_path)
    classifier_type = getattr(module, "ReactionClassifier", None)
    if classifier_type is None:
        raise ProviderUnavailableError(
            "reactionclassifier does not export ReactionClassifier"
        )
    _RC_WORKER_CLASSIFIER = classifier_type(device=device, subset_tier=tier)
    _RC_WORKER_MODULE = module
    _RC_WORKER_VERSION = _module_version(module, "reactionclassifier")
    _RC_WORKER_LABEL_POLICY = label_policy


def _reactionclassifier_worker(record: ReactionRecord) -> ReactionClassResult:
    if _RC_WORKER_CLASSIFIER is None or _RC_WORKER_MODULE is None:
        raise RuntimeError("ReactionClassifier worker was not initialized")
    if not record.classifier_input.strip():
        return _reactionclassifier_error_result(
            record,
            _RC_WORKER_VERSION,
            "empty classifier input",
        )
    try:
        raw_result = _RC_WORKER_CLASSIFIER.classify(record.classifier_input)
    except Exception as exc:
        return _reactionclassifier_error_result(record, _RC_WORKER_VERSION, exc)
    return _normalize_reactionclassifier_result(
        record,
        raw_result,
        module=_RC_WORKER_MODULE,
        provider_version=_RC_WORKER_VERSION,
        label_policy=_RC_WORKER_LABEL_POLICY,
    )


class ReactionClassifierProvider:
    """ReactionClassifier adapter with configurable neural-label acceptance."""

    provider_name = "reactionclassifier"
    taxonomy_id = REACTIONCLASSIFIER_TAXONOMY

    def __init__(
        self,
        *,
        package_path: str | os.PathLike[str] | None = None,
        tier: int = SUPPORTED_TIER,
        label_policy: str = DEFAULT_LABEL_POLICY,
        torch_threads: int = 1,
        device: str = "cpu",
    ) -> None:
        _validate_supported_options(tier, label_policy)
        if int(torch_threads) < 1:
            raise ValueError("torch_threads must be at least 1")
        if device != "cpu":
            raise ValueError("only the CPU ReactionClassifier provider is implemented")
        self.package_path = None if package_path is None else str(package_path)
        self.tier = int(tier)
        self.label_policy = label_policy
        self.torch_threads = int(torch_threads)
        self.device = device
        self._module: ModuleType | None = None
        self._classifier: Any | None = None
        self._provider_version: str | None = None

    def _ensure_module(self) -> ModuleType:
        if self._module is None:
            self._module = _load_reactionclassifier_module(self.package_path)
            self._provider_version = _module_version(
                self._module,
                "reactionclassifier",
            )
        return self._module

    @property
    def provider_version(self) -> str:
        self._ensure_module()
        return self._provider_version or "unknown"

    def _ensure_classifier(self) -> Any:
        if self._classifier is None:
            _set_torch_threads(self.torch_threads)
            module = self._ensure_module()
            classifier_type = getattr(module, "ReactionClassifier", None)
            if classifier_type is None:
                raise ProviderUnavailableError(
                    "reactionclassifier does not export ReactionClassifier"
                )
            self._classifier = classifier_type(
                device=self.device,
                subset_tier=self.tier,
            )
        return self._classifier

    def classify_many(
        self,
        records: Sequence[ReactionRecord],
        *,
        n_cpu: int = 1,
        worker_chunksize: int = 100,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> list[ReactionClassResult]:
        records = list(records)
        _validate_record_ids(records)
        if not records:
            return []
        if int(n_cpu) < 1:
            raise ValueError("n_cpu must be at least 1")
        if int(worker_chunksize) < 1:
            raise ValueError("worker_chunksize must be at least 1")

        if int(n_cpu) > 1:
            # Validate and record metadata in the parent before spawning.  Each
            # worker still owns exactly one independently initialized model.
            self._ensure_module()
            context = multiprocessing.get_context("spawn")
            with ProcessPoolExecutor(
                max_workers=int(n_cpu),
                mp_context=context,
                initializer=_init_reactionclassifier_worker,
                initargs=(
                    self.package_path,
                    self.device,
                    self.tier,
                    self.torch_threads,
                    self.label_policy,
                ),
            ) as executor:
                results: list[ReactionClassResult] = []
                for result in executor.map(
                    _reactionclassifier_worker,
                    records,
                    chunksize=int(worker_chunksize),
                ):
                    results.append(result)
                    if progress_callback is not None:
                        progress_callback(len(results), len(records))
                return results

        classifier = self._ensure_classifier()
        module = self._ensure_module()
        version = self.provider_version
        results: list[ReactionClassResult] = []
        for record in records:
            if not record.classifier_input.strip():
                result = _reactionclassifier_error_result(
                    record,
                    version,
                    "empty classifier input",
                )
            else:
                try:
                    raw_result = classifier.classify(record.classifier_input)
                except Exception as exc:
                    result = _reactionclassifier_error_result(record, version, exc)
                else:
                    result = _normalize_reactionclassifier_result(
                        record,
                        raw_result,
                        module=module,
                        provider_version=version,
                        label_policy=self.label_policy,
                    )
            results.append(result)
            if progress_callback is not None:
                progress_callback(len(results), len(records))
        return results


def _validate_record_ids(records: Sequence[ReactionRecord]) -> None:
    seen: set[str] = set()
    for record in records:
        if not record.record_id:
            raise ValueError("reaction record IDs must be non-empty")
        if record.record_id in seen:
            raise ValueError(f"duplicate reaction record ID: {record.record_id}")
        seen.add(record.record_id)


def _resolve_executable(executable: str | os.PathLike[str]) -> Path:
    """Resolve a NameRXN executable from a command, binary, or HazELNut root."""

    text = str(executable)
    supplied = Path(text).expanduser()
    if supplied.is_dir():
        root = supplied.resolve()
        candidates = (
            root / "build" / "namerxn",
            root / "bin" / "namerxn",
            root / "namerxn",
        )
        for candidate in candidates:
            if candidate.is_file() and os.access(candidate, os.X_OK):
                return candidate.resolve()
        tried = ", ".join(str(candidate) for candidate in candidates)
        raise ProviderUnavailableError(
            "NameRXN was not found below the supplied directory; tried: " + tried
        )
    if supplied.is_file() or os.sep in text or (os.altsep and os.altsep in text):
        resolved = supplied.resolve()
        if not resolved.is_file() or not os.access(resolved, os.X_OK):
            raise ProviderUnavailableError(
                f"NameRXN executable is unavailable or not executable: {resolved}"
            )
        return resolved
    discovered = shutil.which(text)
    if discovered is None:
        raise ProviderUnavailableError(
            f"NameRXN executable {text!r} was not found on PATH"
        )
    return Path(discovered).resolve()


_NAMERXN_VERSION_PATTERN = re.compile(r"(?i)NameRXN[^0-9]{0,100}(\d+(?:\.\d+)+)")


def _detect_namerxn_version(executable: Path) -> str:
    """Query NameRXN provenance without making classification depend on it."""

    try:
        completed = subprocess.run(
            [str(executable), "-help"],
            capture_output=True,
            text=True,
            check=False,
        )
    except Exception:
        return "unknown"
    combined = "\n".join(text for text in (completed.stdout, completed.stderr) if text)
    match = _NAMERXN_VERSION_PATTERN.search(combined)
    return match.group(1) if match else "unknown"


def _name_rxn_error_result(
    record: ReactionRecord,
    provider_version: str,
    message: str,
    *,
    diagnostics: Mapping[str, Any] | None = None,
) -> ReactionClassResult:
    return ReactionClassResult(
        record_id=record.record_id,
        provider_name="namerxn",
        provider_version=provider_version,
        taxonomy_id=NAMERXN_TAXONOMY,
        status="error",
        diagnostics=diagnostics or {},
        accepted=False,
        error=message,
    )


def _name_rxn_result(
    record: ReactionRecord,
    raw_code: str,
    *,
    provider_version: str,
) -> ReactionClassResult:
    code = raw_code.strip()
    if code in {"", "0.0"} or code.lower() == "unrecognized":
        return ReactionClassResult(
            record_id=record.record_id,
            provider_name="namerxn",
            provider_version=provider_version,
            taxonomy_id=NAMERXN_TAXONOMY,
            raw_code=code or None,
            status="unclassified",
            accepted=False,
        )
    tier3_code = project_tier3_code(code)
    if tier3_code is None:
        return ReactionClassResult(
            record_id=record.record_id,
            provider_name="namerxn",
            provider_version=provider_version,
            taxonomy_id=NAMERXN_TAXONOMY,
            raw_code=code,
            status="invalid_tier3",
            diagnostics={"reason": "label is not a numeric code with three components"},
            accepted=False,
        )
    return ReactionClassResult(
        record_id=record.record_id,
        provider_name="namerxn",
        provider_version=provider_version,
        taxonomy_id=NAMERXN_TAXONOMY,
        raw_code=code,
        tier3_code=tier3_code,
        status="classified",
        accepted=True,
    )


def _parse_namerxn_output(
    output_path: Path,
    batch_ids: set[str],
) -> tuple[dict[str, str], dict[str, list[str]], list[str]]:
    labels: dict[str, str] = {}
    errors: dict[str, list[str]] = {}
    unexpected: list[str] = []
    with output_path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            stripped = line.rstrip()
            if not stripped:
                continue
            parts = stripped.rsplit(maxsplit=2)
            if len(parts) != 3:
                matched_ids = batch_ids.intersection(stripped.split())
                for batch_id in matched_ids:
                    errors.setdefault(batch_id, []).append(
                        f"malformed NameRXN output at line {line_number}"
                    )
                continue
            batch_id = parts[1]
            if batch_id not in batch_ids:
                unexpected.append(batch_id)
                continue
            if batch_id in labels:
                errors.setdefault(batch_id, []).append(
                    f"duplicate NameRXN output for {batch_id}"
                )
                continue
            labels[batch_id] = parts[2].strip()
    return labels, errors, unexpected


class NameRxnProvider:
    """Batch adapter for the external proprietary NameRXN executable."""

    provider_name = "namerxn"
    taxonomy_id = NAMERXN_TAXONOMY

    def __init__(
        self,
        *,
        executable: str | os.PathLike[str] | None = None,
        tier: int = SUPPORTED_TIER,
        label_policy: str = DEFAULT_LABEL_POLICY,
    ) -> None:
        _validate_supported_options(tier, label_policy)
        self.executable = str(executable or "namerxn")
        self.tier = int(tier)
        self.label_policy = label_policy
        self._provider_version = "unknown"
        self._resolved_executable: Path | None = None

    def _ensure_executable(self) -> Path:
        if self._resolved_executable is None:
            self._resolved_executable = _resolve_executable(self.executable)
            self._provider_version = _detect_namerxn_version(self._resolved_executable)
        return self._resolved_executable

    @property
    def provider_version(self) -> str:
        self._ensure_executable()
        return self._provider_version

    def _classify_batch(
        self,
        records: Sequence[ReactionRecord],
        executable: Path,
        *,
        start_index: int,
    ) -> list[ReactionClassResult]:
        batch_records: list[tuple[str, ReactionRecord]] = []
        immediate_results: dict[str, ReactionClassResult] = {}
        for index, record in enumerate(records, start=start_index):
            batch_id = f"RXN_{index:08d}"
            reaction = record.classifier_input.strip()
            if not reaction:
                immediate_results[record.record_id] = _name_rxn_error_result(
                    record,
                    self.provider_version,
                    "empty classifier input",
                )
            elif any(character.isspace() for character in reaction):
                immediate_results[record.record_id] = _name_rxn_error_result(
                    record,
                    self.provider_version,
                    "NameRXN classifier input contains whitespace",
                )
            else:
                batch_records.append((batch_id, record))

        labels: dict[str, str] = {}
        parse_errors: dict[str, list[str]] = {}
        if batch_records:
            with tempfile.TemporaryDirectory(prefix="route-inspector-namerxn-") as tmp:
                temporary_dir = Path(tmp)
                input_path = temporary_dir / "input.smi"
                output_path = temporary_dir / "output.smi"
                with input_path.open("w", encoding="utf-8", newline="\n") as handle:
                    for batch_id, record in batch_records:
                        handle.write(f"{record.classifier_input.strip()} {batch_id}\n")
                completed = subprocess.run(
                    [str(executable), "-nomap", str(input_path), str(output_path)],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                combined_log = "\n".join(
                    text for text in (completed.stdout, completed.stderr) if text
                )
                version_match = _NAMERXN_VERSION_PATTERN.search(combined_log)
                if version_match:
                    self._provider_version = version_match.group(1)
                if completed.returncode != 0:
                    excerpt = combined_log.strip()[-2000:]
                    raise ProviderExecutionError(
                        f"NameRXN exited with status {completed.returncode}"
                        + (f": {excerpt}" if excerpt else "")
                    )
                if not output_path.is_file():
                    raise ProviderExecutionError(
                        "NameRXN completed without creating its output file"
                    )
                batch_ids = {batch_id for batch_id, _record in batch_records}
                labels, parse_errors, unexpected = _parse_namerxn_output(
                    output_path,
                    batch_ids,
                )
                if unexpected:
                    raise ProviderExecutionError(
                        "NameRXN emitted unexpected record IDs; first is "
                        f"{unexpected[0]}"
                    )

        classified_results: dict[str, ReactionClassResult] = {}
        for batch_id, record in batch_records:
            record_errors = parse_errors.get(batch_id, [])
            if record_errors:
                classified_results[record.record_id] = _name_rxn_error_result(
                    record,
                    self.provider_version,
                    "; ".join(record_errors),
                    diagnostics={"batch_id": batch_id},
                )
            elif batch_id not in labels:
                classified_results[record.record_id] = ReactionClassResult(
                    record_id=record.record_id,
                    provider_name="namerxn",
                    provider_version=self.provider_version,
                    taxonomy_id=NAMERXN_TAXONOMY,
                    status="unclassified",
                    diagnostics={
                        "batch_id": batch_id,
                        "reason": "NameRXN emitted no output record",
                    },
                    accepted=False,
                )
            else:
                classified_results[record.record_id] = _name_rxn_result(
                    record,
                    labels[batch_id],
                    provider_version=self.provider_version,
                )
        classified_results.update(immediate_results)
        return [classified_results[record.record_id] for record in records]

    def classify_many(
        self,
        records: Sequence[ReactionRecord],
        *,
        n_cpu: int = 1,
        worker_chunksize: int = 100,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> list[ReactionClassResult]:
        del n_cpu  # The external NameRXN command controls its own execution.
        records = list(records)
        _validate_record_ids(records)
        if int(worker_chunksize) < 1:
            raise ValueError("worker_chunksize must be at least 1")
        if not records:
            return []
        executable = self._ensure_executable()
        results: list[ReactionClassResult] = []
        chunk_size = int(worker_chunksize)
        for offset in range(0, len(records), chunk_size):
            chunk = records[offset : offset + chunk_size]
            results.extend(
                self._classify_batch(
                    chunk,
                    executable,
                    start_index=offset + 1,
                )
            )
            if progress_callback is not None:
                progress_callback(min(offset + len(chunk), len(records)), len(records))
        return results


def create_provider(
    backend: str,
    *,
    reaction_classifier_path: str | os.PathLike[str] | None = None,
    namerxn_path: str | os.PathLike[str] | None = None,
    namerxn_executable: str | os.PathLike[str] | None = None,
    tier: int = SUPPORTED_TIER,
    label_policy: str = DEFAULT_LABEL_POLICY,
    torch_threads: int = 1,
    device: str = "cpu",
) -> ReactionClassProvider:
    """Construct one provider without importing its optional dependencies."""

    normalized = backend.strip().lower().replace("-", "")
    if normalized == "reactionclassifier":
        return ReactionClassifierProvider(
            package_path=reaction_classifier_path,
            tier=tier,
            label_policy=label_policy,
            torch_threads=torch_threads,
            device=device,
        )
    if normalized == "namerxn":
        if namerxn_path is not None and namerxn_executable is not None:
            if Path(namerxn_path).expanduser() != Path(namerxn_executable).expanduser():
                raise ValueError(
                    "namerxn_path and namerxn_executable specify different paths"
                )
        return NameRxnProvider(
            executable=(
                namerxn_path if namerxn_path is not None else namerxn_executable
            ),
            tier=tier,
            label_policy=label_policy,
        )
    raise ValueError(
        f"unsupported reaction-classification backend {backend!r}; "
        "choose 'reactionclassifier' or 'namerxn'"
    )


__all__ = [
    "NAMERXN_TAXONOMY",
    "REACTIONCLASSIFIER_TAXONOMY",
    "NameRxnProvider",
    "ProviderExecutionError",
    "ProviderUnavailableError",
    "ReactionClassProvider",
    "ReactionClassResult",
    "ReactionClassifierProvider",
    "ReactionRecord",
    "create_provider",
    "project_tier3_code",
]
