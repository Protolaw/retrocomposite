"""Shared reaction-class result helpers used by classification stages."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Any, Iterable, Mapping


def record_id(classifier_input: str) -> str:
    """Return the stable provider record ID for a canonical reaction string."""

    digest = hashlib.sha256(classifier_input.encode("utf-8")).hexdigest()
    return f"rxn_{digest[:24]}"


def result_attr(result: Any | None, name: str, default: Any = "") -> Any:
    """Read a normalized result attribute, including compatibility aliases."""

    if result is None:
        return default
    aliases = {
        "provider_name": ("provider_name", "provider"),
        "taxonomy_id": ("taxonomy_id", "taxonomy"),
    }
    for candidate in aliases.get(name, (name,)):
        if hasattr(result, candidate):
            value = getattr(result, candidate)
            return default if value is None else value
    return default


def diagnostics(result: Any | None) -> dict[str, Any]:
    """Return classifier diagnostics as an ordinary dictionary."""

    value = result_attr(result, "diagnostics", {})
    return dict(value) if isinstance(value, Mapping) else {"value": value}


def valid_tier3(code: str) -> bool:
    """Return whether a code has exactly three numeric components."""

    return bool(re.fullmatch(r"\d+\.\d+\.\d+", code))


def result_accepted(result: Any | None, *, error: str = "") -> bool:
    """Return whether a provider result is accepted as a numeric Tier-3 label."""

    if error or result is None:
        return False
    code = str(result_attr(result, "tier3_code", ""))
    return bool(result_attr(result, "accepted", False)) and valid_tier3(code)


@dataclass
class BatchReconciliation:
    """Provider results reconciled against the submitted stable record IDs."""

    result_by_id: dict[str, Any]
    duplicate_ids: tuple[str, ...]
    unexpected_ids: tuple[str, ...]
    empty_result_ids: int


def reconcile_batch_results(
    expected_ids: Iterable[str],
    results: Iterable[Any],
    *,
    ignore_errors: bool,
) -> BatchReconciliation:
    """Reconcile one provider batch without depending on a stage's row schema."""

    expected = {str(value) for value in expected_ids}
    result_by_id: dict[str, Any] = {}
    duplicates: set[str] = set()
    unexpected: set[str] = set()
    empty_result_ids = 0
    for result in results:
        result_id = str(result_attr(result, "record_id", ""))
        if not result_id:
            empty_result_ids += 1
            continue
        if result_id not in expected:
            unexpected.add(result_id)
            continue
        if result_id in result_by_id:
            duplicates.add(result_id)
            continue
        result_by_id[result_id] = result

    if (duplicates or unexpected or empty_result_ids) and not ignore_errors:
        details = []
        if duplicates:
            details.append("duplicate=" + ",".join(sorted(duplicates)))
        if unexpected:
            details.append("unexpected=" + ",".join(sorted(unexpected)))
        if empty_result_ids:
            details.append(f"empty={empty_result_ids}")
        raise ValueError(
            "reaction-class provider returned irreconcilable record IDs: "
            + "; ".join(details)
        )

    # A duplicated identifier is ambiguous: never accept the provider's first row.
    for duplicate_id in duplicates:
        result_by_id.pop(duplicate_id, None)
    return BatchReconciliation(
        result_by_id=result_by_id,
        duplicate_ids=tuple(sorted(duplicates)),
        unexpected_ids=tuple(sorted(unexpected)),
        empty_result_ids=empty_result_ids,
    )


def provider_metadata(provider: Any) -> tuple[str, str, str]:
    """Return normalized provider name, version, and taxonomy metadata."""

    provider_name = str(
        getattr(provider, "provider_name", getattr(provider, "provider", ""))
    )
    provider_version = str(getattr(provider, "provider_version", "") or "unknown")
    taxonomy = str(getattr(provider, "taxonomy_id", getattr(provider, "taxonomy", "")))
    return provider_name, provider_version, taxonomy


__all__ = [
    "BatchReconciliation",
    "diagnostics",
    "provider_metadata",
    "reconcile_batch_results",
    "record_id",
    "result_accepted",
    "result_attr",
    "valid_tier3",
]
