"""Persist source-bound NameRxn annotations without extracting reaction rules."""

import json
import re
from pathlib import Path


def taxonomy_names(path):
    """Read labels supplied with this NameRxn build; codes remain authoritative."""
    names = {}
    if path is None:
        return names
    pattern = re.compile(r'^RXN\([^,]+,("(?:\\.|[^"\\])*"),[^,]+,"([^"]+)"')
    for line in Path(path).read_text().splitlines():
        match = pattern.match(line)
        if match:
            name, code = json.loads(match[1]), match[2]
            if code in names and names[code] != name:
                raise ValueError(f"conflicting NameRxn taxonomy label: {code}")
            names[code] = name
    if not names:
        raise ValueError("no NameRxn taxonomy definitions found")
    return names
