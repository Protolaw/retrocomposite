"""Canonical molecular representations and constitutional graph comparison."""

from __future__ import annotations

from functools import lru_cache
from typing import Any

from route_inspector.chemistry.parsing import parse_reaction


def canonical_molecule_string(molecule: Any) -> str:
    """Return a canonical, unmapped molecule string without mutating the input."""

    molecule_copy = molecule.copy()
    molecule_copy.canonicalize()
    return str(molecule_copy)


@lru_cache(maxsize=8192)
def canonical_unmapped_reaction_string(reaction_smiles: str) -> str:
    """Return a canonical atom-map-free reaction without changing its direction.

    Chython retains atom-map identities internally when it parses a mapped reaction,
    while its ordinary reaction string representation omits those identities. A
    copied container is canonicalized here so callers receive a stable
    ``reactants>>products`` classifier input without mutating the cached parse.
    """

    reaction = parse_reaction(reaction_smiles).copy()
    reaction.canonicalize()
    return str(reaction)


def molecules_equivalent(left: Any, right: Any) -> bool:
    """Compare exact constitutional graphs with a stereo-agnostic fallback."""

    if left.atoms_count != right.atoms_count or left.bonds_count != right.bonds_count:
        return False

    left_copy = left.copy()
    right_copy = right.copy()
    left_copy.canonicalize()
    right_copy.canonicalize()
    if left_copy == right_copy:
        return True

    left_copy = left.copy()
    right_copy = right.copy()
    try:
        left_copy.clean_stereo()
        right_copy.clean_stereo()
    except Exception:
        return False
    left_copy.canonicalize()
    right_copy.canonicalize()
    return left_copy == right_copy
