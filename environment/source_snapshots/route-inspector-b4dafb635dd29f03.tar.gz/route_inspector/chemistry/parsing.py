"""Cached Chython molecule and reaction parsing."""

from __future__ import annotations

from functools import lru_cache
from typing import Any


@lru_cache(maxsize=1024)
def parse_molecule(smiles_text: str) -> Any:
    """Parse a molecule SMILES string with Chython."""

    from chython import smiles

    return smiles(smiles_text)


@lru_cache(maxsize=1024)
def parse_reaction(reaction_smiles: str) -> Any:
    """Parse a reaction SMILES string with Chython."""

    from chython import smiles

    return smiles(reaction_smiles)
