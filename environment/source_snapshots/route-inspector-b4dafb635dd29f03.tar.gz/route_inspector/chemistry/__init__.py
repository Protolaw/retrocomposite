"""Shared parsing, molecular comparison, and atom-map correspondence API."""

from route_inspector.chemistry.mapping import (
    DEFAULT_MAX_STATE_PRESERVING_MAPPINGS,
    AtomMapping,
    MoleculeAlignmentLimitError,
    exact_map_identity_mapping,
    exact_mapped_reactions_correspond,
    find_matching_molecule,
    mapped_molecules_correspond,
    state_preserving_molecule_mapping,
)
from route_inspector.chemistry.mapping import strict_atom_mapping as strict_atom_mapping
from route_inspector.chemistry.molecules import (
    canonical_molecule_string,
    canonical_unmapped_reaction_string,
    molecules_equivalent,
)
from route_inspector.chemistry.parsing import parse_molecule, parse_reaction

__all__ = [
    "AtomMapping",
    "DEFAULT_MAX_STATE_PRESERVING_MAPPINGS",
    "MoleculeAlignmentLimitError",
    "canonical_molecule_string",
    "canonical_unmapped_reaction_string",
    "exact_map_identity_mapping",
    "exact_mapped_reactions_correspond",
    "find_matching_molecule",
    "mapped_molecules_correspond",
    "molecules_equivalent",
    "parse_molecule",
    "parse_reaction",
    "state_preserving_molecule_mapping",
]
