"""Strict atom correspondence and state-preserving molecular alignment.

Strict comparison retains hydrogen-state distinctions. Alignment separately
normalizes Chython's equivalent no-hydrogen sentinels.
"""

from __future__ import annotations

from typing import Any, Iterable

from route_inspector.chemistry.molecules import molecules_equivalent
from route_inspector.chemistry.parsing import parse_molecule

AtomMapping = tuple[tuple[int, int], ...]
DEFAULT_MAX_STATE_PRESERVING_MAPPINGS = 10_000


class MoleculeAlignmentLimitError(RuntimeError):
    """Raised when exhaustive state-preserving alignment exceeds its limit."""


def _atom_signature(atom: Any) -> tuple[Any, ...]:
    return (
        atom.atomic_number,
        atom.isotope,
        atom.charge,
        atom.is_radical,
        atom.implicit_hydrogens,
        atom.hybridization,
    )


def _alignment_atom_signature(atom: Any) -> tuple[Any, ...]:
    """Return atom state with Chython's two no-hydrogen sentinels unified.

    Chython can expose an aromatic heteroatom with no implicit hydrogens as either
    ``None`` or ``0`` depending on whether it came from a standalone molecule or a
    reaction component. Both serialize to the same atom state (for example
    ``[o]`` or ``[n]``). Positive counts, including aromatic ``[nH]``, remain
    distinct.
    """

    signature = list(_atom_signature(atom))
    if signature[4] is None:
        signature[4] = 0
    return tuple(signature)


def strict_atom_mapping(
    left: Any,
    right: Any,
    mapping: dict[int, int],
) -> bool:
    if len(mapping) != left.atoms_count:
        return False
    if any(
        _atom_signature(left.atom(atom_number))
        != _atom_signature(right.atom(mapping[atom_number]))
        for atom_number in left
    ):
        return False
    for atom_number, neighbor_number, bond in left.bonds():
        try:
            other = right.bond(
                mapping[atom_number],
                mapping[neighbor_number],
            )
        except Exception:
            return False
        if int(bond) != int(other):
            return False
    return True


def _state_preserving_mapping(
    left: Any,
    right: Any,
    mapping: dict[int, int],
) -> bool:
    """Check exact graph state while tolerating equivalent no-H sentinels."""

    if len(mapping) != left.atoms_count:
        return False
    if any(
        _alignment_atom_signature(left.atom(atom_number))
        != _alignment_atom_signature(right.atom(mapping[atom_number]))
        for atom_number in left
    ):
        return False
    for atom_number, neighbor_number, bond in left.bonds():
        try:
            other = right.bond(
                mapping[atom_number],
                mapping[neighbor_number],
            )
        except Exception:
            return False
        if int(bond) != int(other):
            return False
    return True


def exact_map_identity_mapping(left: Any, right: Any) -> AtomMapping | None:
    """Return the identity map alignment when both mapped graphs are exact."""

    try:
        if (
            left.atoms_count != right.atoms_count
            or left.bonds_count != right.bonds_count
        ):
            return None
        left_ids = {int(atom_number) for atom_number in left}
        right_ids = {int(atom_number) for atom_number in right}
        if left_ids != right_ids:
            return None
        mapping = {atom_number: atom_number for atom_number in left_ids}
        if not strict_atom_mapping(left, right, mapping):
            return None
    except (AttributeError, TypeError, ValueError):
        return None
    return tuple(sorted(mapping.items()))


def state_preserving_molecule_mapping(
    left: Any,
    right: Any,
    *,
    max_mappings: int = DEFAULT_MAX_STATE_PRESERVING_MAPPINGS,
) -> AtomMapping | None:
    """Return the least-changing exact-state graph alignment.

    Persistent-map identity is retained whenever it is already exact. Otherwise
    all Chython automorphisms are considered because the default automorphism
    filter can hide the only alignment that preserves an aromatic ``[nH]`` or
    another atom state. Among exact-state witnesses, the alignment moving the
    fewest existing map IDs is selected, followed by lexical ordering.

    ``None`` means that the molecules have no state-preserving isomorphism. The
    search raises :class:`MoleculeAlignmentLimitError` rather than accepting an
    unproven best-so-far mapping when the safety limit is exceeded.
    """

    if max_mappings < 1:
        raise ValueError("max_mappings must be at least 1")

    identity = exact_map_identity_mapping(left, right)
    if identity is not None:
        return identity
    try:
        if (
            left.atoms_count != right.atoms_count
            or left.bonds_count != right.bonds_count
        ):
            return None
        mappings = left.get_mapping(right, automorphism_filter=False)
    except (AttributeError, TypeError, ValueError):
        return None

    best: AtomMapping | None = None
    best_key: tuple[int, tuple[int, ...]] | None = None
    mappings_seen = 0
    for raw_mapping in mappings:
        mappings_seen += 1
        if mappings_seen > max_mappings:
            raise MoleculeAlignmentLimitError(
                "state-preserving molecule alignment exceeded "
                f"{max_mappings} graph mappings"
            )
        mapping = {int(source): int(target) for source, target in raw_mapping.items()}
        if not _state_preserving_mapping(left, right, mapping):
            continue
        pairs = tuple(sorted(mapping.items()))
        key = (
            sum(source != target for source, target in pairs),
            tuple(target for _source, target in pairs),
        )
        if best_key is None or key < best_key:
            best = pairs
            best_key = key
    return best


def exact_mapped_reactions_correspond(left: Any, right: Any) -> bool:
    """Compare reaction sides as exact persistent-map graph multisets.

    Component ordering and SMILES traversal may differ, but reaction direction,
    component multiplicity, mapped atom identities, atom states, and bond states
    must be identical. Stereochemical labels are intentionally not compared.
    """

    for side in ("reactants", "products", "reagents"):
        left_components = tuple(getattr(left, side, ()))
        right_components = tuple(getattr(right, side, ()))
        if len(left_components) != len(right_components):
            return False
        unmatched = set(range(len(right_components)))
        for left_component in left_components:
            match = next(
                (
                    index
                    for index in sorted(unmatched)
                    if exact_map_identity_mapping(
                        left_component, right_components[index]
                    )
                    is not None
                ),
                None,
            )
            if match is None:
                return False
            unmatched.remove(match)
    return True


def mapped_molecules_correspond(left: Any, right: Any) -> bool:
    """Match route molecules by mapped identity and then exact graph isomorphism."""

    if left.atoms_count != right.atoms_count or left.bonds_count != right.bonds_count:
        return False
    if exact_map_identity_mapping(left, right) is not None:
        return True
    try:
        if any(True for _mapping in left.get_mapping(right)):
            return True
    except Exception:
        pass
    return molecules_equivalent(left, right)


def find_matching_molecule(
    candidates: Iterable[Any],
    reference: Any | None,
    *,
    fallback_smiles: str = "",
    excluded_indexes: set[int] | None = None,
) -> tuple[int, Any] | tuple[None, None]:
    """Return the first candidate corresponding to a mapped route molecule."""

    excluded = excluded_indexes or set()
    reference_molecule = reference
    if reference_molecule is None and fallback_smiles:
        try:
            reference_molecule = parse_molecule(fallback_smiles)
        except Exception:
            reference_molecule = None
    if reference_molecule is None:
        return None, None

    for index, candidate in enumerate(candidates):
        if index in excluded:
            continue
        try:
            if mapped_molecules_correspond(candidate, reference_molecule):
                return index, candidate
        except Exception:
            continue
    return None, None
