"""Read-only native stereo identities, including symmetry-equivalent spellings.

Mapped identities use a common map-ordered traversal. Unmapped identities
minimize that traversal over constitutional automorphisms, since Chython's
ordinary SMILES ordering can leave symmetric stereo centres tied.
"""

from functools import lru_cache

from route_inspector.chemistry.mapping import (
    DEFAULT_MAX_STATE_PRESERVING_MAPPINGS,
    MoleculeAlignmentLimitError,
    _state_preserving_mapping,
)


@lru_cache(maxsize=16384)
def stereo_molecule(text):
    """Parse without discarding stereo; permit only redundant directional bonds.

    The strict reader validates stereo annotations before rejecting unused slash
    marks. That specific failure may be reparsed permissively; other stereo errors
    remain failures. Returned cached containers must never be mutated.
    """
    from chython import smiles
    from chython.containers import MoleculeContainer

    try:
        molecule = smiles(text, strict_stereo=True)
    except ValueError as error:
        if str(error) != "directional bond has no assigned stereo element":
            raise
        molecule = smiles(text)
    if not isinstance(molecule, MoleculeContainer) or not molecule.atoms_count:
        raise ValueError("Expected a nonempty molecular SMILES")
    return molecule


def map_ordered_signature(molecule):
    """Retain fixed maps, stereo, isotopes, atom states and CX radical labels."""
    tokens, order = molecule._smiles(int, mapping=True, _return_order=True)
    text = "".join(tokens)
    extension = molecule._format_cxsmiles(order)
    return f"{text} {extension}" if extension else text


@lru_cache(maxsize=16384)
def unmapped_stereo_signature(text, *, remove_stereo=False):
    molecule = stereo_molecule(text).copy()
    molecule.kekule()
    molecule.thiele(fix_tautomers=False)
    scaffold = molecule.copy()
    scaffold.clean_stereo()
    constitutional = str(scaffold)
    has_stereo = any(a.stereo is not None for _, a in molecule.atoms()) or any(
        bond.stereo is not None for _, _, bond in molecule.bonds()
    )
    if remove_stereo or not has_stereo:
        return constitutional

    # Parsing the unmapped constitutional string establishes a common set of
    # traversal labels. These temporary IDs never reach the stored route.
    reference = stereo_molecule(constitutional)
    best = None
    for count, mapping in enumerate(
        molecule.get_mapping(reference, automorphism_filter=False), start=1
    ):
        if count > DEFAULT_MAX_STATE_PRESERVING_MAPPINGS:
            raise MoleculeAlignmentLimitError(
                "stereo identity exceeds "
                f"{DEFAULT_MAX_STATE_PRESERVING_MAPPINGS} graph mappings"
            )
        if not _state_preserving_mapping(molecule, reference, mapping):
            continue
        candidate = molecule.copy()
        candidate.remap(mapping)
        key = map_ordered_signature(candidate)
        if best is None or key < best:
            best = key
    if best is None:
        raise ValueError("No state-preserving native stereo correspondence")
    return best
