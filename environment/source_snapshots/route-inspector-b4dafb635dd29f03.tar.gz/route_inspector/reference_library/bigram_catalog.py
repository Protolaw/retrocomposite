"""Exact, supplementary Retro-BLEU-like bigram reference catalog."""

from __future__ import annotations

import csv
import hashlib
import json
from collections import OrderedDict, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from route_inspector.metrics.retro_bleu.bigrams import RetroBleuBigramOccurrence
from route_inspector.reference_library.models import ReferenceRouteKey
from route_inspector.rules.graph import canonical_json

RETRO_BLEU_BIGRAM_IDENTITY_VERSION = 2
SUPPORTED_RETRO_BLEU_BIGRAM_IDENTITY_VERSIONS = frozenset({1, 2})
REFERENCE_BIGRAM_OCCURRENCE_SCHEMA_VERSION = 2
SUPPORTED_REFERENCE_BIGRAM_OCCURRENCE_SCHEMA_VERSIONS = frozenset({1, 2})
REFERENCE_BIGRAM_ENTRY_SCHEMA_VERSION = 2
SUPPORTED_REFERENCE_BIGRAM_ENTRY_SCHEMA_VERSIONS = frozenset({1, 2})
RETRO_BLEU_BIGRAM_CATALOG_SCHEMA_VERSION = 2
SUPPORTED_RETRO_BLEU_BIGRAM_CATALOG_SCHEMA_VERSIONS = frozenset({1, 2})

LEGACY_RETRO_BLEU_BIGRAM_IDENTITY_CONFIGURATION = {
    "identity_version": 1,
    "gram_length": 2,
    "rule_order_preserved": True,
    "atom_mapping_in_identity": False,
    "lookup_key_role": "candidate_index_only",
    "authoritative_equivalence": "ordered_exact_labelled_rule_graphs",
    "reaction_centre_continuity_required": False,
    "route_topology": "immediate_parent_to_child",
}

RETRO_BLEU_BIGRAM_IDENTITY_CONFIGURATION = {
    "identity_version": RETRO_BLEU_BIGRAM_IDENTITY_VERSION,
    "gram_length": 2,
    "rule_order_preserved": True,
    "atom_mapping_in_identity": False,
    "lookup_key_role": "candidate_index_only",
    "authoritative_equivalence": "ordered_complete_context_query_cgr_keys",
    "query_cgr_key_source": ("synplan.chem.utils.cgr_utils.canonical_query_cgr_key"),
    "query_cgr_key_context": "context_bearing",
    "high_symmetry_fallback": (
        "deterministic greedy canonicalization can split isomorphic high-symmetry "
        "rules; equal complete keys remain authoritative"
    ),
    "reaction_centre_continuity_required": False,
    "route_topology": "immediate_parent_to_child",
}


def _json_copy(value: Any, *, label: str) -> Any:
    try:
        return json.loads(canonical_json(value))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be finite JSON data") from exc


def _legacy_bigram_lookup_key(rules: tuple[Mapping[str, Any], ...]) -> str:
    from route_inspector.rules.graph import graph_coarse_signature

    signature = {
        "identity_version": 1,
        "ordered_rule_graph_signatures": [
            graph_coarse_signature(rule) for rule in rules
        ],
    }
    digest = hashlib.sha256(canonical_json(signature).encode("utf-8")).hexdigest()
    return f"retro_bleu_bigram_i_{digest}"


def _query_key_bigram_lookup_key(query_cgr_keys: tuple[str, str]) -> str:
    signature = {
        "identity_version": RETRO_BLEU_BIGRAM_IDENTITY_VERSION,
        "family": "retro_bleu_like_bigram",
        "query_cgr_keys": list(query_cgr_keys),
    }
    digest = hashlib.sha256(canonical_json(signature).encode("utf-8")).hexdigest()
    return f"retro_bleu_bigram_i_{digest}"


def _exact_identity_certificate(identity: "RetroBleuBigramIdentity") -> str:
    if identity.identity_version == 2:
        return canonical_json(
            {
                "identity_version": 2,
                "query_cgr_keys": list(identity.query_cgr_keys),
            }
        )
    from route_inspector.rules.canonical import _canonical_graph_certificate

    return canonical_json(
        {
            "identity_version": identity.identity_version,
            "ordered_rule_graph_certificates": [
                _canonical_graph_certificate(rule) for rule in identity.rules
            ],
        }
    )


@dataclass(frozen=True)
class RetroBleuBigramIdentity:
    """Versioned identity for an ordered pair of contiguous reaction rules."""

    query_cgr_keys: tuple[str, str] = ("", "")
    rules: tuple[Mapping[str, Any], ...] = ()
    lookup_key: str = ""
    identity_version: int = RETRO_BLEU_BIGRAM_IDENTITY_VERSION

    def __post_init__(self) -> None:
        identity_version = int(self.identity_version)
        if identity_version not in SUPPORTED_RETRO_BLEU_BIGRAM_IDENTITY_VERSIONS:
            raise ValueError("unsupported Retro-BLEU-like bigram identity version")
        query_cgr_keys = tuple(str(key) for key in self.query_cgr_keys)
        rules = tuple(
            _json_copy(rule, label="bigram rule graph") for rule in self.rules
        )
        if identity_version == 2:
            if len(query_cgr_keys) != 2 or any(not key for key in query_cgr_keys):
                raise ValueError(
                    "a v2 bigram identity requires two non-empty query_cgr_keys"
                )
            if rules:
                raise ValueError("v2 bigram identities do not store rule graphs")
            expected_key = _query_key_bigram_lookup_key(query_cgr_keys)
        else:
            from route_inspector.rules.graph import graph_coarse_signature

            if len(rules) != 2 or not all(isinstance(rule, dict) for rule in rules):
                raise ValueError("a v1 bigram identity requires two rule graphs")
            for rule in rules:
                graph_coarse_signature(rule)
            if any(query_cgr_keys):
                raise ValueError("v1 bigram identities do not store query_cgr_keys")
            expected_key = _legacy_bigram_lookup_key(rules)
        if self.lookup_key and str(self.lookup_key) != expected_key:
            raise ValueError("bigram lookup key disagrees with its identity payload")
        object.__setattr__(self, "query_cgr_keys", query_cgr_keys)
        object.__setattr__(self, "rules", rules)
        object.__setattr__(self, "lookup_key", expected_key)
        object.__setattr__(self, "identity_version", identity_version)

    @classmethod
    def from_query_cgr_keys(
        cls,
        query_cgr_keys: Iterable[str],
    ) -> "RetroBleuBigramIdentity":
        keys = tuple(str(key) for key in query_cgr_keys)
        if len(keys) != 2:
            raise ValueError("a bigram identity requires exactly two keys")
        return cls(query_cgr_keys=(keys[0], keys[1]))

    @classmethod
    def from_occurrence(
        cls,
        occurrence: RetroBleuBigramOccurrence,
        *,
        identity_version: int = RETRO_BLEU_BIGRAM_IDENTITY_VERSION,
    ) -> "RetroBleuBigramIdentity":
        if not isinstance(occurrence, RetroBleuBigramOccurrence):
            raise TypeError("occurrence must be RetroBleuBigramOccurrence")
        if int(identity_version) == 2:
            return cls.from_query_cgr_keys(
                step.query_cgr_key for step in occurrence.steps
            )
        return cls.from_rule_smarts(
            occurrence.rule_smarts,
            identity_version=identity_version,
        )

    @classmethod
    def from_rule_smarts(
        cls,
        rules: Iterable[str],
        *,
        identity_version: int = RETRO_BLEU_BIGRAM_IDENTITY_VERSION,
    ) -> "RetroBleuBigramIdentity":
        normalized = tuple(str(rule) for rule in rules)
        if len(normalized) != 2:
            raise ValueError("a bigram identity requires exactly two rules")
        if int(identity_version) == 2:
            from route_inspector.rules.identity import rule_querycgr_identity

            keys = tuple(rule_querycgr_identity(rule) for rule in normalized)
            if any(key.startswith("unparsed_smarts:") for key in keys):
                raise ValueError(
                    "bigram rule SMARTS cannot be parsed into complete query_cgr_keys"
                )
            return cls.from_query_cgr_keys(keys)
        if int(identity_version) != 1:
            raise ValueError("unsupported Retro-BLEU-like bigram identity version")
        from route_inspector.rules.graph import rule_smarts_to_graph

        return cls(
            query_cgr_keys=("", ""),
            rules=(
                rule_smarts_to_graph(normalized[0]),
                rule_smarts_to_graph(normalized[1]),
            ),
            identity_version=1,
        )

    def equivalent_to(self, other: object) -> bool:
        if not isinstance(other, RetroBleuBigramIdentity):
            return False
        if (
            self.identity_version != other.identity_version
            or self.lookup_key != other.lookup_key
        ):
            return False
        if self.identity_version == 2:
            return self.query_cgr_keys == other.query_cgr_keys
        from route_inspector.rules.graph import (
            labelled_graphs_are_isomorphic,
        )

        return all(
            labelled_graphs_are_isomorphic(left, right)
            for left, right in zip(self.rules, other.rules)
        )

    def to_dict(self) -> dict[str, Any]:
        record = {
            "identity_version": self.identity_version,
            "lookup_key": self.lookup_key,
            "family": "retro_bleu_like_bigram",
        }
        if self.identity_version == 2:
            record["query_cgr_keys"] = list(self.query_cgr_keys)
        else:
            record["rules"] = [
                _json_copy(rule, label="bigram rule graph") for rule in self.rules
            ]
        return record

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RetroBleuBigramIdentity":
        if value.get("family") != "retro_bleu_like_bigram":
            raise ValueError("invalid Retro-BLEU-like bigram identity family")
        identity_version = int(value.get("identity_version", -1))
        if identity_version == 2:
            raw_keys = value.get("query_cgr_keys")
            if not isinstance(raw_keys, list) or len(raw_keys) != 2:
                raise ValueError("v2 bigram identity keys must be a two-item array")
            return cls(
                query_cgr_keys=(str(raw_keys[0]), str(raw_keys[1])),
                lookup_key=str(value.get("lookup_key") or ""),
                identity_version=2,
            )
        raw_rules = value.get("rules")
        if not isinstance(raw_rules, list) or len(raw_rules) != 2:
            raise ValueError("v1 bigram identity rules must be a two-item array")
        return cls(
            query_cgr_keys=("", ""),
            rules=(raw_rules[0], raw_rules[1]),
            lookup_key=str(value.get("lookup_key") or ""),
            identity_version=identity_version,
        )


def _reference_occurrence_id(
    route: ReferenceRouteKey,
    native_occurrence_id: str,
) -> str:
    payload = {
        # The wrapper schema changed in v2, but occurrence IDs remain stable.
        "schema_version": 1,
        "route": route.to_dict(),
        "native_occurrence_id": str(native_occurrence_id),
    }
    digest = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
    return f"reference_bigram_o_{digest}"


@dataclass(frozen=True)
class ReferenceBigramOccurrence:
    """One native bigram plus its Reference-route cohort membership."""

    identity: RetroBleuBigramIdentity
    occurrence: RetroBleuBigramOccurrence
    route: ReferenceRouteKey
    route_has_rrseq_cons: bool
    route_has_rrseq_gap: bool
    schema_version: int = REFERENCE_BIGRAM_OCCURRENCE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        schema_version = int(self.schema_version)
        if schema_version not in SUPPORTED_REFERENCE_BIGRAM_OCCURRENCE_SCHEMA_VERSIONS:
            raise ValueError("unsupported Reference bigram occurrence schema version")
        if not isinstance(self.identity, RetroBleuBigramIdentity):
            raise TypeError("identity must be RetroBleuBigramIdentity")
        if schema_version != self.identity.identity_version:
            raise ValueError("bigram wrapper and identity versions must agree")
        if not isinstance(self.occurrence, RetroBleuBigramOccurrence):
            raise TypeError("occurrence must be RetroBleuBigramOccurrence")
        if not isinstance(self.route, ReferenceRouteKey):
            raise TypeError("route must be ReferenceRouteKey")
        native_route = {
            "dataset_id": self.occurrence.dataset_id,
            "source_identity": self.occurrence.source_identity,
            "route_id": self.occurrence.route_id,
        }
        if native_route != self.route.to_dict():
            raise ValueError("native bigram provenance differs from Reference route")
        expected_identity = RetroBleuBigramIdentity.from_occurrence(
            self.occurrence,
            identity_version=self.identity.identity_version,
        )
        if not expected_identity.equivalent_to(self.identity):
            raise ValueError("bigram identity differs from native occurrence rules")

    @property
    def reference_occurrence_id(self) -> str:
        return _reference_occurrence_id(self.route, self.occurrence.occurrence_id)

    @property
    def route_without_rrseq(self) -> bool:
        return not self.route_has_rrseq_cons and not self.route_has_rrseq_gap

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "reference_occurrence_id": self.reference_occurrence_id,
            "identity": self.identity.to_dict(),
            "occurrence": self.occurrence.to_dict(),
            "route": self.route.to_dict(),
            "route_has_rrseq_cons": self.route_has_rrseq_cons,
            "route_has_rrseq_gap": self.route_has_rrseq_gap,
            "route_without_rrseq": self.route_without_rrseq,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ReferenceBigramOccurrence":
        result = cls(
            identity=RetroBleuBigramIdentity.from_dict(value["identity"]),
            occurrence=RetroBleuBigramOccurrence.from_dict(value["occurrence"]),
            route=ReferenceRouteKey.from_dict(value["route"]),
            route_has_rrseq_cons=bool(value["route_has_rrseq_cons"]),
            route_has_rrseq_gap=bool(value["route_has_rrseq_gap"]),
            schema_version=int(value.get("schema_version", -1)),
        )
        if (
            str(value.get("reference_occurrence_id") or "")
            != result.reference_occurrence_id
        ):
            raise ValueError("Reference bigram occurrence ID is inconsistent")
        if (
            "route_without_rrseq" in value
            and bool(value["route_without_rrseq"]) != result.route_without_rrseq
        ):
            raise ValueError("serialized no-RRSeq cohort flag is inconsistent")
        return result


@dataclass(frozen=True)
class RetroBleuBigramLibraryEntry:
    """One exact bigram family with global and no-RRSeq support."""

    entry_id: str
    identity: RetroBleuBigramIdentity
    representative_rule_smarts: tuple[str, str]
    reference_occurrence_ids: tuple[str, ...]
    reference_routes: tuple[ReferenceRouteKey, ...]
    no_rrseq_reference_occurrence_ids: tuple[str, ...]
    no_rrseq_reference_routes: tuple[ReferenceRouteKey, ...]
    representative_occurrence_id: str
    no_rrseq_representative_occurrence_id: str | None
    schema_version: int = REFERENCE_BIGRAM_ENTRY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        schema_version = int(self.schema_version)
        if schema_version not in SUPPORTED_REFERENCE_BIGRAM_ENTRY_SCHEMA_VERSIONS:
            raise ValueError("unsupported Reference bigram entry schema version")
        if not isinstance(self.identity, RetroBleuBigramIdentity):
            raise TypeError("identity must be RetroBleuBigramIdentity")
        if schema_version != self.identity.identity_version:
            raise ValueError("bigram entry and identity versions must agree")
        if not str(self.entry_id):
            raise ValueError("bigram entry requires entry_id")
        representative = tuple(str(rule) for rule in self.representative_rule_smarts)
        if len(representative) != 2:
            raise ValueError("representative bigram requires exactly two rules")
        if self.identity.identity_version == 1 and not (
            RetroBleuBigramIdentity.from_rule_smarts(
                representative,
                identity_version=1,
            ).equivalent_to(self.identity)
        ):
            raise ValueError("representative rules differ from bigram identity")
        occurrence_ids = tuple(
            sorted(str(item) for item in self.reference_occurrence_ids)
        )
        routes = tuple(sorted(self.reference_routes))
        no_rrseq_ids = tuple(
            sorted(str(item) for item in self.no_rrseq_reference_occurrence_ids)
        )
        no_rrseq_routes = tuple(sorted(self.no_rrseq_reference_routes))
        if not occurrence_ids or not routes:
            raise ValueError("bigram entry requires occurrence and route support")
        if len(occurrence_ids) != len(set(occurrence_ids)):
            raise ValueError("bigram entry occurrence IDs must be unique")
        if len(routes) != len(set(routes)):
            raise ValueError("bigram entry route keys must be unique")
        if not set(no_rrseq_ids).issubset(occurrence_ids):
            raise ValueError("no-RRSeq occurrence support must be a global subset")
        if not set(no_rrseq_routes).issubset(routes):
            raise ValueError("no-RRSeq route support must be a global subset")
        if self.representative_occurrence_id not in occurrence_ids:
            raise ValueError("representative occurrence must belong to the entry")
        if no_rrseq_ids:
            if self.no_rrseq_representative_occurrence_id not in no_rrseq_ids:
                raise ValueError("no-RRSeq representative must belong to its cohort")
        elif self.no_rrseq_representative_occurrence_id is not None:
            raise ValueError("empty no-RRSeq support cannot have a representative")
        object.__setattr__(self, "entry_id", str(self.entry_id))
        object.__setattr__(self, "representative_rule_smarts", representative)
        object.__setattr__(self, "reference_occurrence_ids", occurrence_ids)
        object.__setattr__(self, "reference_routes", routes)
        object.__setattr__(
            self,
            "no_rrseq_reference_occurrence_ids",
            no_rrseq_ids,
        )
        object.__setattr__(self, "no_rrseq_reference_routes", no_rrseq_routes)

    @property
    def occurrence_count(self) -> int:
        return len(self.reference_occurrence_ids)

    @property
    def route_count(self) -> int:
        return len(self.reference_routes)

    @property
    def no_rrseq_occurrence_count(self) -> int:
        return len(self.no_rrseq_reference_occurrence_ids)

    @property
    def no_rrseq_route_count(self) -> int:
        return len(self.no_rrseq_reference_routes)

    def support(self) -> dict[str, Any]:
        return {
            "all_reference": {
                "occurrence_count": self.occurrence_count,
                "route_count": self.route_count,
                "representative_occurrence_id": self.representative_occurrence_id,
                "reference_routes": [
                    route.to_dict() for route in self.reference_routes
                ],
            },
            "reference_without_rrseq": {
                "occurrence_count": self.no_rrseq_occurrence_count,
                "route_count": self.no_rrseq_route_count,
                "representative_occurrence_id": (
                    self.no_rrseq_representative_occurrence_id
                ),
                "reference_routes": [
                    route.to_dict() for route in self.no_rrseq_reference_routes
                ],
            },
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "entry_id": self.entry_id,
            "identity": self.identity.to_dict(),
            "representative_rule_smarts": list(self.representative_rule_smarts),
            "reference_occurrence_ids": list(self.reference_occurrence_ids),
            "reference_routes": [route.to_dict() for route in self.reference_routes],
            "no_rrseq_reference_occurrence_ids": list(
                self.no_rrseq_reference_occurrence_ids
            ),
            "no_rrseq_reference_routes": [
                route.to_dict() for route in self.no_rrseq_reference_routes
            ],
            "representative_occurrence_id": self.representative_occurrence_id,
            "no_rrseq_representative_occurrence_id": (
                self.no_rrseq_representative_occurrence_id
            ),
            "support": self.support(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RetroBleuBigramLibraryEntry":
        result = cls(
            entry_id=str(value["entry_id"]),
            identity=RetroBleuBigramIdentity.from_dict(value["identity"]),
            representative_rule_smarts=tuple(value["representative_rule_smarts"]),
            reference_occurrence_ids=tuple(value["reference_occurrence_ids"]),
            reference_routes=tuple(
                ReferenceRouteKey.from_dict(item) for item in value["reference_routes"]
            ),
            no_rrseq_reference_occurrence_ids=tuple(
                value["no_rrseq_reference_occurrence_ids"]
            ),
            no_rrseq_reference_routes=tuple(
                ReferenceRouteKey.from_dict(item)
                for item in value["no_rrseq_reference_routes"]
            ),
            representative_occurrence_id=str(value["representative_occurrence_id"]),
            no_rrseq_representative_occurrence_id=(
                None
                if value.get("no_rrseq_representative_occurrence_id") is None
                else str(value["no_rrseq_representative_occurrence_id"])
            ),
            schema_version=int(value.get("schema_version", -1)),
        )
        if "support" in value and value["support"] != result.support():
            raise ValueError("serialized bigram support is inconsistent")
        return result


def _entry_prefix(lookup_key: str) -> str:
    return lookup_key.replace("retro_bleu_bigram_i_", "retro_bleu_bigram_e_", 1)


class RetroBleuBigramCatalog:
    """Validated in-memory exact-match catalog for optional bigram evidence."""

    def __init__(
        self,
        *,
        entries: Iterable[RetroBleuBigramLibraryEntry],
        occurrences: Iterable[ReferenceBigramOccurrence],
        entry_by_occurrence: Mapping[str, str],
    ) -> None:
        self._entries = tuple(sorted(entries, key=lambda item: item.entry_id))
        identity_versions = {entry.identity.identity_version for entry in self._entries}
        if len(identity_versions) > 1:
            raise ValueError("a bigram catalog cannot mix identity versions")
        self._identity_version = (
            identity_versions.pop()
            if identity_versions
            else RETRO_BLEU_BIGRAM_IDENTITY_VERSION
        )
        self._catalog_schema_version = self._identity_version
        self._identity_configuration = dict(
            RETRO_BLEU_BIGRAM_IDENTITY_CONFIGURATION
            if self._identity_version == RETRO_BLEU_BIGRAM_IDENTITY_VERSION
            else LEGACY_RETRO_BLEU_BIGRAM_IDENTITY_CONFIGURATION
        )
        self._occurrences = tuple(
            sorted(occurrences, key=lambda item: item.reference_occurrence_id)
        )
        self._entry_by_occurrence = dict(entry_by_occurrence)
        self._lookup: dict[tuple[int, str], list[RetroBleuBigramLibraryEntry]] = (
            defaultdict(list)
        )
        for entry in self._entries:
            self._lookup[
                (entry.identity.identity_version, entry.identity.lookup_key)
            ].append(entry)
        occurrence_ids = {
            occurrence.reference_occurrence_id for occurrence in self._occurrences
        }
        if occurrence_ids != set(self._entry_by_occurrence):
            raise ValueError("bigram entry ownership does not cover every occurrence")
        if len(occurrence_ids) != len(self._occurrences):
            raise ValueError("Reference bigram occurrence IDs must be unique")
        if set(self._entry_by_occurrence.values()) != {
            entry.entry_id for entry in self._entries
        }:
            raise ValueError("bigram entry ownership references unknown/empty entries")

    @classmethod
    def from_occurrences(
        cls,
        occurrences: Iterable[ReferenceBigramOccurrence],
    ) -> "RetroBleuBigramCatalog":
        ordered = tuple(
            sorted(occurrences, key=lambda item: item.reference_occurrence_id)
        )
        buckets: dict[
            tuple[int, str],
            list[tuple[RetroBleuBigramIdentity, list[ReferenceBigramOccurrence]]],
        ] = defaultdict(list)
        for occurrence in ordered:
            identity = occurrence.identity
            key = (identity.identity_version, identity.lookup_key)
            for representative, members in buckets[key]:
                if representative.equivalent_to(identity):
                    members.append(occurrence)
                    break
            else:
                buckets[key].append((identity, [occurrence]))

        entries: list[RetroBleuBigramLibraryEntry] = []
        ownership: dict[str, str] = {}
        for key in sorted(buckets):
            components = sorted(
                buckets[key],
                key=lambda item: _exact_identity_certificate(item[0]),
            )
            for ordinal, (identity, members) in enumerate(components):
                entry_id = f"{_entry_prefix(identity.lookup_key)}~{ordinal:04d}"
                occurrence_ids = tuple(
                    member.reference_occurrence_id for member in members
                )
                no_rrseq_members = tuple(
                    member for member in members if member.route_without_rrseq
                )
                representative = min(
                    members,
                    key=lambda item: (
                        "$".join(item.occurrence.rule_smarts),
                        item.reference_occurrence_id,
                    ),
                )
                entry = RetroBleuBigramLibraryEntry(
                    entry_id=entry_id,
                    identity=identity,
                    representative_rule_smarts=representative.occurrence.rule_smarts,
                    reference_occurrence_ids=occurrence_ids,
                    reference_routes=tuple({member.route for member in members}),
                    no_rrseq_reference_occurrence_ids=tuple(
                        member.reference_occurrence_id for member in no_rrseq_members
                    ),
                    no_rrseq_reference_routes=tuple(
                        {member.route for member in no_rrseq_members}
                    ),
                    representative_occurrence_id=representative.reference_occurrence_id,
                    no_rrseq_representative_occurrence_id=(
                        None
                        if not no_rrseq_members
                        else min(
                            member.reference_occurrence_id
                            for member in no_rrseq_members
                        )
                    ),
                    schema_version=identity.identity_version,
                )
                entries.append(entry)
                ownership.update(
                    {
                        reference_occurrence_id: entry_id
                        for reference_occurrence_id in occurrence_ids
                    }
                )
        return cls(
            entries=entries,
            occurrences=ordered,
            entry_by_occurrence=ownership,
        )

    @property
    def identity_version(self) -> int:
        return self._identity_version

    @property
    def catalog_id(self) -> str:
        payload = {
            "catalog_schema_version": self._catalog_schema_version,
            "identity_configuration": self._identity_configuration,
            "entries": [entry.to_dict() for entry in self._entries],
            "occurrence_ownership": [
                [occurrence_id, self._entry_by_occurrence[occurrence_id]]
                for occurrence_id in sorted(self._entry_by_occurrence)
            ],
        }
        digest = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
        return f"retro_bleu_bigram_catalog_{digest}"

    def entries(self) -> tuple[RetroBleuBigramLibraryEntry, ...]:
        return self._entries

    def occurrences(self) -> tuple[ReferenceBigramOccurrence, ...]:
        return self._occurrences

    def entry_id_for_occurrence(self, reference_occurrence_id: str) -> str:
        return self._entry_by_occurrence[str(reference_occurrence_id)]

    def lookup(
        self,
        identity: RetroBleuBigramIdentity,
    ) -> RetroBleuBigramLibraryEntry | None:
        if not isinstance(identity, RetroBleuBigramIdentity):
            raise TypeError("identity must be RetroBleuBigramIdentity")
        candidates = self._lookup.get(
            (identity.identity_version, identity.lookup_key),
            (),
        )
        matches = [
            entry for entry in candidates if entry.identity.equivalent_to(identity)
        ]
        if len(matches) > 1:
            raise RuntimeError("bigram catalog contains duplicate exact identities")
        return matches[0] if matches else None

    def entry_records(self) -> tuple[dict[str, Any], ...]:
        return tuple(entry.to_dict() for entry in self._entries)

    def occurrence_records(self) -> tuple[dict[str, Any], ...]:
        return tuple(
            {
                "entry_id": self.entry_id_for_occurrence(
                    occurrence.reference_occurrence_id
                ),
                "occurrence": occurrence.to_dict(),
            }
            for occurrence in self._occurrences
        )

    def summary(self) -> dict[str, Any]:
        no_rrseq_occurrences = sum(
            occurrence.route_without_rrseq for occurrence in self._occurrences
        )
        return {
            "retro_bleu_bigram_catalog_id": self.catalog_id,
            "retro_bleu_bigram_catalog_schema_version": (self._catalog_schema_version),
            "retro_bleu_bigram_identity_configuration": dict(
                self._identity_configuration
            ),
            "retro_bleu_bigram_identity_count": len(self._entries),
            "retro_bleu_bigram_occurrence_count": len(self._occurrences),
            "no_rrseq_retro_bleu_bigram_identity_count": sum(
                bool(entry.no_rrseq_occurrence_count) for entry in self._entries
            ),
            "no_rrseq_retro_bleu_bigram_occurrence_count": no_rrseq_occurrences,
        }

    def _verification_summary(self, metadata: Mapping[str, Any]) -> dict[str, Any]:
        """Check legacy counters when recorded, without emitting them anew."""

        summary = self.summary()
        legacy_counts = {
            "reference_route_count_with_retro_bleu_bigrams": False,
            "no_rrseq_route_count_with_retro_bleu_bigrams": True,
        }
        for key, no_rrseq_only in legacy_counts.items():
            if key in metadata:
                summary[key] = len(
                    {
                        occurrence.route
                        for occurrence in self.occurrences()
                        if not no_rrseq_only or occurrence.route_without_rrseq
                    }
                )
        return summary

    @classmethod
    def from_records(
        cls,
        *,
        entry_records: Iterable[Mapping[str, Any]],
        occurrence_records: Iterable[Mapping[str, Any]],
        expected_catalog_id: str,
    ) -> "RetroBleuBigramCatalog":
        raw_entries = tuple(entry_records)
        persisted_entries = tuple(
            RetroBleuBigramLibraryEntry.from_dict(item) for item in raw_entries
        )
        if any(
            canonical_json(raw) != canonical_json(entry.to_dict())
            for raw, entry in zip(raw_entries, persisted_entries)
        ):
            raise ValueError("bigram entry records must be complete and canonical")
        if [entry.entry_id for entry in persisted_entries] != sorted(
            entry.entry_id for entry in persisted_entries
        ):
            raise ValueError("bigram entry records are not canonically ordered")
        persisted_ownership: dict[str, str] = {}
        occurrences: list[ReferenceBigramOccurrence] = []
        occurrence_ids: list[str] = []
        for record in occurrence_records:
            occurrence = ReferenceBigramOccurrence.from_dict(record["occurrence"])
            occurrence_id = occurrence.reference_occurrence_id
            if occurrence_id in persisted_ownership:
                raise ValueError("duplicate Reference bigram occurrence record")
            persisted_ownership[occurrence_id] = str(record["entry_id"])
            occurrences.append(occurrence)
            occurrence_ids.append(occurrence_id)
            expected_record = {
                "entry_id": persisted_ownership[occurrence_id],
                "occurrence": occurrence.to_dict(),
            }
            if canonical_json(record) != canonical_json(expected_record):
                raise ValueError(
                    "bigram occurrence records must be complete and canonical"
                )
        if occurrence_ids != sorted(occurrence_ids):
            raise ValueError("bigram occurrence records are not canonically ordered")
        rebuilt = cls.from_occurrences(occurrences)
        if rebuilt.entries() != tuple(
            sorted(persisted_entries, key=lambda item: item.entry_id)
        ):
            raise ValueError("bigram entry records disagree with occurrence provenance")
        if rebuilt._entry_by_occurrence != persisted_ownership:
            raise ValueError("bigram occurrence ownership is inconsistent")
        if rebuilt.catalog_id != str(expected_catalog_id):
            raise ValueError("Retro-BLEU-like bigram catalog ID is inconsistent")
        return rebuilt


class _LazyRetroBleuBigramCatalog(RetroBleuBigramCatalog):
    """Read-only bigram catalog that validates only payloads used by a query."""

    def __init__(
        self,
        *,
        entries_path: Path,
        occurrences_path: Path,
        report_path: Path,
        metadata: Mapping[str, Any],
    ) -> None:
        self._entries_path = Path(entries_path)
        self._occurrences_path = Path(occurrences_path)
        self._report_path = Path(report_path)
        self._metadata = dict(metadata)
        self._offsets_by_lookup: (
            dict[tuple[int, str], tuple[tuple[str, int], ...]] | None
        ) = None
        self._offset_by_entry: dict[str, int] = {}
        self._entry_cache: dict[str, RetroBleuBigramLibraryEntry] = {}
        self._occurrence_cache: tuple[ReferenceBigramOccurrence, ...] | None = None
        self._lazy_entry_by_occurrence: dict[str, str] | None = None

    @property
    def identity_version(self) -> int:
        configuration = self._metadata.get("retro_bleu_bigram_identity_configuration")
        if not isinstance(configuration, Mapping):
            raise ValueError("bigram metadata lacks its identity configuration")
        version = int(configuration.get("identity_version", -1))
        if version not in SUPPORTED_RETRO_BLEU_BIGRAM_IDENTITY_VERSIONS:
            raise ValueError("unsupported persisted bigram identity version")
        return version

    @property
    def catalog_id(self) -> str:
        return str(self._metadata["retro_bleu_bigram_catalog_id"])

    def _ensure_entry_index(self) -> None:
        if self._offsets_by_lookup is not None:
            return
        mutable: dict[tuple[int, str], list[tuple[str, int]]] = defaultdict(list)
        offset_by_entry: dict[str, int] = {}
        with self._report_path.open(encoding="utf-8", newline="") as report_stream:
            rows = csv.DictReader(report_stream, delimiter="\t")
            with self._entries_path.open("rb") as entry_stream:
                for row in rows:
                    offset = entry_stream.tell()
                    if not entry_stream.readline():
                        raise ValueError(
                            "bigram report contains more rows than entries JSONL"
                        )
                    entry_id = str(row["entry_id"])
                    lookup_key = str(row["lookup_key"])
                    mutable[(self.identity_version, lookup_key)].append(
                        (entry_id, offset)
                    )
                    offset_by_entry[entry_id] = offset
                if entry_stream.readline():
                    raise ValueError(
                        "bigram entries JSONL contains more rows than its report"
                    )
        self._offsets_by_lookup = {
            key: tuple(values) for key, values in mutable.items()
        }
        self._offset_by_entry = offset_by_entry

    def _entry_at(self, entry_id: str, offset: int) -> RetroBleuBigramLibraryEntry:
        cached = self._entry_cache.get(entry_id)
        if cached is not None:
            return cached
        with self._entries_path.open("rb") as stream:
            stream.seek(offset)
            encoded = stream.readline()
        try:
            raw_entry = json.loads(encoded)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError(f"invalid bigram entry payload for {entry_id}") from exc
        if not isinstance(raw_entry, Mapping):
            raise ValueError(f"bigram entry payload must be an object: {entry_id}")
        entry = RetroBleuBigramLibraryEntry.from_dict(raw_entry)
        if entry.entry_id != entry_id:
            raise ValueError(
                "bigram report order disagrees with entries JSONL: "
                f"expected {entry_id}, found {entry.entry_id}"
            )
        self._entry_cache[entry_id] = entry
        return entry

    def entries(self) -> tuple[RetroBleuBigramLibraryEntry, ...]:
        self._ensure_entry_index()
        return tuple(
            self._entry_at(entry_id, self._offset_by_entry[entry_id])
            for entry_id in sorted(self._offset_by_entry)
        )

    def _load_occurrences(self) -> None:
        if self._occurrence_cache is not None:
            return
        occurrences: list[ReferenceBigramOccurrence] = []
        ownership: dict[str, str] = {}
        with self._occurrences_path.open(encoding="utf-8") as stream:
            for line_number, line in enumerate(stream, start=1):
                try:
                    record = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(
                        f"invalid bigram occurrence JSON on line {line_number}"
                    ) from exc
                if not isinstance(record, Mapping) or not isinstance(
                    record.get("occurrence"), Mapping
                ):
                    raise ValueError(
                        f"bigram occurrence line {line_number} must contain an object"
                    )
                occurrence = ReferenceBigramOccurrence.from_dict(record["occurrence"])
                occurrences.append(occurrence)
                ownership[occurrence.reference_occurrence_id] = str(
                    record.get("entry_id") or ""
                )
        self._occurrence_cache = tuple(occurrences)
        self._lazy_entry_by_occurrence = ownership

    def occurrences(self) -> tuple[ReferenceBigramOccurrence, ...]:
        self._load_occurrences()
        if self._occurrence_cache is None:
            raise RuntimeError("bigram occurrence cache was not initialized")
        return self._occurrence_cache

    def entry_id_for_occurrence(self, reference_occurrence_id: str) -> str:
        self._load_occurrences()
        if self._lazy_entry_by_occurrence is None:
            raise RuntimeError("bigram occurrence ownership was not initialized")
        return self._lazy_entry_by_occurrence[str(reference_occurrence_id)]

    def lookup(
        self,
        identity: RetroBleuBigramIdentity,
    ) -> RetroBleuBigramLibraryEntry | None:
        if not isinstance(identity, RetroBleuBigramIdentity):
            raise TypeError("identity must be RetroBleuBigramIdentity")
        self._ensure_entry_index()
        if self._offsets_by_lookup is None:
            raise RuntimeError("bigram lookup index was not initialized")
        candidates = tuple(
            self._entry_at(entry_id, offset)
            for entry_id, offset in self._offsets_by_lookup.get(
                (identity.identity_version, identity.lookup_key), ()
            )
        )
        matches = [
            entry for entry in candidates if entry.identity.equivalent_to(identity)
        ]
        if len(matches) > 1:
            raise RuntimeError("bigram catalog contains duplicate exact identities")
        return matches[0] if matches else None

    def entry_records(self) -> tuple[dict[str, Any], ...]:
        return tuple(entry.to_dict() for entry in self.entries())

    def occurrence_records(self) -> tuple[dict[str, Any], ...]:
        return tuple(
            {
                "entry_id": self.entry_id_for_occurrence(
                    occurrence.reference_occurrence_id
                ),
                "occurrence": occurrence.to_dict(),
            }
            for occurrence in self.occurrences()
        )

    def summary(self) -> dict[str, Any]:
        keys = (
            "retro_bleu_bigram_catalog_id",
            "retro_bleu_bigram_catalog_schema_version",
            "retro_bleu_bigram_identity_configuration",
            "retro_bleu_bigram_identity_count",
            "retro_bleu_bigram_occurrence_count",
            "no_rrseq_retro_bleu_bigram_identity_count",
            "no_rrseq_retro_bleu_bigram_occurrence_count",
        )
        return {key: self._metadata[key] for key in keys}


def _update_text_digest(digest: Any, value: str) -> None:
    encoded = str(value).encode("utf-8")
    digest.update(len(encoded).to_bytes(8, "big"))
    digest.update(encoded)


def verify_bigram_catalog_streaming(
    *,
    entries_path: str | Path,
    occurrences_path: str | Path,
    report_path: str | Path,
    metadata: Mapping[str, Any],
) -> None:
    """Fully verify bigram sidecars without materializing their payloads."""

    entries_file = Path(entries_path)
    occurrences_file = Path(occurrences_path)
    report_file = Path(report_path)
    configuration = metadata.get("retro_bleu_bigram_identity_configuration")
    if not isinstance(configuration, Mapping):
        raise ValueError("bigram metadata lacks its identity configuration")
    identity_version = int(configuration.get("identity_version", -1))
    expected_configuration = (
        RETRO_BLEU_BIGRAM_IDENTITY_CONFIGURATION
        if identity_version == RETRO_BLEU_BIGRAM_IDENTITY_VERSION
        else LEGACY_RETRO_BLEU_BIGRAM_IDENTITY_CONFIGURATION
    )
    if dict(configuration) != expected_configuration:
        raise ValueError("persisted bigram identity configuration is unsupported")
    catalog_schema_version = int(
        metadata.get("retro_bleu_bigram_catalog_schema_version", -1)
    )
    if (
        catalog_schema_version
        not in SUPPORTED_RETRO_BLEU_BIGRAM_CATALOG_SCHEMA_VERSIONS
    ):
        raise ValueError("unsupported persisted bigram catalog schema version")
    if catalog_schema_version != identity_version:
        raise ValueError("bigram catalog and identity versions must agree")

    offsets: dict[str, int] = {}
    catalog_digest = hashlib.sha256()
    catalog_digest.update(b'{"catalog_schema_version":')
    catalog_digest.update(str(catalog_schema_version).encode("ascii"))
    catalog_digest.update(b',"entries":[')
    entry_count = 0
    with report_file.open(encoding="utf-8", newline="") as report_stream:
        report_rows = csv.DictReader(report_stream, delimiter="\t")
        with entries_file.open("rb") as entry_stream:
            for row in report_rows:
                offset = entry_stream.tell()
                encoded = entry_stream.readline()
                if not encoded:
                    raise ValueError("bigram report has more rows than entries JSONL")
                try:
                    raw_entry = json.loads(encoded)
                except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                    raise ValueError("invalid bigram entry JSON") from exc
                entry = RetroBleuBigramLibraryEntry.from_dict(raw_entry)
                if canonical_json(raw_entry) != canonical_json(entry.to_dict()):
                    raise ValueError(
                        "bigram entry record is not canonical and complete"
                    )
                expected_report = {
                    "entry_id": entry.entry_id,
                    "lookup_key": entry.identity.lookup_key,
                    "retro_bleu_bigram": "$".join(entry.representative_rule_smarts),
                    "occurrence_count": str(entry.occurrence_count),
                    "route_count": str(entry.route_count),
                    "no_rrseq_occurrence_count": str(entry.no_rrseq_occurrence_count),
                    "no_rrseq_route_count": str(entry.no_rrseq_route_count),
                    "representative_occurrence_id": entry.representative_occurrence_id,
                    "no_rrseq_representative_occurrence_id": (
                        entry.no_rrseq_representative_occurrence_id or ""
                    ),
                    "reference_routes_json": canonical_json(
                        [route.to_dict() for route in entry.reference_routes]
                    ),
                    "no_rrseq_reference_routes_json": canonical_json(
                        [route.to_dict() for route in entry.no_rrseq_reference_routes]
                    ),
                }
                if dict(row) != expected_report:
                    raise ValueError(f"bigram report differs for {entry.entry_id}")
                if entry.identity.identity_version != identity_version:
                    raise ValueError(
                        "bigram entry identity version differs from metadata"
                    )
                if entry.entry_id in offsets:
                    raise ValueError("duplicate bigram entry ID")
                offsets[entry.entry_id] = offset
                if entry_count:
                    catalog_digest.update(b",")
                catalog_digest.update(canonical_json(entry.to_dict()).encode("utf-8"))
                entry_count += 1
            if entry_stream.readline():
                raise ValueError("bigram entries JSONL has more rows than its report")
    catalog_digest.update(b'],"identity_configuration":')
    catalog_digest.update(canonical_json(dict(configuration)).encode("utf-8"))
    catalog_digest.update(b',"occurrence_ownership":[')

    support: dict[str, dict[str, Any]] = {}
    identity_cache: OrderedDict[str, RetroBleuBigramIdentity] = OrderedDict()

    def entry_identity(entry_id: str, stream: Any) -> RetroBleuBigramIdentity:
        cached = identity_cache.get(entry_id)
        if cached is not None:
            identity_cache.move_to_end(entry_id)
            return cached
        try:
            offset = offsets[entry_id]
        except KeyError as exc:
            raise ValueError("bigram occurrence refers to an unknown entry") from exc
        stream.seek(offset)
        entry = RetroBleuBigramLibraryEntry.from_dict(json.loads(stream.readline()))
        identity_cache[entry_id] = entry.identity
        if len(identity_cache) > 64:
            identity_cache.popitem(last=False)
        return entry.identity

    previous_occurrence_id = ""
    occurrence_count = 0
    routes: set[ReferenceRouteKey] = set()
    no_rrseq_routes: set[ReferenceRouteKey] = set()
    no_rrseq_occurrence_count = 0
    with entries_file.open("rb") as entry_stream:
        with occurrences_file.open(encoding="utf-8") as occurrence_stream:
            for line_number, line in enumerate(occurrence_stream, start=1):
                try:
                    record = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(
                        f"invalid bigram occurrence JSON on line {line_number}"
                    ) from exc
                if not isinstance(record, Mapping):
                    raise ValueError("bigram occurrence record must be an object")
                wrapper = ReferenceBigramOccurrence.from_dict(record["occurrence"])
                expected_record = {
                    "entry_id": str(record.get("entry_id") or ""),
                    "occurrence": wrapper.to_dict(),
                }
                if canonical_json(record) != canonical_json(expected_record):
                    raise ValueError("bigram occurrence record is not canonical")
                occurrence_id = wrapper.reference_occurrence_id
                if previous_occurrence_id and occurrence_id <= previous_occurrence_id:
                    raise ValueError("bigram occurrences are not uniquely ordered")
                previous_occurrence_id = occurrence_id
                entry_id = str(record.get("entry_id") or "")
                if not wrapper.identity.equivalent_to(
                    entry_identity(entry_id, entry_stream)
                ):
                    raise ValueError(
                        "bigram occurrence identity differs from its entry"
                    )
                state = support.setdefault(
                    entry_id,
                    {
                        "count": 0,
                        "routes": set(),
                        "no_count": 0,
                        "no_routes": set(),
                        "ids": hashlib.sha256(),
                        "no_ids": hashlib.sha256(),
                        "representative": None,
                        "no_representative": None,
                    },
                )
                state["count"] += 1
                state["routes"].add(wrapper.route)
                _update_text_digest(state["ids"], occurrence_id)
                candidate = ("$".join(wrapper.occurrence.rule_smarts), occurrence_id)
                if (
                    state["representative"] is None
                    or candidate < state["representative"]
                ):
                    state["representative"] = candidate
                if wrapper.route_without_rrseq:
                    state["no_count"] += 1
                    state["no_routes"].add(wrapper.route)
                    _update_text_digest(state["no_ids"], occurrence_id)
                    if (
                        state["no_representative"] is None
                        or occurrence_id < state["no_representative"]
                    ):
                        state["no_representative"] = occurrence_id
                    no_rrseq_occurrence_count += 1
                    no_rrseq_routes.add(wrapper.route)
                routes.add(wrapper.route)
                if occurrence_count:
                    catalog_digest.update(b",")
                catalog_digest.update(
                    canonical_json([occurrence_id, entry_id]).encode("utf-8")
                )
                occurrence_count += 1
    catalog_digest.update(b"]}")

    no_rrseq_identity_count = 0
    with entries_file.open(encoding="utf-8") as stream:
        for line in stream:
            entry = RetroBleuBigramLibraryEntry.from_dict(json.loads(line))
            state = support.get(entry.entry_id)
            if state is None:
                raise ValueError("bigram entry has no occurrence provenance")
            ids_digest = hashlib.sha256()
            for occurrence_id in entry.reference_occurrence_ids:
                _update_text_digest(ids_digest, occurrence_id)
            no_ids_digest = hashlib.sha256()
            for occurrence_id in entry.no_rrseq_reference_occurrence_ids:
                _update_text_digest(no_ids_digest, occurrence_id)
            expected_representative = state["representative"][1]
            if (
                state["count"] != entry.occurrence_count
                or state["routes"] != set(entry.reference_routes)
                or state["ids"].digest() != ids_digest.digest()
                or expected_representative != entry.representative_occurrence_id
                or state["no_count"] != entry.no_rrseq_occurrence_count
                or state["no_routes"] != set(entry.no_rrseq_reference_routes)
                or state["no_ids"].digest() != no_ids_digest.digest()
                or state["no_representative"]
                != entry.no_rrseq_representative_occurrence_id
            ):
                raise ValueError(f"bigram support differs for {entry.entry_id}")
            no_rrseq_identity_count += bool(entry.no_rrseq_occurrence_count)

    observed = {
        "retro_bleu_bigram_catalog_id": (
            f"retro_bleu_bigram_catalog_{catalog_digest.hexdigest()}"
        ),
        "retro_bleu_bigram_catalog_schema_version": catalog_schema_version,
        "retro_bleu_bigram_identity_configuration": dict(configuration),
        "retro_bleu_bigram_identity_count": entry_count,
        "retro_bleu_bigram_occurrence_count": occurrence_count,
        "no_rrseq_retro_bleu_bigram_identity_count": no_rrseq_identity_count,
        "no_rrseq_retro_bleu_bigram_occurrence_count": no_rrseq_occurrence_count,
    }
    # Legacy report-only counters remain verified if an older artifact has them.
    for key, count in (
        ("reference_route_count_with_retro_bleu_bigrams", len(routes)),
        ("no_rrseq_route_count_with_retro_bleu_bigrams", len(no_rrseq_routes)),
    ):
        if key in metadata:
            observed[key] = count
    for key, expected in observed.items():
        if metadata.get(key) != expected:
            raise ValueError(f"manifest Retro-BLEU bigram metadata differs for {key}")


__all__ = [
    "LEGACY_RETRO_BLEU_BIGRAM_IDENTITY_CONFIGURATION",
    "REFERENCE_BIGRAM_ENTRY_SCHEMA_VERSION",
    "REFERENCE_BIGRAM_OCCURRENCE_SCHEMA_VERSION",
    "RETRO_BLEU_BIGRAM_CATALOG_SCHEMA_VERSION",
    "RETRO_BLEU_BIGRAM_IDENTITY_CONFIGURATION",
    "RETRO_BLEU_BIGRAM_IDENTITY_VERSION",
    "SUPPORTED_REFERENCE_BIGRAM_ENTRY_SCHEMA_VERSIONS",
    "SUPPORTED_REFERENCE_BIGRAM_OCCURRENCE_SCHEMA_VERSIONS",
    "SUPPORTED_RETRO_BLEU_BIGRAM_CATALOG_SCHEMA_VERSIONS",
    "SUPPORTED_RETRO_BLEU_BIGRAM_IDENTITY_VERSIONS",
    "ReferenceBigramOccurrence",
    "RetroBleuBigramCatalog",
    "RetroBleuBigramIdentity",
    "RetroBleuBigramLibraryEntry",
    "verify_bigram_catalog_streaming",
]
