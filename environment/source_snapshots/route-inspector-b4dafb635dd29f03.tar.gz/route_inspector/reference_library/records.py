"""Verified Reference-library implementation boundary."""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from route_inspector.reference_library.models import (
    ReferenceRouteKey,
    TacticIdentity,
    TacticOccurrence,
)
from route_inspector.reference_library.profile import (
    canonical_json,
)
from route_inspector.reference_library.storage.contracts import TACTIC_KINDS


def _detached_json(value: Any, *, label: str) -> Any:
    try:
        return json.loads(canonical_json(value))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be JSON-compatible") from exc


def _route_sort_key(route: ReferenceRouteKey) -> tuple[str, str, str]:
    return route.dataset_id, route.source_identity, route.route_id


def _occurrence_sort_key(occurrence: TacticOccurrence) -> str:
    return occurrence.reference_occurrence_id


def _collision_ordinal(entry_id: str) -> int:
    try:
        return int(entry_id.rsplit("~", 1)[1])
    except (IndexError, ValueError) as exc:
        raise ValueError(f"invalid tactic-library entry ID: {entry_id!r}") from exc


@dataclass(frozen=True)
class TacticLibraryEntry:
    """One exact normalized tactic identity plus Reference-corpus support."""

    entry_id: str
    identity: TacticIdentity
    occurrence_count: int
    route_count: int
    reference_routes: tuple[ReferenceRouteKey, ...]
    route_target_smiles: tuple[str, ...]
    motif_target_smiles: tuple[str, ...]
    representative_occurrence_id: str
    annotation_summary: Mapping[str, Any]

    def __post_init__(self) -> None:
        if not self.entry_id:
            raise ValueError("entry_id must not be empty")
        if self.identity.kind not in TACTIC_KINDS:
            raise ValueError(f"unsupported tactic kind: {self.identity.kind!r}")
        if self.occurrence_count < 1:
            raise ValueError("occurrence_count must be positive")
        routes = tuple(sorted(set(self.reference_routes), key=_route_sort_key))
        if routes != self.reference_routes:
            raise ValueError("reference_routes must be sorted and unique")
        if self.route_count != len(routes) or self.route_count < 1:
            raise ValueError("route_count must equal reference_routes length")
        if not self.representative_occurrence_id:
            raise ValueError("representative_occurrence_id must not be empty")
        for field_name, values in (
            ("route_target_smiles", self.route_target_smiles),
            ("motif_target_smiles", self.motif_target_smiles),
        ):
            if tuple(sorted(set(values))) != values:
                raise ValueError(f"{field_name} must be sorted and unique")
        object.__setattr__(
            self,
            "annotation_summary",
            _detached_json(self.annotation_summary, label="annotation_summary"),
        )

    @property
    def kind(self) -> str:
        return self.identity.kind

    @property
    def lookup_key(self) -> str:
        return self.identity.lookup_key

    def to_dict(self) -> dict[str, Any]:
        return {
            "entry_id": self.entry_id,
            "identity": self.identity.to_dict(),
            "occurrence_count": self.occurrence_count,
            "route_count": self.route_count,
            "reference_routes": [route.to_dict() for route in self.reference_routes],
            "route_target_smiles": list(self.route_target_smiles),
            "motif_target_smiles": list(self.motif_target_smiles),
            "representative_occurrence_id": self.representative_occurrence_id,
            "annotation_summary": dict(self.annotation_summary),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TacticLibraryEntry":
        return cls(
            entry_id=str(value["entry_id"]),
            identity=TacticIdentity.from_dict(value["identity"]),
            occurrence_count=int(value["occurrence_count"]),
            route_count=int(value["route_count"]),
            reference_routes=tuple(
                ReferenceRouteKey.from_dict(route)
                for route in value.get("reference_routes", ())
            ),
            route_target_smiles=tuple(
                str(item) for item in value.get("route_target_smiles", ())
            ),
            motif_target_smiles=tuple(
                str(item) for item in value.get("motif_target_smiles", ())
            ),
            representative_occurrence_id=str(value["representative_occurrence_id"]),
            annotation_summary=dict(value.get("annotation_summary") or {}),
        )
