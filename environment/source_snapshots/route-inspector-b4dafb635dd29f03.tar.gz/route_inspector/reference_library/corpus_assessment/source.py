"""Read existing tactic and composite libraries without graph equivalence checks."""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator, Literal, Mapping

from route_inspector.composite_rules.library import (
    CompositeLibraryEntry,
    CompositeLibraryManifest,
)
from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.reference_library.corpus_assessment.identity import (
    AssessmentIdentity,
    bigram_identity,
    composite_identity,
    rrseq_identity,
    rrsubtree_identity,
)
from route_inspector.reference_library.storage.manifest import ReferenceLibraryManifest

Verification = Literal["fast", "full"]


def _numeric_aware(value: str) -> tuple[int, int | str]:
    try:
        return 0, int(value)
    except ValueError:
        return 1, value


def _validate_descriptor(
    root: Path,
    descriptor: Mapping[str, Any],
    *,
    full: bool,
) -> Path:
    path = root / str(descriptor["path"])
    if path.stat().st_size != int(descriptor["size_bytes"]):
        raise ValueError(f"artifact size differs from manifest: {path.name}")
    if full and _sha256_file(path) != str(descriptor["sha256"]):
        raise ValueError(f"artifact digest differs from manifest: {path.name}")
    return path


@dataclass
class ReferenceSource:
    """Fast-verified read-only view of an existing Reference tactic library."""

    root: Path
    manifest: ReferenceLibraryManifest
    corpus: Mapping[str, Any]
    connection: sqlite3.Connection
    bigram_occurrences_path: Path
    bigram_entry_ids: frozenset[str]

    @property
    def dataset_id(self) -> str:
        return str(self.corpus["dataset_id"])

    @property
    def source_identity(self) -> str:
        return str(self.corpus["source_identity"])

    @property
    def source_routes_sha256(self) -> str:
        return str(self.corpus["input_sha256"])

    def close(self) -> None:
        self.connection.close()

    def __enter__(self) -> "ReferenceSource":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


@dataclass
class CompositeSource:
    """Fast-verified read-only view of a certified composite library."""

    root: Path
    manifest: CompositeLibraryManifest
    connection: sqlite3.Connection

    def close(self) -> None:
        self.connection.close()

    def __enter__(self) -> "CompositeSource":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


@dataclass(frozen=True)
class SourceOccurrence:
    """Compact occurrence record used by both construction and assessment."""

    identity: AssessmentIdentity
    occurrence_id: str
    route_id: str
    source_entry_id: str
    source_kind: str
    selected_reaction_node_paths: tuple[tuple[int, ...], ...]
    skipped_reaction_node_paths: tuple[tuple[int, ...], ...]
    native_occurrence_id: str

    def provenance(self) -> dict[str, Any]:
        return {
            "source_entry_id": self.source_entry_id,
            "source_kind": self.source_kind,
            "native_occurrence_id": self.native_occurrence_id,
            "selected_reaction_node_paths": [
                list(path) for path in self.selected_reaction_node_paths
            ],
            "skipped_reaction_node_paths": [
                list(path) for path in self.skipped_reaction_node_paths
            ],
            "motif_length": self.identity.motif_length,
        }


def _paths(value: Any, *, label: str) -> tuple[tuple[int, ...], ...]:
    if value is None:
        return ()
    if not isinstance(value, (list, tuple)):
        raise ValueError(f"{label} must be an array")
    paths: list[tuple[int, ...]] = []
    for raw_path in value:
        if not isinstance(raw_path, (list, tuple)):
            raise ValueError(f"{label} must contain node paths")
        path = tuple(int(index) for index in raw_path)
        if any(index < 0 for index in path):
            raise ValueError(f"{label} cannot contain negative indices")
        paths.append(path)
    return tuple(paths)


def open_reference_source(
    directory: str | Path,
    *,
    verification: Verification = "fast",
) -> ReferenceSource:
    """Open a tactic source without running stable-library isomorphism audits."""

    if verification not in {"fast", "full"}:
        raise ValueError("verification must be 'fast' or 'full'")
    root = Path(directory).expanduser()
    raw = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    if not isinstance(raw, Mapping):
        raise ValueError("Reference manifest must contain an object")
    manifest = ReferenceLibraryManifest.from_dict(raw)
    if len(manifest.reference_corpora) != 1:
        raise ValueError("Experiment B requires one source corpus per library")
    corpus = manifest.reference_corpora[0]
    required = {
        "catalog",
        "retro_bleu_bigram_entries",
        "retro_bleu_bigram_occurrences",
    }
    missing = required.difference(manifest.artifacts)
    if missing:
        raise ValueError(
            "Reference library lacks required Experiment-B artifacts: "
            + ", ".join(sorted(missing))
        )
    full = verification == "full"
    if full:
        for descriptor in manifest.artifacts.values():
            _validate_descriptor(root, descriptor, full=True)
    catalog_path = _validate_descriptor(root, manifest.artifacts["catalog"], full=full)
    bigram_entries_path = _validate_descriptor(
        root, manifest.artifacts["retro_bleu_bigram_entries"], full=full
    )
    bigram_path = _validate_descriptor(
        root,
        manifest.artifacts["retro_bleu_bigram_occurrences"],
        full=full,
    )
    bigram_entry_ids: set[str] = set()
    with bigram_entries_path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            value = json.loads(line)
            entry_id = (
                str(value.get("entry_id") or "") if isinstance(value, Mapping) else ""
            )
            if not entry_id or entry_id in bigram_entry_ids:
                raise ValueError(
                    f"invalid bigram entry ownership at line {line_number}"
                )
            bigram_entry_ids.add(entry_id)
    connection = sqlite3.connect(f"file:{catalog_path.resolve()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    version = int(connection.execute("PRAGMA user_version").fetchone()[0])
    if version != manifest.catalog_schema_version:
        connection.close()
        raise ValueError("Reference catalog schema differs from manifest")
    metadata = {
        str(row["key"]): json.loads(row["value_json"])
        for row in connection.execute("SELECT key, value_json FROM metadata")
    }
    expected = {
        "library_id": manifest.library_id,
        "configuration_fingerprint": manifest.configuration_fingerprint,
        "processing_profile": manifest.processing_profile.to_dict(),
        "entry_count": manifest.statistics["entry_count"],
        "occurrence_count": manifest.statistics["occurrence_count"],
    }
    if metadata != expected:
        connection.close()
        raise ValueError("Reference catalog metadata differs from manifest")
    if full:
        integrity = str(connection.execute("PRAGMA integrity_check").fetchone()[0])
        if integrity != "ok":
            connection.close()
            raise ValueError(f"Reference catalog integrity failed: {integrity}")
    return ReferenceSource(
        root, manifest, corpus, connection, bigram_path, frozenset(bigram_entry_ids)
    )


def open_composite_source(
    directory: str | Path,
    *,
    reference: ReferenceSource,
    verification: Verification = "fast",
) -> CompositeSource:
    """Open and bind a composite source to its exact tactic source library."""

    if verification not in {"fast", "full"}:
        raise ValueError("verification must be 'fast' or 'full'")
    root = Path(directory).expanduser()
    raw = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    if not isinstance(raw, Mapping):
        raise ValueError("composite manifest must contain an object")
    manifest = CompositeLibraryManifest.from_dict(raw)
    if manifest.source_reference_library_id != reference.manifest.library_id:
        raise ValueError("composite library belongs to another Reference library")
    if (
        manifest.source_processing_profile_fingerprint
        != reference.manifest.configuration_fingerprint
    ):
        raise ValueError("composite and tactic processing profiles differ")
    if manifest.source_routes_sha256 != reference.source_routes_sha256:
        raise ValueError("composite and tactic source route digests differ")
    descriptor = manifest.artifacts.get("catalog")
    if not isinstance(descriptor, Mapping):
        raise ValueError("composite library requires catalog.sqlite")
    full = verification == "full"
    if full:
        for artifact in manifest.artifacts.values():
            _validate_descriptor(root, artifact, full=True)
    catalog_path = _validate_descriptor(root, descriptor, full=full)
    connection = sqlite3.connect(f"file:{catalog_path.resolve()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    version = int(connection.execute("PRAGMA user_version").fetchone()[0])
    # Composite schema v1 catalogs predate PRAGMA user_version assignment.
    if version not in {0, manifest.catalog_schema_version}:
        connection.close()
        raise ValueError("composite catalog schema differs from manifest")
    metadata = {
        str(row["key"]): json.loads(row["value_json"])
        for row in connection.execute("SELECT key, value_json FROM metadata")
    }
    expected = {
        "entry_count": manifest.statistics["composite_entry_count"],
        "library_id": manifest.library_id,
        "link_count": manifest.statistics["certified_link_count"],
        "source_reference_library_id": manifest.source_reference_library_id,
    }
    if metadata != expected:
        connection.close()
        raise ValueError("composite catalog metadata differs from manifest")
    if full:
        integrity = str(connection.execute("PRAGMA integrity_check").fetchone()[0])
        if integrity != "ok":
            connection.close()
            raise ValueError(f"composite catalog integrity failed: {integrity}")
    return CompositeSource(root, manifest, connection)


def iter_tactic_occurrences(reference: ReferenceSource) -> Iterator[SourceOccurrence]:
    """Yield validated tactic records and context-bearing CGR-key identities."""

    sql = """
        SELECT o.*, e.tactic_kind AS entry_kind, er.entry_id AS owned_entry_id
        FROM occurrences AS o
        JOIN entries AS e ON e.entry_id = o.entry_id
        LEFT JOIN entry_routes AS er
          ON er.entry_id = o.entry_id
         AND er.dataset_id = o.dataset_id
         AND er.source_identity = o.source_identity
         AND er.route_id = o.route_id
        ORDER BY o.tactic_kind, o.reference_occurrence_id
    """
    for row in reference.connection.execute(sql):
        value = json.loads(row["occurrence_json"])
        if not isinstance(value, Mapping):
            raise ValueError("tactic occurrence JSON must contain an object")
        native = value.get("native_payload")
        route = value.get("route")
        if not isinstance(native, Mapping) or not isinstance(route, Mapping):
            raise ValueError("tactic occurrence lacks native payload or route")
        kind = str(row["tactic_kind"])
        ownership = (
            kind == str(row["entry_kind"])
            and str(row["owned_entry_id"] or "") == str(row["entry_id"])
            and str(row["reference_occurrence_id"])
            == str(value.get("reference_occurrence_id") or "")
            and str(row["native_occurrence_id"])
            == str(value.get("occurrence_id") or "")
            and str(row["dataset_id"]) == str(route.get("dataset_id") or "")
            and str(row["source_identity"]) == str(route.get("source_identity") or "")
            and str(row["route_id"]) == str(route.get("route_id") or "")
        )
        if not ownership:
            raise ValueError(
                f"invalid tactic occurrence ownership: {row['reference_occurrence_id']}"
            )
        if (
            str(row["dataset_id"]) != reference.dataset_id
            or str(row["source_identity"]) != reference.source_identity
        ):
            raise ValueError("tactic occurrence belongs to an unknown corpus")
        if kind.startswith("rrseq_"):
            identity = rrseq_identity(kind, native)
        elif kind.startswith("rrsubtree_"):
            identity = rrsubtree_identity(native)
        else:
            raise ValueError(f"unsupported tactic kind: {kind}")
        yield SourceOccurrence(
            identity=identity,
            occurrence_id=str(row["reference_occurrence_id"]),
            route_id=str(row["route_id"]),
            source_entry_id=str(row["entry_id"]),
            source_kind=kind,
            selected_reaction_node_paths=_paths(
                value.get("selected_reaction_node_paths"), label="selected paths"
            ),
            skipped_reaction_node_paths=_paths(
                value.get("skipped_reaction_node_paths"), label="skipped paths"
            ),
            native_occurrence_id=str(row["native_occurrence_id"]),
        )


def iter_bigram_occurrences(reference: ReferenceSource) -> Iterator[SourceOccurrence]:
    """Yield persisted contiguous bigrams without re-extracting route rules."""

    observed_occurrence_ids: set[str] = set()
    with reference.bigram_occurrences_path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            value = json.loads(line)
            outer = value.get("occurrence") if isinstance(value, Mapping) else None
            native = outer.get("occurrence") if isinstance(outer, Mapping) else None
            route = outer.get("route") if isinstance(outer, Mapping) else None
            if not isinstance(native, Mapping) or not isinstance(route, Mapping):
                raise ValueError(f"invalid bigram occurrence at line {line_number}")
            if (
                str(route.get("dataset_id") or "") != reference.dataset_id
                or str(route.get("source_identity") or "") != reference.source_identity
                or str(route.get("route_id") or "") != str(native.get("route_id") or "")
            ):
                raise ValueError(f"invalid bigram ownership at line {line_number}")
            occurrence_id = str(outer.get("reference_occurrence_id") or "")
            entry_id = str(value.get("entry_id") or "")
            if (
                not occurrence_id
                or occurrence_id in observed_occurrence_ids
                or entry_id not in reference.bigram_entry_ids
            ):
                raise ValueError(
                    f"invalid bigram occurrence ownership at line {line_number}"
                )
            observed_occurrence_ids.add(occurrence_id)
            yield SourceOccurrence(
                identity=bigram_identity(native),
                occurrence_id=occurrence_id,
                route_id=str(route["route_id"]),
                source_entry_id=entry_id,
                source_kind="retro_bleu_bigram",
                selected_reaction_node_paths=_paths(
                    native.get("reaction_node_paths"), label="bigram paths"
                ),
                skipped_reaction_node_paths=(),
                native_occurrence_id=str(native.get("occurrence_id") or ""),
            )


def iter_composite_occurrences(
    reference: ReferenceSource,
    composite: CompositeSource,
) -> Iterator[SourceOccurrence]:
    """Yield every certified decomposition link as one composite occurrence."""

    sql = """
        SELECT l.*, e.entry_json
        FROM links AS l
        JOIN entries AS e ON e.composite_id = l.composite_id
        ORDER BY l.link_id
    """
    identities = {}
    for row in composite.connection.execute(sql):
        composite_id = str(row["composite_id"])
        if composite_id not in identities:
            entry = CompositeLibraryEntry.from_dict(json.loads(row["entry_json"]))
            if entry.identity_version != composite.manifest.library_format_version:
                raise ValueError(
                    "composite entry and manifest identity versions differ"
                )
            identities[composite_id] = composite_identity(
                entry.normalized_rule,
                identity_version=entry.identity_version,
                identity_key=entry.identity_key,
            )
        tactic = reference.connection.execute(
            """
            SELECT occurrence_json, entry_id, dataset_id, source_identity, route_id
            FROM occurrences WHERE reference_occurrence_id = ?
            """,
            (row["reference_occurrence_id"],),
        ).fetchone()
        if tactic is None:
            raise ValueError(
                "composite link references an unknown tactic occurrence: "
                f"{row['reference_occurrence_id']}"
            )
        ownership = (
            str(row["tactic_entry_id"]) == str(tactic["entry_id"])
            and str(row["dataset_id"]) == str(tactic["dataset_id"])
            and str(row["source_identity"]) == str(tactic["source_identity"])
            and str(row["route_id"]) == str(tactic["route_id"])
            and str(row["dataset_id"]) == reference.dataset_id
            and str(row["source_identity"]) == reference.source_identity
        )
        if not ownership:
            raise ValueError(f"invalid composite link ownership: {row['link_id']}")
        value = json.loads(tactic["occurrence_json"])
        yield SourceOccurrence(
            identity=identities[composite_id],
            occurrence_id=str(row["link_id"]),
            route_id=str(row["route_id"]),
            source_entry_id=str(row["composite_id"]),
            source_kind=str(row["kind"]),
            selected_reaction_node_paths=_paths(
                value.get("selected_reaction_node_paths"), label="selected paths"
            ),
            skipped_reaction_node_paths=(),
            native_occurrence_id=str(row["reference_occurrence_id"]),
        )


def iter_all_occurrences(
    reference: ReferenceSource,
    composite: CompositeSource,
) -> Iterator[SourceOccurrence]:
    """Yield all six Experiment-B evidence channels deterministically."""

    yield from iter_tactic_occurrences(reference)
    yield from iter_bigram_occurrences(reference)
    yield from iter_composite_occurrences(reference, composite)


__all__ = [
    "CompositeSource",
    "ReferenceSource",
    "SourceOccurrence",
    "Verification",
    "iter_all_occurrences",
    "iter_bigram_occurrences",
    "iter_composite_occurrences",
    "iter_tactic_occurrences",
    "open_composite_source",
    "open_reference_source",
]
