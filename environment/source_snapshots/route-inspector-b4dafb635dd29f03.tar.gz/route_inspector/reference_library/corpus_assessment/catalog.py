"""Persisted CGR-key precedent catalog for Experiment B."""

from __future__ import annotations

import hashlib
import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, Mapping

from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.reference_library.corpus_assessment.identity import (
    ENTITY_TYPES,
    AssessmentIdentity,
    EntityType,
    canonical_json,
)

REFERENCE_ASSESSMENT_FORMAT_VERSION = 1
REFERENCE_ASSESSMENT_CATALOG_SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE metadata (
    key TEXT PRIMARY KEY,
    value_json TEXT NOT NULL
) WITHOUT ROWID;

CREATE TABLE families (
    family_id TEXT PRIMARY KEY,
    entity_type TEXT NOT NULL,
    identity_sha256 TEXT NOT NULL,
    identity_json TEXT NOT NULL,
    reference_route_support INTEGER NOT NULL CHECK(reference_route_support >= 1),
    reference_occurrence_support INTEGER NOT NULL CHECK(reference_occurrence_support >= 1),
    reference_route_ids_json TEXT NOT NULL,
    representative_occurrence_id TEXT NOT NULL,
    representative_route_id TEXT NOT NULL,
    representative_provenance_json TEXT NOT NULL,
    UNIQUE(entity_type, identity_sha256, identity_json)
) WITHOUT ROWID;

CREATE INDEX idx_families_identity
ON families(entity_type, identity_sha256);
"""


@dataclass(frozen=True)
class ReferenceFamily:
    """One exact key family and its frozen Reference-corpus support."""

    family_id: str
    entity_type: EntityType
    identity_sha256: str
    identity_json: str
    reference_route_support: int
    reference_occurrence_support: int
    reference_route_ids: tuple[str, ...]
    representative_occurrence_id: str
    representative_route_id: str
    representative_provenance: Mapping[str, Any]

    def __post_init__(self) -> None:
        if not self.family_id or not self.representative_occurrence_id:
            raise ValueError("Reference family identifiers must not be empty")
        if self.entity_type not in ENTITY_TYPES:
            raise ValueError(
                f"unsupported Reference family entity: {self.entity_type!r}"
            )
        if len(self.identity_sha256) != 64:
            raise ValueError("identity_sha256 must be a SHA-256 digest")
        if hashlib.sha256(self.identity_json.encode("utf-8")).hexdigest() != (
            self.identity_sha256
        ):
            raise ValueError("identity_sha256 differs from identity_json")
        routes = tuple(sorted({str(route_id) for route_id in self.reference_route_ids}))
        if routes != self.reference_route_ids or any(not value for value in routes):
            raise ValueError("reference_route_ids must be sorted and unique")
        if self.reference_route_support != len(routes):
            raise ValueError("reference route support differs from route IDs")
        if self.reference_occurrence_support < self.reference_route_support:
            raise ValueError("occurrence support cannot be smaller than route support")
        if self.representative_route_id not in routes:
            raise ValueError("representative route is absent from support routes")
        if not isinstance(self.representative_provenance, Mapping):
            raise ValueError("representative provenance must be an object")

    def to_dict(self) -> dict[str, Any]:
        return {
            "family_id": self.family_id,
            "entity_type": self.entity_type,
            "identity_sha256": self.identity_sha256,
            "identity_json": self.identity_json,
            "reference_route_support": self.reference_route_support,
            "reference_occurrence_support": self.reference_occurrence_support,
            "reference_route_ids": list(self.reference_route_ids),
            "representative_occurrence_id": self.representative_occurrence_id,
            "representative_route_id": self.representative_route_id,
            "representative_provenance": json.loads(
                canonical_json(self.representative_provenance)
            ),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ReferenceFamily":
        return cls(
            family_id=str(value["family_id"]),
            entity_type=str(value["entity_type"]),  # type: ignore[arg-type]
            identity_sha256=str(value["identity_sha256"]),
            identity_json=str(value["identity_json"]),
            reference_route_support=int(value["reference_route_support"]),
            reference_occurrence_support=int(value["reference_occurrence_support"]),
            reference_route_ids=tuple(
                str(item) for item in value["reference_route_ids"]
            ),
            representative_occurrence_id=str(value["representative_occurrence_id"]),
            representative_route_id=str(value["representative_route_id"]),
            representative_provenance=dict(value["representative_provenance"]),
        )


class RouteAssessmentReference:
    """Lazy, immutable n1 precedent index for corpus-level assessment."""

    def __init__(
        self,
        root: Path,
        manifest: Mapping[str, Any],
        connection: sqlite3.Connection,
    ) -> None:
        self.root = root
        self.manifest = dict(manifest)
        self._connection = connection
        self._cache: dict[tuple[str, str, str], ReferenceFamily | None] = {}

    @property
    def reference_id(self) -> str:
        return str(self.manifest["reference_assessment_id"])

    @property
    def reference_dataset(self) -> str:
        return str(self.manifest["reference_dataset"])

    @property
    def processing_profile_fingerprint(self) -> str:
        return str(self.manifest["processing_profile_fingerprint"])

    @property
    def source_reference_library_id(self) -> str:
        return str(self.manifest["source_reference_library_id"])

    @property
    def source_composite_library_id(self) -> str:
        return str(self.manifest["source_composite_library_id"])

    def close(self) -> None:
        self._connection.close()

    def __enter__(self) -> "RouteAssessmentReference":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def lookup(self, identity: AssessmentIdentity) -> ReferenceFamily | None:
        """Resolve by digest, then require complete serialized-key equality."""

        cache_key = (
            identity.entity_type,
            identity.identity_sha256,
            identity.identity_json,
        )
        if cache_key in self._cache:
            return self._cache[cache_key]
        rows = self._connection.execute(
            """
            SELECT family_id, entity_type, identity_sha256, identity_json,
                   reference_route_support, reference_occurrence_support,
                   reference_route_ids_json, representative_occurrence_id,
                   representative_route_id, representative_provenance_json
            FROM families
            WHERE entity_type = ? AND identity_sha256 = ?
            ORDER BY family_id
            """,
            (identity.entity_type, identity.identity_sha256),
        )
        match = None
        for row in rows:
            if str(row[3]) != identity.identity_json:
                continue
            match = ReferenceFamily(
                family_id=str(row[0]),
                entity_type=str(row[1]),  # type: ignore[arg-type]
                identity_sha256=str(row[2]),
                identity_json=str(row[3]),
                reference_route_support=int(row[4]),
                reference_occurrence_support=int(row[5]),
                reference_route_ids=tuple(json.loads(row[6])),
                representative_occurrence_id=str(row[7]),
                representative_route_id=str(row[8]),
                representative_provenance=dict(json.loads(row[9])),
            )
            break
        self._cache[cache_key] = match
        return match

    def families(
        self, entity_type: EntityType | None = None
    ) -> tuple[ReferenceFamily, ...]:
        sql = """
            SELECT family_id, entity_type, identity_sha256, identity_json,
                   reference_route_support, reference_occurrence_support,
                   reference_route_ids_json, representative_occurrence_id,
                   representative_route_id, representative_provenance_json
            FROM families
        """
        parameters: tuple[Any, ...] = ()
        if entity_type is not None:
            sql += " WHERE entity_type = ?"
            parameters = (entity_type,)
        sql += " ORDER BY entity_type, family_id"
        return tuple(
            ReferenceFamily(
                family_id=str(row[0]),
                entity_type=str(row[1]),  # type: ignore[arg-type]
                identity_sha256=str(row[2]),
                identity_json=str(row[3]),
                reference_route_support=int(row[4]),
                reference_occurrence_support=int(row[5]),
                reference_route_ids=tuple(json.loads(row[6])),
                representative_occurrence_id=str(row[7]),
                representative_route_id=str(row[8]),
                representative_provenance=dict(json.loads(row[9])),
            )
            for row in self._connection.execute(sql, parameters)
        )

    @classmethod
    def load(
        cls,
        directory: str | Path,
        *,
        verification: Literal["fast", "full"] = "fast",
    ) -> "RouteAssessmentReference":
        root = Path(directory).expanduser()
        manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
        if (
            int(manifest.get("format_version", -1))
            != REFERENCE_ASSESSMENT_FORMAT_VERSION
        ):
            raise ValueError("unsupported route-assessment reference format")
        if verification not in {"fast", "full"}:
            raise ValueError("verification must be 'fast' or 'full'")
        artifacts = manifest.get("artifacts")
        if not isinstance(artifacts, Mapping):
            raise ValueError("route-assessment manifest requires artifacts")
        if int(manifest.get("catalog_schema_version", -1)) != (
            REFERENCE_ASSESSMENT_CATALOG_SCHEMA_VERSION
        ):
            raise ValueError("unsupported route-assessment manifest catalog schema")
        catalog_descriptor = artifacts.get("catalog")
        if not isinstance(catalog_descriptor, Mapping):
            raise ValueError("route-assessment reference requires catalog.sqlite")
        resolved_artifacts: dict[str, Path] = {}
        for name, descriptor in artifacts.items():
            if not isinstance(descriptor, Mapping):
                raise ValueError(f"invalid artifact descriptor: {name}")
            relative = Path(str(descriptor["path"]))
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError(f"artifact path must be library-relative: {relative}")
            path = root / relative
            if path.stat().st_size != int(descriptor["size_bytes"]):
                raise ValueError(f"artifact size differs for {path.name}")
            if verification == "full" and _sha256_file(path) != str(
                descriptor["sha256"]
            ):
                raise ValueError(f"artifact digest differs for {path.name}")
            resolved_artifacts[str(name)] = path
        catalog_path = resolved_artifacts["catalog"]

        connection = sqlite3.connect(
            f"file:{catalog_path.resolve()}?mode=ro",
            uri=True,
        )
        version = int(connection.execute("PRAGMA user_version").fetchone()[0])
        if version != REFERENCE_ASSESSMENT_CATALOG_SCHEMA_VERSION:
            connection.close()
            raise ValueError("unsupported route-assessment catalog schema")
        metadata = {
            str(key): json.loads(value)
            for key, value in connection.execute(
                "SELECT key, value_json FROM metadata ORDER BY key"
            )
        }
        expected = {
            "family_count": int(manifest["statistics"]["family_count"]),
            "reference_assessment_id": str(manifest["reference_assessment_id"]),
            "source_composite_library_id": str(manifest["source_composite_library_id"]),
            "source_reference_library_id": str(manifest["source_reference_library_id"]),
        }
        if metadata != expected:
            connection.close()
            raise ValueError("route-assessment catalog metadata differs from manifest")
        if verification == "full":
            integrity = str(connection.execute("PRAGMA integrity_check").fetchone()[0])
            if integrity != "ok":
                connection.close()
                raise ValueError(
                    f"route-assessment catalog integrity failed: {integrity}"
                )
            jsonl_path = root / str(artifacts["families"]["path"])
            rows = {
                family.family_id: family.to_dict()
                for family in cls(root, manifest, connection).families()
            }
            observed: dict[str, Mapping[str, Any]] = {}
            with jsonl_path.open(encoding="utf-8") as stream:
                for line in stream:
                    value = json.loads(line)
                    family = ReferenceFamily.from_dict(value)
                    if family.family_id in observed:
                        connection.close()
                        raise ValueError("families.jsonl contains duplicate family IDs")
                    observed[family.family_id] = family.to_dict()
            if rows != observed:
                connection.close()
                raise ValueError("families.jsonl differs from catalog.sqlite")
        return cls(root, manifest, connection)


def create_catalog(
    path: Path,
    families: tuple[ReferenceFamily, ...],
    *,
    metadata: Mapping[str, Any],
) -> None:
    """Create one immutable SQLite catalog from deterministic family records."""

    connection = sqlite3.connect(path)
    try:
        connection.executescript(_SCHEMA)
        connection.execute(
            f"PRAGMA user_version = {REFERENCE_ASSESSMENT_CATALOG_SCHEMA_VERSION}"
        )
        connection.executemany(
            "INSERT INTO metadata(key, value_json) VALUES (?, ?)",
            ((key, canonical_json(value)) for key, value in sorted(metadata.items())),
        )
        connection.executemany(
            """
            INSERT INTO families(
                family_id, entity_type, identity_sha256, identity_json,
                reference_route_support, reference_occurrence_support,
                reference_route_ids_json, representative_occurrence_id,
                representative_route_id, representative_provenance_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                (
                    family.family_id,
                    family.entity_type,
                    family.identity_sha256,
                    family.identity_json,
                    family.reference_route_support,
                    family.reference_occurrence_support,
                    canonical_json(list(family.reference_route_ids)),
                    family.representative_occurrence_id,
                    family.representative_route_id,
                    canonical_json(family.representative_provenance),
                )
                for family in families
            ),
        )
        connection.commit()
    finally:
        connection.close()


__all__ = [
    "REFERENCE_ASSESSMENT_CATALOG_SCHEMA_VERSION",
    "REFERENCE_ASSESSMENT_FORMAT_VERSION",
    "ReferenceFamily",
    "RouteAssessmentReference",
    "create_catalog",
]
