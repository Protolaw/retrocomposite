"""CGR-key identities used only by corpus-level Reference assessment.

This module intentionally does not import the Reference-library graph-equivalence
implementation.  Complete serialized SynPlanner ``query_cgr_key`` payloads are
the authoritative comparison values for Experiment B.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Literal, Mapping, TypeAlias

EntityType: TypeAlias = Literal[
    "rrseq_cons",
    "rrseq_gap",
    "rrsubtree_cons",
    "rrsubtree_gap",
    "composite",
    "retro_bleu_bigram",
]

ENTITY_TYPES: tuple[EntityType, ...] = (
    "rrseq_cons",
    "rrseq_gap",
    "rrsubtree_cons",
    "rrsubtree_gap",
    "composite",
    "retro_bleu_bigram",
)
TACTIC_ENTITY_TYPES = ENTITY_TYPES[:4]
CGR_KEY_IDENTITY_VERSION = 1


def canonical_json(value: Any) -> str:
    """Return the deterministic JSON encoding used for exact key equality."""

    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    )


@dataclass(frozen=True)
class AssessmentIdentity:
    """One complete key payload plus a non-authoritative indexed digest."""

    entity_type: EntityType
    identity_json: str
    identity_sha256: str
    motif_length: int | None = None

    @classmethod
    def create(
        cls,
        entity_type: EntityType,
        payload: Mapping[str, Any],
        *,
        motif_length: int | None = None,
    ) -> "AssessmentIdentity":
        if entity_type not in ENTITY_TYPES:
            raise ValueError(f"unsupported assessment entity: {entity_type!r}")
        encoded = canonical_json(payload)
        digest = hashlib.sha256(encoded.encode("utf-8")).hexdigest()
        if motif_length is not None and motif_length < 1:
            raise ValueError("motif_length must be positive")
        return cls(entity_type, encoded, digest, motif_length)


def _required_keys(value: Any, *, field: str) -> tuple[str, ...]:
    if not isinstance(value, (list, tuple)) or isinstance(value, (str, bytes)):
        raise ValueError(f"{field} must be an array")
    if not value or any(not isinstance(item, str) or not item for item in value):
        raise ValueError(f"{field} must contain non-empty query_cgr_keys")
    return tuple(value)


def rrseq_identity(kind: str, native: Mapping[str, Any]) -> AssessmentIdentity:
    """Return an ordered context-bearing RRSeq identity."""

    if kind not in {"rrseq_cons", "rrseq_gap"}:
        raise ValueError("RRSeq identity requires rrseq_cons or rrseq_gap")
    keys = _required_keys(native.get("query_cgr_keys"), field="query_cgr_keys")
    return AssessmentIdentity.create(
        kind,  # type: ignore[arg-type]
        {
            "identity_version": CGR_KEY_IDENTITY_VERSION,
            "family": "rrseq",
            "kind": kind,
            "query_cgr_keys": list(keys),
        },
        motif_length=len(keys),
    )


def _path(value: Any, *, field: str) -> tuple[int, ...]:
    if not isinstance(value, (list, tuple)):
        raise ValueError(f"{field} must be an integer node path")
    try:
        path = tuple(int(index) for index in value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field} must be an integer node path") from exc
    if any(index < 0 for index in path):
        raise ValueError(f"{field} cannot contain negative indices")
    return path


def rrsubtree_identity(native: Mapping[str, Any]) -> AssessmentIdentity:
    """Return a sibling-order-invariant CGR-key/topology tree identity."""

    variant = str(native.get("kind") or "")
    if variant not in {"cons", "gap"}:
        raise ValueError("RRSubtree occurrence requires kind cons or gap")
    entity_type: EntityType = "rrsubtree_cons" if variant == "cons" else "rrsubtree_gap"
    root = _path(native.get("root_reaction_node_path"), field="root path")
    raw_nodes = native.get("nodes")
    raw_edges = native.get("edges")
    if not isinstance(raw_nodes, list) or len(raw_nodes) < 3:
        raise ValueError("RRSubtree identity requires at least three nodes")
    if not isinstance(raw_edges, list) or len(raw_edges) != len(raw_nodes) - 1:
        raise ValueError("RRSubtree identity requires nodes - 1 edges")

    keys_by_path: dict[tuple[int, ...], str] = {}
    for row in raw_nodes:
        if not isinstance(row, Mapping):
            raise ValueError("RRSubtree nodes must be objects")
        path = _path(row.get("reaction_node_path"), field="reaction_node_path")
        key = str(row.get("query_cgr_key") or "")
        if not key:
            raise ValueError("RRSubtree nodes require query_cgr_key")
        if path in keys_by_path:
            raise ValueError("RRSubtree node paths must be unique")
        keys_by_path[path] = key
    if root not in keys_by_path:
        raise ValueError("RRSubtree root path does not identify a node")

    children: dict[tuple[int, ...], list[tuple[int, tuple[int, ...]]]] = {
        path: [] for path in keys_by_path
    }
    indegree = {path: 0 for path in keys_by_path}
    has_gap = False
    for row in raw_edges:
        if not isinstance(row, Mapping):
            raise ValueError("RRSubtree edges must be objects")
        parent = _path(
            row.get("parent_reaction_node_path"), field="parent reaction path"
        )
        child = _path(row.get("child_reaction_node_path"), field="child reaction path")
        if parent not in keys_by_path or child not in keys_by_path:
            raise ValueError("RRSubtree edge references an unknown node")
        skipped_paths = row.get("skipped_reaction_node_paths", ())
        if not isinstance(skipped_paths, (list, tuple)):
            raise ValueError("skipped_reaction_node_paths must be an array")
        skipped_count = len(skipped_paths)
        has_gap = has_gap or skipped_count > 0
        children[parent].append((skipped_count, child))
        indegree[child] += 1
    if indegree[root] != 0 or any(
        degree != 1 for path, degree in indegree.items() if path != root
    ):
        raise ValueError("RRSubtree nodes must form one rooted tree")
    if len(children[root]) < 2:
        raise ValueError("RRSubtree identity requires two root branches")
    if variant == "cons" and has_gap:
        raise ValueError("RRSubtree_cons cannot contain skipped reactions")
    if variant == "gap" and not has_gap:
        raise ValueError("RRSubtree_gap requires a skipped reaction")

    active: set[tuple[int, ...]] = set()
    visited: set[tuple[int, ...]] = set()

    def visit(path: tuple[int, ...]) -> dict[str, Any]:
        if path in active:
            raise ValueError("RRSubtree identity contains a cycle")
        active.add(path)
        visited.add(path)
        branch_rows = [
            {
                "skipped_reaction_count": skipped,
                "child": visit(child),
            }
            for skipped, child in children[path]
        ]
        branch_rows.sort(key=canonical_json)
        active.remove(path)
        return {
            "query_cgr_key": keys_by_path[path],
            "children": branch_rows,
        }

    tree = visit(root)
    if visited != set(keys_by_path):
        raise ValueError("RRSubtree identity contains unreachable nodes")
    return AssessmentIdentity.create(
        entity_type,
        {
            "identity_version": CGR_KEY_IDENTITY_VERSION,
            "family": "rrsubtree",
            "kind": entity_type,
            "subtree": tree,
        },
        motif_length=len(keys_by_path),
    )


def bigram_identity(native: Mapping[str, Any]) -> AssessmentIdentity:
    """Return the ordered two-step context-bearing bigram identity."""

    steps = native.get("steps")
    if not isinstance(steps, list) or len(steps) != 2:
        raise ValueError("Retro-BLEU-like bigram requires exactly two steps")
    keys = _required_keys(
        [
            step.get("query_cgr_key") if isinstance(step, Mapping) else None
            for step in steps
        ],
        field="bigram step query_cgr_keys",
    )
    return AssessmentIdentity.create(
        "retro_bleu_bigram",
        {
            "identity_version": CGR_KEY_IDENTITY_VERSION,
            "family": "retro_bleu_like_bigram",
            "query_cgr_keys": list(keys),
        },
        motif_length=2,
    )


def composite_identity(
    normalized_rule: str = "",
    *,
    identity_version: int = 1,
    identity_key: str | None = None,
) -> AssessmentIdentity:
    """Use persisted structural family identity, retaining exact-SMARTS semantics for v1.

    A family representative is presentation only. No key is recomputed and no
    execution certificate is inferred from structural family membership.
    """
    if identity_version in {2, 3}:
        if not isinstance(identity_key, str) or not identity_key:
            raise ValueError(
                "structural composite assessment requires a persisted identity_key"
            )
        payload = json.loads(identity_key)
        if not isinstance(payload, dict) or payload.get("version") != identity_version:
            raise ValueError("invalid persisted composite identity_key version")
        return AssessmentIdentity.create(
            "composite",
            {
                "identity_version": identity_version,
                "family": "certified_composite",
                "identity_key": identity_key,
            },
        )
    if identity_version != 1 or identity_key is not None:
        raise ValueError("unsupported composite assessment identity policy")

    normalized = "".join(str(normalized_rule).split())
    if not normalized or ">>" not in normalized:
        raise ValueError("composite identity requires executable reaction SMARTS")
    return AssessmentIdentity.create(
        "composite",
        {
            "identity_version": CGR_KEY_IDENTITY_VERSION,
            "family": "certified_composite",
            "normalized_rule": normalized,
        },
    )


def composite_identity_contract(version: int) -> str:
    if version == 1:
        return "whitespace-normalized executable SMARTS"
    if version == 2:
        return "persisted structural composite identity_key (version 2)"
    if version == 3:
        return "persisted independent complete query sides identity_key (version 3)"
    raise ValueError("unsupported composite assessment identity version")


def support_bin(reference_route_support: int) -> str:
    """Return the fixed Experiment-B support category."""

    value = int(reference_route_support)
    if value < 0:
        raise ValueError("reference route support cannot be negative")
    if value == 0:
        return "novel"
    if value == 1:
        return "singleton"
    if value <= 3:
        return "low"
    if value <= 10:
        return "moderate"
    if value <= 50:
        return "high"
    return "very_high"


__all__ = [
    "AssessmentIdentity",
    "CGR_KEY_IDENTITY_VERSION",
    "ENTITY_TYPES",
    "EntityType",
    "TACTIC_ENTITY_TYPES",
    "bigram_identity",
    "canonical_json",
    "composite_identity",
    "rrseq_identity",
    "rrsubtree_identity",
    "support_bin",
]
