"""Bounded, read-only browsing of persisted tactics and source-route rosters.

This module owns catalog queries; presentation code never queries SQLite tables.
The supplied library must remain immutable and be used on its owning thread.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from route_inspector.reference_library.catalog import ReferenceTacticLibrary
from route_inspector.reference_library.models import ReferenceRouteKey, TacticOccurrence

KINDS = ("rrseq_cons", "rrseq_gap", "rrsubtree_cons", "rrsubtree_gap")


@dataclass(frozen=True)
class BrowsePage:
    rows: tuple[dict[str, Any], ...]
    total: int
    offset: int
    limit: int


def route_token(route: ReferenceRouteKey) -> str:
    """An unambiguous UI key, including corpus and source identity."""
    return json.dumps(route.to_dict(), sort_keys=True, separators=(",", ":"))


def occurrence_summary(occurrence: TacticOccurrence, entry=None) -> dict[str, Any]:
    return {
        "id": occurrence.reference_occurrence_id,
        "entry_id": entry.entry_id if entry is not None else None,
        "kind": occurrence.identity.kind,
        "known": True if entry is not None else None,
        "size": len(occurrence.selected_reaction_node_paths),
        "selected_paths": [
            "/".join(map(str, p)) for p in occurrence.selected_reaction_node_paths
        ],
        "skipped_paths": [
            "/".join(map(str, p)) for p in occurrence.skipped_reaction_node_paths
        ],
        "route_count": entry.route_count if entry is not None else 0,
        "route": occurrence.route.to_dict(),
    }


def _bounds(offset: int, limit: int) -> None:
    if offset < 0 or not 1 <= limit <= 200:
        raise ValueError("offset must be nonnegative; limit must be between 1 and 200")


def matches_route_search(route_id, target, search, target_search_text=None):
    """Treat numeric input as an exact ID, never a SMILES/map substring."""
    query = search.strip().casefold()
    if query.isdecimal():
        return query == str(route_id).strip().casefold()
    return (
        query in str(route_id).casefold()
        or query in target.casefold()
        or (
            target_search_text is not None
            and query in target_search_text(target).casefold()
        )
    )


def sort_route_rows(rows, sort_by=None, descending=False, target_label=None):
    """Sort complete compact rosters, retaining deterministic source-aware ties."""
    if sort_by is None:
        return rows
    if sort_by not in {
        "dataset_id",
        "route_id",
        "target_unmapped",
        "occurrence_count",
        "unique_tactic_count",
        "reaction_count",
    }:
        raise ValueError("invalid route sort column")

    def route_number(value):
        return (0, int(value)) if value.isascii() and value.isdecimal() else (1, value)

    def value(row):
        if sort_by == "route_id":
            return route_number(row["route_id"])
        if sort_by == "target_unmapped":
            target = row.get("target", "")
            return target_label(target) if target_label else target
        return row.get(sort_by, 0 if sort_by.endswith("count") else "")

    ordered = sorted(
        rows,
        key=lambda row: (
            row.get("dataset_id", ""),
            row.get("source_identity", ""),
            route_number(row["route_id"]),
            row["route_id"],
        ),
    )
    known = [row for row in ordered if value(row) is not None]
    unknown = [row for row in ordered if value(row) is None]
    return sorted(known, key=value, reverse=descending) + unknown


class LibraryBrowser:
    """Pagination and compact summaries without scientific re-extraction."""

    def __init__(self, library: ReferenceTacticLibrary):
        self.library = library
        self._entry_summaries = {}
        self._roster: tuple[dict[str, Any], ...] | None = None
        self._source_targets = {}

    def related(self, entry_id, *, index, direction="extensions", offset=0, limit=20):
        """Exact cores/extensions from a disposable index of this library."""
        _bounds(offset, limit)
        rows = index.relations(entry_id, direction)
        return BrowsePage(
            tuple(rows[offset : offset + limit]), len(rows), offset, limit
        )

    def entries(
        self,
        *,
        kind=KINDS[0],
        minimum_size=0,
        minimum_support=1,
        search="",
        offset=0,
        limit=50,
        sort_by="route_count",
        descending=True,
        activator_filter="all",
        activator_index=None,
    ) -> BrowsePage:
        _bounds(offset, limit)
        from route_inspector.rules.activators import filter_ids

        allowed = filter_ids(activator_filter, activator_index, kind)
        if kind not in KINDS or minimum_size < 0 or minimum_support < 1:
            raise ValueError("invalid tactic filter")
        if sort_by not in {"entry_id", "route_count", "occurrence_count", "size"}:
            raise ValueError("invalid tactic sort column")
        if kind not in self._entry_summaries:
            # The library is immutable for this browser's lifetime. Project just
            # the compact catalogue once per kind: repeated SQLite COUNT/SELECT
            # queries otherwise parse every large representative JSON twice.
            connection = self.library._connection
            if connection is not None:
                size = "json_array_length(o.occurrence_json, '$.selected_reaction_node_paths')"
                occurrence_table = "occurrences"
                if self.library.manifest.library_format_version >= 7:
                    size = "o.rule_count"
                    occurrence_table = "occurrence_summaries"
                summaries = [
                    dict(row)
                    for row in connection.execute(
                        "SELECT e.entry_id, e.tactic_kind AS kind, e.route_count, "
                        f"e.occurrence_count, {size} AS size "
                        f"FROM entries e JOIN {occurrence_table} o ON "
                        "o.reference_occurrence_id = e.representative_occurrence_id "
                        "WHERE e.tactic_kind = ?",
                        (kind,),
                    )
                ]
            else:
                summaries = []
                for entry in self.library.entries(kind):
                    occurrence = self.library.get_occurrence(
                        entry.representative_occurrence_id
                    )
                    summaries.append(
                        dict(
                            entry_id=entry.entry_id,
                            kind=kind,
                            route_count=entry.route_count,
                            occurrence_count=entry.occurrence_count,
                            size=len(occurrence.selected_reaction_node_paths),
                        )
                    )
            self._entry_summaries[kind] = tuple(
                sorted(summaries, key=lambda row: row["entry_id"])
            )
        # Filter the full catalogue before paging. Stable sorting preserves the
        # ascending ID tie-breaker; copies keep callers from mutating the cache.
        rows = [
            row
            for row in self._entry_summaries[kind]
            if row["route_count"] >= minimum_support
            and row["size"] >= minimum_size
            and search in row["entry_id"]
            and (allowed is None or row["entry_id"] in allowed)
        ]
        total = len(rows)
        rows.sort(key=lambda row: row[sort_by], reverse=descending)
        rows = [dict(row) for row in rows[offset : offset + limit]]
        return BrowsePage(tuple(rows), total, offset, limit)

    def _route_roster(self) -> tuple[dict[str, Any], ...]:
        if self._roster is not None:
            return self._roster
        roster: dict[str, dict[str, Any]] = {}

        def ensure(key, target=""):
            token = route_token(key)
            if token not in roster:
                roster[token] = dict(
                    id=token,
                    **key.to_dict(),
                    target=target,
                    occurrence_count=0,
                    unique_tactic_count=0,
                    reaction_count=None,
                    **{kind: 0 for kind in KINDS},
                )
            if target:
                roster[token]["target"] = target
            return roster[token]

        # The manifest, not the occurrence table, includes zero-tactic routes.
        for corpus in self.library.manifest.reference_corpora:
            for route_id in corpus.get("route_ids", ()):
                ensure(
                    ReferenceRouteKey(
                        corpus["dataset_id"], corpus["source_identity"], str(route_id)
                    )
                )
        connection = self.library._connection
        if connection is not None:
            # A verified source already supplies targets for the whole corpus.
            # Avoid parsing every occurrence's potentially large chemistry JSON
            # just to recover a target that will immediately be replaced.
            targets_attached = bool(roster) and all(
                (row["dataset_id"], row["source_identity"]) in self._source_targets
                and row["route_id"]
                in self._source_targets[(row["dataset_id"], row["source_identity"])][0]
                for row in roster.values()
            )
            target_expression = (
                "''"
                if targets_attached
                else "min(json_extract(occurrence_json, '$.route_target_smiles'))"
            )
            records = connection.execute(
                "SELECT dataset_id, source_identity, route_id, tactic_kind, count(*) AS n, "
                f"count(DISTINCT entry_id) AS u, {target_expression} AS target "
                "FROM occurrences NOT INDEXED "
                "GROUP BY dataset_id, source_identity, route_id, tactic_kind"
            )
            for row in records:
                key = ReferenceRouteKey(
                    row["dataset_id"], row["source_identity"], row["route_id"]
                )
                result = ensure(key, row["target"])
                result[row["tactic_kind"]] = row["n"]
                result["occurrence_count"] += row["n"]
                result["unique_tactic_count"] += row["u"]
        else:
            seen: dict[str, set[str]] = {}
            for occurrence in self.library.iter_occurrences():
                result = ensure(occurrence.route, occurrence.route_target_smiles)
                result[occurrence.identity.kind] += 1
                result["occurrence_count"] += 1
                seen.setdefault(result["id"], set()).add(
                    self.library.entry_id_for_occurrence(
                        occurrence.reference_occurrence_id
                    )
                )
            for token, entries in seen.items():
                roster[token]["unique_tactic_count"] = len(entries)
        for row in roster.values():
            self._enrich_route(row)
        self._roster = tuple(
            sorted(
                roster.values(),
                key=lambda row: (
                    row["dataset_id"],
                    row["source_identity"],
                    (0, int(row["route_id"]))
                    if row["route_id"].isdigit()
                    else (1, row["route_id"]),
                ),
            )
        )
        return self._roster

    def set_route_targets(
        self, dataset_id, source_identity, targets, *, reaction_counts=None
    ):
        """Enrich the roster from an independently verified source, including empty routes."""
        self._source_targets[(dataset_id, source_identity)] = (
            dict(targets),
            dict(reaction_counts) if reaction_counts is not None else None,
        )
        if self._roster is not None:
            for row in self._roster:
                self._enrich_route(row)

    def _enrich_route(self, row):
        source = self._source_targets.get((row["dataset_id"], row["source_identity"]))
        if source is not None:
            targets, reaction_counts = source
            row["target"] = targets.get(row["route_id"], row["target"])
            if reaction_counts is not None:
                row["reaction_count"] = reaction_counts.get(row["route_id"])

    def routes(
        self,
        *,
        search="",
        entry_id=None,
        offset=0,
        limit=50,
        target_search_text=None,
        rrseq_cons="any",
        rrseq_gap="any",
        sort_by=None,
        descending=False,
    ) -> BrowsePage:
        """Filter before pagination, optionally including a presentation label.

        The callback augments text search only; stored targets and route keys
        remain unchanged. Without it, existing mapped-target search is preserved.
        RRSeq presence filters are combined with AND, independently of other
        tactic types. ``absent`` includes manifest routes with no occurrences.
        """
        _bounds(offset, limit)
        presence = {"rrseq_cons": rrseq_cons, "rrseq_gap": rrseq_gap}
        if any(
            value not in ("any", "present", "absent") for value in presence.values()
        ):
            raise ValueError("RRSeq presence must be any, present or absent")
        allowed = None
        if entry_id is not None:
            allowed = {
                route_token(key)
                for key in self.library.get_entry(entry_id).reference_routes
            }
        rows = [
            row
            for row in self._route_roster()
            if (allowed is None or row["id"] in allowed)
            and all(
                value == "any" or (row[kind] > 0) == (value == "present")
                for kind, value in presence.items()
            )
            and matches_route_search(
                row["route_id"], row["target"], search, target_search_text
            )
        ]
        rows = sort_route_rows(rows, sort_by, descending, target_search_text)
        page = [dict(row) for row in rows[offset : offset + limit]]
        if entry_id is not None:
            connection = self.library._connection
            if connection is not None:
                counts = {
                    route_token(ReferenceRouteKey(row[0], row[1], row[2])): row[3]
                    for row in connection.execute(
                        "SELECT dataset_id, source_identity, route_id, count(*) "
                        "FROM occurrences WHERE entry_id = ? "
                        "GROUP BY dataset_id, source_identity, route_id",
                        (entry_id,),
                    )
                }
            else:
                counts = {}
                for occurrence in self.library.iter_occurrences(entry_id):
                    token = route_token(occurrence.route)
                    counts[token] = counts.get(token, 0) + 1
            for row in page:
                row["matching_occurrence_count"] = counts.get(row["id"], 0)
        return BrowsePage(tuple(page), len(rows), offset, limit)

    def occurrences(
        self,
        *,
        route: ReferenceRouteKey | None = None,
        entry_id=None,
        offset=0,
        limit=50,
    ) -> BrowsePage:
        _bounds(offset, limit)
        if route is None and entry_id is None:
            raise ValueError("select a route or tactic before loading occurrences")
        connection = self.library._connection
        if connection is not None:
            predicates, params = [], []
            if entry_id is not None:
                self.library.get_entry(entry_id)
                predicates.append("entry_id = ?")
                params.append(entry_id)
            if route is not None:
                for name, value in route.to_dict().items():
                    predicates.append(f"{name} = ?")
                    params.append(value)
            where = " AND ".join(predicates)
            total = connection.execute(
                f"SELECT count(*) FROM occurrences WHERE {where}", params
            ).fetchone()[0]
            records = connection.execute(
                f"SELECT reference_occurrence_id, entry_id FROM occurrences WHERE {where} "
                "ORDER BY tactic_kind, reference_occurrence_id LIMIT ? OFFSET ?",
                (*params, limit, offset),
            )
            items = [
                (self.library.get_occurrence(row[0]), self.library.get_entry(row[1]))
                for row in records
            ]
        else:
            occurrences = list(
                self.library.iter_occurrences(
                    entry_id, **(route.to_dict() if route else {})
                )
            )
            occurrences.sort(key=lambda o: (o.identity.kind, o.reference_occurrence_id))
            total = len(occurrences)
            items = [
                (
                    o,
                    self.library.get_entry(
                        self.library.entry_id_for_occurrence(o.reference_occurrence_id)
                    ),
                )
                for o in occurrences[offset : offset + limit]
            ]
        return BrowsePage(
            tuple(occurrence_summary(o, e) for o, e in items), total, offset, limit
        )
