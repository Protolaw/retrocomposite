"""Counts-only evidence matching for exact generated-route occurrences.

This module deliberately contains no chemical scoring policy.  It joins an exact
generated occurrence to its already-built route context history, queries the
all-corpus reference index at the nested base/local/joint levels, and returns the
supporting provenance unchanged.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

from route_inspector.context.history import (
    RouteContextHistory,
    project_context_history_to_occurrence,
)
from route_inspector.reference_library.context_index import ReferenceIndex
from route_inspector.reference_library.context_index.models import (
    RRSEQ_CONS_KIND,
    RRSEQ_GAP_KIND,
    T1_KIND,
    canonical_json,
)

GENERATED_INSPECTION_SCHEMA_VERSION = 2
_COUNT_UNITS = ("occurrence_count", "route_count", "source_document_count")


def occurrence_identity_keys(
    occurrence: Mapping[str, Any],
    *,
    occurrence_kind: str,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Return ordered analytical and context-bearing identities."""

    if occurrence_kind == T1_KIND:
        base = str(occurrence.get("base_query_cgr_key") or "")
        local = str(
            occurrence.get("query_cgr_key")
            or occurrence.get("local_context_query_cgr_key")
            or ""
        )
        base_keys = (base,) if base else ()
        local_keys = (local,) if local else ()
    elif occurrence_kind in {RRSEQ_CONS_KIND, RRSEQ_GAP_KIND}:
        base_keys = tuple(
            str(value) for value in occurrence.get("base_query_cgr_keys", ()) if value
        )
        local_keys = tuple(
            str(value) for value in occurrence.get("query_cgr_keys", ()) if value
        )
    else:
        raise ValueError(f"unsupported occurrence kind: {occurrence_kind}")
    if not base_keys or not local_keys:
        raise ValueError(
            f"{occurrence_kind} occurrence lacks base or local QueryCGR identity"
        )
    if len(base_keys) != len(local_keys):
        raise ValueError("base and local occurrence identity lengths differ")
    return base_keys, local_keys


def occurrence_joint_tokens(
    projection: Mapping[str, Any],
) -> tuple[str, ...]:
    """Return the occurrence-local normalized FG-history multiset.

    Multiplicity is retained by returning one token per independent lineage.
    Center-intersecting lineages and non-statistical descriptors remain in the
    projection for audit purposes but cannot contribute co-occurrence tokens.
    """

    tokens = []
    for observation in projection.get("functional_group_observations", ()):
        if not isinstance(observation, Mapping):
            continue
        if not bool(observation.get("include_in_context_statistics", False)):
            continue
        # New histories carry a route-independent canonical full-lineage token.
        # The summary token remains readable output; legacy projections retain
        # their former fallback behavior when used outside strict v2 workflows.
        token = str(observation.get("joint_token") or observation.get("token") or "")
        if token:
            tokens.append(token)
    return tuple(sorted(tokens))


def _counts_dict(match: Any | None) -> dict[str, int]:
    if match is None:
        return {unit: 0 for unit in _COUNT_UNITS}
    return {unit: int(getattr(match.counts, unit)) for unit in _COUNT_UNITS}


def _certified_composites_for_every_local_match(
    local_match: Any | None,
) -> tuple[str, ...]:
    """Intersect occurrence-certified composite IDs across all exact matches."""

    if local_match is None or not local_match.provenance:
        return ()
    certified: set[str] | None = None
    for precedent in local_match.provenance:
        current = set(precedent.composite_ids)
        certified = current if certified is None else certified & current
    return tuple(sorted(certified or ()))


def _factorability_evidence(
    occurrence: Mapping[str, Any],
    local_match: Any | None,
) -> dict[str, Any]:
    precedents = () if local_match is None else local_match.provenance
    return {
        "analysis_only": True,
        "generated_has_persistent_net_change": bool(
            occurrence.get("has_persistent_net_change", False)
        ),
        "reference_occurrence_count": len(precedents),
        "reference_factorability_certified_count": sum(
            bool(item.factorability_certified) for item in precedents
        ),
        "reference_factorability_values": sorted(
            {item.factorability for item in precedents if item.factorability}
        ),
        "reference_occurrence_ids": [item.occurrence_id for item in precedents],
    }


def _protection_precedents(
    index: ReferenceIndex,
    *,
    occurrence_kind: str,
    base_keys: Sequence[str],
    local_keys: Sequence[str],
    projection: Mapping[str, Any],
) -> list[dict[str, Any]]:
    # Every reaction is represented by t1 evidence, and executable interval
    # evidence is represented by RRSeq-cons.  RRSeq-gap stays analysis-only and
    # does not create an additional protection decision domain.
    if occurrence_kind == RRSEQ_GAP_KIND:
        return []
    results: list[dict[str, Any]] = []
    rows = projection.get("protection_evidence", ())
    for ordinal, row in enumerate(rows):
        if not isinstance(row, Mapping):
            continue
        state = str(row.get("protection_state") or "unknown")
        if state not in {"protected", "unprotected"}:
            continue
        family_id = str(row.get("family_id") or "")
        if not family_id:
            continue
        pg_type = str(row.get("pg_type") or row.get("protection_group_type") or "")
        site_token = str(row.get("site_token") or "")
        evidence = index.query_protection_precedents(
            base_keys,
            local_keys=local_keys,
            family_id=family_id,
            pg_type=pg_type,
            site_token=site_token,
            occurrence_kind=occurrence_kind,
        )
        results.append(
            {
                "site_ordinal": ordinal,
                "lineage_id": str(row.get("lineage_id") or ""),
                "family_id": family_id,
                "site_token": site_token,
                "generated_protection_state": state,
                "pg_type": pg_type,
                "protection_event_ids": list(
                    row.get("protection_event_ids") or row.get("event_ids") or ()
                ),
                "evidence": evidence.to_dict(),
            }
        )
    return results


def match_generated_occurrence(
    index: ReferenceIndex,
    occurrence: Mapping[str, Any],
    history: RouteContextHistory,
    *,
    occurrence_kind: str,
) -> dict[str, Any]:
    """Match one exact generated occurrence and retain every reference."""

    base_keys, local_keys = occurrence_identity_keys(
        occurrence,
        occurrence_kind=occurrence_kind,
    )
    projection = project_context_history_to_occurrence(history, occurrence)
    joint_tokens = occurrence_joint_tokens(projection)
    evidence = index.query(
        base_keys,
        local_keys=local_keys,
        joint_tokens=joint_tokens,
        occurrence_kind=occurrence_kind,
    )
    certified_composites = (
        _certified_composites_for_every_local_match(evidence.local)
        if occurrence_kind == RRSEQ_CONS_KIND
        else ()
    )
    protection = _protection_precedents(
        index,
        occurrence_kind=occurrence_kind,
        base_keys=base_keys,
        local_keys=local_keys,
        projection=projection,
    )
    result = {
        "schema_version": GENERATED_INSPECTION_SCHEMA_VERSION,
        "occurrence_kind": occurrence_kind,
        "occurrence_id": str(occurrence.get("occurrence_id") or ""),
        "dataset_id": str(occurrence.get("dataset_id") or history.dataset_id),
        "source_identity": str(
            occurrence.get("source_identity") or history.source_identity
        ),
        "route_id": str(occurrence.get("route_id") or history.route_id),
        "base_query_cgr_keys": list(base_keys),
        "local_context_query_cgr_keys": list(local_keys),
        "joint_context_tokens": list(joint_tokens),
        "context_history": projection,
        "evidence": evidence.to_dict(),
        "certified_consecutive_composite_ids": list(certified_composites),
        "analysis_only": occurrence_kind == RRSEQ_GAP_KIND,
        "protection_precedents": protection,
        "generated_occurrence": dict(occurrence),
    }
    if occurrence_kind == RRSEQ_GAP_KIND:
        result["factorability_evidence"] = _factorability_evidence(
            occurrence,
            evidence.local,
        )
    return result


def evidence_summary_row(record: Mapping[str, Any]) -> dict[str, Any]:
    """Flatten one inspection record into its auditable TSV count row."""

    evidence = record["evidence"]
    row: dict[str, Any] = {
        "occurrence_kind": record["occurrence_kind"],
        "occurrence_id": record["occurrence_id"],
        "dataset_id": record["dataset_id"],
        "source_identity": record["source_identity"],
        "route_id": record["route_id"],
        "reaction_node_paths_json": canonical_json(
            record["context_history"].get("reaction_node_paths", ())
        ),
        "base_query_cgr_keys_json": canonical_json(record["base_query_cgr_keys"]),
        "local_context_query_cgr_keys_json": canonical_json(
            record["local_context_query_cgr_keys"]
        ),
        "joint_context_tokens_json": canonical_json(record["joint_context_tokens"]),
        "certified_consecutive_composite_ids_json": canonical_json(
            record["certified_consecutive_composite_ids"]
        ),
        "analysis_only": int(bool(record["analysis_only"])),
        "protection_site_count": len(record["protection_precedents"]),
    }
    for level in ("base", "local", "joint_containment", "joint_exact"):
        match = evidence.get(level)
        counts = (
            {unit: 0 for unit in _COUNT_UNITS} if match is None else match["counts"]
        )
        for unit in _COUNT_UNITS:
            row[f"{level}_{unit}"] = int(counts[unit])
    if record["occurrence_kind"] == RRSEQ_GAP_KIND:
        factorability = record.get("factorability_evidence", {})
        row["factorability_reference_occurrence_count"] = int(
            factorability.get("reference_occurrence_count", 0)
        )
        row["factorability_certified_reference_count"] = int(
            factorability.get("reference_factorability_certified_count", 0)
        )
    else:
        row["factorability_reference_occurrence_count"] = 0
        row["factorability_certified_reference_count"] = 0
    return row


def deterministic_jsonl(records: Iterable[Mapping[str, Any]]) -> str:
    """Serialize inspection records in stable occurrence order."""

    ordered = sorted(
        records,
        key=lambda item: (
            str(item.get("occurrence_kind") or ""),
            str(item.get("occurrence_id") or ""),
        ),
    )
    return "".join(
        json.dumps(
            record,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
        )
        + "\n"
        for record in ordered
    )


__all__ = [
    "GENERATED_INSPECTION_SCHEMA_VERSION",
    "deterministic_jsonl",
    "evidence_summary_row",
    "match_generated_occurrence",
    "occurrence_identity_keys",
    "occurrence_joint_tokens",
]
