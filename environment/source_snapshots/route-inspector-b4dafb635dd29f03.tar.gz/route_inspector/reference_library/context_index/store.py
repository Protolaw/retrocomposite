"""Atomic SQLite reference index and occurrence-local evidence queries."""

from __future__ import annotations

import csv
import json
import os
import sqlite3
import tempfile
from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping, Sequence
from contextlib import ExitStack
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from route_inspector.infrastructure.hashing import sha256_file as _sha256
from route_inspector.infrastructure.publication import (
    atomic_text_path as _atomic_text_path,
)
from route_inspector.infrastructure.publication import publish_files_with_rollback
from route_inspector.reference_library.context_index.models import (
    OCCURRENCE_KINDS,
    REFERENCE_INDEX_SCHEMA_VERSION,
    RRSEQ_CONS_KIND,
    RRSEQ_GAP_KIND,
    T1_KIND,
    CertifiedCompositeLink,
    ProtectionEvidence,
    ReferenceIndexMetadata,
    ReferenceOccurrence,
    SourceRecord,
    canonical_json,
    joint_token_counter,
    joint_token_signature,
    ordered_identity_signature,
)
from route_inspector.reference_library.context_index.readers import (
    iter_composite_certificates,
    iter_reference_occurrences,
    normalize_composite_certificates,
    normalize_reference_occurrences,
)

JointMode = Literal["containment", "exact"]


SCHEMA_SQL = """
CREATE TABLE metadata (
    key TEXT PRIMARY KEY,
    value_json TEXT NOT NULL
) WITHOUT ROWID;

CREATE TABLE occurrences (
    occurrence_id TEXT PRIMARY KEY,
    payload_schema_version INTEGER NOT NULL,
    occurrence_kind TEXT NOT NULL CHECK (
        occurrence_kind IN ('t1', 'rrseq_cons', 'rrseq_gap')
    ),
    dataset_id TEXT NOT NULL,
    source_identity TEXT NOT NULL,
    route_id TEXT NOT NULL,
    route_target_smiles TEXT NOT NULL,
    segment_target_smiles TEXT NOT NULL,
    target_smiles TEXT NOT NULL,
    root_index INTEGER,
    branch_index INTEGER,
    branch_indices_json TEXT NOT NULL,
    start_position INTEGER,
    end_position INTEGER,
    base_signature TEXT NOT NULL,
    local_signature TEXT NOT NULL,
    joint_signature TEXT NOT NULL,
    joint_token_count INTEGER NOT NULL CHECK (joint_token_count >= 0),
    context_history_id TEXT NOT NULL,
    analysis_only INTEGER NOT NULL CHECK (analysis_only IN (0, 1)),
    factorability TEXT NOT NULL,
    factorability_certified INTEGER NOT NULL CHECK (
        factorability_certified IN (0, 1)
    ),
    content_digest TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    CHECK (
        (occurrence_kind = 'rrseq_gap' AND analysis_only = 1)
        OR (occurrence_kind != 'rrseq_gap' AND analysis_only = 0)
    )
) WITHOUT ROWID;

CREATE TABLE identity_keys (
    occurrence_id TEXT NOT NULL REFERENCES occurrences(occurrence_id) ON DELETE CASCADE,
    evidence_level TEXT NOT NULL CHECK (evidence_level IN ('base', 'local')),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    identity_key TEXT NOT NULL,
    PRIMARY KEY (occurrence_id, evidence_level, ordinal)
) WITHOUT ROWID;

CREATE TABLE source_records (
    occurrence_id TEXT NOT NULL REFERENCES occurrences(occurrence_id) ON DELETE CASCADE,
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    raw_source_id TEXT NOT NULL,
    source_record_id TEXT NOT NULL,
    source_document_id TEXT NOT NULL,
    source_id_adapter TEXT NOT NULL,
    PRIMARY KEY (occurrence_id, ordinal)
) WITHOUT ROWID;

CREATE TABLE node_paths (
    occurrence_id TEXT NOT NULL REFERENCES occurrences(occurrence_id) ON DELETE CASCADE,
    path_kind TEXT NOT NULL CHECK (
        path_kind IN ('reaction', 'molecule', 'selected_reaction', 'skipped_reaction')
    ),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    node_path_json TEXT NOT NULL,
    PRIMARY KEY (occurrence_id, path_kind, ordinal)
) WITHOUT ROWID;

CREATE TABLE functional_group_observations (
    occurrence_id TEXT NOT NULL REFERENCES occurrences(occurrence_id) ON DELETE CASCADE,
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    family_id TEXT NOT NULL,
    transition_status TEXT NOT NULL,
    location TEXT NOT NULL,
    token TEXT NOT NULL,
    lineage_id TEXT NOT NULL,
    protection_state TEXT NOT NULL,
    pg_type TEXT NOT NULL,
    raw_pattern TEXT NOT NULL,
    atom_maps_json TEXT NOT NULL,
    include_in_joint_context INTEGER NOT NULL CHECK (
        include_in_joint_context IN (0, 1)
    ),
    payload_json TEXT NOT NULL,
    PRIMARY KEY (occurrence_id, ordinal)
) WITHOUT ROWID;

CREATE TABLE functional_group_transitions (
    occurrence_id TEXT NOT NULL,
    observation_ordinal INTEGER NOT NULL,
    transition_ordinal INTEGER NOT NULL CHECK (transition_ordinal >= 0),
    lineage_id TEXT NOT NULL,
    transition_id TEXT NOT NULL,
    path_position INTEGER,
    reaction_node_path_json TEXT NOT NULL,
    transition_status TEXT NOT NULL,
    before_family_id TEXT NOT NULL,
    after_family_id TEXT NOT NULL,
    before_location_json TEXT NOT NULL,
    after_location_json TEXT NOT NULL,
    protection_transition TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    PRIMARY KEY (occurrence_id, observation_ordinal, transition_ordinal),
    FOREIGN KEY (occurrence_id, observation_ordinal)
        REFERENCES functional_group_observations(occurrence_id, ordinal)
        ON DELETE CASCADE
) WITHOUT ROWID;

CREATE TABLE joint_tokens (
    occurrence_id TEXT NOT NULL REFERENCES occurrences(occurrence_id) ON DELETE CASCADE,
    token TEXT NOT NULL,
    multiplicity INTEGER NOT NULL CHECK (multiplicity > 0),
    PRIMARY KEY (occurrence_id, token)
) WITHOUT ROWID;

CREATE TABLE protection_evidence (
    occurrence_id TEXT NOT NULL REFERENCES occurrences(occurrence_id) ON DELETE CASCADE,
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    lineage_id TEXT NOT NULL,
    site_token TEXT NOT NULL,
    family_id TEXT NOT NULL,
    protection_state TEXT NOT NULL,
    fg_transition_status TEXT NOT NULL,
    protection_transition TEXT NOT NULL,
    pg_type TEXT NOT NULL,
    event_id TEXT NOT NULL,
    start_position INTEGER,
    end_position INTEGER,
    node_paths_json TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    PRIMARY KEY (occurrence_id, ordinal)
) WITHOUT ROWID;

CREATE TABLE protection_events (
    occurrence_id TEXT NOT NULL,
    event_id TEXT NOT NULL,
    lineage_id TEXT NOT NULL,
    evidence_ordinal INTEGER NOT NULL,
    event_schema_version INTEGER NOT NULL CHECK (event_schema_version >= 1),
    pg_type TEXT NOT NULL,
    protection_transition TEXT NOT NULL,
    source_type TEXT NOT NULL,
    trace_status TEXT NOT NULL,
    protected_atom_maps_json TEXT NOT NULL,
    deprotection_node_id TEXT NOT NULL,
    deprotection_reaction_node_path_json TEXT NOT NULL,
    protection_node_id TEXT NOT NULL,
    protection_reaction_node_path_json TEXT NOT NULL,
    protected_precursor_molecule_node_path_json TEXT NOT NULL,
    stock_node_id TEXT NOT NULL,
    stock_molecule_node_path_json TEXT NOT NULL,
    interval_reaction_node_paths_json TEXT NOT NULL,
    protected_molecule_node_paths_json TEXT NOT NULL,
    occurrence_node_paths_json TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    PRIMARY KEY (occurrence_id, event_id, lineage_id),
    FOREIGN KEY (occurrence_id, evidence_ordinal)
        REFERENCES protection_evidence(occurrence_id, ordinal)
        ON DELETE CASCADE
) WITHOUT ROWID;

CREATE TABLE gap_evidence (
    occurrence_id TEXT PRIMARY KEY REFERENCES occurrences(occurrence_id) ON DELETE CASCADE,
    factorability TEXT NOT NULL,
    certified INTEGER NOT NULL CHECK (certified IN (0, 1)),
    evidence_json TEXT NOT NULL
) WITHOUT ROWID;

CREATE TABLE certified_composite_links (
    occurrence_id TEXT NOT NULL REFERENCES occurrences(occurrence_id) ON DELETE CASCADE,
    composite_id TEXT NOT NULL,
    composite_rule TEXT NOT NULL,
    validation_status TEXT NOT NULL CHECK (
        validation_status IN ('validated_unique', 'validated_ambiguous')
    ),
    lineage_certified INTEGER NOT NULL CHECK (lineage_certified = 1),
    payload_json TEXT NOT NULL,
    PRIMARY KEY (occurrence_id, composite_id)
) WITHOUT ROWID;
"""


INDEX_SQL = """
CREATE INDEX idx_occurrences_base
    ON occurrences(base_signature, occurrence_kind, occurrence_id);
CREATE INDEX idx_occurrences_local
    ON occurrences(base_signature, local_signature, occurrence_kind, occurrence_id);
CREATE INDEX idx_occurrences_joint_exact
    ON occurrences(
        base_signature, local_signature, joint_signature,
        occurrence_kind, occurrence_id
    );
CREATE INDEX idx_occurrences_route
    ON occurrences(dataset_id, source_identity, route_id, occurrence_id);
CREATE INDEX idx_identity_key_lookup
    ON identity_keys(evidence_level, identity_key, ordinal, occurrence_id);
CREATE INDEX idx_joint_token_lookup
    ON joint_tokens(token, multiplicity, occurrence_id);
CREATE INDEX idx_source_document_lookup
    ON source_records(source_document_id, occurrence_id);
CREATE INDEX idx_source_record_lookup
    ON source_records(source_record_id, occurrence_id);
CREATE INDEX idx_node_path_lookup
    ON node_paths(path_kind, node_path_json, occurrence_id);
CREATE INDEX idx_fg_family_lookup
    ON functional_group_observations(
        family_id, transition_status, location, occurrence_id
    );
CREATE INDEX idx_fg_transition_lookup
    ON functional_group_transitions(
        transition_status, reaction_node_path_json, occurrence_id
    );
CREATE INDEX idx_protection_lookup
    ON protection_evidence(
        family_id, protection_state, pg_type, site_token, occurrence_id
    );
CREATE INDEX idx_protection_event_lookup
    ON protection_events(event_id, lineage_id, occurrence_id);
CREATE INDEX idx_gap_factorability
    ON gap_evidence(factorability, certified, occurrence_id);
CREATE INDEX idx_certified_composite_lookup
    ON certified_composite_links(composite_id, occurrence_id);
"""


@dataclass(frozen=True)
class EvidenceCounts:
    occurrence_count: int
    route_count: int
    source_document_count: int

    def to_dict(self) -> dict[str, int]:
        return {
            "occurrence_count": self.occurrence_count,
            "route_count": self.route_count,
            "source_document_count": self.source_document_count,
        }


@dataclass(frozen=True)
class OccurrenceProvenance:
    occurrence_id: str
    occurrence_kind: str
    dataset_id: str
    source_identity: str
    route_id: str
    route_target_smiles: str
    segment_target_smiles: str
    target_smiles: str
    root_index: int | None
    branch_index: int | None
    branch_indices: tuple[int, ...]
    start_position: int | None
    end_position: int | None
    base_keys: tuple[str, ...]
    local_keys: tuple[str, ...]
    joint_tokens: tuple[str, ...]
    source_records: tuple[SourceRecord, ...]
    reaction_node_paths: tuple[tuple[int, ...], ...]
    molecule_node_paths: tuple[tuple[int, ...], ...]
    selected_reaction_node_paths: tuple[tuple[int, ...], ...]
    skipped_reaction_node_paths: tuple[tuple[int, ...], ...]
    context_history_id: str
    analysis_only: bool
    factorability: str
    factorability_certified: bool
    protection_evidence: tuple[ProtectionEvidence, ...]
    composite_ids: tuple[str, ...]
    payload: Mapping[str, Any]

    @property
    def source_document_ids(self) -> tuple[str, ...]:
        return tuple(
            sorted(
                {
                    record.source_document_id
                    for record in self.source_records
                    if record.source_document_id
                }
            )
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "occurrence_id": self.occurrence_id,
            "occurrence_kind": self.occurrence_kind,
            "dataset_id": self.dataset_id,
            "source_identity": self.source_identity,
            "route_id": self.route_id,
            "route_target_smiles": self.route_target_smiles,
            "segment_target_smiles": self.segment_target_smiles,
            "target_smiles": self.target_smiles,
            "root_index": self.root_index,
            "branch_index": self.branch_index,
            "branch_indices": list(self.branch_indices),
            "start_position": self.start_position,
            "end_position": self.end_position,
            "base_keys": list(self.base_keys),
            "local_keys": list(self.local_keys),
            "joint_tokens": list(self.joint_tokens),
            "source_records": [record.to_dict() for record in self.source_records],
            "source_document_ids": list(self.source_document_ids),
            "reaction_node_paths": [list(path) for path in self.reaction_node_paths],
            "molecule_node_paths": [list(path) for path in self.molecule_node_paths],
            "selected_reaction_node_paths": [
                list(path) for path in self.selected_reaction_node_paths
            ],
            "skipped_reaction_node_paths": [
                list(path) for path in self.skipped_reaction_node_paths
            ],
            "context_history_id": self.context_history_id,
            "analysis_only": self.analysis_only,
            "factorability": self.factorability,
            "factorability_certified": self.factorability_certified,
            "protection_evidence": [
                item.to_dict() for item in self.protection_evidence
            ],
            "composite_ids": list(self.composite_ids),
            "payload": dict(self.payload),
        }


@dataclass(frozen=True)
class EvidenceMatch:
    evidence_level: str
    match_mode: str
    counts: EvidenceCounts
    provenance: tuple[OccurrenceProvenance, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "evidence_level": self.evidence_level,
            "match_mode": self.match_mode,
            "counts": self.counts.to_dict(),
            "provenance": [item.to_dict() for item in self.provenance],
        }


@dataclass(frozen=True)
class EvidenceQueryResult:
    base: EvidenceMatch
    local: EvidenceMatch | None
    joint_containment: EvidenceMatch | None
    joint_exact: EvidenceMatch | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "base": self.base.to_dict(),
            "local": None if self.local is None else self.local.to_dict(),
            "joint_containment": (
                None
                if self.joint_containment is None
                else self.joint_containment.to_dict()
            ),
            "joint_exact": (
                None if self.joint_exact is None else self.joint_exact.to_dict()
            ),
        }


@dataclass(frozen=True)
class ProtectionPrecedentResult:
    """Counts-only protected and unprotected precedent evidence."""

    family_id: str
    pg_type: str
    site_token: str
    occurrence_kind: str | None
    protected: EvidenceMatch
    unprotected: EvidenceMatch

    def to_dict(self) -> dict[str, Any]:
        return {
            "family_id": self.family_id,
            "pg_type": self.pg_type,
            "site_token": self.site_token,
            "occurrence_kind": self.occurrence_kind,
            "protected": self.protected.to_dict(),
            "unprotected": self.unprotected.to_dict(),
        }


@dataclass(frozen=True)
class ReferenceIndexBuildResult:
    path: Path
    occurrence_count: int
    occurrence_counts_by_kind: Mapping[str, int]
    functional_group_observation_count: int
    functional_group_transition_count: int
    joint_token_count: int
    protection_evidence_count: int
    protection_event_count: int
    certified_composite_link_count: int
    skipped_uncertified_composite_count: int
    database_sha256: str
    export_paths: Mapping[str, Path]

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": str(self.path),
            "occurrence_count": self.occurrence_count,
            "occurrence_counts_by_kind": dict(self.occurrence_counts_by_kind),
            "functional_group_observation_count": self.functional_group_observation_count,
            "functional_group_transition_count": self.functional_group_transition_count,
            "joint_token_count": self.joint_token_count,
            "protection_evidence_count": self.protection_evidence_count,
            "protection_event_count": self.protection_event_count,
            "certified_composite_link_count": self.certified_composite_link_count,
            "skipped_uncertified_composite_count": self.skipped_uncertified_composite_count,
            "database_sha256": self.database_sha256,
            "export_paths": {
                key: str(value) for key, value in self.export_paths.items()
            },
        }


def _chunks(
    values: Sequence[tuple[Any, ...]], size: int
) -> Iterable[Sequence[tuple[Any, ...]]]:
    for start in range(0, len(values), size):
        yield values[start : start + size]


def _executemany_batched(
    connection: sqlite3.Connection,
    sql: str,
    values: Sequence[tuple[Any, ...]],
    *,
    batch_size: int,
) -> None:
    for chunk in _chunks(values, batch_size):
        connection.executemany(sql, chunk)


def _insert_occurrences(
    connection: sqlite3.Connection,
    occurrences: Sequence[ReferenceOccurrence],
    *,
    batch_size: int,
) -> dict[str, int]:
    occurrence_rows: list[tuple[Any, ...]] = []
    identity_rows: list[tuple[Any, ...]] = []
    source_rows: list[tuple[Any, ...]] = []
    path_rows: list[tuple[Any, ...]] = []
    fg_rows: list[tuple[Any, ...]] = []
    fg_transition_rows: list[tuple[Any, ...]] = []
    token_rows: list[tuple[Any, ...]] = []
    protection_rows: list[tuple[Any, ...]] = []
    protection_event_rows: list[tuple[Any, ...]] = []
    gap_rows: list[tuple[Any, ...]] = []

    for occurrence in occurrences:
        tokens = joint_token_counter(occurrence.joint_tokens)
        occurrence_rows.append(
            (
                occurrence.occurrence_id,
                occurrence.payload_schema_version,
                occurrence.occurrence_kind,
                occurrence.dataset_id,
                occurrence.source_identity,
                occurrence.route_id,
                occurrence.route_target_smiles,
                occurrence.segment_target_smiles,
                occurrence.target_smiles,
                occurrence.root_index,
                occurrence.branch_index,
                canonical_json(occurrence.branch_indices),
                occurrence.start_position,
                occurrence.end_position,
                occurrence.base_signature,
                occurrence.local_signature,
                occurrence.joint_signature,
                sum(tokens.values()),
                occurrence.context_history_id,
                int(occurrence.analysis_only),
                occurrence.factorability,
                int(occurrence.factorability_certified),
                occurrence.content_digest(),
                canonical_json(occurrence.payload),
            )
        )
        for level, keys in (
            ("base", occurrence.base_keys),
            ("local", occurrence.local_keys),
        ):
            identity_rows.extend(
                (occurrence.occurrence_id, level, ordinal, key)
                for ordinal, key in enumerate(keys)
            )
        source_rows.extend(
            (
                occurrence.occurrence_id,
                ordinal,
                source.raw_source_id,
                source.source_record_id,
                source.source_document_id,
                source.source_id_adapter,
            )
            for ordinal, source in enumerate(occurrence.source_records)
        )
        for path_kind, paths in (
            ("reaction", occurrence.reaction_node_paths),
            ("molecule", occurrence.molecule_node_paths),
            ("selected_reaction", occurrence.selected_reaction_node_paths),
            ("skipped_reaction", occurrence.skipped_reaction_node_paths),
        ):
            path_rows.extend(
                (occurrence.occurrence_id, path_kind, ordinal, canonical_json(path))
                for ordinal, path in enumerate(paths)
            )
        fg_rows.extend(
            (
                occurrence.occurrence_id,
                ordinal,
                item.family_id,
                item.transition_status,
                item.location,
                item.context_token,
                item.lineage_id,
                item.protection_state,
                item.pg_type,
                item.raw_pattern,
                canonical_json(item.atom_maps),
                int(item.include_in_joint_context),
                canonical_json(item.payload),
            )
            for ordinal, item in enumerate(occurrence.functional_groups)
        )
        for ordinal, item in enumerate(occurrence.functional_groups):
            timeline = item.payload.get("transition_timeline") or ()
            for transition_ordinal, transition in enumerate(timeline):
                if not isinstance(transition, Mapping):
                    continue
                fg_transition_rows.append(
                    (
                        occurrence.occurrence_id,
                        ordinal,
                        transition_ordinal,
                        item.lineage_id,
                        str(transition.get("transition_id") or ""),
                        (
                            None
                            if transition.get("path_position") is None
                            else int(transition["path_position"])
                        ),
                        canonical_json(transition.get("reaction_node_path") or ()),
                        str(transition.get("status") or ""),
                        str(transition.get("before_family_id") or ""),
                        str(transition.get("after_family_id") or ""),
                        canonical_json(
                            transition.get("before_location_detail")
                            if "before_location_detail" in transition
                            else transition.get("before_location")
                        ),
                        canonical_json(
                            transition.get("after_location_detail")
                            if "after_location_detail" in transition
                            else transition.get("after_location")
                        ),
                        str(transition.get("protection_transition") or ""),
                        canonical_json(transition),
                    )
                )
        token_rows.extend(
            (occurrence.occurrence_id, token, multiplicity)
            for token, multiplicity in sorted(tokens.items())
        )
        protection_rows.extend(
            (
                occurrence.occurrence_id,
                ordinal,
                item.lineage_id,
                item.site_token,
                item.family_id,
                item.protection_state,
                item.fg_transition_status,
                item.protection_transition,
                item.pg_type,
                item.event_id,
                item.start_position,
                item.end_position,
                canonical_json(item.node_paths),
                canonical_json(item.payload),
            )
            for ordinal, item in enumerate(occurrence.protection_evidence)
        )
        for ordinal, item in enumerate(occurrence.protection_evidence):
            raw_event_ids = item.payload.get("protection_event_ids") or ()
            if isinstance(raw_event_ids, str):
                raw_event_ids = (raw_event_ids,)
            event_ids = tuple(
                sorted(
                    {
                        event_id
                        for raw_event_id in (*raw_event_ids, item.event_id)
                        for event_id in str(raw_event_id).split("|")
                        if event_id
                    }
                )
            )
            trace_events_by_id = {
                str(event.get("event_id") or ""): dict(event)
                for event in item.payload.get("protection_trace_events") or ()
                if isinstance(event, Mapping) and event.get("event_id")
            }
            for event_id in event_ids:
                trace_event = trace_events_by_id.get(event_id)
                if trace_event is None:
                    # Site-detector IDs remain in protection_evidence. Only
                    # exact mapped tracer records belong in protection_events.
                    continue
                event_payload = trace_event
                event_schema_version = int(trace_event.get("schema_version") or 0)
                if event_schema_version <= 0:
                    raise ValueError(
                        f"protection event {event_id} has no tracer schema version"
                    )
                event_pg_type = str(trace_event.get("pg_type") or "")
                if not event_pg_type:
                    raise ValueError(
                        f"protection event {event_id} has no exact tracer PG type"
                    )
                linked_lineage_id = str(trace_event.get("linked_lineage_id") or "")
                if linked_lineage_id != item.lineage_id:
                    raise ValueError(
                        f"protection event {event_id} lineage differs from "
                        f"occurrence {occurrence.occurrence_id} evidence"
                    )
                source_occurrence_id = str(
                    trace_event.get("source_occurrence_id") or ""
                )
                if (
                    source_occurrence_id
                    and source_occurrence_id != occurrence.occurrence_id
                ):
                    raise ValueError(
                        f"protection event {event_id} occurrence reference differs "
                        f"from {occurrence.occurrence_id}"
                    )
                protection_event_rows.append(
                    (
                        occurrence.occurrence_id,
                        event_id,
                        item.lineage_id,
                        ordinal,
                        event_schema_version,
                        event_pg_type,
                        item.protection_transition,
                        str(event_payload.get("source_type") or ""),
                        str(event_payload.get("trace_status") or ""),
                        canonical_json(
                            event_payload.get(
                                "protected_atom_maps",
                                event_payload.get("protected_atom_ids") or (),
                            )
                        ),
                        str(event_payload.get("deprotection_node_id") or ""),
                        canonical_json(
                            event_payload.get("deprotection_reaction_node_path") or ()
                        ),
                        str(event_payload.get("protection_node_id") or ""),
                        canonical_json(
                            event_payload.get("protection_reaction_node_path") or ()
                        ),
                        canonical_json(
                            event_payload.get("protected_precursor_molecule_node_path")
                            or ()
                        ),
                        str(event_payload.get("stock_node_id") or ""),
                        canonical_json(
                            event_payload.get("stock_molecule_node_path") or ()
                        ),
                        canonical_json(
                            event_payload.get("interval_reaction_node_paths") or ()
                        ),
                        canonical_json(
                            event_payload.get("protected_molecule_node_paths") or ()
                        ),
                        canonical_json(item.node_paths),
                        canonical_json(event_payload),
                    )
                )
        if occurrence.occurrence_kind == RRSEQ_GAP_KIND:
            gap_rows.append(
                (
                    occurrence.occurrence_id,
                    occurrence.factorability,
                    int(occurrence.factorability_certified),
                    canonical_json(occurrence.gap_evidence),
                )
            )

    _executemany_batched(
        connection,
        """INSERT INTO occurrences VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        )""",
        occurrence_rows,
        batch_size=batch_size,
    )
    _executemany_batched(
        connection,
        "INSERT INTO identity_keys VALUES (?, ?, ?, ?)",
        identity_rows,
        batch_size=batch_size,
    )
    _executemany_batched(
        connection,
        "INSERT INTO source_records VALUES (?, ?, ?, ?, ?, ?)",
        source_rows,
        batch_size=batch_size,
    )
    _executemany_batched(
        connection,
        "INSERT INTO node_paths VALUES (?, ?, ?, ?)",
        path_rows,
        batch_size=batch_size,
    )
    _executemany_batched(
        connection,
        "INSERT INTO functional_group_observations VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        fg_rows,
        batch_size=batch_size,
    )
    _executemany_batched(
        connection,
        "INSERT INTO functional_group_transitions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        fg_transition_rows,
        batch_size=batch_size,
    )
    _executemany_batched(
        connection,
        "INSERT INTO joint_tokens VALUES (?, ?, ?)",
        token_rows,
        batch_size=batch_size,
    )
    _executemany_batched(
        connection,
        "INSERT INTO protection_evidence VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        protection_rows,
        batch_size=batch_size,
    )
    _executemany_batched(
        connection,
        """INSERT INTO protection_events VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        )""",
        protection_event_rows,
        batch_size=batch_size,
    )
    _executemany_batched(
        connection,
        "INSERT INTO gap_evidence VALUES (?, ?, ?, ?)",
        gap_rows,
        batch_size=batch_size,
    )
    return {
        "source_records": len(source_rows),
        "node_paths": len(path_rows),
        "functional_group_observations": len(fg_rows),
        "functional_group_transitions": len(fg_transition_rows),
        "joint_token_rows": len(token_rows),
        "joint_token_count": sum(row[2] for row in token_rows),
        "protection_evidence": len(protection_rows),
        "protection_events": len(protection_event_rows),
        "gap_evidence": len(gap_rows),
        "identity_keys": len(identity_rows),
    }


def _certified_links(
    occurrences: Sequence[ReferenceOccurrence],
    certificates: Iterable[CertifiedCompositeLink | Mapping[str, Any]],
) -> tuple[tuple[CertifiedCompositeLink, ...], int]:
    all_records: list[CertifiedCompositeLink | Mapping[str, Any]] = list(certificates)
    all_records.extend(
        link for occurrence in occurrences for link in occurrence.embedded_composites
    )
    normalized = normalize_composite_certificates(all_records)
    by_id = {occurrence.occurrence_id: occurrence for occurrence in occurrences}
    certified: list[CertifiedCompositeLink] = []
    skipped = 0
    for link in normalized:
        if not link.certified:
            skipped += 1
            continue
        occurrence = by_id.get(link.occurrence_id)
        if occurrence is None:
            raise ValueError(
                f"certified composite references unknown occurrence {link.occurrence_id}"
            )
        if occurrence.occurrence_kind != RRSEQ_CONS_KIND or occurrence.analysis_only:
            raise ValueError(
                "certified composites may only link to executable RRseq_cons "
                f"occurrences: {link.occurrence_id} is {occurrence.occurrence_kind}"
            )
        certified.append(link)
    return tuple(certified), skipped


def _insert_certified_links(
    connection: sqlite3.Connection,
    links: Sequence[CertifiedCompositeLink],
    *,
    batch_size: int,
) -> None:
    rows = [
        (
            link.occurrence_id,
            link.composite_id,
            link.composite_rule,
            link.validation_status,
            1,
            canonical_json(link.payload),
        )
        for link in links
    ]
    _executemany_batched(
        connection,
        "INSERT INTO certified_composite_links VALUES (?, ?, ?, ?, ?, ?)",
        rows,
        batch_size=batch_size,
    )


def _validate_database(
    connection: sqlite3.Connection,
    occurrences: Sequence[ReferenceOccurrence],
    child_counts: Mapping[str, int],
    certified_count: int,
) -> None:
    expected = {
        "occurrences": len(occurrences),
        "identity_keys": child_counts["identity_keys"],
        "source_records": child_counts["source_records"],
        "node_paths": child_counts["node_paths"],
        "functional_group_observations": child_counts["functional_group_observations"],
        "functional_group_transitions": child_counts["functional_group_transitions"],
        "joint_tokens": child_counts["joint_token_rows"],
        "protection_evidence": child_counts["protection_evidence"],
        "protection_events": child_counts["protection_events"],
        "gap_evidence": child_counts["gap_evidence"],
        "certified_composite_links": certified_count,
    }
    for table, count in expected.items():
        actual = int(connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
        if actual != count:
            raise RuntimeError(
                f"reference-index count invariant failed for {table}: "
                f"expected={count} actual={actual}"
            )
    token_total = int(
        connection.execute(
            "SELECT COALESCE(SUM(multiplicity), 0) FROM joint_tokens"
        ).fetchone()[0]
    )
    if token_total != child_counts["joint_token_count"]:
        raise RuntimeError(
            "reference-index joint-token multiplicity invariant failed: "
            f"expected={child_counts['joint_token_count']} actual={token_total}"
        )
    identity_total = sum(
        len(occurrence.base_keys) + len(occurrence.local_keys)
        for occurrence in occurrences
    )
    if identity_total != child_counts["identity_keys"]:
        raise RuntimeError("reference-index identity-key accounting is incomplete")
    foreign_keys = connection.execute("PRAGMA foreign_key_check").fetchall()
    if foreign_keys:
        raise RuntimeError(
            f"reference-index foreign-key violations: {foreign_keys[:5]}"
        )
    integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
    if integrity != "ok":
        raise RuntimeError(f"reference-index integrity check failed: {integrity}")


def _write_metadata(
    connection: sqlite3.Connection,
    metadata: ReferenceIndexMetadata,
    occurrences: Sequence[ReferenceOccurrence],
    child_counts: Mapping[str, int],
    certified_count: int,
    skipped_count: int,
) -> None:
    kind_counts = Counter(item.occurrence_kind for item in occurrences)
    values = {
        **metadata.to_dict(),
        "occurrence_count": len(occurrences),
        "occurrence_counts_by_kind": {
            key: kind_counts.get(key, 0) for key in sorted(OCCURRENCE_KINDS)
        },
        "functional_group_observation_count": child_counts[
            "functional_group_observations"
        ],
        "functional_group_transition_count": child_counts[
            "functional_group_transitions"
        ],
        "joint_token_count": child_counts["joint_token_count"],
        "protection_evidence_count": child_counts["protection_evidence"],
        "protection_event_count": child_counts["protection_events"],
        "certified_composite_link_count": certified_count,
        "skipped_uncertified_composite_count": skipped_count,
    }
    connection.executemany(
        "INSERT INTO metadata(key, value_json) VALUES (?, ?)",
        [(key, canonical_json(values[key])) for key in sorted(values)],
    )


def build_reference_index(
    output_path: str | Path,
    records: Iterable[ReferenceOccurrence | Mapping[str, Any]],
    *,
    metadata: ReferenceIndexMetadata,
    context_histories: Iterable[Mapping[str, Any]] = (),
    composite_certificates: Iterable[CertifiedCompositeLink | Mapping[str, Any]] = (),
    dataset_id: str | None = None,
    batch_size: int = 5_000,
    exports_dir: str | Path | None = None,
    export_formats: Sequence[str] = ("jsonl", "tsv"),
) -> ReferenceIndexBuildResult:
    """Build a deterministic reference index and publish its complete artifact set.

    All chemistry-bearing work must already be present in the occurrence and
    context-history records.  A single SQLite writer performs batched inserts;
    indexes are created only after the bulk load. Requested exports and the
    database hash are staged before publication. Caught publication failures roll
    back prior files. Writers must be serialized; multiple output paths do not
    provide a simultaneous-reader or power-loss transaction.
    """

    if batch_size <= 0:
        raise ValueError("batch_size must be positive")
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    occurrences = normalize_reference_occurrences(
        records,
        context_histories=context_histories,
        dataset_id=dataset_id,
    )
    links, skipped_links = _certified_links(occurrences, composite_certificates)

    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{output.name}.", suffix=".tmp", dir=output.parent
    )
    os.close(descriptor)
    temporary = Path(temporary_name)
    export_paths: dict[str, Path] = {}
    try:
        connection = sqlite3.connect(temporary)
        try:
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA journal_mode = OFF")
            connection.execute("PRAGMA synchronous = OFF")
            connection.execute("PRAGMA temp_store = MEMORY")
            connection.execute("PRAGMA page_size = 4096")
            connection.execute(
                f"PRAGMA user_version = {REFERENCE_INDEX_SCHEMA_VERSION}"
            )
            connection.executescript(SCHEMA_SQL)
            with connection:
                child_counts = _insert_occurrences(
                    connection, occurrences, batch_size=batch_size
                )
                _insert_certified_links(connection, links, batch_size=batch_size)
                _write_metadata(
                    connection,
                    metadata,
                    occurrences,
                    child_counts,
                    len(links),
                    skipped_links,
                )
            connection.executescript(INDEX_SQL)
            _validate_database(connection, occurrences, child_counts, len(links))
            connection.commit()
            connection.execute("VACUUM")
            connection.commit()
        finally:
            connection.close()
        with ExitStack() as staging:
            pending_files: list[tuple[Path, Path]] = []
            if exports_dir is not None:
                destination = Path(exports_dir)
                destination.mkdir(parents=True, exist_ok=True)
                staged_exports = Path(
                    staging.enter_context(
                        tempfile.TemporaryDirectory(
                            prefix=".reference-exports-",
                            dir=destination,
                            ignore_cleanup_errors=True,
                        )
                    )
                )
                staged_paths = export_reference_index(
                    temporary, staged_exports, formats=export_formats
                )
                export_paths = {
                    key: destination / path.name for key, path in staged_paths.items()
                }
                pending_files.extend(
                    (path, export_paths[key]) for key, path in staged_paths.items()
                )
            kind_counts = Counter(item.occurrence_kind for item in occurrences)
            result = ReferenceIndexBuildResult(
                path=output,
                occurrence_count=len(occurrences),
                occurrence_counts_by_kind={
                    key: kind_counts.get(key, 0) for key in sorted(OCCURRENCE_KINDS)
                },
                functional_group_observation_count=child_counts[
                    "functional_group_observations"
                ],
                functional_group_transition_count=child_counts[
                    "functional_group_transitions"
                ],
                joint_token_count=child_counts["joint_token_count"],
                protection_evidence_count=child_counts["protection_evidence"],
                protection_event_count=child_counts["protection_events"],
                certified_composite_link_count=len(links),
                skipped_uncertified_composite_count=skipped_links,
                database_sha256=_sha256(temporary),
                export_paths=export_paths,
            )
            # The database is the last published artifact; any replacement failure
            # restores the entire previous set, including already replaced exports.
            pending_files.append((temporary, output))
            publish_files_with_rollback(pending_files)
            return result
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


def build_reference_index_from_paths(
    output_path: str | Path,
    occurrence_paths: Iterable[str | Path],
    *,
    metadata: ReferenceIndexMetadata,
    context_history_paths: Iterable[str | Path] = (),
    composite_certificate_paths: Iterable[str | Path] = (),
    dataset_id: str | None = None,
    batch_size: int = 5_000,
    exports_dir: str | Path | None = None,
    export_formats: Sequence[str] = ("jsonl", "tsv"),
) -> ReferenceIndexBuildResult:
    """Command-friendly path adapter for :func:`build_reference_index`."""

    records = iter_reference_occurrences(
        occurrence_paths,
        context_history_paths=tuple(context_history_paths),
        dataset_id=dataset_id,
    )
    certificates = iter_composite_certificates(composite_certificate_paths)
    return build_reference_index(
        output_path,
        records,
        metadata=metadata,
        composite_certificates=certificates,
        batch_size=batch_size,
        exports_dir=exports_dir,
        export_formats=export_formats,
    )


class ReferenceIndex:
    """Read-only access to nested occurrence-level reference evidence."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        if not self.path.is_file():
            raise FileNotFoundError(self.path)
        self._connection = sqlite3.connect(self.path)
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA query_only = ON")
        version = int(self._connection.execute("PRAGMA user_version").fetchone()[0])
        if version != REFERENCE_INDEX_SCHEMA_VERSION:
            self._connection.close()
            raise ValueError(f"unsupported reference-index schema version: {version}")

    def __enter__(self) -> "ReferenceIndex":
        return self

    def __exit__(self, *_args: Any) -> None:
        self.close()

    def close(self) -> None:
        self._connection.close()

    @property
    def metadata(self) -> dict[str, Any]:
        return {
            str(row["key"]): json.loads(row["value_json"])
            for row in self._connection.execute(
                "SELECT key, value_json FROM metadata ORDER BY key"
            )
        }

    def _identity_sql(
        self,
        *,
        level: str,
        base_signature: str,
        local_signature: str | None,
        occurrence_kind: str | None,
        joint_tokens: Sequence[str] | None = None,
        joint_mode: JointMode | None = None,
    ) -> tuple[str, list[Any]]:
        conditions = ["o.base_signature = ?"]
        parameters: list[Any] = [base_signature]
        if level in {"local", "joint"}:
            if local_signature is None:
                raise ValueError(f"{level} evidence requires local identity keys")
            conditions.append("o.local_signature = ?")
            parameters.append(local_signature)
        if occurrence_kind is not None:
            if occurrence_kind not in OCCURRENCE_KINDS:
                raise ValueError(f"unsupported occurrence kind: {occurrence_kind}")
            conditions.append("o.occurrence_kind = ?")
            parameters.append(occurrence_kind)

        join = ""
        if level == "joint":
            if joint_tokens is None or joint_mode not in {"containment", "exact"}:
                raise ValueError("joint evidence requires tokens and a match mode")
            counter = joint_token_counter(joint_tokens)
            if joint_mode == "exact":
                conditions.append("o.joint_signature = ?")
                parameters.append(joint_token_signature(joint_tokens))
            elif counter:
                clauses: list[str] = []
                token_parameters: list[Any] = []
                for token, multiplicity in sorted(counter.items()):
                    clauses.append("(token = ? AND multiplicity >= ?)")
                    token_parameters.extend((token, multiplicity))
                join = (
                    " JOIN (SELECT occurrence_id FROM joint_tokens WHERE "
                    + " OR ".join(clauses)
                    + " GROUP BY occurrence_id HAVING COUNT(*) = ?) matched"
                    " ON matched.occurrence_id = o.occurrence_id"
                )
                parameters = [*token_parameters, len(counter), *parameters]
        sql = (
            "SELECT o.occurrence_id FROM occurrences o"
            + join
            + " WHERE "
            + " AND ".join(conditions)
            + " ORDER BY o.occurrence_id"
        )
        return sql, parameters

    def _paths(self, occurrence_id: str) -> dict[str, tuple[tuple[int, ...], ...]]:
        grouped: dict[str, list[tuple[int, ...]]] = {
            "reaction": [],
            "molecule": [],
            "selected_reaction": [],
            "skipped_reaction": [],
        }
        for row in self._connection.execute(
            """SELECT path_kind, node_path_json FROM node_paths
               WHERE occurrence_id = ? ORDER BY path_kind, ordinal""",
            (occurrence_id,),
        ):
            grouped[str(row["path_kind"])].append(
                tuple(int(value) for value in json.loads(row["node_path_json"]))
            )
        return {key: tuple(value) for key, value in grouped.items()}

    def _provenance(
        self, occurrence_ids: Sequence[str]
    ) -> tuple[OccurrenceProvenance, ...]:
        provenance: list[OccurrenceProvenance] = []
        for occurrence_id in occurrence_ids:
            row = self._connection.execute(
                "SELECT * FROM occurrences WHERE occurrence_id = ?",
                (occurrence_id,),
            ).fetchone()
            if row is None:
                raise RuntimeError(f"missing indexed occurrence {occurrence_id}")
            identity_rows = self._connection.execute(
                """SELECT evidence_level, identity_key FROM identity_keys
                   WHERE occurrence_id = ? ORDER BY evidence_level, ordinal""",
                (occurrence_id,),
            ).fetchall()
            identities = {
                level: tuple(
                    str(item["identity_key"])
                    for item in identity_rows
                    if item["evidence_level"] == level
                )
                for level in ("base", "local")
            }
            sources = tuple(
                SourceRecord(
                    raw_source_id=str(item["raw_source_id"]),
                    source_record_id=str(item["source_record_id"]),
                    source_document_id=str(item["source_document_id"]),
                    source_id_adapter=str(item["source_id_adapter"]),
                )
                for item in self._connection.execute(
                    """SELECT raw_source_id, source_record_id, source_document_id,
                              source_id_adapter
                       FROM source_records WHERE occurrence_id = ? ORDER BY ordinal""",
                    (occurrence_id,),
                )
            )
            tokens = tuple(
                token
                for item in self._connection.execute(
                    """SELECT token, multiplicity FROM joint_tokens
                       WHERE occurrence_id = ? ORDER BY token""",
                    (occurrence_id,),
                )
                for token in [str(item["token"])] * int(item["multiplicity"])
            )
            protection = tuple(
                ProtectionEvidence(
                    lineage_id=str(item["lineage_id"]),
                    family_id=str(item["family_id"]),
                    site_token=str(item["site_token"]),
                    protection_state=str(item["protection_state"]),
                    fg_transition_status=str(item["fg_transition_status"]),
                    protection_transition=str(item["protection_transition"]),
                    pg_type=str(item["pg_type"]),
                    event_id=str(item["event_id"]),
                    start_position=item["start_position"],
                    end_position=item["end_position"],
                    node_paths=tuple(
                        tuple(int(value) for value in path)
                        for path in json.loads(item["node_paths_json"])
                    ),
                    payload=json.loads(item["payload_json"]),
                )
                for item in self._connection.execute(
                    """SELECT * FROM protection_evidence
                       WHERE occurrence_id = ? ORDER BY ordinal""",
                    (occurrence_id,),
                )
            )
            composite_ids = tuple(
                str(item["composite_id"])
                for item in self._connection.execute(
                    """SELECT composite_id FROM certified_composite_links
                       WHERE occurrence_id = ? ORDER BY composite_id""",
                    (occurrence_id,),
                )
            )
            paths = self._paths(occurrence_id)
            provenance.append(
                OccurrenceProvenance(
                    occurrence_id=occurrence_id,
                    occurrence_kind=str(row["occurrence_kind"]),
                    dataset_id=str(row["dataset_id"]),
                    source_identity=str(row["source_identity"]),
                    route_id=str(row["route_id"]),
                    route_target_smiles=str(row["route_target_smiles"]),
                    segment_target_smiles=str(row["segment_target_smiles"]),
                    target_smiles=str(row["target_smiles"]),
                    root_index=row["root_index"],
                    branch_index=row["branch_index"],
                    branch_indices=tuple(json.loads(row["branch_indices_json"])),
                    start_position=row["start_position"],
                    end_position=row["end_position"],
                    base_keys=identities["base"],
                    local_keys=identities["local"],
                    joint_tokens=tokens,
                    source_records=sources,
                    reaction_node_paths=paths["reaction"],
                    molecule_node_paths=paths["molecule"],
                    selected_reaction_node_paths=paths["selected_reaction"],
                    skipped_reaction_node_paths=paths["skipped_reaction"],
                    context_history_id=str(row["context_history_id"]),
                    analysis_only=bool(row["analysis_only"]),
                    factorability=str(row["factorability"]),
                    factorability_certified=bool(row["factorability_certified"]),
                    protection_evidence=protection,
                    composite_ids=composite_ids,
                    payload=json.loads(row["payload_json"]),
                )
            )
        return tuple(provenance)

    @staticmethod
    def _counts(provenance: Sequence[OccurrenceProvenance]) -> EvidenceCounts:
        routes = {
            (item.dataset_id, item.source_identity, item.route_id)
            for item in provenance
        }
        documents = {
            (item.dataset_id, source.source_document_id)
            for item in provenance
            for source in item.source_records
            if source.source_document_id
        }
        return EvidenceCounts(len(provenance), len(routes), len(documents))

    def _match(
        self,
        *,
        level: str,
        match_mode: str,
        base_signature: str,
        local_signature: str | None,
        occurrence_kind: str | None,
        joint_tokens: Sequence[str] | None = None,
        joint_mode: JointMode | None = None,
    ) -> EvidenceMatch:
        sql, parameters = self._identity_sql(
            level=level,
            base_signature=base_signature,
            local_signature=local_signature,
            occurrence_kind=occurrence_kind,
            joint_tokens=joint_tokens,
            joint_mode=joint_mode,
        )
        occurrence_ids = tuple(
            str(row["occurrence_id"])
            for row in self._connection.execute(sql, parameters)
        )
        provenance = self._provenance(occurrence_ids)
        return EvidenceMatch(
            evidence_level=level,
            match_mode=match_mode,
            counts=self._counts(provenance),
            provenance=provenance,
        )

    def _match_counts(
        self,
        *,
        level: str,
        base_signature: str,
        local_signature: str | None,
        occurrence_kind: str | None,
        joint_tokens: Sequence[str] | None = None,
        joint_mode: JointMode | None = None,
    ) -> EvidenceCounts:
        """Count matching evidence without materializing provenance payloads."""

        match_sql, parameters = self._identity_sql(
            level=level,
            base_signature=base_signature,
            local_signature=local_signature,
            occurrence_kind=occurrence_kind,
            joint_tokens=joint_tokens,
            joint_mode=joint_mode,
        )
        match_sql = match_sql.removesuffix(" ORDER BY o.occurrence_id")
        row = self._connection.execute(
            """WITH matched AS ("""
            + match_sql
            + """),
                matched_occurrences AS (
                    SELECT o.* FROM occurrences o
                    JOIN matched m ON m.occurrence_id = o.occurrence_id
                )
                SELECT
                    (SELECT COUNT(*) FROM matched_occurrences),
                    (SELECT COUNT(*) FROM (
                        SELECT DISTINCT dataset_id, source_identity, route_id
                        FROM matched_occurrences
                    )),
                    (SELECT COUNT(*) FROM (
                        SELECT DISTINCT o.dataset_id, s.source_document_id
                        FROM matched_occurrences o
                        JOIN source_records s
                          ON s.occurrence_id = o.occurrence_id
                        WHERE s.source_document_id <> ''
                    ))""",
            parameters,
        ).fetchone()
        if row is None:  # pragma: no cover - aggregate SELECT always returns one row
            raise RuntimeError("reference-index count query returned no row")
        return EvidenceCounts(*(int(value) for value in row))

    def query_counts(
        self,
        base_keys: Sequence[str],
        *,
        local_keys: Sequence[str],
        joint_tokens: Sequence[str],
        occurrence_kind: str | None = None,
    ) -> Mapping[str, EvidenceCounts]:
        """Return base/local/joint count units without exact precedent payloads."""

        if len(base_keys) != len(local_keys):
            raise ValueError("base and local query sequences must have equal length")
        base_signature = ordered_identity_signature(base_keys)
        local_signature = ordered_identity_signature(local_keys)
        common = {
            "base_signature": base_signature,
            "occurrence_kind": occurrence_kind,
        }
        return {
            "base": self._match_counts(
                level="base",
                local_signature=None,
                **common,
            ),
            "local": self._match_counts(
                level="local",
                local_signature=local_signature,
                **common,
            ),
            "joint_containment": self._match_counts(
                level="joint",
                local_signature=local_signature,
                joint_tokens=joint_tokens,
                joint_mode="containment",
                **common,
            ),
            "joint_exact": self._match_counts(
                level="joint",
                local_signature=local_signature,
                joint_tokens=joint_tokens,
                joint_mode="exact",
                **common,
            ),
        }

    def query(
        self,
        base_keys: Sequence[str],
        *,
        local_keys: Sequence[str] | None = None,
        joint_tokens: Sequence[str] | None = None,
        occurrence_kind: str | None = None,
    ) -> EvidenceQueryResult:
        """Return nested base, local, containment, and exact corpus evidence.

        Joint tokens are evaluated as one multiset against each candidate
        occurrence.  Tokens found in different occurrences can never jointly
        satisfy a query.
        """

        base_signature = ordered_identity_signature(base_keys)
        local_signature = (
            None if local_keys is None else ordered_identity_signature(local_keys)
        )
        if local_keys is not None and len(base_keys) != len(local_keys):
            raise ValueError("base and local query sequences must have equal length")
        if joint_tokens is not None and local_signature is None:
            raise ValueError("joint evidence requires local_keys")

        base = self._match(
            level="base",
            match_mode="exact_identity",
            base_signature=base_signature,
            local_signature=None,
            occurrence_kind=occurrence_kind,
        )
        local = None
        containment = None
        exact = None
        if local_signature is not None:
            local = self._match(
                level="local",
                match_mode="exact_identity",
                base_signature=base_signature,
                local_signature=local_signature,
                occurrence_kind=occurrence_kind,
            )
        if joint_tokens is not None:
            containment = self._match(
                level="joint",
                match_mode="containment",
                base_signature=base_signature,
                local_signature=local_signature,
                occurrence_kind=occurrence_kind,
                joint_tokens=joint_tokens,
                joint_mode="containment",
            )
            exact = self._match(
                level="joint",
                match_mode="exact",
                base_signature=base_signature,
                local_signature=local_signature,
                occurrence_kind=occurrence_kind,
                joint_tokens=joint_tokens,
                joint_mode="exact",
            )
        return EvidenceQueryResult(base, local, containment, exact)

    def _protection_match(
        self,
        *,
        base_signature: str,
        local_signature: str,
        family_id: str,
        protection_state: str,
        pg_type: str,
        site_token: str,
        occurrence_kind: str | None,
    ) -> EvidenceMatch:
        conditions = [
            "o.base_signature = ?",
            "o.local_signature = ?",
        ]
        parameters: list[Any] = [base_signature, local_signature]
        if occurrence_kind is None:
            conditions.append("o.occurrence_kind IN ('t1', 'rrseq_cons')")
        else:
            if occurrence_kind not in {"t1", RRSEQ_CONS_KIND}:
                raise ValueError(
                    "protection precedents support only t1 and rrseq_cons occurrences"
                )
            conditions.append("o.occurrence_kind = ?")
            parameters.append(occurrence_kind)

        protection_conditions = [
            "p.occurrence_id = o.occurrence_id",
            "p.family_id = ?",
            "p.protection_state = ?",
        ]
        protection_parameters: list[Any] = [family_id, protection_state]
        # An exposed/unprotected site has no protecting-group type. PG type is
        # therefore a protected-precedent filter only.
        if protection_state == "protected" and pg_type:
            protection_conditions.append("p.pg_type = ?")
            protection_parameters.append(pg_type)
        if site_token:
            protection_conditions.append("p.site_token = ?")
            protection_parameters.append(site_token)
        conditions.append(
            "EXISTS (SELECT 1 FROM protection_evidence p WHERE "
            + " AND ".join(protection_conditions)
            + ")"
        )
        parameters.extend(protection_parameters)
        sql = (
            "SELECT o.occurrence_id FROM occurrences o WHERE "
            + " AND ".join(conditions)
            + " ORDER BY o.occurrence_id"
        )
        occurrence_ids = tuple(
            str(row["occurrence_id"])
            for row in self._connection.execute(sql, parameters)
        )
        provenance = self._provenance(occurrence_ids)
        return EvidenceMatch(
            evidence_level="protection",
            match_mode=f"{protection_state}_precedent",
            counts=self._counts(provenance),
            provenance=provenance,
        )

    def query_protection_precedents(
        self,
        base_keys: Sequence[str],
        *,
        local_keys: Sequence[str],
        family_id: str,
        pg_type: str = "",
        site_token: str = "",
        occurrence_kind: str | None = None,
    ) -> ProtectionPrecedentResult:
        """Return protected versus exposed precedent counts, without a verdict.

        The local identity is always nested under the supplied base identity.
        An optional site token, designed to exclude protection state, prevents
        different sites in one occurrence from being conflated.
        """

        if not family_id:
            raise ValueError("family_id is required")
        if len(base_keys) != len(local_keys):
            raise ValueError("base and local query sequences must have equal length")
        base_signature = ordered_identity_signature(base_keys)
        local_signature = ordered_identity_signature(local_keys)
        protected = self._protection_match(
            base_signature=base_signature,
            local_signature=local_signature,
            family_id=family_id,
            protection_state="protected",
            pg_type=pg_type,
            site_token=site_token,
            occurrence_kind=occurrence_kind,
        )
        unprotected = self._protection_match(
            base_signature=base_signature,
            local_signature=local_signature,
            family_id=family_id,
            protection_state="unprotected",
            pg_type=pg_type,
            site_token=site_token,
            occurrence_kind=occurrence_kind,
        )
        return ProtectionPrecedentResult(
            family_id=family_id,
            pg_type=pg_type,
            site_token=site_token,
            occurrence_kind=occurrence_kind,
            protected=protected,
            unprotected=unprotected,
        )

    def explain_query_plan(
        self,
        base_keys: Sequence[str],
        *,
        local_keys: Sequence[str] | None = None,
        joint_tokens: Sequence[str] | None = None,
        joint_mode: JointMode | None = None,
        occurrence_kind: str | None = None,
    ) -> tuple[str, ...]:
        """Return SQLite's plan for an evidence lookup (for benchmarks/audits)."""

        level = "base"
        local_signature = None
        if local_keys is not None:
            local_signature = ordered_identity_signature(local_keys)
            level = "local"
        if joint_tokens is not None:
            level = "joint"
            joint_mode = joint_mode or "exact"
        sql, parameters = self._identity_sql(
            level=level,
            base_signature=ordered_identity_signature(base_keys),
            local_signature=local_signature,
            occurrence_kind=occurrence_kind,
            joint_tokens=joint_tokens,
            joint_mode=joint_mode,
        )
        return tuple(
            str(row[3])
            for row in self._connection.execute("EXPLAIN QUERY PLAN " + sql, parameters)
        )

    def explain_route_query_plan(
        self,
        dataset_id: str,
        source_identity: str,
        route_id: str,
    ) -> tuple[str, ...]:
        """Return SQLite's plan for an exact route-provenance lookup."""

        return tuple(
            str(row[3])
            for row in self._connection.execute(
                """EXPLAIN QUERY PLAN
                   SELECT occurrence_id FROM occurrences
                   WHERE dataset_id = ? AND source_identity = ? AND route_id = ?
                   ORDER BY occurrence_id""",
                (dataset_id, source_identity, route_id),
            )
        )

    def explain_source_query_plan(
        self,
        *,
        source_document_id: str | None = None,
        source_record_id: str | None = None,
    ) -> tuple[str, ...]:
        """Return SQLite's plan for an exact source-provenance lookup."""

        if (source_document_id is None) == (source_record_id is None):
            raise ValueError(
                "supply exactly one of source_document_id or source_record_id"
            )
        column = (
            "source_document_id"
            if source_document_id is not None
            else "source_record_id"
        )
        value = (
            source_document_id if source_document_id is not None else source_record_id
        )
        return tuple(
            str(row[3])
            for row in self._connection.execute(
                "EXPLAIN QUERY PLAN SELECT occurrence_id FROM source_records "
                f"WHERE {column} = ? ORDER BY occurrence_id",
                (value,),
            )
        )

    def all_provenance(self) -> tuple[OccurrenceProvenance, ...]:
        occurrence_ids = tuple(
            str(row[0])
            for row in self._connection.execute(
                "SELECT occurrence_id FROM occurrences ORDER BY occurrence_id"
            )
        )
        return self._provenance(occurrence_ids)


def _support_tsv_fields() -> list[str]:
    fields = [
        "occurrence_id",
        "occurrence_kind",
        "dataset_id",
        "source_identity",
        "route_id",
        "source_record_ids_json",
        "source_document_ids_json",
        "reaction_node_paths_json",
        "selected_reaction_node_paths_json",
        "skipped_reaction_node_paths_json",
        "base_keys_json",
        "local_keys_json",
        "joint_tokens_json",
        "analysis_only",
        "factorability",
        "factorability_certified",
        "certified_composite_ids_json",
    ]
    for level in ("base", "local", "joint_containment", "joint_exact"):
        fields.extend(
            f"{level}_{unit}"
            for unit in (
                "occurrence_count",
                "route_count",
                "source_document_count",
            )
        )
    return fields


class _EvidenceCountsAccumulator:
    """Mutable exact-count units used by the deterministic export pass."""

    __slots__ = ("occurrence_count", "routes", "source_documents")

    def __init__(self) -> None:
        self.occurrence_count = 0
        self.routes: set[tuple[str, str, str]] = set()
        self.source_documents: set[tuple[str, str]] = set()

    def add(self, record: OccurrenceProvenance) -> None:
        self.occurrence_count += 1
        self.routes.add((record.dataset_id, record.source_identity, record.route_id))
        self.source_documents.update(
            (record.dataset_id, source_document_id)
            for source_document_id in record.source_document_ids
        )

    def merge(self, other: "_EvidenceCountsAccumulator") -> None:
        self.occurrence_count += other.occurrence_count
        self.routes.update(other.routes)
        self.source_documents.update(other.source_documents)

    def freeze(self) -> EvidenceCounts:
        return EvidenceCounts(
            occurrence_count=self.occurrence_count,
            route_count=len(self.routes),
            source_document_count=len(self.source_documents),
        )


def _export_support_counts(
    records: Sequence[OccurrenceProvenance],
) -> dict[str, Mapping[str, EvidenceCounts]]:
    """Compute all exported support counts in grouped, occurrence-local passes.

    Base, local, and joint-exact support are equality groups. Joint containment
    compares token multisets only within the same occurrence-kind/base/local
    group, matching :meth:`ReferenceIndex.query_counts` without issuing four
    aggregate SQLite queries for every distinct exported occurrence key.
    """

    base_groups: dict[tuple[Any, ...], _EvidenceCountsAccumulator] = {}
    local_groups: dict[tuple[Any, ...], _EvidenceCountsAccumulator] = {}
    exact_groups: dict[tuple[Any, ...], _EvidenceCountsAccumulator] = {}
    exact_tokens: dict[tuple[Any, ...], Counter[str]] = {}
    exact_keys_by_local: dict[tuple[Any, ...], list[tuple[Any, ...]]] = defaultdict(
        list
    )
    keys_by_occurrence: dict[
        str, tuple[tuple[Any, ...], tuple[Any, ...], tuple[Any, ...]]
    ] = {}

    for record in records:
        base_key = (record.occurrence_kind, record.base_keys)
        local_key = (*base_key, record.local_keys)
        token_counter = joint_token_counter(record.joint_tokens)
        token_key = tuple(sorted(token_counter.items()))
        exact_key = (*local_key, token_key)
        keys_by_occurrence[record.occurrence_id] = (
            base_key,
            local_key,
            exact_key,
        )

        for groups, key in (
            (base_groups, base_key),
            (local_groups, local_key),
            (exact_groups, exact_key),
        ):
            accumulator = groups.get(key)
            if accumulator is None:
                accumulator = _EvidenceCountsAccumulator()
                groups[key] = accumulator
            accumulator.add(record)

        if exact_key not in exact_tokens:
            exact_tokens[exact_key] = token_counter
            exact_keys_by_local[local_key].append(exact_key)

    containment_groups: dict[tuple[Any, ...], EvidenceCounts] = {}
    for exact_keys in exact_keys_by_local.values():
        for query_key in exact_keys:
            query_tokens = exact_tokens[query_key]
            accumulator = _EvidenceCountsAccumulator()
            for candidate_key in exact_keys:
                candidate_tokens = exact_tokens[candidate_key]
                if all(
                    candidate_tokens.get(token, 0) >= multiplicity
                    for token, multiplicity in query_tokens.items()
                ):
                    accumulator.merge(exact_groups[candidate_key])
            containment_groups[query_key] = accumulator.freeze()

    frozen_base = {key: value.freeze() for key, value in base_groups.items()}
    frozen_local = {key: value.freeze() for key, value in local_groups.items()}
    frozen_exact = {key: value.freeze() for key, value in exact_groups.items()}
    return {
        occurrence_id: {
            "base": frozen_base[base_key],
            "local": frozen_local[local_key],
            "joint_containment": containment_groups[exact_key],
            "joint_exact": frozen_exact[exact_key],
        }
        for occurrence_id, (
            base_key,
            local_key,
            exact_key,
        ) in keys_by_occurrence.items()
    }


def _support_tsv_row(
    record: OccurrenceProvenance,
    support: Mapping[str, EvidenceCounts],
) -> dict[str, Any]:
    row: dict[str, Any] = {
        "occurrence_id": record.occurrence_id,
        "occurrence_kind": record.occurrence_kind,
        "dataset_id": record.dataset_id,
        "source_identity": record.source_identity,
        "route_id": record.route_id,
        "source_record_ids_json": canonical_json(
            [
                source.source_record_id
                for source in record.source_records
                if source.source_record_id
            ]
        ),
        "source_document_ids_json": canonical_json(record.source_document_ids),
        "reaction_node_paths_json": canonical_json(record.reaction_node_paths),
        "selected_reaction_node_paths_json": canonical_json(
            record.selected_reaction_node_paths
        ),
        "skipped_reaction_node_paths_json": canonical_json(
            record.skipped_reaction_node_paths
        ),
        "base_keys_json": canonical_json(record.base_keys),
        "local_keys_json": canonical_json(record.local_keys),
        "joint_tokens_json": canonical_json(record.joint_tokens),
        "analysis_only": int(record.analysis_only),
        "factorability": record.factorability,
        "factorability_certified": int(record.factorability_certified),
        "certified_composite_ids_json": canonical_json(record.composite_ids),
    }
    for level, counts in support.items():
        row[f"{level}_occurrence_count"] = counts.occurrence_count
        row[f"{level}_route_count"] = counts.route_count
        row[f"{level}_source_document_count"] = counts.source_document_count
    return row


def _write_support_tsv(
    output: Path,
    records: Iterable[OccurrenceProvenance],
    support_by_occurrence: Mapping[str, Mapping[str, EvidenceCounts]],
) -> Path:
    temporary, stream = _atomic_text_path(output)
    try:
        with stream:
            writer = csv.DictWriter(
                stream,
                fieldnames=_support_tsv_fields(),
                delimiter="\t",
                lineterminator="\n",
            )
            writer.writeheader()
            for record in records:
                writer.writerow(
                    _support_tsv_row(
                        record,
                        support_by_occurrence[record.occurrence_id],
                    )
                )
        os.replace(temporary, output)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    return output


def export_reference_index(
    index_path: str | Path,
    output_dir: str | Path,
    *,
    formats: Sequence[str] = ("jsonl", "tsv"),
) -> dict[str, Path]:
    """Export deterministic human/audit views without changing index semantics."""

    requested = tuple(dict.fromkeys(str(value).lower() for value in formats))
    unsupported = sorted(set(requested) - {"jsonl", "tsv"})
    if unsupported:
        raise ValueError(f"unsupported reference-index export format(s): {unsupported}")
    destination = Path(output_dir)
    with ReferenceIndex(index_path) as index:
        records = index.all_provenance()
        support_by_occurrence = _export_support_counts(records)

    outputs: dict[str, Path] = {}
    if "jsonl" in requested:
        output = destination / "reference_occurrences.jsonl"
        temporary, stream = _atomic_text_path(output)
        try:
            with stream:
                for record in records:
                    payload = record.to_dict()
                    payload["support_counts"] = {
                        level: counts.to_dict()
                        for level, counts in support_by_occurrence[
                            record.occurrence_id
                        ].items()
                    }
                    stream.write(canonical_json(payload) + "\n")
            os.replace(temporary, output)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
        outputs["jsonl"] = output

    if "tsv" in requested:
        output = destination / "reference_occurrences.tsv"
        _write_support_tsv(output, records, support_by_occurrence)
        outputs["tsv"] = output
        kind_outputs = {
            T1_KIND: ("single_rule_support_tsv", "single_rule_support.tsv"),
            RRSEQ_CONS_KIND: ("rrseq_cons_support_tsv", "rrseq_cons_support.tsv"),
            RRSEQ_GAP_KIND: ("rrseq_gap_support_tsv", "rrseq_gap_support.tsv"),
        }
        for kind, (output_key, filename) in kind_outputs.items():
            kind_output = destination / filename
            _write_support_tsv(
                kind_output,
                (record for record in records if record.occurrence_kind == kind),
                support_by_occurrence,
            )
            outputs[output_key] = kind_output
    return outputs


__all__ = [
    "EvidenceCounts",
    "EvidenceMatch",
    "EvidenceQueryResult",
    "OccurrenceProvenance",
    "ProtectionPrecedentResult",
    "ReferenceIndex",
    "ReferenceIndexBuildResult",
    "build_reference_index",
    "build_reference_index_from_paths",
    "export_reference_index",
]
