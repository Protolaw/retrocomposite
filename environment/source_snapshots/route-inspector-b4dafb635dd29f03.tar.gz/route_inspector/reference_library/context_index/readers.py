"""Readers for exact occurrence, context-history, and certificate sidecars."""

from __future__ import annotations

import gzip
import json
from collections.abc import Iterable, Iterator, Mapping
from pathlib import Path
from typing import Any

from route_inspector.reference_library.context_index.models import (
    CertifiedCompositeLink,
    ReferenceOccurrence,
    canonical_json,
)


def _open_text(path: Path):
    return (
        gzip.open(path, "rt", encoding="utf-8")
        if path.suffix == ".gz"
        else path.open("r", encoding="utf-8")
    )


def _records_from_json(value: Any, *, path: Path) -> Iterator[Mapping[str, Any]]:
    if isinstance(value, list):
        for index, record in enumerate(value):
            if not isinstance(record, Mapping):
                raise ValueError(f"expected an object at {path}[{index}]")
            yield record
        return
    if not isinstance(value, Mapping):
        raise ValueError(f"expected a JSON object or array in {path}")
    if (
        "occurrence_id" in value
        or "context_history_id" in value
        or "history_id" in value
    ):
        yield value
        return
    for wrapper in (
        "occurrences",
        "records",
        "context_histories",
        "validation_records",
        "composite_certificates",
    ):
        records = value.get(wrapper)
        if records is not None:
            yield from _records_from_json(records, path=path)
            return

    # Node/occurrence-keyed sidecars are accepted when every value is an object.
    if value and all(isinstance(record, Mapping) for record in value.values()):
        for key in sorted(value, key=str):
            record = dict(value[key])
            if not any(
                name in record
                for name in ("occurrence_id", "context_history_id", "history_id")
            ):
                record["context_history_id"] = str(key)
            yield record
        return
    raise ValueError(f"unrecognized record container in {path}")


def iter_mapping_records(path: str | Path) -> Iterator[Mapping[str, Any]]:
    """Yield mapping records from JSON arrays, wrappers, or JSONL sidecars."""

    source = Path(path)
    name = source.name[:-3] if source.name.endswith(".gz") else source.name
    if name.endswith(".json"):
        with _open_text(source) as stream:
            yield from _records_from_json(json.load(stream), path=source)
        return

    with _open_text(source) as stream:
        for line_number, line in enumerate(stream, start=1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"invalid JSON at {source}:{line_number}: {exc}"
                ) from exc
            if not isinstance(value, Mapping):
                raise ValueError(f"expected an object at {source}:{line_number}")
            yield value


def _route_history_key(value: Mapping[str, Any]) -> str:
    required = ("dataset_id", "source_identity", "route_id")
    if any(value.get(field) in (None, "") for field in required):
        return ""
    return "route:" + canonical_json([str(value[field]) for field in required])


def _is_route_history(value: Mapping[str, Any]) -> bool:
    return all(
        field in value
        for field in ("molecule_records", "transitions", "reaction_node_paths")
    )


def _add_context_history(
    lookup: dict[str, Mapping[str, Any]],
    digests: dict[str, str],
    record: Mapping[str, Any],
    *,
    label: str,
) -> None:
    keys = {
        str(record.get(name) or "")
        for name in ("context_history_id", "history_id", "occurrence_id")
    }
    route_key = _route_history_key(record) if _is_route_history(record) else ""
    keys.discard("")
    if route_key:
        keys.add(route_key)
    if not keys:
        raise ValueError(f"context-history record in {label} has no stable ID")
    digest = canonical_json(record)
    for key in sorted(keys):
        previous = digests.get(key)
        if previous is not None and previous != digest:
            raise ValueError(f"conflicting context-history payloads for {key}")
        lookup[key] = record
        digests[key] = digest


def _validate_projected_history(
    history: Mapping[str, Any],
    occurrence: Mapping[str, Any],
) -> Mapping[str, Any]:
    for field in ("dataset_id", "source_identity", "route_id"):
        expected = occurrence.get(field)
        actual = history.get(field)
        if (
            expected not in (None, "")
            and actual not in (None, "")
            and str(expected) != str(actual)
        ):
            raise ValueError(f"projected context history {field} mismatch")
    expected_id = str(occurrence.get("occurrence_id") or "")
    actual_id = str(history.get("occurrence_id") or "")
    if expected_id and actual_id and expected_id != actual_id:
        raise ValueError("projected context history occurrence_id mismatch")
    expected_route_history_id = str(
        occurrence.get("route_context_history_id")
        or occurrence.get("context_history_ref")
        or ""
    )
    actual_route_history_id = str(history.get("route_context_history_id") or "")
    if (
        expected_route_history_id
        and actual_route_history_id != expected_route_history_id
    ):
        raise ValueError("projected route context-history reference mismatch")
    expected_projection_id = str(occurrence.get("context_history_projection_id") or "")
    actual_projection_id = str(history.get("context_history_id") or "")
    if expected_projection_id and actual_projection_id != expected_projection_id:
        raise ValueError("projected occurrence context-history reference mismatch")
    return history


def _effective_dataset_id(
    occurrence: Mapping[str, Any],
    history: Mapping[str, Any] | None,
    *,
    fallback: str | None,
) -> str:
    """Resolve corpus identity without overwriting record-level provenance."""

    occurrence_dataset = str(occurrence.get("dataset_id") or "")
    history_dataset = str((history or {}).get("dataset_id") or "")
    if occurrence_dataset and history_dataset and occurrence_dataset != history_dataset:
        raise ValueError(
            "occurrence/context-history dataset_id mismatch: "
            f"{occurrence_dataset!r} != {history_dataset!r}"
        )
    return occurrence_dataset or history_dataset or str(fallback or "")


def _project_route_history(
    history_record: Mapping[str, Any],
    occurrence: Mapping[str, Any],
) -> Mapping[str, Any]:
    from route_inspector.context.history import (
        RouteContextHistory,
        project_context_history_to_occurrence,
    )

    history = RouteContextHistory.from_dict(history_record)
    if not history.mapping_validated:
        raise ValueError(
            f"context history {history.history_id} is not mapping validated"
        )
    projected = project_context_history_to_occurrence(history, occurrence)
    return _validate_projected_history(projected, occurrence)


def _select_context_history(
    lookup: Mapping[str, Mapping[str, Any]],
    occurrence: Mapping[str, Any],
) -> Mapping[str, Any] | None:
    if not lookup:
        return None
    occurrence_id = str(occurrence.get("occurrence_id") or "")
    explicit_refs = tuple(
        dict.fromkeys(
            str(value)
            for value in (
                occurrence.get("context_history_projection_id"),
                occurrence.get("context_history_id"),
                occurrence.get("context_history_ref"),
                occurrence.get("route_context_history_id"),
            )
            if value
        )
    )
    candidates: list[Mapping[str, Any]] = []
    for explicit_ref in explicit_refs:
        candidate = lookup.get(explicit_ref)
        if candidate is not None:
            candidates.append(candidate)
            break
    if not candidates and occurrence_id and occurrence_id in lookup:
        candidates.append(lookup[occurrence_id])
    if not candidates:
        # A command-level dataset ID is only a final fallback. It must not filter
        # out a route history that already carries its own corpus identity.
        expected_dataset = str(occurrence.get("dataset_id") or "")
        expected_source = str(occurrence.get("source_identity") or "")
        expected_route = str(occurrence.get("route_id") or "")
        seen: set[str] = set()
        for candidate in lookup.values():
            if not _is_route_history(candidate):
                continue
            if (
                expected_dataset
                and str(candidate.get("dataset_id") or "") != expected_dataset
            ):
                continue
            if str(candidate.get("source_identity") or "") != expected_source:
                continue
            if str(candidate.get("route_id") or "") != expected_route:
                continue
            digest = canonical_json(candidate)
            if digest not in seen:
                candidates.append(candidate)
                seen.add(digest)
    if not candidates and explicit_refs:
        raise ValueError(
            f"no context history for explicit reference {explicit_refs[0]!r}"
        )

    projected: list[Mapping[str, Any]] = []
    failures: list[str] = []
    for candidate in candidates:
        try:
            value = (
                _project_route_history(candidate, occurrence)
                if _is_route_history(candidate)
                else _validate_projected_history(candidate, occurrence)
            )
        except Exception as exc:
            failures.append(str(exc))
            continue
        projected.append(value)
    if len(projected) != 1:
        detail = "; ".join(failures[:3])
        raise ValueError(
            "context history did not resolve to one exact occurrence projection; "
            f"occurrence={occurrence_id!r} candidates={len(candidates)} "
            f"matches={len(projected)} errors={detail}"
        )
    return projected[0]


def load_context_history_lookup(
    paths: Iterable[str | Path],
) -> dict[str, Mapping[str, Any]]:
    """Load context histories keyed by history ID and/or occurrence ID.

    Duplicate byte-equivalent records are harmless.  Conflicting payloads for
    the same key fail closed so context from two route occurrences can never be
    combined accidentally.
    """

    lookup: dict[str, Mapping[str, Any]] = {}
    digests: dict[str, str] = {}
    for path in paths:
        for record in iter_mapping_records(path):
            _add_context_history(lookup, digests, record, label=str(path))
    return lookup


def iter_reference_occurrences(
    occurrence_paths: Iterable[str | Path],
    *,
    context_history_paths: Iterable[str | Path] = (),
    dataset_id: str | None = None,
) -> Iterator[ReferenceOccurrence]:
    """Normalize heterogeneous exact occurrence sidecars.

    Pre-projected records are joined by explicit history/occurrence ID. Full
    route histories are projected through the occurrence's unique ordered node
    paths. Route-level or global functional-group unions are never accepted.
    """

    histories = load_context_history_lookup(context_history_paths)
    for path in occurrence_paths:
        for record_index, record in enumerate(iter_mapping_records(path)):
            try:
                history = _select_context_history(histories, record)
                effective_dataset_id = _effective_dataset_id(
                    record,
                    history,
                    fallback=dataset_id,
                )
                yield ReferenceOccurrence.from_mapping(
                    record,
                    context_history=history,
                    dataset_id=str(effective_dataset_id or ""),
                )
            except Exception as exc:
                raise ValueError(
                    f"invalid reference occurrence at {path}[{record_index}]: {exc}"
                ) from exc


def iter_composite_certificates(
    paths: Iterable[str | Path],
) -> Iterator[CertifiedCompositeLink]:
    """Read validation records, retaining certificate semantics in the model."""

    for path in paths:
        for record_index, record in enumerate(iter_mapping_records(path)):
            try:
                link = CertifiedCompositeLink.from_mapping(record)
            except Exception as exc:
                raise ValueError(
                    f"invalid composite certificate at {path}[{record_index}]: {exc}"
                ) from exc
            if not link.occurrence_id:
                raise ValueError(
                    f"composite certificate at {path}[{record_index}] has no occurrence_id"
                )
            if link.certified and not link.composite_id:
                raise ValueError(
                    f"certified composite certificate at {path}[{record_index}] "
                    "has no composite ID"
                )
            yield link


def normalize_reference_occurrences(
    records: Iterable[ReferenceOccurrence | Mapping[str, Any]],
    *,
    context_histories: Iterable[Mapping[str, Any]] = (),
    dataset_id: str | None = None,
) -> tuple[ReferenceOccurrence, ...]:
    """Normalize in-memory records and reject conflicting occurrence IDs."""

    history_lookup: dict[str, Mapping[str, Any]] = {}
    history_digests: dict[str, str] = {}
    for history in context_histories:
        _add_context_history(history_lookup, history_digests, history, label="memory")

    normalized: dict[str, ReferenceOccurrence] = {}
    digests: dict[str, str] = {}
    for record in records:
        if isinstance(record, ReferenceOccurrence):
            occurrence = record
        else:
            history = _select_context_history(history_lookup, record)
            effective_dataset_id = _effective_dataset_id(
                record,
                history,
                fallback=dataset_id,
            )
            occurrence = ReferenceOccurrence.from_mapping(
                record,
                context_history=history,
                dataset_id=str(effective_dataset_id or ""),
            )
        digest = occurrence.content_digest()
        previous = digests.get(occurrence.occurrence_id)
        if previous is not None and previous != digest:
            raise ValueError(
                f"conflicting reference occurrences for {occurrence.occurrence_id}"
            )
        normalized[occurrence.occurrence_id] = occurrence
        digests[occurrence.occurrence_id] = digest
    return tuple(normalized[key] for key in sorted(normalized))


def normalize_composite_certificates(
    records: Iterable[CertifiedCompositeLink | Mapping[str, Any]],
) -> tuple[CertifiedCompositeLink, ...]:
    """Normalize and deterministically de-duplicate certificate records."""

    normalized: dict[tuple[str, str], CertifiedCompositeLink] = {}
    payloads: dict[tuple[str, str], str] = {}
    for record in records:
        link = (
            record
            if isinstance(record, CertifiedCompositeLink)
            else CertifiedCompositeLink.from_mapping(record)
        )
        if not link.occurrence_id:
            raise ValueError("composite certificates require occurrence_id")
        if link.certified and not link.composite_id:
            raise ValueError("certified composite certificates require composite_id")
        key = (link.occurrence_id, link.composite_id)
        digest = canonical_json(
            {
                "occurrence_id": link.occurrence_id,
                "composite_id": link.composite_id,
                "composite_rule": link.composite_rule,
                "validation_status": link.validation_status,
                "accepted": link.accepted,
                "lineage_certified": link.lineage_certified,
            }
        )
        previous = payloads.get(key)
        if previous is not None and previous != digest:
            raise ValueError(
                f"conflicting composite certificate payloads for {key[0]}/{key[1]}"
            )
        normalized[key] = link
        payloads[key] = digest
    return tuple(normalized[key] for key in sorted(normalized))


__all__ = [
    "iter_composite_certificates",
    "iter_mapping_records",
    "iter_reference_occurrences",
    "load_context_history_lookup",
    "normalize_composite_certificates",
    "normalize_reference_occurrences",
]
