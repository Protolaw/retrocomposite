"""Versioned, chemistry-independent records for reference evidence.

The reference index deliberately consumes occurrence sidecars rather than
recomputing chemistry.  This module normalizes the slightly different t1,
RRseq_cons, RRseq_gap, context-history, protection, and composite-validation
payloads into one strict contract.  No field in this contract is interpreted as
chemical plausibility; it is exact corpus evidence only.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence

REFERENCE_OCCURRENCE_SCHEMA_VERSION = 1
REFERENCE_INDEX_SCHEMA_VERSION = 3
REFERENCE_SCOPE = "all_data"

T1_KIND = "t1"
RRSEQ_CONS_KIND = "rrseq_cons"
RRSEQ_GAP_KIND = "rrseq_gap"
OCCURRENCE_KINDS = frozenset({T1_KIND, RRSEQ_CONS_KIND, RRSEQ_GAP_KIND})

CERTIFIED_COMPOSITE_STATUSES = frozenset({"validated_unique", "validated_ambiguous"})


def canonical_json(value: Any) -> str:
    """Serialize a value deterministically for identities and SQLite payloads."""

    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )


def ordered_identity_signature(keys: Sequence[str]) -> str:
    """Return a collision-safe signature retaining sequence order."""

    normalized = tuple(str(key) for key in keys)
    if not normalized or any(not key for key in normalized):
        raise ValueError("identity keys must be non-empty strings")
    return canonical_json(normalized)


def joint_token_counter(tokens: Iterable[str]) -> Counter[str]:
    """Return the exact functional-group token multiset for one occurrence."""

    counter: Counter[str] = Counter()
    for raw_token in tokens:
        token = str(raw_token)
        if not token:
            raise ValueError("joint functional-group tokens must be non-empty")
        counter[token] += 1
    return counter


def joint_token_signature(tokens: Iterable[str]) -> str:
    """Return a deterministic signature retaining token multiplicity."""

    counter = joint_token_counter(tokens)
    return canonical_json(sorted(counter.items()))


def _first(
    mapping: Mapping[str, Any], names: Sequence[str], default: Any = None
) -> Any:
    for name in names:
        if name in mapping and mapping[name] is not None:
            return mapping[name]
    return default


def _as_tuple(value: Any) -> tuple[Any, ...]:
    if value is None:
        return ()
    if isinstance(value, tuple):
        return value
    if isinstance(value, list):
        return tuple(value)
    return (value,)


def _string_tuple(value: Any) -> tuple[str, ...]:
    return tuple(str(item) for item in _as_tuple(value) if str(item))


def _path(value: Iterable[Any]) -> tuple[int, ...]:
    return tuple(int(index) for index in value)


def _paths(value: Any) -> tuple[tuple[int, ...], ...]:
    return tuple(_path(path) for path in _as_tuple(value))


def _bool(value: Any, *, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "yes", "1", "y"}:
            return True
        if normalized in {"false", "no", "0", "n", ""}:
            return False
    return bool(value)


def _sequence_from_text(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        if not value:
            return ()
        parts = tuple(value.split("$"))
    else:
        parts = tuple(str(item) for item in _as_tuple(value))
    if any(not part.strip() for part in parts):
        raise ValueError("identity sequences cannot contain blank keys")
    return parts


def infer_occurrence_kind(value: Mapping[str, Any]) -> str:
    """Infer one supported occurrence kind from common sidecar aliases."""

    explicit = _first(value, ("occurrence_kind", "kind", "sequence_kind"))
    if explicit is not None:
        normalized = str(explicit).strip().lower().replace("-", "_")
        aliases = {
            "single": T1_KIND,
            "single_rule": T1_KIND,
            "reaction": T1_KIND,
            "cons": RRSEQ_CONS_KIND,
            "consecutive": RRSEQ_CONS_KIND,
            "gap": RRSEQ_GAP_KIND,
            "gapped": RRSEQ_GAP_KIND,
        }
        normalized = aliases.get(normalized, normalized)
        if normalized in OCCURRENCE_KINDS:
            return normalized
        raise ValueError(f"unsupported occurrence kind: {explicit}")
    if (
        "RRseq_gap" in value
        or value.get("skipped_steps")
        or value.get("skipped_positions")
    ):
        return RRSEQ_GAP_KIND
    if "RRseq_cons" in value or "raw_sequence" in value:
        return RRSEQ_CONS_KIND
    return T1_KIND


def _identity_keys(
    value: Mapping[str, Any], *, level: str, kind: str
) -> tuple[str, ...]:
    if level == "base":
        sequence_names = (
            "base_query_cgr_keys",
            "base_keys",
            "ordered_base_keys",
        )
        single_names = ("base_query_cgr_key", "base_key")
    else:
        sequence_names = (
            "local_context_query_cgr_keys",
            "local_query_cgr_keys",
            "local_keys",
            "ordered_local_keys",
            "query_cgr_keys",
        )
        single_names = (
            "local_context_query_cgr_key",
            "local_query_cgr_key",
            "local_key",
            "query_cgr_key",
        )

    nested = value.get("identities")
    if isinstance(nested, Mapping):
        nested_value = nested.get(level)
        if isinstance(nested_value, Mapping):
            candidate = _first(nested_value, ("keys", "ordered_keys", "key"))
            if candidate is not None:
                return _sequence_from_text(candidate)
        elif nested_value is not None:
            return _sequence_from_text(nested_value)

    candidate = _first(value, sequence_names)
    if candidate is None:
        candidate = _first(value, single_names)
    keys = _sequence_from_text(candidate)
    if keys:
        return keys

    steps = (
        value.get("selected_steps")
        if kind == RRSEQ_GAP_KIND
        else value.get("source_matches")
    )
    if steps:
        per_step = []
        for step in steps:
            if not isinstance(step, Mapping):
                continue
            key = _first(step, sequence_names + single_names)
            if key is not None:
                per_step.extend(_sequence_from_text(key))
        if per_step:
            return tuple(per_step)
    return ()


def validate_native_occurrence_payload(value: Mapping[str, Any], *, kind: str) -> None:
    """Reapply native sidecar identity checks before generic normalization.

    Historical and third-party normalized records need not contain every native
    payload field. Once a record has the complete Route Inspector sidecar
    contract, however, it must not bypass the stable-ID validators merely
    because it is being loaded through the reference-index adapter.
    """

    current_payload_schema = {
        T1_KIND: 2,
        RRSEQ_CONS_KIND: 3,
        RRSEQ_GAP_KIND: 3,
    }[kind]
    declared_schema = value.get("schema_version")
    declares_current_native = "identity_version" in value or (
        declared_schema is not None and int(declared_schema) == current_payload_schema
    )

    def validate_identity_aliases(
        *,
        base_keys: tuple[str, ...],
        local_keys: tuple[str, ...],
        canonical_base_field: str,
        canonical_local_field: str,
    ) -> None:
        alias_fields = {
            "base": (
                "base_query_cgr_keys",
                "base_keys",
                "ordered_base_keys",
                "base_query_cgr_key",
                "base_key",
            ),
            "local": (
                "local_context_query_cgr_keys",
                "local_query_cgr_keys",
                "local_keys",
                "ordered_local_keys",
                "query_cgr_keys",
                "local_context_query_cgr_key",
                "local_query_cgr_key",
                "local_key",
                "query_cgr_key",
            ),
        }
        for level, expected, canonical_field in (
            ("base", base_keys, canonical_base_field),
            ("local", local_keys, canonical_local_field),
        ):
            nested = value.get("identities")
            if isinstance(nested, Mapping) and level in nested:
                nested_value = nested[level]
                if isinstance(nested_value, Mapping):
                    nested_value = _first(
                        nested_value,
                        ("keys", "ordered_keys", "key"),
                    )
                if (
                    nested_value is not None
                    and _sequence_from_text(nested_value) != expected
                ):
                    raise ValueError(
                        f"native {kind} nested {level} identity aliases disagree"
                    )
            for field_name in alias_fields[level]:
                if field_name == canonical_field or field_name not in value:
                    continue
                if _sequence_from_text(value[field_name]) != expected:
                    raise ValueError(
                        f"native {kind} {field_name} identity alias disagrees"
                    )

    def validate_source_overrides(native_rows: Iterable[Mapping[str, Any]]) -> None:
        expected = tuple(SourceRecord.from_mapping(row) for row in native_rows)
        for field_name in ("source_records", "reaction_source_records"):
            if field_name not in value:
                continue
            explicit_rows = _as_tuple(value[field_name])
            if not all(isinstance(row, Mapping) for row in explicit_rows):
                raise ValueError(f"native {kind} {field_name} must contain objects")
            actual = tuple(SourceRecord.from_mapping(row) for row in explicit_rows)
            if actual != expected:
                raise ValueError(
                    f"native {kind} {field_name} override differs from step provenance"
                )

    def validate_node_path_aliases(
        *,
        reaction_paths: tuple[tuple[int, ...], ...],
        molecule_paths: tuple[tuple[int, ...], ...],
        canonical_reaction_field: str,
        canonical_molecule_field: str,
    ) -> None:
        for field_name in (
            "reaction_node_path",
            "reaction_node_paths",
            "interval_reaction_node_paths",
        ):
            if field_name == canonical_reaction_field or field_name not in value:
                continue
            raw_paths = (
                (_path(value[field_name]),)
                if field_name.endswith("_path")
                else _paths(value[field_name])
            )
            if raw_paths != reaction_paths:
                raise ValueError(
                    f"native {kind} {field_name} alias differs from exact paths"
                )
        for field_name in (
            "molecule_node_path",
            "molecule_node_paths",
            "target_molecule_path",
        ):
            if field_name == canonical_molecule_field or field_name not in value:
                continue
            raw_paths = (
                (_path(value[field_name]),)
                if field_name.endswith("_path")
                else _paths(value[field_name])
            )
            if raw_paths != molecule_paths:
                raise ValueError(
                    f"native {kind} {field_name} alias differs from exact paths"
                )

    def validate_completeness(required: set[str]) -> bool:
        complete = required <= value.keys()
        if declares_current_native and not complete:
            missing = ", ".join(sorted(required - value.keys()))
            raise ValueError(
                f"versioned native {kind} occurrence is missing fields: {missing}"
            )
        return complete

    if kind == T1_KIND:
        native_fields = {
            "schema_version",
            "occurrence_id",
            "dataset_id",
            "source_identity",
            "route_id",
            "route_target_smiles",
            "target_smiles",
            "root_index",
            "branch_indices",
            "reaction_node_path",
            "target_molecule_path",
            "rule_smarts",
            "reaction_smiles",
            "center_atom_maps",
            "query_cgr_key",
            "local_context_query_cgr_key",
            "base_query_cgr_key",
            "base_rule_atom_maps",
            "raw_source_id",
            "raw_source_record_id",
            "source_record_id",
            "source_document_id",
            "source_id_adapter",
        }
        if validate_completeness(native_fields):
            from route_inspector.rules.occurrences import SingleRuleOccurrence

            SingleRuleOccurrence.from_dict(value)
            validate_identity_aliases(
                base_keys=(str(value["base_query_cgr_key"]),),
                local_keys=(str(value["query_cgr_key"]),),
                canonical_base_field="base_query_cgr_key",
                canonical_local_field="query_cgr_key",
            )
            validate_source_overrides((value,))
            validate_node_path_aliases(
                reaction_paths=(_path(value["reaction_node_path"]),),
                molecule_paths=(_path(value["target_molecule_path"]),),
                canonical_reaction_field="reaction_node_path",
                canonical_molecule_field="target_molecule_path",
            )
        return

    if kind == RRSEQ_CONS_KIND:
        native_fields = {
            "schema_version",
            "occurrence_id",
            "dataset_id",
            "source_identity",
            "route_id",
            "raw_sequence",
            "query_cgr_keys",
            "base_query_cgr_keys",
            "source_matches",
            "source_route_leaves",
            "reaction_node_paths",
            "start_position",
            "end_position",
            "root_index",
            "branch_index",
            "branch_indices",
            "route_target_smiles",
            "segment_target_smiles",
            "RRseq_cons",
            "rrseq_cons_size",
        }
        if validate_completeness(native_fields):
            from route_inspector.tactics.rrseq.occurrences import RRseqConsOccurrence

            required_match_fields = {
                "step_index",
                "path_position",
                "reaction_node_path",
                "target_molecule_path",
                "rule_smarts",
                "reaction_smiles",
                "target_smiles",
                "product_index",
                "center_atom_maps",
                "query_cgr_key",
                "base_query_cgr_key",
                "base_rule_atom_maps",
                "raw_source_id",
                "raw_source_record_id",
                "source_record_id",
                "source_document_id",
                "source_id_adapter",
                "product_to_target_atom_map",
                "continuation_reactant_index",
                "continuation_molecule_path",
                "continuation_to_next_target_atom_map",
            }
            for match_index, match in enumerate(value["source_matches"]):
                if not isinstance(match, Mapping):
                    raise ValueError(
                        f"RRseq_cons source_matches[{match_index}] must be an object"
                    )
                missing = required_match_fields - match.keys()
                if missing:
                    raise ValueError(
                        f"RRseq_cons source_matches[{match_index}] is missing fields: "
                        + ", ".join(sorted(missing))
                    )
            required_leaf_fields = {
                "mapped_smiles",
                "step_index",
                "path_position",
                "reactant_index",
                "molecule_node_path",
            }
            for leaf_index, leaf in enumerate(value["source_route_leaves"]):
                if not isinstance(leaf, Mapping):
                    raise ValueError(
                        f"RRseq_cons source_route_leaves[{leaf_index}] must be an object"
                    )
                missing = required_leaf_fields - leaf.keys()
                if missing:
                    raise ValueError(
                        f"RRseq_cons source_route_leaves[{leaf_index}] is missing fields: "
                        + ", ".join(sorted(missing))
                    )
            occurrence = RRseqConsOccurrence.from_dict(value)
            for match_index, match in enumerate(occurrence.source_matches):
                if not match.query_cgr_key or not match.base_query_cgr_key:
                    raise ValueError(
                        "versioned native RRseq_cons source_matches require base "
                        f"and local identities at index {match_index}"
                    )
            validate_identity_aliases(
                base_keys=tuple(str(key) for key in value["base_query_cgr_keys"]),
                local_keys=tuple(str(key) for key in value["query_cgr_keys"]),
                canonical_base_field="base_query_cgr_keys",
                canonical_local_field="query_cgr_keys",
            )
            validate_source_overrides(value["source_matches"])
            validate_node_path_aliases(
                reaction_paths=tuple(
                    _path(path) for path in value["reaction_node_paths"]
                ),
                molecule_paths=tuple(
                    _path(match["target_molecule_path"])
                    for match in value["source_matches"]
                ),
                canonical_reaction_field="reaction_node_paths",
                canonical_molecule_field="",
            )
        return

    native_fields = {
        "schema_version",
        "occurrence_id",
        "dataset_id",
        "source_identity",
        "route_id",
        "start_position",
        "selected_positions",
        "selected_steps",
        "skipped_positions",
        "skipped_steps",
        "query_cgr_keys",
        "base_query_cgr_keys",
        "RRseq_gap",
        "RRseq",
        "selected_step_ids",
        "route_target_smiles",
        "target_molecule",
        "connector_maps",
        "skipped_center_maps",
        "selected_center_maps",
        "accumulated_history_maps",
        "selected_center_maps_by_step",
        "selected_rule_context_maps_by_step",
        "selected_rule_context_maps",
        "gap_contexts",
        "has_persistent_net_change",
        "route_cgr_provenance",
        "root_index",
        "branch_index",
    }
    if not validate_completeness(native_fields):
        return
    for field_name in (
        "dataset_id",
        "source_identity",
        "route_id",
        "route_target_smiles",
        "target_molecule",
    ):
        if not str(value[field_name]):
            raise ValueError(f"RRseq_gap requires non-empty {field_name}")
    from route_inspector.tactics.rrseq.enumeration import stable_rrseq_gap_occurrence_id
    from route_inspector.tactics.rrseq.gapped import (
        RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION,
    )

    identity_version = int(
        value.get("identity_version", RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION)
    )
    if identity_version != RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION:
        raise ValueError(
            f"unsupported RRseq_gap occurrence identity version: {identity_version}"
        )
    from route_inspector.tactics.rrseq.gapped import RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION

    schema_version = int(value["schema_version"])
    if schema_version != RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION:
        raise ValueError(
            f"unsupported RRseq_gap occurrence schema version: {schema_version}"
        )
    selected_positions = tuple(int(item) for item in value["selected_positions"])
    if "inter_selection_gap_widths" in value:
        from route_inspector.tactics.rrseq.gap_widths import native_gap_widths

        native_gap_widths(value)
    selected_steps = tuple(value["selected_steps"])
    if len(selected_positions) < 2 or tuple(sorted(set(selected_positions))) != (
        selected_positions
    ):
        raise ValueError(
            "RRseq_gap selected_positions must contain at least two ordered unique steps"
        )
    if (
        int(value["root_index"]) < 0
        or int(value["branch_index"]) < 0
        or selected_positions[0] < 0
    ):
        raise ValueError(
            "RRseq_gap root, branch, and interval positions must be non-negative"
        )
    if len(selected_steps) != len(selected_positions) or not all(
        isinstance(step, Mapping) for step in selected_steps
    ):
        raise ValueError(
            "RRseq_gap selected_steps must map one-to-one to selected_positions"
        )
    step_positions = tuple(int(step["position"]) for step in selected_steps)
    if step_positions != selected_positions:
        raise ValueError(
            "RRseq_gap selected step positions differ from selected_positions"
        )
    if int(value["start_position"]) != selected_positions[0]:
        raise ValueError("RRseq_gap start_position differs from first selected step")

    skipped_positions = tuple(int(item) for item in value["skipped_positions"])
    skipped_steps = tuple(value["skipped_steps"])
    if len(skipped_steps) != len(skipped_positions) or not all(
        isinstance(step, Mapping) for step in skipped_steps
    ):
        raise ValueError(
            "RRseq_gap skipped_steps must map one-to-one to skipped_positions"
        )
    skipped_step_positions = tuple(int(step["position"]) for step in skipped_steps)
    if skipped_step_positions != skipped_positions:
        raise ValueError(
            "RRseq_gap skipped step positions differ from skipped_positions"
        )
    expected_skipped = tuple(
        position
        for position in range(selected_positions[0], selected_positions[-1] + 1)
        if position not in set(selected_positions)
    )
    if skipped_positions != expected_skipped:
        raise ValueError(
            "RRseq_gap skipped positions do not complete the selected interval"
        )
    if not skipped_positions:
        raise ValueError("RRseq_gap native occurrence must contain a skipped step")

    def validate_step(step: Mapping[str, Any], *, collection: str, index: int) -> None:
        required_step_fields = {
            "position",
            "reaction_node_path",
            "target_molecule_path",
            "target_molecule",
            "raw_source_id",
            "raw_source_record_id",
            "source_record_id",
            "source_document_id",
            "source_id_adapter",
            "rule_smarts",
            "query_cgr_key",
            "base_query_cgr_key",
            "base_rule_atom_maps",
            "center_atoms",
            "reaction_smiles",
            "reactant_center_molecules",
            "product_center_molecules",
        }
        missing = required_step_fields - step.keys()
        if missing:
            raise ValueError(
                f"RRseq_gap {collection}[{index}] is missing fields: "
                + ", ".join(sorted(missing))
            )
        reaction_path = _path(step["reaction_node_path"])
        target_path = _path(step["target_molecule_path"])
        if any(path_index < 0 for path_index in (*reaction_path, *target_path)):
            raise ValueError(
                f"RRseq_gap {collection}[{index}] node paths must be non-negative"
            )
        if not reaction_path or target_path != reaction_path[:-1]:
            raise ValueError(
                f"RRseq_gap {collection}[{index}] target path must parent reaction path"
            )
        for field_name in (
            "target_molecule",
            "rule_smarts",
            "query_cgr_key",
            "base_query_cgr_key",
            "reaction_smiles",
        ):
            if not str(step[field_name]):
                raise ValueError(
                    f"RRseq_gap {collection}[{index}] requires {field_name}"
                )
        center_maps = tuple(int(item) for item in step["center_atoms"])
        base_maps = tuple(int(item) for item in step["base_rule_atom_maps"])
        if center_maps != tuple(sorted(set(center_maps))):
            raise ValueError(
                f"RRseq_gap {collection}[{index}] center_atoms must be canonical"
            )
        if base_maps != tuple(sorted(set(base_maps))):
            raise ValueError(
                f"RRseq_gap {collection}[{index}] base_rule_atom_maps must be canonical"
            )
        if not set(center_maps) <= set(base_maps):
            raise ValueError(
                f"RRseq_gap {collection}[{index}] center atoms exceed base mask"
            )
        if str(step["raw_source_id"]) != str(step["raw_source_record_id"]):
            raise ValueError(
                f"RRseq_gap {collection}[{index}] raw source aliases disagree"
            )
        from route_inspector.datasets.source_ids import source_id_adapter_from_name

        expected_source = source_id_adapter_from_name(
            str(step["source_id_adapter"])
        ).parse({"ID": str(step["raw_source_record_id"])})
        if str(step["source_record_id"]) != expected_source.source_record_id:
            raise ValueError(
                f"RRseq_gap {collection}[{index}] source_record_id disagrees with adapter"
            )
        if str(step["source_document_id"]) != expected_source.source_document_id:
            raise ValueError(
                f"RRseq_gap {collection}[{index}] source_document_id disagrees with adapter"
            )

    for index, step in enumerate(selected_steps):
        validate_step(step, collection="selected_steps", index=index)
    for index, step in enumerate(skipped_steps):
        validate_step(step, collection="skipped_steps", index=index)

    selected_paths = tuple(_path(step["reaction_node_path"]) for step in selected_steps)
    skipped_paths = tuple(_path(step["reaction_node_path"]) for step in skipped_steps)
    if len(set((*selected_paths, *skipped_paths))) != (
        len(selected_paths) + len(skipped_paths)
    ):
        raise ValueError("RRseq_gap selected and skipped reaction paths must be unique")
    interval_steps = tuple(
        step
        for _position, step in sorted(
            (
                *zip(selected_positions, selected_steps),
                *zip(skipped_positions, skipped_steps),
            )
        )
    )
    interval_paths = tuple(_path(step["reaction_node_path"]) for step in interval_steps)
    for current_step, next_step in zip(interval_steps, interval_steps[1:]):
        current_reaction_path = _path(current_step["reaction_node_path"])
        next_target_path = _path(next_step["target_molecule_path"])
        if (
            len(next_target_path) != len(current_reaction_path) + 1
            or next_target_path[:-1] != current_reaction_path
        ):
            raise ValueError("RRseq_gap interval steps leave the exact route branch")
    explicit_selected_paths = value.get("selected_reaction_node_paths")
    if explicit_selected_paths is not None and _paths(explicit_selected_paths) != (
        selected_paths
    ):
        raise ValueError(
            "RRseq_gap selected_reaction_node_paths differ from selected_steps"
        )
    explicit_skipped_paths = value.get("skipped_reaction_node_paths")
    if explicit_skipped_paths is not None and _paths(explicit_skipped_paths) != (
        skipped_paths
    ):
        raise ValueError(
            "RRseq_gap skipped_reaction_node_paths differ from skipped_steps"
        )
    explicit_interval_paths = value.get("reaction_node_paths")
    if explicit_interval_paths is not None and _paths(explicit_interval_paths) != (
        interval_paths
    ):
        raise ValueError("RRseq_gap reaction_node_paths differ from interval steps")

    local_keys = _sequence_from_text(value["query_cgr_keys"])
    base_keys = _sequence_from_text(value["base_query_cgr_keys"])
    if len(local_keys) != len(selected_steps) or len(base_keys) != len(selected_steps):
        raise ValueError(
            "RRseq_gap identity sequences must map one-to-one to selected_steps"
        )
    selected_rules: list[str] = []
    for index, step in enumerate(selected_steps):
        rule_smarts = str(step.get("rule_smarts") or "")
        local_key = str(step.get("query_cgr_key") or "")
        base_key = str(step.get("base_query_cgr_key") or "")
        if not rule_smarts or not local_key or not base_key:
            raise ValueError(
                "RRseq_gap native selected steps require rule and identity fields"
            )
        if local_key != local_keys[index]:
            raise ValueError(
                "RRseq_gap selected-step query_cgr_key differs from top-level identity"
            )
        if base_key != base_keys[index]:
            raise ValueError(
                "RRseq_gap selected-step base_query_cgr_key differs from top-level identity"
            )
        selected_rules.append(rule_smarts)
    serialized_sequence = "$".join(selected_rules)
    if str(value["RRseq_gap"]) != serialized_sequence:
        raise ValueError("RRseq_gap differs from selected-step rule sequence")
    if value.get("RRseq") is not None and str(value["RRseq"]) != serialized_sequence:
        raise ValueError("RRseq alias differs from selected-step rule sequence")
    if (
        value.get("selected_step_ids") is not None
        and tuple(int(item) for item in value["selected_step_ids"])
        != selected_positions
    ):
        raise ValueError("RRseq_gap selected_step_ids differ from selected_positions")

    selected_center_sets = tuple(
        set(int(item) for item in step["center_atoms"]) for step in selected_steps
    )
    skipped_center_set = {
        int(item) for step in skipped_steps for item in step["center_atoms"]
    }
    selected_center_set = set().union(*selected_center_sets)
    if tuple(int(item) for item in value["selected_center_maps"]) != tuple(
        sorted(selected_center_set)
    ):
        raise ValueError("RRseq_gap selected_center_maps differ from selected steps")
    if tuple(int(item) for item in value["accumulated_history_maps"]) != tuple(
        sorted(selected_center_set)
    ):
        raise ValueError(
            "RRseq_gap accumulated_history_maps differ from selected steps"
        )
    if tuple(int(item) for item in value["skipped_center_maps"]) != tuple(
        sorted(skipped_center_set)
    ):
        raise ValueError("RRseq_gap skipped_center_maps differ from skipped steps")
    expected_centers_by_step = tuple(
        {
            "position": position,
            "center_maps": sorted(selected_center_sets[index]),
        }
        for index, position in enumerate(selected_positions)
    )
    actual_centers_by_step = tuple(
        {
            "position": int(item["position"]),
            "center_maps": sorted(int(atom_map) for atom_map in item["center_maps"]),
        }
        for item in value["selected_center_maps_by_step"]
    )
    if actual_centers_by_step != expected_centers_by_step:
        raise ValueError(
            "RRseq_gap selected_center_maps_by_step differ from selected steps"
        )
    connector_set: set[int] = set()
    selected_history: set[int] = set()
    for center_set in selected_center_sets:
        connector_set.update(selected_history & center_set)
        selected_history.update(center_set)
    if tuple(int(item) for item in value["connector_maps"]) != tuple(
        sorted(connector_set)
    ):
        raise ValueError("RRseq_gap connector_maps differ from selected center history")
    context_rows = tuple(value["selected_rule_context_maps_by_step"])
    if len(context_rows) != len(selected_positions):
        raise ValueError(
            "RRseq_gap selected rule contexts must map one-to-one to selected steps"
        )
    context_union: set[int] = set()
    for index, row in enumerate(context_rows):
        if int(row["position"]) != selected_positions[index]:
            raise ValueError("RRseq_gap selected rule context positions disagree")
        context_maps = tuple(int(item) for item in row["context_maps"])
        if context_maps != tuple(sorted(set(context_maps))):
            raise ValueError("RRseq_gap selected rule context maps must be canonical")
        center_maps = selected_center_sets[index]
        mapped_target_atoms = {
            int(atom_map)
            for atom_map in re.findall(
                r":(\d+)\]",
                str(selected_steps[index]["target_molecule"]),
            )
        }
        target_center_maps = center_maps & mapped_target_atoms
        if not target_center_maps <= set(context_maps):
            raise ValueError(
                "RRseq_gap selected rule context must contain its target-side "
                "reaction center"
            )
        if mapped_target_atoms and not set(context_maps) <= mapped_target_atoms:
            raise ValueError(
                "RRseq_gap selected rule context contains maps absent from target"
            )
        context_union.update(context_maps)
    if tuple(int(item) for item in value["selected_rule_context_maps"]) != tuple(
        sorted(context_union)
    ):
        raise ValueError(
            "RRseq_gap selected_rule_context_maps differ from per-step contexts"
        )
    if str(value["target_molecule"]) != str(selected_steps[0]["target_molecule"]):
        raise ValueError("RRseq_gap target_molecule differs from first selected step")
    if value.get("end_position") is not None and int(value["end_position"]) != (
        selected_positions[-1] + 1
    ):
        raise ValueError("RRseq_gap end_position differs from selected interval")
    interval_by_position = {
        int(step["position"]): step for step in (*selected_steps, *skipped_steps)
    }
    expected_gap_contexts: list[dict[str, Any]] = []
    history_centers: set[int] = set()
    for selected_index, position in enumerate(selected_positions):
        center_set = selected_center_sets[selected_index]
        if selected_index == 0:
            history_centers.update(center_set)
            continue
        left_position = selected_positions[selected_index - 1]
        connectors = sorted(history_centers & center_set)
        history_centers.update(center_set)
        if position <= left_position + 1:
            continue
        expected_gap_contexts.append(
            {
                "left_selected_position": left_position,
                "right_selected_position": position,
                "skipped_positions": list(range(left_position + 1, position)),
                "connector_maps": connectors,
                "after_left_selected_molecule": str(
                    interval_by_position[left_position + 1]["target_molecule"]
                ),
                "before_right_selected_molecule": str(
                    interval_by_position[position]["target_molecule"]
                ),
            }
        )
    normalized_gap_contexts = [
        {
            "left_selected_position": int(item["left_selected_position"]),
            "right_selected_position": int(item["right_selected_position"]),
            "skipped_positions": [
                int(position) for position in item["skipped_positions"]
            ],
            "connector_maps": [int(atom_map) for atom_map in item["connector_maps"]],
            "after_left_selected_molecule": str(item["after_left_selected_molecule"]),
            "before_right_selected_molecule": str(
                item["before_right_selected_molecule"]
            ),
        }
        for item in value["gap_contexts"]
    ]
    if normalized_gap_contexts != expected_gap_contexts:
        raise ValueError(
            "RRseq_gap gap_contexts differ from the exact skipped interval"
        )
    persistent_flag = value["has_persistent_net_change"]
    if not isinstance(persistent_flag, bool):
        raise ValueError("RRseq_gap has_persistent_net_change must be boolean")
    provenance = value["route_cgr_provenance"]
    if not isinstance(provenance, Mapping):
        raise ValueError("RRseq_gap route_cgr_provenance must be an object")
    required_provenance_fields = {
        "net_center_maps",
        "net_center_components",
        "composed_selected_reaction_smiles",
        "preserve_transient_bonds",
    }
    missing_provenance = required_provenance_fields - provenance.keys()
    if missing_provenance:
        raise ValueError(
            "RRseq_gap route_cgr_provenance is missing fields: "
            + ", ".join(sorted(missing_provenance))
        )
    net_center_maps = tuple(int(item) for item in provenance["net_center_maps"])
    if net_center_maps != tuple(sorted(set(net_center_maps))):
        raise ValueError("RRseq_gap net_center_maps must be canonical")
    components = tuple(provenance["net_center_components"])
    component_center_union: set[int] = set()
    seen_component_maps: set[int] = set()
    for component_index, component in enumerate(components):
        if not isinstance(component, Mapping):
            raise ValueError("RRseq_gap net center components must be objects")
        required_component_fields = {
            "center_maps",
            "selected_step_numbers",
            "atomic_selected_step_numbers",
            "selected_positions",
        }
        missing_component = required_component_fields - component.keys()
        if missing_component:
            raise ValueError(
                f"RRseq_gap net_center_components[{component_index}] is missing fields"
            )
        component_maps = tuple(int(item) for item in component["center_maps"])
        step_numbers = tuple(int(item) for item in component["selected_step_numbers"])
        atomic_step_numbers = tuple(
            int(item) for item in component["atomic_selected_step_numbers"]
        )
        component_positions = tuple(
            int(item) for item in component["selected_positions"]
        )
        if component_maps != tuple(sorted(set(component_maps))) or not component_maps:
            raise ValueError("RRseq_gap component center maps must be canonical")
        if not set(component_positions) <= set(selected_positions):
            raise ValueError(
                "RRseq_gap component selected positions exceed the occurrence"
            )
        valid_step_numbers = set(range(1, len(selected_positions) + 1))
        if (
            step_numbers != tuple(sorted(set(step_numbers)))
            or not set(step_numbers) <= valid_step_numbers
        ):
            raise ValueError(
                "RRseq_gap component selected_step_numbers must be canonical"
            )
        if atomic_step_numbers != tuple(sorted(set(atomic_step_numbers))) or not set(
            atomic_step_numbers
        ) <= set(step_numbers):
            raise ValueError(
                "RRseq_gap component atomic steps must be a canonical subset"
            )
        expected_component_positions = tuple(
            selected_positions[step_number - 1] for step_number in step_numbers
        )
        if component_positions != expected_component_positions:
            raise ValueError(
                "RRseq_gap component positions differ from selected step attribution"
            )
        if seen_component_maps.intersection(component_maps):
            raise ValueError("RRseq_gap net center components must be disjoint")
        seen_component_maps.update(component_maps)
        component_center_union.update(component_maps)
    if tuple(sorted(component_center_union)) != net_center_maps:
        raise ValueError("RRseq_gap net_center_maps differ from net center components")
    if persistent_flag != bool(components):
        raise ValueError(
            "RRseq_gap persistent-net-change flag differs from RouteCGR components"
        )
    if persistent_flag and not str(provenance["composed_selected_reaction_smiles"]):
        raise ValueError("RRseq_gap composed selected reaction is required")
    if provenance["preserve_transient_bonds"] is not False:
        raise ValueError("RRseq_gap preserve_transient_bonds must be false")
    reaction_smiles = tuple(
        str(step.get("reaction_smiles") or "") for step in selected_steps
    )
    if any(not item for item in reaction_smiles):
        raise ValueError("RRseq_gap native selected steps require reaction_smiles")
    from route_inspector.tactics.rrseq.gapped import (
        compose_gapped_history,
        history_provenance_payload,
    )

    try:
        expected_provenance = history_provenance_payload(
            compose_gapped_history(reaction_smiles),
            selected_positions,
        )
    except Exception as exc:
        raise ValueError(
            "RRseq_gap selected reactions cannot reproduce RouteCGR provenance"
        ) from exc
    if canonical_json(provenance) != canonical_json(expected_provenance):
        raise ValueError(
            "RRseq_gap RouteCGR provenance differs from exact selected-reaction replay"
        )
    expected_id = stable_rrseq_gap_occurrence_id(
        source_identity=str(value.get("source_identity") or ""),
        route_id=value.get("route_id"),
        root_index=int(value["root_index"]),
        branch_index=int(value["branch_index"]),
        selected_positions=selected_positions,
        reaction_smiles=reaction_smiles,
    )
    if str(value.get("occurrence_id") or "") != expected_id:
        raise ValueError("occurrence_id does not match RRseq_gap identity fields")
    validate_identity_aliases(
        base_keys=base_keys,
        local_keys=local_keys,
        canonical_base_field="base_query_cgr_keys",
        canonical_local_field="query_cgr_keys",
    )
    validate_source_overrides(interval_steps)
    validate_node_path_aliases(
        reaction_paths=interval_paths,
        molecule_paths=tuple(
            _path(step["target_molecule_path"]) for step in interval_steps
        ),
        canonical_reaction_field="",
        canonical_molecule_field="",
    )


def _source_rows(value: Mapping[str, Any]) -> tuple[Mapping[str, Any], ...]:
    rows = _first(value, ("source_records", "reaction_source_records"))
    if rows is not None:
        return tuple(row for row in _as_tuple(rows) if isinstance(row, Mapping))

    source_matches = value.get("source_matches") or ()
    if not source_matches:
        interval_steps: list[tuple[int, int, int, Mapping[str, Any]]] = []
        for role, collection_name in enumerate(("selected_steps", "skipped_steps")):
            for ordinal, step in enumerate(value.get(collection_name) or ()):
                if not isinstance(step, Mapping):
                    continue
                position = _first(
                    step,
                    ("path_position", "reaction_index", "step_index", "position"),
                    ordinal,
                )
                interval_steps.append((int(position), role, ordinal, step))
        source_matches = tuple(item[-1] for item in sorted(interval_steps))
    derived: list[Mapping[str, Any]] = []
    for step in source_matches:
        if not isinstance(step, Mapping):
            continue
        raw_id = _first(
            step,
            (
                "raw_source_id",
                "raw_source_record_id",
                "source_id",
                "metadata_id",
                "ID",
            ),
        )
        record_id = _first(step, ("source_record_id", "record_id"))
        document_id = _first(step, ("source_document_id", "document_id", "patent_id"))
        metadata = step.get("metadata")
        if isinstance(metadata, Mapping):
            raw_id = raw_id or metadata.get("ID")
        if raw_id is not None or record_id is not None or document_id is not None:
            derived.append(
                {
                    "raw_source_id": raw_id,
                    "source_record_id": record_id,
                    "source_document_id": document_id,
                    "source_id_adapter": step.get("source_id_adapter", "raw"),
                }
            )
    if derived:
        return tuple(derived)

    raw_id = _first(
        value,
        (
            "raw_source_id",
            "raw_source_record_id",
            "source_id",
            "metadata_id",
            "ID",
        ),
    )
    record_id = _first(value, ("source_record_id", "record_id"))
    document_id = _first(value, ("source_document_id", "document_id", "patent_id"))
    if raw_id is None and record_id is None and document_id is None:
        return ()
    return (
        {
            "raw_source_id": raw_id,
            "source_record_id": record_id,
            "source_document_id": document_id,
            "source_id_adapter": value.get("source_id_adapter", "raw"),
        },
    )


@dataclass(frozen=True)
class SourceRecord:
    """One source database identifier contributing to an occurrence."""

    raw_source_id: str = ""
    source_record_id: str = ""
    source_document_id: str = ""
    source_id_adapter: str = "raw"

    def __post_init__(self) -> None:
        from route_inspector.datasets.source_ids import source_id_adapter_from_name

        expected = source_id_adapter_from_name(self.source_id_adapter).parse(
            {"ID": self.raw_source_id}
        )
        if self.source_record_id != expected.source_record_id:
            raise ValueError("source_record_id differs from the adapter-derived value")
        if self.source_document_id != expected.source_document_id:
            raise ValueError(
                "source_document_id differs from the adapter-derived value"
            )

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "SourceRecord":
        if (
            "raw_source_id" in value
            and "raw_source_record_id" in value
            and str(value["raw_source_id"]) != str(value["raw_source_record_id"])
        ):
            raise ValueError("raw source identifier aliases disagree")
        raw = str(
            _first(
                value,
                (
                    "raw_source_id",
                    "raw_source_record_id",
                    "source_id",
                    "metadata_id",
                    "ID",
                ),
                "",
            )
            or ""
        )
        adapter = str(value.get("source_id_adapter") or "raw")
        from route_inspector.datasets.source_ids import source_id_adapter_from_name

        expected = source_id_adapter_from_name(adapter).parse({"ID": raw})
        record_value = _first(value, ("source_record_id", "record_id"))
        document_value = _first(
            value,
            ("source_document_id", "document_id", "patent_id"),
        )
        record = (
            expected.source_record_id if record_value is None else str(record_value)
        )
        document = (
            expected.source_document_id
            if document_value is None
            else str(document_value)
        )
        if record != expected.source_record_id:
            raise ValueError("source_record_id differs from the adapter-derived value")
        if document != expected.source_document_id:
            raise ValueError(
                "source_document_id differs from the adapter-derived value"
            )
        return cls(
            raw_source_id=raw,
            source_record_id=record,
            source_document_id=document,
            source_id_adapter=adapter,
        )

    def to_dict(self) -> dict[str, str]:
        return {
            "raw_source_id": self.raw_source_id,
            "source_record_id": self.source_record_id,
            "source_document_id": self.source_document_id,
            "source_id_adapter": self.source_id_adapter,
        }


@dataclass(frozen=True)
class FunctionalGroupEvidence:
    """One exact functional-group observation retained for one occurrence."""

    family_id: str
    transition_status: str
    location: str
    token: str = ""
    lineage_id: str = ""
    protection_state: str = "unknown"
    pg_type: str = ""
    raw_pattern: str = ""
    atom_maps: tuple[int, ...] = ()
    include_in_joint_context: bool = True
    payload: Mapping[str, Any] = field(default_factory=dict, compare=False, hash=False)

    def __post_init__(self) -> None:
        if not self.family_id:
            raise ValueError("functional-group family_id is required")
        if not self.transition_status:
            raise ValueError("functional-group transition_status is required")
        if not self.location:
            raise ValueError("functional-group location is required")

    @property
    def context_token(self) -> str:
        """Return the normalized joint-context token for this observation."""

        if self.token:
            return self.token
        return canonical_json(
            {
                "family_id": self.family_id,
                "location": self.location,
                "protection_state": self.protection_state,
                "transition_status": self.transition_status,
            }
        )

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "FunctionalGroupEvidence":
        atom_maps = _first(
            value,
            ("atom_maps", "route_atom_maps", "anchor_atom_maps", "mapped_atoms"),
            (),
        )
        location = str(
            _first(value, ("location", "location_class"), "remote") or "remote"
        )
        stratum = str(value.get("stratum") or "")
        default_include = location != "center" and stratum in {
            "",
            "primary_fg",
            "reactive_handle",
            "primary",
            "handle",
        }
        return cls(
            family_id=str(
                _first(value, ("family_id", "group_family_id", "name"), "") or ""
            ),
            transition_status=str(
                _first(value, ("transition_status", "status"), "persistent")
                or "persistent"
            ),
            location=location,
            token=str(
                _first(value, ("joint_token", "context_token", "token"), "") or ""
            ),
            lineage_id=str(_first(value, ("lineage_id", "fg_lineage_id"), "") or ""),
            protection_state=str(value.get("protection_state") or "unknown"),
            pg_type=str(
                _first(value, ("pg_type", "protection_group_type", "group_type"), "")
                or ""
            ),
            raw_pattern=str(
                _first(value, ("raw_pattern", "pattern_name", "query_name"), "") or ""
            ),
            atom_maps=tuple(sorted(int(atom_map) for atom_map in _as_tuple(atom_maps))),
            include_in_joint_context=_bool(
                _first(
                    value,
                    ("include_in_joint_context", "include_in_context_statistics"),
                    default_include,
                )
            ),
            payload=dict(value),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "family_id": self.family_id,
            "transition_status": self.transition_status,
            "location": self.location,
            "token": self.context_token,
            "lineage_id": self.lineage_id,
            "protection_state": self.protection_state,
            "pg_type": self.pg_type,
            "raw_pattern": self.raw_pattern,
            "atom_maps": list(self.atom_maps),
            "include_in_joint_context": self.include_in_joint_context,
        }


@dataclass(frozen=True)
class ProtectionEvidence:
    """Mapped protection evidence associated with a functional-group lineage."""

    lineage_id: str = ""
    site_token: str = ""
    family_id: str = ""
    protection_state: str = "unknown"
    fg_transition_status: str = ""
    protection_transition: str = ""
    pg_type: str = ""
    event_id: str = ""
    start_position: int | None = None
    end_position: int | None = None
    node_paths: tuple[tuple[int, ...], ...] = ()
    payload: Mapping[str, Any] = field(default_factory=dict, compare=False, hash=False)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "ProtectionEvidence":
        start = value.get("start_position")
        end = value.get("end_position")
        paths = _first(
            value,
            ("node_paths", "reaction_node_paths", "interval_node_paths"),
        )
        if paths is None and value.get("reaction_node_path") is not None:
            paths = (value["reaction_node_path"],)
        paths = paths or ()
        return cls(
            lineage_id=str(_first(value, ("lineage_id", "fg_lineage_id"), "") or ""),
            site_token=str(
                _first(
                    value,
                    ("site_token", "lineage_token", "context_lineage_token"),
                    "",
                )
                or ""
            ),
            family_id=str(_first(value, ("family_id", "group_family_id"), "") or ""),
            protection_state=str(value.get("protection_state") or "unknown"),
            fg_transition_status=str(
                value.get("fg_transition_status")
                or value.get("transition_status")
                or ""
            ),
            protection_transition=str(value.get("protection_transition") or ""),
            pg_type=str(
                _first(value, ("pg_type", "protection_group_type", "group_type"), "")
                or ""
            ),
            event_id=str(_first(value, ("event_id", "protection_event_id"), "") or ""),
            start_position=None if start is None else int(start),
            end_position=None if end is None else int(end),
            node_paths=_paths(paths),
            payload=dict(value),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "lineage_id": self.lineage_id,
            "site_token": self.site_token,
            "family_id": self.family_id,
            "protection_state": self.protection_state,
            "fg_transition_status": self.fg_transition_status,
            "protection_transition": self.protection_transition,
            "pg_type": self.pg_type,
            "event_id": self.event_id,
            "start_position": self.start_position,
            "end_position": self.end_position,
            "node_paths": [list(path) for path in self.node_paths],
        }


@dataclass(frozen=True)
class CertifiedCompositeLink:
    """One accepted consecutive-composite certificate."""

    occurrence_id: str
    composite_id: str
    composite_rule: str
    validation_status: str
    accepted: bool
    lineage_certified: bool
    payload: Mapping[str, Any] = field(default_factory=dict, compare=False, hash=False)

    @property
    def certified(self) -> bool:
        return (
            self.accepted
            and self.lineage_certified
            and self.validation_status in CERTIFIED_COMPOSITE_STATUSES
        )

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "CertifiedCompositeLink":
        status = str(_first(value, ("validation_status", "status"), "") or "")
        accepted = _bool(_first(value, ("accepted", "certified"), False))
        lineage_value = _first(value, ("lineage_certified", "mapping_consistent"))
        if lineage_value is None:
            source_comparison = value.get("source_comparison")
            representative = value.get("representative_validation")
            lineage_value = bool(
                isinstance(source_comparison, Mapping)
                and source_comparison.get("mapping_consistent")
                and isinstance(representative, Mapping)
                and representative.get("mapping_consistent")
            )
        return cls(
            occurrence_id=str(value.get("occurrence_id") or ""),
            composite_id=str(
                _first(
                    value,
                    ("composite_id", "composite_aggregate_key", "composite_cgr"),
                    "",
                )
                or ""
            ),
            composite_rule=str(
                _first(
                    value, ("composite_rule", "representative_rule", "rule_smarts"), ""
                )
                or ""
            ),
            validation_status=status,
            accepted=accepted,
            lineage_certified=_bool(lineage_value),
            payload=dict(value),
        )


def _functional_group_rows(
    value: Mapping[str, Any],
    context_history: Mapping[str, Any] | None,
) -> tuple[FunctionalGroupEvidence, ...]:
    candidates: list[Any] = []
    sources: tuple[Mapping[str, Any], ...] = (
        (context_history,) if isinstance(context_history, Mapping) else (value,)
    )
    for source in sources:
        nested = source.get("context_history")
        if isinstance(nested, Mapping):
            source = {**source, **nested}
        raw = _first(
            source,
            (
                "functional_groups",
                "fg_observations",
                "functional_group_observations",
                "groups",
            ),
        )
        if raw is not None:
            candidates.extend(_as_tuple(raw))
    return tuple(
        FunctionalGroupEvidence.from_mapping(item)
        for item in candidates
        if isinstance(item, Mapping)
    )


def _protection_rows(
    value: Mapping[str, Any],
    context_history: Mapping[str, Any] | None,
) -> tuple[ProtectionEvidence, ...]:
    candidates: list[Any] = []
    sources: tuple[Mapping[str, Any], ...] = (
        (context_history,) if isinstance(context_history, Mapping) else (value,)
    )
    for source in sources:
        nested = source.get("context_history")
        if isinstance(nested, Mapping):
            source = {**source, **nested}
        trace_events_by_id = {
            str(event.get("event_id") or ""): dict(event)
            for event in _as_tuple(source.get("protection_trace_events"))
            if isinstance(event, Mapping) and event.get("event_id")
        }
        raw = _first(
            source,
            ("protection_evidence", "protection_events", "protecting_groups"),
        )
        if raw is not None:
            groups_by_lineage: dict[str, Mapping[str, Any]] = {}
            groups = _first(
                source,
                (
                    "functional_groups",
                    "fg_observations",
                    "functional_group_observations",
                    "groups",
                ),
                (),
            )
            for group in _as_tuple(groups):
                if isinstance(group, Mapping) and group.get("lineage_id"):
                    groups_by_lineage[str(group["lineage_id"])] = group
            represented_lineages: set[str] = set()
            for item in _as_tuple(raw):
                if not isinstance(item, Mapping):
                    continue
                enriched = dict(item)
                lineage_id = str(
                    _first(item, ("lineage_id", "fg_lineage_id"), "") or ""
                )
                if lineage_id:
                    represented_lineages.add(lineage_id)
                group = groups_by_lineage.get(lineage_id, {})
                enriched.setdefault("family_id", group.get("family_id") or "")
                enriched.setdefault("site_token", group.get("token") or "")
                enriched.setdefault(
                    "fg_transition_status",
                    group.get("transition_status") or "",
                )
                enriched.setdefault(
                    "protection_transition",
                    item.get("protection_transition") or "",
                )
                if not enriched.get("event_id"):
                    event_ids = _string_tuple(item.get("protection_event_ids") or ())
                    if event_ids:
                        enriched["event_id"] = "|".join(sorted(event_ids))
                raw_event_ids = _string_tuple(
                    item.get("protection_event_ids") or enriched.get("event_id") or ()
                )
                event_ids = tuple(
                    sorted(
                        {
                            event_id
                            for raw_event_id in raw_event_ids
                            for event_id in str(raw_event_id).split("|")
                            if event_id
                        }
                    )
                )
                item_trace_events = {
                    str(event.get("event_id") or ""): dict(event)
                    for event in _as_tuple(item.get("protection_trace_events"))
                    if isinstance(event, Mapping) and event.get("event_id")
                }
                selected_trace_events: list[dict[str, Any]] = []
                for event_id in event_ids:
                    event = item_trace_events.get(event_id) or trace_events_by_id.get(
                        event_id
                    )
                    if event is None:
                        continue
                    linked_lineage_id = str(event.get("linked_lineage_id") or "")
                    if (
                        lineage_id
                        and linked_lineage_id
                        and lineage_id != linked_lineage_id
                    ):
                        raise ValueError(
                            f"protection event {event_id} is linked to a different "
                            "functional-group lineage"
                        )
                    selected_trace_events.append(event)
                if selected_trace_events:
                    enriched["protection_trace_events"] = selected_trace_events
                if not any(
                    enriched.get(name) is not None
                    for name in ("node_paths", "reaction_node_paths")
                ):
                    reaction_paths = source.get("reaction_node_paths")
                    if reaction_paths is not None:
                        enriched["node_paths"] = reaction_paths
                candidates.append(enriched)
            for lineage_id, group in sorted(groups_by_lineage.items()):
                if lineage_id in represented_lineages:
                    continue
                synthesized = dict(group)
                synthesized.setdefault("site_token", group.get("token") or "")
                synthesized.setdefault(
                    "fg_transition_status",
                    group.get("transition_status") or "",
                )
                synthesized.setdefault(
                    "protection_transition",
                    group.get("protection_transition") or "",
                )
                reaction_paths = source.get("reaction_node_paths")
                if reaction_paths is not None:
                    synthesized.setdefault("node_paths", reaction_paths)
                candidates.append(synthesized)
        else:
            groups = _first(
                source,
                (
                    "functional_groups",
                    "fg_observations",
                    "functional_group_observations",
                    "groups",
                ),
                (),
            )
            for group in _as_tuple(groups):
                if not isinstance(group, Mapping):
                    continue
                synthesized = dict(group)
                synthesized.setdefault("site_token", group.get("token") or "")
                if group.get("reaction_node_path") is not None:
                    synthesized.setdefault("node_paths", [group["reaction_node_path"]])
                candidates.append(synthesized)
    return tuple(
        ProtectionEvidence.from_mapping(item)
        for item in candidates
        if isinstance(item, Mapping)
    )


def _node_paths(value: Mapping[str, Any], key: str) -> tuple[tuple[int, ...], ...]:
    if key == "reaction_node_paths" and value.get("reaction_node_path") is not None:
        return (_path(value["reaction_node_path"]),)
    if key == "molecule_node_paths":
        molecule_path = _first(
            value,
            ("molecule_node_path", "target_molecule_path"),
        )
        if molecule_path is not None:
            return (_path(molecule_path),)
    explicit = value.get(key)
    if explicit is not None:
        return _paths(explicit)

    interval_steps: list[tuple[int, int, int, Mapping[str, Any]]] = []
    for role, collection_name in enumerate(("selected_steps", "skipped_steps")):
        for ordinal, step in enumerate(value.get(collection_name) or ()):
            if not isinstance(step, Mapping):
                continue
            position = _first(
                step,
                ("path_position", "reaction_index", "step_index", "position"),
            )
            if position is None:
                raise ValueError(
                    f"{collection_name}[{ordinal}] has no interval position"
                )
            interval_steps.append((int(position), role, ordinal, step))
    ordered_interval = tuple(item[-1] for item in sorted(interval_steps))
    if key == "reaction_node_paths" and ordered_interval:
        return tuple(_path(step["reaction_node_path"]) for step in ordered_interval)
    if key == "molecule_node_paths":
        source_matches = value.get("source_matches") or ordered_interval
        paths: list[tuple[int, ...]] = []
        for step in source_matches:
            if not isinstance(step, Mapping):
                continue
            path = _first(
                step,
                ("target_molecule_path", "molecule_node_path", "node_path"),
            )
            if path is not None:
                paths.append(_path(path))
        return tuple(paths)

    step_key = {
        "reaction_node_paths": "selected_steps",
        "selected_reaction_node_paths": "selected_steps",
        "skipped_reaction_node_paths": "skipped_steps",
        "molecule_node_paths": "molecule_nodes",
    }.get(key)
    if not step_key:
        return ()
    return tuple(
        _path(
            step["reaction_node_path"]
            if "reaction_node_path" in step
            else step["node_path"]
        )
        for step in value.get(step_key) or ()
        if isinstance(step, Mapping)
        and ("reaction_node_path" in step or "node_path" in step)
    )


@dataclass(frozen=True)
class ReferenceOccurrence:
    """One exact corpus occurrence and its nested evidence identities."""

    occurrence_id: str
    occurrence_kind: str
    dataset_id: str
    source_identity: str
    route_id: str
    base_keys: tuple[str, ...]
    local_keys: tuple[str, ...]
    functional_groups: tuple[FunctionalGroupEvidence, ...] = ()
    explicit_joint_tokens: tuple[str, ...] = ()
    source_records: tuple[SourceRecord, ...] = ()
    route_target_smiles: str = ""
    segment_target_smiles: str = ""
    target_smiles: str = ""
    root_index: int | None = None
    branch_index: int | None = None
    branch_indices: tuple[int, ...] = ()
    start_position: int | None = None
    end_position: int | None = None
    reaction_node_paths: tuple[tuple[int, ...], ...] = ()
    molecule_node_paths: tuple[tuple[int, ...], ...] = ()
    selected_reaction_node_paths: tuple[tuple[int, ...], ...] = ()
    skipped_reaction_node_paths: tuple[tuple[int, ...], ...] = ()
    context_history_id: str = ""
    analysis_only: bool = False
    factorability: str = ""
    factorability_certified: bool = False
    gap_evidence: Mapping[str, Any] = field(
        default_factory=dict, compare=False, hash=False
    )
    protection_evidence: tuple[ProtectionEvidence, ...] = ()
    embedded_composites: tuple[CertifiedCompositeLink, ...] = ()
    payload_schema_version: int = 1
    schema_version: int = REFERENCE_OCCURRENCE_SCHEMA_VERSION
    payload: Mapping[str, Any] = field(default_factory=dict, compare=False, hash=False)

    def __post_init__(self) -> None:
        if self.schema_version != REFERENCE_OCCURRENCE_SCHEMA_VERSION:
            raise ValueError(
                f"unsupported reference occurrence schema version: {self.schema_version}"
            )
        if not self.occurrence_id:
            raise ValueError("occurrence_id is required")
        if self.occurrence_kind not in OCCURRENCE_KINDS:
            raise ValueError(f"unsupported occurrence kind: {self.occurrence_kind}")
        if not self.dataset_id or not self.source_identity or not self.route_id:
            raise ValueError("dataset_id, source_identity, and route_id are required")
        ordered_identity_signature(self.base_keys)
        ordered_identity_signature(self.local_keys)
        if len(self.base_keys) != len(self.local_keys):
            raise ValueError("base and local identity sequences must have equal length")
        identity_length = len(self.base_keys)
        if len(set(self.reaction_node_paths)) != len(self.reaction_node_paths):
            raise ValueError("reaction_node_paths must be unique")
        if len(set(self.selected_reaction_node_paths)) != len(
            self.selected_reaction_node_paths
        ):
            raise ValueError("selected reaction node paths must be unique")
        if len(set(self.skipped_reaction_node_paths)) != len(
            self.skipped_reaction_node_paths
        ):
            raise ValueError("skipped reaction node paths must be unique")
        if self.occurrence_kind == T1_KIND:
            if identity_length != 1:
                raise ValueError("t1 occurrences must contain exactly one identity key")
            if len(self.reaction_node_paths) != 1:
                raise ValueError(
                    "t1 occurrences require exactly one reaction node path"
                )
        elif self.occurrence_kind == RRSEQ_CONS_KIND:
            if len(self.reaction_node_paths) != identity_length:
                raise ValueError(
                    "RRseq_cons identity length must equal reaction_node_paths length"
                )
            if self.selected_reaction_node_paths and (
                self.selected_reaction_node_paths != self.reaction_node_paths
            ):
                raise ValueError(
                    "RRseq_cons selected reaction paths must equal its exact path"
                )
            if self.skipped_reaction_node_paths:
                raise ValueError("RRseq_cons occurrences cannot contain skipped paths")
            if (self.start_position is None) != (self.end_position is None):
                raise ValueError(
                    "RRseq_cons occurrence bounds must be both present or both absent"
                )
            if self.start_position is not None and (
                self.end_position - self.start_position != identity_length
            ):
                raise ValueError(
                    "RRseq_cons identity length does not match occurrence bounds"
                )
        else:
            if len(self.selected_reaction_node_paths) != identity_length:
                raise ValueError(
                    "RRseq_gap identity length must equal selected reaction paths"
                )
            selected = set(self.selected_reaction_node_paths)
            skipped = set(self.skipped_reaction_node_paths)
            if selected & skipped:
                raise ValueError(
                    "RRseq_gap selected and skipped reaction paths must be disjoint"
                )
            if set(self.reaction_node_paths) != selected | skipped:
                raise ValueError(
                    "RRseq_gap exact reaction path must equal selected plus skipped paths"
                )
        if self.occurrence_kind == RRSEQ_GAP_KIND and not self.analysis_only:
            raise ValueError("RRseq_gap occurrences must be marked analysis_only")
        if self.occurrence_kind != RRSEQ_GAP_KIND and self.analysis_only:
            raise ValueError("only RRseq_gap occurrences may be marked analysis_only")
        if self.occurrence_kind != RRSEQ_GAP_KIND and (
            self.factorability or self.factorability_certified or self.gap_evidence
        ):
            raise ValueError("factorability evidence is only valid for RRseq_gap")
        if self.end_position is not None and self.start_position is not None:
            if self.end_position <= self.start_position:
                raise ValueError("end_position must be greater than start_position")

    @property
    def base_signature(self) -> str:
        return ordered_identity_signature(self.base_keys)

    @property
    def local_signature(self) -> str:
        return ordered_identity_signature(self.local_keys)

    @property
    def joint_tokens(self) -> tuple[str, ...]:
        if self.explicit_joint_tokens:
            return self.explicit_joint_tokens
        return tuple(
            observation.context_token
            for observation in self.functional_groups
            if observation.include_in_joint_context and observation.location != "center"
        )

    @property
    def joint_signature(self) -> str:
        return joint_token_signature(self.joint_tokens)

    @classmethod
    def from_mapping(
        cls,
        value: Mapping[str, Any],
        *,
        context_history: Mapping[str, Any] | None = None,
        dataset_id: str | None = None,
    ) -> "ReferenceOccurrence":
        kind = infer_occurrence_kind(value)
        validate_native_occurrence_payload(value, kind=kind)
        exact_reaction_paths = _node_paths(value, "reaction_node_paths")
        if context_history is not None:
            occurrence_id = str(value.get("occurrence_id") or "")
            projected_occurrence_id = str(context_history.get("occurrence_id") or "")
            evidence_fields = {
                "functional_group_observations",
                "functional_groups",
                "fg_observations",
                "groups",
                "protection_evidence",
                "protection_trace_events",
                "interval_lineages",
            }
            carries_occurrence_evidence = bool(
                evidence_fields.intersection(context_history)
            )
            if carries_occurrence_evidence and (
                not projected_occurrence_id
                or context_history.get("reaction_node_paths") is None
                or not str(context_history.get("context_history_id") or "")
                or not str(context_history.get("route_context_history_id") or "")
            ):
                raise ValueError(
                    "context evidence requires an exact occurrence projection"
                )
            if (
                occurrence_id
                and projected_occurrence_id
                and occurrence_id != projected_occurrence_id
            ):
                raise ValueError("projected context history occurrence_id mismatch")

            projected_paths = context_history.get("reaction_node_paths")
            if projected_paths is not None and _paths(projected_paths) != (
                exact_reaction_paths
            ):
                raise ValueError(
                    "projected context history reaction_node_paths mismatch"
                )

            occurrence_route_refs = {
                str(value.get(field) or "")
                for field in ("context_history_ref", "route_context_history_id")
            }
            occurrence_route_refs.discard("")
            if len(occurrence_route_refs) > 1:
                raise ValueError("occurrence route context-history references disagree")
            projected_route_ref = str(
                context_history.get("route_context_history_id") or ""
            )
            if occurrence_route_refs and projected_route_ref not in (
                "",
                next(iter(occurrence_route_refs)),
            ):
                raise ValueError("projected route context-history reference mismatch")

            occurrence_projection_ref = str(
                value.get("context_history_projection_id") or ""
            )
            projected_projection_ref = str(
                context_history.get("context_history_id") or ""
            )
            if (
                occurrence_projection_ref
                and projected_projection_ref
                and occurrence_projection_ref != projected_projection_ref
            ):
                raise ValueError(
                    "projected occurrence context-history reference mismatch"
                )
        base_keys = _identity_keys(value, level="base", kind=kind)
        local_keys = _identity_keys(value, level="local", kind=kind)
        if not base_keys:
            raise ValueError(
                f"occurrence {value.get('occurrence_id', '')} has no base identity"
            )
        if not local_keys:
            raise ValueError(
                f"occurrence {value.get('occurrence_id', '')} has no local identity"
            )

        functional_groups = _functional_group_rows(value, context_history)
        explicit_tokens = (
            ()
            if context_history is not None
            else _string_tuple(
                _first(
                    value,
                    ("joint_fg_tokens", "joint_context_tokens", "joint_tokens"),
                    (),
                )
            )
        )
        protection = _protection_rows(value, context_history)

        embedded_raw = _first(
            value,
            ("certified_composites", "composite_certificates", "composite_links"),
            (),
        )
        embedded = tuple(
            CertifiedCompositeLink.from_mapping(
                {"occurrence_id": value.get("occurrence_id"), **item}
            )
            for item in _as_tuple(embedded_raw)
            if isinstance(item, Mapping)
        )

        classification = value.get("classification")
        if isinstance(classification, Mapping):
            factorability = str(
                _first(classification, ("classification", "factorability", "label"), "")
                or ""
            )
            factorability_certified = _bool(classification.get("certified"))
            gap_evidence: Mapping[str, Any] = dict(classification)
        else:
            factorability = str(
                _first(
                    value,
                    ("factorability",),
                    classification if isinstance(classification, str) else "",
                )
                or ""
            )
            factorability_certified = _bool(
                _first(value, ("factorability_certified", "certified"), False)
            )
            gap_evidence = dict(value.get("gap_evidence") or {})

        source_rows = _source_rows(value)
        source_records = tuple(SourceRecord.from_mapping(row) for row in source_rows)
        root = value.get("root_index")
        branch = value.get("branch_index")
        start = value.get("start_position")
        end = value.get("end_position")
        history_id = str(
            _first(value, ("context_history_id", "context_history_ref"), "") or ""
        )
        if not history_id and context_history is not None:
            history_id = str(
                _first(context_history, ("context_history_id", "history_id"), "") or ""
            )
        occurrence_dataset = str(value.get("dataset_id") or "")
        history_dataset = str((context_history or {}).get("dataset_id") or "")
        occurrence_source = str(value.get("source_identity") or "")
        history_source = str((context_history or {}).get("source_identity") or "")
        occurrence_route = str(value.get("route_id") or "")
        history_route = str((context_history or {}).get("route_id") or "")
        for field_name, occurrence_value, history_value in (
            ("dataset_id", occurrence_dataset, history_dataset),
            ("source_identity", occurrence_source, history_source),
            ("route_id", occurrence_route, history_route),
        ):
            if occurrence_value and history_value and occurrence_value != history_value:
                raise ValueError(
                    f"occurrence/context-history {field_name} mismatch: "
                    f"{occurrence_value!r} != {history_value!r}"
                )

        return cls(
            occurrence_id=str(value.get("occurrence_id") or ""),
            occurrence_kind=kind,
            dataset_id=str(occurrence_dataset or history_dataset or dataset_id or ""),
            source_identity=str(occurrence_source or history_source or ""),
            route_id=str(occurrence_route or history_route or ""),
            base_keys=base_keys,
            local_keys=local_keys,
            functional_groups=functional_groups,
            explicit_joint_tokens=explicit_tokens,
            source_records=source_records,
            route_target_smiles=str(value.get("route_target_smiles") or ""),
            segment_target_smiles=str(value.get("segment_target_smiles") or ""),
            target_smiles=str(
                _first(value, ("target_smiles", "target_molecule"), "") or ""
            ),
            root_index=None if root is None else int(root),
            branch_index=None if branch is None else int(branch),
            branch_indices=tuple(
                int(index) for index in _as_tuple(value.get("branch_indices"))
            ),
            start_position=None if start is None else int(start),
            end_position=None if end is None else int(end),
            reaction_node_paths=exact_reaction_paths,
            molecule_node_paths=_node_paths(value, "molecule_node_paths"),
            selected_reaction_node_paths=_node_paths(
                value, "selected_reaction_node_paths"
            ),
            skipped_reaction_node_paths=_node_paths(
                value, "skipped_reaction_node_paths"
            ),
            context_history_id=history_id,
            analysis_only=(kind == RRSEQ_GAP_KIND),
            factorability=factorability if kind == RRSEQ_GAP_KIND else "",
            factorability_certified=(
                factorability_certified if kind == RRSEQ_GAP_KIND else False
            ),
            gap_evidence=gap_evidence if kind == RRSEQ_GAP_KIND else {},
            protection_evidence=protection,
            embedded_composites=embedded,
            payload_schema_version=int(value.get("schema_version", 1)),
            payload=dict(value),
        )

    def content_digest(self) -> str:
        """Return a deterministic digest used to reject conflicting duplicates."""

        payload = {
            "occurrence_id": self.occurrence_id,
            "kind": self.occurrence_kind,
            "dataset_id": self.dataset_id,
            "source_identity": self.source_identity,
            "route_id": self.route_id,
            "route_target_smiles": self.route_target_smiles,
            "segment_target_smiles": self.segment_target_smiles,
            "target_smiles": self.target_smiles,
            "root_index": self.root_index,
            "branch_index": self.branch_index,
            "branch_indices": self.branch_indices,
            "start_position": self.start_position,
            "end_position": self.end_position,
            "base_keys": self.base_keys,
            "local_keys": self.local_keys,
            "joint_tokens": sorted(joint_token_counter(self.joint_tokens).items()),
            "source_records": [record.to_dict() for record in self.source_records],
            "reaction_node_paths": self.reaction_node_paths,
            "molecule_node_paths": self.molecule_node_paths,
            "selected_reaction_node_paths": self.selected_reaction_node_paths,
            "skipped_reaction_node_paths": self.skipped_reaction_node_paths,
            "context_history_id": self.context_history_id,
            "analysis_only": self.analysis_only,
            "factorability": self.factorability,
            "factorability_certified": self.factorability_certified,
            "gap_evidence": self.gap_evidence,
            "functional_groups": [item.to_dict() for item in self.functional_groups],
            "functional_group_payloads": [
                item.payload for item in self.functional_groups
            ],
            "protection_evidence": [
                item.to_dict() for item in self.protection_evidence
            ],
            "protection_payloads": [item.payload for item in self.protection_evidence],
            "payload_schema_version": self.payload_schema_version,
            "payload": self.payload,
        }
        return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class ReferenceIndexMetadata:
    """Reproducibility metadata stored inside one reference index."""

    vocabulary_version: str
    vocabulary_hash: str
    config_hash: str
    input_schema_versions: Mapping[str, int]
    reference_scope: str = REFERENCE_SCOPE
    schema_version: int = REFERENCE_INDEX_SCHEMA_VERSION
    extra: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.schema_version != REFERENCE_INDEX_SCHEMA_VERSION:
            raise ValueError(
                f"unsupported reference index schema version: {self.schema_version}"
            )
        if self.reference_scope != REFERENCE_SCOPE:
            raise ValueError("reference indexes require reference_scope='all_data'")
        if (
            not self.vocabulary_version
            or not self.vocabulary_hash
            or not self.config_hash
        ):
            raise ValueError("vocabulary version/hash and config hash are required")
        if not self.input_schema_versions:
            raise ValueError("input_schema_versions must not be empty")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "reference_scope": self.reference_scope,
            "vocabulary_version": self.vocabulary_version,
            "vocabulary_hash": self.vocabulary_hash,
            "config_hash": self.config_hash,
            "input_schema_versions": dict(sorted(self.input_schema_versions.items())),
            "extra": dict(self.extra),
        }


__all__ = [
    "CERTIFIED_COMPOSITE_STATUSES",
    "CertifiedCompositeLink",
    "FunctionalGroupEvidence",
    "OCCURRENCE_KINDS",
    "ProtectionEvidence",
    "REFERENCE_INDEX_SCHEMA_VERSION",
    "REFERENCE_OCCURRENCE_SCHEMA_VERSION",
    "REFERENCE_SCOPE",
    "RRSEQ_CONS_KIND",
    "RRSEQ_GAP_KIND",
    "ReferenceIndexMetadata",
    "ReferenceOccurrence",
    "SourceRecord",
    "T1_KIND",
    "canonical_json",
    "infer_occurrence_kind",
    "joint_token_counter",
    "joint_token_signature",
    "ordered_identity_signature",
    "validate_native_occurrence_payload",
]
