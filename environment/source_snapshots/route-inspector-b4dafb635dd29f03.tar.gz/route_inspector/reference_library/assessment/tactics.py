"""Exact known/novel assessment for one route's extracted tactics."""

from __future__ import annotations

import math
from collections import defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any, ClassVar

from route_inspector.reference_library.assessment.bigrams import (
    BIGRAM_COMPONENT_UNAVAILABLE_LIMITATION,
    RetroBleuBigramAssessment,
)
from route_inspector.reference_library.catalog import ReferenceTacticLibrary
from route_inspector.reference_library.models import (
    ReferenceRouteKey,
    TacticIdentity,
    TacticOccurrence,
)
from route_inspector.reference_library.records import TacticLibraryEntry

ROUTE_TACTIC_ASSESSMENT_SCHEMA_VERSION = 2

TACTIC_KINDS = (
    "rrseq_cons",
    "rrseq_gap",
    "rrsubtree_cons",
    "rrsubtree_gap",
)
TACTIC_FAMILIES = ("rrseq", "rrsubtree")
_KIND_TO_FAMILY = {
    "rrseq_cons": "rrseq",
    "rrseq_gap": "rrseq",
    "rrsubtree_cons": "rrsubtree",
    "rrsubtree_gap": "rrsubtree",
}
ASSESSMENT_STATUSES = frozenset(
    {
        "fully_covered",
        "partially_novel",
        "tactic_novel",
        "no_extracted_tactics",
        "assessment_incomplete",
    }
)
NO_EXTRACTED_TACTICS_LIMITATION = (
    "No RRSeq or RRSubtree tactic was extracted under the current definitions; "
    "this does not mean that the route contains no synthetic tactic."
)
INCOMPLETE_ASSESSMENT_LIMITATION = (
    "Tactic extraction was incomplete; the reported coverage and novelty counts "
    "are partial and must not be interpreted as a complete route assessment."
)


def _coverage_fraction(numerator: int, denominator: int) -> float | None:
    return None if denominator == 0 else numerator / denominator


@dataclass(frozen=True)
class TacticMatch:
    """One exact query occurrence and its exact reference-library match, if any."""

    occurrence: TacticOccurrence
    reference_entry: TacticLibraryEntry | None

    def __post_init__(self) -> None:
        if self.reference_entry is not None and not (
            self.reference_entry.identity.equivalent_to(self.occurrence.identity)
        ):
            raise ValueError(
                "reference entry is not exactly equivalent to the query occurrence"
            )

    @property
    def known(self) -> bool:
        """Return whether this exact occurrence identity exists in the library."""

        return self.reference_entry is not None

    @property
    def reference_support(self) -> dict[str, Any] | None:
        """Return a compact support view while retaining the complete entry."""

        entry = self.reference_entry
        if entry is None:
            return None
        return {
            "occurrence_count": entry.occurrence_count,
            "route_count": entry.route_count,
            "representative_occurrence_id": entry.representative_occurrence_id,
            "reference_routes": [route.to_dict() for route in entry.reference_routes],
            "route_target_smiles": list(entry.route_target_smiles),
            "motif_target_smiles": list(entry.motif_target_smiles),
        }

    def to_dict(self) -> dict[str, Any]:
        """Return a lossless JSON-compatible representation."""

        return {
            "occurrence": self.occurrence.to_dict(),
            "known": self.known,
            "reference_entry": (
                None if self.reference_entry is None else self.reference_entry.to_dict()
            ),
            "reference_support": self.reference_support,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TacticMatch":
        """Restore and validate a serialized match."""

        raw_entry = value.get("reference_entry")
        result = cls(
            occurrence=TacticOccurrence.from_dict(value["occurrence"]),
            reference_entry=(
                None if raw_entry is None else TacticLibraryEntry.from_dict(raw_entry)
            ),
        )
        if "known" in value and bool(value["known"]) != result.known:
            raise ValueError("serialized known flag disagrees with reference entry")
        if (
            "reference_support" in value
            and value["reference_support"] != result.reference_support
        ):
            raise ValueError(
                "serialized reference support disagrees with reference entry"
            )
        return result


@dataclass(frozen=True)
class TacticCoverage:
    """Occurrence-level and exact-identity coverage for one tactic scope."""

    scope: str
    occurrence_count: int
    unique_identity_count: int
    known_occurrence_count: int
    novel_occurrence_count: int
    known_unique_identity_count: int
    novel_unique_identity_count: int
    occurrence_coverage_numerator: int
    occurrence_coverage_denominator: int
    occurrence_coverage_fraction: float | None
    unique_coverage_numerator: int
    unique_coverage_denominator: int
    unique_coverage_fraction: float | None

    _COUNT_FIELDS: ClassVar[tuple[str, ...]] = (
        "occurrence_count",
        "unique_identity_count",
        "known_occurrence_count",
        "novel_occurrence_count",
        "known_unique_identity_count",
        "novel_unique_identity_count",
        "occurrence_coverage_numerator",
        "occurrence_coverage_denominator",
        "unique_coverage_numerator",
        "unique_coverage_denominator",
    )

    def __post_init__(self) -> None:
        if not self.scope:
            raise ValueError("coverage scope must not be empty")
        for name in self._COUNT_FIELDS:
            if int(getattr(self, name)) < 0:
                raise ValueError(f"{name} must be non-negative")
        if self.known_occurrence_count + self.novel_occurrence_count != (
            self.occurrence_count
        ):
            raise ValueError("known and novel occurrence counts do not account exactly")
        if (
            self.known_unique_identity_count + self.novel_unique_identity_count
            != self.unique_identity_count
        ):
            raise ValueError("known and novel unique counts do not account exactly")
        if (
            self.occurrence_coverage_numerator != self.known_occurrence_count
            or self.occurrence_coverage_denominator != self.occurrence_count
        ):
            raise ValueError("occurrence coverage ratio disagrees with counts")
        if (
            self.unique_coverage_numerator != self.known_unique_identity_count
            or self.unique_coverage_denominator != self.unique_identity_count
        ):
            raise ValueError("unique coverage ratio disagrees with counts")
        self._validate_fraction(
            self.occurrence_coverage_fraction,
            numerator=self.occurrence_coverage_numerator,
            denominator=self.occurrence_coverage_denominator,
            label="occurrence",
        )
        self._validate_fraction(
            self.unique_coverage_fraction,
            numerator=self.unique_coverage_numerator,
            denominator=self.unique_coverage_denominator,
            label="unique",
        )

    @staticmethod
    def _validate_fraction(
        value: float | None,
        *,
        numerator: int,
        denominator: int,
        label: str,
    ) -> None:
        expected = _coverage_fraction(numerator, denominator)
        if expected is None:
            if value is not None:
                raise ValueError(f"zero-denominator {label} coverage must be None")
            return
        if value is None or not math.isclose(value, expected, rel_tol=0, abs_tol=1e-15):
            raise ValueError(f"{label} coverage fraction disagrees with counts")

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-compatible coverage record."""

        return {
            "scope": self.scope,
            **{name: getattr(self, name) for name in self._COUNT_FIELDS},
            "occurrence_coverage_fraction": self.occurrence_coverage_fraction,
            "unique_coverage_fraction": self.unique_coverage_fraction,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TacticCoverage":
        """Restore and validate a serialized coverage record."""

        return cls(
            scope=str(value["scope"]),
            **{name: int(value[name]) for name in cls._COUNT_FIELDS},
            occurrence_coverage_fraction=(
                None
                if value.get("occurrence_coverage_fraction") is None
                else float(value["occurrence_coverage_fraction"])
            ),
            unique_coverage_fraction=(
                None
                if value.get("unique_coverage_fraction") is None
                else float(value["unique_coverage_fraction"])
            ),
        )


def _identity_bucket(identity: TacticIdentity) -> tuple[str, int, str]:
    return (identity.kind, identity.identity_version, identity.lookup_key)


def _unique_match_states(matches: Iterable[TacticMatch]) -> tuple[bool, ...]:
    """Group by a coarse key, then require authoritative exact equivalence."""

    groups: dict[tuple[str, int, str], list[tuple[TacticIdentity, bool]]] = defaultdict(
        list
    )
    for match in matches:
        identity = match.occurrence.identity
        bucket = groups[_identity_bucket(identity)]
        for representative, known in bucket:
            if not representative.equivalent_to(identity):
                continue
            if known != match.known:
                raise RuntimeError(
                    "equivalent query identities received inconsistent library matches"
                )
            break
        else:
            bucket.append((identity, match.known))
    return tuple(known for key in sorted(groups) for _identity, known in groups[key])


def _coverage(scope: str, matches: Iterable[TacticMatch]) -> TacticCoverage:
    selected = tuple(matches)
    unique_states = _unique_match_states(selected)
    known_occurrences = sum(match.known for match in selected)
    known_unique = sum(unique_states)
    occurrence_count = len(selected)
    unique_count = len(unique_states)
    return TacticCoverage(
        scope=scope,
        occurrence_count=occurrence_count,
        unique_identity_count=unique_count,
        known_occurrence_count=known_occurrences,
        novel_occurrence_count=occurrence_count - known_occurrences,
        known_unique_identity_count=known_unique,
        novel_unique_identity_count=unique_count - known_unique,
        occurrence_coverage_numerator=known_occurrences,
        occurrence_coverage_denominator=occurrence_count,
        occurrence_coverage_fraction=_coverage_fraction(
            known_occurrences, occurrence_count
        ),
        unique_coverage_numerator=known_unique,
        unique_coverage_denominator=unique_count,
        unique_coverage_fraction=_coverage_fraction(known_unique, unique_count),
    )


@dataclass(frozen=True)
class RouteTacticAssessment:
    """Known/novel tactic assessment for exactly one source route."""

    route: ReferenceRouteKey
    status: str
    extraction_complete: bool
    matches: tuple[TacticMatch, ...]
    overall: TacticCoverage
    by_family: Mapping[str, TacticCoverage]
    by_kind: Mapping[str, TacticCoverage]
    retro_bleu_bigrams: RetroBleuBigramAssessment
    errors: tuple[Mapping[str, Any], ...] = ()
    limitation: str | None = None
    schema_version: int = ROUTE_TACTIC_ASSESSMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != ROUTE_TACTIC_ASSESSMENT_SCHEMA_VERSION:
            raise ValueError(
                f"unsupported assessment schema version: {self.schema_version}"
            )
        if self.status not in ASSESSMENT_STATUSES:
            raise ValueError(f"unsupported route assessment status: {self.status}")
        if set(self.by_family) != set(TACTIC_FAMILIES):
            raise ValueError("family coverage must contain rrseq and rrsubtree")
        if set(self.by_kind) != set(TACTIC_KINDS):
            raise ValueError("kind coverage must contain all four tactic kinds")
        if not isinstance(self.retro_bleu_bigrams, RetroBleuBigramAssessment):
            raise TypeError("retro_bleu_bigrams must be RetroBleuBigramAssessment")
        if self.overall.scope != "overall":
            raise ValueError("overall coverage has the wrong scope")
        for family, coverage in self.by_family.items():
            if coverage.scope != family:
                raise ValueError("family coverage scope disagrees with its key")
        for kind, coverage in self.by_kind.items():
            if coverage.scope != kind:
                raise ValueError("kind coverage scope disagrees with its key")
        if any(match.occurrence.route != self.route for match in self.matches):
            raise ValueError("every assessed occurrence must belong to the route")
        expected_rrseq_cons = any(
            match.occurrence.identity.kind == "rrseq_cons" for match in self.matches
        )
        expected_rrseq_gap = any(
            match.occurrence.identity.kind == "rrseq_gap" for match in self.matches
        )
        if (
            self.retro_bleu_bigrams.query_has_rrseq_cons != expected_rrseq_cons
            or self.retro_bleu_bigrams.query_has_rrseq_gap != expected_rrseq_gap
        ):
            raise ValueError(
                "bigram query RRSeq presence disagrees with tactic occurrences"
            )
        if self.extraction_complete and self.errors:
            raise ValueError("an assessment with extraction errors cannot be complete")
        expected_overall = _coverage("overall", self.matches)
        expected_by_kind = {
            kind: _coverage(
                kind,
                (
                    match
                    for match in self.matches
                    if match.occurrence.identity.kind == kind
                ),
            )
            for kind in TACTIC_KINDS
        }
        expected_by_family = {
            family: _coverage(
                family,
                (
                    match
                    for match in self.matches
                    if _KIND_TO_FAMILY[match.occurrence.identity.kind] == family
                ),
            )
            for family in TACTIC_FAMILIES
        }
        if self.overall != expected_overall:
            raise ValueError("overall coverage disagrees with exact matches")
        if dict(self.by_kind) != expected_by_kind:
            raise ValueError("kind coverage disagrees with exact matches")
        if dict(self.by_family) != expected_by_family:
            raise ValueError("family coverage disagrees with exact matches")
        expected_status = _assessment_status(
            self.overall,
            extraction_complete=self.extraction_complete,
            has_errors=bool(self.errors),
        )
        if self.status != expected_status:
            raise ValueError("assessment status disagrees with completeness and counts")
        if self.status == "no_extracted_tactics":
            if self.limitation != NO_EXTRACTED_TACTICS_LIMITATION:
                raise ValueError(
                    "no_extracted_tactics requires its explicit scientific limitation"
                )
        elif self.status == "assessment_incomplete":
            if self.limitation != INCOMPLETE_ASSESSMENT_LIMITATION:
                raise ValueError(
                    "assessment_incomplete requires its explicit limitation"
                )
        elif self.limitation is not None:
            raise ValueError("complete tactic assessments must not carry a limitation")

    def to_dict(self) -> dict[str, Any]:
        """Return a deterministic, lossless JSON-compatible representation."""

        return {
            "schema_version": self.schema_version,
            "route": self.route.to_dict(),
            "status": self.status,
            "extraction_complete": self.extraction_complete,
            "matches": [match.to_dict() for match in self.matches],
            "overall": self.overall.to_dict(),
            "by_family": {
                family: self.by_family[family].to_dict() for family in TACTIC_FAMILIES
            },
            "by_kind": {kind: self.by_kind[kind].to_dict() for kind in TACTIC_KINDS},
            "retro_bleu_bigrams": self.retro_bleu_bigrams.to_dict(),
            "errors": [dict(error) for error in self.errors],
            "limitation": self.limitation,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RouteTacticAssessment":
        """Restore and validate a serialized route assessment."""
        schema_version = int(value.get("schema_version", -1))
        matches = tuple(TacticMatch.from_dict(item) for item in value["matches"])
        raw_bigram = value.get("retro_bleu_bigrams")
        if schema_version == 1 and raw_bigram is None:
            bigram_assessment = RetroBleuBigramAssessment(
                availability="library_component_unavailable",
                query_has_rrseq_cons=any(
                    match.occurrence.identity.kind == "rrseq_cons" for match in matches
                ),
                query_has_rrseq_gap=any(
                    match.occurrence.identity.kind == "rrseq_gap" for match in matches
                ),
                limitation=BIGRAM_COMPONENT_UNAVAILABLE_LIMITATION,
            )
        elif schema_version == ROUTE_TACTIC_ASSESSMENT_SCHEMA_VERSION and isinstance(
            raw_bigram,
            Mapping,
        ):
            bigram_assessment = RetroBleuBigramAssessment.from_dict(raw_bigram)
        else:
            raise ValueError(f"unsupported assessment schema version: {schema_version}")
        return cls(
            schema_version=ROUTE_TACTIC_ASSESSMENT_SCHEMA_VERSION,
            route=ReferenceRouteKey.from_dict(value["route"]),
            status=str(value["status"]),
            extraction_complete=bool(value["extraction_complete"]),
            matches=matches,
            overall=TacticCoverage.from_dict(value["overall"]),
            by_family={
                str(key): TacticCoverage.from_dict(item)
                for key, item in value["by_family"].items()
            },
            by_kind={
                str(key): TacticCoverage.from_dict(item)
                for key, item in value["by_kind"].items()
            },
            retro_bleu_bigrams=bigram_assessment,
            errors=tuple(dict(error) for error in value.get("errors", ())),
            limitation=(
                None if value.get("limitation") is None else str(value["limitation"])
            ),
        )


def _assessment_status(
    coverage: TacticCoverage,
    *,
    extraction_complete: bool,
    has_errors: bool,
) -> str:
    if not extraction_complete or has_errors:
        return "assessment_incomplete"
    if coverage.occurrence_count == 0:
        return "no_extracted_tactics"
    if coverage.known_occurrence_count == coverage.occurrence_count:
        return "fully_covered"
    if coverage.known_occurrence_count == 0:
        return "tactic_novel"
    return "partially_novel"


def assess_tactic_occurrences(
    occurrences: Iterable[TacticOccurrence],
    library: ReferenceTacticLibrary,
    *,
    route: ReferenceRouteKey | None = None,
    extraction_complete: bool = True,
    errors: Iterable[Mapping[str, Any]] = (),
    retro_bleu_bigrams: RetroBleuBigramAssessment | None = None,
) -> RouteTacticAssessment:
    """Assess exact RRSeq/RRSubtree occurrences against a reference library.

    The library first selects a coarse lookup group, then confirms authoritative
    identity equivalence.  This function independently follows the same two-step
    rule when counting unique query identities.  Consequently, neither lookup-key
    nor hash equality alone can create a known match or collapse two query tactics.
    """

    ordered = tuple(
        sorted(
            occurrences,
            key=lambda item: (
                item.identity.kind,
                item.route.dataset_id,
                item.route.source_identity,
                item.route.route_id,
                item.occurrence_id,
            ),
        )
    )
    if any(item.identity.kind not in _KIND_TO_FAMILY for item in ordered):
        invalid = sorted(
            {
                item.identity.kind
                for item in ordered
                if item.identity.kind not in _KIND_TO_FAMILY
            }
        )
        raise ValueError(f"unsupported assessed tactic kind(s): {invalid}")
    reference_occurrence_ids = [item.reference_occurrence_id for item in ordered]
    if len(reference_occurrence_ids) != len(set(reference_occurrence_ids)):
        raise ValueError("assessed Reference occurrence IDs must be unique")

    occurrence_routes = {item.route for item in ordered}
    if route is None:
        if len(occurrence_routes) != 1:
            raise ValueError(
                "route is required when occurrences do not identify exactly one route"
            )
        route = next(iter(occurrence_routes))
    elif occurrence_routes and occurrence_routes != {route}:
        raise ValueError("assessed occurrences belong to a different route")

    normalized_errors = tuple(dict(error) for error in errors)
    matches = tuple(
        TacticMatch(
            occurrence=occurrence,
            reference_entry=library.lookup(occurrence.identity),
        )
        for occurrence in ordered
    )
    overall = _coverage("overall", matches)
    by_kind = {
        kind: _coverage(
            kind,
            (match for match in matches if match.occurrence.identity.kind == kind),
        )
        for kind in TACTIC_KINDS
    }
    by_family = {
        family: _coverage(
            family,
            (
                match
                for match in matches
                if _KIND_TO_FAMILY[match.occurrence.identity.kind] == family
            ),
        )
        for family in TACTIC_FAMILIES
    }
    assessment_complete = bool(extraction_complete and not normalized_errors)
    status = _assessment_status(
        overall,
        extraction_complete=assessment_complete,
        has_errors=bool(normalized_errors),
    )
    limitation = (
        NO_EXTRACTED_TACTICS_LIMITATION
        if status == "no_extracted_tactics"
        else INCOMPLETE_ASSESSMENT_LIMITATION
        if status == "assessment_incomplete"
        else None
    )
    if retro_bleu_bigrams is None:
        retro_bleu_bigrams = RetroBleuBigramAssessment(
            availability="library_component_unavailable",
            query_has_rrseq_cons=any(
                match.occurrence.identity.kind == "rrseq_cons" for match in matches
            ),
            query_has_rrseq_gap=any(
                match.occurrence.identity.kind == "rrseq_gap" for match in matches
            ),
            limitation=BIGRAM_COMPONENT_UNAVAILABLE_LIMITATION,
        )
    return RouteTacticAssessment(
        route=route,
        status=status,
        extraction_complete=assessment_complete,
        matches=matches,
        overall=overall,
        by_family=by_family,
        by_kind=by_kind,
        retro_bleu_bigrams=retro_bleu_bigrams,
        errors=normalized_errors,
        limitation=limitation,
    )


__all__ = [
    "ASSESSMENT_STATUSES",
    "INCOMPLETE_ASSESSMENT_LIMITATION",
    "NO_EXTRACTED_TACTICS_LIMITATION",
    "ROUTE_TACTIC_ASSESSMENT_SCHEMA_VERSION",
    "RouteTacticAssessment",
    "TACTIC_FAMILIES",
    "TACTIC_KINDS",
    "TacticCoverage",
    "TacticMatch",
    "assess_tactic_occurrences",
]
