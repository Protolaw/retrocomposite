"""Assessment and comparison of reference evidence."""
