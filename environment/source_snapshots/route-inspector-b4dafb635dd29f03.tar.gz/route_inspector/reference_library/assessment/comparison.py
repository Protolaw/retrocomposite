"""Compare exact tactic identities in two persisted Reference libraries.

The default paths compare the canonical PaRoutes n1 and n5 libraries. Hashes
and lookup keys are candidate indexes only: tactic overlap follows the identity
contract persisted by each library (complete CGR-key payloads for format v3,
legacy graph equivalence for older libraries), while composite-rule overlap uses
the complete whitespace-normalized executable SMARTS.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import tempfile
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from route_inspector.composite_rules import CompositeDecompositionLibrary
from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.reference_library import (
    ReferenceTacticLibrary,
    TacticLibraryEntry,
)

TACTIC_KINDS = (
    "rrseq_cons",
    "rrseq_gap",
    "rrsubtree_cons",
    "rrsubtree_gap",
)
PANEL_ORDER = (*TACTIC_KINDS, "composite_rules")
REGION_ORDER = {"left_only": 0, "shared": 1, "right_only": 2}
REPORT_COLUMNS = (
    "region",
    "left_entry_id",
    "right_entry_id",
    "left_popularity",
    "right_popularity",
    "left_occurrence_count",
    "right_occurrence_count",
)


def _tactic_row(
    region: str,
    left: TacticLibraryEntry | None,
    right: TacticLibraryEntry | None,
) -> dict[str, Any]:
    return {
        "region": region,
        "left_entry_id": "" if left is None else left.entry_id,
        "right_entry_id": "" if right is None else right.entry_id,
        "left_popularity": "" if left is None else left.route_count,
        "right_popularity": "" if right is None else right.route_count,
        "left_occurrence_count": "" if left is None else left.occurrence_count,
        "right_occurrence_count": "" if right is None else right.occurrence_count,
    }


def compare_tactic_kind(
    left_library: ReferenceTacticLibrary,
    right_library: ReferenceTacticLibrary,
    kind: str,
) -> list[dict[str, Any]]:
    """Compare one tactic kind using exact library lookup semantics."""

    rows: list[dict[str, Any]] = []
    matched_right: set[str] = set()
    for left_entry in left_library.entries(kind):
        right_entry = right_library.lookup(left_entry.identity)
        if right_entry is None:
            rows.append(_tactic_row("left_only", left_entry, None))
            continue
        if right_entry.entry_id in matched_right:
            raise RuntimeError(
                "multiple left entries matched one exact right-library identity"
            )
        matched_right.add(right_entry.entry_id)
        rows.append(_tactic_row("shared", left_entry, right_entry))

    for right_entry in right_library.entries(kind):
        if right_entry.entry_id not in matched_right:
            rows.append(_tactic_row("right_only", None, right_entry))
    return _sort_rows(rows)


def _composite_row(region: str, left: Any | None, right: Any | None) -> dict[str, Any]:
    return {
        "region": region,
        "left_entry_id": "" if left is None else left.composite_id,
        "right_entry_id": "" if right is None else right.composite_id,
        "left_popularity": "" if left is None else left.route_count,
        "right_popularity": "" if right is None else right.route_count,
        "left_occurrence_count": "" if left is None else left.occurrence_count,
        "right_occurrence_count": "" if right is None else right.occurrence_count,
    }


def compare_composite_rules(
    left_library: CompositeDecompositionLibrary,
    right_library: CompositeDecompositionLibrary,
) -> list[dict[str, Any]]:
    """Compare versioned composite families without transferring certificates."""
    if (
        left_library.manifest.library_format_version
        != right_library.manifest.library_format_version
    ):
        raise ValueError(
            "composite identity versions differ; reindex companions before comparison"
        )

    def family_key(entry):
        return (
            entry.identity_key if entry.identity_version >= 2 else entry.normalized_rule
        )

    left_by_rule = {family_key(entry): entry for entry in left_library.entries()}
    right_by_rule = {family_key(entry): entry for entry in right_library.entries()}
    if len(left_by_rule) != len(left_library.entries()):
        raise RuntimeError(
            "left composite library contains duplicate family identities"
        )
    if len(right_by_rule) != len(right_library.entries()):
        raise RuntimeError(
            "right composite library contains duplicate family identities"
        )

    rows: list[dict[str, Any]] = []
    for rule in sorted(set(left_by_rule) | set(right_by_rule)):
        left_entry = left_by_rule.get(rule)
        right_entry = right_by_rule.get(rule)
        if left_entry is None:
            region = "right_only"
        elif right_entry is None:
            region = "left_only"
        else:
            region = "shared"
        rows.append(_composite_row(region, left_entry, right_entry))
    return _sort_rows(rows)


def _sort_rows(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    def sort_key(row: Mapping[str, Any]) -> tuple[Any, ...]:
        support = max(
            int(row["left_popularity"] or 0),
            int(row["right_popularity"] or 0),
        )
        return (
            REGION_ORDER[str(row["region"])],
            -support,
            str(row["left_entry_id"]),
            str(row["right_entry_id"]),
        )

    return [dict(row) for row in sorted(rows, key=sort_key)]


def _panel_counts(rows: Sequence[Mapping[str, Any]]) -> dict[str, int]:
    counts = {
        region: sum(row["region"] == region for row in rows) for region in REGION_ORDER
    }
    return {
        **counts,
        "left_total": counts["left_only"] + counts["shared"],
        "right_total": counts["right_only"] + counts["shared"],
        "union": len(rows),
    }


def _write_tsv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=REPORT_COLUMNS, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def build_overlap_analysis(
    *,
    left_library_path: str | Path,
    right_library_path: str | Path,
    left_composite_path: str | Path,
    right_composite_path: str | Path,
    output_dir: str | Path,
    left_label: str = "n1",
    right_label: str = "n5",
    verification: str = "fast",
) -> dict[str, Any]:
    """Compare five entity pools and publish deterministic TSV/JSON results."""

    destination = Path(output_dir)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError(destination)
    temporary = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent)
    )
    try:
        with (
            ReferenceTacticLibrary.load(
                left_library_path, verification=verification
            ) as left_library,
            ReferenceTacticLibrary.load(
                right_library_path, verification=verification
            ) as right_library,
            CompositeDecompositionLibrary.load(
                left_composite_path, verification=verification
            ) as left_composite,
            CompositeDecompositionLibrary.load(
                right_composite_path, verification=verification
            ) as right_composite,
        ):
            left_composite.assert_reference_library(left_library)
            right_composite.assert_reference_library(right_library)

            reports = {
                kind: compare_tactic_kind(left_library, right_library, kind)
                for kind in TACTIC_KINDS
            }
            reports["composite_rules"] = compare_composite_rules(
                left_composite,
                right_composite,
            )
            artifacts: dict[str, dict[str, Any]] = {}
            for panel in PANEL_ORDER:
                path = temporary / f"{panel}.tsv"
                _write_tsv(path, reports[panel])
                artifacts[panel] = {
                    "path": path.name,
                    "sha256": _sha256_file(path),
                    "size_bytes": path.stat().st_size,
                }

            summary = {
                "schema_version": 1,
                "comparison": "exact_map_independent_tactic_identity",
                "composite_comparison": (
                    "exact_whitespace_normalized_executable_smarts"
                ),
                "popularity_definition": "distinct_supporting_routes",
                "labels": {"left": left_label, "right": right_label},
                "libraries": {
                    "left": {
                        "reference_library_id": left_library.library_id,
                        "processing_profile_fingerprint": (
                            left_library.processing_profile.fingerprint
                        ),
                        "composite_library_id": left_composite.library_id,
                    },
                    "right": {
                        "reference_library_id": right_library.library_id,
                        "processing_profile_fingerprint": (
                            right_library.processing_profile.fingerprint
                        ),
                        "composite_library_id": right_composite.library_id,
                    },
                },
                "processing_profiles_equal": (
                    left_library.processing_profile.fingerprint
                    == right_library.processing_profile.fingerprint
                ),
                "panels": {
                    panel: _panel_counts(reports[panel]) for panel in PANEL_ORDER
                },
                "artifacts": artifacts,
            }
            (temporary / "summary.json").write_text(
                json.dumps(summary, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
        os.rename(temporary, destination)
    except Exception:
        for path in sorted(temporary.rglob("*"), reverse=True):
            if path.is_file():
                path.unlink()
            elif path.is_dir():
                path.rmdir()
        if temporary.exists():
            temporary.rmdir()
        raise
    return summary


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--left-library",
        default="outputs/reference_libraries/n1",
    )
    parser.add_argument(
        "--right-library",
        default="outputs/reference_libraries/n5",
    )
    parser.add_argument(
        "--left-composite-library",
        default="outputs/composite_libraries/n1",
    )
    parser.add_argument(
        "--right-composite-library",
        default="outputs/composite_libraries/n5",
    )
    parser.add_argument(
        "--output-dir",
        default="outputs/library_overlap/n1_n5",
    )
    parser.add_argument("--left-label", default="n1")
    parser.add_argument("--right-label", default="n5")
    parser.add_argument("--verification", choices=("fast", "full"), default="fast")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    summary = build_overlap_analysis(
        left_library_path=args.left_library,
        right_library_path=args.right_library,
        left_composite_path=args.left_composite_library,
        right_composite_path=args.right_composite_library,
        output_dir=args.output_dir,
        left_label=args.left_label,
        right_label=args.right_label,
        verification=args.verification,
    )
    print(json.dumps(summary["panels"], indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
