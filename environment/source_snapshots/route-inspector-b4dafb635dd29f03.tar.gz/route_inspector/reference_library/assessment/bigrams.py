"""Supplementary Retro-BLEU-like bigram overlap assessment."""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass
from typing import Any, ClassVar, Iterable, Mapping

from route_inspector.metrics.retro_bleu.bigrams import RetroBleuBigramOccurrence
from route_inspector.reference_library.bigram_catalog import (
    RetroBleuBigramCatalog,
    RetroBleuBigramIdentity,
    RetroBleuBigramLibraryEntry,
)

RETRO_BLEU_BIGRAM_ASSESSMENT_SCHEMA_VERSION = 1
BIGRAM_EVIDENCE_AVAILABILITIES = frozenset(
    {"available", "library_component_unavailable", "extraction_incomplete"}
)
BIGRAM_COVERAGE_STATUSES = frozenset(
    {"fully_covered", "partially_novel", "bigram_novel", "no_extracted_bigrams"}
)
BIGRAM_COMPONENT_UNAVAILABLE_LIMITATION = (
    "The Reference library has no Retro-BLEU-like bigram component; RRSeq and "
    "RRSubtree tactic assessment remains valid, but bigram overlap was not assessed."
)
BIGRAM_EXTRACTION_INCOMPLETE_LIMITATION = (
    "Retro-BLEU-like bigram extraction was incomplete; no bigram novelty verdict "
    "is reported, while the separate tactic assessment remains unchanged."
)


@dataclass(frozen=True)
class RetroBleuBigramMatch:
    """One query bigram and its exact Reference entry, if present."""

    occurrence: RetroBleuBigramOccurrence
    identity: RetroBleuBigramIdentity
    reference_entry: RetroBleuBigramLibraryEntry | None

    def __post_init__(self) -> None:
        expected = RetroBleuBigramIdentity.from_occurrence(
            self.occurrence,
            identity_version=self.identity.identity_version,
        )
        if not expected.equivalent_to(self.identity):
            raise ValueError("query bigram identity differs from its occurrence")
        if self.reference_entry is not None and not (
            self.reference_entry.identity.equivalent_to(self.identity)
        ):
            raise ValueError("Reference bigram entry is not exactly equivalent")

    @property
    def known_in_all_reference(self) -> bool:
        return self.reference_entry is not None

    @property
    def known_in_reference_without_rrseq(self) -> bool:
        return bool(
            self.reference_entry is not None
            and self.reference_entry.no_rrseq_occurrence_count
        )

    @property
    def reference_support(self) -> dict[str, Any] | None:
        return None if self.reference_entry is None else self.reference_entry.support()

    def to_dict(self) -> dict[str, Any]:
        return {
            "occurrence": self.occurrence.to_dict(),
            "identity": self.identity.to_dict(),
            "known_in_all_reference": self.known_in_all_reference,
            "known_in_reference_without_rrseq": (self.known_in_reference_without_rrseq),
            "reference_entry": (
                None if self.reference_entry is None else self.reference_entry.to_dict()
            ),
            "reference_support": self.reference_support,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RetroBleuBigramMatch":
        raw_entry = value.get("reference_entry")
        result = cls(
            occurrence=RetroBleuBigramOccurrence.from_dict(value["occurrence"]),
            identity=RetroBleuBigramIdentity.from_dict(value["identity"]),
            reference_entry=(
                None
                if raw_entry is None
                else RetroBleuBigramLibraryEntry.from_dict(raw_entry)
            ),
        )
        for field, expected in (
            ("known_in_all_reference", result.known_in_all_reference),
            (
                "known_in_reference_without_rrseq",
                result.known_in_reference_without_rrseq,
            ),
            ("reference_support", result.reference_support),
        ):
            if field in value and value[field] != expected:
                raise ValueError(f"serialized {field} is inconsistent")
        return result


def _coverage_fraction(numerator: int, denominator: int) -> float | None:
    return None if denominator == 0 else numerator / denominator


def _coverage_status(known: int, total: int) -> str:
    if total == 0:
        return "no_extracted_bigrams"
    if known == total:
        return "fully_covered"
    if known == 0:
        return "bigram_novel"
    return "partially_novel"


@dataclass(frozen=True)
class RetroBleuBigramCoverage:
    """Occurrence and exact-identity coverage for one Reference cohort."""

    scope: str
    status: str
    occurrence_count: int
    unique_identity_count: int
    known_occurrence_count: int
    novel_occurrence_count: int
    known_unique_identity_count: int
    novel_unique_identity_count: int
    occurrence_coverage_fraction: float | None
    unique_coverage_fraction: float | None

    _COUNT_FIELDS: ClassVar[tuple[str, ...]] = (
        "occurrence_count",
        "unique_identity_count",
        "known_occurrence_count",
        "novel_occurrence_count",
        "known_unique_identity_count",
        "novel_unique_identity_count",
    )

    def __post_init__(self) -> None:
        if self.scope not in {"all_reference", "reference_without_rrseq"}:
            raise ValueError("unsupported bigram coverage scope")
        if self.status not in BIGRAM_COVERAGE_STATUSES:
            raise ValueError("unsupported bigram coverage status")
        for name in self._COUNT_FIELDS:
            if int(getattr(self, name)) < 0:
                raise ValueError(f"{name} must be non-negative")
        if self.known_occurrence_count + self.novel_occurrence_count != (
            self.occurrence_count
        ):
            raise ValueError("bigram occurrence counts are inconsistent")
        if self.known_unique_identity_count + self.novel_unique_identity_count != (
            self.unique_identity_count
        ):
            raise ValueError("bigram unique-identity counts are inconsistent")
        if self.status != _coverage_status(
            self.known_occurrence_count,
            self.occurrence_count,
        ):
            raise ValueError("bigram coverage status disagrees with occurrence counts")
        for value, numerator, denominator in (
            (
                self.occurrence_coverage_fraction,
                self.known_occurrence_count,
                self.occurrence_count,
            ),
            (
                self.unique_coverage_fraction,
                self.known_unique_identity_count,
                self.unique_identity_count,
            ),
        ):
            expected = _coverage_fraction(numerator, denominator)
            if expected is None:
                if value is not None:
                    raise ValueError("zero-denominator coverage must be None")
            elif value is None or not math.isclose(
                value,
                expected,
                rel_tol=0,
                abs_tol=1e-15,
            ):
                raise ValueError("bigram coverage fraction is inconsistent")

    def to_dict(self) -> dict[str, Any]:
        return {
            "scope": self.scope,
            "status": self.status,
            **{name: getattr(self, name) for name in self._COUNT_FIELDS},
            "occurrence_coverage_fraction": self.occurrence_coverage_fraction,
            "unique_coverage_fraction": self.unique_coverage_fraction,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RetroBleuBigramCoverage":
        return cls(
            scope=str(value["scope"]),
            status=str(value["status"]),
            **{name: int(value[name]) for name in cls._COUNT_FIELDS},
            occurrence_coverage_fraction=(
                None
                if value.get("occurrence_coverage_fraction") is None
                else float(value["occurrence_coverage_fraction"])
            ),
            unique_coverage_fraction=(
                None
                if value.get("unique_coverage_fraction") is None
                else float(value["unique_coverage_fraction"])
            ),
        )


def _unique_known_states(
    matches: Iterable[RetroBleuBigramMatch],
    *,
    no_rrseq: bool,
) -> tuple[bool, ...]:
    groups: dict[tuple[int, str], list[tuple[RetroBleuBigramIdentity, bool]]] = (
        defaultdict(list)
    )
    for match in matches:
        identity = match.identity
        known = (
            match.known_in_reference_without_rrseq
            if no_rrseq
            else match.known_in_all_reference
        )
        bucket = groups[(identity.identity_version, identity.lookup_key)]
        for representative, previous_known in bucket:
            if not representative.equivalent_to(identity):
                continue
            if previous_known != known:
                raise RuntimeError(
                    "equivalent bigrams received inconsistent Reference support"
                )
            break
        else:
            bucket.append((identity, known))
    return tuple(known for key in sorted(groups) for _identity, known in groups[key])


def _coverage(
    scope: str,
    matches: tuple[RetroBleuBigramMatch, ...],
) -> RetroBleuBigramCoverage:
    no_rrseq = scope == "reference_without_rrseq"
    states = tuple(
        match.known_in_reference_without_rrseq
        if no_rrseq
        else match.known_in_all_reference
        for match in matches
    )
    unique_states = _unique_known_states(matches, no_rrseq=no_rrseq)
    known = sum(states)
    known_unique = sum(unique_states)
    return RetroBleuBigramCoverage(
        scope=scope,
        status=_coverage_status(known, len(matches)),
        occurrence_count=len(matches),
        unique_identity_count=len(unique_states),
        known_occurrence_count=known,
        novel_occurrence_count=len(matches) - known,
        known_unique_identity_count=known_unique,
        novel_unique_identity_count=len(unique_states) - known_unique,
        occurrence_coverage_fraction=_coverage_fraction(known, len(matches)),
        unique_coverage_fraction=_coverage_fraction(
            known_unique,
            len(unique_states),
        ),
    )


@dataclass(frozen=True)
class RetroBleuBigramAssessment:
    """Independent bigram-evidence result nested in a route assessment."""

    availability: str
    query_has_rrseq_cons: bool
    query_has_rrseq_gap: bool
    matches: tuple[RetroBleuBigramMatch, ...] = ()
    all_reference: RetroBleuBigramCoverage | None = None
    reference_without_rrseq: RetroBleuBigramCoverage | None = None
    errors: tuple[Mapping[str, Any], ...] = ()
    limitation: str | None = None
    schema_version: int = RETRO_BLEU_BIGRAM_ASSESSMENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if int(self.schema_version) != RETRO_BLEU_BIGRAM_ASSESSMENT_SCHEMA_VERSION:
            raise ValueError("unsupported bigram assessment schema version")
        if self.availability not in BIGRAM_EVIDENCE_AVAILABILITIES:
            raise ValueError("unsupported bigram evidence availability")
        normalized_errors = tuple(dict(error) for error in self.errors)
        object.__setattr__(self, "errors", normalized_errors)
        if self.availability == "available":
            if self.limitation is not None or normalized_errors:
                raise ValueError("available bigram evidence cannot carry limitations")
            if self.all_reference != _coverage("all_reference", self.matches):
                raise ValueError("global bigram coverage disagrees with matches")
            if self.reference_without_rrseq != _coverage(
                "reference_without_rrseq",
                self.matches,
            ):
                raise ValueError("no-RRSeq bigram coverage disagrees with matches")
        else:
            if (
                self.matches
                or self.all_reference is not None
                or (self.reference_without_rrseq is not None)
            ):
                raise ValueError(
                    "unavailable/incomplete bigram evidence has no verdict"
                )
            expected_limitation = (
                BIGRAM_COMPONENT_UNAVAILABLE_LIMITATION
                if self.availability == "library_component_unavailable"
                else BIGRAM_EXTRACTION_INCOMPLETE_LIMITATION
            )
            if self.limitation != expected_limitation:
                raise ValueError("bigram evidence limitation is inconsistent")
            if self.availability == "extraction_incomplete" and not normalized_errors:
                raise ValueError("incomplete bigram extraction requires an error")

    @property
    def query_without_rrseq(self) -> bool:
        return not self.query_has_rrseq_cons and not self.query_has_rrseq_gap

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "availability": self.availability,
            "query_rrseq_presence": {
                "rrseq_cons": self.query_has_rrseq_cons,
                "rrseq_gap": self.query_has_rrseq_gap,
                "neither": self.query_without_rrseq,
            },
            "matches": [match.to_dict() for match in self.matches],
            "all_reference": (
                None if self.all_reference is None else self.all_reference.to_dict()
            ),
            "reference_without_rrseq": (
                None
                if self.reference_without_rrseq is None
                else self.reference_without_rrseq.to_dict()
            ),
            "errors": [dict(error) for error in self.errors],
            "limitation": self.limitation,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RetroBleuBigramAssessment":
        presence = value.get("query_rrseq_presence")
        if not isinstance(presence, Mapping):
            raise ValueError("bigram assessment requires query_rrseq_presence")
        result = cls(
            availability=str(value["availability"]),
            query_has_rrseq_cons=bool(presence["rrseq_cons"]),
            query_has_rrseq_gap=bool(presence["rrseq_gap"]),
            matches=tuple(
                RetroBleuBigramMatch.from_dict(item)
                for item in value.get("matches", ())
            ),
            all_reference=(
                None
                if value.get("all_reference") is None
                else RetroBleuBigramCoverage.from_dict(value["all_reference"])
            ),
            reference_without_rrseq=(
                None
                if value.get("reference_without_rrseq") is None
                else RetroBleuBigramCoverage.from_dict(value["reference_without_rrseq"])
            ),
            errors=tuple(dict(error) for error in value.get("errors", ())),
            limitation=(
                None if value.get("limitation") is None else str(value["limitation"])
            ),
            schema_version=int(value.get("schema_version", -1)),
        )
        if "neither" in presence and bool(presence["neither"]) != (
            result.query_without_rrseq
        ):
            raise ValueError("serialized query RRSeq presence is inconsistent")
        return result


def assess_retro_bleu_bigrams(
    occurrences: Iterable[RetroBleuBigramOccurrence],
    catalog: RetroBleuBigramCatalog | None,
    *,
    query_has_rrseq_cons: bool,
    query_has_rrseq_gap: bool,
    extraction_error: Mapping[str, Any] | None = None,
) -> RetroBleuBigramAssessment:
    """Assess exact query bigrams without affecting tactic coverage."""

    if catalog is None:
        return RetroBleuBigramAssessment(
            availability="library_component_unavailable",
            query_has_rrseq_cons=query_has_rrseq_cons,
            query_has_rrseq_gap=query_has_rrseq_gap,
            limitation=BIGRAM_COMPONENT_UNAVAILABLE_LIMITATION,
        )
    if extraction_error is not None:
        return RetroBleuBigramAssessment(
            availability="extraction_incomplete",
            query_has_rrseq_cons=query_has_rrseq_cons,
            query_has_rrseq_gap=query_has_rrseq_gap,
            errors=(dict(extraction_error),),
            limitation=BIGRAM_EXTRACTION_INCOMPLETE_LIMITATION,
        )
    ordered = tuple(
        sorted(
            occurrences,
            key=lambda item: (item.reaction_node_paths, item.occurrence_id),
        )
    )
    if len({item.occurrence_id for item in ordered}) != len(ordered):
        raise ValueError("query bigram occurrence IDs must be unique")
    matches = tuple(
        RetroBleuBigramMatch(
            occurrence=occurrence,
            identity=(
                identity := RetroBleuBigramIdentity.from_occurrence(
                    occurrence,
                    identity_version=catalog.identity_version,
                )
            ),
            reference_entry=catalog.lookup(identity),
        )
        for occurrence in ordered
    )
    return RetroBleuBigramAssessment(
        availability="available",
        query_has_rrseq_cons=query_has_rrseq_cons,
        query_has_rrseq_gap=query_has_rrseq_gap,
        matches=matches,
        all_reference=_coverage("all_reference", matches),
        reference_without_rrseq=_coverage("reference_without_rrseq", matches),
    )


__all__ = [
    "BIGRAM_COMPONENT_UNAVAILABLE_LIMITATION",
    "BIGRAM_COVERAGE_STATUSES",
    "BIGRAM_EVIDENCE_AVAILABILITIES",
    "BIGRAM_EXTRACTION_INCOMPLETE_LIMITATION",
    "RETRO_BLEU_BIGRAM_ASSESSMENT_SCHEMA_VERSION",
    "RetroBleuBigramAssessment",
    "RetroBleuBigramCoverage",
    "RetroBleuBigramMatch",
    "assess_retro_bleu_bigrams",
]
