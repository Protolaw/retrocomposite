"""Version-dispatched tactic certificates; historical policies remain intact."""

from typing import Any, Mapping, Sequence

from route_inspector.reference_library.models import TacticIdentity, TacticOccurrence
from route_inspector.rules.canonical import _canonical_graph_certificate
from route_inspector.rules.graph import canonical_json


def _identity_sort_key(identity: TacticIdentity) -> str:
    return canonical_json(identity.to_dict())


def _canonical_tree_certificate(node: Mapping[str, Any]) -> str:
    children = [
        {
            "skipped_reaction_count": int(row["skipped_reaction_count"]),
            "child": _canonical_tree_certificate(row["child"]),
        }
        for row in node["children"]
    ]
    children.sort(key=canonical_json)
    return canonical_json(
        {
            "rule_graph": _canonical_graph_certificate(node["rule_graph"]),
            "children": children,
        }
    )


def _identity_exact_certificate(identity: TacticIdentity) -> str:
    payload = identity.equivalence_payload
    if identity.identity_version >= 3:
        from route_inspector.reference_library.identity.transformation import (
            exact_certificate,
        )

        return exact_certificate(
            identity.kind, payload, identity_version=identity.identity_version
        )
    if identity.identity_version >= 2:
        from route_inspector.reference_library.identity.tactics import (
            normalized_tactic_payload,
        )

        exact_payload: Any = normalized_tactic_payload(
            identity.kind,
            payload,
            identity_version=identity.identity_version,
        )
    elif identity.kind.startswith("rrseq_"):
        exact_payload = {
            "ordered_rules": [
                _canonical_graph_certificate(rule) for rule in payload["rules"]
            ]
        }
    else:
        exact_payload = {
            "root": _canonical_tree_certificate(payload["root"]),
        }
    return canonical_json(
        {
            "identity_version": identity.identity_version,
            "kind": identity.kind,
            "exact_payload": exact_payload,
        }
    )


def _component_exact_certificate(
    component: Sequence[TacticOccurrence],
) -> str:
    certificates = {
        _identity_exact_certificate(identity)
        for identity in {
            _identity_sort_key(occurrence.identity): occurrence.identity
            for occurrence in component
        }.values()
    }
    if len(certificates) != 1:
        raise RuntimeError(
            "exact-equivalent tactics produced different canonical certificates"
        )
    return next(iter(certificates))
