"""Versioned tactic identities, exact comparisons, and certificates."""
