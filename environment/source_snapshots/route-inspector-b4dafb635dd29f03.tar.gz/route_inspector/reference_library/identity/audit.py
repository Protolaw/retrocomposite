"""Optional graph-isomorphism audit for CGR-key identity splits."""

from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from route_inspector.reference_library.bigram_catalog import RetroBleuBigramIdentity
from route_inspector.reference_library.build.adapters import adapt_native_occurrence
from route_inspector.reference_library.catalog import ReferenceTacticLibrary

KEY_ISOMORPHISM_AUDIT_SCHEMA_VERSION = 1


def _split_groups(
    rows: Iterable[tuple[str, str, Any]],
) -> tuple[dict[str, Any], ...]:
    buckets: dict[tuple[str, str], list[tuple[str, Any]]] = defaultdict(list)
    for namespace, entry_id, legacy_identity in rows:
        buckets[(namespace, legacy_identity.lookup_key)].append(
            (str(entry_id), legacy_identity)
        )
    splits: list[dict[str, Any]] = []
    for (namespace, legacy_lookup_key), members in sorted(buckets.items()):
        components: list[list[tuple[str, Any]]] = []
        for entry_id, identity in sorted(members):
            for component in components:
                if identity.equivalent_to(component[0][1]):
                    component.append((entry_id, identity))
                    break
            else:
                components.append([(entry_id, identity)])
        for component in components:
            entry_ids = sorted(entry_id for entry_id, _identity in component)
            if len(entry_ids) < 2:
                continue
            splits.append(
                {
                    "namespace": namespace,
                    "legacy_lookup_key": legacy_lookup_key,
                    "v2_entry_count": len(entry_ids),
                    "v2_entry_ids": entry_ids,
                }
            )
    splits.sort(
        key=lambda item: (
            item["namespace"],
            item["legacy_lookup_key"],
            item["v2_entry_ids"],
        )
    )
    return tuple(splits)


def key_isomorphism_audit(library: ReferenceTacticLibrary) -> dict[str, Any]:
    """Report v2 entries that legacy graph isomorphism would merge.

    This diagnostic constructs separate legacy identities and never mutates the
    supplied catalog, entry IDs, or library ID.
    """

    if library.tactic_identity_version != 2:
        raise ValueError("CGR-key split audit requires a tactic identity v2 library")
    library_id = library.library_id
    tactic_rows = []
    for entry in library.entries():
        occurrence = library.get_occurrence(entry.representative_occurrence_id)
        legacy = adapt_native_occurrence(
            entry.kind,
            occurrence.native_payload,
            identity_version=1,
        ).identity
        tactic_rows.append((entry.kind, entry.entry_id, legacy))
    tactic_splits = _split_groups(tactic_rows)

    bigram_rows = []
    bigram_catalog = library.retro_bleu_bigram_catalog
    if bigram_catalog is not None:
        if bigram_catalog.identity_version != 2:
            raise ValueError("CGR-key split audit requires bigram identity v2")
        for entry in bigram_catalog.entries():
            legacy = RetroBleuBigramIdentity.from_rule_smarts(
                entry.representative_rule_smarts,
                identity_version=1,
            )
            bigram_rows.append(("retro_bleu_like_bigram", entry.entry_id, legacy))
    bigram_splits = _split_groups(bigram_rows)
    if library.library_id != library_id:
        raise RuntimeError("identity audit unexpectedly changed the library ID")
    return {
        "schema_version": KEY_ISOMORPHISM_AUDIT_SCHEMA_VERSION,
        "library_id": library_id,
        "identity_effect": "diagnostic_only",
        "tactic": {
            "audited_entry_count": len(tactic_rows),
            "possible_split_group_count": len(tactic_splits),
            "possible_split_entry_count": sum(
                int(group["v2_entry_count"]) for group in tactic_splits
            ),
            "groups": list(tactic_splits),
        },
        "retro_bleu_bigrams": {
            "available": bigram_catalog is not None,
            "audited_entry_count": len(bigram_rows),
            "possible_split_group_count": len(bigram_splits),
            "possible_split_entry_count": sum(
                int(group["v2_entry_count"]) for group in bigram_splits
            ),
            "groups": list(bigram_splits),
        },
        "limitation": (
            "Unequal complete CGR keys remain distinct. This optional legacy "
            "isomorphism audit only identifies possible family splits and never "
            "merges entries or changes support counts."
        ),
    }


def write_key_isomorphism_audit(
    library_directory: str | Path,
    output_path: str | Path | None = None,
) -> Path:
    """Write the report-only audit beside a fully written library."""

    root = Path(library_directory)
    destination = (
        root / "reports" / "key_isomorphism_audit.json"
        if output_path is None
        else Path(output_path)
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    with ReferenceTacticLibrary.load(root, verification="fast") as library:
        report = key_isomorphism_audit(library)
    destination.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return destination


__all__ = [
    "KEY_ISOMORPHISM_AUDIT_SCHEMA_VERSION",
    "key_isomorphism_audit",
    "write_key_isomorphism_audit",
]
