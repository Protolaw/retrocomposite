"""Versioned tactic transformations, sequence order, topology, and gap widths."""

import hashlib
from collections import defaultdict

from route_inspector.rules.graph import canonical_json
from route_inspector.rules.transformation import (
    METRICS,
    rule_signature,
    rules_equivalent,
)

TRANSFORMATION_IDENTITY_VERSION = 3


def from_occurrence(occurrence, steps, *, identity_version=3):
    """Attach live extraction graphs without modifying native provenance."""
    from route_inspector.reference_library.models import TacticIdentity

    rules = {}
    for path in occurrence.selected_reaction_node_paths:
        step = steps[path]
        if not step.transformation:
            raise ValueError(
                "Transformation identity requires live extracted query sides"
            )
        rules[path] = step.transformation
    payload = dict(occurrence.identity.equivalence_payload)
    if occurrence.identity.kind.startswith("rrseq"):
        payload["rule_sides"] = [
            rules[path] for path in occurrence.selected_reaction_node_paths
        ]
    else:
        native = occurrence.native_payload
        children = defaultdict(list)
        for edge in native["edges"]:
            children[tuple(edge["parent_reaction_node_path"])].append(edge)

        def visit(path):
            return {
                "rule_sides": rules[path],
                "query_cgr_key": rules[path]["query_cgr_key"],
                "children": [
                    {
                        "skipped_reaction_count": len(
                            edge["skipped_reaction_node_paths"]
                        ),
                        "child": visit(tuple(edge["child_reaction_node_path"])),
                    }
                    for edge in children[path]
                ],
            }

        payload["root"] = visit(tuple(native["root_reaction_node_path"]))
    if identity_version >= 4 and occurrence.identity.kind == "rrseq_gap":
        from route_inspector.tactics.rrseq.gap_widths import occurrence_gap_widths

        payload["inter_selection_gap_widths"] = list(occurrence_gap_widths(occurrence))
    return TacticIdentity(
        occurrence.identity.kind, payload, identity_version=identity_version
    )


def _tree(node, rule_fn):
    if node["query_cgr_key"] != node["rule_sides"]["query_cgr_key"]:
        raise ValueError("Transformation tree native key mismatch")
    return {
        "rule": rule_fn(node["rule_sides"]),
        "children": sorted(
            [
                {
                    "skipped_reaction_count": row["skipped_reaction_count"],
                    "child": _tree(row["child"], rule_fn),
                }
                for row in node["children"]
            ],
            key=canonical_json,
        ),
    }


def payload_signature(kind, payload, *, identity_version=3):
    from route_inspector.reference_library.identity.tactics import (
        normalized_tactic_payload,
    )

    normalized_tactic_payload(kind, payload, identity_version=2)
    if kind.startswith("rrseq"):
        rules = payload["rule_sides"]
        if len(rules) != len(payload["query_cgr_keys"]) or len(rules) < 2:
            raise ValueError("Transformation sequence length mismatch")
        if any(
            r["query_cgr_key"] != key
            for r, key in zip(rules, payload["query_cgr_keys"])
        ):
            raise ValueError("Transformation native keys mismatch")
        value = [rule_signature(rule) for rule in rules]
    else:
        value = _tree(payload["root"], rule_signature)
    result = {"identity_version": identity_version, "kind": kind, "rules": value}
    if identity_version >= 4 and kind == "rrseq_gap":
        from route_inspector.tactics.rrseq.gap_widths import validate_gap_widths

        result["inter_selection_gap_widths"] = list(
            validate_gap_widths(
                payload.get("inter_selection_gap_widths"), len(payload["rule_sides"])
            )
        )
    return result


def lookup_key(kind, payload, *, identity_version=3):
    return (
        "tactic_i_"
        + hashlib.sha256(
            canonical_json(
                payload_signature(kind, payload, identity_version=identity_version)
            ).encode()
        ).hexdigest()
    )


def payloads_equivalent(kind, left, right, *, identity_version=3):
    METRICS["tactic_candidate_comparisons"] += 1
    if payload_signature(
        kind, left, identity_version=identity_version
    ) != payload_signature(kind, right, identity_version=identity_version):
        return False
    if kind.startswith("rrseq"):
        return all(
            rules_equivalent(a, b)
            for a, b in zip(left["rule_sides"], right["rule_sides"])
        )

    def same(a, b):
        if not rules_equivalent(a["rule_sides"], b["rule_sides"]):
            return False
        available = list(b["children"])
        for child in a["children"]:
            for i, other in enumerate(available):
                if child["skipped_reaction_count"] == other[
                    "skipped_reaction_count"
                ] and same(child["child"], other["child"]):
                    available.pop(i)
                    break
            else:
                return False
        return not available

    return same(left["root"], right["root"])


def exact_certificate(kind, payload, *, identity_version=3):
    from route_inspector.rules.canonical import _canonical_graph_certificate

    def rule_certificate(rule):
        if "exact_representation" in rule:
            return {"exact_representation": rule["exact_representation"]}
        return {
            side: _canonical_graph_certificate(rule[side])
            for side in ("reactants", "products")
        }

    value = (
        [rule_certificate(rule) for rule in payload["rule_sides"]]
        if kind.startswith("rrseq")
        else _tree(payload["root"], rule_certificate)
    )
    result = {"identity_version": identity_version, "kind": kind, "rules": value}
    if identity_version >= 4 and kind == "rrseq_gap":
        result["inter_selection_gap_widths"] = payload_signature(
            kind, payload, identity_version=identity_version
        )["inter_selection_gap_widths"]
    return canonical_json(result)
