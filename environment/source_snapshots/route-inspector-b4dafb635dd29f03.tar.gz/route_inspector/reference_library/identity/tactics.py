"""Versioned identities for RRSeq and RRSubtree tactics."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from typing import Any, Literal, cast

from route_inspector.rules.graph import canonical_json

TacticKindText = Literal[
    "rrseq_cons",
    "rrseq_gap",
    "rrsubtree_cons",
    "rrsubtree_gap",
]

_KINDS = frozenset({"rrseq_cons", "rrseq_gap", "rrsubtree_cons", "rrsubtree_gap"})
_LEGACY_GRAPH_IDENTITY_VERSION = 1
_QUERY_CGR_KEY_IDENTITY_VERSION = 2
_SUPPORTED_IDENTITY_VERSIONS = frozenset(
    {_LEGACY_GRAPH_IDENTITY_VERSION, _QUERY_CGR_KEY_IDENTITY_VERSION, 3, 4}
)


def _kind(value: str) -> TacticKindText:
    normalized = str(value)
    if normalized not in _KINDS:
        raise ValueError(f"unsupported tactic kind: {value!r}")
    return cast(TacticKindText, normalized)


def _identity_version(value: int) -> int:
    normalized = int(value)
    if normalized not in _SUPPORTED_IDENTITY_VERSIONS:
        raise ValueError(f"unsupported tactic identity version: {value}")
    return normalized


def _variant_for_kind(kind: str) -> str:
    return "gap" if kind.endswith("_gap") else "cons"


def _sequence(value: Any, *, field: str) -> Sequence[Any]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise ValueError(f"{field} must be an array")
    return value


def _rrseq_graphs(
    kind: str, payload: Mapping[str, Any]
) -> tuple[Mapping[str, Any], ...]:
    from route_inspector.rules.graph import graph_coarse_signature

    if payload.get("family") != "rrseq":
        raise ValueError("RRSeq identity payload requires family='rrseq'")
    if payload.get("variant") != _variant_for_kind(kind):
        raise ValueError("RRSeq identity variant differs from tactic kind")
    rules = _sequence(payload.get("rules"), field="RRSeq identity rules")
    if len(rules) < 2:
        raise ValueError("RRSeq identity requires at least two rule graphs")
    if not all(isinstance(rule, Mapping) for rule in rules):
        raise ValueError("RRSeq identity rules must contain labelled graphs")
    graphs = tuple(cast(Mapping[str, Any], rule) for rule in rules)
    for graph in graphs:
        graph_coarse_signature(graph)
    return graphs


def _rrseq_query_keys(kind: str, payload: Mapping[str, Any]) -> tuple[str, ...]:
    if payload.get("family") != "rrseq":
        raise ValueError("RRSeq identity payload requires family='rrseq'")
    if payload.get("variant") != _variant_for_kind(kind):
        raise ValueError("RRSeq identity variant differs from tactic kind")
    values = _sequence(
        payload.get("query_cgr_keys"),
        field="RRSeq identity query_cgr_keys",
    )
    keys = tuple(str(value) for value in values)
    if len(keys) < 2 or any(not key for key in keys):
        raise ValueError(
            "RRSeq identity requires at least two non-empty query_cgr_keys"
        )
    return keys


def _legacy_tree_node_signature(node: Mapping[str, Any], *, variant: str) -> str:
    from route_inspector.rules.graph import graph_coarse_signature

    graph = node.get("rule_graph")
    if not isinstance(graph, Mapping):
        raise ValueError("RRSubtree nodes require a labelled rule_graph")
    graph_signature = graph_coarse_signature(graph)
    children = _sequence(node.get("children"), field="RRSubtree children")
    child_signatures: list[dict[str, Any]] = []
    for child_row in children:
        if not isinstance(child_row, Mapping):
            raise ValueError("RRSubtree children must be objects")
        skipped = int(child_row.get("skipped_reaction_count", -1))
        if skipped < 0:
            raise ValueError("RRSubtree skipped-reaction counts must be non-negative")
        if variant == "cons" and skipped:
            raise ValueError("RRSubtree_cons identity edges cannot skip reactions")
        child = child_row.get("child")
        if not isinstance(child, Mapping):
            raise ValueError("RRSubtree edges require a child tree node")
        child_signatures.append(
            {
                "skipped_reaction_count": skipped,
                "child_signature": _legacy_tree_node_signature(
                    child,
                    variant=variant,
                ),
            }
        )
    child_signatures.sort(key=canonical_json)
    encoded = {
        "rule_graph_signature": graph_signature,
        "children": child_signatures,
    }
    return hashlib.sha256(canonical_json(encoded).encode("utf-8")).hexdigest()


def _validate_tree_shape(
    *,
    variant: str,
    root: Mapping[str, Any],
    validate_node: Any,
) -> None:
    validate_node(root, variant=variant)
    root_children = _sequence(root.get("children"), field="RRSubtree children")
    if len(root_children) < 2:
        raise ValueError("RRSubtree identity requires at least two root branches")

    def shape(node: Mapping[str, Any]) -> tuple[int, bool]:
        node_count = 1
        has_skipped_edge = False
        for child_row in _sequence(node.get("children"), field="RRSubtree children"):
            if not isinstance(child_row, Mapping):
                raise ValueError("RRSubtree children must be objects")
            skipped = int(child_row.get("skipped_reaction_count", -1))
            child = child_row.get("child")
            if skipped < 0 or not isinstance(child, Mapping):
                raise ValueError("RRSubtree edge payload is invalid")
            child_count, child_has_skip = shape(child)
            node_count += child_count
            has_skipped_edge = has_skipped_edge or bool(skipped) or child_has_skip
        return node_count, has_skipped_edge

    node_count, has_skipped_edge = shape(root)
    if node_count < 3:
        raise ValueError("RRSubtree identity requires at least three nodes")
    if variant == "gap" and not has_skipped_edge:
        raise ValueError("RRSubtree_gap identity requires at least one skipped edge")


def _legacy_rrsubtree_root(
    kind: str,
    payload: Mapping[str, Any],
) -> Mapping[str, Any]:
    if payload.get("family") != "rrsubtree":
        raise ValueError("RRSubtree identity payload requires family='rrsubtree'")
    variant = _variant_for_kind(kind)
    if payload.get("variant") != variant:
        raise ValueError("RRSubtree identity variant differs from tactic kind")
    root = payload.get("root")
    if not isinstance(root, Mapping):
        raise ValueError("RRSubtree identity requires a root tree node")
    _validate_tree_shape(
        variant=variant,
        root=root,
        validate_node=_legacy_tree_node_signature,
    )
    return root


def _query_key_tree_node(
    node: Mapping[str, Any],
    *,
    variant: str,
) -> dict[str, Any]:
    query_cgr_key = str(node.get("query_cgr_key") or "")
    if not query_cgr_key:
        raise ValueError("RRSubtree nodes require a non-empty query_cgr_key")
    children = _sequence(node.get("children"), field="RRSubtree children")
    normalized_children: list[dict[str, Any]] = []
    for child_row in children:
        if not isinstance(child_row, Mapping):
            raise ValueError("RRSubtree children must be objects")
        skipped = int(child_row.get("skipped_reaction_count", -1))
        if skipped < 0:
            raise ValueError("RRSubtree skipped-reaction counts must be non-negative")
        if variant == "cons" and skipped:
            raise ValueError("RRSubtree_cons identity edges cannot skip reactions")
        child = child_row.get("child")
        if not isinstance(child, Mapping):
            raise ValueError("RRSubtree edges require a child tree node")
        normalized_children.append(
            {
                "skipped_reaction_count": skipped,
                "child": _query_key_tree_node(child, variant=variant),
            }
        )
    normalized_children.sort(key=canonical_json)
    return {
        "query_cgr_key": query_cgr_key,
        "children": normalized_children,
    }


def _query_key_rrsubtree_root(
    kind: str,
    payload: Mapping[str, Any],
) -> dict[str, Any]:
    if payload.get("family") != "rrsubtree":
        raise ValueError("RRSubtree identity payload requires family='rrsubtree'")
    variant = _variant_for_kind(kind)
    if payload.get("variant") != variant:
        raise ValueError("RRSubtree identity variant differs from tactic kind")
    root = payload.get("root")
    if not isinstance(root, Mapping):
        raise ValueError("RRSubtree identity requires a root tree node")
    normalized = _query_key_tree_node(root, variant=variant)
    _validate_tree_shape(
        variant=variant,
        root=normalized,
        validate_node=_query_key_tree_node,
    )
    return normalized


def normalized_tactic_payload(
    kind: str,
    equivalence_payload: Mapping[str, Any],
    *,
    identity_version: int,
) -> dict[str, Any]:
    """Validate and normalize one versioned tactic identity payload."""

    normalized_kind = _kind(kind)
    version = _identity_version(identity_version)
    variant = _variant_for_kind(normalized_kind)
    if version >= 3:
        from route_inspector.reference_library.identity.transformation import (
            payload_signature,
        )

        # Preserve the established kind, length, topology and gap validation.
        normalized_tactic_payload(
            normalized_kind, equivalence_payload, identity_version=2
        )
        payload_signature(
            normalized_kind, equivalence_payload, identity_version=version
        )
        return dict(equivalence_payload)
    if version == _LEGACY_GRAPH_IDENTITY_VERSION:
        if normalized_kind.startswith("rrseq_"):
            return {
                "family": "rrseq",
                "variant": variant,
                "rules": [
                    dict(graph)
                    for graph in _rrseq_graphs(normalized_kind, equivalence_payload)
                ],
            }
        return {
            "family": "rrsubtree",
            "variant": variant,
            "root": dict(_legacy_rrsubtree_root(normalized_kind, equivalence_payload)),
        }
    if normalized_kind.startswith("rrseq_"):
        return {
            "family": "rrseq",
            "variant": variant,
            "query_cgr_keys": list(
                _rrseq_query_keys(normalized_kind, equivalence_payload)
            ),
        }
    return {
        "family": "rrsubtree",
        "variant": variant,
        "root": _query_key_rrsubtree_root(
            normalized_kind,
            equivalence_payload,
        ),
    }


def tactic_lookup_key(
    kind: str,
    equivalence_payload: Mapping[str, Any],
    *,
    identity_version: int = _QUERY_CGR_KEY_IDENTITY_VERSION,
) -> str:
    """Return the versioned tactic lookup key.

    Identity v1 uses a coarse invariant bucket and therefore requires exact
    labelled-graph isomorphism. Identity v2 hashes the complete normalized
    QueryCGR-key/topology payload; callers still compare that complete payload
    to make hash collisions harmless.
    """

    normalized_kind = _kind(kind)
    version = _identity_version(identity_version)
    if version >= 3:
        from route_inspector.reference_library.identity.transformation import lookup_key

        return lookup_key(
            normalized_kind, equivalence_payload, identity_version=version
        )
    if version == _LEGACY_GRAPH_IDENTITY_VERSION:
        from route_inspector.rules.graph import graph_coarse_signature

        if normalized_kind.startswith("rrseq_"):
            graphs = _rrseq_graphs(normalized_kind, equivalence_payload)
            signature: Any = {
                "kind": normalized_kind,
                "ordered_rule_graph_signatures": [
                    graph_coarse_signature(graph) for graph in graphs
                ],
            }
        else:
            root = _legacy_rrsubtree_root(normalized_kind, equivalence_payload)
            signature = {
                "kind": normalized_kind,
                "rooted_tree_signature": _legacy_tree_node_signature(
                    root,
                    variant=_variant_for_kind(normalized_kind),
                ),
            }
    else:
        signature = {
            "identity_version": version,
            "kind": normalized_kind,
            "equivalence_payload": normalized_tactic_payload(
                normalized_kind,
                equivalence_payload,
                identity_version=version,
            ),
        }
    digest = hashlib.sha256(canonical_json(signature).encode("utf-8")).hexdigest()
    return f"tactic_i_{digest}"


def _legacy_tree_nodes_are_equivalent(
    left: Mapping[str, Any],
    right: Mapping[str, Any],
    *,
    variant: str,
) -> bool:
    from route_inspector.rules.graph import labelled_graphs_are_isomorphic

    left_graph = left.get("rule_graph")
    right_graph = right.get("rule_graph")
    if not isinstance(left_graph, Mapping) or not isinstance(right_graph, Mapping):
        raise ValueError("RRSubtree nodes require labelled rule graphs")
    if not labelled_graphs_are_isomorphic(left_graph, right_graph):
        return False
    left_children = _sequence(left.get("children"), field="RRSubtree children")
    right_children = _sequence(right.get("children"), field="RRSubtree children")
    if len(left_children) != len(right_children):
        return False
    if not all(isinstance(row, Mapping) for row in (*left_children, *right_children)):
        raise ValueError("RRSubtree children must be objects")

    right_rows = tuple(cast(Mapping[str, Any], row) for row in right_children)
    used: set[int] = set()

    def pair(left_index: int) -> bool:
        if left_index == len(left_children):
            return True
        left_row = cast(Mapping[str, Any], left_children[left_index])
        left_skipped = int(left_row.get("skipped_reaction_count", -1))
        left_child = left_row.get("child")
        if left_skipped < 0 or not isinstance(left_child, Mapping):
            raise ValueError("RRSubtree edge payload is invalid")
        for right_index, right_row in enumerate(right_rows):
            if right_index in used:
                continue
            right_skipped = int(right_row.get("skipped_reaction_count", -1))
            right_child = right_row.get("child")
            if (
                left_skipped != right_skipped
                or not isinstance(right_child, Mapping)
                or not _legacy_tree_nodes_are_equivalent(
                    left_child,
                    right_child,
                    variant=variant,
                )
            ):
                continue
            used.add(right_index)
            if pair(left_index + 1):
                return True
            used.remove(right_index)
        return False

    return pair(0)


def tactic_payloads_are_equivalent(
    kind: str,
    left: Mapping[str, Any],
    right: Mapping[str, Any],
    *,
    identity_version: int = _QUERY_CGR_KEY_IDENTITY_VERSION,
) -> bool:
    """Return the authoritative equivalence verdict for one identity version."""

    normalized_kind = _kind(kind)
    version = _identity_version(identity_version)
    if version >= 3:
        from route_inspector.reference_library.identity.transformation import (
            payloads_equivalent,
        )

        return payloads_equivalent(
            normalized_kind, left, right, identity_version=version
        )
    if version == _QUERY_CGR_KEY_IDENTITY_VERSION:
        left_payload = normalized_tactic_payload(
            normalized_kind,
            left,
            identity_version=version,
        )
        right_payload = normalized_tactic_payload(
            normalized_kind,
            right,
            identity_version=version,
        )
        return canonical_json(left_payload) == canonical_json(right_payload)

    from route_inspector.rules.graph import labelled_graphs_are_isomorphic

    if normalized_kind.startswith("rrseq_"):
        left_graphs = _rrseq_graphs(normalized_kind, left)
        right_graphs = _rrseq_graphs(normalized_kind, right)
        return len(left_graphs) == len(right_graphs) and all(
            labelled_graphs_are_isomorphic(left_graph, right_graph)
            for left_graph, right_graph in zip(left_graphs, right_graphs)
        )
    left_root = _legacy_rrsubtree_root(normalized_kind, left)
    right_root = _legacy_rrsubtree_root(normalized_kind, right)
    return _legacy_tree_nodes_are_equivalent(
        left_root,
        right_root,
        variant=_variant_for_kind(normalized_kind),
    )


def rrseq_tactic_identity(
    kind: Literal["rrseq_cons", "rrseq_gap"],
    rule_smarts: Sequence[str] | None = None,
    *,
    query_cgr_keys: Sequence[str] | None = None,
    rule_sides: Sequence[Mapping[str, Any]] | None = None,
    inter_selection_gap_widths: Sequence[int] | None = None,
    identity_version: int = _QUERY_CGR_KEY_IDENTITY_VERSION,
) -> Any:
    """Build an ordered RRSeq identity.

    Production callers should provide native query_cgr_keys. SMARTS-only
    callers may omit them; SynPlanner's cached canonical key helper is then
    used as a compatibility convenience.
    """

    normalized_kind = _kind(kind)
    if not normalized_kind.startswith("rrseq_"):
        raise ValueError("rrseq_tactic_identity requires an RRSeq kind")
    version = _identity_version(identity_version)
    rules = tuple(str(rule) for rule in (rule_smarts or ()))
    if rules and len(rules) < 2:
        raise ValueError("RRSeq identity requires at least two rules")
    if version == _LEGACY_GRAPH_IDENTITY_VERSION:
        if len(rules) < 2:
            raise ValueError("legacy RRSeq identity requires at least two rules")
        from route_inspector.rules.graph import rule_smarts_to_graph

        payload = {
            "family": "rrseq",
            "variant": _variant_for_kind(normalized_kind),
            "rules": [rule_smarts_to_graph(rule) for rule in rules],
        }
    else:
        keys = tuple(str(key) for key in (query_cgr_keys or ()))
        if not keys:
            if len(rules) < 2:
                raise ValueError(
                    "RRSeq identity requires native query_cgr_keys or rule SMARTS"
                )
            from route_inspector.rules.identity import rule_querycgr_identity

            keys = tuple(rule_querycgr_identity(rule) for rule in rules)
            if any(key.startswith("unparsed_smarts:") for key in keys):
                raise ValueError(
                    "RRSeq rule SMARTS cannot be parsed into complete query_cgr_keys"
                )
        if len(keys) < 2 or any(not key for key in keys):
            raise ValueError("RRSeq identity requires complete query_cgr_keys")
        if rules and len(rules) != len(keys):
            raise ValueError("RRSeq rules and query_cgr_keys lengths differ")
        payload = {
            "family": "rrseq",
            "variant": _variant_for_kind(normalized_kind),
            "query_cgr_keys": list(keys),
        }

    if version >= 3:
        if rule_sides is None:
            raise ValueError(
                "Transformation identity requires live extracted rule_sides"
            )
        payload["rule_sides"] = list(rule_sides)
    if version >= 4 and normalized_kind == "rrseq_gap":
        from route_inspector.tactics.rrseq.gap_widths import validate_gap_widths

        payload["inter_selection_gap_widths"] = list(
            validate_gap_widths(inter_selection_gap_widths, len(keys))
        )

    from route_inspector.reference_library.models import TacticIdentity

    return TacticIdentity(
        kind=normalized_kind,
        equivalence_payload=payload,
        identity_version=version,
    )


def _rrsubtree_payload(
    occurrence: Any,
    *,
    identity_version: int,
) -> dict[str, Any]:
    from route_inspector.tactics.rrsubtree.models import RRSubtreeOccurrence

    native = (
        occurrence
        if isinstance(occurrence, RRSubtreeOccurrence)
        else RRSubtreeOccurrence.from_dict(occurrence)
    )
    nodes = {node.reaction_node_path: node for node in native.nodes}
    children: dict[tuple[int, ...], list[Any]] = {path: [] for path in nodes}
    for edge in native.edges:
        children[edge.parent_reaction_node_path].append(edge)

    visited: set[tuple[int, ...]] = set()

    def visit(path: tuple[int, ...]) -> dict[str, Any]:
        if path in visited:
            raise ValueError("RRSubtree occurrence contains a cycle")
        try:
            node = nodes[path]
        except KeyError as exc:
            raise ValueError("RRSubtree edge references an unknown node") from exc
        visited.add(path)
        child_rows = [
            {
                "skipped_reaction_count": len(edge.skipped_reaction_node_paths),
                "child": visit(edge.child_reaction_node_path),
            }
            for edge in children[path]
        ]
        child_rows.sort(key=canonical_json)
        if identity_version == _LEGACY_GRAPH_IDENTITY_VERSION:
            from route_inspector.rules.graph import rule_smarts_to_graph

            return {
                "rule_graph": rule_smarts_to_graph(node.rule_smarts),
                "children": child_rows,
            }
        query_cgr_key = str(node.query_cgr_key or "")
        if not query_cgr_key:
            raise ValueError("RRSubtree identity requires native query_cgr_keys")
        return {
            "query_cgr_key": query_cgr_key,
            "children": child_rows,
        }

    root = visit(native.root_reaction_node_path)
    if visited != set(nodes):
        raise ValueError("RRSubtree occurrence contains unreachable selected nodes")
    return {
        "family": "rrsubtree",
        "variant": native.kind,
        "root": root,
    }


def rrsubtree_tactic_identity(
    occurrence: Any,
    *,
    identity_version: int = _QUERY_CGR_KEY_IDENTITY_VERSION,
) -> Any:
    """Build a rooted, sibling-order-invariant identity from an occurrence."""

    from route_inspector.reference_library.models import TacticIdentity
    from route_inspector.tactics.rrsubtree.models import RRSubtreeOccurrence

    native = (
        occurrence
        if isinstance(occurrence, RRSubtreeOccurrence)
        else RRSubtreeOccurrence.from_dict(occurrence)
    )
    version = _identity_version(identity_version)
    kind = cast(TacticKindText, f"rrsubtree_{native.kind}")
    return TacticIdentity(
        kind=kind,
        equivalence_payload=_rrsubtree_payload(
            native,
            identity_version=version,
        ),
        identity_version=version,
    )


__all__ = [
    "normalized_tactic_payload",
    "rrseq_tactic_identity",
    "rrsubtree_tactic_identity",
    "tactic_lookup_key",
    "tactic_payloads_are_equivalent",
]
