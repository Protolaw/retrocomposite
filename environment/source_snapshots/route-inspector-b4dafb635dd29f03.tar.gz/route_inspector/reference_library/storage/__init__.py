"""Reference-library persistence, schemas, and integrity validation."""
