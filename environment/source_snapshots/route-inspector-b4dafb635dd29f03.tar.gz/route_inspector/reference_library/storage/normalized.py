"""Lossless, content-addressed JSON storage for Reference format 7.

Logical catalog views retain the existing query contract. Only physical storage
changes: repeated JSON subtrees are stored once, compressed with stdlib zlib.
Typed container nodes distinguish references from arbitrary provenance fields.
"""

from __future__ import annotations

import hashlib
import json
import pickle
import sqlite3
import zlib
from collections import OrderedDict
from contextlib import contextmanager
from itertools import zip_longest

from route_inspector.infrastructure.auditing import (
    audit_active,
    audit_progress,
    audit_remember,
)
from route_inspector.infrastructure.build_workspace import ByteMemo
from route_inspector.rules.graph import canonical_json

OBJECT_PATH = "objects/payloads.sqlite"
FORMAT_VERSION = 7
_MIN_OBJECT_BYTES = 1024


class ObjectStore:
    def __init__(self, connection):
        self.connection = connection
        dictionary_path = connection.execute("PRAGMA database_list").fetchone()[2]
        if dictionary_path:
            from pathlib import Path

            stat = Path(dictionary_path).stat()
            self.audit_namespace = (
                dictionary_path,
                stat.st_dev,
                stat.st_ino,
                stat.st_size,
                stat.st_mtime_ns,
                stat.st_ctime_ns,
            )
        else:
            self.audit_namespace = id(connection)
        self._node = ByteMemo(self._read_node)
        self._known = OrderedDict()
        self._packed_rules = ByteMemo(lambda encoded: self.pack(json.loads(encoded)))

    def pack(self, value):
        if isinstance(value, dict):
            node = {
                "d": [
                    [key, self._named(key, child)]
                    for key, child in sorted(value.items())
                ]
            }
        elif isinstance(value, list):
            node = {"l": [self.pack(child) for child in value]}
        elif isinstance(value, str):
            node = {"s": value}
            if len(value) <= 80:
                return node
        else:
            return value
        raw = canonical_json(node).encode("utf-8")
        if len(raw) < _MIN_OBJECT_BYTES:
            return node
        key = hashlib.sha256(raw).hexdigest()
        if key not in self._known:
            self.connection.execute(
                "INSERT OR IGNORE INTO payload_objects VALUES (?, ?)",
                (key, zlib.compress(raw, level=3)),
            )
        self._known[key] = True
        self._known.move_to_end(key)
        if len(self._known) > 4096:
            self._known.popitem(last=False)
        return {"r": key}

    def _named(self, key, value):
        # Rule sides recur across many overlapping tactics. Cache exact encoded
        # values, never approximate chemical signatures or mutable user objects.
        if key == "rule_sides" and isinstance(value, list):
            return {"l": [self._cached_rule(side) for side in value]}
        return self.pack(value)

    def _cached_rule(self, value):
        return self._packed_rules(canonical_json(value))

    def _read_node(self, key):
        return audit_remember(
            "normalized_object",
            (self.audit_namespace, key),
            lambda: self._read_node_uncached(key),
        )

    def _read_node_uncached(self, key):
        row = self.connection.execute(
            "SELECT payload FROM payload_objects WHERE object_id=?", (key,)
        ).fetchone()
        if row is None:
            raise ValueError(f"missing normalized payload object: {key}")
        try:
            raw = zlib.decompress(row[0])
            node = json.loads(raw)
        except (zlib.error, ValueError) as exc:
            raise ValueError(f"invalid normalized payload object: {key}") from exc
        if (
            hashlib.sha256(raw).hexdigest() != key
            or canonical_json(node).encode() != raw
        ):
            raise ValueError(f"normalized payload object hash mismatch: {key}")
        return node

    def unpack(self, node, ancestors=()):
        if not isinstance(node, dict):
            if node is None or isinstance(node, (bool, int, float)):
                return node
            raise ValueError("invalid normalized payload primitive")
        if len(node) != 1:
            raise ValueError("invalid normalized payload node")
        if "r" in node:
            key = node["r"]
            if key in ancestors or len(ancestors) > 256:
                raise ValueError("cyclic normalized payload reference")
            if audit_active():

                def expand():
                    self._prime_audit_children(key, ancestors)
                    value = self.unpack(self._node(key), (*ancestors, key))
                    depth = self._reference_depth(key, ancestors)
                    return pickle.dumps(value, protocol=5), depth

                packed, depth = audit_remember(
                    "expanded_normalized_object", (self.audit_namespace, key), expand
                )
                if len(ancestors) + depth > 257:
                    raise ValueError("cyclic normalized payload reference")
                # Each caller receives a detached object, never shared mutable provenance.
                return pickle.loads(packed)
            return self.unpack(self._node(key), (*ancestors, key))
        if "s" in node and isinstance(node["s"], str):
            return node["s"]
        if "l" in node and isinstance(node["l"], list):
            return [self.unpack(child, ancestors) for child in node["l"]]
        if "d" in node and isinstance(node["d"], list):
            pairs = node["d"]
            if any(
                not isinstance(pair, list)
                or len(pair) != 2
                or not isinstance(pair[0], str)
                for pair in pairs
            ):
                raise ValueError("invalid normalized dictionary")
            keys = [pair[0] for pair in pairs]
            if keys != sorted(set(keys)):
                raise ValueError("duplicate or unordered normalized dictionary keys")
            return {key: self.unpack(child, ancestors) for key, child in pairs}
        raise ValueError("invalid normalized payload tag")

    def _prime_audit_children(self, root, ancestors):
        """Expand reference DAGs bottom-up, avoiding recursive cache-call stacks."""
        stack = [(root, ancestors, False)]
        while stack:
            key, parents, exiting = stack.pop()
            if key in parents or len(parents) > 256:
                raise ValueError("cyclic normalized payload reference")
            if exiting:
                if key != root:
                    self.unpack({"r": key}, parents)
                continue
            stack.append((key, parents, True))
            pending = [self._node(key)]
            children = []
            while pending:
                node = pending.pop()
                if isinstance(node, dict):
                    if set(node) == {"r"}:
                        children.append(node["r"])
                    else:
                        pending.extend(node.values())
                elif isinstance(node, list):
                    pending.extend(node)
            stack.extend((child, (*parents, key), False) for child in children)

    def _reference_depth(self, key, ancestors):
        if key in ancestors or len(ancestors) > 256:
            raise ValueError("cyclic normalized payload reference")

        def compute():
            def height(node):
                if isinstance(node, dict):
                    if set(node) == {"r"}:
                        return self._reference_depth(node["r"], (*ancestors, key))
                    return max((height(v) for v in node.values()), default=0)
                if isinstance(node, list):
                    return max((height(v) for v in node), default=0)
                return 0

            return 1 + height(self._node(key))

        depth = audit_remember(
            "normalized_reference_depth", (self.audit_namespace, key), compute
        )
        if len(ancestors) + depth > 257:
            raise ValueError("cyclic normalized payload reference")
        return depth

    def project_json(self, text, fields):
        """Decode selected top-level fields without expanding unrelated chemistry."""
        node = json.loads(text)
        ancestors = set()
        while isinstance(node, dict) and set(node) == {"r"}:
            key = node["r"]
            if key in ancestors or len(ancestors) > 256:
                raise ValueError("cyclic normalized payload reference")
            ancestors.add(key)
            node = self._node(key)
        if not isinstance(node, dict) or set(node) != {"d"}:
            raise ValueError("normalized projection requires a dictionary")
        pairs = node["d"]
        if not isinstance(pairs, list) or any(
            not isinstance(p, list) or len(p) != 2 or not isinstance(p[0], str)
            for p in pairs
        ):
            raise ValueError("invalid normalized dictionary")
        keys = [p[0] for p in pairs]
        if keys != sorted(set(keys)):
            raise ValueError("duplicate or unordered normalized dictionary keys")
        selected = set(json.loads(fields))
        return canonical_json(
            {
                key: self.unpack(child, tuple(ancestors))
                for key, child in pairs
                if key in selected
            }
        )

    def pack_json(self, text):
        return canonical_json(self.pack(json.loads(text)))

    def expand_json(self, text):
        return canonical_json(self.unpack(json.loads(text)))


def register(connection, *, create=False, source=None):
    if create:
        connection.execute(
            "CREATE TABLE IF NOT EXISTS payload_objects ("
            "object_id TEXT PRIMARY KEY, payload BLOB NOT NULL) WITHOUT ROWID"
        )
    store = ObjectStore(source if source is not None else connection)
    connection.create_function("ri_pack_json", 1, store.pack_json)
    connection.create_function(
        "ri_project_json", 2, store.project_json, deterministic=True
    )
    connection.create_function(
        "ri_expand_json", 1, store.expand_json, deterministic=True
    )
    return store


def _view_sql(name, columns):
    select = ",".join(
        f"ri_expand_json({column}) AS {column}" if column.endswith("_json") else column
        for column in columns
    )
    return f"CREATE VIEW {name} AS SELECT {select} FROM packed_{name}"


def normalize_table(connection, name):
    """Install views over empty builder tables; preserve indexes and foreign keys."""
    if not name.replace("_", "").isalnum():
        raise ValueError("invalid normalized table name")
    columns = [row[1] for row in connection.execute(f"PRAGMA table_info({name})")]
    primary = [
        row[1] for row in connection.execute(f"PRAGMA table_info({name})") if row[5]
    ]
    if (
        len(primary) != 1
        or connection.execute(f"SELECT 1 FROM {name} LIMIT 1").fetchone()
    ):
        raise ValueError("normalization requires an empty table with one primary key")
    packed = f"packed_{name}"
    connection.execute(f"ALTER TABLE {name} RENAME TO {packed}")
    values = ",".join(
        f"ri_pack_json(NEW.{column})" if column.endswith("_json") else f"NEW.{column}"
        for column in columns
    )
    assignments = ",".join(
        f"{column}=CASE WHEN NEW.{column} IS OLD.{column} THEN {column} ELSE ri_pack_json(NEW.{column}) END"
        if column.endswith("_json")
        else f"{column}=NEW.{column}"
        for column in columns
    )
    connection.executescript(
        _view_sql(name, columns) + ";"
        f"CREATE TRIGGER insert_{name} INSTEAD OF INSERT ON {name} BEGIN "
        f"INSERT INTO {packed} ({','.join(columns)}) VALUES ({values}); END;"
        f"CREATE TRIGGER update_{name} INSTEAD OF UPDATE ON {name} BEGIN "
        f"UPDATE {packed} SET {assignments} WHERE {primary[0]}=OLD.{primary[0]}; END;"
        f"CREATE TRIGGER delete_{name} INSTEAD OF DELETE ON {name} BEGIN "
        f"DELETE FROM {packed} WHERE {primary[0]}=OLD.{primary[0]}; END;"
    )


def write_objects(connection, path):
    """Publish one portable dictionary shared by sidecars and the runtime catalog."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.unlink(missing_ok=True)
    with sqlite3.connect(path) as target:
        target.execute("PRAGMA journal_mode=OFF")
        target.execute("PRAGMA user_version=1")
        register(target, create=True)
        target.executemany(
            "INSERT INTO payload_objects VALUES (?,?)",
            connection.execute(
                "SELECT object_id,payload FROM payload_objects ORDER BY object_id"
            ),
        )


def verify_objects(root, connection=None):
    """Verify every dictionary object, including otherwise unreferenced records."""
    if connection is not None:
        for name in ("entries", "occurrences"):
            columns = [
                r[1] for r in connection.execute(f"PRAGMA table_info(packed_{name})")
            ]
            row = connection.execute(
                "SELECT sql FROM sqlite_master WHERE type='view' AND name=?", (name,)
            ).fetchone()
            if row is None or row[0] != _view_sql(name, columns):
                raise ValueError(f"noncanonical normalized catalog view: {name}")
    with sidecar_store(root) as store:
        dictionary = store.connection
        if dictionary.execute("PRAGMA integrity_check").fetchone() != (
            "ok",
        ) or dictionary.execute("PRAGMA user_version").fetchone() != (1,):
            raise ValueError("invalid normalized object dictionary")
        total = dictionary.execute("SELECT COUNT(*) FROM payload_objects").fetchone()[0]
        audit_progress("Checking shared objects", 0, total, force=True)
        for completed, (key,) in enumerate(
            dictionary.execute(
                "SELECT object_id FROM payload_objects ORDER BY object_id"
            ),
            1,
        ):
            store._read_node(key)
            if completed % 1000 == 0:
                audit_progress("Checking shared objects", completed, total)
        audit_progress("Checking shared objects", total, total, force=True)


def verified_sidecar_rows(
    connection, root, path, query, parameters=(), *, label, occurrence=False
):
    """Check physical agreement before decoding each shared logical record once.

    Different valid packing remains supported through a logical comparison.
    The caller must first verify the dictionary and canonical runtime views.
    """
    from .artifacts import _iter_physical_jsonl

    with sidecar_store(root) as store:
        for row, packed in zip_longest(
            connection.execute(query, parameters),
            _iter_physical_jsonl(path, label=label),
        ):
            if row is None or packed is None:
                raise ValueError(f"{label} and SQLite counts differ")
            if occurrence:
                sql_packed = {
                    "d": [
                        ["entry_id", {"s": str(row["entry_id"])}],
                        ["occurrence", json.loads(row["occurrence_json"])],
                    ]
                }
            else:
                sql_packed = json.loads(row["entry_json"])
            record = store.unpack(packed)
            if not isinstance(record, dict):
                raise ValueError(f"{label} must decode to objects")
            if sql_packed != packed and canonical_json(
                store.unpack(sql_packed)
            ) != canonical_json(record):
                raise ValueError(f"{label} differs from SQLite")
            yield row, record


@contextmanager
def sidecar_store(root):
    """Decode portable records using the publication's bounded SQLite dictionary."""
    connection = _open_dictionary(root)
    try:
        yield ObjectStore(connection)
    finally:
        connection.close()


def _open_dictionary(root):
    connection = sqlite3.connect(
        f"{(root / OBJECT_PATH).resolve().as_uri()}?mode=ro", uri=True
    )
    # An immutable publication is read as one snapshot. Avoid reopening a
    # read transaction (and checking file locks) for every small DAG node.
    connection.execute("BEGIN")
    return connection


class CatalogConnection(sqlite3.Connection):
    """Close the library-local dictionary with its owning catalog handle."""

    payload_dictionary = None

    def close(self):
        try:
            super().close()
        finally:
            if self.payload_dictionary is not None:
                self.payload_dictionary.close()
                self.payload_dictionary = None


def attach_dictionary(connection, root):
    dictionary = _open_dictionary(root)
    connection.payload_dictionary = dictionary
    register(connection, source=dictionary)
