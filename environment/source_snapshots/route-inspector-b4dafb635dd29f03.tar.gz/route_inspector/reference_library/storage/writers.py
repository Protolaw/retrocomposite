"""Verified Reference-library implementation boundary."""

from __future__ import annotations

import csv
import json
import shutil
import sqlite3
import tempfile
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from typing import TYPE_CHECKING, Any

from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.reference_library.models import (
    TacticOccurrence,
)
from route_inspector.reference_library.profile import (
    canonical_json,
)
from route_inspector.reference_library.records import (
    TacticLibraryEntry,
    _collision_ordinal,
)
from route_inspector.reference_library.storage.artifacts import (
    _json_digest,
    _publish_directory_no_replace,
)
from route_inspector.reference_library.storage.contracts import (
    _SCHEMA_SQL,
    TACTIC_CATALOG_SCHEMA_VERSION,
    TACTIC_KINDS,
)

if TYPE_CHECKING:
    pass


class LibraryWriters:
    """Persistence operations for the ReferenceTacticLibrary protocol."""

    def save(
        self,
        directory: str | Path,
        *,
        include_sqlite: bool = True,
    ) -> Path:
        """Atomically publish portable JSONL, optionally with a SQLite accelerator."""

        if not isinstance(include_sqlite, bool):
            raise TypeError("include_sqlite must be a boolean")
        destination = Path(directory).expanduser()
        if destination.exists():
            raise FileExistsError(
                f"reference tactic-library destination already exists: {destination}"
            )
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = Path(
            tempfile.mkdtemp(
                prefix=f".{destination.name}.",
                suffix=".tmp",
                dir=destination.parent,
            )
        )
        try:
            if (
                self.manifest.library_format_version >= 7
                and self.directory is not None
                and (not include_sqlite or "catalog" in self.manifest.artifacts)
            ):
                artifacts = {}
                for name, descriptor in self.manifest.artifacts.items():
                    if name == "catalog" and not include_sqlite:
                        continue
                    target = temporary / descriptor["path"]
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(self.directory / descriptor["path"], target)
                    if (
                        target.stat().st_size != descriptor["size_bytes"]
                        or _sha256_file(target) != descriptor["sha256"]
                    ):
                        raise ValueError(
                            f"source artifact changed during normalized copy: {name}"
                        )
                    artifacts[name] = dict(descriptor)
                finalized_manifest = self.manifest.with_artifacts(artifacts)
            else:
                artifacts = self._write_artifacts(
                    temporary,
                    include_sqlite=include_sqlite,
                )
                finalized_manifest = self.manifest.with_artifacts(artifacts)
                if finalized_manifest.library_format_version >= 7:
                    from dataclasses import replace

                    finalized_manifest = replace(
                        finalized_manifest, library_format_version=6
                    )
            (temporary / "manifest.json").write_text(
                json.dumps(finalized_manifest.to_dict(), indent=2) + "\n",
                encoding="utf-8",
            )
            if destination.exists():
                raise FileExistsError(
                    "reference tactic-library destination appeared during build: "
                    f"{destination}"
                )
            _publish_directory_no_replace(temporary, destination)
        except Exception:
            shutil.rmtree(temporary, ignore_errors=True)
            raise
        self.manifest = finalized_manifest
        return destination

    def _write_artifacts(
        self,
        directory: Path,
        *,
        include_sqlite: bool,
    ) -> dict[str, dict[str, Any]]:
        for child in (
            "rrseq",
            "rrsubtree",
            "retro_bleu_bigrams",
            "provenance",
            "reports",
        ):
            (directory / child).mkdir(parents=True, exist_ok=True)
        occurrence_rows = tuple(self._iter_occurrence_rows())
        entries = self.entries()

        rrseq_entries_path = directory / "rrseq" / "entries.jsonl"
        rrsubtree_entries_path = directory / "rrsubtree" / "entries.jsonl"
        self._write_jsonl(
            rrseq_entries_path,
            (entry.to_dict() for entry in entries if entry.kind.startswith("rrseq_")),
        )
        self._write_jsonl(
            rrsubtree_entries_path,
            (
                entry.to_dict()
                for entry in entries
                if entry.kind.startswith("rrsubtree_")
            ),
        )
        occurrences_path = directory / "provenance" / "occurrences.jsonl"
        self._write_jsonl(
            occurrences_path,
            (
                {"entry_id": entry_id, "occurrence": occurrence.to_dict()}
                for entry_id, occurrence in occurrence_rows
            ),
        )

        report_paths: dict[str, Path] = {}
        for kind in TACTIC_KINDS:
            path = directory / "reports" / f"{kind}.tsv"
            self._write_report(path, self.entries(kind))
            report_paths[f"report_{kind}"] = path

        bigram_paths: dict[str, Path] = {}
        if self.retro_bleu_bigram_catalog is not None:
            bigram_entries_path = directory / "retro_bleu_bigrams" / "entries.jsonl"
            bigram_occurrences_path = (
                directory / "retro_bleu_bigrams" / "occurrences.jsonl"
            )
            bigram_report_path = directory / "reports" / "retro_bleu_bigrams.tsv"
            self._write_jsonl(
                bigram_entries_path,
                self.retro_bleu_bigram_catalog.entry_records(),
            )
            self._write_jsonl(
                bigram_occurrences_path,
                self.retro_bleu_bigram_catalog.occurrence_records(),
            )
            self._write_bigram_report(
                bigram_report_path,
                self.retro_bleu_bigram_catalog.entries(),
            )
            bigram_paths = {
                "retro_bleu_bigram_entries": bigram_entries_path,
                "retro_bleu_bigram_occurrences": bigram_occurrences_path,
                "report_retro_bleu_bigrams": bigram_report_path,
            }

        component_paths: dict[str, Path] = {}
        if self.pg_strategy_library is not None:
            component_paths["pg_strategy_manifest"] = (
                self.pg_strategy_library.write_component(
                    directory, include_sqlite=include_sqlite
                )
            )
        paths = {
            "rrseq_entries": rrseq_entries_path,
            "rrsubtree_entries": rrsubtree_entries_path,
            "occurrences": occurrences_path,
            **report_paths,
            **bigram_paths,
            **component_paths,
        }
        if self.manifest.library_format_version < 6:
            summary_path = directory / "summary.json"
            summary_path.write_text(
                json.dumps(self.manifest.legacy_summary(), indent=2) + "\n",
                encoding="utf-8",
            )
            paths["summary"] = summary_path
        if include_sqlite:
            catalog_path = directory / "catalog.sqlite"
            self._write_sqlite(catalog_path, occurrence_rows)
            paths["catalog"] = catalog_path
        return {
            name: {
                "path": path.relative_to(directory).as_posix(),
                "sha256": _sha256_file(path),
                "size_bytes": path.stat().st_size,
            }
            for name, path in sorted(paths.items())
        }

    def _write_sqlite(
        self,
        path: Path,
        occurrence_rows: Sequence[tuple[str, TacticOccurrence]],
    ) -> None:
        connection = sqlite3.connect(path)
        try:
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA journal_mode = OFF")
            connection.execute("PRAGMA synchronous = OFF")
            connection.execute(f"PRAGMA user_version = {TACTIC_CATALOG_SCHEMA_VERSION}")
            connection.executescript(_SCHEMA_SQL)
            entries = self.entries()
            metadata = {
                "library_id": self.library_id,
                "configuration_fingerprint": self.processing_profile.fingerprint,
                "processing_profile": self.processing_profile.to_dict(),
                "entry_count": len(entries),
                "occurrence_count": len(occurrence_rows),
            }
            with connection:
                connection.executemany(
                    "INSERT INTO metadata(key, value_json) VALUES (?, ?)",
                    [(key, canonical_json(metadata[key])) for key in sorted(metadata)],
                )
                connection.executemany(
                    """INSERT INTO entries(
                           entry_id, tactic_kind, identity_version, lookup_key,
                           collision_ordinal, occurrence_count, route_count,
                           representative_occurrence_id, entry_json
                       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    [
                        (
                            entry.entry_id,
                            entry.kind,
                            entry.identity.identity_version,
                            entry.lookup_key,
                            _collision_ordinal(entry.entry_id),
                            entry.occurrence_count,
                            entry.route_count,
                            entry.representative_occurrence_id,
                            canonical_json(entry.to_dict()),
                        )
                        for entry in entries
                    ],
                )
                connection.executemany(
                    """INSERT INTO entry_routes(
                           entry_id, dataset_id, source_identity, route_id
                       ) VALUES (?, ?, ?, ?)""",
                    [
                        (
                            entry.entry_id,
                            route.dataset_id,
                            route.source_identity,
                            route.route_id,
                        )
                        for entry in entries
                        for route in entry.reference_routes
                    ],
                )
                connection.executemany(
                    """INSERT INTO occurrences(
                           reference_occurrence_id, native_occurrence_id,
                           entry_id, tactic_kind, dataset_id, source_identity,
                           route_id, native_schema_version, content_sha256,
                           occurrence_json
                       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    [
                        (
                            occurrence.reference_occurrence_id,
                            occurrence.occurrence_id,
                            entry_id,
                            occurrence.identity.kind,
                            occurrence.route.dataset_id,
                            occurrence.route.source_identity,
                            occurrence.route.route_id,
                            occurrence.native_schema_version,
                            _json_digest(occurrence.to_dict()),
                            canonical_json(occurrence.to_dict()),
                        )
                        for entry_id, occurrence in occurrence_rows
                    ],
                )
            self._validate_connection(connection)
            connection.execute("VACUUM")
        finally:
            connection.close()

    @staticmethod
    def _write_jsonl(path: Path, records: Iterable[Mapping[str, Any]]) -> None:
        with path.open("w", encoding="utf-8", newline="\n") as stream:
            for record in records:
                stream.write(canonical_json(record) + "\n")

    @staticmethod
    def _write_report(
        path: Path,
        entries: Sequence[TacticLibraryEntry],
    ) -> None:
        fields = (
            "entry_id",
            "kind",
            "lookup_key",
            "occurrence_count",
            "route_count",
            "representative_occurrence_id",
            "reference_routes_json",
            "route_target_smiles_json",
            "motif_target_smiles_json",
            "annotation_summary_json",
        )
        with path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(
                stream,
                fieldnames=fields,
                delimiter="\t",
                lineterminator="\n",
            )
            writer.writeheader()
            for entry in entries:
                writer.writerow(
                    {
                        "entry_id": entry.entry_id,
                        "kind": entry.kind,
                        "lookup_key": entry.lookup_key,
                        "occurrence_count": entry.occurrence_count,
                        "route_count": entry.route_count,
                        "representative_occurrence_id": (
                            entry.representative_occurrence_id
                        ),
                        "reference_routes_json": canonical_json(
                            [route.to_dict() for route in entry.reference_routes]
                        ),
                        "route_target_smiles_json": canonical_json(
                            entry.route_target_smiles
                        ),
                        "motif_target_smiles_json": canonical_json(
                            entry.motif_target_smiles
                        ),
                        "annotation_summary_json": canonical_json(
                            entry.annotation_summary
                        ),
                    }
                )

    @staticmethod
    def _write_bigram_report(path: Path, entries: Sequence[Any]) -> None:
        fields = (
            "entry_id",
            "lookup_key",
            "retro_bleu_bigram",
            "occurrence_count",
            "route_count",
            "no_rrseq_occurrence_count",
            "no_rrseq_route_count",
            "representative_occurrence_id",
            "no_rrseq_representative_occurrence_id",
            "reference_routes_json",
            "no_rrseq_reference_routes_json",
        )
        with path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(
                stream,
                fieldnames=fields,
                delimiter="\t",
                lineterminator="\n",
            )
            writer.writeheader()
            for entry in entries:
                writer.writerow(
                    {
                        "entry_id": entry.entry_id,
                        "lookup_key": entry.identity.lookup_key,
                        "retro_bleu_bigram": "$".join(entry.representative_rule_smarts),
                        "occurrence_count": entry.occurrence_count,
                        "route_count": entry.route_count,
                        "no_rrseq_occurrence_count": (entry.no_rrseq_occurrence_count),
                        "no_rrseq_route_count": entry.no_rrseq_route_count,
                        "representative_occurrence_id": (
                            entry.representative_occurrence_id
                        ),
                        "no_rrseq_representative_occurrence_id": (
                            entry.no_rrseq_representative_occurrence_id or ""
                        ),
                        "reference_routes_json": canonical_json(
                            [route.to_dict() for route in entry.reference_routes]
                        ),
                        "no_rrseq_reference_routes_json": canonical_json(
                            [
                                route.to_dict()
                                for route in entry.no_rrseq_reference_routes
                            ]
                        ),
                    }
                )
