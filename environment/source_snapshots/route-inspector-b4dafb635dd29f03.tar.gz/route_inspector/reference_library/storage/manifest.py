"""Human-inspectable manifest for a reloadable reference tactic library."""

from __future__ import annotations

import json
from collections.abc import Sequence
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from importlib.metadata import PackageNotFoundError, version
from pathlib import PurePosixPath
from typing import Any, Mapping

from route_inspector import __version__
from route_inspector.reference_library.models import (
    REFERENCE_OCCURRENCE_ID_VERSION,
    TACTIC_IDENTITY_VERSION,
)
from route_inspector.reference_library.profile import (
    ReferenceProcessingProfile,
    canonical_json,
)
from route_inspector.rules.graph import GRAPH_SCHEMA_VERSION

REFERENCE_LIBRARY_FORMAT_VERSION = 6
SUPPORTED_REFERENCE_LIBRARY_FORMAT_VERSIONS = frozenset({1, 2, 3, 4, 5, 6, 7})
REFERENCE_TACTIC_CATALOG_SCHEMA_VERSION = 1
LEGACY_REFERENCE_TACTIC_IDENTITY_CONFIGURATION = {
    "tactic_identity_version": 1,
    "reference_occurrence_id_version": REFERENCE_OCCURRENCE_ID_VERSION,
    "reference_occurrence_id_scope": (
        "tactic_kind_and_full_reference_route_and_native_id"
    ),
    "rule_graph_schema_version": GRAPH_SCHEMA_VERSION,
    "lookup_key_role": "candidate_index_only",
    "authoritative_equivalence": "exact_labelled_graph_and_rooted_topology",
    "reaction_side_atom_state_preserved": True,
    "unrepresented_query_constraint_policy": "reject_fail_closed",
    "rrseq_rule_order_preserved": True,
    "rrseq_gap_width_in_identity": False,
    "rrsubtree_sibling_order_preserved": False,
    "rrsubtree_skipped_reaction_count_in_identity": True,
}


def _synplanner_version() -> str:
    try:
        return version("SynPlanner")
    except PackageNotFoundError:
        return "unavailable"


REFERENCE_TACTIC_IDENTITY_CONFIGURATION = {
    "tactic_identity_version": TACTIC_IDENTITY_VERSION,
    "synplanner_version": _synplanner_version(),
    "reference_occurrence_id_version": REFERENCE_OCCURRENCE_ID_VERSION,
    "reference_occurrence_id_scope": (
        "tactic_kind_and_full_reference_route_and_native_id"
    ),
    "query_cgr_key_source": "synplan.chem.utils.canonical_query_cgr_key",
    "canonical_key_function_contract": (
        "canonical_query_cgr_key(QueryCGR) -> deterministic str"
    ),
    "query_cgr_key_scope": "context_bearing",
    "lookup_key_role": "sha256_locator_only",
    "authoritative_equivalence": ("complete_query_cgr_key_payload_and_rooted_topology"),
    "canonicalization_fallback": (
        "deterministic_greedy_ordering_may_split_high_symmetry_equivalents"
    ),
    "rrseq_rule_order_preserved": True,
    "rrseq_gap_width_in_identity": False,
    "rrsubtree_sibling_order_preserved": False,
    "rrsubtree_skipped_reaction_count_in_identity": True,
}

_ROUTE_COUNT_PREFIX = "route_count"
TRANSFORMATION_IDENTITY_CONFIGURATION = {
    **REFERENCE_TACTIC_IDENTITY_CONFIGURATION,
    "tactic_identity_version": 3,
    "authoritative_equivalence": "independent_query_sides_and_rooted_topology",
    "lookup_key_role": "candidate_signature_only",
    "canonicalization_fallback": "exact_isomorphism_within_candidate_buckets",
    "query_side_source": "live_extracted_query_objects",
    "cross_side_atom_correspondence_in_identity": False,
    "unrepresented_query_constraint_policy": "exact_representation_only",
}
WIDTH_IDENTITY_CONFIGURATION = {
    **TRANSFORMATION_IDENTITY_CONFIGURATION,
    "tactic_identity_version": 4,
    "rrseq_gap_width_in_identity": True,
    "rrseq_gap_width_encoding": "ordered_inter_selection_counts_including_zeros",
}

_REQUIRED_ROUTE_COUNTS = (
    "route_count",
    "route_count_with_tactics",
    "route_count_without_extracted_tactics",
)


def _created_at() -> str:
    return datetime.now(timezone.utc).isoformat()


def _detached_mapping(value: Mapping[str, Any], *, label: str) -> dict[str, Any]:
    try:
        return json.loads(canonical_json(value))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be JSON-compatible") from exc


def _validate_relative_artifact_path(value: str) -> None:
    path = PurePosixPath(value)
    if not value or path.is_absolute() or ".." in path.parts:
        raise ValueError(f"artifact path must be library-relative: {value!r}")


def compact_supplementary_evidence(value: Mapping[str, Any]) -> dict[str, Any]:
    """Keep cohort counts and definitions; membership comes from route provenance."""
    result = _detached_mapping(value, label="supplementary_evidence")
    bigrams = result.get("retro_bleu_bigrams")
    if isinstance(bigrams, dict):
        bigrams.pop("reference_route_ids_without_rrseq_cons_or_gap", None)
    return result


def normalize_reference_corpora(
    values: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any], ...]:
    """Validate and deterministically order Reference-corpus descriptors."""

    corpora: list[dict[str, Any]] = []
    for index, value in enumerate(values):
        if not isinstance(value, Mapping):
            raise ValueError(f"reference_corpora[{index}] must be an object")
        corpus = _detached_mapping(value, label=f"reference_corpora[{index}]")
        dataset_id = str(corpus.get("dataset_id") or "").strip()
        source_identity = str(corpus.get("source_identity") or "").strip()
        if not dataset_id:
            raise ValueError("Reference corpus requires non-empty dataset_id")
        if not source_identity:
            raise ValueError("Reference corpus requires non-empty source_identity")
        corpus["dataset_id"] = dataset_id
        corpus["source_identity"] = source_identity

        missing_counts = [name for name in _REQUIRED_ROUTE_COUNTS if name not in corpus]
        if missing_counts:
            raise ValueError(
                "Reference corpus requires complete route counts: "
                + ", ".join(missing_counts)
            )

        for name, count in tuple(corpus.items()):
            if name != _ROUTE_COUNT_PREFIX and not name.startswith(
                f"{_ROUTE_COUNT_PREFIX}_"
            ):
                continue
            if isinstance(count, bool) or not isinstance(count, int) or count < 0:
                raise ValueError(
                    f"Reference corpus {name!r} must be a non-negative integer"
                )

        raw_route_ids = corpus.get("route_ids")
        if raw_route_ids is not None:
            if not isinstance(raw_route_ids, Sequence) or isinstance(
                raw_route_ids, (str, bytes)
            ):
                raise ValueError("Reference corpus route_ids must be an array")
            route_ids = tuple(
                sorted(str(route_id).strip() for route_id in raw_route_ids)
            )
            if any(not route_id for route_id in route_ids):
                raise ValueError("Reference corpus route_ids must not contain blanks")
            if len(route_ids) != len(set(route_ids)):
                raise ValueError("Reference corpus route_ids must be unique")
            corpus["route_ids"] = list(route_ids)
            route_count = corpus.get("route_count")
            if route_count is not None and route_count != len(route_ids):
                raise ValueError(
                    "Reference corpus route_count must equal route_ids length"
                )

        raw_no_rrseq_ids = corpus.get("route_ids_without_rrseq_cons_or_gap")
        if raw_no_rrseq_ids is not None:
            if not isinstance(raw_no_rrseq_ids, Sequence) or isinstance(
                raw_no_rrseq_ids,
                (str, bytes),
            ):
                raise ValueError(
                    "Reference corpus route_ids_without_rrseq_cons_or_gap "
                    "must be an array"
                )
            no_rrseq_ids = tuple(
                sorted(str(route_id).strip() for route_id in raw_no_rrseq_ids)
            )
            if any(not route_id for route_id in no_rrseq_ids) or len(
                no_rrseq_ids
            ) != len(set(no_rrseq_ids)):
                raise ValueError(
                    "Reference corpus no-RRSeq route IDs must be non-empty and unique"
                )
            if raw_route_ids is not None and not set(no_rrseq_ids).issubset(
                corpus["route_ids"]
            ):
                raise ValueError(
                    "Reference corpus no-RRSeq route IDs must be a route_ids subset"
                )
            corpus["route_ids_without_rrseq_cons_or_gap"] = list(no_rrseq_ids)
            recorded_count = corpus.get("route_count_without_rrseq_cons_or_gap")
            if recorded_count is not None and recorded_count != len(no_rrseq_ids):
                raise ValueError(
                    "Reference corpus no-RRSeq route count must equal its ID list"
                )

        total = corpus["route_count"]
        with_tactics = corpus["route_count_with_tactics"]
        without_tactics = corpus["route_count_without_extracted_tactics"]
        for name, count in (
            ("route_count_with_tactics", with_tactics),
            ("route_count_without_extracted_tactics", without_tactics),
        ):
            if count > total:
                raise ValueError(f"Reference corpus {name} exceeds route_count")
        if with_tactics + without_tactics != total:
            raise ValueError(
                "Reference corpus with/without-tactic counts must sum to route_count"
            )

        input_sha256 = corpus.get("input_sha256")
        if input_sha256 is not None:
            digest = str(input_sha256)
            if len(digest) != 64 or any(
                character not in "0123456789abcdef" for character in digest
            ):
                raise ValueError("Reference corpus input_sha256 is invalid")
            corpus["input_sha256"] = digest
        corpora.append(corpus)

    if not corpora:
        raise ValueError("reference_corpora must not be empty")
    corpora.sort(
        key=lambda corpus: canonical_json(
            [corpus["dataset_id"], corpus["source_identity"]]
        )
    )
    keys = [(corpus["dataset_id"], corpus["source_identity"]) for corpus in corpora]
    if len(keys) != len(set(keys)):
        raise ValueError("reference_corpora must not contain duplicates")
    return tuple(corpora)


@dataclass(frozen=True)
class ReferenceLibraryManifest:
    """Versioned metadata binding one catalog to its processing profile."""

    library_id: str
    processing_profile: ReferenceProcessingProfile
    reference_corpora: tuple[Mapping[str, Any], ...]
    statistics: Mapping[str, Any]
    identity_configuration: Mapping[str, Any] = field(
        default_factory=lambda: dict(REFERENCE_TACTIC_IDENTITY_CONFIGURATION)
    )
    supplementary_evidence: Mapping[str, Any] = field(default_factory=dict)
    components: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)
    artifacts: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)
    route_inspector_version: str = __version__
    route_inspector_commit: str = ""
    catalog_schema_version: int = REFERENCE_TACTIC_CATALOG_SCHEMA_VERSION
    created_at: str = field(default_factory=_created_at)
    library_format_version: int = REFERENCE_LIBRARY_FORMAT_VERSION

    def __post_init__(self) -> None:
        if (
            self.library_format_version
            not in SUPPORTED_REFERENCE_LIBRARY_FORMAT_VERSIONS
        ):
            raise ValueError(
                "unsupported reference library format version: "
                f"{self.library_format_version}"
            )
        if not self.library_id:
            raise ValueError("library_id must not be empty")
        if self.catalog_schema_version < 1:
            raise ValueError("catalog_schema_version must be positive")
        if not self.route_inspector_version:
            raise ValueError("route_inspector_version must not be empty")
        try:
            parsed_timestamp = datetime.fromisoformat(self.created_at)
        except ValueError as exc:
            raise ValueError("created_at must be an ISO-8601 timestamp") from exc
        if parsed_timestamp.tzinfo is None:
            raise ValueError("created_at must include a timezone")

        object.__setattr__(
            self,
            "reference_corpora",
            normalize_reference_corpora(self.reference_corpora),
        )
        object.__setattr__(
            self,
            "statistics",
            _detached_mapping(self.statistics, label="statistics"),
        )
        identity_configuration = _detached_mapping(
            self.identity_configuration,
            label="identity_configuration",
        )
        expected_identity_configuration = (
            WIDTH_IDENTITY_CONFIGURATION
            if self.library_format_version == 5
            else TRANSFORMATION_IDENTITY_CONFIGURATION
            if self.library_format_version == 4
            else REFERENCE_TACTIC_IDENTITY_CONFIGURATION
            if self.library_format_version >= 3
            else LEGACY_REFERENCE_TACTIC_IDENTITY_CONFIGURATION
        )
        if self.library_format_version >= 6:
            # Storage layout and scientific identity are independent contracts.
            expected_identity_configuration = {
                1: LEGACY_REFERENCE_TACTIC_IDENTITY_CONFIGURATION,
                2: REFERENCE_TACTIC_IDENTITY_CONFIGURATION,
                3: TRANSFORMATION_IDENTITY_CONFIGURATION,
                4: WIDTH_IDENTITY_CONFIGURATION,
            }.get(identity_configuration.get("tactic_identity_version"))
            if expected_identity_configuration is None:
                raise ValueError("unsupported tactic identity configuration")
        if expected_identity_configuration.get("tactic_identity_version") != 1:
            observed_version = str(
                identity_configuration.get("synplanner_version") or ""
            )
            observed_contract = dict(identity_configuration)
            expected_contract = dict(expected_identity_configuration)
            observed_contract.pop("synplanner_version", None)
            expected_contract.pop("synplanner_version", None)
            compatible_identity_configuration = (
                bool(observed_version) and observed_contract == expected_contract
            )
        else:
            compatible_identity_configuration = (
                identity_configuration == expected_identity_configuration
            )
        if not compatible_identity_configuration:
            raise ValueError(
                "manifest identity configuration is incompatible with "
                f"library format version {self.library_format_version}"
            )
        object.__setattr__(
            self,
            "identity_configuration",
            identity_configuration,
        )
        supplementary_evidence = _detached_mapping(
            self.supplementary_evidence,
            label="supplementary_evidence",
        )
        object.__setattr__(
            self,
            "supplementary_evidence",
            supplementary_evidence,
        )
        components = _detached_mapping(self.components, label="components")
        if self.library_format_version == 1 and components:
            raise ValueError(
                "Reference-library format v1 cannot declare peer components"
            )
        normalized_components: dict[str, dict[str, Any]] = {}
        for name, raw_component in sorted(components.items()):
            component = _detached_mapping(
                raw_component,
                label=f"component {name!r}",
            )
            path = str(component.get("manifest_path") or "")
            library_id = str(component.get("library_id") or "")
            _validate_relative_artifact_path(path)
            if not library_id:
                raise ValueError(f"component {name!r} requires a library_id")
            for version_name in ("library_format_version", "catalog_schema_version"):
                version = component.get(version_name)
                if (
                    isinstance(version, bool)
                    or not isinstance(version, int)
                    or version < 1
                ):
                    raise ValueError(
                        f"component {name!r} requires positive {version_name}"
                    )
            normalized_components[str(name)] = component
        object.__setattr__(self, "components", normalized_components)

        normalized_artifacts: dict[str, dict[str, Any]] = {}
        for name, raw_descriptor in sorted(self.artifacts.items()):
            descriptor = _detached_mapping(
                raw_descriptor,
                label=f"artifact {name!r}",
            )
            path = str(descriptor.get("path") or "")
            digest = str(descriptor.get("sha256") or "")
            size = descriptor.get("size_bytes")
            _validate_relative_artifact_path(path)
            if len(digest) != 64 or any(
                character not in "0123456789abcdef" for character in digest
            ):
                raise ValueError(f"artifact {name!r} has an invalid SHA-256")
            if isinstance(size, bool) or not isinstance(size, int) or size < 0:
                raise ValueError(f"artifact {name!r} requires non-negative size_bytes")
            normalized_artifacts[str(name)] = {
                "path": path,
                "sha256": digest,
                "size_bytes": size,
            }
        object.__setattr__(self, "artifacts", normalized_artifacts)

    @property
    def configuration_fingerprint(self) -> str:
        return self.processing_profile.fingerprint

    def with_artifacts(
        self,
        artifacts: Mapping[str, Mapping[str, Any]],
    ) -> "ReferenceLibraryManifest":
        """Return a copy bound to finalized artifact hashes."""

        return replace(self, artifacts=artifacts)

    def with_components(
        self,
        components: Mapping[str, Mapping[str, Any]],
    ) -> "ReferenceLibraryManifest":
        """Return a copy declaring independently versioned peer components."""

        return replace(self, components=components)

    def legacy_summary(self) -> dict[str, Any]:
        """Reproduce the mandatory summary contract for storage formats 1–5."""
        return {
            "library_format_version": self.library_format_version,
            "catalog_schema_version": self.catalog_schema_version,
            "identity_configuration": dict(self.identity_configuration),
            "library_id": self.library_id,
            "configuration_fingerprint": self.configuration_fingerprint,
            **(
                {"supplementary_evidence": dict(self.supplementary_evidence)}
                if self.supplementary_evidence
                else {}
            ),
            **({"components": dict(self.components)} if self.components else {}),
            **dict(self.statistics),
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "library_format_version": self.library_format_version,
            "library_id": self.library_id,
            "created_at": self.created_at,
            "route_inspector_version": self.route_inspector_version,
            "route_inspector_commit": self.route_inspector_commit,
            "catalog_schema_version": self.catalog_schema_version,
            "configuration_fingerprint": self.configuration_fingerprint,
            "processing_profile": self.processing_profile.to_dict(),
            "identity_configuration": dict(self.identity_configuration),
            "supplementary_evidence": dict(self.supplementary_evidence),
            "components": {
                name: dict(value) for name, value in sorted(self.components.items())
            },
            "reference_corpora": [dict(corpus) for corpus in self.reference_corpora],
            "statistics": dict(self.statistics),
            "artifacts": {
                name: dict(descriptor)
                for name, descriptor in sorted(self.artifacts.items())
            },
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ReferenceLibraryManifest":
        profile = ReferenceProcessingProfile.from_dict(value["processing_profile"])
        recorded_fingerprint = str(value.get("configuration_fingerprint") or "")
        if recorded_fingerprint != profile.fingerprint:
            raise ValueError(
                "manifest configuration fingerprint does not match its "
                "processing profile"
            )
        return cls(
            library_format_version=int(value.get("library_format_version", -1)),
            library_id=str(value["library_id"]),
            created_at=str(value["created_at"]),
            route_inspector_version=str(value["route_inspector_version"]),
            route_inspector_commit=str(value.get("route_inspector_commit") or ""),
            catalog_schema_version=int(value["catalog_schema_version"]),
            processing_profile=profile,
            identity_configuration=dict(value.get("identity_configuration") or {}),
            supplementary_evidence=dict(value.get("supplementary_evidence") or {}),
            components=dict(value.get("components") or {}),
            reference_corpora=tuple(value.get("reference_corpora") or ()),
            statistics=dict(value.get("statistics") or {}),
            artifacts=dict(value.get("artifacts") or {}),
        )


__all__ = [
    "LEGACY_REFERENCE_TACTIC_IDENTITY_CONFIGURATION",
    "REFERENCE_LIBRARY_FORMAT_VERSION",
    "REFERENCE_TACTIC_CATALOG_SCHEMA_VERSION",
    "REFERENCE_TACTIC_IDENTITY_CONFIGURATION",
    "SUPPORTED_REFERENCE_LIBRARY_FORMAT_VERSIONS",
    "ReferenceLibraryManifest",
    "normalize_reference_corpora",
]
