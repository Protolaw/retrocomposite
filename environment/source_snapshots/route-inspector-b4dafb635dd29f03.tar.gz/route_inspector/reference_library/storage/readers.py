"""Verified Reference-library implementation boundary."""

from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
from collections import Counter, defaultdict
from collections.abc import Mapping
from itertools import zip_longest
from pathlib import Path
from types import SimpleNamespace
from typing import TYPE_CHECKING, Any, Literal

from route_inspector.infrastructure.auditing import audit_progress, audit_scope
from route_inspector.infrastructure.build_workspace import ByteMemo
from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.reference_library.build.aggregation import (
    _accumulate_annotation_summary,
    _finalize_annotation_summary,
    _library_statistics,
    _validate_observed_route_corpora,
)
from route_inspector.reference_library.identity.certificates import (
    _identity_exact_certificate,
    _identity_sort_key,
)
from route_inspector.reference_library.models import (
    ReferenceRouteKey,
    TacticIdentity,
    TacticOccurrence,
)
from route_inspector.reference_library.profile import (
    ReferenceProcessingProfile,
    canonical_json,
)
from route_inspector.reference_library.records import (
    TacticLibraryEntry,
    _collision_ordinal,
    _route_sort_key,
)
from route_inspector.reference_library.storage.artifacts import (
    _iter_canonical_jsonl,
    _json_digest,
    _read_canonical_jsonl,
)
from route_inspector.reference_library.storage.contracts import (
    _ALLOWED_ARTIFACTS,
    _ARTIFACT_PATHS,
    _BIGRAM_ARTIFACTS,
    _COLLISION_ORDINAL_WIDTH,
    _REQUIRED_ARTIFACTS,
    TACTIC_CATALOG_SCHEMA_VERSION,
    TACTIC_KINDS,
    TACTIC_LIBRARY_ID_FORMAT_VERSION,
)
from route_inspector.reference_library.storage.manifest import ReferenceLibraryManifest

if TYPE_CHECKING:
    from route_inspector.reference_library.catalog import ReferenceTacticLibrary

_LOG = logging.getLogger(__name__)


class LibraryReaders:
    """Persistence operations for the ReferenceTacticLibrary protocol."""

    @staticmethod
    def _validate_legacy_summary(
        root: Path, manifest: ReferenceLibraryManifest
    ) -> None:
        if manifest.library_format_version >= 6:
            return
        path = root / str(manifest.artifacts["summary"]["path"])
        if json.loads(path.read_text(encoding="utf-8")) != manifest.legacy_summary():
            raise ValueError("summary.json disagrees with the validated manifest")

    @classmethod
    def _load_bigram_catalog(
        cls,
        root: Path,
        manifest: ReferenceLibraryManifest,
    ) -> Any | None:
        declared = set(manifest.artifacts) & _BIGRAM_ARTIFACTS
        metadata = manifest.supplementary_evidence.get("retro_bleu_bigrams")
        if declared and declared != _BIGRAM_ARTIFACTS:
            raise ValueError(
                "Retro-BLEU bigram artifacts must be declared as a complete group"
            )
        if not declared:
            if metadata is not None:
                raise ValueError(
                    "manifest declares Retro-BLEU bigram metadata without artifacts"
                )
            return None
        if not isinstance(metadata, Mapping):
            raise ValueError(
                "Retro-BLEU bigram artifacts require supplementary metadata"
            )

        from route_inspector.reference_library.bigram_catalog import (
            RetroBleuBigramCatalog,
        )

        entry_records = _read_canonical_jsonl(
            root / str(manifest.artifacts["retro_bleu_bigram_entries"]["path"]),
            label="retro_bleu_bigram_entries",
        )
        occurrence_records = _read_canonical_jsonl(
            root / str(manifest.artifacts["retro_bleu_bigram_occurrences"]["path"]),
            label="retro_bleu_bigram_occurrences",
        )
        catalog_id = str(metadata.get("retro_bleu_bigram_catalog_id") or "")
        catalog = RetroBleuBigramCatalog.from_records(
            entry_records=entry_records,
            occurrence_records=occurrence_records,
            expected_catalog_id=catalog_id,
        )
        for key, expected in catalog._verification_summary(metadata).items():
            if metadata.get(key) != expected:
                raise ValueError(
                    f"manifest Retro-BLEU bigram metadata disagrees for {key!r}"
                )
        return catalog

    @classmethod
    def _load_jsonl(
        cls,
        root: Path,
        manifest: ReferenceLibraryManifest,
        retro_bleu_bigram_catalog: Any | None = None,
    ) -> "ReferenceTacticLibrary":
        """Reload the complete portable representation into memory."""

        entries: list[TacticLibraryEntry] = []
        for artifact_name, expected_prefix in (
            ("rrseq_entries", "rrseq_"),
            ("rrsubtree_entries", "rrsubtree_"),
        ):
            path = root / str(manifest.artifacts[artifact_name]["path"])
            artifact_entries: list[TacticLibraryEntry] = []
            for raw_entry in _read_canonical_jsonl(path, label=artifact_name):
                entry = TacticLibraryEntry.from_dict(raw_entry)
                if canonical_json(raw_entry) != canonical_json(entry.to_dict()):
                    raise ValueError(
                        f"{artifact_name} contains a non-complete entry payload: "
                        f"{entry.entry_id}"
                    )
                if not entry.kind.startswith(expected_prefix):
                    raise ValueError(
                        f"{artifact_name} contains the wrong tactic kind: {entry.kind}"
                    )
                artifact_entries.append(entry)
            if [entry.entry_id for entry in artifact_entries] != sorted(
                entry.entry_id for entry in artifact_entries
            ):
                raise ValueError(f"{artifact_name} entries are not canonically ordered")
            entries.extend(artifact_entries)

        entries.sort(key=lambda entry: entry.entry_id)
        if len({entry.entry_id for entry in entries}) != len(entries):
            raise ValueError("entry JSONL sidecars contain duplicate entry IDs")

        occurrence_path = root / str(manifest.artifacts["occurrences"]["path"])
        occurrences: list[TacticOccurrence] = []
        entry_by_occurrence: dict[str, str] = {}
        occurrence_ids: list[str] = []
        for raw_record in _read_canonical_jsonl(
            occurrence_path,
            label="occurrences",
        ):
            raw_occurrence = raw_record.get("occurrence")
            if not isinstance(raw_occurrence, Mapping):
                raise ValueError("occurrences records require an occurrence object")
            occurrence = TacticOccurrence.from_dict(raw_occurrence)
            reference_id = occurrence.reference_occurrence_id
            entry_id = str(raw_record.get("entry_id") or "")
            expected_record = {
                "entry_id": entry_id,
                "occurrence": occurrence.to_dict(),
            }
            if canonical_json(raw_record) != canonical_json(expected_record):
                raise ValueError(
                    "occurrences contains a non-complete provenance record: "
                    f"{reference_id}"
                )
            if not entry_id:
                raise ValueError("occurrences records require a non-empty entry_id")
            if reference_id in entry_by_occurrence:
                raise ValueError(
                    "occurrences contains a duplicate reference occurrence ID: "
                    f"{reference_id}"
                )
            occurrences.append(occurrence)
            entry_by_occurrence[reference_id] = entry_id
            occurrence_ids.append(reference_id)
        if occurrence_ids != sorted(occurrence_ids):
            raise ValueError("occurrences records are not canonically ordered")

        rebuilt = cls.from_occurrences(
            occurrences,
            processing_profile=manifest.processing_profile,
            reference_corpora=manifest.reference_corpora,
            route_inspector_commit=manifest.route_inspector_commit,
        )
        persisted_entries = tuple(entries)
        if persisted_entries != rebuilt.entries():
            raise ValueError("entry JSONL sidecars disagree with occurrence provenance")
        if entry_by_occurrence != rebuilt._entry_by_occurrence:
            raise ValueError(
                "occurrence JSONL entry ownership disagrees with exact identities"
            )
        if rebuilt.library_id != manifest.library_id:
            raise ValueError(
                "manifest library_id does not bind the portable JSONL contents"
            )

        core_statistics = _library_statistics(persisted_entries, occurrences)
        for name, expected_value in core_statistics.items():
            if manifest.statistics.get(name) != expected_value:
                raise ValueError(
                    f"manifest statistic {name!r} disagrees with JSONL contents"
                )
        corpus_route_count = sum(
            int(corpus["route_count"]) for corpus in manifest.reference_corpora
        )
        corpus_without_tactics = sum(
            int(corpus["route_count_without_extracted_tactics"])
            for corpus in manifest.reference_corpora
        )
        for name, expected_value in (
            ("reference_route_count_processed", corpus_route_count),
            (
                "reference_route_count_without_extracted_tactics",
                corpus_without_tactics,
            ),
        ):
            if name in manifest.statistics and (
                manifest.statistics[name] != expected_value
            ):
                raise ValueError(
                    f"manifest statistic {name!r} disagrees with Reference corpora"
                )

        cls._validate_legacy_summary(root, manifest)
        return cls(
            manifest=manifest,
            entries=persisted_entries,
            occurrences=occurrences,
            entry_by_occurrence=entry_by_occurrence,
            directory=root,
            connection=None,
            retro_bleu_bigram_catalog=retro_bleu_bigram_catalog,
        )

    @staticmethod
    def _open_read_only_connection(catalog_path: Path) -> sqlite3.Connection:
        from .normalized import CatalogConnection, attach_dictionary

        connection = sqlite3.connect(
            f"{catalog_path.resolve().as_uri()}?mode=ro",
            uri=True,
            factory=CatalogConnection,
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA query_only = ON")
        if connection.execute(
            "SELECT 1 FROM sqlite_master WHERE name='packed_entries' AND type='table'"
        ).fetchone():
            try:
                attach_dictionary(connection, catalog_path.parent)
            except Exception:
                connection.close()
                raise
        return connection

    @classmethod
    def _open_fast_sqlite(
        cls,
        root: Path,
        manifest: ReferenceLibraryManifest,
    ) -> "ReferenceTacticLibrary":
        """Open a caller-trusted, previously verified and unchanged runtime index."""

        catalog_path = root / str(manifest.artifacts["catalog"]["path"])
        connection = cls._open_read_only_connection(catalog_path)
        try:
            _LOG.info("Verifying Reference objects and catalog: %s", root)
            version = int(connection.execute("PRAGMA user_version").fetchone()[0])
            if version != TACTIC_CATALOG_SCHEMA_VERSION:
                raise ValueError(
                    f"unsupported SQLite tactic catalog schema version: {version}"
                )
            required_tables = {
                "metadata",
                "entries",
                "entry_routes",
                "occurrences",
            }
            observed_tables = {
                str(row["name"])
                for row in connection.execute(
                    "SELECT name FROM sqlite_master WHERE type IN ('table','view')"
                )
            }
            if not required_tables.issubset(observed_tables):
                raise ValueError("SQLite tactic catalog is missing required tables")
            if manifest.library_format_version >= 7 and not {
                "packed_entries",
                "packed_occurrences",
                "occurrence_summaries",
            }.issubset(observed_tables):
                raise ValueError("SQLite tactic catalog is missing normalized storage")
            required_indexes = {
                "idx_entries_lookup",
                "idx_occurrences_entry",
                "idx_occurrences_route",
            }
            observed_indexes = {
                str(row["name"])
                for row in connection.execute(
                    "SELECT name FROM sqlite_master WHERE type = ?", ("index",)
                )
            }
            if not required_indexes.issubset(observed_indexes):
                raise ValueError("SQLite tactic catalog is missing required indexes")
            metadata = {
                str(row["key"]): json.loads(row["value_json"])
                for row in connection.execute(
                    "SELECT key, value_json FROM metadata ORDER BY key"
                )
            }
            expected_metadata_keys = {
                "library_id",
                "configuration_fingerprint",
                "processing_profile",
                "entry_count",
                "occurrence_count",
            }
            if set(metadata) != expected_metadata_keys:
                raise ValueError("catalog metadata set is incomplete or unknown")
            if metadata["library_id"] != manifest.library_id:
                raise ValueError("catalog library_id does not match manifest")
            if metadata["configuration_fingerprint"] != (
                manifest.configuration_fingerprint
            ):
                raise ValueError(
                    "catalog configuration fingerprint does not match manifest"
                )
            if metadata["processing_profile"] != (
                manifest.processing_profile.to_dict()
            ):
                raise ValueError("catalog processing profile does not match manifest")
            for metadata_name in ("entry_count", "occurrence_count"):
                expected = manifest.statistics.get(metadata_name)
                if expected is not None and metadata[metadata_name] != expected:
                    raise ValueError(
                        f"catalog {metadata_name} does not match manifest statistics"
                    )

            bigram_catalog = None
            if set(manifest.artifacts) & _BIGRAM_ARTIFACTS:
                from route_inspector.reference_library.bigram_catalog import (
                    _LazyRetroBleuBigramCatalog,
                )

                bigram_metadata = manifest.supplementary_evidence.get(
                    "retro_bleu_bigrams"
                )
                if not isinstance(bigram_metadata, Mapping):
                    raise ValueError(
                        "Retro-BLEU bigram artifacts require supplementary metadata"
                    )
                bigram_catalog = _LazyRetroBleuBigramCatalog(
                    entries_path=(
                        root
                        / str(manifest.artifacts["retro_bleu_bigram_entries"]["path"])
                    ),
                    occurrences_path=(
                        root
                        / str(
                            manifest.artifacts["retro_bleu_bigram_occurrences"]["path"]
                        )
                    ),
                    report_path=(
                        root
                        / str(manifest.artifacts["report_retro_bleu_bigrams"]["path"])
                    ),
                    metadata=bigram_metadata,
                )
            return cls(
                manifest=manifest,
                entries=None,
                occurrences=None,
                entry_by_occurrence=None,
                directory=root,
                connection=connection,
                retro_bleu_bigram_catalog=bigram_catalog,
            )
        except Exception:
            connection.close()
            raise

    @classmethod
    def _attach_pg_strategy_component(
        cls,
        library: "ReferenceTacticLibrary",
        root: Path,
        manifest: ReferenceLibraryManifest,
        *,
        backend: Literal["auto", "sqlite", "jsonl"],
        verification: Literal["fast", "full"],
    ) -> "ReferenceTacticLibrary":
        component = manifest.components.get("pg_strategy")
        if component is None:
            return library
        from route_inspector.protection.strategies.catalog import (
            ReferencePGStrategyLibrary,
        )

        try:
            pg_library = ReferencePGStrategyLibrary.load(
                root,
                backend=backend,
                verification=verification,
            )
            if pg_library.library_id != component["library_id"]:
                raise ValueError(
                    "PG strategy component ID disagrees with root manifest"
                )
            if (
                pg_library.manifest.library_format_version
                != component["library_format_version"]
            ):
                raise ValueError(
                    "PG strategy format version disagrees with root manifest"
                )
            if (
                pg_library.manifest.catalog_schema_version
                != component["catalog_schema_version"]
            ):
                raise ValueError(
                    "PG strategy schema version disagrees with root manifest"
                )
            if tuple(pg_library.manifest.reference_corpora) != tuple(
                manifest.reference_corpora
            ):
                raise ValueError(
                    "PG strategy Reference corpora disagree with tactic library"
                )
            expected_fingerprint = pg_library.manifest.processing_profile.get(
                "reference_processing_profile_fingerprint"
            )
            if expected_fingerprint != manifest.configuration_fingerprint:
                raise ValueError(
                    "PG strategy processing profile disagrees with tactic library"
                )
        except Exception:
            library.close()
            raise
        library.pg_strategy_library = pg_library
        return library

    @classmethod
    def _verify_full_sqlite_streaming(
        cls,
        root: Path,
        manifest: ReferenceLibraryManifest,
    ) -> None:
        """Verify SQLite and portable sidecars with bounded payload memory."""

        catalog_path = root / str(manifest.artifacts["catalog"]["path"])
        connection = cls._open_read_only_connection(catalog_path)
        try:
            if manifest.library_format_version >= 7:
                from .normalized import verify_objects

                verify_objects(root, connection)
            cls._validate_connection(connection)
            version = int(connection.execute("PRAGMA user_version").fetchone()[0])
            if version != TACTIC_CATALOG_SCHEMA_VERSION:
                raise ValueError(
                    f"unsupported SQLite tactic catalog schema version: {version}"
                )
            metadata = {
                str(row["key"]): json.loads(row["value_json"])
                for row in connection.execute(
                    "SELECT key, value_json FROM metadata ORDER BY key"
                )
            }
            expected_metadata_keys = {
                "library_id",
                "configuration_fingerprint",
                "processing_profile",
                "entry_count",
                "occurrence_count",
            }
            if set(metadata) != expected_metadata_keys:
                raise ValueError("catalog metadata set is incomplete or unknown")
            if metadata["library_id"] != manifest.library_id:
                raise ValueError("catalog library_id does not match manifest")
            if metadata["configuration_fingerprint"] != (
                manifest.configuration_fingerprint
            ):
                raise ValueError(
                    "catalog configuration fingerprint does not match manifest"
                )
            if metadata["processing_profile"] != (
                manifest.processing_profile.to_dict()
            ):
                raise ValueError("catalog processing profile does not match manifest")
            for name in ("entry_count", "occurrence_count"):
                expected = manifest.statistics.get(name)
                if expected is not None and metadata[name] != expected:
                    raise ValueError(
                        f"catalog {name} does not match manifest statistics"
                    )

            identity_version = int(
                manifest.identity_configuration["tactic_identity_version"]
            )
            entry_counts_by_kind: Counter[str] = Counter()
            entry_count = 0
            occurrence_support_total = 0
            _LOG.info("Verifying Reference entry sidecars")
            audit_progress(
                "Checking tactic entries", 0, metadata["entry_count"], force=True
            )

            for artifact_name, prefix in (
                ("rrseq_entries", "rrseq_"),
                ("rrsubtree_entries", "rrsubtree_"),
            ):
                path = root / str(manifest.artifacts[artifact_name]["path"])
                if manifest.library_format_version >= 7:
                    from .normalized import verified_sidecar_rows

                    paired_rows = verified_sidecar_rows(
                        connection,
                        root,
                        path,
                        "SELECT * FROM packed_entries WHERE tactic_kind LIKE ? ORDER BY entry_id",
                        (f"{prefix}%",),
                        label=artifact_name,
                    )
                else:
                    paired_rows = zip_longest(
                        connection.execute(
                            "SELECT * FROM entries WHERE tactic_kind LIKE ? ORDER BY entry_id",
                            (f"{prefix}%",),
                        ),
                        _iter_canonical_jsonl(path, label=artifact_name),
                    )
                for sql_row, raw_entry in paired_rows:
                    if sql_row is None or raw_entry is None:
                        raise ValueError(
                            f"{artifact_name} and SQLite entry counts differ"
                        )
                    entry = TacticLibraryEntry.from_dict(raw_entry)
                    if canonical_json(raw_entry) != canonical_json(entry.to_dict()):
                        raise ValueError(
                            f"{artifact_name} contains a non-complete entry"
                        )
                    if manifest.library_format_version < 7:
                        sql_payload = json.loads(sql_row["entry_json"])
                        if canonical_json(sql_payload) != canonical_json(raw_entry):
                            raise ValueError(
                                f"{artifact_name} differs from SQLite for {entry.entry_id}"
                            )
                    expected_columns = (
                        entry.entry_id,
                        entry.kind,
                        entry.identity.identity_version,
                        entry.lookup_key,
                        _collision_ordinal(entry.entry_id),
                        entry.occurrence_count,
                        entry.route_count,
                        entry.representative_occurrence_id,
                    )
                    actual_columns = tuple(
                        sql_row[name]
                        for name in (
                            "entry_id",
                            "tactic_kind",
                            "identity_version",
                            "lookup_key",
                            "collision_ordinal",
                            "occurrence_count",
                            "route_count",
                            "representative_occurrence_id",
                        )
                    )
                    if expected_columns != actual_columns:
                        raise ValueError(
                            "catalog entry columns disagree with payload: "
                            f"{entry.entry_id}"
                        )
                    if entry.identity.identity_version != identity_version:
                        raise ValueError(
                            "catalog entry identity version differs from manifest"
                        )
                    persisted_routes = tuple(
                        ReferenceRouteKey(
                            dataset_id=str(row["dataset_id"]),
                            source_identity=str(row["source_identity"]),
                            route_id=str(row["route_id"]),
                        )
                        for row in connection.execute(
                            """SELECT dataset_id, source_identity, route_id
                               FROM entry_routes WHERE entry_id = ?
                               ORDER BY dataset_id, source_identity, route_id""",
                            (entry.entry_id,),
                        )
                    )
                    if persisted_routes != entry.reference_routes:
                        raise ValueError(
                            f"catalog route support differs for {entry.entry_id}"
                        )
                    entry_counts_by_kind[entry.kind] += 1
                    entry_count += 1
                    if entry_count % 250 == 0:
                        audit_progress(
                            "Checking tactic entries",
                            entry_count,
                            metadata["entry_count"],
                        )
                    occurrence_support_total += entry.occurrence_count
                    if entry_count % 10000 == 0:
                        _LOG.info("Verified %s Reference entries", entry_count)

            if entry_count != int(metadata["entry_count"]):
                raise ValueError("catalog entry count does not match metadata")

            if manifest.library_format_version >= 7 and connection.execute(
                "SELECT COUNT(*) FROM occurrence_summaries"
            ).fetchone()[0] != int(metadata["occurrence_count"]):
                raise ValueError(
                    "normalized occurrence summary count disagrees with metadata"
                )

            current_bucket: tuple[str, int, str] | None = None
            bucket_ordinal = 0
            bucket_entry_ids: list[str] = []

            def finish_bucket() -> None:
                if len(bucket_entry_ids) > 1:
                    bucket_identities = [
                        TacticLibraryEntry.from_dict(
                            json.loads(
                                connection.execute(
                                    "SELECT entry_json FROM entries WHERE entry_id=?",
                                    (entry_id,),
                                ).fetchone()[0]
                            )
                        ).identity
                        for entry_id in bucket_entry_ids
                    ]
                    # Exact canonical ordering is only needed for real lookup
                    # collisions. Singleton buckets are verified by ownership below.
                    bucket_certificates = [
                        _identity_exact_certificate(identity)
                        for identity in bucket_identities
                    ]
                    if bucket_certificates != sorted(bucket_certificates):
                        raise ValueError(
                            "catalog collision ordinals disagree with exact identity order"
                        )
                    if len(bucket_certificates) != len(set(bucket_certificates)):
                        raise ValueError(
                            "catalog contains duplicate exact certificates in one bucket"
                        )
                    for left_index, left in enumerate(bucket_identities):
                        for right in bucket_identities[left_index + 1 :]:
                            if left.equivalent_to(right):
                                raise ValueError(
                                    "catalog contains duplicate exact identities in one "
                                    "lookup bucket"
                                )

            collision_rows = connection.execute(
                """SELECT tactic_kind, identity_version, lookup_key,
                          collision_ordinal, entry_id
                   FROM entries
                   ORDER BY tactic_kind, identity_version, lookup_key,
                            collision_ordinal"""
            )
            for row in collision_rows:
                bucket = (
                    str(row["tactic_kind"]),
                    int(row["identity_version"]),
                    str(row["lookup_key"]),
                )
                if bucket != current_bucket:
                    finish_bucket()
                    current_bucket = bucket
                    bucket_ordinal = 0
                    bucket_entry_ids = []
                if int(row["collision_ordinal"]) != bucket_ordinal:
                    raise ValueError(
                        "catalog collision ordinals are not canonical and consecutive"
                    )
                expected_entry_id = (
                    f"{bucket[2]}~{bucket_ordinal:0{_COLLISION_ORDINAL_WIDTH}d}"
                )
                if str(row["entry_id"]) != expected_entry_id:
                    raise ValueError("catalog collision entry ID is not canonical")
                bucket_entry_ids.append(str(row["entry_id"]))
                bucket_ordinal += 1
            finish_bucket()

            occurrence_count = 0
            _LOG.info("Verifying Reference occurrence sidecars")
            audit_progress(
                "Checking tactic occurrences",
                0,
                metadata["occurrence_count"],
                force=True,
            )
            occurrence_counts_by_kind: Counter[str] = Counter()
            observed_routes: dict[tuple[str, str], set[str]] = defaultdict(set)
            occurrence_path = root / str(manifest.artifacts["occurrences"]["path"])
            if manifest.library_format_version >= 7:
                from .normalized import verified_sidecar_rows

                paired_occurrences = verified_sidecar_rows(
                    connection,
                    root,
                    occurrence_path,
                    "SELECT * FROM packed_occurrences ORDER BY reference_occurrence_id",
                    label="occurrences",
                    occurrence=True,
                )
            else:
                paired_occurrences = zip_longest(
                    connection.execute(
                        "SELECT * FROM occurrences ORDER BY reference_occurrence_id"
                    ),
                    _iter_canonical_jsonl(occurrence_path, label="occurrences"),
                )
            for sql_row, raw_record in paired_occurrences:
                if sql_row is None or raw_record is None:
                    raise ValueError("occurrence JSONL and SQLite counts differ")
                raw_occurrence = raw_record.get("occurrence")
                if not isinstance(raw_occurrence, Mapping):
                    raise ValueError("occurrence sidecar requires an occurrence object")
                occurrence = TacticOccurrence.from_dict(raw_occurrence)
                if manifest.library_format_version >= 7:
                    summary = connection.execute(
                        "SELECT rule_count FROM occurrence_summaries WHERE reference_occurrence_id=?",
                        (occurrence.reference_occurrence_id,),
                    ).fetchone()
                    if summary is None or summary[0] != len(
                        occurrence.selected_reaction_node_paths
                    ):
                        raise ValueError(
                            "normalized occurrence summary disagrees with provenance"
                        )
                expected_record = {
                    "entry_id": str(sql_row["entry_id"]),
                    "occurrence": occurrence.to_dict(),
                }
                if canonical_json(raw_record) != canonical_json(expected_record):
                    raise ValueError("occurrence sidecar is not canonical and complete")
                if manifest.library_format_version < 7:
                    sql_payload = json.loads(sql_row["occurrence_json"])
                    if canonical_json(sql_payload) != canonical_json(raw_occurrence):
                        raise ValueError(
                            "occurrence sidecar differs from SQLite for "
                            f"{occurrence.reference_occurrence_id}"
                        )
                content_sha256 = _json_digest(occurrence.to_dict())
                expected_columns = (
                    occurrence.reference_occurrence_id,
                    occurrence.occurrence_id,
                    str(sql_row["entry_id"]),
                    occurrence.identity.kind,
                    occurrence.route.dataset_id,
                    occurrence.route.source_identity,
                    occurrence.route.route_id,
                    occurrence.native_schema_version,
                    content_sha256,
                )
                actual_columns = tuple(
                    sql_row[name]
                    for name in (
                        "reference_occurrence_id",
                        "native_occurrence_id",
                        "entry_id",
                        "tactic_kind",
                        "dataset_id",
                        "source_identity",
                        "route_id",
                        "native_schema_version",
                        "content_sha256",
                    )
                )
                if expected_columns != actual_columns:
                    raise ValueError(
                        "catalog occurrence columns disagree with payload: "
                        f"{occurrence.reference_occurrence_id}"
                    )
                if occurrence.identity.identity_version != identity_version:
                    raise ValueError(
                        "catalog occurrence identity version differs from manifest"
                    )
                occurrence_counts_by_kind[occurrence.identity.kind] += 1
                observed_routes[
                    (occurrence.route.dataset_id, occurrence.route.source_identity)
                ].add(occurrence.route.route_id)
                occurrence_count += 1
                if occurrence_count % 250 == 0:
                    audit_progress(
                        "Checking tactic occurrences",
                        occurrence_count,
                        metadata["occurrence_count"],
                    )
                if occurrence_count % 10000 == 0:
                    _LOG.info("Verified %s Reference occurrences", occurrence_count)

            if occurrence_count != int(metadata["occurrence_count"]):
                raise ValueError("catalog occurrence count does not match metadata")
            if occurrence_count != occurrence_support_total:
                raise ValueError("catalog occurrence support accounting failed")

            # Ownership already visits entries in canonical ID order. Bind
            # those same validated identities without a second decoding pass.
            digest = hashlib.sha256()
            digest.update(b'{"entries":[')
            _LOG.info("Verifying Reference ownership and aggregate support")
            for entry_index, entry_row in enumerate(
                connection.execute(
                    "SELECT entry_id, entry_json FROM entries ORDER BY entry_id"
                )
            ):
                if entry_index % 250 == 0:
                    audit_progress(
                        "Checking ownership and support",
                        entry_index,
                        metadata["entry_count"],
                    )
                entry = TacticLibraryEntry.from_dict(
                    json.loads(entry_row["entry_json"])
                )
                if entry_index:
                    digest.update(b",")
                digest.update(
                    canonical_json(
                        {
                            "entry_id": entry.entry_id,
                            "identity": entry.identity.to_dict(),
                        }
                    ).encode("utf-8")
                )
                count = 0
                routes: set[tuple[str, str, str]] = set()
                route_targets: set[str] = set()
                motif_targets: set[str] = set()
                representative: str | None = None
                annotation_state: dict[str, dict[str, Any]] = {}
                equivalence_cache = ByteMemo(
                    lambda encoded: TacticIdentity.from_dict(
                        json.loads(encoded)
                    ).equivalent_to(entry.identity)
                )
                if manifest.library_format_version >= 7:
                    # Complete records, models and hashes were already checked
                    # above. Ownership needs identity and support, not a second
                    # expansion of the large native chemistry payload.
                    fields = canonical_json(
                        [
                            "identity",
                            "route",
                            "route_target_smiles",
                            "motif_target_smiles",
                            "reference_occurrence_id",
                            "annotations",
                        ]
                    )
                    ownership_rows = connection.execute(
                        "SELECT ri_project_json(occurrence_json,?) AS occurrence_json "
                        "FROM packed_occurrences WHERE entry_id=? ORDER BY reference_occurrence_id",
                        (fields, entry.entry_id),
                    )
                else:
                    ownership_rows = connection.execute(
                        "SELECT occurrence_json FROM occurrences WHERE entry_id=? ORDER BY reference_occurrence_id",
                        (entry.entry_id,),
                    )
                for occurrence_row in ownership_rows:
                    raw = json.loads(occurrence_row["occurrence_json"])
                    if manifest.library_format_version >= 7:
                        raw["identity"] = TacticIdentity.from_dict(raw["identity"])
                        raw["route"] = ReferenceRouteKey.from_dict(raw["route"])
                        occurrence = SimpleNamespace(**raw)
                    else:
                        occurrence = TacticOccurrence.from_dict(raw)
                    identity_signature = _identity_sort_key(occurrence.identity)
                    owned = equivalence_cache(identity_signature)
                    if not owned:
                        raise ValueError(
                            "catalog occurrence is not exactly owned by its entry: "
                            f"{occurrence.reference_occurrence_id}"
                        )
                    count += 1
                    routes.add(_route_sort_key(occurrence.route))
                    if occurrence.route_target_smiles:
                        route_targets.add(occurrence.route_target_smiles)
                    if occurrence.motif_target_smiles:
                        motif_targets.add(occurrence.motif_target_smiles)
                    representative = min(
                        occurrence.reference_occurrence_id,
                        representative or occurrence.reference_occurrence_id,
                    )
                    _accumulate_annotation_summary(annotation_state, occurrence)
                if count != entry.occurrence_count:
                    raise ValueError(
                        f"catalog occurrence support differs for {entry.entry_id}"
                    )
                if routes != {
                    _route_sort_key(route) for route in entry.reference_routes
                }:
                    raise ValueError(
                        f"catalog occurrence routes differ for {entry.entry_id}"
                    )
                if representative != entry.representative_occurrence_id:
                    raise ValueError(
                        "catalog representative occurrence is not canonical for "
                        f"{entry.entry_id}"
                    )
                if tuple(sorted(route_targets)) != entry.route_target_smiles:
                    raise ValueError(
                        f"catalog route targets differ for {entry.entry_id}"
                    )
                if tuple(sorted(motif_targets)) != entry.motif_target_smiles:
                    raise ValueError(
                        f"catalog motif targets differ for {entry.entry_id}"
                    )
                expected_annotations = _finalize_annotation_summary(
                    annotation_state,
                    occurrence_count=count,
                )
                if expected_annotations != entry.annotation_summary:
                    raise ValueError(
                        f"catalog annotation summary differs for {entry.entry_id}"
                    )
                if (entry_index + 1) % 10000 == 0:
                    _LOG.info(
                        "Verified ownership of %s Reference entries", entry_index + 1
                    )

            _validate_observed_route_corpora(
                observed_routes,
                manifest.reference_corpora,
            )
            core_statistics = {
                "entry_count": entry_count,
                "occurrence_count": occurrence_count,
                "reference_route_count_with_tactics": sum(
                    len(route_ids) for route_ids in observed_routes.values()
                ),
                "entries_by_kind": {
                    kind: entry_counts_by_kind.get(kind, 0) for kind in TACTIC_KINDS
                },
                "occurrences_by_kind": {
                    kind: occurrence_counts_by_kind.get(kind, 0)
                    for kind in TACTIC_KINDS
                },
            }
            for name, expected in core_statistics.items():
                if manifest.statistics.get(name) != expected:
                    raise ValueError(
                        f"manifest statistic {name!r} disagrees with catalog contents"
                    )
            corpus_route_count = sum(
                int(corpus["route_count"]) for corpus in manifest.reference_corpora
            )
            corpus_without_tactics = sum(
                int(corpus["route_count_without_extracted_tactics"])
                for corpus in manifest.reference_corpora
            )
            for name, expected in (
                ("reference_route_count_processed", corpus_route_count),
                (
                    "reference_route_count_without_extracted_tactics",
                    corpus_without_tactics,
                ),
            ):
                if (
                    name in manifest.statistics
                    and manifest.statistics[name] != expected
                ):
                    raise ValueError(
                        f"manifest statistic {name!r} disagrees with Reference corpora"
                    )

            digest.update(b'],"library_format_version":')
            digest.update(str(TACTIC_LIBRARY_ID_FORMAT_VERSION).encode("ascii"))
            digest.update(b',"occurrences":[')
            for index, row in enumerate(
                connection.execute(
                    """SELECT reference_occurrence_id, content_sha256
                       FROM occurrences ORDER BY reference_occurrence_id"""
                )
            ):
                if index:
                    digest.update(b",")
                digest.update(
                    canonical_json(
                        {
                            "reference_occurrence_id": str(
                                row["reference_occurrence_id"]
                            ),
                            "content_sha256": str(row["content_sha256"]),
                        }
                    ).encode("utf-8")
                )
            digest.update(b'],"profile_fingerprint":')
            digest.update(
                canonical_json(manifest.processing_profile.fingerprint).encode("utf-8")
            )
            digest.update(b',"reference_corpora":')
            digest.update(
                canonical_json(
                    [dict(corpus) for corpus in manifest.reference_corpora]
                ).encode("utf-8")
            )
            digest.update(b"}")
            if f"reference_library_{digest.hexdigest()}" != manifest.library_id:
                raise ValueError(
                    "manifest library_id does not bind the persisted catalog contents"
                )

            cls._validate_legacy_summary(root, manifest)

            if set(manifest.artifacts) & _BIGRAM_ARTIFACTS:
                from route_inspector.reference_library.bigram_catalog import (
                    verify_bigram_catalog_streaming,
                )

                verify_bigram_catalog_streaming(
                    entries_path=(
                        root
                        / str(manifest.artifacts["retro_bleu_bigram_entries"]["path"])
                    ),
                    occurrences_path=(
                        root
                        / str(
                            manifest.artifacts["retro_bleu_bigram_occurrences"]["path"]
                        )
                    ),
                    report_path=(
                        root
                        / str(manifest.artifacts["report_retro_bleu_bigrams"]["path"])
                    ),
                    metadata=manifest.supplementary_evidence["retro_bleu_bigrams"],
                )
        finally:
            connection.close()

    @classmethod
    @audit_scope
    def load(
        cls,
        directory: str | Path,
        *,
        expected_profile: ReferenceProcessingProfile | None = None,
        backend: Literal["auto", "sqlite", "jsonl"] = "auto",
        verification: Literal["fast", "full"] = "fast",
    ) -> "ReferenceTacticLibrary":
        """Load a library under an explicit caller-selected trust policy.

        ``fast`` (the default SQLite path) assumes that the caller has already
        verified the library and kept it unchanged. It checks layout, sizes,
        schema and metadata, but does not hash artifacts or prove they still
        match the verified snapshot. No persisted trust marker is required or
        treated as proof of prior verification. Lookups remain lazy and retain
        exact candidate identity checks; ``fast`` never means key-only matching.

        Use ``full`` after building, importing, copying or modifying a library,
        or when corruption is suspected. It audits hashes, SQLite integrity and
        scientific/portable-data agreement before returning. JSONL loading
        performs full validation even when ``fast`` is requested.

        Keep the library immutable for the entire lifetime of a loaded handle.
        Neither mode authenticates the publisher or protects against concurrent
        writers; successful verification describes the snapshot checked then.
        """

        if backend not in {"auto", "sqlite", "jsonl"}:
            raise ValueError("backend must be 'auto', 'sqlite', or 'jsonl'")
        if verification not in {"fast", "full"}:
            raise ValueError("verification must be 'fast' or 'full'")
        root = Path(directory).expanduser()
        manifest_path = root / "manifest.json"
        if not manifest_path.is_file():
            raise FileNotFoundError(manifest_path)
        raw_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not isinstance(raw_manifest, Mapping):
            raise ValueError("manifest.json must contain an object")
        manifest = ReferenceLibraryManifest.from_dict(raw_manifest)
        if manifest.catalog_schema_version != TACTIC_CATALOG_SCHEMA_VERSION:
            raise ValueError(
                "unsupported tactic catalog schema version: "
                f"{manifest.catalog_schema_version}"
            )
        artifact_names = set(manifest.artifacts)
        required = _REQUIRED_ARTIFACTS
        allowed = _ALLOWED_ARTIFACTS
        if manifest.library_format_version >= 6:
            required = required - {"summary"}
            allowed = allowed - {"summary"}
        if manifest.library_format_version >= 7:
            required = required | {"payload_objects"}
        else:
            allowed = allowed - {"payload_objects"}
        if not required.issubset(artifact_names) or not artifact_names.issubset(
            allowed
        ):
            raise ValueError(
                "manifest artifact set is incomplete or unknown: "
                f"{sorted(manifest.artifacts)}"
            )
        declared_bigrams = artifact_names & _BIGRAM_ARTIFACTS
        if declared_bigrams and declared_bigrams != _BIGRAM_ARTIFACTS:
            raise ValueError("manifest Retro-BLEU bigram artifact group is incomplete")
        if set(manifest.components) - {"pg_strategy"}:
            raise ValueError(
                f"unsupported Reference-library components: {sorted(manifest.components)}"
            )
        has_pg_component = "pg_strategy" in manifest.components
        if has_pg_component != ("pg_strategy_manifest" in artifact_names):
            raise ValueError(
                "PG strategy component declaration and manifest artifact disagree"
            )
        has_sqlite = "catalog" in manifest.artifacts
        # Fast trusts an unchanged library; candidate matching remains exact.
        full_validation = verification == "full" or backend == "jsonl" or not has_sqlite
        for name, descriptor in manifest.artifacts.items():
            if descriptor["path"] != _ARTIFACT_PATHS[name]:
                raise ValueError(
                    f"manifest artifact {name!r} must use canonical path "
                    f"{_ARTIFACT_PATHS[name]!r}"
                )
            path = root / str(descriptor["path"])
            if not path.is_file():
                raise FileNotFoundError(path)
            if path.stat().st_size != int(descriptor["size_bytes"]):
                raise ValueError(f"artifact size mismatch for {name}")
            if full_validation and (_sha256_file(path) != str(descriptor["sha256"])):
                raise ValueError(f"artifact SHA-256 mismatch for {name}")
        if expected_profile is not None:
            manifest.processing_profile.assert_compatible(expected_profile)

        if backend == "sqlite" and not has_sqlite:
            raise FileNotFoundError(
                "manifest does not declare the optional SQLite catalog artifact"
            )
        if not full_validation:
            return cls._attach_pg_strategy_component(
                cls._open_fast_sqlite(root, manifest),
                root,
                manifest,
                backend=backend,
                verification=verification,
            )

        if has_sqlite and backend in {"auto", "sqlite"}:
            cls._verify_full_sqlite_streaming(root, manifest)
            return cls._attach_pg_strategy_component(
                cls._open_fast_sqlite(root, manifest),
                root,
                manifest,
                backend=backend,
                verification=verification,
            )

        if manifest.library_format_version >= 7:
            from .normalized import verify_objects

            verify_objects(root)
        retro_bleu_bigram_catalog = cls._load_bigram_catalog(root, manifest)
        return cls._attach_pg_strategy_component(
            cls._load_jsonl(root, manifest, retro_bleu_bigram_catalog),
            root,
            manifest,
            backend=backend,
            verification=verification,
        )

    @classmethod
    def verify(
        cls,
        directory: str | Path,
        *,
        expected_profile: ReferenceProcessingProfile | None = None,
        backend: Literal["auto", "sqlite", "jsonl"] = "auto",
    ) -> ReferenceLibraryManifest:
        """Run the complete integrity/equivalence audit and return its manifest."""

        with cls.load(
            directory,
            expected_profile=expected_profile,
            backend=backend,
            verification="full",
        ) as library:
            return library.manifest

    @staticmethod
    def _validate_connection(connection: sqlite3.Connection) -> None:
        integrity = connection.execute("PRAGMA integrity_check").fetchone()
        if integrity is None or str(integrity[0]).lower() != "ok":
            raise ValueError("tactic catalog failed SQLite integrity_check")
        foreign_keys = tuple(connection.execute("PRAGMA foreign_key_check"))
        if foreign_keys:
            raise ValueError("tactic catalog contains foreign-key violations")
