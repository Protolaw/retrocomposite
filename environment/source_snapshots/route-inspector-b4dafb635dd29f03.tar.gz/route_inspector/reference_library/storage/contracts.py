"""Verified Reference-library implementation boundary."""

from __future__ import annotations

from route_inspector.reference_library.storage.manifest import (
    REFERENCE_TACTIC_CATALOG_SCHEMA_VERSION,
)

TACTIC_CATALOG_SCHEMA_VERSION = REFERENCE_TACTIC_CATALOG_SCHEMA_VERSION

_COLLISION_ORDINAL_WIDTH = 4

_LAZY_ENTRY_CACHE_SIZE = 32

_LAZY_OWNERSHIP_CACHE_SIZE = 64

TACTIC_LIBRARY_ID_FORMAT_VERSION = 1

TACTIC_KINDS = (
    "rrseq_cons",
    "rrseq_gap",
    "rrsubtree_cons",
    "rrsubtree_gap",
)

_REQUIRED_ARTIFACTS = frozenset(
    {
        "occurrences",
        "rrseq_entries",
        "rrsubtree_entries",
        "report_rrseq_cons",
        "report_rrseq_gap",
        "report_rrsubtree_cons",
        "report_rrsubtree_gap",
        "summary",
    }
)

_BIGRAM_ARTIFACTS = frozenset(
    {
        "retro_bleu_bigram_entries",
        "retro_bleu_bigram_occurrences",
        "report_retro_bleu_bigrams",
    }
)

_OPTIONAL_ARTIFACTS = (
    frozenset({"catalog", "pg_strategy_manifest", "payload_objects"})
    | _BIGRAM_ARTIFACTS
)

_ALLOWED_ARTIFACTS = _REQUIRED_ARTIFACTS | _OPTIONAL_ARTIFACTS

_ARTIFACT_PATHS = {
    "payload_objects": "objects/payloads.sqlite",
    "catalog": "catalog.sqlite",
    "occurrences": "provenance/occurrences.jsonl",
    "rrseq_entries": "rrseq/entries.jsonl",
    "rrsubtree_entries": "rrsubtree/entries.jsonl",
    "report_rrseq_cons": "reports/rrseq_cons.tsv",
    "report_rrseq_gap": "reports/rrseq_gap.tsv",
    "report_rrsubtree_cons": "reports/rrsubtree_cons.tsv",
    "report_rrsubtree_gap": "reports/rrsubtree_gap.tsv",
    "summary": "summary.json",
    "retro_bleu_bigram_entries": "retro_bleu_bigrams/entries.jsonl",
    "retro_bleu_bigram_occurrences": "retro_bleu_bigrams/occurrences.jsonl",
    "report_retro_bleu_bigrams": "reports/retro_bleu_bigrams.tsv",
    "pg_strategy_manifest": "pg_strategy/manifest.json",
}

_SCHEMA_SQL = """
CREATE TABLE metadata (
    key TEXT PRIMARY KEY,
    value_json TEXT NOT NULL
) WITHOUT ROWID;

CREATE TABLE entries (
    entry_id TEXT PRIMARY KEY,
    tactic_kind TEXT NOT NULL CHECK (
        tactic_kind IN (
            'rrseq_cons', 'rrseq_gap', 'rrsubtree_cons', 'rrsubtree_gap'
        )
    ),
    identity_version INTEGER NOT NULL CHECK (identity_version >= 1),
    lookup_key TEXT NOT NULL,
    collision_ordinal INTEGER NOT NULL CHECK (collision_ordinal >= 0),
    occurrence_count INTEGER NOT NULL CHECK (occurrence_count >= 1),
    route_count INTEGER NOT NULL CHECK (route_count >= 1),
    representative_occurrence_id TEXT NOT NULL,
    entry_json TEXT NOT NULL,
    UNIQUE(tactic_kind, identity_version, lookup_key, collision_ordinal)
) WITHOUT ROWID;

CREATE TABLE entry_routes (
    entry_id TEXT NOT NULL REFERENCES entries(entry_id) ON DELETE CASCADE,
    dataset_id TEXT NOT NULL,
    source_identity TEXT NOT NULL,
    route_id TEXT NOT NULL,
    PRIMARY KEY(entry_id, dataset_id, source_identity, route_id)
) WITHOUT ROWID;

CREATE TABLE occurrences (
    reference_occurrence_id TEXT PRIMARY KEY,
    native_occurrence_id TEXT NOT NULL,
    entry_id TEXT NOT NULL REFERENCES entries(entry_id) ON DELETE CASCADE,
    tactic_kind TEXT NOT NULL,
    dataset_id TEXT NOT NULL,
    source_identity TEXT NOT NULL,
    route_id TEXT NOT NULL,
    native_schema_version INTEGER NOT NULL CHECK (native_schema_version >= 1),
    content_sha256 TEXT NOT NULL,
    occurrence_json TEXT NOT NULL
) WITHOUT ROWID;

CREATE INDEX idx_entries_lookup
    ON entries(tactic_kind, identity_version, lookup_key, collision_ordinal);
CREATE INDEX idx_occurrences_entry
    ON occurrences(entry_id, reference_occurrence_id);
CREATE INDEX idx_occurrences_route
    ON occurrences(
        dataset_id, source_identity, route_id, reference_occurrence_id
    );
"""
