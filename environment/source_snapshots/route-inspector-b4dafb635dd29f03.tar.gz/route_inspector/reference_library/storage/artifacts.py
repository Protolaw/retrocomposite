"""Verified Reference-library implementation boundary."""

from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Iterable, Iterator, Mapping
from pathlib import Path
from typing import Any

from route_inspector.infrastructure.publication import publish_directory_no_replace
from route_inspector.reference_library.profile import (
    canonical_json,
)
from route_inspector.reference_library.storage.manifest import ReferenceLibraryManifest


def _json_digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _canonical_jsonl_properties(
    records: Iterable[Mapping[str, Any]],
) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    for record in records:
        encoded = (canonical_json(record) + "\n").encode("utf-8")
        digest.update(encoded)
        size += len(encoded)
    return digest.hexdigest(), size


def _validate_generated_artifact(
    manifest: ReferenceLibraryManifest,
    name: str,
    records: Iterable[Mapping[str, Any]],
) -> None:
    expected_digest, expected_size = _canonical_jsonl_properties(records)
    descriptor = manifest.artifacts[name]
    if (
        expected_digest != descriptor["sha256"]
        or expected_size != descriptor["size_bytes"]
    ):
        raise ValueError(f"artifact {name!r} disagrees with the SQLite catalog")


def _read_canonical_jsonl(
    path: Path,
    *,
    label: str,
) -> tuple[Mapping[str, Any], ...]:
    """Read complete canonical JSON objects from one portable sidecar."""

    return tuple(_iter_canonical_jsonl(path, label=label))


def _iter_canonical_jsonl(
    path: Path,
    *,
    label: str,
) -> Iterator[Mapping[str, Any]]:
    """Yield canonical JSONL objects without retaining the complete sidecar."""

    root = path.parent.parent
    manifest_path = root / "manifest.json"
    if (
        path.parent.name in {"rrseq", "rrsubtree", "provenance"}
        and manifest_path.is_file()
        and json.loads(manifest_path.read_text()).get("library_format_version", 0) >= 7
    ):
        from .normalized import sidecar_store

        with sidecar_store(root) as store:
            for packed in _iter_physical_jsonl(path, label=label):
                record = store.unpack(packed)
                if not isinstance(record, Mapping):
                    raise ValueError(f"{label} must decode to objects")
                yield record
    else:
        yield from _iter_physical_jsonl(path, label=label)


def _iter_physical_jsonl(path, *, label):
    with path.open("rb") as stream:
        for line_number, encoded in enumerate(stream, start=1):
            if not encoded.endswith(b"\n"):
                raise ValueError(f"{label} line {line_number} must end with a newline")
            try:
                raw_record = json.loads(encoded[:-1].decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise ValueError(
                    f"{label} line {line_number} is not valid UTF-8 JSON"
                ) from exc
            if not isinstance(raw_record, Mapping):
                raise ValueError(f"{label} line {line_number} must contain an object")
            if (canonical_json(raw_record) + "\n").encode("utf-8") != encoded:
                raise ValueError(f"{label} line {line_number} is not canonical JSON")
            yield raw_record


def _publish_directory_no_replace(source: Path, destination: Path) -> None:
    """Compatibility wrapper retaining the catalog's existing error contract."""
    try:
        publish_directory_no_replace(source, destination)
    except FileExistsError as exc:
        if os.name == "nt":
            raise
        raise FileExistsError(
            exc.errno,
            "reference tactic-library destination already exists",
            str(destination),
        ) from None
