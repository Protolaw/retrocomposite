"""Small domain records shared by Reference tactic libraries and assessments."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping, TypeAlias, cast

from route_inspector.rules.graph import canonical_json

TACTIC_IDENTITY_VERSION = 2
SUPPORTED_TACTIC_IDENTITY_VERSIONS = frozenset({1, 2, 3, 4})
REFERENCE_OCCURRENCE_ID_VERSION = 1

TacticKind: TypeAlias = Literal[
    "rrseq_cons",
    "rrseq_gap",
    "rrsubtree_cons",
    "rrsubtree_gap",
]
NodePath: TypeAlias = tuple[int, ...]

_TACTIC_KINDS = frozenset(
    {"rrseq_cons", "rrseq_gap", "rrsubtree_cons", "rrsubtree_gap"}
)


def _json_copy(value: Any, *, field_name: str) -> Any:
    try:
        return json.loads(canonical_json(value))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be finite JSON data") from exc


def _path(value: Any) -> NodePath:
    path = tuple(int(index) for index in value)
    if any(index < 0 for index in path):
        raise ValueError("node paths must contain non-negative child indices")
    return path


def _rrsubtree_identity_node_count(node: Mapping[str, Any]) -> int:
    return 1 + sum(
        _rrsubtree_identity_node_count(child["child"])
        for child in node.get("children", ())
    )


@dataclass(frozen=True, order=True)
class ReferenceRouteKey:
    """Collision-safe identity for one route in one Reference corpus."""

    dataset_id: str
    source_identity: str
    route_id: str

    def __post_init__(self) -> None:
        for field_name in ("dataset_id", "source_identity", "route_id"):
            value = str(getattr(self, field_name))
            if not value:
                raise ValueError(f"ReferenceRouteKey requires non-empty {field_name}")
            object.__setattr__(self, field_name, value)

    def to_dict(self) -> dict[str, str]:
        return {
            "dataset_id": self.dataset_id,
            "source_identity": self.source_identity,
            "route_id": self.route_id,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ReferenceRouteKey":
        return cls(
            dataset_id=str(value["dataset_id"]),
            source_identity=str(value["source_identity"]),
            route_id=str(value["route_id"]),
        )


def stable_reference_occurrence_id(
    *,
    kind: TacticKind,
    route: ReferenceRouteKey,
    native_occurrence_id: str,
) -> str:
    """Qualify a native occurrence ID by its complete Reference route key."""

    normalized_kind = str(kind)
    if normalized_kind not in _TACTIC_KINDS:
        raise ValueError(f"unsupported tactic kind: {kind!r}")
    if not isinstance(route, ReferenceRouteKey):
        raise TypeError("route must be a ReferenceRouteKey")
    normalized_native_id = str(native_occurrence_id)
    if not normalized_native_id:
        raise ValueError("native_occurrence_id must not be empty")
    payload = {
        "identity_version": REFERENCE_OCCURRENCE_ID_VERSION,
        "kind": normalized_kind,
        "route": route.to_dict(),
        "native_occurrence_id": normalized_native_id,
    }
    digest = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
    return f"reference_o_{digest}"


@dataclass(frozen=True)
class TacticIdentity:
    """Versioned tactic identity with locator-only hashing.

    Version 2 compares complete context-bearing QueryCGR-key payloads and rooted
    topology. Version 1 retains exact labelled-graph equivalence for persisted
    legacy libraries.
    """

    kind: TacticKind
    equivalence_payload: Mapping[str, Any]
    lookup_key: str = ""
    identity_version: int = TACTIC_IDENTITY_VERSION

    def __post_init__(self) -> None:
        kind = str(self.kind)
        if kind not in _TACTIC_KINDS:
            raise ValueError(f"unsupported tactic kind: {self.kind!r}")
        identity_version = int(self.identity_version)
        if identity_version not in SUPPORTED_TACTIC_IDENTITY_VERSIONS:
            raise ValueError(
                f"unsupported tactic identity version: {self.identity_version}"
            )
        payload = _json_copy(
            self.equivalence_payload,
            field_name="equivalence_payload",
        )
        if not isinstance(payload, dict):
            raise ValueError("equivalence_payload must be a JSON object")

        from route_inspector.reference_library.identity.tactics import tactic_lookup_key

        expected_key = tactic_lookup_key(
            kind,
            payload,
            identity_version=identity_version,
        )
        supplied_key = str(self.lookup_key)
        if supplied_key and supplied_key != expected_key:
            raise ValueError("lookup_key does not match the equivalence payload")
        object.__setattr__(self, "kind", cast(TacticKind, kind))
        object.__setattr__(self, "identity_version", identity_version)
        object.__setattr__(self, "equivalence_payload", payload)
        object.__setattr__(self, "lookup_key", expected_key)

    def equivalent_to(self, other: object) -> bool:
        """Compare the complete versioned payload, never hash equality alone."""

        if not isinstance(other, TacticIdentity):
            return False
        if self.kind != other.kind or self.identity_version != other.identity_version:
            return False
        # Different coarse keys cannot represent isomorphic payloads under the
        # versioned invariant signature. Equal keys still require exact matching.
        if self.lookup_key != other.lookup_key:
            return False
        from route_inspector.reference_library.identity.tactics import (
            tactic_payloads_are_equivalent,
        )

        return tactic_payloads_are_equivalent(
            self.kind,
            self.equivalence_payload,
            other.equivalence_payload,
            identity_version=self.identity_version,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "identity_version": self.identity_version,
            "kind": self.kind,
            "lookup_key": self.lookup_key,
            "equivalence_payload": _json_copy(
                self.equivalence_payload,
                field_name="equivalence_payload",
            ),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TacticIdentity":
        if "identity_version" not in value:
            raise ValueError("serialized tactic identity requires identity_version")
        return cls(
            kind=cast(TacticKind, str(value["kind"])),
            equivalence_payload=cast(Mapping[str, Any], value["equivalence_payload"]),
            lookup_key=str(value.get("lookup_key") or ""),
            identity_version=int(value["identity_version"]),
        )


@dataclass(frozen=True)
class TacticOccurrence:
    """One normalized tactic tied to its complete native route occurrence.

    ``occurrence_id`` remains the extractor-native identifier. The
    :attr:`reference_occurrence_id` qualifies it by tactic kind and the full
    Reference route triple so two corpora can retain distinct evidence even
    when their native source IDs and route-local paths coincide.
    """

    occurrence_id: str
    identity: TacticIdentity
    route: ReferenceRouteKey
    route_target_smiles: str
    motif_target_smiles: str
    selected_reaction_node_paths: tuple[NodePath, ...]
    skipped_reaction_node_paths: tuple[NodePath, ...]
    native_schema_version: int
    native_payload: Mapping[str, Any]
    annotations: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        occurrence_id = str(self.occurrence_id)
        if not occurrence_id:
            raise ValueError("TacticOccurrence requires occurrence_id")
        if not isinstance(self.identity, TacticIdentity):
            raise TypeError("identity must be a TacticIdentity")
        if not isinstance(self.route, ReferenceRouteKey):
            raise TypeError("route must be a ReferenceRouteKey")
        schema_version = int(self.native_schema_version)
        if schema_version < 1:
            raise ValueError("native_schema_version must be positive")
        selected = tuple(_path(path) for path in self.selected_reaction_node_paths)
        skipped = tuple(_path(path) for path in self.skipped_reaction_node_paths)
        if len(selected) != len(set(selected)):
            raise ValueError("selected reaction-node paths must be unique")
        if len(skipped) != len(set(skipped)):
            raise ValueError("skipped reaction-node paths must be unique")
        if set(selected) & set(skipped):
            raise ValueError(
                "selected and skipped reaction-node paths must be disjoint"
            )
        kind = self.identity.kind
        identity_payload = self.identity.equivalence_payload
        if kind.startswith("rrseq_"):
            sequence_field = (
                "query_cgr_keys" if self.identity.identity_version >= 2 else "rules"
            )
            expected_selected = len(identity_payload[sequence_field])
        else:
            expected_selected = _rrsubtree_identity_node_count(identity_payload["root"])
        if len(selected) != expected_selected:
            raise ValueError(
                f"{kind} selected path count must equal identity node/rule count"
            )
        if kind.endswith("_cons") and skipped:
            raise ValueError(f"{kind} cannot contain skipped reaction-node paths")
        if kind.endswith("_gap") and not skipped:
            raise ValueError(f"{kind} requires skipped reaction-node paths")
        if kind == "rrseq_gap" and self.identity.identity_version >= 4:
            from route_inspector.tactics.rrseq.gap_widths import occurrence_gap_widths

            if tuple(
                identity_payload["inter_selection_gap_widths"]
            ) != occurrence_gap_widths(self):
                raise ValueError(
                    "RRSeq_gap identity widths disagree with occurrence provenance"
                )
        native = _json_copy(self.native_payload, field_name="native_payload")
        annotations = _json_copy(self.annotations, field_name="annotations")
        if not isinstance(native, dict) or not isinstance(annotations, dict):
            raise ValueError("native_payload and annotations must be JSON objects")
        if "occurrence_id" not in native:
            raise ValueError("native payload requires occurrence_id")
        native_occurrence_id = native["occurrence_id"]
        if str(native_occurrence_id) != occurrence_id:
            raise ValueError("native occurrence_id differs from TacticOccurrence")
        if "schema_version" not in native:
            raise ValueError("native payload requires schema_version")
        native_schema = native["schema_version"]
        if int(native_schema) != schema_version:
            raise ValueError("native schema_version differs from native_schema_version")
        for field_name, expected in self.route.to_dict().items():
            if field_name not in native:
                raise ValueError(f"native payload requires {field_name}")
            supplied = native[field_name]
            if str(supplied) != expected:
                raise ValueError(
                    f"native {field_name} differs from the Reference route key"
                )
        object.__setattr__(self, "occurrence_id", occurrence_id)
        object.__setattr__(self, "route_target_smiles", str(self.route_target_smiles))
        object.__setattr__(self, "motif_target_smiles", str(self.motif_target_smiles))
        object.__setattr__(self, "selected_reaction_node_paths", selected)
        object.__setattr__(self, "skipped_reaction_node_paths", skipped)
        object.__setattr__(self, "native_schema_version", schema_version)
        object.__setattr__(self, "native_payload", native)
        object.__setattr__(self, "annotations", annotations)

    @property
    def reference_occurrence_id(self) -> str:
        """Return the deterministic catalog-safe ID for this occurrence."""

        return stable_reference_occurrence_id(
            kind=self.identity.kind,
            route=self.route,
            native_occurrence_id=self.occurrence_id,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "reference_occurrence_id": self.reference_occurrence_id,
            "occurrence_id": self.occurrence_id,
            "identity": self.identity.to_dict(),
            "route": self.route.to_dict(),
            "route_target_smiles": self.route_target_smiles,
            "motif_target_smiles": self.motif_target_smiles,
            "selected_reaction_node_paths": [
                list(path) for path in self.selected_reaction_node_paths
            ],
            "skipped_reaction_node_paths": [
                list(path) for path in self.skipped_reaction_node_paths
            ],
            "native_schema_version": self.native_schema_version,
            "native_payload": _json_copy(
                self.native_payload,
                field_name="native_payload",
            ),
            "annotations": _json_copy(
                self.annotations,
                field_name="annotations",
            ),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TacticOccurrence":
        occurrence = cls(
            occurrence_id=str(value["occurrence_id"]),
            identity=TacticIdentity.from_dict(value["identity"]),
            route=ReferenceRouteKey.from_dict(value["route"]),
            route_target_smiles=str(value.get("route_target_smiles") or ""),
            motif_target_smiles=str(value.get("motif_target_smiles") or ""),
            selected_reaction_node_paths=tuple(
                _path(path) for path in value.get("selected_reaction_node_paths", ())
            ),
            skipped_reaction_node_paths=tuple(
                _path(path) for path in value.get("skipped_reaction_node_paths", ())
            ),
            native_schema_version=int(value["native_schema_version"]),
            native_payload=cast(Mapping[str, Any], value["native_payload"]),
            annotations=cast(Mapping[str, Any], value.get("annotations") or {}),
        )
        supplied_reference_id = value.get("reference_occurrence_id")
        if (
            supplied_reference_id is not None
            and str(supplied_reference_id) != occurrence.reference_occurrence_id
        ):
            raise ValueError(
                "reference_occurrence_id does not match native occurrence provenance"
            )
        return occurrence


__all__ = [
    "NodePath",
    "REFERENCE_OCCURRENCE_ID_VERSION",
    "ReferenceRouteKey",
    "TACTIC_IDENTITY_VERSION",
    "TacticIdentity",
    "TacticKind",
    "TacticOccurrence",
    "stable_reference_occurrence_id",
]
