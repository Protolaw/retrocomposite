"""Provider-only reclassification of persisted PG strategy libraries."""

from __future__ import annotations

import json
import os
import shutil
import tempfile
from collections import defaultdict
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Callable, Mapping

from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.protection.strategies.catalog import (
    PGStrategyLibraryManifest,
    ReferencePGStrategyLibrary,
    _component_content,
    _digest,
    _support_record,
)
from route_inspector.protection.strategies.models import ProcessedRoutePGStrategies
from route_inspector.protection.strategies.processing import (
    annotate_pg_strategy_classifications,
)
from route_inspector.reference_library.catalog import ReferenceTacticLibrary
from route_inspector.reference_library.storage.artifacts import (
    _publish_directory_no_replace,
)


@dataclass(frozen=True)
class PGStrategyReclassificationResult:
    """Summary of one immutable provider-specific library publication."""

    output_path: Path
    tactic_library_id: str
    pg_strategy_library_id: str
    provider: str
    provider_version: str
    taxonomy: str
    unique_classifier_inputs: int
    interval_step_occurrences: int


def _artifact_descriptor(path: Path, root: Path) -> dict[str, Any]:
    return {
        "path": path.relative_to(root).as_posix(),
        "sha256": _sha256_file(path),
        "size_bytes": path.stat().st_size,
    }


def _link_or_copy(source: str, destination: str) -> str:
    try:
        os.link(source, destination)
        return destination
    except OSError:
        return shutil.copy2(source, destination)


def _processed_routes(pg_library: ReferencePGStrategyLibrary):
    event_entries = pg_library.entries("event")
    step_entries = pg_library.entries("interval_step")
    events = tuple(
        pg_library.get_event_occurrence(str(record["occurrence_id"]))
        for entry in event_entries
        for record in entry.support_records
    )
    steps = tuple(
        pg_library.get_interval_step(str(record["occurrence_id"]))
        for entry in step_entries
        for record in entry.support_records
    )
    grouped: dict[Any, dict[str, list[Any]]] = defaultdict(
        lambda: {"events": [], "steps": []}
    )
    for event in events:
        grouped[event.route]["events"].append(event)
    for step in steps:
        grouped[step.route]["steps"].append(step)
    if not grouped:
        raise ValueError("PG strategy component contains no resolved events")

    def route_key(route: Any) -> tuple[str, str, tuple[int, str]]:
        route_id = str(route.route_id)
        try:
            sortable_id = (0, f"{int(route_id):020d}")
        except ValueError:
            sortable_id = (1, route_id)
        return str(route.dataset_id), str(route.source_identity), sortable_id

    ordered_routes = sorted(grouped, key=route_key)
    diagnostics = pg_library.diagnostics
    processed = []
    for index, route in enumerate(ordered_routes):
        values = grouped[route]
        processed.append(
            ProcessedRoutePGStrategies(
                route=route,
                events=tuple(
                    sorted(values["events"], key=lambda item: item.occurrence_id)
                ),
                interval_steps=tuple(
                    sorted(values["steps"], key=lambda item: item.occurrence_id)
                ),
                interval_sequences=(),
                diagnostics=diagnostics if index == 0 else (),
            )
        )
    return tuple(processed)


def reclassify_pg_strategy_library_to_directory(
    source_library: str | Path,
    output_dir: str | Path,
    provider: Any,
    *,
    classifier_metadata: Mapping[str, Any] | None = None,
    n_cpu: int = 1,
    worker_chunksize: int = 100,
    progress_callback: Callable[[int, int], None] | None = None,
) -> PGStrategyReclassificationResult:
    """Publish a new Reference library with only PG class labels replaced.

    Tactic, bigram, PG-event, and PG-identity artifacts are retained exactly.
    The source directory is never modified, and the destination must not exist.
    """

    source = Path(source_library).expanduser().resolve()
    destination = Path(output_dir).expanduser().resolve()
    if destination.exists():
        raise FileExistsError(f"destination already exists: {destination}")
    if source == destination:
        raise ValueError("source and destination libraries must differ")

    source_manifest = json.loads((source / "manifest.json").read_text(encoding="utf-8"))
    if str(source_manifest.get("library_id", "")).startswith("pg_strategy_library_"):
        from route_inspector.protection.strategies.reclassification import (
            reclassify_standalone_pg_library,
        )

        return reclassify_standalone_pg_library(
            source,
            output_dir,
            provider,
            classifier_metadata=classifier_metadata,
            n_cpu=n_cpu,
            worker_chunksize=worker_chunksize,
            progress_callback=progress_callback,
        )
    library = ReferenceTacticLibrary.load(source, verification="fast")
    try:
        pg_library = library.pg_strategy_library
        if pg_library is None:
            raise ValueError("source Reference library has no PG strategy component")
        processed = _processed_routes(pg_library)
        source_entries = pg_library.entries()
        source_events = tuple(event for route in processed for event in route.events)
        source_event_ids = {event.occurrence_id for event in source_events}
        source_step_ids = {
            step.occurrence_id for route in processed for step in route.interval_steps
        }
        source_entry_ids = {entry.entry_id for entry in source_entries}
        source_statistics = dict(pg_library.manifest.statistics)
        source_profile = json.loads(json.dumps(pg_library.manifest.processing_profile))
        reference_corpora = tuple(pg_library.manifest.reference_corpora)
        tactic_library_id = library.library_id

        enriched = annotate_pg_strategy_classifications(
            processed,
            provider,
            n_cpu=n_cpu,
            worker_chunksize=worker_chunksize,
            progress_callback=progress_callback,
        )
        provider_version = str(provider.provider_version)
        provider_name = str(provider.provider_name)
        taxonomy = str(provider.taxonomy_id)
        profile = source_profile
        profile["classifier"] = {
            **dict(classifier_metadata or {}),
            "provider": provider_name,
            "provider_version": provider_version,
            "taxonomy": taxonomy,
            "tier": 3,
        }
        replacement_steps = tuple(
            step for route in enriched for step in route.interval_steps
        )
        replacement_step_by_id = {
            step.occurrence_id: step for step in replacement_steps
        }
        replacement_entries = tuple(
            replace(
                entry,
                support_records=tuple(
                    _support_record(
                        replacement_step_by_id[str(record["occurrence_id"])]
                    )
                    for record in entry.support_records
                ),
            )
            if entry.kind == "interval_step"
            else entry
            for entry in source_entries
        )
        component_content = _component_content(
            processing_profile=profile,
            reference_corpora=reference_corpora,
            entries=replacement_entries,
            events=source_events,
            steps=replacement_steps,
            diagnostics=pg_library.diagnostics,
        )
        replacement_manifest = PGStrategyLibraryManifest(
            library_id=f"pg_strategy_library_{_digest(component_content)}",
            processing_profile=profile,
            reference_corpora=reference_corpora,
            statistics=source_statistics,
        )
        event_ownership = {
            str(record["occurrence_id"]): entry.entry_id
            for entry in replacement_entries
            if entry.kind == "event"
            for record in entry.support_records
        }
        step_ownership = {
            str(record["occurrence_id"]): entry.entry_id
            for entry in replacement_entries
            if entry.kind == "interval_step"
            for record in entry.support_records
        }
        replacement_pg = ReferencePGStrategyLibrary(
            manifest=replacement_manifest,
            entries=replacement_entries,
            event_occurrences=source_events,
            interval_steps=replacement_steps,
            diagnostics=pg_library.diagnostics,
            event_ownership=event_ownership,
            step_ownership=step_ownership,
        )
        replacement_event_ids = {
            event.occurrence_id for route in enriched for event in route.events
        }
        replacement_step_ids = {
            step.occurrence_id for route in enriched for step in route.interval_steps
        }
        if replacement_event_ids != source_event_ids:
            raise RuntimeError(
                "PG event occurrence IDs changed during reclassification"
            )
        if replacement_step_ids != source_step_ids:
            raise RuntimeError("PG interval-step IDs changed during reclassification")
        if {entry.entry_id for entry in replacement_pg.entries()} != source_entry_ids:
            raise RuntimeError("PG entry identities changed during reclassification")
        if dict(replacement_pg.manifest.statistics) != source_statistics:
            raise RuntimeError("PG statistics changed during reclassification")
        unique_inputs = len(
            {
                str(step.classification["classifier_input"])
                for route in enriched
                for step in route.interval_steps
            }
        )
    finally:
        library.close()

    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(
        tempfile.mkdtemp(
            prefix=f".{destination.name}.",
            suffix=".tmp",
            dir=destination.parent,
        )
    )
    try:
        shutil.copytree(
            source,
            temporary,
            dirs_exist_ok=True,
            copy_function=_link_or_copy,
            symlinks=False,
        )
        shutil.rmtree(temporary / "pg_strategy")
        pg_manifest_path = replacement_pg.write_component(
            temporary,
            include_sqlite=True,
        )

        manifest_path = temporary / "manifest.json"
        manifest = json.loads((source / "manifest.json").read_text(encoding="utf-8"))
        component = dict(manifest["components"]["pg_strategy"])
        component["library_id"] = replacement_pg.library_id
        manifest["components"]["pg_strategy"] = component
        manifest["artifacts"]["pg_strategy_manifest"] = _artifact_descriptor(
            pg_manifest_path,
            temporary,
        )

        if manifest["library_format_version"] < 6:
            summary_path = temporary / "summary.json"
            summary = json.loads((source / "summary.json").read_text(encoding="utf-8"))
            summary["components"] = dict(manifest["components"])
            summary_path.unlink()
            summary_path.write_text(
                json.dumps(summary, indent=2) + "\n",
                encoding="utf-8",
            )
            manifest["artifacts"]["summary"] = _artifact_descriptor(
                summary_path,
                temporary,
            )
        manifest_path.unlink()
        manifest_path.write_text(
            json.dumps(manifest, indent=2) + "\n",
            encoding="utf-8",
        )
        _publish_directory_no_replace(temporary, destination)
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise

    with ReferenceTacticLibrary.load(destination, verification="fast") as loaded:
        if loaded.pg_strategy_library is None:
            raise RuntimeError("published library lost its PG strategy component")
        if loaded.pg_strategy_library.library_id != replacement_pg.library_id:
            raise RuntimeError("published PG strategy component ID is inconsistent")

    return PGStrategyReclassificationResult(
        output_path=destination,
        tactic_library_id=tactic_library_id,
        pg_strategy_library_id=replacement_pg.library_id,
        provider=provider_name,
        provider_version=provider_version,
        taxonomy=taxonomy,
        unique_classifier_inputs=unique_inputs,
        interval_step_occurrences=len(source_step_ids),
    )


__all__ = [
    "PGStrategyReclassificationResult",
    "reclassify_pg_strategy_library_to_directory",
]
