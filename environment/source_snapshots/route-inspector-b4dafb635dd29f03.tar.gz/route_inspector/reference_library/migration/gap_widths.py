"""Verified ownership migration; mapped occurrences and certificates stay exact."""

from dataclasses import replace


def transformation_migration(old_reference, new_reference, companion):
    from route_inspector.composite_rules.library import (
        CompositeDecompositionLibrary,
        _library_id,
    )
    from route_inspector.composite_rules.reindex import validate_composite_library

    if (
        old_reference.tactic_identity_version,
        new_reference.tactic_identity_version,
    ) not in ((2, 3), (3, 4)):
        raise ValueError("Migration requires identity v2 to v3 or v3 to v4")
    if old_reference.processing_profile != new_reference.processing_profile:
        raise ValueError("Migration changed extraction settings")
    if (
        old_reference.manifest.reference_corpora
        != new_reference.manifest.reference_corpora
    ):
        raise ValueError("Migration changed source corpus")
    validate_composite_library(companion, old_reference)
    mapping, ownership, counts = {}, {}, {}
    for old in old_reference.iter_occurrences():
        oid = old.reference_occurrence_id
        new = new_reference.get_occurrence(oid)
        a, b = old.to_dict(), new.to_dict()
        a.pop("identity")
        b.pop("identity")
        if a != b:
            raise ValueError(f"Migration changed occurrence provenance: {oid}")
        entry = new_reference.entry_id_for_occurrence(oid)
        old_entry = old_reference.entry_id_for_occurrence(oid)
        mapping.setdefault(old_entry, set()).add(entry)
        ownership[oid] = entry
        counts[old_entry] = counts.get(old_entry, 0) + 1
    if set(ownership) != {
        o.reference_occurrence_id for o in new_reference.iter_occurrences()
    }:
        raise ValueError("Migration changed the occurrence roster")
    # A historical native key may have omitted query constraints; permit honest
    # splits in the report, while requiring the reported four-way merge separately.
    entries = companion.entries()
    links = tuple(
        replace(link, tactic_entry_id=ownership[link.reference_occurrence_id])
        for entry in entries
        for link in companion.links_for_entry(entry.composite_id)
    )
    manifest = replace(
        companion.manifest,
        source_reference_library_id=new_reference.library_id,
        library_id=_library_id(
            new_reference.library_id,
            companion.manifest.source_routes_sha256,
            companion.manifest.construction_profile,
            entries,
            links,
            format_version=companion.manifest.library_format_version,
        ),
        artifacts={},
    )
    report = {
        "operation": "gap_width_identity_migration"
        if new_reference.tactic_identity_version == 4
        else "transformation_family_migration",
        "old_reference_library_id": old_reference.library_id,
        "new_reference_library_id": new_reference.library_id,
        "occurrences_preserved": len(ownership),
        "certificates_preserved": len(links),
        "tactic_ids": [
            {"old": old, "new": sorted(new), "occurrence_count": counts[old]}
            for old, new in sorted(mapping.items())
        ],
    }
    return CompositeDecompositionLibrary(
        manifest=manifest, entries=entries, links=links, errors=companion.errors
    ), report


def with_gap_width_identity(occurrence):
    """Upgrade v3 evidence without parsing rules or changing native provenance."""
    from route_inspector.reference_library.models import TacticIdentity
    from route_inspector.tactics.rrseq.gap_widths import occurrence_gap_widths

    if occurrence.identity.identity_version != 3:
        raise ValueError("Width migration requires transformation identity version 3")
    payload = dict(occurrence.identity.equivalence_payload)
    if occurrence.identity.kind == "rrseq_gap":
        payload["inter_selection_gap_widths"] = list(occurrence_gap_widths(occurrence))
    return replace(
        occurrence,
        identity=TacticIdentity(occurrence.identity.kind, payload, identity_version=4),
    )


def migrate_gap_width_reference(old_reference, destination):
    """Stream a verified v3 library into staged v4 identities without extraction."""
    import hashlib
    import json
    import shutil
    import sqlite3
    import tempfile
    from collections import defaultdict
    from pathlib import Path

    from route_inspector.infrastructure.hashing import sha256_file
    from route_inspector.infrastructure.publication import publish_directory_no_replace
    from route_inspector.reference_library.build.streaming import (
        _STAGING_SCHEMA,
        _aggregate_tactics,
        _stream_library_id,
        _tactic_statistics,
        _write_final_sqlite,
        _write_jsonl_from_column,
        _write_tactic_report,
    )
    from route_inspector.reference_library.catalog import ReferenceTacticLibrary
    from route_inspector.reference_library.profile import canonical_json
    from route_inspector.reference_library.storage.manifest import (
        REFERENCE_LIBRARY_FORMAT_VERSION,
        WIDTH_IDENTITY_CONFIGURATION,
        compact_supplementary_evidence,
    )

    if old_reference.tactic_identity_version != 3 or old_reference.directory is None:
        raise ValueError("Migration requires a persisted version 3 reference library")
    destination = Path(destination)
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent)
    )
    db = None
    try:
        db = sqlite3.connect(stage / "migration.sqlite")
        db.row_factory = sqlite3.Row
        db.executescript(_STAGING_SCHEMA)
        db.execute(
            "CREATE TABLE old_ownership(occurrence_id TEXT PRIMARY KEY, entry_id TEXT)"
        )
        for i, old in enumerate(old_reference.iter_occurrences()):
            new = with_gap_width_identity(old)
            value = new.to_dict()
            old_value = old.to_dict()
            old_value["identity"] = value["identity"]
            if old_value != value:
                raise ValueError("Migration changed occurrence evidence")
            encoded = canonical_json(value)
            db.execute(
                "INSERT INTO tactic_occurrences VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NULL)",
                (
                    new.reference_occurrence_id,
                    new.occurrence_id,
                    new.identity.kind,
                    4,
                    new.identity.lookup_key,
                    canonical_json(new.identity.to_dict()),
                    new.route.dataset_id,
                    new.route.source_identity,
                    new.route.route_id,
                    new.native_schema_version,
                    hashlib.sha256(encoded.encode()).hexdigest(),
                    encoded,
                ),
            )
            db.execute(
                "INSERT INTO old_ownership VALUES (?,?)",
                (
                    new.reference_occurrence_id,
                    old_reference.entry_id_for_occurrence(new.reference_occurrence_id),
                ),
            )
            if i % 2000 == 0:
                db.commit()
                print(f"Migrated {i:,} occurrence identities", flush=True)
        db.commit()
        _aggregate_tactics(db)
        stats = dict(old_reference.manifest.statistics)
        stats.update(_tactic_statistics(db))
        # Route roster counts are unchanged; staging contains no new route processing.
        for key in (
            "reference_route_count_processed",
            "reference_route_count_with_tactics",
            "reference_route_count_without_extracted_tactics",
        ):
            if key in old_reference.manifest.statistics:
                stats[key] = old_reference.manifest.statistics[key]
        library_id = _stream_library_id(
            db,
            profile_fingerprint=old_reference.processing_profile.fingerprint,
            reference_corpora=old_reference.manifest.reference_corpora,
        )
        manifest = replace(
            old_reference.manifest,
            library_format_version=REFERENCE_LIBRARY_FORMAT_VERSION,
            identity_configuration=WIDTH_IDENTITY_CONFIGURATION,
            library_id=library_id,
            statistics=stats,
            supplementary_evidence=compact_supplementary_evidence(
                old_reference.manifest.supplementary_evidence
            ),
            artifacts={},
        )
        paths = {}
        for key, descriptor in old_reference.manifest.artifacts.items():
            if key == "summary":
                continue
            target = stage / descriptor["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            paths[key] = target
            if key not in {
                "catalog",
                "occurrences",
                "rrseq_entries",
                "rrsubtree_entries",
                "summary",
            } and not key.startswith("report_rr"):
                shutil.copy2(old_reference.directory / descriptor["path"], target)
        component = old_reference.manifest.components.get("pg_strategy")
        if component is not None:
            manifest_path = component["manifest_path"]
            if (
                manifest_path
                != old_reference.manifest.artifacts["pg_strategy_manifest"]["path"]
            ):
                raise ValueError(
                    "PG strategy component manifest path disagrees with artifact"
                )
            component_path = Path(manifest_path).parent
            # The root manifest indexes only the nested manifest. Preserve all
            # component evidence and its optional catalog without reserializing.
            shutil.copytree(
                old_reference.directory / component_path,
                stage / component_path,
                dirs_exist_ok=True,
            )
        for kind in ("rrseq_cons", "rrseq_gap", "rrsubtree_cons", "rrsubtree_gap"):
            _write_tactic_report(db, paths[f"report_{kind}"], kind)
        for prefix in ("rrseq", "rrsubtree"):
            _write_jsonl_from_column(
                db,
                paths[f"{prefix}_entries"],
                f"SELECT entry_json FROM tactic_entries WHERE tactic_kind LIKE '{prefix}_%' ORDER BY entry_id",
            )
        with paths["occurrences"].open("w") as out:
            for row in db.execute(
                "SELECT entry_id,occurrence_json FROM tactic_occurrences ORDER BY reference_occurrence_id"
            ):
                out.write(
                    '{"entry_id":'
                    + canonical_json(row["entry_id"])
                    + ',"occurrence":'
                    + row["occurrence_json"]
                    + "}\n"
                )
        _write_final_sqlite(
            db, paths.setdefault("catalog", stage / "catalog.sqlite"), manifest=manifest
        )
        artifacts = {
            key: dict(
                path=p.relative_to(stage).as_posix(),
                sha256=sha256_file(p),
                size_bytes=p.stat().st_size,
            )
            for key, p in paths.items()
        }
        (stage / "manifest.json").write_text(
            json.dumps(manifest.with_artifacts(artifacts).to_dict(), indent=2) + "\n"
        )
        mapping = defaultdict(set)
        for row in db.execute(
            "SELECT o.entry_id AS old,n.entry_id AS new FROM old_ownership o JOIN tactic_occurrences n ON o.occurrence_id=n.reference_occurrence_id"
        ):
            mapping[row["old"]].add(row["new"])
        report = dict(
            operation="gap_width_identity_migration",
            old_reference_library_id=old_reference.library_id,
            new_reference_library_id=library_id,
            occurrences_preserved=stats["occurrence_count"],
            tactic_ids=[
                dict(old=old, new=sorted(new)) for old, new in sorted(mapping.items())
            ],
            split_families=sum(len(v) > 1 for v in mapping.values()),
            statistics=stats,
        )
        db.close()
        db = None
        (stage / "migration.sqlite").unlink()
        with ReferenceTacticLibrary.load(stage, verification="full"):
            pass
        publish_directory_no_replace(stage, destination)
        return report
    finally:
        if db is not None:
            db.close()
        if stage.exists():
            shutil.rmtree(stage)
