"""Versioned scientific processing profiles for tactic libraries.

Scientific resource paths remain fingerprinted. Only explicitly curated
operational output metadata and creation timestamps are excluded.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

# Version 3 requires skipped RRSubtree centers to avoid all selected centers
# on their arm. Older profiles remain readable for historical inspection.
REFERENCE_PROCESSING_PROFILE_VERSION = 3
SUPPORTED_REFERENCE_PROCESSING_PROFILE_VERSIONS = frozenset({1, 2, 3})

_NON_SEMANTIC_KEYS = frozenset(
    {
        "created_at",
        "creation_time",
        "creation_timestamp",
        "output_path",
        "timestamp",
    }
)


class ReferenceProfileCompatibilityError(ValueError):
    """Raised when route assessment and library extraction profiles differ."""


def canonical_json(value: Any) -> str:
    """Serialize a JSON-compatible value deterministically."""

    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    )


def _json_value(value: Any, *, label: str) -> Any:
    """Return a detached, deterministic JSON value or fail clearly."""

    def path_strings(item: Any) -> Any:
        if isinstance(item, Path):
            return str(item)
        if isinstance(item, Mapping):
            return {key: path_strings(nested) for key, nested in item.items()}
        if isinstance(item, (list, tuple)):
            return [path_strings(nested) for nested in item]
        return item

    try:
        return json.loads(canonical_json(path_strings(value)))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be JSON-compatible") from exc


def _is_non_semantic_key(key: str) -> bool:
    normalized = key.strip().lower()
    return normalized in _NON_SEMANTIC_KEYS


def _semantic_value(value: Any) -> Any:
    """Remove only explicitly non-scientific metadata from a fingerprint payload."""

    if isinstance(value, Mapping):
        return {
            str(key): _semantic_value(item)
            for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))
            if not _is_non_semantic_key(str(key))
        }
    if isinstance(value, (list, tuple)):
        return [_semantic_value(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    return value


def _validate_rule_identity_compatibility(config: Mapping[str, Any]) -> None:
    """Reject extraction settings that tactic identity v1 cannot represent."""

    if config.get("ignore_stereo") is False:
        raise ValueError(
            "reference tactic identity v1 requires "
            "rule_extraction_config.ignore_stereo=True"
        )
    atom_info = config.get("atom_info_retention")
    if not isinstance(atom_info, Mapping):
        return
    unsupported = sorted(
        field_name
        for section in atom_info.values()
        if isinstance(section, Mapping)
        for field_name in ("implicit_hydrogens", "ring_sizes")
        if section.get(field_name) is True
    )
    if unsupported:
        raise ValueError(
            "reference tactic identity v1 cannot preserve enabled "
            "atom_info_retention constraints: " + ", ".join(sorted(set(unsupported)))
        )


@dataclass(frozen=True)
class ReferenceProcessingProfile:
    """All extraction settings that determine tactic-library compatibility."""

    input_state: str
    rule_extraction_config: Mapping[str, Any]
    protection_config: Mapping[str, Any]
    source_id_adapter: str
    rrseq_min_length: int
    rrseq_max_length: int | None
    rrsubtree_min_size: int
    rrsubtree_max_size: int
    rrsubtree_max_candidates_per_route: int
    factorability_config: Mapping[str, Any] = field(default_factory=dict)
    mapping_validation: bool = True
    schema_version: int = REFERENCE_PROCESSING_PROFILE_VERSION

    def __post_init__(self) -> None:
        if self.schema_version not in SUPPORTED_REFERENCE_PROCESSING_PROFILE_VERSIONS:
            raise ValueError(
                "unsupported reference processing profile version: "
                f"{self.schema_version}"
            )
        if self.input_state not in {"raw", "preprocessed"}:
            raise ValueError("input_state must be 'raw' or 'preprocessed'")
        if not self.source_id_adapter:
            raise ValueError("source_id_adapter must not be empty")
        if self.rrseq_min_length < 2:
            raise ValueError("rrseq_min_length must be at least 2")
        if (
            self.rrseq_max_length is not None
            and self.rrseq_max_length < self.rrseq_min_length
        ):
            raise ValueError("rrseq_max_length must be at least rrseq_min_length")
        if self.rrsubtree_min_size < 3:
            raise ValueError("rrsubtree_min_size must be at least 3")
        if self.rrsubtree_max_size < self.rrsubtree_min_size:
            raise ValueError("rrsubtree_max_size must be at least rrsubtree_min_size")
        if self.rrsubtree_max_candidates_per_route < 1:
            raise ValueError("rrsubtree_max_candidates_per_route must be positive")
        if not self.mapping_validation:
            raise ValueError(
                "reference tactic libraries require mapping_validation=True"
            )
        _validate_rule_identity_compatibility(self.rule_extraction_config)
        object.__setattr__(
            self,
            "rule_extraction_config",
            _json_value(
                self.rule_extraction_config,
                label="rule_extraction_config",
            ),
        )
        object.__setattr__(
            self,
            "protection_config",
            _json_value(self.protection_config, label="protection_config"),
        )
        object.__setattr__(
            self,
            "factorability_config",
            _json_value(self.factorability_config, label="factorability_config"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the complete human-inspectable profile payload."""

        return {
            "schema_version": self.schema_version,
            "input_state": self.input_state,
            "rule_extraction_config": dict(self.rule_extraction_config),
            "protection_config": dict(self.protection_config),
            "source_id_adapter": self.source_id_adapter,
            "rrseq_min_length": self.rrseq_min_length,
            "rrseq_max_length": self.rrseq_max_length,
            "rrsubtree_min_size": self.rrsubtree_min_size,
            "rrsubtree_max_size": self.rrsubtree_max_size,
            "rrsubtree_max_candidates_per_route": (
                self.rrsubtree_max_candidates_per_route
            ),
            "factorability_config": dict(self.factorability_config),
            "mapping_validation": self.mapping_validation,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ReferenceProcessingProfile":
        """Validate and deserialize one persisted processing profile."""

        return cls(
            schema_version=int(value.get("schema_version", -1)),
            input_state=str(value["input_state"]),
            rule_extraction_config=dict(value.get("rule_extraction_config") or {}),
            protection_config=dict(value.get("protection_config") or {}),
            source_id_adapter=str(value["source_id_adapter"]),
            rrseq_min_length=int(value["rrseq_min_length"]),
            rrseq_max_length=(
                None
                if value.get("rrseq_max_length") is None
                else int(value["rrseq_max_length"])
            ),
            rrsubtree_min_size=int(value["rrsubtree_min_size"]),
            rrsubtree_max_size=int(value["rrsubtree_max_size"]),
            rrsubtree_max_candidates_per_route=int(
                value["rrsubtree_max_candidates_per_route"]
            ),
            factorability_config=dict(value.get("factorability_config") or {}),
            mapping_validation=bool(value.get("mapping_validation", False)),
        )

    @property
    def compatibility_payload(self) -> dict[str, Any]:
        """Return only semantic settings used for compatibility decisions."""

        return _semantic_value(self.to_dict())

    @property
    def canonical_json(self) -> str:
        """Return canonical semantic configuration JSON."""

        return canonical_json(self.compatibility_payload)

    @property
    def fingerprint(self) -> str:
        """Return a deterministic SHA-256 compatibility fingerprint."""

        return hashlib.sha256(self.canonical_json.encode("utf-8")).hexdigest()

    def assert_compatible(self, other: "ReferenceProcessingProfile") -> None:
        """Fail clearly unless two tactic-extraction profiles are identical."""

        if not isinstance(other, ReferenceProcessingProfile):
            raise TypeError("other must be a ReferenceProcessingProfile")
        if self.fingerprint == other.fingerprint:
            return
        left = self.compatibility_payload
        right = other.compatibility_payload
        differing = sorted(
            key for key in set(left) | set(right) if left.get(key) != right.get(key)
        )
        raise ReferenceProfileCompatibilityError(
            "incompatible reference tactic-library processing profile; "
            f"differing_fields={differing} "
            f"library_fingerprint={self.fingerprint} "
            f"assessment_fingerprint={other.fingerprint}"
        )


__all__ = [
    "REFERENCE_PROCESSING_PROFILE_VERSION",
    "ReferenceProcessingProfile",
    "ReferenceProfileCompatibilityError",
    "canonical_json",
]
