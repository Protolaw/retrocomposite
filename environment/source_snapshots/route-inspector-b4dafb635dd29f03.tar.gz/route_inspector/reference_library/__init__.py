"""Reference libraries, occurrence records, and assessment policies.

Construction and publication workflows live in :mod:`route_inspector.workflows`.
"""

from importlib import import_module

_EXPORTS = {
    "INCOMPLETE_ASSESSMENT_LIMITATION": (
        "route_inspector.reference_library.assessment.tactics",
        "INCOMPLETE_ASSESSMENT_LIMITATION",
    ),
    "NO_EXTRACTED_TACTICS_LIMITATION": (
        "route_inspector.reference_library.assessment.tactics",
        "NO_EXTRACTED_TACTICS_LIMITATION",
    ),
    "ROUTE_TACTIC_ASSESSMENT_SCHEMA_VERSION": (
        "route_inspector.reference_library.assessment.tactics",
        "ROUTE_TACTIC_ASSESSMENT_SCHEMA_VERSION",
    ),
    "RouteTacticAssessment": (
        "route_inspector.reference_library.assessment.tactics",
        "RouteTacticAssessment",
    ),
    "TacticCoverage": (
        "route_inspector.reference_library.assessment.tactics",
        "TacticCoverage",
    ),
    "TacticMatch": (
        "route_inspector.reference_library.assessment.tactics",
        "TacticMatch",
    ),
    "assess_tactic_occurrences": (
        "route_inspector.reference_library.assessment.tactics",
        "assess_tactic_occurrences",
    ),
    "RETRO_BLEU_BIGRAM_ASSESSMENT_SCHEMA_VERSION": (
        "route_inspector.reference_library.assessment.bigrams",
        "RETRO_BLEU_BIGRAM_ASSESSMENT_SCHEMA_VERSION",
    ),
    "RetroBleuBigramAssessment": (
        "route_inspector.reference_library.assessment.bigrams",
        "RetroBleuBigramAssessment",
    ),
    "RetroBleuBigramCoverage": (
        "route_inspector.reference_library.assessment.bigrams",
        "RetroBleuBigramCoverage",
    ),
    "RetroBleuBigramMatch": (
        "route_inspector.reference_library.assessment.bigrams",
        "RetroBleuBigramMatch",
    ),
    "assess_retro_bleu_bigrams": (
        "route_inspector.reference_library.assessment.bigrams",
        "assess_retro_bleu_bigrams",
    ),
    "RETRO_BLEU_BIGRAM_CATALOG_SCHEMA_VERSION": (
        "route_inspector.reference_library.bigram_catalog",
        "RETRO_BLEU_BIGRAM_CATALOG_SCHEMA_VERSION",
    ),
    "RETRO_BLEU_BIGRAM_IDENTITY_CONFIGURATION": (
        "route_inspector.reference_library.bigram_catalog",
        "RETRO_BLEU_BIGRAM_IDENTITY_CONFIGURATION",
    ),
    "RETRO_BLEU_BIGRAM_IDENTITY_VERSION": (
        "route_inspector.reference_library.bigram_catalog",
        "RETRO_BLEU_BIGRAM_IDENTITY_VERSION",
    ),
    "ReferenceBigramOccurrence": (
        "route_inspector.reference_library.bigram_catalog",
        "ReferenceBigramOccurrence",
    ),
    "RetroBleuBigramCatalog": (
        "route_inspector.reference_library.bigram_catalog",
        "RetroBleuBigramCatalog",
    ),
    "RetroBleuBigramIdentity": (
        "route_inspector.reference_library.bigram_catalog",
        "RetroBleuBigramIdentity",
    ),
    "RetroBleuBigramLibraryEntry": (
        "route_inspector.reference_library.bigram_catalog",
        "RetroBleuBigramLibraryEntry",
    ),
    "ReferenceTacticLibrary": (
        "route_inspector.reference_library.catalog",
        "ReferenceTacticLibrary",
    ),
    "TACTIC_CATALOG_SCHEMA_VERSION": (
        "route_inspector.reference_library.storage.contracts",
        "TACTIC_CATALOG_SCHEMA_VERSION",
    ),
    "rrseq_tactic_identity": (
        "route_inspector.reference_library.identity.tactics",
        "rrseq_tactic_identity",
    ),
    "rrsubtree_tactic_identity": (
        "route_inspector.reference_library.identity.tactics",
        "rrsubtree_tactic_identity",
    ),
    "REFERENCE_LIBRARY_FORMAT_VERSION": (
        "route_inspector.reference_library.storage.manifest",
        "REFERENCE_LIBRARY_FORMAT_VERSION",
    ),
    "REFERENCE_TACTIC_IDENTITY_CONFIGURATION": (
        "route_inspector.reference_library.storage.manifest",
        "REFERENCE_TACTIC_IDENTITY_CONFIGURATION",
    ),
    "ReferenceLibraryManifest": (
        "route_inspector.reference_library.storage.manifest",
        "ReferenceLibraryManifest",
    ),
    "TACTIC_IDENTITY_VERSION": (
        "route_inspector.reference_library.models",
        "TACTIC_IDENTITY_VERSION",
    ),
    "ReferenceRouteKey": (
        "route_inspector.reference_library.models",
        "ReferenceRouteKey",
    ),
    "TacticIdentity": ("route_inspector.reference_library.models", "TacticIdentity"),
    "TacticOccurrence": (
        "route_inspector.reference_library.models",
        "TacticOccurrence",
    ),
    "ProcessedRouteTactics": (
        "route_inspector.reference_library.build.processing",
        "ProcessedRouteTactics",
    ),
    "RouteTacticProcessingError": (
        "route_inspector.reference_library.build.processing",
        "RouteTacticProcessingError",
    ),
    "RouteTacticProcessor": (
        "route_inspector.reference_library.build.processing",
        "RouteTacticProcessor",
    ),
    "REFERENCE_PROCESSING_PROFILE_VERSION": (
        "route_inspector.reference_library.profile",
        "REFERENCE_PROCESSING_PROFILE_VERSION",
    ),
    "ReferenceProcessingProfile": (
        "route_inspector.reference_library.profile",
        "ReferenceProcessingProfile",
    ),
    "ReferenceProfileCompatibilityError": (
        "route_inspector.reference_library.profile",
        "ReferenceProfileCompatibilityError",
    ),
    "TacticLibraryEntry": (
        "route_inspector.reference_library.records",
        "TacticLibraryEntry",
    ),
    "ReferenceLibraryPublicationResult": (
        "route_inspector.reference_library.build.streaming",
        "ReferenceLibraryPublicationResult",
    ),
    "build_reference_library_to_directory": (
        "route_inspector.reference_library.build.streaming",
        "build_reference_library_to_directory",
    ),
    "PGStrategyReclassificationResult": (
        "route_inspector.reference_library.migration.pg_reclassification",
        "PGStrategyReclassificationResult",
    ),
    "reclassify_pg_strategy_library_to_directory": (
        "route_inspector.reference_library.migration.pg_reclassification",
        "reclassify_pg_strategy_library_to_directory",
    ),
}

__all__ = sorted(_EXPORTS)


def __getattr__(name):
    if name not in _EXPORTS:
        raise AttributeError(name)
    module, attribute = _EXPORTS[name]
    value = getattr(import_module(module), attribute)
    globals()[name] = value
    return value
