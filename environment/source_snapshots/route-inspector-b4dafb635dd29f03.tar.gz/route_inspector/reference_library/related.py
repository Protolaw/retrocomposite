"""Derived, exact core/extension browsing; never modifies a source library.

Rule tokens are equivalence classes established by RuleFamilyIndex, not hashes.
Shapes retain stored retrosynthetic direction and selected-edge gap widths.
"""

from __future__ import annotations

import json
import os
import sqlite3
import tempfile
from collections import Counter
from functools import lru_cache
from pathlib import Path

from route_inspector.rules.transformation import RuleFamilyIndex

INDEX_VERSION = 2


def compact_shape(kind, payload, families):
    nodes = []
    if kind.startswith("rrseq"):
        rules = payload["rule_sides"]
        gaps = (
            payload["inter_selection_gap_widths"]
            if kind.endswith("_gap")
            else [0] * (len(rules) - 1)
        )
        for i, rule in enumerate(rules):
            nodes.append(
                {
                    "rule": families.family(rule),
                    "parent": i - 1 if i else None,
                    "gap": gaps[i - 1] if i else 0,
                }
            )
    else:

        def visit(node, parent=None, gap=0):
            index = len(nodes)
            nodes.append(
                {
                    "rule": families.family(node["rule_sides"]),
                    "parent": parent,
                    "gap": gap,
                }
            )
            for edge in node["children"]:
                visit(edge["child"], index, edge["skipped_reaction_count"])

        visit(payload["root"])
    return nodes


def containment(core, extension, family, *, allow_equal=False):
    """Return one deterministic exact embedding (core index -> extension index).

    Children use exhaustive injective assignment, with memoized pair matches;
    equal-labelled siblings must not cause a greedy false negative.
    """
    if len(core) > len(extension) or (len(core) == len(extension) and not allow_equal):
        return None
    if family == "rrseq":
        for start in range(len(extension) - len(core) + 1):
            if all(
                node["rule"] == extension[start + i]["rule"]
                and (i == 0 or node["gap"] == extension[start + i]["gap"])
                for i, node in enumerate(core)
            ):
                return {i: start + i for i in range(len(core))}
        return None
    children = []
    for nodes in (core, extension):
        adjacency = [[] for _ in nodes]
        for i, node in enumerate(nodes):
            if node["parent"] is not None:
                adjacency[node["parent"]].append(i)
        children.append(adjacency)

    @lru_cache(None)
    def match(a, b):
        if core[a]["rule"] != extension[b]["rule"]:
            return None
        choices = []
        for child in children[0][a]:
            possible = [
                (other, result)
                for other in children[1][b]
                if core[child]["gap"] == extension[other]["gap"]
                and (result := match(child, other)) is not None
            ]
            if not possible:
                return None
            choices.append((child, possible))
        choices.sort(key=lambda row: (len(row[1]), row[0]))

        def assign(position, used, pairs):
            if position == len(choices):
                return ((a, b), *pairs)
            for other, mapping in choices[position][1]:
                if other not in used:
                    result = assign(position + 1, used | {other}, (*pairs, *mapping))
                    if result is not None:
                        return result
            return None

        return assign(0, set(), ())

    for root in range(len(extension)):
        if (result := match(0, root)) is not None:
            return dict(sorted(result))
    return None


class RelatedIndex:
    """Thread-owned disposable SQLite cache of compact shapes and query results."""

    def __init__(self, path):
        self.connection = sqlite3.connect(
            Path(path).resolve().as_uri() + "?mode=ro", uri=True
        )
        self.connection.row_factory = sqlite3.Row
        self._results = {}

    def close(self):
        self.connection.close()

    @staticmethod
    def build(path, entries, identity):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(
            dir=path.parent, prefix=".related-", suffix=".sqlite"
        )
        os.close(fd)
        connection = sqlite3.connect(temporary)
        try:
            connection.executescript("""
                CREATE TABLE metadata (identity TEXT NOT NULL);
                CREATE TABLE entries (
                    entry_id TEXT PRIMARY KEY, kind TEXT, family TEXT, size INTEGER,
                    route_count INTEGER, occurrence_count INTEGER, shape TEXT, reason TEXT);
                CREATE TABLE membership (entry_id TEXT, rule INTEGER, amount INTEGER,
                    PRIMARY KEY (entry_id, rule));
                CREATE INDEX by_rule ON membership(rule, entry_id);
                CREATE INDEX by_size ON entries(size);
            """)
            connection.execute("INSERT INTO metadata VALUES (?)", (identity,))
            families = RuleFamilyIndex()
            for entry in entries:
                kind = entry["identity"]["kind"]
                payload = entry["identity"]["equivalence_payload"]
                reason = None
                try:
                    shape = compact_shape(kind, payload, families)
                except KeyError:
                    shape = []
                    reason = "This legacy entry lacks exact transformation sides or recorded gap widths. Rebuild its reference library to explore related tactics."
                connection.execute(
                    "INSERT INTO entries VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        entry["entry_id"],
                        kind,
                        kind.split("_")[0],
                        len(shape),
                        entry["route_count"],
                        entry["occurrence_count"],
                        json.dumps(shape),
                        reason,
                    ),
                )
                connection.executemany(
                    "INSERT INTO membership VALUES (?, ?, ?)",
                    [
                        (entry["entry_id"], rule, amount)
                        for rule, amount in Counter(n["rule"] for n in shape).items()
                    ],
                )
            connection.commit()
            if connection.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("Related-tactic index failed integrity check")
            connection.close()
            os.replace(temporary, path)
        finally:
            connection.close()
            Path(temporary).unlink(missing_ok=True)

    def valid(self, identity):
        return (
            self.connection.execute("PRAGMA quick_check").fetchone()[0] == "ok"
            and self.connection.execute("SELECT identity FROM metadata").fetchone()[0]
            == identity
            and self.connection.execute("SELECT count(*) FROM entries").fetchone()[0]
            >= 0
            and self.connection.execute("SELECT count(*) FROM membership").fetchone()[0]
            >= 0
        )

    def entry(self, entry_id):
        row = self.connection.execute(
            "SELECT * FROM entries WHERE entry_id=?", (entry_id,)
        ).fetchone()
        if row is None:
            raise KeyError(entry_id)
        result = dict(row)
        result["shape"] = json.loads(result["shape"])
        return result

    def relations(self, entry_id, direction):
        if direction not in {"extensions", "cores"}:
            raise ValueError("Choose extensions or cores")
        key = (entry_id, direction)
        if key in self._results:
            return self._results[key]
        selected = self.entry(entry_id)
        if selected["reason"]:
            raise ValueError(selected["reason"])
        # Exact multiset containment prunes both directions before graph matching.
        small, large = ("s", "e") if direction == "extensions" else ("e", "s")
        operator = ">" if direction == "extensions" else "<"
        candidates = self.connection.execute(
            f"""
            SELECT e.* FROM entries e, entries s
            WHERE s.entry_id=? AND e.size {operator} s.size
              AND e.reason IS NULL
              AND NOT EXISTS (
                SELECT 1 FROM membership a WHERE a.entry_id={small}.entry_id
                AND NOT EXISTS (SELECT 1 FROM membership b
                    WHERE b.entry_id={large}.entry_id AND b.rule=a.rule AND b.amount>=a.amount))
            ORDER BY abs(e.size-s.size), e.route_count DESC, e.entry_id
        """,
            (entry_id,),
        )
        results = []
        for row in candidates:
            candidate = dict(row)
            candidate["shape"] = json.loads(candidate["shape"])
            core, extension = (
                (selected, candidate)
                if direction == "extensions"
                else (candidate, selected)
            )
            # A sequence is a directed path, so it can be an exact core of a
            # branching subtree. Never flatten a subtree to compare its nodes
            # as a sequence: that would connect siblings or erase branching.
            family = (
                "rrseq"
                if core["family"] == extension["family"] == "rrseq"
                else "rrsubtree"
            )
            mapping = containment(core["shape"], extension["shape"], family)
            if mapping is not None:
                results.append(
                    {
                        **{
                            k: candidate[k]
                            for k in (
                                "entry_id",
                                "kind",
                                "size",
                                "route_count",
                                "occurrence_count",
                            )
                        },
                        "difference": abs(candidate["size"] - selected["size"]),
                        "core_entry_id": core["entry_id"],
                        "extension_entry_id": extension["entry_id"],
                        "mapping": [[a, b] for a, b in mapping.items()],
                    }
                )
        # Bound the session cache without truncating any individual search.
        if len(self._results) >= 128:
            self._results.pop(next(iter(self._results)))
        self._results[key] = tuple(results)
        return self._results[key]


def library_entries(library):
    """Stream entry payloads; do not materialize occurrence chemistry."""
    if library._connection is not None:
        for row in library._connection.execute(
            "SELECT entry_json FROM entries ORDER BY entry_id"
        ):
            yield json.loads(row[0])
    else:
        for entry in sorted(library.entries(), key=lambda e: e.entry_id):
            yield entry.to_dict()
