"""Resolved scientific settings for route processor construction."""

from dataclasses import dataclass
from pathlib import Path


@dataclass
class ProcessorSettings:
    config: Path | None = None
    input_state: str | None = None
    protection_config: Path | None = None
    source_id_adapter: str | None = None
    rrseq_min_length: int | None = None
    rrseq_max_length: int | None = None
    rrsubtree_min_size: int | None = None
    rrsubtree_max_size: int | None = None
    rrsubtree_max_candidates_per_route: int | None = None
    classify_gap_factorability: bool | None = None
    factorability_context_radius: int | None = None
    factorability_max_replay_outcomes: int | None = None
    factorability_require_unique_replay: bool | None = None
