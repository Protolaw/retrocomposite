"""Reloadable, exact-equivalence catalog for reference tactic occurrences."""

from __future__ import annotations

import json
import sqlite3
from collections import defaultdict
from collections.abc import Iterable, Iterator, Mapping, Sequence
from pathlib import Path
from typing import Any

from route_inspector import __version__
from route_inspector.infrastructure.runtime import git_commit_hash
from route_inspector.reference_library.build.aggregation import (
    _build_entries,
    _deduplicate_occurrences,
    _library_id,
    _library_statistics,
    _reference_corpora_from_occurrences,
    _validate_observed_route_corpora,
    _validate_occurrence_corpora,
)
from route_inspector.reference_library.identity.certificates import _identity_sort_key
from route_inspector.reference_library.models import (
    TACTIC_IDENTITY_VERSION,
    ReferenceRouteKey,
    TacticIdentity,
    TacticOccurrence,
)
from route_inspector.reference_library.profile import (
    ReferenceProcessingProfile,
)
from route_inspector.reference_library.records import (
    TacticLibraryEntry,
    _collision_ordinal,
    _detached_json,
)
from route_inspector.reference_library.storage.artifacts import _json_digest
from route_inspector.reference_library.storage.contracts import (
    _ARTIFACT_PATHS,
    _LAZY_ENTRY_CACHE_SIZE,
    _LAZY_OWNERSHIP_CACHE_SIZE,
    TACTIC_CATALOG_SCHEMA_VERSION,
    TACTIC_KINDS,
)
from route_inspector.reference_library.storage.manifest import (
    REFERENCE_LIBRARY_FORMAT_VERSION,
    ReferenceLibraryManifest,
    compact_supplementary_evidence,
    normalize_reference_corpora,
)
from route_inspector.reference_library.storage.readers import LibraryReaders
from route_inspector.reference_library.storage.writers import LibraryWriters


class ReferenceTacticLibrary(LibraryReaders, LibraryWriters):
    """Exact tactic catalog with optional lazy SQLite-backed provenance."""

    def __init__(
        self,
        *,
        manifest: ReferenceLibraryManifest,
        entries: Sequence[TacticLibraryEntry] | None,
        occurrences: Sequence[TacticOccurrence] | None = None,
        entry_by_occurrence: Mapping[str, str] | None = None,
        directory: Path | None = None,
        connection: sqlite3.Connection | None = None,
        retro_bleu_bigram_catalog: Any | None = None,
        pg_strategy_library: Any | None = None,
    ) -> None:
        self.manifest = manifest
        self._entries = (
            None
            if entries is None
            else tuple(sorted(entries, key=lambda entry: entry.entry_id))
        )
        self._entry_by_id = {entry.entry_id: entry for entry in (self._entries or ())}
        if self._entries is not None and len(self._entry_by_id) != len(self._entries):
            raise ValueError("duplicate tactic-library entry IDs")
        self._buckets: dict[tuple[str, int, str], tuple[TacticLibraryEntry, ...]] = {}
        mutable_buckets: dict[tuple[str, int, str], list[TacticLibraryEntry]] = (
            defaultdict(list)
        )
        for entry in self._entries or ():
            identity = entry.identity
            mutable_buckets[
                (identity.kind, identity.identity_version, identity.lookup_key)
            ].append(entry)
        if self._entries is not None:
            self._buckets = {
                key: tuple(sorted(values, key=lambda item: item.entry_id))
                for key, values in mutable_buckets.items()
            }
        self._occurrences = (
            None
            if occurrences is None
            else {item.reference_occurrence_id: item for item in occurrences}
        )
        self._entry_by_occurrence = dict(entry_by_occurrence or {})
        self.directory = directory
        self._connection = connection
        self._ownership_equivalence: dict[tuple[str, str], bool] = {}
        self.retro_bleu_bigram_catalog = retro_bleu_bigram_catalog
        self.pg_strategy_library = pg_strategy_library

    @classmethod
    def from_occurrences(
        cls,
        occurrences: Iterable[TacticOccurrence],
        *,
        processing_profile: ReferenceProcessingProfile,
        reference_corpora: Sequence[Mapping[str, Any]] | None = None,
        route_inspector_commit: str | None = None,
        statistics_extra: Mapping[str, Any] | None = None,
        retro_bleu_bigram_catalog: Any | None = None,
        supplementary_evidence: Mapping[str, Any] | None = None,
        pg_strategy_library: Any | None = None,
        tactic_identity_version: int | None = None,
    ) -> "ReferenceTacticLibrary":
        """Aggregate exact occurrences without recomputing chemistry."""

        normalized = _deduplicate_occurrences(occurrences)
        entries, entry_by_occurrence = _build_entries(normalized)
        raw_corpora = (
            tuple(reference_corpora)
            if reference_corpora is not None
            else _reference_corpora_from_occurrences(normalized)
        )
        if not raw_corpora:
            raise ValueError(
                "reference_corpora is required when no tactic occurrences exist"
            )
        corpora = normalize_reference_corpora(raw_corpora)
        _validate_occurrence_corpora(normalized, corpora)
        statistics = _library_statistics(entries, normalized)
        extra_statistics = _detached_json(
            statistics_extra or {},
            label="statistics_extra",
        )
        if not isinstance(extra_statistics, dict):
            raise ValueError("statistics_extra must be a JSON object")
        conflicting_statistics = sorted(set(statistics) & set(extra_statistics))
        if conflicting_statistics:
            raise ValueError(
                "statistics_extra cannot overwrite core catalog statistics: "
                f"{conflicting_statistics}"
            )
        statistics.update(extra_statistics)
        evidence = _detached_json(
            supplementary_evidence or {},
            label="supplementary_evidence",
        )
        if not isinstance(evidence, dict):
            raise ValueError("supplementary_evidence must be a JSON object")
        if retro_bleu_bigram_catalog is None:
            if evidence:
                raise ValueError(
                    "supplementary evidence requires a Retro-BLEU bigram catalog"
                )
        else:
            from route_inspector.reference_library.bigram_catalog import (
                RetroBleuBigramCatalog,
            )

            if not isinstance(retro_bleu_bigram_catalog, RetroBleuBigramCatalog):
                raise TypeError(
                    "retro_bleu_bigram_catalog must be RetroBleuBigramCatalog"
                )
            recorded = evidence.get("retro_bleu_bigrams")
            if not isinstance(recorded, Mapping):
                raise ValueError(
                    "supplementary evidence requires retro_bleu_bigrams metadata"
                )
            for key, expected in retro_bleu_bigram_catalog._verification_summary(
                recorded
            ).items():
                if recorded.get(key) != expected:
                    raise ValueError(
                        f"supplementary bigram metadata disagrees for {key!r}"
                    )
        components: dict[str, dict[str, Any]] = {}
        if pg_strategy_library is not None:
            from route_inspector.protection.strategies.catalog import (
                ReferencePGStrategyLibrary,
            )

            if not isinstance(pg_strategy_library, ReferencePGStrategyLibrary):
                raise TypeError(
                    "pg_strategy_library must be ReferencePGStrategyLibrary"
                )
            if tuple(pg_strategy_library.manifest.reference_corpora) != tuple(corpora):
                raise ValueError(
                    "PG strategy and tactic libraries require identical Reference corpora"
                )
            components["pg_strategy"] = {
                "library_id": pg_strategy_library.library_id,
                "manifest_path": _ARTIFACT_PATHS["pg_strategy_manifest"],
                "library_format_version": pg_strategy_library.manifest.library_format_version,
                "catalog_schema_version": pg_strategy_library.manifest.catalog_schema_version,
            }
        identity_versions = {
            occurrence.identity.identity_version for occurrence in normalized
        }
        if len(identity_versions) > 1:
            raise ValueError(
                "one Reference library cannot mix tactic identity versions"
            )
        identity_version = (
            next(iter(identity_versions))
            if identity_versions
            else tactic_identity_version or TACTIC_IDENTITY_VERSION
        )
        if (
            tactic_identity_version is not None
            and identity_version != tactic_identity_version
        ):
            raise ValueError(
                "Requested tactic identity version differs from occurrences"
            )
        if identity_version not in {1, 2, 3, 4}:
            raise ValueError("Unsupported tactic identity version")
        if identity_version == 4:
            from route_inspector.reference_library.storage.manifest import (
                WIDTH_IDENTITY_CONFIGURATION,
            )

            identity_configuration = WIDTH_IDENTITY_CONFIGURATION
        elif identity_version == 3:
            from route_inspector.reference_library.storage.manifest import (
                TRANSFORMATION_IDENTITY_CONFIGURATION,
            )

            identity_configuration = TRANSFORMATION_IDENTITY_CONFIGURATION
        elif identity_version == 1:
            from route_inspector.reference_library.storage.manifest import (
                LEGACY_REFERENCE_TACTIC_IDENTITY_CONFIGURATION,
            )

            identity_configuration = LEGACY_REFERENCE_TACTIC_IDENTITY_CONFIGURATION
        else:
            from route_inspector.reference_library.storage.manifest import (
                REFERENCE_TACTIC_IDENTITY_CONFIGURATION,
            )

            identity_configuration = REFERENCE_TACTIC_IDENTITY_CONFIGURATION
        manifest = ReferenceLibraryManifest(
            library_id=_library_id(processing_profile, entries, normalized, corpora),
            library_format_version=REFERENCE_LIBRARY_FORMAT_VERSION,
            identity_configuration=identity_configuration,
            processing_profile=processing_profile,
            reference_corpora=tuple(corpora),
            statistics=statistics,
            supplementary_evidence=compact_supplementary_evidence(evidence),
            artifacts={},
            route_inspector_version=__version__,
            route_inspector_commit=(
                git_commit_hash()
                if route_inspector_commit is None
                else str(route_inspector_commit)
            ),
            catalog_schema_version=TACTIC_CATALOG_SCHEMA_VERSION,
            components=components,
        )
        return cls(
            manifest=manifest,
            entries=entries,
            occurrences=normalized,
            entry_by_occurrence=entry_by_occurrence,
            retro_bleu_bigram_catalog=retro_bleu_bigram_catalog,
            pg_strategy_library=pg_strategy_library,
        )

    @property
    def processing_profile(self) -> ReferenceProcessingProfile:
        return self.manifest.processing_profile

    @property
    def tactic_identity_version(self) -> int:
        """Return the identity contract selected by the persisted manifest."""

        return int(self.manifest.identity_configuration["tactic_identity_version"])

    @property
    def library_id(self) -> str:
        return self.manifest.library_id

    def __enter__(self) -> "ReferenceTacticLibrary":
        return self

    def __exit__(self, *_args: Any) -> None:
        self.close()

    def close(self) -> None:
        if self._connection is not None:
            self._connection.close()
            self._connection = None
        if self.pg_strategy_library is not None:
            self.pg_strategy_library.close()

    def routes_without_tactics(
        self, *, kinds: Sequence[str] = ("rrseq_cons", "rrseq_gap")
    ) -> tuple[ReferenceRouteKey, ...]:
        """Return processed routes having none of the requested tactic kinds.

        The complete corpus roster is authoritative, including routes with no
        occurrences. An old library without that roster cannot answer this query.
        Build workflows abort on extraction errors; absence is relative to their
        recorded processing profile, never a claim about unprocessed routes.
        """
        if isinstance(kinds, str) or not kinds or set(kinds) - set(TACTIC_KINDS):
            raise ValueError(
                "kinds must be a non-empty sequence of supported tactic kinds"
            )
        requested = frozenset(kinds)
        roster: set[ReferenceRouteKey] = set()
        for corpus in self.manifest.reference_corpora:
            if "route_ids" not in corpus:
                raise ValueError(
                    "Cannot derive route cohort: library lacks a complete processed "
                    "route_ids inventory; occurrence absence alone is insufficient"
                )
            roster.update(
                ReferenceRouteKey(
                    corpus["dataset_id"], corpus["source_identity"], route_id
                )
                for route_id in corpus["route_ids"]
            )
        observed: dict[tuple[str, str], set[str]] = defaultdict(set)
        excluded: set[ReferenceRouteKey] = set()
        counts: dict[str, int] = defaultdict(int)
        if self._connection is not None:
            rows = self._connection.execute(
                "SELECT dataset_id, source_identity, route_id, tactic_kind, COUNT(*) AS n "
                "FROM occurrences GROUP BY dataset_id, source_identity, route_id, tactic_kind"
            )
            memberships = (
                (
                    ReferenceRouteKey(
                        row["dataset_id"], row["source_identity"], row["route_id"]
                    ),
                    row["tactic_kind"],
                    row["n"],
                )
                for row in rows
            )
        else:
            memberships = (
                (occurrence.route, occurrence.identity.kind, 1)
                for occurrence in self.iter_occurrences()
            )
        for route, kind, count in memberships:
            observed[(route.dataset_id, route.source_identity)].add(route.route_id)
            counts[kind] += count
            if kind in requested:
                excluded.add(route)
        _validate_observed_route_corpora(observed, self.manifest.reference_corpora)
        expected = self.manifest.statistics["occurrences_by_kind"]
        if any(counts[kind] != expected.get(kind, 0) for kind in TACTIC_KINDS):
            raise ValueError("Route cohort occurrence counts disagree with manifest")
        return tuple(sorted(roster - excluded))

    def entries(self, kind: str | None = None) -> tuple[TacticLibraryEntry, ...]:
        if kind is not None and kind not in TACTIC_KINDS:
            raise ValueError(f"unsupported tactic kind: {kind!r}")
        if self._entries is not None:
            if kind is None:
                return self._entries
            return tuple(entry for entry in self._entries if entry.kind == kind)
        if self._connection is None:
            raise RuntimeError("reference tactic library is closed")
        sql = "SELECT * FROM entries"
        parameters: tuple[Any, ...] = ()
        if kind is not None:
            sql += " WHERE tactic_kind = ?"
            parameters = (kind,)
        sql += " ORDER BY entry_id"
        loaded = tuple(
            self._entry_from_row(row)
            for row in self._connection.execute(sql, parameters)
        )
        return loaded

    def _entry_from_row(self, row: sqlite3.Row) -> TacticLibraryEntry:
        entry_id = str(row["entry_id"])
        cached = self._entry_by_id.get(entry_id)
        if cached is not None:
            if self._entries is None:
                self._entry_by_id.pop(entry_id)
                self._entry_by_id[entry_id] = cached
            return cached
        raw_entry = json.loads(row["entry_json"])
        if not isinstance(raw_entry, Mapping):
            raise ValueError("catalog entry_json must contain an object")
        entry = TacticLibraryEntry.from_dict(raw_entry)
        expected = (
            entry.entry_id,
            entry.kind,
            entry.identity.identity_version,
            entry.lookup_key,
            _collision_ordinal(entry.entry_id),
            entry.occurrence_count,
            entry.route_count,
            entry.representative_occurrence_id,
        )
        actual = tuple(
            row[name]
            for name in (
                "entry_id",
                "tactic_kind",
                "identity_version",
                "lookup_key",
                "collision_ordinal",
                "occurrence_count",
                "route_count",
                "representative_occurrence_id",
            )
        )
        if expected != actual:
            raise ValueError(f"catalog entry columns disagree with payload: {entry_id}")
        if self._entries is None and len(self._entry_by_id) >= _LAZY_ENTRY_CACHE_SIZE:
            self._entry_by_id.pop(next(iter(self._entry_by_id)))
        self._entry_by_id[entry_id] = entry
        return entry

    def get_entry(self, entry_id: str) -> TacticLibraryEntry:
        normalized = str(entry_id)
        cached = self._entry_by_id.get(normalized)
        if cached is not None:
            return cached
        if self._connection is None:
            raise KeyError(f"unknown tactic-library entry: {normalized}")
        row = self._connection.execute(
            "SELECT * FROM entries WHERE entry_id = ?",
            (normalized,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown tactic-library entry: {normalized}")
        return self._entry_from_row(row)

    def lookup(self, identity: TacticIdentity) -> TacticLibraryEntry | None:
        """Return an exact match; lookup-key equality alone is never sufficient."""

        if not isinstance(identity, TacticIdentity):
            raise TypeError("identity must be a TacticIdentity")
        if self._entries is None:
            if self._connection is None:
                raise RuntimeError("reference tactic library is closed")
            candidates = tuple(
                self._entry_from_row(row)
                for row in self._connection.execute(
                    """SELECT * FROM entries
                       WHERE tactic_kind = ? AND identity_version = ?
                         AND lookup_key = ?
                       ORDER BY collision_ordinal""",
                    (
                        identity.kind,
                        identity.identity_version,
                        identity.lookup_key,
                    ),
                )
            )
        else:
            candidates = self._buckets.get(
                (identity.kind, identity.identity_version, identity.lookup_key),
                (),
            )
        matches = [
            entry for entry in candidates if identity.equivalent_to(entry.identity)
        ]
        if len(matches) > 1:
            raise RuntimeError(
                "one identity matched multiple exact collision-bucket entries"
            )
        return matches[0] if matches else None

    def _occurrence_from_row(self, row: sqlite3.Row) -> TacticOccurrence:
        raw_occurrence = json.loads(row["occurrence_json"])
        if not isinstance(raw_occurrence, Mapping):
            raise ValueError("catalog occurrence_json must contain an object")
        occurrence = TacticOccurrence.from_dict(raw_occurrence)
        expected = (
            occurrence.reference_occurrence_id,
            occurrence.occurrence_id,
            occurrence.identity.kind,
            occurrence.route.dataset_id,
            occurrence.route.source_identity,
            occurrence.route.route_id,
            occurrence.native_schema_version,
            _json_digest(occurrence.to_dict()),
        )
        actual = tuple(
            row[name]
            for name in (
                "reference_occurrence_id",
                "native_occurrence_id",
                "tactic_kind",
                "dataset_id",
                "source_identity",
                "route_id",
                "native_schema_version",
                "content_sha256",
            )
        )
        if expected != actual:
            raise ValueError(
                "catalog occurrence columns disagree with occurrence_json: "
                f"{occurrence.reference_occurrence_id}"
            )
        entry_id = str(row["entry_id"])
        ownership_key = (entry_id, _identity_sort_key(occurrence.identity))
        owned = self._ownership_equivalence.get(ownership_key)
        if owned is None:
            owned = occurrence.identity.equivalent_to(self.get_entry(entry_id).identity)
            if (
                self._occurrences is None
                and len(self._ownership_equivalence) >= _LAZY_OWNERSHIP_CACHE_SIZE
            ):
                self._ownership_equivalence.pop(next(iter(self._ownership_equivalence)))
            self._ownership_equivalence[ownership_key] = owned
        if not owned:
            raise ValueError(
                "catalog occurrence is not exactly owned by its entry: "
                f"{occurrence.reference_occurrence_id}"
            )
        return occurrence

    def _iter_occurrence_rows(
        self,
        entry_id: str | None = None,
        *,
        kind: str | None = None,
        route_id: str | None = None,
        dataset_id: str | None = None,
        source_identity: str | None = None,
    ) -> Iterator[tuple[str, TacticOccurrence]]:
        if kind is not None and kind not in TACTIC_KINDS:
            raise ValueError(f"unsupported tactic kind: {kind!r}")
        if entry_id is not None:
            self.get_entry(entry_id)
        if self._occurrences is not None:
            for occurrence_id in sorted(self._occurrences):
                current_entry_id = self._entry_by_occurrence[occurrence_id]
                occurrence = self._occurrences[occurrence_id]
                if entry_id is not None and current_entry_id != entry_id:
                    continue
                if kind is not None and occurrence.identity.kind != kind:
                    continue
                route = occurrence.route
                if route_id is not None and route.route_id != str(route_id):
                    continue
                if dataset_id is not None and route.dataset_id != str(dataset_id):
                    continue
                if source_identity is not None and (
                    route.source_identity != str(source_identity)
                ):
                    continue
                yield current_entry_id, occurrence
            return
        if self._connection is None:
            raise RuntimeError("reference tactic library is closed")
        sql = "SELECT * FROM occurrences"
        predicates: list[str] = []
        parameters: list[Any] = []
        if entry_id is not None:
            predicates.append("entry_id = ?")
            parameters.append(entry_id)
        if kind is not None:
            predicates.append("tactic_kind = ?")
            parameters.append(kind)
        for column, value in (
            ("route_id", route_id),
            ("dataset_id", dataset_id),
            ("source_identity", source_identity),
        ):
            if value is not None:
                predicates.append(f"{column} = ?")
                parameters.append(str(value))
        if predicates:
            sql += " WHERE " + " AND ".join(predicates)
        sql += " ORDER BY reference_occurrence_id"
        for row in self._connection.execute(sql, tuple(parameters)):
            yield str(row["entry_id"]), self._occurrence_from_row(row)

    def iter_occurrences(
        self,
        entry_id: str | None = None,
        *,
        kind: str | None = None,
        route_id: str | None = None,
        dataset_id: str | None = None,
        source_identity: str | None = None,
    ) -> Iterator[TacticOccurrence]:
        """Yield lazily, using persisted entry/route indexes when supplied."""

        for _entry_id, occurrence in self._iter_occurrence_rows(
            entry_id,
            kind=kind,
            route_id=route_id,
            dataset_id=dataset_id,
            source_identity=source_identity,
        ):
            yield occurrence

    def get_occurrence(self, reference_occurrence_id: str) -> TacticOccurrence:
        """Return one occurrence through its primary-key index."""

        normalized = str(reference_occurrence_id)
        if self._occurrences is not None:
            try:
                return self._occurrences[normalized]
            except KeyError as exc:
                raise KeyError(f"unknown Reference occurrence: {normalized}") from exc
        if self._connection is None:
            raise RuntimeError("reference tactic library is closed")
        row = self._connection.execute(
            "SELECT * FROM occurrences WHERE reference_occurrence_id = ?",
            (normalized,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown Reference occurrence: {normalized}")
        return self._occurrence_from_row(row)

    def entry_id_for_occurrence(self, reference_occurrence_id: str) -> str:
        """Return indexed exact-entry ownership for one Reference occurrence."""

        normalized = str(reference_occurrence_id)
        if self._occurrences is not None:
            try:
                return self._entry_by_occurrence[normalized]
            except KeyError as exc:
                raise KeyError(f"unknown Reference occurrence: {normalized}") from exc
        if self._connection is None:
            raise RuntimeError("reference tactic library is closed")
        row = self._connection.execute(
            "SELECT entry_id FROM occurrences WHERE reference_occurrence_id = ?",
            (normalized,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown Reference occurrence: {normalized}")
        return str(row["entry_id"])

    def occurrences_for_entry(
        self,
        entry_id: str,
    ) -> tuple[TacticOccurrence, ...]:
        return tuple(self.iter_occurrences(entry_id))

    def occurrence_examples_for_entry(
        self,
        entry_id: str,
        *,
        limit: int = 2,
        distinct_routes: bool = True,
    ) -> tuple[TacticOccurrence, ...]:
        """Return deterministic, indexed examples without scanning provenance."""

        normalized_limit = int(limit)
        if normalized_limit < 0:
            raise ValueError("limit must be non-negative")
        if normalized_limit == 0:
            return ()
        examples: list[TacticOccurrence] = []
        observed_routes: set[ReferenceRouteKey] = set()
        for occurrence in self.iter_occurrences(str(entry_id)):
            if distinct_routes and occurrence.route in observed_routes:
                continue
            examples.append(occurrence)
            observed_routes.add(occurrence.route)
            if len(examples) >= normalized_limit:
                break
        return tuple(examples)

    def occurrence_statistics(self, kind: str | None = None) -> dict[str, int]:
        """Return compact occurrence and distinct-route counts."""

        if kind is not None and kind not in TACTIC_KINDS:
            raise ValueError(f"unsupported tactic kind: {kind!r}")
        if self._occurrences is not None:
            selected = tuple(
                occurrence
                for occurrence in self._occurrences.values()
                if kind is None or occurrence.identity.kind == kind
            )
            return {
                "occurrence_count": len(selected),
                "route_count": len({occurrence.route for occurrence in selected}),
            }
        if self._connection is None:
            raise RuntimeError("reference tactic library is closed")
        predicate = "" if kind is None else " WHERE tactic_kind = ?"
        parameters: tuple[Any, ...] = () if kind is None else (kind,)
        occurrence_count = int(
            self._connection.execute(
                "SELECT COUNT(*) FROM occurrences" + predicate,
                parameters,
            ).fetchone()[0]
        )
        route_count = int(
            self._connection.execute(
                """SELECT COUNT(*) FROM (
                       SELECT DISTINCT dataset_id, source_identity, route_id
                       FROM occurrences"""
                + predicate
                + ")",
                parameters,
            ).fetchone()[0]
        )
        return {
            "occurrence_count": occurrence_count,
            "route_count": route_count,
        }

    def assert_compatible(self, profile: ReferenceProcessingProfile) -> None:
        self.processing_profile.assert_compatible(profile)


__all__ = [
    "TACTIC_CATALOG_SCHEMA_VERSION",
    "TACTIC_KINDS",
    "ReferenceTacticLibrary",
    "TacticLibraryEntry",
]
