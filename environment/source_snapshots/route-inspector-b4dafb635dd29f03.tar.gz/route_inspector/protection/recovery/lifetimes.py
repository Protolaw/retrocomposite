"""Enumerate contiguous PG lifetimes around an exact evidence window."""

from route_inspector.protection.recovery.generation import sites
from route_inspector.protection.recovery.trees import at, ids, mol

LIFETIME_POLICY = {
    "version": 2,
    "scope": "contiguous_supersets_of_matched_window_on_same_mapped_branch",
    "ordering": "matched_windows_first_then_shortest_extension_in_evidence_order",
    "validation": "persistent_free_group_and_endpoint_rules; full_interval_replay_if_anchor_changes",
    "original_evidence": "evaluation_only",
}


def extensions(
    query,
    paths,
    site,
    reference,
    event,
    *,
    steps,
    maximum=8,
    site_limit=256,
    generalized=True,
    reverse_rule=True,
    site_cache=None,
    mask=None,
):
    """Return additional lifetimes and whether a valid span exceeded a bound.

    Tree ancestry fixes the forward continuation. Backward continuation must
    carry the same mapped anchors on exactly one input; never join siblings.
    Discovery is repeated at the earlier substrate to retain the reference
    functional-group core. Anchor changes require executable interval validation.
    """
    paths = tuple(paths)
    anchors = {site[1][n] for n in event["protected_atom_ids"]}
    backwards, current = [], site[0]
    # Look one step beyond the bound so truncation is observable.
    while len(backwards) <= maximum:
        reactions = at(query, current).get("children", [])
        if len(reactions) != 1 or reactions[0]["type"] != "reaction":
            break
        path = current + (0,)
        if path not in steps:
            break
        inputs = [
            path + (i,)
            for i, child in enumerate(reactions[0]["children"])
            if anchors <= ids(mol(child["smiles"]))
        ]
        if len(inputs) != 1:
            break
        backwards.append(path)
        current = inputs[0]
    forwards, current = [], paths[-1][:-2]
    while current and len(forwards) <= maximum:
        if current not in steps:
            break
        forwards.append(current)
        current = current[:-2]
    results, truncated = [], False
    for extra in range(1, maximum + 2):
        for before in range(
            max(0, extra - len(forwards)), min(extra, len(backwards)) + 1
        ):
            after = extra - before
            span = tuple(reversed(backwards[:before])) + paths + tuple(forwards[:after])
            candidates, capped = sites(
                query,
                span,
                reference,
                event,
                limit=site_limit,
                generalized=generalized,
                reverse_rule=reverse_rule,
                cache=site_cache,
                mask=mask,
            )
            truncated |= capped
            for candidate in candidates:
                if any(
                    candidate[1].get(n) != site[1][n]
                    for n in event["protected_atom_ids"]
                ):
                    continue
                if extra > maximum:
                    truncated = True
                else:
                    results.append((span, candidate))
    return results, truncated
