"""Native Chython site queries with boundary-independent core constraints."""

from dataclasses import dataclass
from itertools import islice

from chython import QueryContainer
from chython.periodictable import QueryElement

from route_inspector.protection.recovery.molecules import mol


@dataclass
class SiteQuery:
    pattern: object
    carbon_neighbors: frozenset

    def copy(self):
        return SiteQuery(self.pattern.copy(), self.carbon_neighbors)

    def get_mapping(self, molecule, *, limit=None):
        matches = (
            mapping
            for mapping in self.pattern.get_mapping(molecule, automorphism_filter=False)
            if all(
                any(
                    molecule.atom(m).atomic_number == 6
                    for m in molecule._bonds[mapping[n]]
                )
                for n in self.carbon_neighbors
            )
        )
        return matches if limit is None else islice(matches, limit)


def build_query(
    text, additions, site_atoms, generalized, protected_text, endpoint_context
):
    molecule = mol(text)
    for anchor, restored, element, order in additions:
        candidates = [
            n
            for n, bond in molecule._bonds[anchor].items()
            if molecule.atom(n).atomic_symbol == element
            and len(molecule._bonds[n]) == 1
            and int(bond) == order
        ]
        if len(candidates) != 1:
            raise ValueError("Ambiguous reference free-site restoration")
        molecule.remap({candidates[0]: restored})
    core = set(site_atoms)
    if generalized:
        core.update(n for _, n, _, _ in additions)
        core.update(
            m
            for n in tuple(core)
            for m, bond in molecule._bonds[n].items()
            if int(bond) in (2, 3)
        )
    selected = core & set(molecule)
    if not generalized:
        selected |= {m for n in tuple(selected) for m in molecule._bonds[n]}
    protected = mol(protected_text)
    query = QueryContainer("")
    carbon_neighbors = set()
    for n in molecule:
        if n not in selected:
            continue
        atom = molecule.atom(n)
        h = atom.implicit_hydrogens or 0
        constraints = {"implicit_hydrogens": h}
        if n in core:
            if generalized:
                consumed = (
                    max(0, h - (protected.atom(n).implicit_hydrogens or 0))
                    if protected.has_atom(n)
                    else 0
                )
                constraints = {"implicit_hydrogens": tuple(range(consumed, 15))}
                if (
                    endpoint_context
                    and atom.atomic_number == 8
                    and any(
                        molecule.atom(m).atomic_number == 6 for m in molecule._bonds[n]
                    )
                ):
                    carbon_neighbors.add(n)
            else:
                constraints["neighbors"] = len(molecule._bonds[n])
        query.add_atom(
            QueryElement.from_symbol(atom.atomic_symbol)(
                isotope=None if n in core else atom.isotope,
                charge=atom.charge,
                hybridization=4 if atom.hybridization == 4 else (1, 2, 3),
                **constraints,
            ),
            n,
        )
    for n, m, bond in molecule.bonds():
        if n in selected and m in selected:
            query.add_bond(n, m, int(bond))
    return SiteQuery(query, frozenset(carbon_neighbors))
