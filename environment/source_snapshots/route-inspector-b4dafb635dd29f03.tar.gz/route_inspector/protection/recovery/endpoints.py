"""Paired, pure reference endpoints independent of retrieved lifespan evidence."""

from collections import defaultdict

from route_inspector.protection.recovery.artifacts import stable_id
from route_inspector.protection.recovery.generation import (
    _substrate_roles,
    source_parts,
)
from route_inspector.protection.recovery.molecules import marked_fragment
from route_inspector.protection.recovery.selectivity import forward_rule
from route_inspector.protection.recovery.stripping import describe_mask
from route_inspector.protection.recovery.trees import fingerprint, mol

ENDPOINT_POLICY = {
    "version": 2,
    "graph_backend": "chython-synplan",
    "scope": "same_pg_introduced_not_preserved_positive_lifetime_pure_endpoints",
    "pairing": "both_endpoints_from_one_reference_event",
    "ordering": "supplemental_after_all_matched_event_tiers",
    "validation": "full_interval_and_both_endpoints",
    "identical_source_exclusion": "both_evidence_and_endpoint_sources",
}


def pair_key(reference, event, *, mask=None):
    """Conservative chemistry identity: rules, mask and complete donor trees.

    Rule text is deliberately retained: a different removal rule must not be
    suppressed simply because the installation substrate/donor is the same.
    """
    _, donors = source_parts(reference, event)
    spec = mask if mask is not None else describe_mask(event)
    molecule = mol(spec["protected_smiles"])
    selected = set(spec["mask"]) | set(spec["site_atoms"])
    return stable_id(
        {
            "pg_type": event["pg_type"],
            "protection": event["protection_rule_smarts"],
            "deprotection": event["deprotection_rule_smarts"],
            "fragment": marked_fragment(molecule, selected, set(spec["anchors"])),
            "donors": sorted(fingerprint(d) for d in donors),
        }
    )


def reference_record(endpoint):
    event = endpoint["event"]
    record = {
        "route_id": endpoint["route_id"],
        "event_id": event["occurrence_id"],
        "pair_id": endpoint["pair_id"],
        "protection_path": event["protection_reaction_node_path"],
        "deprotection_path": event["deprotection_reaction_node_path"],
        "protection_rule": event["protection_rule_smarts"],
        "deprotection_rule": event["deprotection_rule_smarts"],
        "equivalent_references": endpoint.get("equivalent_references", []),
    }
    if endpoint.get("original_endpoint_rules"):
        record["rule_scope"] = "functional_class"
        record["original_endpoint_rules"] = endpoint["original_endpoint_rules"]
        record["source_replay"] = endpoint["source_replay"]
    return record


def build_bank(
    references, entries, diagnostics, *, reverse_rule, protection_rules=None
):
    """Prepare once per job; no query or original-recovery labels enter."""
    bank, by_event = defaultdict(list), {}
    for entry in entries:
        event = entry["event"]
        try:
            roles = _substrate_roles(
                forward_rule(
                    event["protection_rule_smarts"], reverse_rule=reverse_rule
                ),
                event["protection_reaction_smiles"],
                tuple(sorted(event["protected_atom_ids"])),
            )
            if not roles:
                raise ValueError("Reference installation substrate role is unresolved")
            mask = describe_mask(event, protection_rules)
            endpoint = {
                **entry,
                "mask_spec": mask,
                "pair_id": pair_key(references[entry["route_id"]], event, mask=mask),
            }
            bank[event["pg_type"]].append(endpoint)
            by_event[event["occurrence_id"]] = endpoint
        except Exception as exc:
            diagnostics.append(
                {
                    "stage": "reference_endpoint",
                    "route_id": entry["route_id"],
                    "event_id": event["occurrence_id"],
                    "message": str(exc),
                }
            )
    for entries in bank.values():
        entries.sort(key=lambda e: (e["route_id"], e["event"]["occurrence_id"]))
    return dict(bank), by_event


def eligible_pairs(bank, pg_type, excluded_fingerprint):
    """Exclude identical sources before collapsing equivalent endpoint pairs."""
    groups = {}
    for entry in bank.get(pg_type, []):
        if entry["fingerprint"] == excluded_fingerprint:
            continue
        groups.setdefault(entry["pair_id"], []).append(entry)
    return [
        {
            **entries[0],
            "equivalent_references": [
                {"route_id": e["route_id"], "event_id": e["event"]["occurrence_id"]}
                for e in entries
            ],
        }
        for entries in groups.values()
    ]
