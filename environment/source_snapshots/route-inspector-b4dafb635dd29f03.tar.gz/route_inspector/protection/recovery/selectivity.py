"""Bounded forward replay for PG installation, interval, removal and subsequent reactions.

Only the query reaction and its reference rule enter this module. Product
identity is constitutional, as are the extracted rules; saved route molecules
and their stereochemistry are never modified.
"""

from copy import deepcopy
from functools import lru_cache, reduce
from itertools import product as assignments
from operator import or_

from route_inspector.protection.recovery.molecules import (
    Lineage,
    comparison_reaction,
    mol,
    validate_edit,
)
from route_inspector.protection.recovery.molecules import (
    component_signature as stereo_component_signature,
)

SELECTIVITY_POLICY = {
    "version": 9,
    "graph_backend": "chython-synplan",
    "application_budget": "distinct_compatible_mapped_patches",
    "patch_identity": "retain_ordered_aromatic_heteroatom_roles",
    "aromatic_hydrogens": "bounded_unconstrained_template_nitrogen_completions",
    "competition": "distinct_valid_constitutional_products",
    "unverified": "exclude",
    "deprotection": "required_intended_product_for_every_candidate",
    "post_deprotection": "immediate_consuming_reaction_or_not_applicable",
    "reactant_patterns": "joint_injective_mappings_may_share_input_molecule",
    "molecule_grouping": "preserve_expected_reactant_partition",
    "attachment_sites": "all_chemically_compatible_free_sites_not_only_intended_site",
    "reacting_site_classes": "reacting_and_departing_roles_with_carbonyl_and_leaving_fragment_classes",
    "role_discovery": "mapped_candidate_bond_changes_including_deleted_atoms",
    "attachment_acid_alcohol_competition": "preserved",
}


def competition_warning(check):
    """Competition is advisory only with a witnessed intended product and lineage."""
    return (
        check.get("status") == "competing"
        and check.get("reason") == "competing_products"
        and check.get("intended_product_reproduced") is True
        and check.get("distinct_valid_products", 0) > 1
        and not check.get("truncated", False)
    )


def selectivity_warnings(selectivity, policy):
    if policy != "warn_competing":
        return []
    return [
        {"stage": stage, "check": check}
        for stage, result in selectivity.items()
        for check in result.get("steps", [result])
        if competition_warning(check)
    ]


def acceptance_failures(selectivity, policy="strict"):
    """Fail closed and retain a diagnostic when mandatory removal was skipped."""
    removal = selectivity.get("deprotection")
    if not removal or removal.get("status") == "not_applicable":
        selectivity["deprotection"] = {
            "status": "unverified",
            "reason": "required_deprotection_check_missing"
            if not removal
            else "required_deprotection_check_not_applicable",
        }
    failures = {}
    for name, result in selectivity.items():
        for check in result.get("steps", [result]):
            if check.get("status") in {"passed", "not_applicable"}:
                continue
            if policy == "warn_competing" and competition_warning(check):
                continue
            # Inspect every interval leaf: an advisory first step cannot hide
            # a later product mismatch or exhausted replay bound.
            failures.setdefault(name, check)
            if check.get("truncated") and not failures[name].get("truncated"):
                failures[name] = {**failures[name], "truncated": True}
    return failures


def forward_rule(rule, *, reverse_rule):
    left, agents, right = rule.split(">")
    if agents:
        raise ValueError("Reaction rules with a reagent section are unsupported")
    return f"{right}>>{left}" if reverse_rule else rule


@lru_cache(maxsize=1024)
def _reactor(rule):
    from chython.reactor import Reactor

    reactor = Reactor.from_smarts(rule, one_shot=True, automorphism_filter=False)
    required = (
        "_patterns",
        "_products_atoms",
        "_replacement",
        "_patcher",
        "_get_deleted",
        "_one_shot",
    )
    if not all(hasattr(reactor, attr) for attr in required):
        raise ValueError("Chython forward replay contract is unsupported")
    return reactor


@lru_cache(maxsize=8192)
def _lineage_signature(text, fixed_maps):
    return Lineage(text, fixed_maps)


def replay(
    rule,
    reaction_smiles,
    *,
    reverse_rule,
    limit=256,
    fixed_maps=(),
    attachment_sites=None,
):
    """Enumerate raw matches; bound distinct compatible mapped patches.

    Fixed input maps establish that the intended site is actually replayed;
    numeric maps do not distinguish competing product identities. Unchosen
    input molecules are spectators, not additional products. Cached records are
    copied so callers can safely attach occurrence provenance.
    """
    if limit < 1:
        raise ValueError("Selectivity application limit must be positive")
    return deepcopy(
        _replay(
            rule,
            reaction_smiles,
            reverse_rule,
            limit,
            tuple(sorted(fixed_maps)),
            None
            if attachment_sites is None
            else tuple(sorted({tuple(sorted(site)) for site in attachment_sites})),
        )
    )


def attachment_atoms(product_text, scaffold_maps):
    """Scaffold atoms bonded to a transferred donor; donor symmetries are allowed."""
    return _attachment_atoms(product_text, frozenset(scaffold_maps))


@lru_cache(maxsize=8192)
def _attachment_atoms(product_text, scaffold_maps):
    molecule = mol(product_text)
    return tuple(
        sorted(
            n
            for n in molecule
            if n in scaffold_maps
            and any(m not in scaffold_maps for m in molecule._bonds[n])
        )
    )


def _functional_classes(text, *, oxygen_acyl=True):
    """Distinguish reacting functional groups without copying substrate context."""
    # Callers receive a private mapping; cached class signatures are immutable.
    return dict(_functional_class_items(text, oxygen_acyl))


@lru_cache(maxsize=8192)
def _functional_class_items(text, oxygen_acyl):
    molecule = mol(text)

    def carbonyl(n):
        return molecule.atom(n).atomic_number == 6 and any(
            int(b) == 2 and molecule.atom(m).atomic_number in {8, 16}
            for m, b in molecule._bonds[n].items()
        )

    result = {}
    for n, atom in molecule.atoms():
        groups = set()
        for m in molecule._bonds[n]:
            neighbor = molecule.atom(m)
            if atom.atomic_number == 7:
                if neighbor.atomic_number in {6, 15, 16} and any(
                    int(b) == 2 and molecule.atom(k).atomic_number in {8, 16}
                    for k, b in molecule._bonds[m].items()
                ):
                    groups.add(("acyl_or_sulfonyl", neighbor.atomic_number))
                if neighbor.atomic_number == 8:
                    groups.add(("nitrogen_oxygen", 8))
            elif atom.atomic_number in {8, 16}:
                groups.add(("neighbor", neighbor.atomic_number))
                if oxygen_acyl and carbonyl(m):
                    groups.add(
                        (
                            "acyl_context",
                            tuple(
                                sorted(
                                    molecule.atom(k).atomic_number
                                    for k in molecule._bonds[m]
                                    if k != n
                                )
                            ),
                        )
                    )
        if carbonyl(n):
            groups.add(
                (
                    "carbonyl",
                    tuple(
                        sorted(
                            (molecule.atom(m).atomic_number, int(b))
                            for m, b in molecule._bonds[n].items()
                        )
                    ),
                )
            )
        if atom.atomic_number == 6:
            groups.add(
                (
                    "carbon_shape",
                    (
                        len(molecule._bonds[n]),
                        atom.implicit_hydrogens or 0,
                        {1: "SP3", 2: "SP2", 3: "SP", 4: "SP2"}[atom.hybridization],
                    ),
                )
            )
        result[n] = (
            atom.atomic_number,
            atom.charge,
            atom.hybridization == 4,
            (atom.implicit_hydrogens or 0) > 0,
            tuple(sorted(groups)),
        )
    return tuple(result.items())


def _bonds(molecule):
    return {
        tuple(sorted((a, b))): int(bond)
        for a, neighbors in molecule._bonds.items()
        for b, bond in neighbors.items()
    }


def _rule_changes(reactor):
    left = {pair: order for p in reactor._patterns for pair, order in _bonds(p).items()}
    right = _bonds(reactor._replacement)
    return left, [
        (a, b, left.get((a, b)), right.get((a, b)))
        for a, b in left.keys() | right.keys()
        if left.get((a, b)) != right.get((a, b))
    ]


def _reaction_role_mappings(reactor, reaction, limit):
    """Bounded full-rule correspondences consistent with recorded mapped edits.

    Extend product correspondences onto input patterns, including deleted atoms.
    This uses the candidate reaction, never held-out original-route chemistry.
    """
    _, changes = _rule_changes(reactor)
    source = reduce(or_, (m.copy() for m in reaction.reactants))
    expected = reduce(or_, (m.copy() for m in reaction.products))
    expected_atoms = set(expected)
    source_bonds, expected_bonds = _bonds(source), _bonds(expected)
    inputs = {n: i for i, molecule in enumerate(reaction.reactants) for n in molecule}
    correspondences = []
    bound = max(limit, 4096)
    work = 0
    pattern_options = []
    for pattern in reactor._patterns:
        options = []
        for molecule in reaction.reactants:
            for mapping in pattern.get_mapping(molecule, automorphism_filter=False):
                work += 1
                if work > bound:
                    return None, True
                options.append(mapping)
        pattern_options.append(options)
    for i, mapping in enumerate(
        reactor._replacement.get_mapping(expected, automorphism_filter=False)
    ):
        # Product-role discovery is separate from raw forward applications.
        if i >= bound:
            return None, True
        options = [
            [
                option
                for option in candidates
                if all(
                    (
                        mapping[n] == target
                        if n in mapping
                        else target not in expected_atoms
                    )
                    for n, target in option.items()
                )
            ]
            for candidates in pattern_options
        ]
        for parts in assignments(*options):
            work += 1
            if work > bound:
                return None, True
            full = {
                **mapping,
                **{n: target for part in parts for n, target in part.items()},
            }
            if len(set(full.values())) != len(full):
                continue
            if not all(
                source_bonds.get(tuple(sorted((full[a], full[b])))) == before
                and expected_bonds.get(tuple(sorted((full[a], full[b])))) == after
                for a, b, before, after in changes
            ):
                continue
            correspondences.append(
                (
                    full,
                    _partition(
                        tuple(inputs[next(iter(part.values()))] for part in parts)
                    ),
                )
            )
    return correspondences, False


def _reaction_site_constraints(reactor, reaction, classes, limit):
    """Classes and molecule partitions, not an intended-atom whitelist."""
    left, changes = _rule_changes(reactor)
    atoms = {n: a for pattern in reactor._patterns for n, a in pattern.atoms()}
    deleted = set(atoms) - set(reactor._replacement)
    roles = {
        n
        for a, b, _, _ in changes
        for n in (a, b)
        if n in atoms
        and (
            atoms[n].atomic_number in {7, 8, 16}
            or (
                atoms[n].atomic_number == 6
                and (
                    n in deleted
                    or any(
                        n in pair
                        and order == 2
                        and atoms[pair[1] if pair[0] == n else pair[0]].atomic_number
                        in {8, 16}
                        for pair, order in left.items()
                    )
                )
            )
        )
    }
    mappings, capped = _reaction_role_mappings(reactor, reaction, limit)
    if capped:
        return None, True
    return {
        (tuple(sorted((n, classes[mapping[n]]) for n in roles)), partition)
        for mapping, partition in mappings
    }, False


def _partition(indices):
    groups = {}
    return tuple(groups.setdefault(i, len(groups)) for i in indices)


def _patch_key(reactor, structure, mapping):
    """Conservative identity of a patch, retaining every input atom identity.

    Only permutations with the same selected atoms, deleted atoms and complete
    replacement graph collapse. Different sites (even constitutionally symmetric
    sites) stay separate so intended lineage cannot be inferred from another site.
    Stereo-bearing templates use the full mapping instead of symmetry reduction.
    Aromatic heteroatom roles remain ordered: native Kekule completion can assign
    their hydrogens differently even when the unlabelled patch graph is equal.
    """
    replacement = reactor._replacement
    if any(a.stereo is not None for _, a in replacement.atoms()) or any(
        b.stereo is not None for _, _, b in replacement.bonds()
    ):
        return tuple(sorted(mapping.items()))

    def translated(n):
        return mapping.get(n, -n)

    atoms = tuple(
        sorted(
            (
                translated(n),
                type(a).__name__,
                a.atomic_number,
                a.isotope,
                a.charge,
                a.is_radical,
                repr(a.implicit_hydrogens) if n not in mapping else "",
            )
            for n, a in replacement.atoms()
        )
    )
    bonds = tuple(
        sorted(
            (*sorted((translated(a), translated(b))), int(bond))
            for a, b, bond in replacement.bonds()
        )
    )
    return (
        tuple(sorted(mapping.values())),
        tuple(sorted(reactor._get_deleted(structure, mapping))),
        atoms,
        bonds,
        tuple(
            translated(n)
            for n, atom in replacement.atoms()
            if atom.atomic_number != 6 and 4 in atom.hybridization
        ),
    )


def _patch_variants(product, reactor, mapping):
    """Complete only hydrogen-unspecified aromatic N roles in the full rule.

    Native graph patching chooses one valid completion based on traversal. A
    rule with bare aromatic N can permit other mapped N-H assignments. Enumerate
    those assignments without looking at the expected product; callers charge
    each attempt to the application budget and validate valence and lineage.
    Fixed-H roles and aromatic atoms outside the replacement stay unchanged.
    """
    yield product, {}
    selected = sorted(
        mapping[n]
        for n, atom in reactor._replacement.atoms()
        if atom.atomic_number == 7
        and 4 in atom.hybridization
        and not atom.implicit_hydrogens
        and n in mapping
        and product.has_atom(mapping[n])
        and product.atom(mapping[n]).hybridization == 4
        and product.atom(mapping[n]).neighbors == 2
        and not product.atom(mapping[n]).charge
        and not product.atom(mapping[n]).is_radical
    )
    if not selected:
        return
    original = tuple(product.atom(n).implicit_hydrogens for n in selected)
    for hydrogens in assignments((0, 1), repeat=len(selected)):
        if hydrogens == original:
            continue
        candidate = product.copy()
        completion = dict(zip(selected, hydrogens, strict=True))
        for n, count in completion.items():
            candidate.atom(n)._implicit_hydrogens = count
        candidate.fix_structure(recalculate_hydrogens=False)
        yield candidate, completion


@lru_cache(maxsize=8192)
def _replay(rule, reaction_smiles, reverse_rule, limit, fixed_maps, attachment_sites):
    from chython import smiles
    from chython._functions import lazy_product
    from chython.exceptions import InvalidAromaticRing

    record = {
        "reaction_smiles": reaction_smiles,
        "status": "unverified",
        "rule_smarts": rule,
        "reverse_rule": reverse_rule,
        "raw_applications": 0,
        "distinct_patch_applications": 0,
        "duplicate_patch_applications": 0,
        "invalid_products": 0,
        "ineligible_site_applications": 0,
        "overlapping_applications": 0,
        "incompatible_reaction_site_applications": 0,
        "incompatible_molecule_groupings": 0,
        "distinct_valid_products": 0,
        "intended_product_reproduced": False,
        "complete": False,
        "truncated": False,
        "outcomes": [],
    }
    if attachment_sites is not None:
        record["eligible_attachment_sites"] = [list(s) for s in attachment_sites]
    try:
        reactor = _reactor(forward_rule(rule, reverse_rule=reverse_rule))
        reaction = smiles(reaction_smiles)
        structures = reaction.reactants
        all_maps = [n for m in structures for n in m]
        if len(all_maps) != len(set(all_maps)):
            raise ValueError("Replay inputs have overlapping atom identities")
        expected_text = reaction_smiles.split(">")[2]
        expected = stereo_component_signature(expected_text, remove_stereo=True)
        expected_lineage = _lineage_signature(expected_text, fixed_maps)
        classes = _functional_classes(
            reaction_smiles.split(">")[0], oxygen_acyl=attachment_sites is None
        )
        constraints, capped = _reaction_site_constraints(
            reactor, reaction, classes, limit
        )
        if not constraints and not capped:
            normalized = comparison_reaction(reaction_smiles)
            if normalized != reaction_smiles:
                normalized_reaction = smiles(normalized)
                normalized_classes = _functional_classes(
                    normalized.split(">")[0], oxygen_acyl=attachment_sites is None
                )
                alternate, alternate_capped = _reaction_site_constraints(
                    reactor, normalized_reaction, normalized_classes, limit
                )
                if alternate or alternate_capped:
                    reaction = normalized_reaction
                    structures = reaction.reactants
                    classes, constraints, capped = (
                        normalized_classes,
                        alternate,
                        alternate_capped,
                    )
                    record["matching_representation"] = "native_resonance"
        if capped:
            record.update(
                reason="application_limit",
                truncated=True,
                limit_scope="reacting_role_discovery",
            )
            return record
        unique = set()
        allowed_groupings = (
            {tuple(range(len(reactor._patterns)))}
            if constraints is None
            else {partition for _, partition in constraints}
        )
        record["reactant_pattern_groupings"] = sorted(allowed_groupings)
        # One reaction can use several disjoint patterns on the same molecule
        # (e.g. cyclic urea formation). Apply the complete rule jointly once.
        for chosen_indices in assignments(
            range(len(structures)), repeat=len(reactor._patterns)
        ):
            partition = _partition(chosen_indices)
            if partition not in allowed_groupings:
                record["incompatible_molecule_groupings"] += 1
                continue
            chosen = [structures[i] for i in chosen_indices]
            united = reduce(
                or_, (structures[i].copy() for i in sorted(set(chosen_indices)))
            )
            mappings = lazy_product(
                *(
                    p.get_mapping(m, automorphism_filter=False)
                    for p, m in zip(reactor._patterns, chosen, strict=True)
                )
            )
            seen_patches = set()
            for parts in mappings:
                record["raw_applications"] += 1
                mapping = {k: v for part in parts for k, v in part.items()}
                if len(set(mapping.values())) != len(mapping):
                    record["overlapping_applications"] += 1
                    continue
                if constraints is not None and not any(
                    all(classes.get(mapping[n]) == signature for n, signature in option)
                    for option, expected_partition in constraints
                    if partition == expected_partition
                ):
                    record["incompatible_reaction_site_applications"] += 1
                    continue
                key = _patch_key(reactor, united, mapping)
                if key in seen_patches:
                    record["duplicate_patch_applications"] += 1
                    continue
                if record["distinct_patch_applications"] >= limit:
                    record.update(
                        reason="application_limit",
                        truncated=True,
                        limit_scope="distinct_compatible_mapped_patches",
                    )
                    return record
                seen_patches.add(key)
                record["distinct_patch_applications"] += 1
                try:
                    patched = reactor._patcher(united, mapping)
                except (InvalidAromaticRing, ValueError):
                    record["invalid_products"] += 1
                    continue
                for product, completion in _patch_variants(patched, reactor, mapping):
                    if completion:
                        if record["distinct_patch_applications"] >= limit:
                            record.update(
                                reason="application_limit",
                                truncated=True,
                                limit_scope="aromatic_hydrogen_completions",
                            )
                            return record
                        record["distinct_patch_applications"] += 1
                        record["aromatic_hydrogen_completions"] = (
                            record.get("aromatic_hydrogen_completions", 0) + 1
                        )
                    try:
                        if completion:
                            product.kekule()
                            product.thiele(fix_tautomers=False)
                        validate_edit(product, united)
                        product_text = format(product, "m")
                        identity = stereo_component_signature(
                            product_text, remove_stereo=True
                        )
                        lineage = _lineage_signature(product_text, fixed_maps)
                        applied_sites = (
                            attachment_atoms(product_text, set(fixed_maps))
                            if attachment_sites is not None
                            else None
                        )
                    except (InvalidAromaticRing, ValueError):
                        record["invalid_products"] += 1
                        continue
                    if (
                        attachment_sites is not None
                        and applied_sites not in attachment_sites
                    ):
                        record["ineligible_site_applications"] += 1
                        continue
                    if identity == expected and lineage == expected_lineage:
                        record["intended_product_reproduced"] = True
                    if identity not in unique:
                        unique.add(identity)
                        record["outcomes"].append(
                            {
                                "product_smiles": list(identity),
                                "mapped_product_smiles": product_text,
                                "rule_atom_mapping": dict(sorted(mapping.items())),
                                **(
                                    {"aromatic_hydrogen_completion": completion}
                                    if completion
                                    else {}
                                ),
                                "reactant_pattern_molecule_indices": list(
                                    chosen_indices
                                ),
                                **(
                                    {"attachment_site_atom_maps": list(applied_sites)}
                                    if applied_sites is not None
                                    else {}
                                ),
                            }
                        )
                        record["distinct_valid_products"] = len(unique)
                    if len(unique) > 1 and record["intended_product_reproduced"]:
                        # Both witnesses establish the advisory result. Continue
                        # past earlier competing outcomes until the intended site
                        # is actually reproduced; never infer it from construction.
                        record.update(status="competing", reason="competing_products")
                        return record
        record["complete"] = True
        if record["intended_product_reproduced"]:
            record.update(status="passed", reason="unique_intended_product")
        else:
            record["reason"] = "intended_product_not_reproduced"
    except Exception as exc:
        record.update(reason="replay_error", message=f"{type(exc).__name__}: {exc}")
    return record
