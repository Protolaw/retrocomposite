"""Chython molecular graphs and exact, constrained atom correspondences.

Canonical strings are prefilters. A correspondence witness checks atom state,
bonds and (when requested) stereo; atom-map hints never establish equality.
"""

from functools import lru_cache, reduce
from operator import or_

from route_inspector import chemistry
from route_inspector.routes.validation import validate_raw_reaction_atom_mapping


@lru_cache(maxsize=8192)
def parsed(text):
    if validate_raw_reaction_atom_mapping(f"{text}>>{text}"):
        raise ValueError("Molecule lacks unique explicit positive atom maps")
    # Stored routes may mix Kekule and aromatic notation. Normalize resonance
    # representation on a copy, without tautomer or charge standardization.
    molecule = _parse_components(text)
    molecule.kekule()
    molecule.thiele(fix_tautomers=False)
    return molecule


def mol(text):
    return _graph(text).copy()


@lru_cache(maxsize=8192)
def _graph(text):
    if validate_raw_reaction_atom_mapping(f"{text}>>{text}"):
        raise ValueError("Molecule lacks unique explicit positive atom maps")
    molecule = _parse_components(text)
    molecule.thiele(fix_tautomers=False)
    return molecule


def _parse_components(text):
    # Parse disconnected components independently: a leading chiral atom in a
    # later component can otherwise acquire the wrong native traversal parity.
    return reduce(
        or_, (chemistry.parse_molecule(part).copy() for part in text.split("."))
    )


def mapped(molecule):
    return format(molecule, "m")


@lru_cache(maxsize=4096)
def comparison_reaction(text):
    """Common native resonance representation for query/reference extraction."""
    sides = text.split(">")
    if len(sides) != 3:
        raise ValueError("Expected reaction SMILES")
    for i in (0, 2):
        sides[i] = mapped(parsed(sides[i]))
    return ">".join(sides)


@lru_cache(maxsize=4096)
def extraction_reaction(text):
    """Normalize extraction inputs without losing recorded aromatic rings.

    Some heterocyclic carbonyls are not re-perceived by native aromatization.
    Retain their recorded ring bonds for both query and reference extraction;
    comparison/replay resonance normalization remains a separate operation.
    """
    sides = text.split(">")
    if len(sides) != 3:
        raise ValueError("Expected reaction SMILES")
    for i in (0, 2):
        source = _parse_components(sides[i])
        normalized = parsed(sides[i]).copy()
        restore_aromatic_systems(normalized, source)
        sides[i] = mapped(normalized)
    return ">".join(sides)


def restore_aromatic_systems(product, source, *, mapping=None, excluded=()):
    """Restore intact recorded ring systems after native Kekule graph editing.

    Chython does not re-perceive every recorded heterocyclic carbonyl. Preserve
    its aromatic representation only where the complete ring system survives.
    Hydrogen counts come from the edited Kekule graph, never the old substrate.
    """
    mapping = {n: n for n in source} if mapping is None else mapping
    remaining = {n for n, atom in source.atoms() if atom.hybridization == 4}
    selected = set()
    while remaining:
        group = {remaining.pop()}
        pending = list(group)
        while pending:
            for m, bond in source._bonds[pending.pop()].items():
                if int(bond) == 4 and m not in group:
                    group.add(m)
                    remaining.discard(m)
                    pending.append(m)
        if group & set(excluded) or not group <= mapping.keys():
            continue
        target = {mapping[n] for n in group}
        if not target <= set(product):
            continue
        if any(
            {mapping[m] for m in source._bonds[n] if m in group}
            != (set(product._bonds[mapping[n]]) & target)
            for n in group
        ):
            continue
        selected.update(group)
    if not selected:
        return
    hydrogens = {
        mapping[n]: product.atom(mapping[n]).implicit_hydrogens for n in selected
    }
    with product:
        for n, m, bond in source.bonds():
            if n in selected and m in selected and int(bond) == 4:
                a, b = mapping[n], mapping[m]
                if int(product.bond(a, b)) != 4:
                    product.delete_bond(a, b)
                    product.add_bond(a, b, 4)
    for n, h in hydrogens.items():
        product.atom(n)._implicit_hydrogens = h
    product.fix_structure(recalculate_hydrogens=False)


def validate_edit(product, source):
    """Reject newly invalid states, retaining exact recorded spectators.

    Chython's valence table does not cover every recorded inorganic reagent
    (e.g. tetracoordinate I(+3)). Such a state may pass through unchanged, but
    cannot be introduced or modified by a proposed graph edit.
    """
    prior = set(source.check_valence())
    for n in product.check_valence():
        if (
            n not in prior
            or atom_state(product.atom(n)) != atom_state(source.atom(n))
            or {m: int(b) for m, b in product._bonds[n].items()}
            != {m: int(b) for m, b in source._bonds[n].items()}
        ):
            raise ValueError("Graph edit creates an invalid valence state")


def ids(molecule):
    return set(molecule)


def atom_state(atom):
    return (
        atom.atomic_number,
        atom.isotope,
        atom.charge,
        atom.is_radical,
        atom.implicit_hydrogens or 0,
        atom.hybridization,
    )


def stereo_key(molecule):
    ranks = {n: n for n in molecule}
    return "".join(molecule._smiles(ranks.__getitem__, mapping=True))


def mapped_equal(a, b, *, stereo=True):
    if set(a) != set(b) or a.bonds_count != b.bonds_count:
        return False
    if any(atom_state(a.atom(n)) != atom_state(b.atom(n)) for n in a):
        return False
    if any(
        {m: int(bond) for m, bond in a._bonds[n].items()}
        != {m: int(bond) for m, bond in b._bonds[n].items()}
        for n in a
    ):
        return False
    return not stereo or stereo_key(a) == stereo_key(b)


@lru_cache(maxsize=16384)
def component_signature(text, *, remove_stereo=False):
    components = []
    for part in text.split("."):
        molecule = parsed(part).copy()
        if remove_stereo:
            molecule.clean_stereo()
        components.append(str(molecule))
    return tuple(sorted(components))


def correspondences(a, b, pins=None, *, stereo=True):
    """Exact native-graph isomorphisms, enforcing known pairs during search.

    Chython's public substructure iterator has no pinned-atom argument. This
    constrained extension searches its atom/bond containers directly, with
    smallest-domain ordering and adjacency pruning. It never materializes or
    filters a factorial list of unrestricted automorphisms.
    """
    if len(a) != len(b) or a.bonds_count != b.bonds_count:
        return
    pins = dict(pins or {})
    if (
        not pins.keys() <= set(a)
        or not set(pins.values()) <= set(b)
        or len(set(pins.values())) != len(pins)
    ):
        return
    bonds_a = {n: {m: int(v) for m, v in a._bonds[n].items()} for n in a}
    bonds_b = {n: {m: int(v) for m, v in b._bonds[n].items()} for n in b}
    states_a = {n: atom_state(atom) for n, atom in a.atoms()}
    states_b = {n: atom_state(atom) for n, atom in b.atoms()}

    def signature(n, bonds, states):
        return (
            states[n],
            tuple(sorted((order, repr(states[m])) for m, order in bonds[n].items())),
        )

    signatures_a = {n: signature(n, bonds_a, states_a) for n in a}
    signatures_b = {n: signature(n, bonds_b, states_b) for n in b}
    domains = {n: tuple(m for m in b if signatures_b[m] == signatures_a[n]) for n in a}
    if any(m not in domains[n] for n, m in pins.items()):
        return
    if any(
        bonds_a[n].get(k) != bonds_b[m].get(v)
        for n, m in pins.items()
        for k, v in pins.items()
    ):
        return
    used = set(pins.values())

    def visit(mapping):
        if len(mapping) == len(a):
            if stereo:
                candidate = a.copy()
                candidate.remap(mapping)
                if not mapped_equal(candidate, b):
                    return
            yield dict(mapping)
            return
        options = []
        for n in a:
            if n in mapping:
                continue
            possible = [
                m
                for m in domains[n]
                if m not in used
                and all(
                    bonds_a[n].get(k) == bonds_b[m].get(v) for k, v in mapping.items()
                )
            ]
            if not possible:
                return
            options.append(
                (len(possible), -sum(k in mapping for k in bonds_a[n]), n, possible)
            )
        _, _, n, possible = min(options)
        for m in possible:
            mapping[n] = m
            used.add(m)
            yield from visit(mapping)
            used.remove(m)
            del mapping[n]

    yield from visit(pins)


class Lineage:
    """Constitutional product identity with persistent input atoms pinned."""

    def __init__(self, text, fixed_maps):
        self.molecule = parsed(text).copy()
        self.molecule.clean_stereo()
        self.fixed = frozenset(fixed_maps) & set(self.molecule)

    def __eq__(self, other):
        if not isinstance(other, Lineage) or self.fixed != other.fixed:
            return False
        if self.fixed == set(self.molecule) == set(other.molecule):
            return mapped_equal(self.molecule, other.molecule, stereo=False)
        return (
            next(
                correspondences(
                    self.molecule,
                    other.molecule,
                    {n: n for n in self.fixed},
                    stereo=False,
                ),
                None,
            )
            is not None
        )


def marked_fragment(molecule, selected, marked):
    """Conservative map-independent fragment key with labelled anchor atoms."""
    import re

    fragment = molecule.substructure(selected, recalculate_hydrogens=False)
    text = format(fragment, "m")
    return re.sub(
        r":(\d+)(?=\])", lambda m: ":1" if int(m[1]) in marked else ":0", text
    )
