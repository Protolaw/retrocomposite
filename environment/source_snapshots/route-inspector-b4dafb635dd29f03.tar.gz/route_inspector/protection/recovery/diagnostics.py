"""Derived SQLite diagnostics for immutable PG proposal runs.

Classify the furthest stage reached by any candidate. Never use the held-out
original PG type or recovery comparison to explain the availability of proposals.
"""

import json
import os
import sqlite3
import tempfile
from pathlib import Path

NO_PROPOSAL_LABELS = {
    "no_evidence": "No matching evidence",
    "reference_not_transferable": "Reference strategy cannot be transferred",
    "no_placement": "No compatible PG placement",
    "construction_failed": "Candidate construction failed",
    "validation_rejected": "Candidates rejected by validation",
    "processing_error": "Processing error before candidate validation",
    "unavailable": "Diagnostics unavailable",
}
VALIDATION_LABELS = {
    "product_not_reproduced": "Expected product not reproduced only",
    "competing_products": "Competing products only",
    "mixed": "Both product mismatch and competing products",
    "other": "Other or incomplete validation",
}
STEP_LABELS = {
    "attachment": "Protection installation",
    "protected_interval": "Reactions during protection",
    "deprotection": "Deprotection",
    "post_deprotection": "Reaction after deprotection",
}
REASON_LABELS = {
    "intended_product_not_reproduced": "Expected product not reproduced",
    "competing_products": "Competing products",
    "application_limit": "Replay search limit reached",
    "replay_error": "Replay could not be completed",
    "rule_extraction_error": "Required rule unavailable",
    "required_deprotection_check_missing": "Mandatory removal check missing",
    "required_deprotection_check_not_applicable": "Mandatory removal check skipped",
}
INDEX_VERSION = 3


def failed_checks(record):
    """Expose blocking leaves, retaining historical strict-run semantics."""
    validation = record.get("validation", {})
    warnings = validation.get("selectivity_warnings", [])
    for stage, result in validation.get("selectivity", {}).items():
        for check in result.get("steps", [result]):
            if {"stage": stage, "check": check} in warnings:
                continue
            if check.get("status") not in {"passed", "not_applicable"}:
                yield stage, check


def read_records(root, name):
    path = root / name
    if path.is_file():
        with path.open() as stream:
            for line in stream:
                yield json.loads(line)


def build_index(root, destination, digest):
    """Publish a disposable companion; never edit the verified source run."""
    root, destination = Path(root), Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(dir=destination.parent, suffix=".sqlite")
    os.close(fd)
    try:
        _populate(root, temporary, digest)
        os.replace(temporary, destination)
    finally:
        Path(temporary).unlink(missing_ok=True)


def _populate(root, destination, digest):
    with sqlite3.connect(f"file:{root / 'catalog.sqlite'}?mode=ro", uri=True) as source:
        rows = source.execute(
            "SELECT route_id, truncated FROM queries WHERE best_recovery='no_proposal'"
        ).fetchall()
    state = {
        rid: {
            "matched_windows": 0,
            "transferable_windows": 0,
            "generated_candidates": 0,
            "generation_failures": 0,
            "search_incomplete": bool(truncated),
            "processing_error": False,
            "pg_types": set(),
            "evidence_tiers": set(),
            "reasons": set(),
            "messages": [],
            "reference_events": set(),
        }
        for rid, truncated in rows
    }
    available = all(
        (root / name).is_file()
        for name in ("matches.jsonl", "candidate_audit.jsonl", "diagnostics.jsonl")
    )
    for row in read_records(root, "matches.jsonl"):
        if row["route_id"] not in state:
            continue
        item = state[row["route_id"]]
        item["matched_windows"] += 1
        item["transferable_windows"] += bool(
            row.get("transferable_support_events")
            or row.get("available_endpoint_pairs")
        )
        item["pg_types"].add(row["pg_type"])
        item["evidence_tiers"].add(row.get("evidence_tier", "exact"))
        item["reference_events"].update(row.get("support_event_ids", []))
    reference_errors = {}
    for row in read_records(root, "diagnostics.jsonl"):
        stage = row["stage"]
        if stage.startswith("reference"):
            if row.get("event_id"):
                reference_errors.setdefault(row["event_id"], []).append(row)
            continue
        if row.get("route_id") not in state:
            continue
        item = state[row["route_id"]]
        if stage == "generation":
            item["generation_failures"] += 1
            item["messages"].append(row)
        elif not stage.startswith("selectivity_"):
            item["processing_error"] = True
            item["messages"].append(row)
    with sqlite3.connect(destination) as conn:
        conn.executescript("""
            CREATE TABLE metadata(digest TEXT, version INTEGER);
            CREATE TABLE route_diagnostics(
                route_id TEXT PRIMARY KEY, reason TEXT, validation_reason TEXT,
                search_incomplete INTEGER, processing_error INTEGER, payload_json TEXT);
            CREATE INDEX diagnostic_reason ON route_diagnostics(reason, validation_reason);
            CREATE TABLE candidates(candidate_id INTEGER PRIMARY KEY, route_id TEXT, payload_json TEXT);
            CREATE TABLE failed_checks(
                check_id INTEGER PRIMARY KEY, route_id TEXT, candidate_id INTEGER,
                stage TEXT, reason TEXT, payload_json TEXT);
            CREATE INDEX checks_route ON failed_checks(route_id, stage, check_id);
        """)
        conn.execute("INSERT INTO metadata VALUES(?,?)", (digest, INDEX_VERSION))
        for candidate_id, row in enumerate(
            read_records(root, "candidate_audit.jsonl"), 1
        ):
            rid = row["route_id"]
            if rid not in state:
                continue
            item = state[rid]
            item["generated_candidates"] += 1
            conn.execute(
                "INSERT INTO candidates VALUES(?,?,?)",
                (candidate_id, rid, json.dumps(row)),
            )
            for stage, check in failed_checks(row):
                reason = check.get("reason", "unverified")
                item["reasons"].add(reason)
                item["search_incomplete"] |= bool(check.get("truncated"))
                item["processing_error"] |= reason in {
                    "replay_error",
                    "rule_extraction_error",
                }
                canonical_stage = (
                    "protected_interval" if stage == "protected_extension" else stage
                )
                conn.execute(
                    "INSERT INTO failed_checks(route_id,candidate_id,stage,reason,payload_json) VALUES(?,?,?,?,?)",
                    (
                        rid,
                        candidate_id,
                        canonical_stage,
                        reason,
                        json.dumps({"stage": stage, "check": check}),
                    ),
                )
        for rid, item in state.items():
            if not available:
                reason = "unavailable"
            elif item["generated_candidates"]:
                reason = "validation_rejected"
            elif item["generation_failures"]:
                reason = "construction_failed"
            elif item["processing_error"]:
                reason = "processing_error"
            elif not item["matched_windows"]:
                reason = "no_evidence"
            elif not item["transferable_windows"]:
                reason = "reference_not_transferable"
            else:
                reason = "no_placement"
            reasons = item.pop("reasons")
            validation = {
                frozenset(
                    {"intended_product_not_reproduced"}
                ): "product_not_reproduced",
                frozenset({"competing_products"}): "competing_products",
                frozenset(
                    {"intended_product_not_reproduced", "competing_products"}
                ): "mixed",
            }.get(frozenset(reasons), "other" if reasons else None)
            item["validation_reasons"] = sorted(reasons)
            item["reference_diagnostics"] = [
                row
                for eid in sorted(item.pop("reference_events"))
                for row in reference_errors.get(eid, [])
            ]
            for field in ("pg_types", "evidence_tiers"):
                item[field] = sorted(item[field])
            item["attempted_candidates"] = (
                item["generated_candidates"] + item["generation_failures"]
            )
            conn.execute(
                "INSERT INTO route_diagnostics VALUES(?,?,?,?,?,?)",
                (
                    rid,
                    reason,
                    validation,
                    item["search_incomplete"],
                    item["processing_error"],
                    json.dumps(item),
                ),
            )


def filters(
    no_proposal_reason=None,
    validation_reason=None,
    failed_step=None,
    diagnostic_flag=None,
):
    """Bound parameters for joined diagnostics; apply before pagination."""
    clauses, params = [], []
    for value, allowed, column in (
        (no_proposal_reason, NO_PROPOSAL_LABELS, "d.reason"),
        (validation_reason, VALIDATION_LABELS, "d.validation_reason"),
    ):
        if value is not None:
            if value not in allowed:
                raise ValueError(f"Unknown diagnostic filter: {value}")
            clauses.append(column + "=?")
            params.append(value)
    if failed_step is not None:
        if failed_step not in STEP_LABELS:
            raise ValueError(f"Unknown failed step: {failed_step}")
        clauses.append(
            "EXISTS (SELECT 1 FROM diagnostic.failed_checks f WHERE f.route_id=q.route_id AND f.stage=?)"
        )
        params.append(failed_step)
    if diagnostic_flag is not None:
        if diagnostic_flag not in {"search_incomplete", "processing_error"}:
            raise ValueError(f"Unknown diagnostic flag: {diagnostic_flag}")
        clauses.append("d." + diagnostic_flag + "=1")
    return clauses, params
