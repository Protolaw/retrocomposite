"""Counterfactual PG removal, evidence transfer, and independent recovery audits."""
