"""Atomic, event-specific graph edits of recorded protection lifecycles."""

from copy import deepcopy
from functools import lru_cache

from route_inspector import chemistry
from route_inspector.protection.analysis import matching_site_mappings
from route_inspector.protection.chython_rules import load_chython_protection_rules
from route_inspector.protection.recovery.molecules import (
    _parse_components,
    restore_aromatic_systems,
)
from route_inspector.protection.recovery.trees import (
    at,
    primary,
    validate,
)
from route_inspector.routes.access import count_reaction_nodes, walk_route_nodes
from route_inspector.routes.validation import validate_raw_reaction_atom_mapping

STRIPPING_POLICY = {
    "version": 3,
    "graph_backend": "chython-synplan",
    "free_group_restoration": "atom_identity_and_bond_state",
}


@lru_cache(maxsize=8192)
def _molecule(text):
    """Read-only mapped Chython parse; copy before editing or remapping.

    Chython can assign absent atom numbers, so check the recorded maps first.
    The shared raw-side validator performs no chemistry toolkit conversion.
    """
    if validate_raw_reaction_atom_mapping(f"{text}>>{text}"):
        raise ValueError("Molecule lacks unique explicit positive atom maps")
    return _parse_components(text)


def _mapped_equal(left, right):
    from route_inspector.protection.recovery.molecules import mapped_equal, parsed

    return mapped_equal(parsed(left), parsed(right))


def describe_mask(event, rules=None):
    rules = rules or load_chython_protection_rules()
    rule = next(r for r in rules.values() if r.name == event["pg_type"])
    reaction = chemistry.parse_reaction(event["deprotection_reaction_smiles"])
    matches = []
    for source in reaction.reactants:
        for anchors, mapping in matching_site_mappings(source, rule):
            if set(anchors) == set(event["protected_atom_ids"]):
                matches.append((source, anchors, mapping))
    unique = {
        tuple(sorted(mapping.values())): (source, anchors, mapping)
        for source, anchors, mapping in matches
    }
    if len(unique) != 1:
        raise ValueError("PG mask does not have a unique recorded site")
    source, anchors, mapping = next(iter(unique.values()))
    mask = set(mapping.values()) - set(anchors)
    raw_mask = set(mask)
    protection = chemistry.parse_reaction(event["protection_reaction_smiles"])
    substrates = [m for m in protection.reactants if set(anchors) <= set(m)]
    if len(substrates) != 1:
        raise ValueError("Protection free substrate is not unique")
    free = substrates[0]
    # A cleavage SMARTS is not a deletion mask. Ester patterns, for example,
    # include the carbonyl oxygen, which already belonged to the free acid.
    mask -= set(free)
    additions = []
    product = reaction.products[0]
    for anchor_query, element, order in rule.atoms_to_add:
        anchor = mapping[anchor_query]
        possible = [
            n
            for n, bond in product._bonds[anchor].items()
            if product.atom(n).atomic_symbol == element
            and int(bond) == order
            and len(product._bonds[n]) == 1
        ]
        if len(possible) != 1:
            raise ValueError("Free-group restoration is ambiguous")
        additions.append((anchor, possible[0], element, order))
        if source.has_atom(possible[0]):
            mask.discard(possible[0])
    site_atoms = set(anchors) | {
        n for a in mask for n in source._bonds[a] if n not in mask
    }
    if not mask:
        raise ValueError(
            "PG fragment is already present in the recorded input; no removable mask"
        )
    return {
        "anchors": sorted(anchors),
        "mask": sorted(mask),
        "raw_mask": sorted(raw_mask),
        "site_atoms": sorted(site_atoms),
        "additions": additions,
        "protected_smiles": format(source, "m"),
    }


def edit_molecule(text, spec):
    molecule = _molecule(text).copy()
    original = molecule.copy()
    present = set(molecule)
    mask = set(spec["mask"])
    if not mask & present:
        raise ValueError("Selected PG mask is absent at a recorded protected node")
    if not mask <= present or not set(spec["anchors"]) <= present:
        raise ValueError("Partial PG mask encountered on protected branch")
    # Open aromatic DMP rings in Kekule form. A single edit transaction defers
    # hydrogen/stereo repair until the complete free-group graph exists.
    molecule.kekule()
    with molecule:
        for n in sorted(mask):
            molecule.delete_atom(n)
        for anchor, n, element, order in spec["additions"]:
            if molecule.has_atom(n):
                if molecule.atom(n).atomic_symbol != element:
                    raise ValueError("Restored free-group atom has a different element")
            else:
                molecule.add_atom(element, n)
            if n in molecule._bonds[anchor]:
                molecule.delete_bond(anchor, n)
            molecule.add_bond(anchor, n, order)
            if len(molecule._bonds[n]) != 1:
                raise ValueError("Restored free-group atom is not terminal")
    # Restore aromatic representation without tautomer normalization. Transaction
    # finalization recalculates affected hydrogens and removes invalid stereo.
    restore_aromatic_systems(
        molecule, original, excluded={a for a, _, _, _ in spec["additions"]}
    )
    molecule.thiele(fix_tautomers=False)
    if molecule.check_valence():
        raise ValueError("Stripped molecule has invalid valence")
    return format(molecule, "m")


def strip_route(route, events, *, save_original=True):
    """Copy then edit all selected events; never return a partial transformation."""
    if not events:
        raise ValueError("No qualifying events")
    if any(
        e["source_type"] != "introduced" or e["pg_terminus"] != "not_preserved"
        for e in events
    ):
        raise ValueError("Only introduced, removed PG events may be stripped")
    tree = primary(route)
    # Stable original paths survive splicing and are recorded in the ledger.
    for path, node in walk_route_nodes(tree):
        node["metadata"] = {"pg_recovery_source_path": list(path)}
    ledger, remaps, specs = [], {}, []
    for event in events:
        spec = describe_mask(event)
        # Carbonyl oxygen identities can differ at the two endpoints. The free
        # terminal atom in the target-side endpoint is canonical for this edit.
        protection = chemistry.parse_reaction(event["protection_reaction_smiles"])
        for anchor, restored, element, order in spec["additions"]:
            candidates = [
                n
                for m in protection.reactants
                if m.has_atom(anchor)
                for n, b in m._bonds[anchor].items()
                if m.atom(n).atomic_symbol == element
                and int(b) == order
                and len(m._bonds[n]) == 1
            ]
            if len(candidates) != 1:
                raise ValueError(
                    "Protection free-state atom cannot be aligned uniquely"
                )
            if candidates[0] != restored:
                remaps[candidates[0]] = restored
        specs.append((event, spec))
        ledger.append({"event": deepcopy(event), **spec})
    for _, node in walk_route_nodes(tree):
        if node["type"] != "mol":
            continue
        m = _molecule(node["smiles"]).copy()
        m.remap({n: remaps[n] for n in m if n in remaps})
        node["smiles"] = format(m, "m")
    endpoint_paths = set()
    donor_removals = []
    for event, spec in specs:
        paths = {tuple(p) for p in event["protected_molecule_node_paths"]}
        for path in paths:
            node = at(tree, path)
            node["smiles"] = edit_molecule(node["smiles"], spec)
        ppath = tuple(event["protection_reaction_node_path"])
        endpoint_paths.update((ppath, tuple(event["deprotection_reaction_node_path"])))
        reaction = at(tree, ppath)
        product_ids = set(_molecule(at(tree, ppath[:-1])["smiles"]))
        children = []
        for child in reaction["children"]:
            cids = set(_molecule(child["smiles"]))
            if (
                not cids & set(spec["anchors"])
                and cids & set(spec["raw_mask"])
                and (cids & product_ids) <= set(spec["raw_mask"])
            ):
                continue  # PG-only donor; retain its entire provenance in original.
            children.append(child)
        donor_removals.append((reaction, children))
    for reaction, children in donor_removals:
        reaction["children"] = children
    # All edits precede splicing so original paths stay meaningful.
    removed = []

    def rebuild(node):
        for reaction in node.get("children", []):
            for child in reaction.get("children", []):
                rebuild(child)
            reaction["smiles"] = (
                ".".join(c["smiles"] for c in reaction["children"])
                + ">>"
                + node["smiles"]
            )
        if len(node.get("children", [])) == 1:
            reaction = node["children"][0]
            path = tuple(reaction["metadata"]["pg_recovery_source_path"])
            equal = [
                c
                for c in reaction["children"]
                if _mapped_equal(c["smiles"], node["smiles"])
            ]
            if equal and path in endpoint_paths:
                if len(equal) != 1 or any(
                    set(_molecule(c["smiles"])) & set(_molecule(node["smiles"]))
                    for c in reaction["children"]
                    if c is not equal[0]
                ):
                    raise ValueError("No-op endpoint has ambiguous substrate branch")
                removed.append(list(path))
                node["children"] = equal[0].get("children", [])
                node["in_stock"] = equal[0].get("in_stock", not node["children"])

    rebuild(tree)
    validation = validate(tree, route["smiles"])
    correspondence = [
        {
            "new_path": list(path),
            "original_path": node["metadata"]["pg_recovery_source_path"],
        }
        for path, node in walk_route_nodes(tree)
    ]
    metadata = {
        "schema_version": 1,
        "stripping_policy": dict(STRIPPING_POLICY),
        "events": ledger,
        "removed_reaction_paths": removed,
        "steps_before": count_reaction_nodes(route),
        "steps_after": count_reaction_nodes(tree),
        "node_correspondence": correspondence,
        "atom_remapping": remaps,
        "validation": validation,
    }
    if save_original:
        metadata["original_tree"] = deepcopy(route)
    tree.setdefault("metadata", {})["pg_stripping"] = metadata
    return tree, metadata
