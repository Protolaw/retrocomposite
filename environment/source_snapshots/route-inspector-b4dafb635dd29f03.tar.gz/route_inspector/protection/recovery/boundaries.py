"""Reference-supported evidence just outside a proposed PG lifetime."""

BOUNDARY_POLICY = {
    "version": 1,
    "source": "immediate_substrate_preparation_or_post_removal_reaction_of_pure_reference_event",
    "query": "adjacent_branch_interval_on_the_recorded_side_of_matched_boundary",
    "trigger": "no_accepted_proposal_after_interval_evidence_search",
    "validation": "full_interval_both_endpoints_and_selectivity",
}


def adjacent(paths, evidence_paths, role):
    """A boundary is outside the lifetime, on the same actual tree branch."""
    if not paths or len(evidence_paths) != 1:
        return False
    boundary = evidence_paths[0]
    if role == "before_installation":
        return boundary[:-2] == paths[0]
    if role == "after_removal":
        return paths[-1][:-2] == boundary
    return False


def boundary_spans(query, steps, paths, role, maximum):
    from route_inspector.protection.recovery.evidence import windows

    # One extra step makes a lifetime-bound truncation observable, just as in
    # the original interval-evidence search. No gaps or sibling joins.
    return sorted(
        (
            span
            for span, _ in windows(query, steps, len(paths) + maximum + 1)
            if adjacent(span, paths, role)
        ),
        key=lambda span: (len(span), span),
    )
