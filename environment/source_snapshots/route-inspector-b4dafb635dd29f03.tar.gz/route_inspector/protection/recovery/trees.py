"""Mapped tree utilities and stereo-aware, globally consistent comparison."""

import json
from copy import deepcopy
from functools import lru_cache
from hashlib import sha256
from itertools import islice

from route_inspector.protection.recovery.molecules import (
    component_signature as stereo_component_signature,
)
from route_inspector.protection.recovery.molecules import (
    correspondences,
    ids,
    mapped_equal,
    mol,
    parsed,
)
from route_inspector.protection.recovery.molecules import (
    mapped as mapped,
)
from route_inspector.routes.access import count_reaction_nodes
from route_inspector.routes.validation import validate_routes_mapping

COMPARISON_POLICY = {
    "version": 3,
    "graph_backend": "chython-synplan",
    "matching": "global_stereo_preserving_constrained_atom_correspondence",
    "provenance": "verified_hint_with_unseeded_fallback",
    "limit": 256,
    "limit_scope": "per_guided_or_unseeded_search",
}


def at(tree, path):
    for index in path:
        tree = tree["children"][index]
    return tree


def tree_key(tree):
    """Exact, mapped chemistry/topology key, excluding occurrence metadata."""
    return (
        tree["type"],
        tree["smiles"],
        tree.get("in_stock"),
        tuple(tree_key(c) for c in tree.get("children", [])),
    )


def primary(tree):
    """Drop all hidden metadata before proposal chemistry sees the query."""
    return {
        k: deepcopy(tree[k]) for k in ("type", "smiles", "in_stock") if k in tree
    } | {"children": [primary(c) for c in tree.get("children", [])]}


def fingerprint(tree):
    """Cheap stereo/topology fingerprint; global correspondence checked separately."""

    return _fingerprint(tree_key(tree))


@lru_cache(maxsize=8192)
def _fingerprint(tree):
    def key(node):
        kind, text, _, children = node
        state = (
            [stereo_component_signature(s) for s in text.split(">")[::2]]
            if kind == "reaction"
            else stereo_component_signature(text)
        )
        return [
            kind,
            state,
            sorted((key(c) for c in children), key=str),
        ]

    return sha256(json.dumps(key(tree), sort_keys=True).encode()).hexdigest()


def compare_trees(left, right, *, limit=256, atom_mapping=None):
    """Match trees top-down with one global, stereo-preserving atom bijection.

    The target fixes scaffold identities before precursor branches are explored.
    This avoids building a huge symmetric graph of repeated atom occurrences.
    Every local match and every branch permutation shares the same mapping.
    Ambiguous bounded searches return unresolved rather than a false mismatch.
    """
    if fingerprint(left) != fingerprint(right):
        return "different"
    # Provenance is a proposed correspondence, never proof of equality. A bad
    # hint cannot turn an otherwise equivalent route into a mismatch.
    if atom_mapping and len(set(atom_mapping.values())) == len(atom_mapping):
        result = _compare_trees(left, right, limit, dict(atom_mapping))
        if result == "equal":
            return result
    return _compare_trees(left, right, limit, {})


@lru_cache(maxsize=2048)
def _fixed_correspondence_equal(left, right, pins):
    candidate = parsed(left).copy()
    candidate.remap(dict(pins))
    return mapped_equal(candidate, parsed(right))


@lru_cache(maxsize=1024)
def _local_correspondences(left, right, pins, limit):
    # Immutable witnesses only. The complete input strings, established atom
    # pairs and bound are part of the key; cache hits spend the same work budget.
    return tuple(
        tuple(mapping.items())
        for mapping in islice(
            correspondences(parsed(left), parsed(right), dict(pins)), limit + 1
        )
    )


def _compare_trees(left, right, limit, initial):
    work = 0
    truncated = False

    def states(a, b, forward, reverse):
        nonlocal work, truncated
        ma, mb = parsed(a), parsed(b)
        left_ids, right_ids = ids(ma), ids(mb)
        if any(forward[n] not in right_ids for n in left_ids & forward.keys()) or any(
            reverse[n] not in left_ids for n in right_ids & reverse.keys()
        ):
            return
        pins = tuple(sorted((n, forward[n]) for n in left_ids & forward.keys()))
        if left_ids <= forward.keys():
            if _fixed_correspondence_equal(a, b, pins):
                yield forward, reverse
            return
        matches = _local_correspondences(a, b, pins, limit)
        if len(matches) > limit:
            truncated = True
        for witness in matches[:limit]:
            work += 1
            if work > limit:
                truncated = True
                return
            yield forward | dict(witness), reverse | {b: a for a, b in witness}

    def pair_nodes(a, b, forward, reverse):
        if a["type"] != b["type"]:
            return
        aside = (
            a["smiles"].split(">")[::2] if a["type"] == "reaction" else [a["smiles"]]
        )
        bside = (
            b["smiles"].split(">")[::2] if b["type"] == "reaction" else [b["smiles"]]
        )

        def sides(index, f, r):
            if index < 0:
                yield from children(a.get("children", []), b.get("children", []), f, r)
                return
            for nf, nr in states(aside[index], bside[index], f, r):
                yield from sides(index - 1, nf, nr)

        yield from sides(len(aside) - 1, forward, reverse)

    def children(left_children, right_children, forward, reverse):
        if len(left_children) != len(right_children):
            return
        if not left_children:
            yield forward, reverse
            return
        first, rest = left_children[0], left_children[1:]
        first_fingerprint = fingerprint(first)
        for i, other in enumerate(right_children):
            if fingerprint(other) != first_fingerprint:
                continue
            for nf, nr in pair_nodes(first, other, forward, reverse):
                yield from children(
                    rest, right_children[:i] + right_children[i + 1 :], nf, nr
                )

    if (
        next(pair_nodes(left, right, initial, {v: k for k, v in initial.items()}), None)
        is not None
    ):
        return "equal"
    return "unresolved" if truncated else "different"


def validate(tree, original_target, *, edge_cache=None):
    if stereo_component_signature(tree["smiles"]) != stereo_component_signature(
        original_target
    ):
        raise ValueError("Target changed")
    if count_reaction_nodes(tree) == 0:
        # Removing a zero-lifespan lifecycle can leave only the starting
        # material. There is no reaction CGR to compose in this valid case.
        if tree.get("children"):
            raise ValueError("Reaction-free route contains unexpected children")
        mol(tree["smiles"])
        return {
            "mapping": True,
            "target": True,
            "reaction_count": 0,
            "mapping_scope": "single explicitly mapped molecule; no reaction CGR",
        }
    result = validate_routes_mapping(
        {"query": tree}, dataset="pg_recovery", edge_cache=edge_cache
    )
    if result.records:
        raise ValueError(f"Generated route mapping invalid: {result.records[0]}")
    return {
        "mapping": True,
        "target": True,
        "reaction_count": count_reaction_nodes(tree),
    }
