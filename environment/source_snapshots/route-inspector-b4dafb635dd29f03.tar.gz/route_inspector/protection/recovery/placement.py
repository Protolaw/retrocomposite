"""Site-first, evidence-backed fallback without consulting saved originals."""

from functools import lru_cache

from route_inspector.protection.recovery.endpoints import pair_key
from route_inspector.protection.recovery.evidence import windows
from route_inspector.protection.recovery.generation import _substrate_roles, sites
from route_inspector.protection.recovery.selectivity import (
    _reactor,
    _rule_changes,
    forward_rule,
    replay,
)

PLACEMENT_POLICY = {
    "version": 2,
    "trigger": "no_accepted_proposal_after_existing_search",
    "lifetimes": "all_branch_contiguous_spans_containing_evidence_within_existing_extension_bound",
    "families": "same_functional_group_or_same_mask_on_amine_and_heteroaryl_n",
    "query_groups": "later_cross_functional_group_evidence_with_query_site_and_persistence_checks",
    "endpoint_context": "remove_unchanged_substrate_context_for_amine_and_hydroxyl_only_keep_functional_classes",
    "validation": "full_interval_both_endpoints_and_selectivity",
}


def family(pg):
    if pg.startswith("heteroaryl_n_"):
        return "heteroaryl_n", pg[len("heteroaryl_n_") :]
    return tuple(pg.split("_", 1)) if "_" in pg else (pg, "")


def relation(source, target):
    if source == target:
        return "same_pg"
    sf, sm = family(source)
    tf, tm = family(target)
    if sf == tf:
        return "functional_group_family"
    if sm == tm and {sf, tf} == {"amine", "heteroaryl_n"}:
        return "nitrogen_mask_family"
    return None


def transfer_groups(groups, pg_types, *, cross_family=False, only_cross_family=False):
    """Keep source PG identity separate from the proposed, query-compatible PG.

    No saved query origin is consulted. Site discovery and executable endpoints
    decide whether a nominated family actually fits the query.
    """
    unique = {}
    for group in groups:
        for pg in sorted(pg_types):
            link = relation(group["pg_type"], pg)
            if only_cross_family and link:
                continue
            if link is None:
                if not (cross_family or only_cross_family):
                    continue
                link = "cross_functional_group"
            row = {
                **group,
                "pg_type": pg,
                "evidence_pg_type": group["pg_type"],
                "evidence_transfer": link,
            }
            unique.setdefault(
                (
                    row["paths"],
                    row["mode"],
                    pg,
                    row["evidence_pg_type"],
                    row.get("evidence_role"),
                ),
                row,
            )
    priority = {
        "same_pg": 0,
        "nitrogen_mask_family": 1,
        "functional_group_family": 2,
        "cross_functional_group": 3,
    }
    tiers = {"exact": 0, "reduced_context": 1, "center_only": 2}
    return sorted(
        unique.values(),
        key=lambda g: (
            priority[g["evidence_transfer"]],
            tiers[g["tier"]],
            -len(g["paths"]),
        ),
    )


def spans(query, steps, paths, maximum):
    """Enumerate branch spans before testing any installation substrate.

    Include one extra reaction for observable truncation. Missing extraction
    breaks a span; sibling branches are never concatenated.
    """
    paths = tuple(paths)
    return sorted(
        (
            span
            for span, _ in windows(query, steps, len(paths) + maximum + 1)
            if any(span[i : i + len(paths)] == paths for i in range(len(span)))
        ),
        key=lambda span: (len(span), span),
    )


def placements(
    query,
    steps,
    paths,
    reference,
    endpoint,
    *,
    maximum,
    limit,
    reverse_rule,
    cache,
    evidence_role="interval",
):
    from route_inspector.protection.recovery.boundaries import boundary_spans

    results, truncated = [], False
    intervals = (
        spans(query, steps, tuple(paths), maximum)
        if evidence_role == "interval"
        else boundary_spans(query, steps, tuple(paths), evidence_role, maximum)
    )
    for span in intervals:
        found, capped = sites(
            query,
            span,
            reference,
            endpoint["event"],
            limit=limit,
            reverse_rule=reverse_rule,
            cache=cache,
            mask=endpoint["mask_spec"],
        )
        truncated |= capped
        if len(span) > len(paths) + maximum:
            truncated |= bool(found)
        else:
            results.extend((span, site) for site in found)
    return results, truncated


@lru_cache(maxsize=4096)
def broaden_rule(rule, reaction, anchors, reverse_rule):
    """Retain all edits and donor patterns; remove unchanged substrate context."""
    forward = forward_rule(rule, reverse_rule=reverse_rule)
    reactor = _reactor(forward)
    roles = _substrate_roles(forward, reaction, anchors)
    if len({i for i, _ in roles}) != 1:
        return rule
    index = roles[0][0]
    _, changes = _rule_changes(reactor)
    changing = {n for a, b, _, _ in changes for n in (a, b)}
    changing.update(n for _, role in roles for n in role)
    removed = set(reactor._patterns[index]) - changing
    if not removed:
        return rule
    patterns = [p.copy() for p in reactor._patterns]
    replacement = reactor._replacement.copy()
    for n in removed:
        patterns[index].delete_atom(n)
        if n in set(replacement):
            replacement.delete_atom(n)
    for p in [*patterns, replacement]:
        p.flush_cache()
    broadened = (
        ".".join(format(p, "m") for p in patterns) + ">>" + format(replacement, "m")
    )
    return forward_rule(broadened, reverse_rule=reverse_rule)


def generalized_endpoint(endpoint, reference, *, reverse_rule, limit):
    """Add a source-replayed variant; the original endpoint remains available."""
    event = endpoint["event"]
    if family(event["pg_type"])[0] not in {"amine", "hydroxyl"}:
        return None
    updated = dict(event)
    for name in ("protection", "deprotection"):
        updated[name + "_rule_smarts"] = broaden_rule(
            event[name + "_rule_smarts"],
            event[name + "_reaction_smiles"],
            tuple(event["protected_atom_ids"]),
            reverse_rule,
        )
    if all(
        updated[n + "_rule_smarts"] == event[n + "_rule_smarts"]
        for n in ("protection", "deprotection")
    ):
        return None
    source_replay = {}
    for name in ("protection", "deprotection"):
        result = replay(
            updated[name + "_rule_smarts"],
            event[name + "_reaction_smiles"],
            reverse_rule=reverse_rule,
            limit=limit,
        )
        if result["status"] != "passed":
            return None
        source_replay[name] = result
    updated["endpoint_context_policy"] = "functional_class"
    return {
        **endpoint,
        "event": updated,
        "pair_id": pair_key(reference, updated, mask=endpoint["mask_spec"]),
        "original_endpoint_rules": {
            n: event[n + "_rule_smarts"] for n in ("protection", "deprotection")
        },
        "source_replay": source_replay,
    }
