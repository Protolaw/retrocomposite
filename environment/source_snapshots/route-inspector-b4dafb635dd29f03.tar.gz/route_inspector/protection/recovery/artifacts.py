"""Immutable PG recovery publication and indexed, paginated browsing."""

import json
import os
import shutil
import sqlite3
import tempfile
from contextlib import contextmanager
from hashlib import sha256
from pathlib import Path

from route_inspector.infrastructure.hashing import sha256_file


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def stable_id(value):
    return sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def portable(path):
    return os.path.relpath(Path(path).resolve(), Path.cwd())


def publish_copy(source, destination):
    """Publish a complete corpus atomically, with exclusive no-overwrite semantics."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".pg-corpus-", dir=destination.parent)
    try:
        with os.fdopen(fd, "wb") as stream, Path(source).open("rb") as input_stream:
            shutil.copyfileobj(input_stream, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, destination)
    finally:
        Path(temporary).unlink(missing_ok=True)


@contextmanager
def publication(destination):
    destination = Path(destination)
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=".pg-recovery-", dir=destination.parent))
    try:
        yield stage
        if destination.exists():
            raise FileExistsError(f"Refusing to overwrite {destination}")
        stage.rename(destination)
    finally:
        if stage.exists():
            shutil.rmtree(stage)


def finish(root, summary, provenance, diagnostics):
    write_json(root / "summary.json", summary)
    with (root / "errors.tsv").open("w") as stream:
        import csv

        writer = csv.DictWriter(
            stream,
            fieldnames=["stage", "route_id", "event_id", "message"],
            delimiter="\t",
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(diagnostics)
    with (root / "diagnostics.jsonl").open("w") as stream:
        for row in diagnostics:
            stream.write(json.dumps(row, sort_keys=True) + "\n")
    write_json(
        root / "manifest.json",
        {
            "schema_version": 1,
            **provenance,
            "artifacts": {
                str(p.relative_to(root)): sha256_file(p)
                for p in root.rglob("*")
                if p.is_file()
            },
        },
    )


def verify(root):
    root = Path(root)
    manifest = json.loads((root / "manifest.json").read_text())
    if manifest["schema_version"] != 1:
        raise ValueError("Unsupported PG recovery schema")
    for name, digest in manifest["artifacts"].items():
        if Path(name).is_absolute() or ".." in Path(name).parts:
            raise ValueError("Invalid artifact path")
        if sha256_file(root / name) != digest:
            raise ValueError(f"PG recovery artifact changed: {name}")
    return manifest


class PGRecoveryBrowser:
    def __init__(self, root, *, diagnostic_cache=None):
        self.root = Path(root)
        self.manifest = verify(self.root)
        self.summary = json.loads((self.root / "summary.json").read_text())
        self.diagnostic_cache = (
            Path(diagnostic_cache)
            if diagnostic_cache
            else self.root.parent / ".pg-recovery-diagnostics"
        )
        self.diagnostic_path = None

    @contextmanager
    def connection(self, *, diagnostics=False):
        conn = sqlite3.connect(f"file:{self.root / 'catalog.sqlite'}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        try:
            if diagnostics:
                self.ensure_diagnostics()
                conn.execute(
                    "ATTACH DATABASE ? AS diagnostic",
                    (f"file:{self.diagnostic_path}?mode=ro",),
                )
            yield conn
        finally:
            conn.close()

    @staticmethod
    def _recovery_filter(recovery):
        if recovery is None:
            return "", ()
        if recovery not in {
            "no_proposal",
            "different_valid_proposal",
            "original_route_recovered",
            "partial_strategy_recovery",
            "comparison_unresolved",
        }:
            raise ValueError("Unknown recovery status")
        return " WHERE best_recovery = ?", (recovery,)

    def ensure_diagnostics(self):
        from route_inspector.protection.recovery.diagnostics import (
            INDEX_VERSION,
            build_index,
        )

        if self.diagnostic_path is None:
            digest = stable_id(self.manifest)
            path = self.diagnostic_cache / f"{digest}-v{INDEX_VERSION}.sqlite"
            valid = False
            if path.is_file():
                try:
                    with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as conn:
                        valid = conn.execute(
                            "SELECT digest, version FROM metadata"
                        ).fetchone() == (digest, INDEX_VERSION)
                except sqlite3.Error:
                    pass
            if not valid:
                build_index(self.root, path, digest)
            self.diagnostic_path = path

    def _query_filter(self, recovery=None, **diagnostic_filters):
        from route_inspector.protection.recovery.diagnostics import filters

        clauses, params = filters(**diagnostic_filters)
        self._recovery_filter(recovery)  # retain validation for legacy callers
        if recovery is not None:
            clauses.append("q.best_recovery=?")
            params.append(recovery)
        return (" WHERE " + " AND ".join(clauses) if clauses else ""), params

    def route_count(self, *, recovery=None, **diagnostic_filters):
        where, params = self._query_filter(recovery, **diagnostic_filters)
        with self.connection(diagnostics=True) as conn:
            return conn.execute(
                "SELECT count(*) FROM queries q LEFT JOIN diagnostic.route_diagnostics d USING(route_id)"
                + where,
                params,
            ).fetchone()[0]

    def routes(self, offset=0, limit=25, *, recovery=None, **diagnostic_filters):
        where, params = self._query_filter(recovery, **diagnostic_filters)
        with self.connection(diagnostics=True) as conn:
            return [
                dict(r)
                for r in conn.execute(
                    "SELECT q.route_id, q.proposal_count, q.best_recovery, q.truncated, d.reason AS no_proposal_reason, d.validation_reason, d.processing_error "
                    "FROM queries q LEFT JOIN diagnostic.route_diagnostics d USING(route_id)"
                    + where
                    + " ORDER BY CAST(q.route_id AS INTEGER), q.route_id LIMIT ? OFFSET ?",
                    (*params, limit, offset),
                )
            ]

    def diagnostic_counts(self):
        with self.connection(diagnostics=True) as conn:
            return {
                field: dict(
                    conn.execute(
                        f"SELECT {field}, count(*) FROM diagnostic.route_diagnostics WHERE {field} IS NOT NULL GROUP BY {field}"
                    )
                )
                for field in ("reason", "validation_reason")
            }

    def route_diagnostics(self, route_id):
        with self.connection(diagnostics=True) as conn:
            row = conn.execute(
                "SELECT * FROM diagnostic.route_diagnostics WHERE route_id=?",
                (str(route_id),),
            ).fetchone()
            if row is None:
                return None
            return {**dict(row), **json.loads(row["payload_json"])}

    def validation_checks(self, route_id, offset=0, limit=25, *, stage=None):
        from route_inspector.protection.recovery.diagnostics import STEP_LABELS

        if stage is not None and stage not in STEP_LABELS:
            raise ValueError("Unknown failed step")
        where, params = " WHERE f.route_id=?", [str(route_id)]
        if stage is not None:
            where += " AND f.stage=?"
            params.append(stage)
        with self.connection(diagnostics=True) as conn:
            total = conn.execute(
                "SELECT count(*) FROM diagnostic.failed_checks f" + where, params
            ).fetchone()[0]
            rows = []
            for row in conn.execute(
                "SELECT f.*, c.payload_json AS candidate_json FROM diagnostic.failed_checks f JOIN diagnostic.candidates c USING(candidate_id)"
                + where
                + " ORDER BY check_id LIMIT ? OFFSET ?",
                (*params, limit, offset),
            ):
                candidate = json.loads(row["candidate_json"])
                check = json.loads(row["payload_json"])["check"]
                rows.append(
                    {
                        "check_id": row["check_id"],
                        "candidate_id": row["candidate_id"],
                        "stage": row["stage"],
                        "reason": row["reason"],
                        "pg_type": candidate["strategy"]["pg_type"],
                        "site_atom_maps": candidate["strategy"].get(
                            "site_atom_maps", []
                        ),
                        "reference_route_id": candidate.get("reference_route_id"),
                        "query_path": check.get(
                            "query_reaction_path",
                            check.get(
                                "query_input_path", check.get("query_output_path", [])
                            ),
                        ),
                    }
                )
            return {"rows": rows, "total": total}

    def validation_check(self, route_id, check_id):
        with self.connection(diagnostics=True) as conn:
            row = conn.execute(
                "SELECT f.payload_json, c.payload_json FROM diagnostic.failed_checks f JOIN diagnostic.candidates c USING(candidate_id) WHERE f.route_id=? AND f.check_id=?",
                (str(route_id), int(check_id)),
            ).fetchone()
            if row is None:
                raise KeyError(check_id)
            return {**json.loads(row[0]), "candidate": json.loads(row[1])}

    def route(self, route_id):
        with self.connection() as conn:
            row = conn.execute(
                "SELECT tree_json FROM queries WHERE route_id=?", (str(route_id),)
            ).fetchone()
            if row is None:
                raise KeyError(route_id)
            return json.loads(row[0])

    def proposals(self, route_id):
        with self.connection() as conn:
            return [
                json.loads(row[0])
                for row in conn.execute(
                    "SELECT payload_json FROM proposals WHERE route_id=? ORDER BY rank",
                    (str(route_id),),
                )
            ]
