"""Auditable cohort selection, independent of proposal outcomes."""

ELIGIBILITY_POLICY = {
    "version": 2,
    "scope": "whole_route_if_any_selected_event_is_ineligible",
    "default": "ngram",
    "exclusions": ["zero_lifespan", "direct_pg_exchange", "empty_stripped_lifespan"],
    "exchange": "event_pairs_or_endpoint_patterns_with_different_pg_types_on_same_mapped_site",
}


def endpoint_exchanges(event, rules=None):
    """Recognize exchanges even when a conserved anchor bond hides one event.

    In particular, mapped Boc -> TFA can reuse the N-C(=O) atoms. There is
    no separately detected Boc cleavage, but the input is still protected.
    Compare whole native PG patterns on both sides at the focal mapped site;
    unrelated sites and patterns surviving unchanged are not exchanges.
    """
    from route_inspector import chemistry
    from route_inspector.protection.analysis import matching_site_mappings
    from route_inspector.protection.chython_rules import load_chython_protection_rules

    rules = rules if rules is not None else load_chython_protection_rules()
    anchors = set(event["protected_atom_ids"])
    for endpoint in ("protection", "deprotection"):
        text = event.get(endpoint + "_reaction_smiles")
        if not text:
            continue
        reaction = chemistry.parse_reaction(text)

        def present(molecules):
            return {
                rule.name
                for molecule in molecules
                if anchors <= set(molecule)
                for rule in rules.values()
                if any(
                    set(site) == anchors
                    for site, _ in matching_site_mappings(molecule, rule)
                )
            }

        before, after = present(reaction.reactants), present(reaction.products)
        lost, gained = before - after, after - before
        if endpoint == "protection" and event["pg_type"] in gained:
            pairs = [(old, event["pg_type"]) for old in sorted(lost)]
        elif endpoint == "deprotection" and event["pg_type"] in lost:
            pairs = [(event["pg_type"], new) for new in sorted(gained)]
        else:
            pairs = []
        for old, new in pairs:
            yield {
                "code": "direct_pg_exchange",
                "event_ids": [event["occurrence_id"]],
                "pg_types": [old, new],
                "site_atom_maps": sorted(anchors),
                "reaction_node_path": event[endpoint + "_reaction_node_path"],
                "evidence": "endpoint_pg_patterns",
                "reaction_smiles": text,
            }


def eligibility_reasons(selected, all_events, *, stripping=None, rules=None):
    selected_ids = {e["occurrence_id"] for e in selected}
    reasons = []
    for event in selected:
        if event["lifetime_steps"] == 0:
            reasons.append(
                {"code": "zero_lifespan", "event_ids": [event["occurrence_id"]]}
            )
    for removed in all_events:
        if removed["pg_terminus"] != "not_preserved":
            continue
        for installed in all_events:
            pair = [removed["occurrence_id"], installed["occurrence_id"]]
            if (
                installed["source_type"] == "introduced"
                and selected_ids.intersection(pair)
                and removed["pg_type"] != installed["pg_type"]
                and set(removed["protected_atom_ids"])
                == set(installed["protected_atom_ids"])
                and removed["deprotection_reaction_node_path"]
                == installed["protection_reaction_node_path"]
            ):
                reasons.append(
                    {
                        "code": "direct_pg_exchange",
                        "event_ids": pair,
                        "pg_types": [removed["pg_type"], installed["pg_type"]],
                        "site_atom_maps": removed["protected_atom_ids"],
                        "reaction_node_path": removed[
                            "deprotection_reaction_node_path"
                        ],
                    }
                )
    known = {
        (
            tuple(r["reaction_node_path"]),
            tuple(sorted(r["site_atom_maps"])),
            tuple(r["pg_types"]),
        )
        for r in reasons
        if r["code"] == "direct_pg_exchange"
    }
    for event in selected:
        for reason in endpoint_exchanges(event, rules):
            key = (
                tuple(reason["reaction_node_path"]),
                tuple(reason["site_atom_maps"]),
                tuple(reason["pg_types"]),
            )
            if key not in known:
                reasons.append(reason)
                known.add(key)
    if stripping is not None:
        kept = {tuple(r["original_path"]) for r in stripping["node_correspondence"]}
        for event in selected:
            if event["lifetime_steps"] > 0 and not any(
                tuple(p) in kept for p in event["interval_reaction_node_paths"]
            ):
                reasons.append(
                    {
                        "code": "empty_stripped_lifespan",
                        "event_ids": [event["occurrence_id"]],
                    }
                )
    return reasons
