"""Verified library inputs and PG-independent contiguous query windows."""

import json
from collections import defaultdict
from copy import deepcopy
from functools import lru_cache
from pathlib import Path

from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.protection.recovery.molecules import (
    comparison_reaction,
    extraction_reaction,
)
from route_inspector.protection.recovery.stripping import strip_route
from route_inspector.protection.recovery.trees import at, fingerprint, ids, mol
from route_inspector.protection.strategies.catalog import ReferencePGStrategyLibrary
from route_inspector.protection.strategies.models import PGStrategyIntervalStepIdentity
from route_inspector.protection.strategies.processor import RoutePGStrategyProcessor
from route_inspector.routes.access import reaction_nodes, route_items


def library_input(library_path, source):
    with ReferencePGStrategyLibrary.load(library_path) as library:
        manifest = library.manifest.to_dict()
    digest = sha256_file(Path(source))
    if (
        len(manifest["reference_corpora"]) != 1
        or manifest["reference_corpora"][0]["input_sha256"] != digest
    ):
        raise ValueError("Clean source does not match the PG library corpus digest")
    profile = deepcopy(manifest["processing_profile"])
    # Old libraries differ ONLY in target-retained origin tracing. PG recovery
    # admits only observed removals, never target-preserved evidence.
    policy = profile["origin_policy"]
    legacy = policy == {"phthalimide_nitrogen_donor_exclusion": 1}
    if legacy:
        policy["target_retained_fragment_continuity"] = 1
    processor = RoutePGStrategyProcessor.from_profile(profile)
    events = defaultdict(list)
    with (Path(library_path) / "provenance/events.jsonl").open() as stream:
        for line in stream:
            event = json.loads(line)
            if (
                event["source_type"] == "introduced"
                and event["pg_terminus"] == "not_preserved"
            ):
                events[event["route"]["route_id"]].append(event)
    with Path(source).open() as stream:
        routes = {str(k): v for k, v in route_items(json.load(stream))}
    if not set(events) <= routes.keys():
        raise ValueError("Event routes missing from verified source")
    return (
        routes,
        events,
        processor,
        {
            "library_id": manifest["library_id"],
            "source_sha256": digest,
            "processing_profile": profile,
            "legacy_closed_events_compatibility": legacy,
        },
    )


@lru_cache(maxsize=32768)
def identity(rule):
    return PGStrategyIntervalStepIdentity.from_rule(rule)


def extract_steps(tree, extractor, diagnostics, route_id, *, preserve_aromatic=False):
    result = {}
    for path, node in reaction_nodes(tree):
        try:
            normalize = (
                extraction_reaction if preserve_aromatic else comparison_reaction
            )
            step, _ = extractor.extract(normalize(node["smiles"]))
            if step is None:
                raise ValueError("No extractable rule")
            identity(step.rule_smarts)
            result[path] = step.rule_smarts
        except Exception as exc:
            diagnostics.append(
                {
                    "stage": "rule_extraction",
                    "route_id": route_id,
                    "path": list(path),
                    "message": str(exc),
                }
            )
    return result


def windows(tree, steps, maximum):
    """Every actual branch-adjacent window; failure at any step breaks a window."""
    for path, _ in reaction_nodes(tree):
        chain, current = [], path
        while current and len(chain) < maximum:
            if current not in steps:
                break
            chain.append(current)
            yield tuple(chain), tuple(steps[p] for p in chain)
            current = current[:-2]  # synthetic order: child reaction -> its parent


def key(rules):
    return tuple(identity(r).lookup_key for r in rules)


def equivalent(left, right):
    return len(left) == len(right) and all(
        identity(a).equivalent_to(identity(b)) for a, b in zip(left, right, strict=True)
    )


def stored_steps(library, events):
    selected = {e["occurrence_id"] for es in events.values() for e in es}
    result = defaultdict(dict)
    with (Path(library) / "interval_steps/occurrences.jsonl").open() as stream:
        for line in stream:
            step = json.loads(line)
            if step["event_occurrence_id"] in selected:
                result[step["event_occurrence_id"]][
                    tuple(step["reaction_node_path"])
                ] = step["rule_smarts"]
    return result


def build_evidence(
    routes,
    events,
    processor,
    diagnostics,
    progress=lambda *_: None,
    *,
    recorded_steps=None,
    endpoint_entries=None,
    boundary_index=None,
):
    index, maximum, zero = defaultdict(list), 1, 0
    for i, (rid, selected) in enumerate(sorted(events.items())):
        route = routes[rid]
        for event in selected:
            original_steps = (
                recorded_steps[event["occurrence_id"]]
                if recorded_steps is not None
                else extract_steps(route, processor.rule_extractor, diagnostics, rid)
            )
            paths = [tuple(p) for p in event["interval_reaction_node_paths"]]
            if not paths:
                zero += 1
                continue
            maximum = max(maximum, len(paths))
            base = {"event": event, "route_id": rid, "fingerprint": fingerprint(route)}
            variants = [("stored_exact", paths, original_steps, "stored")]
            try:
                stripped, ledger = strip_route(route, [event], save_original=False)
                correspondence = {
                    tuple(v["original_path"]): tuple(v["new_path"])
                    for v in ledger["node_correspondence"]
                }
                projected = [correspondence.get(p) for p in paths]
                extracted = extract_steps(
                    stripped, processor.rule_extractor, diagnostics, rid
                )
                aromatic = extract_steps(
                    stripped,
                    processor.rule_extractor,
                    diagnostics,
                    rid,
                    preserve_aromatic=True,
                )
                variants.append(
                    ("pg_normalized_exact", projected, extracted, "native_resonance")
                )
                if aromatic != extracted:
                    variants.append(
                        (
                            "pg_normalized_exact",
                            projected,
                            aromatic,
                            "recorded_aromatic",
                        )
                    )
                base["transferable"] = all(
                    p in ledger["removed_reaction_paths"]
                    for p in (
                        event["protection_reaction_node_path"],
                        event["deprotection_reaction_node_path"],
                    )
                )
            except Exception as exc:
                base["transferable"] = False
                diagnostics.append(
                    {
                        "stage": "reference_projection",
                        "route_id": rid,
                        "event_id": event["occurrence_id"],
                        "message": str(exc),
                    }
                )
            if endpoint_entries is not None and base["transferable"]:
                endpoint_entries.append(base)
            if boundary_index is not None and base["transferable"]:
                install = tuple(event["protection_reaction_node_path"])
                remove = tuple(event["deprotection_reaction_node_path"])
                anchors = set(event["protected_atom_ids"])
                preceding = [
                    install + (j, 0)
                    for j, child in enumerate(at(route, install)["children"])
                    if anchors <= ids(mol(child["smiles"])) and child.get("children")
                ]
                boundaries = [("before_installation", p) for p in preceding]
                if remove[:-2]:
                    boundaries.append(("after_removal", remove[:-2]))
                for role, path in boundaries:
                    projected_path = correspondence.get(path)
                    if projected_path not in extracted:
                        continue
                    for representation, available in (
                        ("native_resonance", extracted),
                        ("recorded_aromatic", aromatic),
                    ):
                        if projected_path not in available:
                            continue
                        rules = (available[projected_path],)
                        if representation == "recorded_aromatic" and equivalent(
                            rules, (extracted[projected_path],)
                        ):
                            continue
                        boundary_index.setdefault(role, defaultdict(list))[
                            key(rules)
                        ].append(
                            {
                                **base,
                                "mode": "pg_normalized_exact",
                                "rules": rules,
                                "representation": representation,
                                "reference_paths": [path],
                                "start": 0,
                                "length": 1,
                                "evidence_role": role,
                            }
                        )
            for mode, variant_paths, steps, representation in variants:
                for start in range(len(paths)):
                    for length in range(1, len(paths) - start + 1):
                        span = variant_paths[start : start + length]
                        if any(p not in steps for p in span):
                            break
                        rules = tuple(steps[p] for p in span)
                        if (
                            representation == "recorded_aromatic"
                            and all(p in extracted for p in span)
                            and equivalent(rules, tuple(extracted[p] for p in span))
                        ):
                            continue
                        index[key(rules)].append(
                            {
                                **base,
                                "mode": mode,
                                "representation": representation,
                                "rules": rules,
                                "reference_paths": paths[start : start + length],
                                "start": start,
                                "length": length,
                            }
                        )
        if i % 25 == 0:
            progress("reference", f"Projected {i + 1}/{len(events)} reference routes")
    return index, maximum, zero
