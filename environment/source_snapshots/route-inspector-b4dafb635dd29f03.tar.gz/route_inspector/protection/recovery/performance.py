"""Scoped runtime tuning for allocation-heavy chemistry searches."""

import gc
from collections import OrderedDict
from contextlib import contextmanager


class BoundedRuleCache(OrderedDict):
    """Keep recent extracted rules; eviction only causes later recomputation."""

    def __init__(self, values=(), *, maxsize=4096):
        if maxsize < 1:
            raise ValueError("Rule cache size must be positive")
        self.maxsize = maxsize
        super().__init__()
        for key, value in dict(values).items():
            self[key] = value

    def __getitem__(self, key):
        value = super().__getitem__(key)
        self.move_to_end(key)
        return value

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        self.move_to_end(key)
        if len(self) > self.maxsize:
            self.popitem(last=False)


@contextmanager
def proposal_gc_scope():
    """Batch cyclic-GC scans; keep collection enabled and restore caller settings.

    Reference graphs and bounded chemistry caches form a large, mostly live
    object graph. CPython's default 700-allocation trigger repeatedly scans it
    while generating candidates. A larger nursery batches that bookkeeping;
    reference counting and all three collection generations remain active.
    This changes neither search budgets nor chemical validation.
    """
    previous = gc.get_threshold()
    changed = gc.isenabled() and 0 < previous[0] < 500_000
    if changed:
        gc.set_threshold(500_000, *previous[1:])
    try:
        yield
    finally:
        if changed:
            gc.set_threshold(*previous)
