"""Transfer pure recorded PG endpoints to persistent compatible free sites."""

from copy import deepcopy
from functools import lru_cache

from route_inspector.protection.recovery.molecules import (
    restore_aromatic_systems,
    validate_edit,
)
from route_inspector.protection.recovery.selectivity import (
    _functional_classes,
    _reaction_role_mappings,
    _reactor,
    forward_rule,
    replay,
)
from route_inspector.protection.recovery.site_queries import build_query
from route_inspector.protection.recovery.stripping import describe_mask
from route_inspector.protection.recovery.trees import (
    at,
    ids,
    mapped,
    mol,
    primary,
    tree_key,
    validate,
)
from route_inspector.routes.access import walk_route_nodes


def source_parts(reference, event):
    reaction = at(reference, event["protection_reaction_node_path"])
    anchors = set(event["protected_atom_ids"])
    substrates = [c for c in reaction["children"] if anchors <= ids(mol(c["smiles"]))]
    if len(substrates) != 1:
        raise ValueError("Reference protection substrate is not unique")
    substrate = substrates[0]
    return substrate, [c for c in reaction["children"] if c is not substrate]


def site_query(
    text,
    spec,
    *,
    generalized=False,
    protected_text=None,
    endpoint_context=True,
):
    """Find candidate cores; executable rules validate broader attachments.

    The original local-context query remains available for audit comparisons.
    Generalized discovery retains elements, charge, aromaticity and core bonds,
    including restored free atoms needed for carbonyl/ester map transfer.
    """
    return _site_query(
        text,
        tuple(tuple(row) for row in spec["additions"]),
        tuple(spec["site_atoms"]),
        generalized,
        protected_text or spec["protected_smiles"],
        endpoint_context,
    ).copy()


@lru_cache(maxsize=4096)
def _site_query(
    text, additions, site_atoms, generalized, protected_text, endpoint_context
):
    return build_query(
        text, additions, site_atoms, generalized, protected_text, endpoint_context
    )


@lru_cache(maxsize=4096)
def _substrate_roles(rule, reaction_smiles, anchors):
    from chython import smiles

    reactor = _reactor(rule)
    reaction = smiles(reaction_smiles)
    substrates = [m for m in reaction.reactants if set(anchors) <= set(m)]
    if len(substrates) != 1:
        raise ValueError("Reference installation substrate is not unique")
    mappings, capped = _reaction_role_mappings(reactor, reaction, 4096)
    if capped:
        raise ValueError("Reference installation role discovery exceeded its bound")
    roles = {
        (i, tuple(sorted(n for n in pattern if mapping[n] in anchors)))
        for mapping, _ in mappings
        for i, pattern in enumerate(reactor._patterns)
        if set(anchors) <= {mapping[n] for n in pattern} <= set(substrates[0])
    }
    return tuple(sorted(roles))


@lru_cache(maxsize=32768)
def _endpoint_matches(text, anchors, forward, substrate_roles):
    from chython import smiles

    substrate = smiles(text)
    patterns = _reactor(forward)._patterns
    return any(
        set(anchors) == {mapping[n] for n in roles}
        for index, roles in substrate_roles
        for mapping in patterns[index].get_mapping(substrate, automorphism_filter=False)
    )


def endpoint_compatible(
    text, anchors, event, *, reverse_rule, site_policy="substrate_role"
):
    """Require a complete installation substrate pattern at the intended core."""
    rule = event.get("protection_rule_smarts")
    if not rule:
        return True  # Legacy hand-built events extract their rule in generate().
    if event.get("endpoint_context_policy") == "functional_class":
        source = _functional_classes(
            event["protection_reaction_smiles"].split(">")[0], oxygen_acyl=False
        )
        target = _functional_classes(text, oxygen_acyl=False)
        # Retain amine/amide/sulfonamide, charge, aromaticity, H availability,
        # and oxygen-neighbour element distinctions after context removal.
        expected = sorted(source[n] for n in event["protected_atom_ids"])
        actual = sorted(target[n] for n in anchors)
        if expected != actual:
            return False
    from chython import smiles

    forward = forward_rule(rule, reverse_rule=reverse_rule)
    if site_policy == "validated":
        # Historical policy-6 reconstruction must retain its original behavior.
        substrate = smiles(text)
        patterns = _reactor(forward)._patterns
        return any(
            set(anchors) <= set(mapping.values())
            for pattern in patterns
            for mapping in pattern.get_mapping(substrate, automorphism_filter=False)
        )
    return _endpoint_matches(
        text,
        tuple(sorted(anchors)),
        forward,
        _substrate_roles(
            forward,
            event["protection_reaction_smiles"],
            tuple(sorted(event["protected_atom_ids"])),
        ),
    )


def sites(
    query_tree,
    paths,
    reference,
    event,
    *,
    limit=256,
    generalized=True,
    reverse_rule=True,
    site_policy="substrate_role",
    cache=None,
    mask=None,
):
    cache_key = (
        event["occurrence_id"] if "occurrence_id" in event else repr(event),
        event.get("protection_rule_smarts"),
        event.get("endpoint_context_policy"),
        tuple(paths),
        limit,
        generalized,
        reverse_rule,
        site_policy,
    )
    if cache is not None and cache_key in cache:
        return cache[cache_key]
    spec = mask if mask is not None else describe_mask(event)
    substrate, _ = source_parts(reference, event)
    query = site_query(
        substrate["smiles"],
        spec,
        generalized=generalized,
        protected_text=event["protection_reaction_smiles"].split(">")[2],
        endpoint_context=site_policy != "legacy",
    )
    first = at(query_tree, paths[0])
    results, seen, truncated = [], set(), False
    for i, child in enumerate(first["children"]):
        m = mol(child["smiles"])
        matches = tuple(query.get_mapping(m, limit=limit + 1))
        truncated |= len(matches) > limit
        for mapping in matches[:limit]:
            anchors = tuple(mapping[n] for n in spec["anchors"])
            if anchors in seen:
                continue
            if site_policy != "legacy" and not endpoint_compatible(
                child["smiles"],
                anchors,
                event,
                reverse_rule=reverse_rule,
                site_policy=site_policy,
            ):
                continue

            def state(molecule):
                if not set(anchors) <= set(molecule):
                    return None
                return tuple(
                    (
                        molecule.atom(n).atomic_number,
                        molecule.atom(n).charge,
                        molecule.atom(n).hybridization == 4,
                        molecule.atom(n).implicit_hydrogens or 0,
                        tuple(
                            sorted((m, int(b)) for m, b in molecule._bonds[n].items())
                        ),
                    )
                    for n in anchors
                )

            def compatible(text):
                molecule = mol(text)
                if site_policy == "legacy":
                    return state(molecule) == state(m)
                return any(
                    all(match[n] == mapping[n] for n in spec["anchors"])
                    for match in query.get_mapping(molecule, limit=limit + 1)
                )

            if all(compatible(at(query_tree, p[:-1])["smiles"]) for p in paths):
                seen.add(anchors)
                results.append((paths[0] + (i,), mapping))
    if cache is not None:
        cache[cache_key] = results, truncated
    return results, truncated


def attach(text, protected_text, spec, transfer):
    return _attach(
        text,
        protected_text,
        tuple(tuple(row) for row in spec["additions"]),
        tuple(spec["mask"]),
        tuple(spec["site_atoms"]),
        tuple(sorted(transfer.items())),
    )


@lru_cache(maxsize=8192)
def _attach(text, protected_text, additions, mask, site_atoms, transferred_atoms):
    transfer = dict(transferred_atoms)
    free, donor = mol(text), mol(protected_text)
    original_free = free.copy()
    original_donor = donor.copy()
    free.kekule()
    donor.kekule()
    mask = set(mask)
    with free:
        for anchor, restored, element, order in additions:
            if donor.has_atom(restored) and restored not in mask:
                a, n = transfer[anchor], transfer[restored]
                if restored not in donor._bonds[anchor] or n not in free._bonds[a]:
                    raise ValueError(
                        "Retained carbonyl oxygen lacks its attachment bond"
                    )
                free.delete_bond(a, n)
                free.add_bond(a, n, int(donor.bond(anchor, restored)))
                continue
            candidates = [
                n
                for n, bond in free._bonds[transfer[anchor]].items()
                if free.atom(n).atomic_symbol == element
                and len(free._bonds[n]) == 1
                and int(bond) == order
            ]
            if len(candidates) != 1:
                raise ValueError("No unique free atom for carbonyl-mask transfer")
            free.delete_atom(candidates[0])
        for n, atom in donor.atoms():
            if n in mask:
                free.add_atom(
                    atom.copy(),
                    transfer[n],
                    charge=atom.charge,
                    is_radical=atom.is_radical,
                )
        for a, b, bond in donor.bonds():
            if a in mask or b in mask:
                if a not in transfer or b not in transfer:
                    raise ValueError("PG mask has an unrecorded boundary attachment")
                free.add_bond(transfer[a], transfer[b], int(bond))
    restore_aromatic_systems(
        free, original_free, excluded={transfer[a] for a, _, _, _ in additions}
    )
    restore_aromatic_systems(free, original_donor, mapping=transfer)
    free.thiele(fix_tautomers=False)
    for n in mask:
        atom = donor.atom(n)
        if atom.stereo is not None and n in donor.stereogenic_tetrahedrons:
            free.add_atom_stereo(
                transfer[n], tuple(transfer[m] for m in donor._bonds[n]), atom.stereo
            )
        elif atom.stereo is not None and n in donor.stereogenic_allenes:
            n1, n2, *_ = donor.stereogenic_allenes[n]
            free.add_atom_stereo(transfer[n], (transfer[n1], transfer[n2]), atom.stereo)
    for (n, m), (n1, n2, *_) in donor.stereogenic_cis_trans.items():
        a, b = donor._stereo_cis_trans_centers[n]
        mark = donor.bond(a, b).stereo
        if mark is not None and (a in mask or b in mask):
            free.add_cis_trans_stereo(
                transfer[n], transfer[m], transfer[n1], transfer[n2], mark
            )
    validate_edit(free, original_free)
    return mapped(free)


def construct_candidate(
    query,
    paths,
    site,
    reference,
    evidence,
    *,
    evidence_paths=None,
    evidence_role="interval",
):
    """Construct the intended mapped candidate without extraction or validation."""
    event = evidence["event"]
    paths = tuple(paths)
    evidence_paths = tuple(evidence_paths) if evidence_paths is not None else paths
    from route_inspector.protection.recovery.boundaries import adjacent

    if evidence_role == "interval":
        compatible_evidence = bool(evidence_paths) and any(
            paths[i : i + len(evidence_paths)] == evidence_paths
            for i in range(len(paths))
        )
    else:
        compatible_evidence = adjacent(paths, evidence_paths, evidence_role)
    if not compatible_evidence:
        raise ValueError(
            "Proposed lifetime must contain the contiguous evidence window or be adjacent on its recorded boundary side"
        )
    added_paths = [p for p in paths if p not in evidence_paths]
    if not evidence["transferable"]:
        raise ValueError("Reference endpoints contain inseparable chemistry")
    tree = primary(query)
    spec = evidence.get("mask_spec") or describe_mask(event)
    input_path, alignment = site
    anchors = {n: alignment[n] for n in spec["anchors"]}
    all_query_maps = {
        n
        for _, node in walk_route_nodes(tree)
        if node["type"] == "mol"
        for n in ids(mol(node["smiles"]))
    }
    next_map = max(all_query_maps) + 1
    transfer = {n: alignment[n] for n in spec["site_atoms"]}
    reference_substrate, donors = source_parts(reference, event)
    context = site_query(reference_substrate["smiles"], spec)
    input_molecule = mol(at(query, input_path)["smiles"])
    context_matches = any(
        all(match[n] == anchors[n] for n in anchors)
        for match in context.get_mapping(input_molecule, limit=257)
    )
    donor_maps = set(spec["mask"]) | {
        n
        for d in donors
        for _, node in walk_route_nodes(d)
        if node["type"] == "mol"
        for n in ids(mol(node["smiles"]))
    }
    if donor_maps & set(spec["anchors"]):
        raise ValueError("Donor overlaps the scaffold site")
    for n in sorted(donor_maps):
        if n in transfer:
            continue
        transfer[n] = next_map
        next_map += 1
    donor_trees = []
    for donor in donors:
        copied = primary(donor)
        for _, node in walk_route_nodes(copied):
            sides = node["smiles"].split(">")
            for i in (0, 2) if len(sides) == 3 else (0,):
                m = mol(sides[i])
                m.remap({n: transfer[n] for n in m})
                sides[i] = mapped(m)
            node["smiles"] = ">".join(sides)
        donor_trees.append(copied)
    bottom = at(tree, input_path)
    free_bottom = deepcopy(bottom)
    input_remapping = {}
    free_reference = mol(reference_substrate["smiles"])
    for anchor, restored, element, order in spec["additions"]:
        candidates = [
            n
            for n, bond in free_reference._bonds[anchor].items()
            if free_reference.atom(n).atomic_symbol == element
            and len(free_reference._bonds[n]) == 1
            and int(bond) == order
        ]
        if len(candidates) != 1:
            raise ValueError("Reference free atom is ambiguous")
        if candidates[0] != restored:
            input_remapping[alignment[restored]] = next_map
            next_map += 1
    for _, node in walk_route_nodes(free_bottom):
        sides = node["smiles"].split(">")
        for i in (0, 2) if len(sides) == 3 else (0,):
            m = mol(sides[i])
            m.remap({n: input_remapping[n] for n in m if n in input_remapping})
            sides[i] = mapped(m)
        node["smiles"] = ">".join(sides)
    molecule_paths = [input_path] + [p[:-1] for p in paths]
    for p in molecule_paths:
        node = at(tree, p)
        node["smiles"] = attach(
            node["smiles"], spec["protected_smiles"], spec, transfer
        )
    bottom["in_stock"] = False
    bottom["children"] = [
        {
            "type": "reaction",
            "smiles": ".".join(n["smiles"] for n in [free_bottom, *donor_trees])
            + ">>"
            + bottom["smiles"],
            "children": [free_bottom, *donor_trees],
            "metadata": {
                "pg_proposal_endpoint": "protection",
                "reference_event_id": event["occurrence_id"],
            },
        }
    ]
    for p in paths:
        reaction = at(tree, p)
        reaction["smiles"] = (
            ".".join(c["smiles"] for c in reaction["children"])
            + ">>"
            + at(tree, p[:-1])["smiles"]
        )
    protected_steps = {p: at(tree, p)["smiles"] for p in paths}
    top_path = paths[-1][:-1]
    top = at(tree, top_path)
    protected_top = deepcopy(top)
    free_top_smiles = at(query, top_path)["smiles"]
    top["smiles"] = free_top_smiles
    top["children"] = [
        {
            "type": "reaction",
            "smiles": protected_top["smiles"] + ">>" + free_top_smiles,
            "children": [protected_top],
            "metadata": {
                "pg_proposal_endpoint": "deprotection",
                "reference_event_id": event["occurrence_id"],
            },
        }
    ]
    strategy = {
        "pg_type": event["pg_type"],
        "site_atom_maps": sorted(anchors.values()),
        "query_interval_paths": [list(p) for p in paths],
        "matched_window_paths": [list(p) for p in evidence_paths],
        "lifetime_steps": len(paths),
        "additional_reaction_paths": [list(p) for p in added_paths],
        "installation_input_path": list(input_path),
        "removal_output_path": list(top_path),
        "reference_atom_transfer": transfer,
        "free_input_atom_remapping": input_remapping,
        "reference_event_id": event["occurrence_id"],
        "site_discovery": "functional_group_core",
        "matches_reference_context": context_matches,
        "changed_anchor_paths": [
            list(p)
            for p in paths
            if anchor_state(at(query, p[:-1])["smiles"], anchors.values())
            != anchor_state(at(query, input_path)["smiles"], anchors.values())
        ],
    }
    if evidence_role != "interval":
        strategy["evidence_role"] = evidence_role
    return (
        tree,
        strategy,
        {
            "attachment": bottom["children"][0]["smiles"],
            "attachment_fixed_maps": sorted(ids(mol(free_bottom["smiles"]))),
            "protected_steps": protected_steps,
            "deprotection": top["children"][0]["smiles"],
        },
    )


def anchor_state(text, anchors):
    molecule = mol(text)
    return tuple(
        (
            n,
            molecule.atom(n).charge,
            molecule.atom(n).implicit_hydrogens or 0,
            tuple(sorted((m, int(b)) for m, b in molecule._bonds[n].items())),
        )
        for n in sorted(molecule)
        if n in anchors
    )


def generate(
    query,
    paths,
    site,
    reference,
    evidence,
    processor,
    *,
    max_selectivity_applications=256,
    query_steps=None,
    evidence_paths=None,
    evidence_role="interval",
    validate_full_interval=False,
    validation_cache=None,
):
    """Only primary query chemistry enters; original-tree metadata is inaccessible."""
    tree, strategy, reactions = construct_candidate(
        query,
        paths,
        site,
        reference,
        evidence,
        evidence_paths=evidence_paths,
        evidence_role=evidence_role,
    )
    if evidence_role != "interval":
        validate_full_interval = True
    event = evidence["event"]
    paths = tuple(tuple(p) for p in strategy["query_interval_paths"])
    added_paths = [tuple(p) for p in strategy["additional_reaction_paths"]]
    top_path = tuple(strategy["removal_output_path"])
    input_path = tuple(strategy["installation_input_path"])
    anchors = strategy["site_atom_maps"]
    cache_key = tree_key(tree)
    cached = validation_cache.get(cache_key) if validation_cache is not None else None
    if cached is None:
        checks = validate(
            tree,
            query["smiles"],
            edge_cache=validation_cache.setdefault("edges", {})
            if validation_cache is not None
            else None,
        )
        if hasattr(processor, "recovery_lifecycles"):
            detected_events = processor.recovery_lifecycles(tree)
        else:
            process = getattr(
                processor, "process_validated_route", processor.process_route
            )
            detected = process(
                "proposal", tree, dataset_id="pg_recovery", source_identity="generated"
            )
            detected_events = tuple(
                (
                    e.pg_type,
                    e.source_type,
                    e.terminus,
                    frozenset(e.protected_atom_ids),
                    e.lifetime_steps,
                )
                for e in detected.events
            )
        if validation_cache is not None:
            validation_cache[cache_key] = (checks, detected_events)
    else:
        checks, detected_events = cached
    # Validate actual re-detection, not just successful molecule sanitization.
    found = [
        e
        for e in detected_events
        if e
        == (
            event["pg_type"],
            "introduced",
            "not_preserved",
            frozenset(anchors),
            len(paths),
        )
    ]
    if not found:
        if hasattr(processor, "recovery_lifecycles") and hasattr(
            processor, "process_validated_route"
        ):
            # Keep the original detailed extraction error on rejected trees.
            # Successful candidates need no discarded library records; failures
            # still receive full preparation diagnostics instead of hiding them
            # behind the generic lifecycle message.
            processor.process_validated_route(
                "proposal", tree, dataset_id="pg_recovery", source_identity="generated"
            )
        raise ValueError("Generated lifecycle failed independent PG re-detection")
    reverse_rule = processor.profile["rule_extraction_config"]["reverse_rule"]
    protection_rule = event.get("protection_rule_smarts")
    if not protection_rule:
        source_step, _ = processor.rule_extractor.extract(
            at(reference, event["protection_reaction_node_path"])["smiles"]
        )
        protection_rule = source_step.rule_smarts if source_step else ""
    protection = replay(
        protection_rule,
        reactions["attachment"],
        reverse_rule=reverse_rule,
        limit=max_selectivity_applications,
        fixed_maps=reactions["attachment_fixed_maps"],
        attachment_sites=compatible_attachment_sites(
            reactions["attachment"].split(">")[0],
            reference,
            event,
            reactions["attachment_fixed_maps"],
            mask=evidence.get("mask_spec"),
        ),
    )
    protection["query_input_path"] = list(input_path)
    protection["reference_event_id"] = event["occurrence_id"]
    if not top_path:
        after = {"status": "not_applicable", "reason": "terminal_deprotection"}
    else:
        next_path = top_path[:-1]
        next_reaction = at(query, next_path)["smiles"]
        try:
            next_rule = (query_steps or {}).get(next_path)
            if next_rule is None:
                step, _ = processor.rule_extractor.extract(next_reaction)
                next_rule = step.rule_smarts if step else ""
            after = replay(
                next_rule,
                next_reaction,
                reverse_rule=reverse_rule,
                limit=max_selectivity_applications,
                fixed_maps=ids(mol(next_reaction.split(">")[0])),
            )
        except Exception as exc:
            after = {
                "status": "unverified",
                "reason": "rule_extraction_error",
                "message": str(exc),
            }
        after["query_reaction_path"] = list(next_path)
    selectivity = {"attachment": protection, "post_deprotection": after}
    if strategy["changed_anchor_paths"]:
        validate_full_interval = True
    if added_paths or validate_full_interval:
        # Query rules are extracted from the free route, then executed against
        # the actual protected substrate and partners. Do not extract a rule
        # from a fabricated protected reaction and use it to validate itself.
        interval_checks = []
        for path in paths if validate_full_interval else added_paths:
            rule = (query_steps or {}).get(path)
            if rule is None:
                step, _ = processor.rule_extractor.extract(at(query, path)["smiles"])
                rule = step.rule_smarts if step else ""
            reaction = reactions["protected_steps"][path]
            result = replay(
                rule,
                reaction,
                reverse_rule=reverse_rule,
                limit=max_selectivity_applications,
                fixed_maps=ids(mol(reaction.split(">")[0])),
            )
            result["query_reaction_path"] = list(path)
            interval_checks.append(result)
        failed = [r for r in interval_checks if r["status"] != "passed"]
        selectivity[
            "protected_interval" if validate_full_interval else "protected_extension"
        ] = {
            "status": failed[0]["status"] if failed else "passed",
            "reason": failed[0]["reason"]
            if failed
            else (
                "all_interval_reactions_replayed"
                if validate_full_interval
                else "all_added_reactions_replayed"
            ),
            "truncated": any(r["truncated"] for r in interval_checks),
            "steps": interval_checks,
        }
    # Removal is mandatory even for exact windows with unchanged anchor states.
    removal = reactions["deprotection"]
    try:
        removal_rule = event.get("deprotection_rule_smarts")
        if not removal_rule:
            step, _ = processor.rule_extractor.extract(
                at(reference, event["deprotection_reaction_node_path"])["smiles"]
            )
            removal_rule = step.rule_smarts if step else ""
        selectivity["deprotection"] = replay(
            removal_rule,
            removal,
            reverse_rule=reverse_rule,
            limit=max_selectivity_applications,
            fixed_maps=ids(mol(removal.split(">")[0])),
        )
    except Exception as exc:
        selectivity["deprotection"] = {
            "status": "unverified",
            "reason": "rule_extraction_error",
            "message": str(exc),
            "reaction_smiles": removal,
        }
    selectivity["deprotection"]["query_output_path"] = list(top_path)
    selectivity["deprotection"]["reference_event_id"] = event["occurrence_id"]
    return (
        tree,
        {
            **checks,
            "pg_lifecycle": True,
            "selectivity": selectivity,
        },
        strategy,
    )


def compatible_attachment_sites(text, reference, event, scaffold_maps, *, mask=None):
    """Enumerate all eligible scaffold sites, including alternatives to the proposal."""
    spec = mask if mask is not None else describe_mask(event)
    substrate, _ = source_parts(reference, event)
    query = site_query(
        substrate["smiles"],
        spec,
        generalized=True,
        protected_text=event["protection_reaction_smiles"].split(">")[2],
    )
    molecule = mol(text)
    scaffold_maps = set(scaffold_maps)
    protected = mol(event["protection_reaction_smiles"].split(">")[2])
    # Event anchors identify the functional group, not necessarily the atom
    # bonded to the donor: a carboxyl event is anchored at C, but O-methylation
    # attaches at its retained oxygen. Track the actual mask boundary.
    donor_atoms = ids(protected) - ids(mol(substrate["smiles"]))
    boundary = {
        m for n in donor_atoms for m in protected._bonds[n] if m not in donor_atoms
    }
    return {
        tuple(sorted(match[n] for n in query.pattern if n in boundary))
        for match in query.get_mapping(molecule)
        if all(match[n] in scaffold_maps for n in spec["anchors"])
    }
