"""Fallback PG evidence lookup using smaller, exactly matched rule graphs."""

from collections import defaultdict
from functools import lru_cache

from route_inspector.protection.recovery.evidence import identity
from route_inspector.rules.graph import (
    graph_coarse_signature,
    labelled_graphs_are_isomorphic,
    reaction_center_graph,
)

RETRIEVAL_POLICY = {
    "version": 2,
    "secondary_projection": "reaction_center_and_one_neighbor_shell",
    "tertiary_projection": "reaction_center_only_environment_0",
    "tertiary_gate": "no_exact_or_reduced_match_for_same_query_window_and_pg_type_across_both_channels",
    "tertiary_budget": "separate_attempt_and_proposal_caps_per_route",
    "retained_labels": "all_original_atom_and_bond_labels_plus_center_membership",
    "comparison": "exact_labelled_graph_isomorphism_in_sequence_order",
    "priority": "exact_then_reduced_context_then_center_only_including_each_tiers_lifetime_extensions",
    "validation": "full_query_rules_replayed_across_entire_protected_interval",
}


@lru_cache(maxsize=32768)
def projection(rule, environment=1):
    """Preserve every changed centre with zero or one neighbour shell.

    This graph is an index/evidence representation, never an executable rule.
    Environment 1 includes unchanged C=O bonds at acyl centres; environment 0
    deliberately omits unchanged neighbours. No retained labels are weakened; centre
    membership cannot swap with a context atom during graph comparison.
    """
    if environment not in {0, 1}:
        raise ValueError("PG retrieval supports only environment 0 or 1")
    full = identity(rule).rule_graph
    centers = {a["node"] for a in reaction_center_graph(full)["atoms"]}
    retained = centers.copy()
    if environment:
        retained.update(
            node
            for bond in full["bonds"]
            if centers.intersection(bond["nodes"])
            for node in bond["nodes"]
        )
    return {
        "graph_schema_version": full["graph_schema_version"],
        "atoms": [
            {**a, "label": {**a["label"], "reaction_center": a["node"] in centers}}
            for a in full["atoms"]
            if a["node"] in retained
        ],
        "bonds": [b for b in full["bonds"] if set(b["nodes"]) <= retained],
    }


@lru_cache(maxsize=32768)
def step_key(rule, environment=1):
    return graph_coarse_signature(projection(rule, environment))


def key(rules, environment=1):
    return tuple(step_key(rule, environment) for rule in rules)


def equivalent(left, right, environment=1):
    return len(left) == len(right) and all(
        labelled_graphs_are_isomorphic(
            projection(a, environment), projection(b, environment)
        )
        for a, b in zip(left, right, strict=True)
    )


def build_index(exact_index, diagnostics, environment=1):
    """Derive a separate index without modifying persisted N1 identities."""
    index, reported = defaultdict(list), set()
    for support in exact_index.values():
        for evidence in support:
            try:
                lookup = key(evidence["rules"], environment)
            except (ValueError, TypeError) as exc:
                token = (evidence["event"]["occurrence_id"], evidence["mode"], str(exc))
                if token not in reported:
                    reported.add(token)
                    diagnostics.append(
                        {
                            "stage": "reference_retrieval"
                            if environment == 1
                            else "reference_center_retrieval",
                            "route_id": evidence["route_id"],
                            "event_id": evidence["event"]["occurrence_id"],
                            "reference_paths": evidence["reference_paths"],
                            "match_mode": evidence["mode"],
                            "message": str(exc),
                        }
                    )
                continue
            index[lookup].append(
                {
                    **evidence,
                    "mode": evidence["mode"].replace(
                        "_exact",
                        "_reduced_context" if environment == 1 else "_center_only",
                    ),
                }
            )
    return index
