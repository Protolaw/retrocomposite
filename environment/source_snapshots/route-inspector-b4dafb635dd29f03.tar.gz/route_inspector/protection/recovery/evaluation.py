"""Recovery labels, applied only after candidate generation and validation."""

from route_inspector.protection.recovery.trees import compare_trees, ids, mol
from route_inspector.routes.access import walk_route_nodes


def _surviving_atom_correspondence(proposal, original, strategy, stripping):
    """Seed only retained query identities; transferred reference maps are local.

    Hints are checked against every node by compare_trees and fall back to an
    unconstrained search on failure. They never participate in proposal selection.
    """

    def atom_ids(tree):
        return set().union(
            *(
                ids(mol(n["smiles"]))
                for _, n in walk_route_nodes(tree)
                if n["type"] == "mol"
            )
        )

    remap = {int(k): int(v) for k, v in stripping.get("atom_remapping", {}).items()}
    transferred = set(strategy.get("reference_atom_transfer", {}).values())
    input_remap = strategy.get("free_input_atom_remapping", {})
    uncertain = transferred | {int(k) for k in input_remap} | set(input_remap.values())
    present = atom_ids(proposal)
    candidates = {}
    for original_id in atom_ids(original):
        proposed_id = remap.get(original_id, original_id)
        if proposed_id in present and proposed_id not in uncertain:
            candidates.setdefault(proposed_id, []).append(original_id)
    return {n: values[0] for n, values in candidates.items() if len(values) == 1}


def evaluate(proposal, strategy, stripping):
    original = stripping.get("original_tree")
    if original is None:
        return {
            "status": "comparison_unresolved",
            "reason": "No original tree recorded",
        }
    comparison = compare_trees(
        proposal,
        original,
        atom_mapping=_surviving_atom_correspondence(
            proposal, original, strategy, stripping
        ),
    )
    correspondence = {
        tuple(r["original_path"]): tuple(r["new_path"])
        for r in stripping["node_correspondence"]
    }
    remap = {int(k): v for k, v in stripping["atom_remapping"].items()}
    recovered = []
    for record in stripping["events"]:
        event = record["event"]
        expected_paths = [
            correspondence[tuple(p)]
            for p in event["interval_reaction_node_paths"]
            if tuple(p) in correspondence
        ]
        if (
            event["pg_type"] == strategy["pg_type"]
            and sorted(remap.get(a, a) for a in event["protected_atom_ids"])
            == strategy["site_atom_maps"]
            and expected_paths == [tuple(p) for p in strategy["query_interval_paths"]]
        ):
            recovered.append(event["occurrence_id"])
    status = (
        "original_route_recovered"
        if comparison == "equal"
        else "comparison_unresolved"
        if comparison == "unresolved"
        else "partial_strategy_recovery"
        if recovered
        else "different_valid_proposal"
    )
    return {
        "status": status,
        "full_tree_comparison": comparison,
        "recovered_event_ids": recovered,
        "original_event_count": len(stripping["events"]),
    }
