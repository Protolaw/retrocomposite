from __future__ import annotations

import hashlib
import json
import statistics
import sys
import traceback
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Any, Iterable

import route_inspector.routes.access as route_access
from route_inspector import chemistry
from route_inspector.chemistry.standardization import (
    resolve_remove_reagents_standardizer,
)
from route_inspector.composite_rules.composite import (
    query_cgr_coarse_signature,
    query_cgr_isomorphic,
    rule_query_cgr,
)
from route_inspector.infrastructure.artifacts import reference_sort_key, split_cell
from route_inspector.infrastructure.runtime import normalize_n_cpu
from route_inspector.infrastructure.text import read_tsv_rows
from route_inspector.protection.chython_rules import ProtectionRule
from route_inspector.routes import normalization as routes
from route_inspector.rules.config import RuleExtractionSettings
from route_inspector.rules.extraction import SynPlannerRuleExtractor
from route_inspector.rules.models import ReactionRuleStep
from route_inspector.rules.preparation import route_target_smiles
from route_inspector.tactics.rrseq.artifacts import expand_rrseq_tsv_paths
from route_inspector.tactics.rrseq.enumeration import (
    valid_rrseq_cons_sequence_occurrences,
)
from route_inspector.tactics.rrseq.unwrap import split_rrseq

_PROTECTION_WORKER_CONFIG: ProtectionAnalysisConfig | None = None
_PROTECTION_WORKER_RULES: dict[str, ProtectionRule] | None = None
_PROTECTION_WORKER_RRSEQ_INDEX: dict[str, RRseqFamily] | None = None
_PROTECTION_WORKER_RULE_EXTRACTOR: SynPlannerRuleExtractor | None = None

PROTECTION_TRACE_EVENT_SCHEMA_VERSION = 1


@dataclass
class ProtectionAnalysisConfig:
    min_rrseq_cons_size: int = 2
    max_rrseq_cons_size: int = 6
    similarity_threshold: float = 0.70
    include_multicenter: bool = True
    deprotection_first: bool = True
    querycgr_compare: bool = True
    keep_ambiguous_traces: bool = True
    collect_interval_rules: bool = True
    ignore_errors: bool = False
    write_debug_json: bool = False
    write_debug_svg: bool = False
    max_trace_depth: int = 50
    raw_config: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_yaml(cls, path: Path | None) -> "ProtectionAnalysisConfig":
        """Load protection-analysis configuration from a YAML file.

        The helper keeps protection detection, route tracing, and summary generation
        separate while sharing the same normalized route index.
        """
        if path is None:
            return cls()
        import yaml

        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        rrseq = data.get("rrseq_cons") or data.get("rrseqs") or {}
        multicenter = data.get("multicenter") or {}
        tracing = data.get("tracing") or {}
        outputs = data.get("outputs") or {}
        errors = data.get("error_handling") or {}
        return cls(
            min_rrseq_cons_size=int(
                rrseq.get("min_rrseq_cons_size", rrseq.get("min_rrseq_size", 2))
            ),
            max_rrseq_cons_size=int(
                rrseq.get("max_rrseq_cons_size", rrseq.get("max_rrseq_size", 6))
            ),
            similarity_threshold=float(rrseq.get("similarity_threshold", 0.70)),
            include_multicenter=bool(multicenter.get("include_multicenter", True)),
            deprotection_first=bool(multicenter.get("deprotection_first", True)),
            querycgr_compare=bool(rrseq.get("compare_by_querycgr", True)),
            keep_ambiguous_traces=bool(tracing.get("keep_ambiguous_traces", True)),
            collect_interval_rules=bool(
                rrseq.get(
                    "collect_interval_rrseq_cons",
                    rrseq.get("collect_interval_rrseqs", True),
                )
            ),
            ignore_errors=bool(errors.get("ignore_errors", False)),
            write_debug_json=bool(outputs.get("write_debug_json", False)),
            write_debug_svg=bool(outputs.get("write_debug_svg", False)),
            max_trace_depth=int(tracing.get("max_trace_depth", 50)),
            raw_config=data,
        )

    def with_cli_overrides(
        self, args: ProtectionOverrides
    ) -> "ProtectionAnalysisConfig":
        """Return a config copy with CLI override values applied.

        The helper keeps protection detection, route tracing, and summary generation
        separate while sharing the same normalized route index.
        """
        min_size = getattr(
            args,
            "min_rrseq_cons_size",
            getattr(args, "min_rrseq_size", None),
        )
        max_size = getattr(
            args,
            "max_rrseq_cons_size",
            getattr(args, "max_rrseq_size", None),
        )
        if min_size is not None:
            self.min_rrseq_cons_size = min_size
        if max_size is not None:
            self.max_rrseq_cons_size = max_size
        if getattr(args, "similarity_threshold", None) is not None:
            self.similarity_threshold = args.similarity_threshold
        if getattr(args, "include_multicenter", False):
            self.include_multicenter = True
        if getattr(args, "deprotection_first", False):
            self.deprotection_first = True
        if getattr(args, "querycgr_compare", False):
            self.querycgr_compare = True
        if getattr(args, "write_debug_json", False):
            self.write_debug_json = True
        if getattr(args, "write_debug_svg", False):
            self.write_debug_svg = True
        if getattr(args, "ignore_errors", False):
            self.ignore_errors = True
        return self


@dataclass
class MoleculeRecord:
    node_id: str
    node: dict[str, Any]
    smiles: str
    mapped_smiles: str
    depth: int
    parent_reaction_id: str | None = None
    node_path: tuple[int, ...] = ()


@dataclass
class ReactionRecord:
    node_id: str
    node: dict[str, Any]
    reaction_smiles: str
    depth: int
    parent_mol_id: str
    child_mol_ids: tuple[str, ...] = ()
    node_path: tuple[int, ...] = ()


@dataclass
class RouteIndex:
    route: dict[str, Any]
    target_smiles: str
    molecule_records: dict[str, MoleculeRecord]
    reaction_records: dict[str, ReactionRecord]
    reaction_order: tuple[str, ...]
    children_by_mol: dict[str, tuple[str, ...]]
    parent_mol_by_reaction: dict[str, str]
    child_mols_by_reaction: dict[str, tuple[str, ...]]


@dataclass(frozen=True)
class DeprotectionMatch:
    pg_type: str
    rule_id: str
    rule: ProtectionRule
    deprotection_node_id: str
    protected_precursor_node_id: str | None
    protected_precursor_smiles: str
    deprotected_product_smiles: str
    protected_atom_ids: tuple[int, ...]
    protected_query_atom_ids: tuple[int, ...]
    raw_mapping: tuple[tuple[int, int], ...]
    confidence: str
    multicenter_status: str
    n_other_reaction_centers: int
    n_matching_pg_sites_before_deprotection: int
    n_sites_deprotected: int
    selective_deprotection: bool
    ambiguous_rule_match: bool = False
    multiple_deprotection_rules: bool = False
    matched_rule_ids: tuple[str, ...] = ()
    matched_rule_names: tuple[str, ...] = ()


@dataclass
class TraceResult:
    trace_status: str
    source_type: str
    source_node_id: str | None = None
    protection_node_id: str | None = None
    stock_node_id: str | None = None
    stock_smiles: str = ""
    source_fragment_atom_ids: tuple[int, ...] = ()
    visited_reaction_ids: tuple[str, ...] = ()
    protected_molecule_ids: tuple[str, ...] = ()
    failure_reason: str = ""
    last_successful_node_id: str = ""
    last_successful_smiles: str = ""
    candidate_next_nodes: tuple[str, ...] = ()
    n_candidate_traces: int = 0
    debug_message: str = ""


@dataclass
class DeprotectionEvent:
    event_id: str
    route_id: str
    target_smiles: str
    pg_type: str
    protected_functional_group: str
    source_type: str
    trace_status: str
    confidence: str
    deprotection_node_id: str
    deprotection_reaction_smiles: str
    protection_node_id: str = ""
    protection_reaction_smiles: str = ""
    stock_node_id: str = ""
    stock_smiles: str = ""
    protected_precursor_smiles: str = ""
    deprotected_product_smiles: str = ""
    protected_atom_ids: tuple[int, ...] = ()
    source_fragment_atom_ids: tuple[int, ...] = ()
    protected_substructure_smiles: str = ""
    depth_deprotection_from_target: int = 0
    depth_source_from_target: int | None = None
    lifetime_steps: int = 0
    n_intervening_steps: int = 0
    multicenter_status: str = "unknown"
    n_other_reaction_centers: int = 0
    n_matching_pg_sites_before_deprotection: int = 0
    n_sites_deprotected: int = 0
    selective_deprotection: bool = False
    multiple_deprotection_rules: bool = False
    matched_deprotection_rules: tuple[str, ...] = ()
    failure_reason: str = ""
    interval_reaction_ids: tuple[str, ...] = ()
    deprotection_reaction_node_path: tuple[int, ...] = ()
    protected_precursor_molecule_node_path: tuple[int, ...] = ()
    protection_reaction_node_path: tuple[int, ...] = ()
    stock_molecule_node_path: tuple[int, ...] = ()
    interval_reaction_node_paths: tuple[tuple[int, ...], ...] = ()
    protected_molecule_node_paths: tuple[tuple[int, ...], ...] = ()
    trace_last_successful_node_path: tuple[int, ...] = ()
    trace_last_successful_node_id: str = ""
    trace_last_successful_smiles: str = ""
    trace_candidate_next_nodes: tuple[str, ...] = ()
    trace_n_candidate_traces: int = 0
    trace_debug_message: str = ""


@dataclass
class IntervalRuleObservation:
    event_id: str
    route_id: str
    pg_type: str
    trace_status: str
    interval_step_ids: tuple[str, ...]
    interval_reaction_smiles: tuple[str, ...]
    single_step_rules: tuple[str, ...]
    rrseq_size: int
    rrseq_smarts: str
    rrseq_querycgr: str
    rrseq_querycgr_hash: str
    rrseq_family_id: str
    rrseq_support_in_routes: int
    is_full_interval_rule: bool
    is_adjacent_window_rule: bool
    macro_depth_saving: int
    min_distance_pg_to_reaction_center: str = ""
    median_distance_pg_to_reaction_center: str = ""
    first_reaction_after_source: str = ""
    last_reaction_before_deprotection: str = ""


@dataclass(frozen=True)
class ProtectionSingleRuleObservation:
    route_id: str
    pg_type: str
    rule_smarts: str
    reaction_smiles: str
    event_id: str


@dataclass
class ProtectionSingleRuleAggregate:
    representative_rule: str
    query_cgr: Any
    rule_count: int = 0
    pg_types: set[str] = field(default_factory=set)
    route_ids: set[str] = field(default_factory=set)
    event_ids: set[str] = field(default_factory=set)
    reaction_smiles: set[str] = field(default_factory=set)


@dataclass
class RRseqFamily:
    family_id: str
    rrseq: str
    sequence: tuple[str, ...]
    querycgr_hash: str
    querycgr: str
    route_ids: set[str] = field(default_factory=set)
    target_molecules: set[str] = field(default_factory=set)
    source_rows: set[str] = field(default_factory=set)


@dataclass
class ProtectionAnalysisResult:
    route_stats_rows: list[dict[str, Any]]
    event_rows: list[dict[str, Any]]
    interval_rule_rows: list[dict[str, Any]]
    single_rule_rows: list[dict[str, Any]]
    aggregate_single_rule_rows: list[dict[str, Any]]
    group_summary_rows: list[dict[str, Any]]
    rule_family_rows: list[dict[str, Any]]
    trace_failure_rows: list[dict[str, Any]]
    summary: dict[str, Any]
    debug_routes: dict[str, dict[str, Any]] = field(default_factory=dict)
    trace_event_records: list[dict[str, Any]] = field(default_factory=list)


def is_stock_molecule(node: dict[str, Any]) -> bool:
    """Return whether stock molecule matches the expected condition.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    return bool(node.get("in_stock") or (node.get("metadata") or {}).get("in_stock"))


def build_route_index(
    route: dict[str, Any],
    *,
    normalized: bool = False,
) -> RouteIndex:
    """Build a route index, normalizing only when the caller has not done so."""

    if not normalized:
        route = routes.normalized_route_for_analysis(route)
    mol_counter = 0
    rxn_counter = 0
    molecule_records: dict[str, MoleculeRecord] = {}
    reaction_records: dict[str, ReactionRecord] = {}
    reaction_order: list[str] = []
    children_by_mol: dict[str, tuple[str, ...]] = {}
    parent_mol_by_reaction: dict[str, str] = {}
    child_mols_by_reaction: dict[str, tuple[str, ...]] = {}

    def next_mol_id() -> str:
        """Return the next synthetic molecule-node ID for the route index.

        The helper keeps protection detection, route tracing, and summary generation
        separate while sharing the same normalized route index.
        """
        nonlocal mol_counter
        node_id = f"m{mol_counter}"
        mol_counter += 1
        return node_id

    def next_rxn_id() -> str:
        """Return the next synthetic reaction-node ID for the route index.

        The helper keeps protection detection, route tracing, and summary generation
        separate while sharing the same normalized route index.
        """
        nonlocal rxn_counter
        node_id = f"r{rxn_counter}"
        rxn_counter += 1
        return node_id

    def visit_molecule(
        node: dict[str, Any],
        *,
        depth: int,
        parent_reaction_id: str | None,
        node_path: tuple[int, ...],
    ) -> str:
        """Visit one molecule during recursive route traversal.

        The helper keeps protection detection, route tracing, and summary generation
        separate while sharing the same normalized route index.
        """
        mol_id = str(node.get("node_id") or node.get("id") or next_mol_id())
        molecule_records[mol_id] = MoleculeRecord(
            node_id=mol_id,
            node=node,
            smiles=route_access.molecule_node_smiles(node),
            mapped_smiles=route_access.molecule_node_mapped_smiles(node),
            depth=depth,
            parent_reaction_id=parent_reaction_id,
            node_path=node_path,
        )
        reaction_ids: list[str] = []
        for child_index, child in enumerate(node.get("children", []) or []):
            if not isinstance(child, dict) or child.get("type") != "reaction":
                continue
            rxn_id = str(child.get("node_id") or child.get("id") or next_rxn_id())
            reaction_ids.append(rxn_id)
            parent_mol_by_reaction[rxn_id] = mol_id
            child_mol_ids = visit_reaction(
                child,
                node_id=rxn_id,
                depth=depth + 1,
                parent_mol_id=mol_id,
                node_path=node_path + (child_index,),
            )
            child_mols_by_reaction[rxn_id] = tuple(child_mol_ids)
        children_by_mol[mol_id] = tuple(reaction_ids)
        return mol_id

    def visit_reaction(
        node: dict[str, Any],
        *,
        node_id: str,
        depth: int,
        parent_mol_id: str,
        node_path: tuple[int, ...],
    ) -> list[str]:
        """Visit one reaction during recursive route traversal.

        The helper keeps protection detection, route tracing, and summary generation
        separate while sharing the same normalized route index.
        """
        child_mol_ids: list[str] = []
        for child_index, child in enumerate(node.get("children", []) or []):
            if isinstance(child, dict) and child.get("type") == "mol":
                child_mol_ids.append(
                    visit_molecule(
                        child,
                        depth=depth,
                        parent_reaction_id=node_id,
                        node_path=node_path + (child_index,),
                    )
                )
        reaction_records[node_id] = ReactionRecord(
            node_id=node_id,
            node=node,
            reaction_smiles=route_access.reaction_smiles_from_node(node),
            depth=depth,
            parent_mol_id=parent_mol_id,
            child_mol_ids=tuple(child_mol_ids),
            node_path=node_path,
        )
        reaction_order.append(node_id)
        return child_mol_ids

    visit_molecule(route, depth=0, parent_reaction_id=None, node_path=())
    return RouteIndex(
        route=route,
        target_smiles=route_target_smiles(route),
        molecule_records=molecule_records,
        reaction_records=reaction_records,
        reaction_order=tuple(reaction_order),
        children_by_mol=children_by_mol,
        parent_mol_by_reaction=parent_mol_by_reaction,
        child_mols_by_reaction=child_mols_by_reaction,
    )


def reaction_center_atoms(reaction_smiles: str) -> frozenset[int]:
    """Return reaction center atoms from a reaction or route node.

    It relies on globally consistent atom maps so protected atom IDs remain meaningful
    while tracing protection and deprotection events.
    """
    try:
        reaction = chemistry.parse_reaction(reaction_smiles)
        standardizer_type = resolve_remove_reagents_standardizer()
        standardized = standardizer_type()(reaction)
        return frozenset((~standardized).center_atoms)
    except Exception:
        return frozenset()


def has_protected_pattern_for_atoms(
    molecule: Any,
    rule: ProtectionRule,
    protected_atom_ids: Iterable[int],
) -> bool:
    """Return whether the input contains protected pattern for atoms.

    It relies on globally consistent atom maps so protected atom IDs remain meaningful
    while tracing protection and deprotection events.
    """
    protected_atom_set = set(protected_atom_ids)
    for atoms, _mapping in matching_site_mappings(molecule, rule):
        kept_atoms = set(atoms)
        if kept_atoms and kept_atoms <= protected_atom_set:
            return True
    return False


def has_protected_pattern(molecule: Any, rule: ProtectionRule) -> bool:
    """Return whether the input contains protected pattern.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    return bool(matching_sites(molecule, rule))


def molecule_node_has_protected_pattern(
    molecule_record: MoleculeRecord,
    rule: ProtectionRule,
) -> bool:
    """Return molecule node has protected pattern from a molecule or molecule node.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    molecule_smiles = molecule_record.mapped_smiles or molecule_record.smiles
    if not molecule_smiles:
        return False
    try:
        return has_protected_pattern(chemistry.parse_molecule(molecule_smiles), rule)
    except Exception:
        return False


def molecule_record_has_protected_atoms(
    molecule_record: MoleculeRecord,
    rule: ProtectionRule,
    protected_atom_ids: Iterable[int],
) -> bool:
    """Return molecule record has protected atoms from a molecule or molecule node.

    It relies on globally consistent atom maps so protected atom IDs remain meaningful
    while tracing protection and deprotection events.
    """
    molecule_smiles = molecule_record.mapped_smiles or molecule_record.smiles
    if not molecule_smiles:
        return False
    try:
        return has_protected_pattern_for_atoms(
            chemistry.parse_molecule(molecule_smiles),
            rule,
            protected_atom_ids,
        )
    except Exception:
        return False


def _mapped_fragment_signature(
    molecule: Any,
    atom_ids: Iterable[int],
) -> tuple[tuple[Any, ...], tuple[tuple[int, int, int], ...]] | None:
    """Return the internal mapped structure of one exact atom lineage.

    Boundary degree, implicit hydrogens, and hybridization are intentionally omitted:
    incorporating a protected synthon changes the protected atom's external
    environment while retaining the already assembled PG fragment itself.
    """

    selected = frozenset(int(atom_id) for atom_id in atom_ids)
    if not selected or not selected <= set(molecule):
        return None
    atoms = tuple(
        (
            atom_id,
            int(molecule.atom(atom_id).atomic_number),
            molecule.atom(atom_id).isotope,
            int(molecule.atom(atom_id).charge),
            bool(molecule.atom(atom_id).is_radical),
        )
        for atom_id in sorted(selected)
    )
    bonds = tuple(
        sorted(
            (
                min(int(atom_1), int(atom_2)),
                max(int(atom_1), int(atom_2)),
                int(bond),
            )
            for atom_1, atom_2, bond in molecule.bonds()
            if int(atom_1) in selected and int(atom_2) in selected
        )
    )
    return atoms, bonds


PG_ORIGIN_POLICY = {
    "phthalimide_nitrogen_donor_exclusion": 1,
    "target_retained_fragment_continuity": 1,
}


def phthalimide_nitrogen_donor(index, pg_type, precursor_id, anchors, fragment):
    """Reject an observed phthalimide nitrogen donor, not an existing amine.

    An unsubstituted phthalimide ancestor carries the mapped nitrogen and the
    complete mask but no external heavy-atom attachment at that nitrogen.
    Follow only the precursor subtree and require the same internal fragment.
    Stock N-substituted phthalimides with unknown earlier history remain valid.
    """
    if pg_type != "amine_phthalimide" or precursor_id is None:
        return False
    precursor = index.molecule_records[precursor_id]
    fragment = frozenset(fragment)
    molecule = chemistry.parse_molecule(precursor.mapped_smiles or precursor.smiles)
    expected = _mapped_fragment_signature(molecule, fragment)
    if expected is None:
        return False
    for record in index.molecule_records.values():
        if record.node_path[: len(precursor.node_path)] != precursor.node_path:
            continue
        candidate = chemistry.parse_molecule(record.mapped_smiles or record.smiles)
        if _mapped_fragment_signature(candidate, fragment) != expected:
            continue
        if all(
            not any(
                (a == anchor and b not in fragment)
                or (b == anchor and a not in fragment)
                for a, b, _bond in candidate.bonds()
                if candidate.atom(a).atomic_number > 1
                and candidate.atom(b).atomic_number > 1
            )
            for anchor in anchors
        ):
            return True
    return False


def _protected_synthon_stock_candidates(
    index: RouteIndex,
    reaction_ids: Iterable[str],
    match: DeprotectionMatch,
) -> tuple[str, ...]:
    """Find stock reactants carrying the complete mapped PG fragment.

    Strict PG SMARTS can stop matching when a protected building block has a
    different boundary degree before coupling (for example ``BocNH2`` versus an
    ``N``-substituted Boc carbamate). Exact mapped internal-fragment continuity
    distinguishes that stock transfer from genuine in-route PG installation.
    """

    fragment_atom_ids = tuple(
        sorted({int(target) for _query, target in match.raw_mapping})
    )
    if match.protected_precursor_node_id is None:
        return ()
    precursor_record = index.molecule_records.get(match.protected_precursor_node_id)
    if precursor_record is None:
        return ()
    precursor_smiles = precursor_record.mapped_smiles or precursor_record.smiles
    if not precursor_smiles:
        return ()
    try:
        protected_precursor = chemistry.parse_molecule(precursor_smiles)
    except Exception:
        return ()
    expected = _mapped_fragment_signature(protected_precursor, fragment_atom_ids)
    if expected is None:
        return ()

    candidates: set[str] = set()
    for reaction_id in reaction_ids:
        reaction = index.reaction_records[reaction_id]
        for molecule_id in reaction.child_mol_ids:
            record = index.molecule_records[molecule_id]
            if not is_stock_molecule(record.node):
                continue
            molecule_smiles = record.mapped_smiles or record.smiles
            if not molecule_smiles:
                continue
            try:
                molecule = chemistry.parse_molecule(molecule_smiles)
            except Exception:
                continue
            if _mapped_fragment_signature(molecule, fragment_atom_ids) == expected:
                candidates.add(molecule_id)
    return tuple(sorted(candidates))


def matching_site_mappings(
    molecule: Any,
    rule: ProtectionRule,
) -> list[tuple[tuple[int, ...], dict[int, int]]]:
    """Return atom mappings for protection-rule matches in a molecule.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    sites: list[tuple[tuple[int, ...], dict[int, int]]] = []
    mappings = list(rule.query.get_mapping(molecule))
    if rule.name == "heteroaryl_n_thp":
        from route_inspector.protection.endpoints import lactam_thp_mappings

        mappings.extend(lactam_thp_mappings(molecule))
    for mapping in mappings:
        atoms = tuple(
            mapping[query_atom]
            for query_atom in rule.atoms_to_keep
            if query_atom in mapping
        )
        if len(atoms) == len(rule.atoms_to_keep):
            protected_atom_ids = tuple(int(atom_id) for atom_id in atoms)
            if skip_rule_match(rule, molecule, protected_atom_ids):
                continue
            sites.append(
                (
                    protected_atom_ids,
                    {int(source): int(target) for source, target in mapping.items()},
                )
            )
    return sites


def matching_sites(molecule: Any, rule: ProtectionRule) -> list[tuple[int, ...]]:
    """Return matched protecting-group atom sets in a molecule.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    return [atoms for atoms, _mapping in matching_site_mappings(molecule, rule)]


def oxygen_attached_to_carbonyl_carbon(molecule: Any, atom_id: int) -> bool:
    """Return whether an oxygen atom is bonded to a carbonyl carbon.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    if atom_id not in set(molecule):
        return False
    atom = molecule.atom(atom_id)
    if atom.atomic_number != 8:
        return False
    try:
        neighbors = molecule._bonds[atom_id]
    except Exception:
        return False
    for neighbor_id in neighbors:
        neighbor = molecule.atom(neighbor_id)
        if neighbor.atomic_number != 6:
            continue
        for second_neighbor_id, bond in molecule._bonds[neighbor_id].items():
            if second_neighbor_id == atom_id:
                continue
            second_neighbor = molecule.atom(second_neighbor_id)
            if second_neighbor.atomic_number == 8 and int(bond) == 2:
                return True
    return False


def skip_rule_match(
    rule: ProtectionRule,
    reactant: Any,
    protected_atom_ids: tuple[int, ...],
) -> bool:
    """Return whether a protection-rule match should be ignored.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    if rule.name == "hydroxyl_methyl" and protected_atom_ids:
        return oxygen_attached_to_carbonyl_carbon(reactant, protected_atom_ids[0])
    return False


def carboxyl_deprotection_rule(rule: ProtectionRule) -> bool:
    """Return whether a protection rule cleaves a carboxyl protecting group.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    return rule.name.startswith("carboxyl_")


def atom_is_carboxylic_acid_carbon(molecule: Any, atom_id: int) -> bool:
    """Return whether an atom is the carbonyl carbon of a carboxylic acid.

    It relies on globally consistent atom maps so protected atom IDs remain meaningful
    while tracing protection and deprotection events.
    """
    if atom_id not in set(molecule):
        return False
    atom = molecule.atom(atom_id)
    if atom.atomic_number != 6:
        return False
    try:
        neighbors = molecule._bonds[atom_id]
    except Exception:
        return False

    has_double_oxygen = False
    has_single_oxygen = False
    for neighbor_id, bond in neighbors.items():
        neighbor = molecule.atom(neighbor_id)
        if neighbor.atomic_number != 8:
            continue
        if int(bond) == 2:
            has_double_oxygen = True
        elif int(bond) == 1:
            has_single_oxygen = True
    return has_double_oxygen and has_single_oxygen


def molecule_contains_atom_ids(molecule: Any, atom_ids: Iterable[int]) -> bool:
    """Return molecule contains atom IDs from a molecule or molecule node.

    It relies on globally consistent atom maps so protected atom IDs remain meaningful
    while tracing protection and deprotection events.
    """
    molecule_atom_ids = set(molecule)
    return set(atom_ids) <= molecule_atom_ids


def find_child_molecule_node(
    index: RouteIndex,
    rxn_record: ReactionRecord,
    reaction_side_molecule: Any,
) -> str | None:
    """Find child molecule node if a valid match exists.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    for child_mol_id in rxn_record.child_mol_ids:
        smiles_text = index.molecule_records[child_mol_id].smiles
        if not smiles_text:
            continue
        try:
            if chemistry.molecules_equivalent(
                chemistry.parse_molecule(smiles_text), reaction_side_molecule
            ):
                return child_mol_id
        except Exception:
            continue
    if len(rxn_record.child_mol_ids) == 1:
        return rxn_record.child_mol_ids[0]
    return None


def protected_functional_group(
    pg_type: str, molecule: Any, atom_ids: tuple[int, ...]
) -> str:
    """Identify the protected functional group represented by matched atom IDs.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    if pg_type.startswith("heteroaryl_n_"):
        return "heteroaromatic NH"
    if pg_type.startswith("amine"):
        return "amine"
    if pg_type.startswith("carbonyl"):
        return "aldehyde/ketone"
    if pg_type.startswith("carboxyl"):
        return "carboxylic_acid"
    if pg_type.startswith("diol"):
        return "diol"
    if pg_type.startswith("thiol"):
        return "thiol"
    if pg_type.startswith("hydroxyl"):
        atom_id = atom_ids[0] if atom_ids else None
        if atom_id is not None and atom_id in set(molecule):
            try:
                for neighbor_id, _bond in molecule._bonds[atom_id].items():
                    neighbor = molecule.atom(neighbor_id)
                    if getattr(neighbor, "is_aromatic", False):
                        return "phenol"
            except Exception:
                pass
        return "alcohol"
    return pg_type.split("_", 1)[0] if "_" in pg_type else "unknown"


def classify_multicenter_status(
    reaction_smiles: str,
    deprotection_query_atoms: set[int],
) -> tuple[str, int]:
    """Classify multicenter status against reference rules.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    centers = reaction_center_atoms(reaction_smiles)
    if not centers:
        return "unknown", 0
    other_centers = centers - deprotection_query_atoms
    if other_centers:
        try:
            reaction = chemistry.parse_reaction(reaction_smiles)
            for molecule in reaction.reactants + reaction.products:
                atom_ids = set(molecule)
                if not (
                    atom_ids & deprotection_query_atoms and atom_ids & other_centers
                ):
                    continue
                for atom_1, atom_2, _bond in molecule.bonds():
                    if (
                        atom_1 in deprotection_query_atoms and atom_2 in other_centers
                    ) or (
                        atom_2 in deprotection_query_atoms and atom_1 in other_centers
                    ):
                        return "deprotective_combo", len(other_centers)
        except Exception:
            pass
        return "deprotection_plus_other", len(other_centers)
    return "single_center_deprotection", 0


def transformed_products(rule: ProtectionRule, molecule: Any) -> list[Any]:
    """Generate deprotected products for a matched protection rule.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    from chython import Transformer

    try:
        return list(Transformer(rule.query, rule.product_query)(molecule))
    except Exception:
        return []


def detect_deprotections(
    index: RouteIndex,
    rxn_record: ReactionRecord,
    protection_rules: dict[str, ProtectionRule],
    config: ProtectionAnalysisConfig,
) -> list[DeprotectionMatch]:
    """Detect deprotection events in one mapped route reaction.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    reaction = chemistry.parse_reaction(rxn_record.reaction_smiles)
    products = list(reaction.products)
    matches: list[DeprotectionMatch] = []

    for reactant in reaction.reactants:
        child_mol_id = find_child_molecule_node(index, rxn_record, reactant)
        reactant_smiles = chemistry.canonical_molecule_string(reactant)
        for rule_id, rule in protection_rules.items():
            site_mappings = matching_site_mappings(reactant, rule)
            if not site_mappings:
                continue
            sites = [atoms for atoms, _mapping in site_mappings]
            transformed = transformed_products(rule, reactant)
            for protected_atom_ids, mapping in site_mappings:
                exact_product = None
                exact = False
                for candidate in transformed:
                    for product in products:
                        if chemistry.molecules_equivalent(candidate, product):
                            exact_product = product
                            exact = True
                            break
                    if exact_product is not None:
                        break

                product_with_mark = None
                product_still_protected = False
                for product in products:
                    if molecule_contains_atom_ids(product, protected_atom_ids):
                        product_with_mark = product
                        if has_protected_pattern_for_atoms(
                            product,
                            rule,
                            protected_atom_ids,
                        ):
                            product_still_protected = True
                        break

                if exact_product is None and (
                    not config.include_multicenter
                    or product_with_mark is None
                    or product_still_protected
                ):
                    continue

                from route_inspector.protection.endpoints import (
                    is_pg_donation,
                    removal_endpoint_valid,
                )

                if not removal_endpoint_valid(
                    rule, reactant, product_with_mark, mapping
                ):
                    continue
                product = product_with_mark
                if product is None:
                    continue
                if rule.atoms_to_add and is_pg_donation(
                    protected_atom_ids, product, reaction.reactants, protection_rules
                ):
                    continue
                if product is not None and has_protected_pattern_for_atoms(
                    product,
                    rule,
                    protected_atom_ids,
                ):
                    continue
                if carboxyl_deprotection_rule(rule) and (
                    product is None
                    or not protected_atom_ids
                    or not atom_is_carboxylic_acid_carbon(
                        product, protected_atom_ids[0]
                    )
                ):
                    continue
                confidence = "exact" if exact else "high"
                multicenter_status, n_other_centers = classify_multicenter_status(
                    rxn_record.reaction_smiles,
                    set(mapping.values()),
                )
                matches.append(
                    DeprotectionMatch(
                        pg_type=rule.name,
                        rule_id=rule_id,
                        rule=rule,
                        deprotection_node_id=rxn_record.node_id,
                        protected_precursor_node_id=child_mol_id,
                        protected_precursor_smiles=reactant_smiles,
                        deprotected_product_smiles=chemistry.canonical_molecule_string(
                            product
                        ),
                        protected_atom_ids=protected_atom_ids,
                        protected_query_atom_ids=tuple(rule.atoms_to_keep),
                        raw_mapping=tuple(sorted(mapping.items())),
                        confidence=confidence,
                        multicenter_status=multicenter_status,
                        n_other_reaction_centers=n_other_centers,
                        n_matching_pg_sites_before_deprotection=len(set(sites)),
                        n_sites_deprotected=1,
                        selective_deprotection=len(set(sites)) > 1,
                    )
                )

    suppressed_match_indexes: set[int] = set()
    for index, match in enumerate(matches):
        if match.pg_type != "hydroxyl_methyl":
            continue
        match_atoms = set(match.protected_atom_ids)
        for other_index, other in enumerate(matches):
            if index == other_index or other.pg_type == match.pg_type:
                continue
            if (
                other.deprotection_node_id == match.deprotection_node_id
                and other.protected_precursor_node_id
                == match.protected_precursor_node_id
                and match_atoms
                and match_atoms <= {target for _source, target in other.raw_mapping}
            ):
                suppressed_match_indexes.add(index)
                break
    if suppressed_match_indexes:
        matches = [
            match
            for index, match in enumerate(matches)
            if index not in suppressed_match_indexes
        ]

    grouped: dict[
        tuple[str, str | None, tuple[int, ...], str], list[DeprotectionMatch]
    ] = defaultdict(list)
    for match in matches:
        grouped[
            (
                match.deprotection_node_id,
                match.protected_precursor_node_id,
                match.protected_atom_ids,
                match.pg_type,
            )
        ].append(match)

    deduplicated: list[DeprotectionMatch] = []
    for group in grouped.values():
        rule_ids = tuple(sorted({match.rule_id for match in group}))
        rule_names = tuple(sorted({match.pg_type for match in group}))
        deduplicated.append(
            replace(
                group[0],
                multiple_deprotection_rules=len(rule_ids) > 1,
                matched_rule_ids=rule_ids,
                matched_rule_names=rule_names,
            )
        )

    atom_groups: dict[
        tuple[str, str | None, tuple[int, ...]], list[DeprotectionMatch]
    ] = defaultdict(list)
    for match in deduplicated:
        atom_groups[
            (
                match.deprotection_node_id,
                match.protected_precursor_node_id,
                match.protected_atom_ids,
            )
        ].append(match)

    final_matches: list[DeprotectionMatch] = []
    for group in atom_groups.values():
        rule_ids = tuple(
            sorted({rule_id for match in group for rule_id in match.matched_rule_ids})
        )
        rule_names = tuple(
            sorted(
                {rule_name for match in group for rule_name in match.matched_rule_names}
            )
        )
        for match in group:
            final_matches.append(
                replace(
                    match,
                    multiple_deprotection_rules=(
                        match.multiple_deprotection_rules or len(rule_names) > 1
                    ),
                    matched_rule_ids=rule_ids,
                    matched_rule_names=rule_names,
                )
            )
    return final_matches


def trace_protected_group_backward(
    index: RouteIndex,
    match: DeprotectionMatch,
    config: ProtectionAnalysisConfig,
) -> TraceResult:
    """Trace a protected atom set backward through earlier route steps.

    The output distinguishes a protected stock precursor, a protected synthon
    incorporated from stock, and a protecting group introduced during the route.
    """
    if match.protected_precursor_node_id is None:
        return TraceResult(
            trace_status="failed",
            source_type="unresolved",
            failure_reason="route_structure_unexpected",
            last_successful_node_id=match.deprotection_node_id,
            debug_message="could not map protected precursor to a route molecule node",
        )
    if match.ambiguous_rule_match:
        return TraceResult(
            trace_status="ambiguous",
            source_type="ambiguous",
            source_node_id=match.protected_precursor_node_id,
            protected_molecule_ids=(match.protected_precursor_node_id,),
            failure_reason="multiple_deprotection_rules_match",
            last_successful_node_id=match.protected_precursor_node_id,
            n_candidate_traces=2,
            debug_message="multiple chython deprotection rules matched the same atom set",
        )

    current_mol_id = match.protected_precursor_node_id
    protected_atom_ids = match.protected_atom_ids
    visited_reaction_ids: list[str] = []
    protected_molecule_ids: list[str] = []

    for _depth in range(config.max_trace_depth):
        current_record = index.molecule_records[current_mol_id]
        if current_mol_id not in protected_molecule_ids:
            protected_molecule_ids.append(current_mol_id)
        if is_stock_molecule(current_record.node):
            return TraceResult(
                trace_status="stock",
                source_type="stock",
                source_node_id=current_mol_id,
                stock_node_id=current_mol_id,
                stock_smiles=current_record.smiles,
                visited_reaction_ids=tuple(visited_reaction_ids),
                protected_molecule_ids=tuple(protected_molecule_ids),
                last_successful_node_id=current_mol_id,
                last_successful_smiles=current_record.smiles,
            )

        next_reactions = index.children_by_mol.get(current_mol_id, ())
        if not next_reactions:
            return TraceResult(
                trace_status="failed",
                source_type="unresolved",
                visited_reaction_ids=tuple(visited_reaction_ids),
                protected_molecule_ids=tuple(protected_molecule_ids),
                failure_reason="no_parent_reaction",
                last_successful_node_id=current_mol_id,
                last_successful_smiles=current_record.smiles,
            )

        protected_candidates: list[tuple[str, str]] = []
        unprotected_candidates: list[str] = []
        candidate_reaction_ids: list[str] = []
        for next_rxn_id in next_reactions:
            rxn_record = index.reaction_records[next_rxn_id]
            candidate_reaction_ids.append(next_rxn_id)
            try:
                chemistry.parse_reaction(rxn_record.reaction_smiles)
            except Exception:
                return TraceResult(
                    trace_status="failed",
                    source_type="unresolved",
                    visited_reaction_ids=tuple(visited_reaction_ids),
                    protected_molecule_ids=tuple(protected_molecule_ids),
                    failure_reason="reaction_parse_error",
                    last_successful_node_id=current_mol_id,
                    last_successful_smiles=current_record.smiles,
                    candidate_next_nodes=tuple(candidate_reaction_ids),
                )

            for child_mol_id in rxn_record.child_mol_ids:
                child_record = index.molecule_records[child_mol_id]
                if molecule_record_has_protected_atoms(
                    child_record,
                    match.rule,
                    protected_atom_ids,
                ):
                    protected_candidates.append((next_rxn_id, child_mol_id))
                elif child_record.smiles:
                    unprotected_candidates.append(child_mol_id)

        unique_protected = sorted(set(protected_candidates))
        if len(unique_protected) == 1:
            next_rxn_id, next_mol_id = unique_protected[0]
            visited_reaction_ids.append(next_rxn_id)
            current_mol_id = next_mol_id
            continue

        if len(unique_protected) > 1:
            return TraceResult(
                trace_status="ambiguous",
                source_type="ambiguous",
                visited_reaction_ids=tuple(visited_reaction_ids),
                protected_molecule_ids=tuple(protected_molecule_ids),
                failure_reason="multiple_candidate_ancestors",
                last_successful_node_id=current_mol_id,
                last_successful_smiles=current_record.smiles,
                candidate_next_nodes=tuple(
                    f"{rxn_id}:{mol_id}" for rxn_id, mol_id in unique_protected
                ),
                n_candidate_traces=len(unique_protected),
            )

        protected_synthon_candidates = _protected_synthon_stock_candidates(
            index,
            candidate_reaction_ids,
            match,
        )
        if len(protected_synthon_candidates) == 1:
            stock_node_id = protected_synthon_candidates[0]
            stock_record = index.molecule_records[stock_node_id]
            incorporation_node_id = stock_record.parent_reaction_id
            if not incorporation_node_id:
                raise ValueError(
                    "protected-synthon stock node lacks an incorporation reaction"
                )
            return TraceResult(
                trace_status="protected_synthon",
                source_type="protected_synthon",
                source_node_id=stock_node_id,
                protection_node_id=incorporation_node_id,
                stock_node_id=stock_node_id,
                stock_smiles=stock_record.smiles,
                source_fragment_atom_ids=tuple(
                    sorted({target for _query, target in match.raw_mapping})
                ),
                visited_reaction_ids=tuple(visited_reaction_ids),
                protected_molecule_ids=tuple(protected_molecule_ids),
                last_successful_node_id=stock_node_id,
                last_successful_smiles=stock_record.smiles,
                candidate_next_nodes=protected_synthon_candidates,
                n_candidate_traces=1,
                debug_message=(
                    "complete mapped PG fragment transferred from an in-stock reactant"
                ),
            )
        if len(protected_synthon_candidates) > 1:
            return TraceResult(
                trace_status="ambiguous",
                source_type="ambiguous",
                visited_reaction_ids=tuple(visited_reaction_ids),
                protected_molecule_ids=tuple(protected_molecule_ids),
                failure_reason="multiple_protected_synthon_stock_ancestors",
                last_successful_node_id=current_mol_id,
                last_successful_smiles=current_record.smiles,
                candidate_next_nodes=protected_synthon_candidates,
                n_candidate_traces=len(protected_synthon_candidates),
            )

        unique_unprotected_candidates = sorted(set(unprotected_candidates))
        if unique_unprotected_candidates:
            if len(next_reactions) == 1:
                protection_node_id = next_reactions[0]
                return TraceResult(
                    trace_status="introduced",
                    source_type="introduced",
                    source_node_id=protection_node_id,
                    protection_node_id=protection_node_id,
                    visited_reaction_ids=tuple(visited_reaction_ids),
                    protected_molecule_ids=tuple(protected_molecule_ids),
                    last_successful_node_id=current_mol_id,
                    last_successful_smiles=current_record.smiles,
                    candidate_next_nodes=tuple(unique_unprotected_candidates),
                    n_candidate_traces=len(unique_unprotected_candidates),
                )
            return TraceResult(
                trace_status="ambiguous",
                source_type="ambiguous",
                visited_reaction_ids=tuple(visited_reaction_ids),
                protected_molecule_ids=tuple(protected_molecule_ids),
                failure_reason="multiple_candidate_ancestors",
                last_successful_node_id=current_mol_id,
                last_successful_smiles=current_record.smiles,
                candidate_next_nodes=tuple(unique_unprotected_candidates),
                n_candidate_traces=len(unique_unprotected_candidates),
            )

        return TraceResult(
            trace_status="failed",
            source_type="unresolved",
            visited_reaction_ids=tuple(visited_reaction_ids),
            protected_molecule_ids=tuple(protected_molecule_ids),
            failure_reason="mapping_lost",
            last_successful_node_id=current_mol_id,
            last_successful_smiles=current_record.smiles,
            candidate_next_nodes=tuple(candidate_reaction_ids),
        )

    return TraceResult(
        trace_status="failed",
        source_type="unresolved",
        visited_reaction_ids=tuple(visited_reaction_ids),
        protected_molecule_ids=tuple(protected_molecule_ids),
        failure_reason="max_trace_depth_exceeded",
        last_successful_node_id=current_mol_id,
        last_successful_smiles=index.molecule_records[current_mol_id].smiles,
    )


def event_from_match_and_trace(
    route_id: str,
    event_index: int,
    index: RouteIndex,
    match: DeprotectionMatch,
    trace: TraceResult,
) -> DeprotectionEvent:
    """Build a deprotection event from a rule match and its backward trace.

    The output is used to decide whether a protecting group was stock, introduced,
    persistent, or removed during the route.
    """
    rxn_record = index.reaction_records[match.deprotection_node_id]
    protection_reaction_smiles = ""
    if trace.protection_node_id:
        protection_reaction_smiles = index.reaction_records[
            trace.protection_node_id
        ].reaction_smiles
    depth_source = None
    if trace.stock_node_id:
        depth_source = index.molecule_records[trace.stock_node_id].depth
    elif trace.protection_node_id:
        depth_source = index.reaction_records[trace.protection_node_id].depth

    precursor_molecule = chemistry.parse_molecule(match.protected_precursor_smiles)
    if trace.source_type == "stock":
        lifetime_steps = max(0, len(trace.protected_molecule_ids) - 2)
    elif trace.source_type in {"introduced", "protected_synthon"}:
        lifetime_steps = max(0, len(trace.protected_molecule_ids) - 1)
    else:
        lifetime_steps = len(trace.protected_molecule_ids)

    interval_reaction_node_paths = tuple(
        index.reaction_records[node_id].node_path
        for node_id in trace.visited_reaction_ids
    )
    protected_molecule_node_paths = tuple(
        index.molecule_records[node_id].node_path
        for node_id in trace.protected_molecule_ids
    )
    trace_last_successful_node_path: tuple[int, ...] = ()
    if trace.last_successful_node_id:
        molecule_record = index.molecule_records.get(trace.last_successful_node_id)
        reaction_record = index.reaction_records.get(trace.last_successful_node_id)
        if molecule_record is not None and reaction_record is not None:
            raise ValueError(
                "trace node ID resolves to both a molecule and reaction: "
                f"{trace.last_successful_node_id}"
            )
        if molecule_record is not None:
            trace_last_successful_node_path = molecule_record.node_path
        elif reaction_record is not None:
            trace_last_successful_node_path = reaction_record.node_path
        else:
            raise ValueError(
                "trace node ID does not resolve in route index: "
                f"{trace.last_successful_node_id}"
            )
    return DeprotectionEvent(
        event_id=f"{route_id}:pg{event_index}",
        route_id=str(route_id),
        target_smiles=index.target_smiles,
        pg_type=match.pg_type,
        protected_functional_group=protected_functional_group(
            match.pg_type,
            precursor_molecule,
            match.protected_atom_ids,
        ),
        source_type=trace.source_type,
        trace_status=trace.trace_status,
        confidence=match.confidence,
        deprotection_node_id=match.deprotection_node_id,
        deprotection_reaction_smiles=rxn_record.reaction_smiles,
        protection_node_id=trace.protection_node_id or "",
        protection_reaction_smiles=protection_reaction_smiles,
        stock_node_id=trace.stock_node_id or "",
        stock_smiles=trace.stock_smiles,
        protected_precursor_smiles=match.protected_precursor_smiles,
        deprotected_product_smiles=match.deprotected_product_smiles,
        protected_atom_ids=match.protected_atom_ids,
        source_fragment_atom_ids=trace.source_fragment_atom_ids,
        protected_substructure_smiles=match.protected_precursor_smiles,
        depth_deprotection_from_target=rxn_record.depth,
        depth_source_from_target=depth_source,
        lifetime_steps=lifetime_steps,
        n_intervening_steps=lifetime_steps,
        multicenter_status=match.multicenter_status,
        n_other_reaction_centers=match.n_other_reaction_centers,
        n_matching_pg_sites_before_deprotection=(
            match.n_matching_pg_sites_before_deprotection
        ),
        n_sites_deprotected=match.n_sites_deprotected,
        selective_deprotection=match.selective_deprotection,
        multiple_deprotection_rules=match.multiple_deprotection_rules,
        matched_deprotection_rules=match.matched_rule_names or (match.pg_type,),
        failure_reason=trace.failure_reason,
        interval_reaction_ids=trace.visited_reaction_ids,
        deprotection_reaction_node_path=rxn_record.node_path,
        protected_precursor_molecule_node_path=(
            ()
            if match.protected_precursor_node_id is None
            else index.molecule_records[match.protected_precursor_node_id].node_path
        ),
        protection_reaction_node_path=(
            ()
            if not trace.protection_node_id
            else index.reaction_records[trace.protection_node_id].node_path
        ),
        stock_molecule_node_path=(
            ()
            if not trace.stock_node_id
            else index.molecule_records[trace.stock_node_id].node_path
        ),
        interval_reaction_node_paths=interval_reaction_node_paths,
        protected_molecule_node_paths=protected_molecule_node_paths,
        trace_last_successful_node_path=trace_last_successful_node_path,
        trace_last_successful_node_id=trace.last_successful_node_id,
        trace_last_successful_smiles=trace.last_successful_smiles,
        trace_candidate_next_nodes=trace.candidate_next_nodes,
        trace_n_candidate_traces=trace.n_candidate_traces,
        trace_debug_message=trace.debug_message,
    )


def sequence_querycgr_parts(sequence: tuple[str, ...]) -> tuple[Any, ...]:
    """Compose QueryCGR objects for each rule in a rrseq sequence.

    RRseq families are compared structurally so protection rules are grouped by
    chemistry instead of raw SMARTS text.
    """
    parts = []
    for rule_smarts in sequence:
        query_cgr = rule_query_cgr(rule_smarts)
        parts.append(query_cgr_coarse_signature(query_cgr))
    return tuple(parts)


def sequence_querycgr_hash(sequence: tuple[str, ...]) -> tuple[str, str]:
    """Build a stable structural hash for a rrseq sequence.

    RRseq families are compared structurally so protection rules are grouped by
    chemistry instead of raw SMARTS text.
    """
    try:
        parts = sequence_querycgr_parts(sequence)
        querycgr_text = json.dumps(parts, sort_keys=True, default=repr)
        digest = hashlib.sha1(querycgr_text.encode("utf-8")).hexdigest()[:16]
        return querycgr_text, digest
    except Exception:
        fallback = "$".join(sequence)
        digest = hashlib.sha1(fallback.encode("utf-8")).hexdigest()[:16]
        return fallback, digest


def sequences_querycgr_isomorphic(
    left: tuple[str, ...],
    right: tuple[str, ...],
) -> bool:
    """Return whether two rrseq sequences are QueryCGR-isomorphic.

    RRseq families are compared structurally so protection rules are grouped by
    chemistry instead of raw SMARTS text.
    """
    if len(left) != len(right):
        return False
    try:
        return all(
            query_cgr_isomorphic(rule_query_cgr(left_rule), rule_query_cgr(right_rule))
            for left_rule, right_rule in zip(left, right)
        )
    except Exception:
        return False


def load_rrseq_index(paths: Iterable[Path] | None) -> dict[str, RRseqFamily]:
    """Load rrseq rule index from configured sources.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    if not paths:
        return {}
    families_by_hash: dict[str, RRseqFamily] = {}
    expanded = expand_rrseq_tsv_paths(paths)
    for tsv_path in expanded:
        fieldnames, rows = read_tsv_rows(tsv_path)
        rrseq_column = "RRseq_cons" if "RRseq_cons" in fieldnames else "RRseq"
        if rrseq_column not in fieldnames:
            continue
        for row_index, row in enumerate(rows):
            rrseq = (row.get(rrseq_column) or "").strip()
            if not rrseq:
                continue
            sequence = tuple(split_rrseq(rrseq))
            querycgr, query_hash = sequence_querycgr_hash(sequence)
            family = families_by_hash.get(query_hash)
            if family is None:
                family = RRseqFamily(
                    family_id=f"crf_{len(families_by_hash) + 1:06d}",
                    rrseq=rrseq,
                    sequence=sequence,
                    querycgr_hash=query_hash,
                    querycgr=querycgr,
                )
                families_by_hash[query_hash] = family
            family.route_ids.update(split_cell(row.get("Reference")))
            family.target_molecules.update(split_cell(row.get("Target_molecules")))
            family.source_rows.add(f"{tsv_path}:{row_index}")
    return families_by_hash


def default_rule_extractor() -> SynPlannerRuleExtractor:
    """Return the default path for rule extractor.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    args = RuleExtractionSettings(
        config=None,
        environment_atom_count=1,
        include_rings=False,
        keep_leaving_groups=True,
        keep_incoming_groups=False,
        reactor_validation=False,
    )
    return SynPlannerRuleExtractor.from_args(args)


def match_family_for_sequence(
    sequence: tuple[str, ...],
    families_by_hash: dict[str, RRseqFamily],
) -> RRseqFamily | None:
    """Find the rrseq family matching a rule sequence.

    RRseq families are compared structurally so protection rules are grouped by
    chemistry instead of raw SMARTS text.
    """
    _querycgr, query_hash = sequence_querycgr_hash(sequence)
    return families_by_hash.get(query_hash)


def collect_interval_rule_observations(
    event: DeprotectionEvent,
    index: RouteIndex,
    families_by_hash: dict[str, RRseqFamily],
    config: ProtectionAnalysisConfig,
    rule_extractor: SynPlannerRuleExtractor | None,
) -> list[IntervalRuleObservation]:
    """Collect interval rule observations from route-analysis input data.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    if not config.collect_interval_rules or not event.interval_reaction_ids:
        return []
    if rule_extractor is None:
        return []

    steps: list[ReactionRuleStep] = []
    for rxn_id in event.interval_reaction_ids:
        rxn_record = index.reaction_records[rxn_id]
        step, _cache_hit = rule_extractor.extract(rxn_record.reaction_smiles)
        if step is None:
            continue
        parent_mol = index.molecule_records[rxn_record.parent_mol_id]
        steps.append(
            ReactionRuleStep(
                rule_smarts=step.rule_smarts,
                center_atoms=step.center_atoms,
                reaction_smiles=step.reaction_smiles,
                target_smiles=parent_mol.smiles,
                reactant_center_molecules=step.reactant_center_molecules,
                product_center_molecules=step.product_center_molecules,
            )
        )

    observations: list[IntervalRuleObservation] = []
    if not steps:
        return observations

    for sequence, _target_smiles in valid_rrseq_cons_sequence_occurrences(
        steps,
        min_length=config.min_rrseq_cons_size,
        max_length=config.max_rrseq_cons_size,
    ):
        family = match_family_for_sequence(sequence, families_by_hash)
        querycgr, query_hash = sequence_querycgr_hash(sequence)
        family_id = family.family_id if family else f"interval_{query_hash}"
        support = len(family.route_ids) if family else 0
        rrseq = "$".join(sequence)
        observations.append(
            IntervalRuleObservation(
                event_id=event.event_id,
                route_id=event.route_id,
                pg_type=event.pg_type,
                trace_status=event.trace_status,
                interval_step_ids=event.interval_reaction_ids,
                interval_reaction_smiles=tuple(
                    index.reaction_records[rxn_id].reaction_smiles
                    for rxn_id in event.interval_reaction_ids
                ),
                single_step_rules=tuple(step.rule_smarts for step in steps),
                rrseq_size=len(sequence),
                rrseq_smarts=rrseq,
                rrseq_querycgr=querycgr,
                rrseq_querycgr_hash=query_hash,
                rrseq_family_id=family_id,
                rrseq_support_in_routes=support,
                is_full_interval_rule=len(sequence) == len(steps),
                is_adjacent_window_rule=True,
                macro_depth_saving=len(sequence) - 1,
                first_reaction_after_source=(
                    steps[-1].reaction_smiles if steps else ""
                ),
                last_reaction_before_deprotection=(
                    steps[0].reaction_smiles if steps else ""
                ),
            )
        )
    return observations


def collect_single_rule_observations(
    events: list[DeprotectionEvent],
    index: RouteIndex,
    rule_extractor: SynPlannerRuleExtractor | None,
) -> list[ProtectionSingleRuleObservation]:
    """Collect one-step rules inside resolved protection intervals.

    The collection is independent of whether those one-step rules form a valid
    rrseq rule, so it captures the chemistry that happens between protection
    source and deprotection even when no interval rrseq rule is found.
    """
    if rule_extractor is None:
        return []

    observations: list[ProtectionSingleRuleObservation] = []
    for event in events:
        if event.trace_status not in {"introduced", "protected_synthon", "stock"}:
            continue
        for rxn_id in event.interval_reaction_ids:
            rxn_record = index.reaction_records.get(rxn_id)
            if rxn_record is None:
                continue
            step, _cache_hit = rule_extractor.extract(rxn_record.reaction_smiles)
            if step is None:
                continue
            observations.append(
                ProtectionSingleRuleObservation(
                    route_id=event.route_id,
                    pg_type=event.pg_type,
                    rule_smarts=step.rule_smarts,
                    reaction_smiles=step.reaction_smiles,
                    event_id=event.event_id,
                )
            )
    return observations


def protection_detection_policy(protection_rules, config):
    """Identify a fixed rule set for reaction-local detection memoization."""
    payload = (
        bool(config.include_multicenter),
        tuple(
            (
                rid,
                rule.name,
                format(rule.query, "m"),
                format(rule.product_query, "m"),
                rule.atoms_to_keep,
                rule.atoms_to_add,
            )
            for rid, rule in protection_rules.items()
        ),
    )
    return hashlib.sha256(repr(payload).encode()).digest()


def analyze_route_protection(
    route: dict[str, Any],
    route_id: Any,
    protection_rules: dict[str, ProtectionRule],
    rrseq_index: dict[str, RRseqFamily] | None = None,
    config: ProtectionAnalysisConfig | None = None,
    rule_extractor: SynPlannerRuleExtractor | None = None,
    *,
    route_index: RouteIndex | None = None,
    detection_cache=None,
    detection_policy=None,
) -> tuple[list[DeprotectionEvent], list[IntervalRuleObservation], RouteIndex]:
    """Analyze protecting-group behavior in a single route.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    config = config or ProtectionAnalysisConfig()
    families = rrseq_index or {}
    index = route_index or build_route_index(route)
    events: list[DeprotectionEvent] = []
    interval_rules: list[IntervalRuleObservation] = []
    # Cache reaction-local chemistry only. Trace paths and event identities are
    # rebuilt in the current route, including a fresh precursor-node lookup.
    # A processor owns one fixed, profiled rule set and can supply its identity.
    # Standalone callers still compute it from the actual rules on every call.
    if detection_cache is not None and detection_policy is None:
        detection_policy = protection_detection_policy(protection_rules, config)

    for rxn_id in index.reaction_order:
        rxn_record = index.reaction_records[rxn_id]
        cache_key = (detection_policy, rxn_record.reaction_smiles)
        cached = detection_cache.get(cache_key) if detection_cache is not None else None
        if cached is None:
            matches = detect_deprotections(index, rxn_record, protection_rules, config)
            if detection_cache is not None:
                detection_cache[cache_key] = tuple(matches)
                if len(detection_cache) > 8192:
                    detection_cache.pop(next(iter(detection_cache)))
        else:
            matches = [
                replace(
                    match,
                    deprotection_node_id=rxn_record.node_id,
                    protected_precursor_node_id=find_child_molecule_node(
                        index,
                        rxn_record,
                        chemistry.parse_molecule(match.protected_precursor_smiles),
                    ),
                )
                for match in cached
            ]
        for match in matches:
            if phthalimide_nitrogen_donor(
                index,
                match.pg_type,
                match.protected_precursor_node_id,
                match.protected_atom_ids,
                (target for _query, target in match.raw_mapping),
            ):
                continue
            trace = trace_protected_group_backward(index, match, config)
            event = event_from_match_and_trace(
                str(route_id),
                len(events) + 1,
                index,
                match,
                trace,
            )
            events.append(event)
            interval_rules.extend(
                collect_interval_rule_observations(
                    event,
                    index,
                    families,
                    config,
                    rule_extractor,
                )
            )
    return events, interval_rules, index


def event_to_row(event: DeprotectionEvent) -> dict[str, Any]:
    """Convert one deprotection event into an output TSV row.

    The output is used to decide whether a protecting group was stock, introduced,
    persistent, or removed during the route.
    """
    return {
        "event_id": event.event_id,
        "route_id": event.route_id,
        "target_smiles": event.target_smiles,
        "pg_type": event.pg_type,
        "protected_functional_group": event.protected_functional_group,
        "source_type": event.source_type,
        "trace_status": event.trace_status,
        "confidence": event.confidence,
        "deprotection_node_id": event.deprotection_node_id,
        "deprotection_reaction_smiles": event.deprotection_reaction_smiles,
        "protection_node_id": event.protection_node_id,
        "protection_reaction_smiles": event.protection_reaction_smiles,
        "stock_node_id": event.stock_node_id,
        "stock_smiles": event.stock_smiles,
        "protected_precursor_smiles": event.protected_precursor_smiles,
        "deprotected_product_smiles": event.deprotected_product_smiles,
        "protected_atom_ids": ",".join(map(str, event.protected_atom_ids)),
        "source_fragment_atom_ids": ",".join(map(str, event.source_fragment_atom_ids)),
        "protected_substructure_smiles": event.protected_substructure_smiles,
        "depth_deprotection_from_target": event.depth_deprotection_from_target,
        "depth_source_from_target": (
            ""
            if event.depth_source_from_target is None
            else event.depth_source_from_target
        ),
        "lifetime_steps": event.lifetime_steps,
        "n_intervening_steps": event.n_intervening_steps,
        "multicenter_status": event.multicenter_status,
        "n_other_reaction_centers": event.n_other_reaction_centers,
        "n_matching_pg_sites_before_deprotection": (
            event.n_matching_pg_sites_before_deprotection
        ),
        "n_sites_deprotected": event.n_sites_deprotected,
        "selective_deprotection": event.selective_deprotection,
        "multiple_deprotection_rules": event.multiple_deprotection_rules,
        "matched_deprotection_rules": ",".join(event.matched_deprotection_rules),
        "failure_reason": event.failure_reason,
        "interval_reaction_ids": ",".join(event.interval_reaction_ids),
        "deprotection_reaction_node_path": json.dumps(
            list(event.deprotection_reaction_node_path),
            separators=(",", ":"),
        ),
        "protected_precursor_molecule_node_path": json.dumps(
            list(event.protected_precursor_molecule_node_path),
            separators=(",", ":"),
        ),
        "protection_reaction_node_path": json.dumps(
            list(event.protection_reaction_node_path),
            separators=(",", ":"),
        ),
        "stock_molecule_node_path": json.dumps(
            list(event.stock_molecule_node_path),
            separators=(",", ":"),
        ),
        "interval_reaction_node_paths": json.dumps(
            [list(path) for path in event.interval_reaction_node_paths],
            separators=(",", ":"),
        ),
        "protected_molecule_node_paths": json.dumps(
            [list(path) for path in event.protected_molecule_node_paths],
            separators=(",", ":"),
        ),
        "trace_last_successful_node_path": json.dumps(
            list(event.trace_last_successful_node_path),
            separators=(",", ":"),
        ),
        "trace_last_successful_node_id": event.trace_last_successful_node_id,
        "trace_last_successful_smiles": event.trace_last_successful_smiles,
        "trace_candidate_next_nodes": ",".join(event.trace_candidate_next_nodes),
        "trace_n_candidate_traces": event.trace_n_candidate_traces,
        "trace_debug_message": event.trace_debug_message,
    }


def deprotection_event_to_record(event: DeprotectionEvent) -> dict[str, Any]:
    """Return a versioned JSON-ready tracer event with structured path arrays."""

    return {
        "schema_version": PROTECTION_TRACE_EVENT_SCHEMA_VERSION,
        **asdict(event),
    }


def interval_rule_to_row(observation: IntervalRuleObservation) -> dict[str, Any]:
    """Convert one protection interval observation into an output TSV row.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    return {
        "event_id": observation.event_id,
        "route_id": observation.route_id,
        "pg_type": observation.pg_type,
        "trace_status": observation.trace_status,
        "interval_step_ids": ",".join(observation.interval_step_ids),
        "interval_reaction_smiles": " || ".join(observation.interval_reaction_smiles),
        "single_step_rules": " || ".join(observation.single_step_rules),
        "rrseq_size": observation.rrseq_size,
        "rrseq_smarts": observation.rrseq_smarts,
        "rrseq_querycgr": observation.rrseq_querycgr,
        "rrseq_querycgr_hash": observation.rrseq_querycgr_hash,
        "rrseq_family_id": observation.rrseq_family_id,
        "rrseq_support_in_routes": observation.rrseq_support_in_routes,
        "is_full_interval_rule": observation.is_full_interval_rule,
        "is_adjacent_window_rule": observation.is_adjacent_window_rule,
        "macro_depth_saving": observation.macro_depth_saving,
        "min_distance_pg_to_reaction_center": (
            observation.min_distance_pg_to_reaction_center
        ),
        "median_distance_pg_to_reaction_center": (
            observation.median_distance_pg_to_reaction_center
        ),
        "first_reaction_after_source": observation.first_reaction_after_source,
        "last_reaction_before_deprotection": observation.last_reaction_before_deprotection,
    }


def trace_failure_row(
    event: DeprotectionEvent,
    trace: TraceResult | None = None,
) -> dict[str, Any]:
    """Convert one protection trace failure into an output TSV row.

    The output is used to decide whether a protecting group was stock, introduced,
    persistent, or removed during the route.
    """
    return {
        "event_id": event.event_id,
        "route_id": event.route_id,
        "pg_type": event.pg_type,
        "deprotection_node_id": event.deprotection_node_id,
        "deprotection_reaction_node_path": json.dumps(
            list(event.deprotection_reaction_node_path),
            separators=(",", ":"),
        ),
        "protected_precursor_molecule_node_path": json.dumps(
            list(event.protected_precursor_molecule_node_path),
            separators=(",", ":"),
        ),
        "protected_precursor_smiles": event.protected_precursor_smiles,
        "protected_atom_ids": ",".join(map(str, event.protected_atom_ids)),
        "trace_status": event.trace_status,
        "failure_reason": event.failure_reason,
        "last_successful_node_id": event.trace_last_successful_node_id,
        "last_successful_node_path": json.dumps(
            list(event.trace_last_successful_node_path),
            separators=(",", ":"),
        ),
        "last_successful_smiles": event.trace_last_successful_smiles,
        "candidate_next_nodes": ",".join(event.trace_candidate_next_nodes),
        "n_candidate_traces": event.trace_n_candidate_traces,
        "debug_message": event.trace_debug_message,
    }


def route_stats_row(
    route_id: str,
    index: RouteIndex,
    events: list[DeprotectionEvent],
    interval_rules: list[IntervalRuleObservation],
) -> dict[str, Any]:
    """Build an output row for route stats.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    lifetimes = [event.lifetime_steps for event in events]
    pg_types = sorted({event.pg_type for event in events})
    family_ids = {obs.rrseq_family_id for obs in interval_rules}
    max_simultaneous = max_simultaneous_pg(events)
    return {
        "route_id": route_id,
        "target_smiles": index.target_smiles,
        "n_steps": len(index.reaction_records),
        "n_molecule_nodes": len(index.molecule_records),
        "n_reaction_nodes": len(index.reaction_records),
        "n_in_stock_leaves": sum(
            1
            for record in index.molecule_records.values()
            if is_stock_molecule(record.node)
        ),
        "n_protecting_groups_total": len(events),
        "n_pg_types": len(pg_types),
        "pg_types": ",".join(pg_types),
        "n_pg_introduced": sum(
            1 for event in events if event.source_type == "introduced"
        ),
        "n_pg_protected_synthon": sum(
            1 for event in events if event.source_type == "protected_synthon"
        ),
        "n_pg_stock": sum(1 for event in events if event.source_type == "stock"),
        "n_pg_ambiguous": sum(
            1 for event in events if event.trace_status == "ambiguous"
        ),
        "n_pg_failed": sum(1 for event in events if event.trace_status == "failed"),
        "n_deprotection_events": len(events),
        "n_multicenter_deprotection_events": sum(
            1
            for event in events
            if event.multicenter_status
            in {"deprotection_plus_other", "deprotective_combo"}
        ),
        "n_deprotective_combo_events": sum(
            1 for event in events if event.multicenter_status == "deprotective_combo"
        ),
        "max_simultaneous_pg": max_simultaneous,
        "mean_pg_lifetime_steps": (
            f"{statistics.mean(lifetimes):.3f}" if lifetimes else ""
        ),
        "median_pg_lifetime_steps": (
            f"{statistics.median(lifetimes):.3f}" if lifetimes else ""
        ),
        "n_interval_rrseq_cons": len(interval_rules),
        "n_unique_interval_rrseq_cons_families": len(family_ids),
    }


def matching_single_rule_aggregate(
    aggregate_buckets: dict[tuple[Any, ...], list[ProtectionSingleRuleAggregate]],
    query_cgr: Any,
    pg_type: str | None = None,
) -> ProtectionSingleRuleAggregate | None:
    """Find a single-rule aggregate with the same QueryCGR.

    A coarse QueryCGR signature is used only as a lookup bucket; the final duplicate
    decision is made by QueryCGR isomorphism so equivalent SMARTS with different atom
    maps are merged into one row. When ``pg_type`` is supplied, matching is constrained
    to a single protecting-group-specific aggregate.
    """
    for aggregate in aggregate_buckets.get(query_cgr_coarse_signature(query_cgr), []):
        if pg_type is not None and aggregate.pg_types != {pg_type}:
            continue
        if query_cgr_isomorphic(aggregate.query_cgr, query_cgr):
            return aggregate
    return None


def summarize_single_rules_by_pg(
    observations: Iterable[ProtectionSingleRuleObservation],
) -> list[dict[str, Any]]:
    """Summarize intervening one-step rules by PG type and QueryCGR identity.

    The output reports how often each single-step rule occurs inside resolved
    protection intervals, without requiring the rule to be part of a valid rrseq
    rule family.
    """
    aggregate_buckets: dict[tuple[Any, ...], list[ProtectionSingleRuleAggregate]] = (
        defaultdict(list)
    )
    aggregates: list[ProtectionSingleRuleAggregate] = []

    for observation in observations:
        query_cgr = rule_query_cgr(observation.rule_smarts)
        signature = query_cgr_coarse_signature(query_cgr)
        aggregate = matching_single_rule_aggregate(
            aggregate_buckets,
            query_cgr,
            pg_type=observation.pg_type,
        )
        if aggregate is None:
            aggregate = ProtectionSingleRuleAggregate(
                representative_rule=observation.rule_smarts,
                query_cgr=query_cgr,
                pg_types={observation.pg_type},
            )
            aggregate_buckets[signature].append(aggregate)
            aggregates.append(aggregate)

        aggregate.rule_count += 1
        aggregate.pg_types.add(observation.pg_type)
        aggregate.route_ids.add(observation.route_id)
        aggregate.event_ids.add(observation.event_id)
        aggregate.reaction_smiles.add(observation.reaction_smiles)

    rows = [
        {
            "source_pg_type": next(iter(aggregate.pg_types)),
            "rule": aggregate.representative_rule,
            "route_count": len(aggregate.route_ids),
            "rule_count": aggregate.rule_count,
            "route_ids": ",".join(sorted(aggregate.route_ids, key=reference_sort_key)),
        }
        for aggregate in aggregates
    ]
    return sorted(
        rows,
        key=lambda row: (
            -int(row["route_count"]),
            -int(row["rule_count"]),
            row["source_pg_type"],
            row["rule"],
        ),
    )


def summarize_single_rules(
    observations: Iterable[ProtectionSingleRuleObservation],
) -> list[dict[str, Any]]:
    """Summarize intervening one-step rules by PG type.

    This compatibility wrapper returns the per-protecting-group table used for
    ``*_protection_single_rules.tsv``.
    """
    return summarize_single_rules_by_pg(observations)


def summarize_aggregate_single_rules(
    observations: Iterable[ProtectionSingleRuleObservation],
) -> list[dict[str, Any]]:
    """Summarize intervening one-step rules across all PG types.

    This table answers which single-step rules recur across protection contexts. Rules
    are merged by QueryCGR identity only, while all contributing protecting-group types
    are retained in the ``pg_types`` column.
    """
    aggregate_buckets: dict[tuple[Any, ...], list[ProtectionSingleRuleAggregate]] = (
        defaultdict(list)
    )
    aggregates: list[ProtectionSingleRuleAggregate] = []

    for observation in observations:
        query_cgr = rule_query_cgr(observation.rule_smarts)
        signature = query_cgr_coarse_signature(query_cgr)
        aggregate = matching_single_rule_aggregate(aggregate_buckets, query_cgr)
        if aggregate is None:
            aggregate = ProtectionSingleRuleAggregate(
                representative_rule=observation.rule_smarts,
                query_cgr=query_cgr,
            )
            aggregate_buckets[signature].append(aggregate)
            aggregates.append(aggregate)

        aggregate.rule_count += 1
        aggregate.pg_types.add(observation.pg_type)
        aggregate.route_ids.add(observation.route_id)
        aggregate.event_ids.add(observation.event_id)
        aggregate.reaction_smiles.add(observation.reaction_smiles)

    rows = [
        {
            "rule": aggregate.representative_rule,
            "pg_types": ",".join(sorted(aggregate.pg_types)),
            "route_count": len(aggregate.route_ids),
            "rulec_count": aggregate.rule_count,
            "route_ids": ",".join(sorted(aggregate.route_ids, key=reference_sort_key)),
        }
        for aggregate in aggregates
    ]
    return sorted(
        rows,
        key=lambda row: (
            -int(row["route_count"]),
            -int(row["rulec_count"]),
            row["rule"],
        ),
    )


def max_simultaneous_pg(events: list[DeprotectionEvent]) -> int:
    """Count the maximum number of protecting groups present at once.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    if not events:
        return 0
    points = sorted(
        {
            event.depth_deprotection_from_target
            for event in events
            if event.depth_source_from_target is not None
        }
        | {
            int(event.depth_source_from_target)
            for event in events
            if event.depth_source_from_target is not None
        }
    )
    maximum = 1 if events else 0
    for point in points:
        active = 0
        for event in events:
            if event.depth_source_from_target is None:
                continue
            low = min(
                event.depth_deprotection_from_target, event.depth_source_from_target
            )
            high = max(
                event.depth_deprotection_from_target, event.depth_source_from_target
            )
            if low <= point <= high:
                active += 1
        maximum = max(maximum, active)
    return maximum


def resolved_stock_lifetime_summary(
    events: Iterable[DeprotectionEvent],
) -> tuple[int, dict[str, int]]:
    """Count resolved-stock events and their dense lifetime distribution."""

    lifetimes = [
        event.lifetime_steps for event in events if event.trace_status == "stock"
    ]
    if any(lifetime < 0 for lifetime in lifetimes):
        raise ValueError("protection-event lifetime_steps cannot be negative")
    counts = Counter(lifetimes)
    histogram = {
        str(lifetime): counts.get(lifetime, 0)
        for lifetime in range(max(lifetimes, default=-1) + 1)
    }
    return len(lifetimes), histogram


def summarize_groups(
    events: list[DeprotectionEvent],
    interval_rules: list[IntervalRuleObservation],
) -> list[dict[str, Any]]:
    """Summarize protection events by protecting-group type.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    events_by_pg: dict[str, list[DeprotectionEvent]] = defaultdict(list)
    rules_by_pg: dict[str, list[IntervalRuleObservation]] = defaultdict(list)
    for event in events:
        events_by_pg[event.pg_type].append(event)
    for observation in interval_rules:
        rules_by_pg[observation.pg_type].append(observation)

    rows = []
    for pg_type, pg_events in events_by_pg.items():
        lifetimes = [event.lifetime_steps for event in pg_events]
        route_ids = {event.route_id for event in pg_events}
        targets = {event.target_smiles for event in pg_events}
        pg_rules = rules_by_pg.get(pg_type, [])
        family_counts = Counter(obs.rrseq_family_id for obs in pg_rules)
        first_reactions = Counter(
            obs.first_reaction_after_source
            for obs in pg_rules
            if obs.first_reaction_after_source
        )
        last_reactions = Counter(
            obs.last_reaction_before_deprotection
            for obs in pg_rules
            if obs.last_reaction_before_deprotection
        )
        functional_groups = Counter(
            event.protected_functional_group for event in pg_events
        )
        introduced = sum(1 for event in pg_events if event.source_type == "introduced")
        protected_synthon = sum(
            1 for event in pg_events if event.source_type == "protected_synthon"
        )
        stock = sum(1 for event in pg_events if event.source_type == "stock")
        failed = sum(1 for event in pg_events if event.trace_status == "failed")
        ambiguous = sum(1 for event in pg_events if event.trace_status == "ambiguous")
        selective = sum(1 for event in pg_events if event.selective_deprotection)
        popularity = len(pg_events)
        rows.append(
            {
                "pg_type": pg_type,
                "popularity": popularity,
                "route_count": len(route_ids),
                "target_count": len(targets),
                "introduced_count": introduced,
                "protected_synthon_count": protected_synthon,
                "stock_count": stock,
                "ambiguous_count": ambiguous,
                "failed_count": failed,
                "introduction_fraction": f"{introduced / popularity:.6f}",
                "protected_synthon_fraction": (f"{protected_synthon / popularity:.6f}"),
                "stock_fraction": f"{stock / popularity:.6f}",
                "failure_fraction": f"{failed / popularity:.6f}",
                "median_lifetime_steps": (
                    f"{statistics.median(lifetimes):.3f}" if lifetimes else ""
                ),
                "mean_lifetime_steps": f"{statistics.mean(lifetimes):.3f}"
                if lifetimes
                else "",
                "max_lifetime_steps": max(lifetimes) if lifetimes else "",
                "n_unique_rrseq_cons": len({obs.rrseq_smarts for obs in pg_rules}),
                "n_unique_rrseq_families": len(family_counts),
                "top_rrseq_families": ",".join(
                    family for family, _count in family_counts.most_common(5)
                ),
                "top_first_reactions_after_source": " || ".join(
                    reaction for reaction, _count in first_reactions.most_common(3)
                ),
                "top_last_reactions_before_deprotection": " || ".join(
                    reaction for reaction, _count in last_reactions.most_common(3)
                ),
                "top_protected_functional_groups": ",".join(
                    name for name, _count in functional_groups.most_common(5)
                ),
                "n_multicenter_deprotection_events": sum(
                    1
                    for event in pg_events
                    if event.multicenter_status
                    in {"deprotection_plus_other", "deprotective_combo"}
                ),
                "n_deprotective_combo_events": sum(
                    1
                    for event in pg_events
                    if event.multicenter_status == "deprotective_combo"
                ),
                "n_selective_deprotections": selective,
                "selective_deprotection_fraction": f"{selective / popularity:.6f}",
            }
        )
    return sorted(rows, key=lambda row: (-int(row["popularity"]), row["pg_type"]))


def summarize_rule_families(
    events: list[DeprotectionEvent],
    interval_rules: list[IntervalRuleObservation],
) -> list[dict[str, Any]]:
    """Summarize protection events by matched rrseq family.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    event_by_id = {event.event_id: event for event in events}
    grouped: dict[tuple[str, str], list[IntervalRuleObservation]] = defaultdict(list)
    for observation in interval_rules:
        grouped[(observation.pg_type, observation.rrseq_family_id)].append(observation)

    rows = []
    for (pg_type, family_id), observations in grouped.items():
        route_ids = {obs.route_id for obs in observations}
        event_ids = {obs.event_id for obs in observations}
        targets = {
            event_by_id[event_id].target_smiles
            for event_id in event_ids
            if event_id in event_by_id
        }
        representative = observations[0]
        rows.append(
            {
                "pg_type": pg_type,
                "rrseq_family_id": family_id,
                "family_popularity": len(observations),
                "route_count": len(route_ids),
                "target_count": len(targets),
                "representative_rrseq_smarts": (representative.rrseq_smarts),
                "family_size_rules": len({obs.rrseq_smarts for obs in observations}),
                "median_pairwise_similarity": "",
                "min_pairwise_similarity": "",
                "max_pairwise_similarity": "",
                "example_route_ids": ",".join(
                    sorted(route_ids, key=reference_sort_key)[:10]
                ),
                "example_event_ids": ",".join(sorted(event_ids)[:10]),
                "example_target_smiles": ",".join(sorted(targets)[:5]),
                "interpretation_label": f"{pg_type}->{family_id}",
            }
        )
    return sorted(
        rows,
        key=lambda row: (
            -int(row["family_popularity"]),
            row["pg_type"],
            row["rrseq_family_id"],
        ),
    )


def network_edges(
    rule_family_rows: list[dict[str, Any]],
    events: list[DeprotectionEvent],
) -> list[dict[str, Any]]:
    """Build route-network edges for protection summary outputs.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    lifetime_by_pg = defaultdict(list)
    for event in events:
        lifetime_by_pg[event.pg_type].append(event.lifetime_steps)
    rows = []
    for row in rule_family_rows:
        lifetimes = lifetime_by_pg.get(row["pg_type"], [])
        rows.append(
            {
                "source_pg_type": row["pg_type"],
                "target_rule_family_id": row["rrseq_family_id"],
                "edge_weight": row["family_popularity"],
                "route_count": row["route_count"],
                "target_count": row["target_count"],
                "median_lifetime_steps": (
                    f"{statistics.median(lifetimes):.3f}" if lifetimes else ""
                ),
                "representative_rule": row["representative_rrseq_smarts"],
                "interpretation_label": row["interpretation_label"],
            }
        )
    return rows


def _init_protection_worker(
    config: ProtectionAnalysisConfig,
    rrseq_index: dict[str, RRseqFamily] | None,
    protection_rules: dict[str, ProtectionRule] | None,
) -> None:
    """Run the worker entry point for init protection.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    global _PROTECTION_WORKER_CONFIG
    global _PROTECTION_WORKER_RULES
    global _PROTECTION_WORKER_RRSEQ_INDEX
    global _PROTECTION_WORKER_RULE_EXTRACTOR
    from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
    from route_inspector.protection.chython_rules import load_chython_protection_rules

    setup_runtime_cache_dirs()
    _PROTECTION_WORKER_CONFIG = config
    _PROTECTION_WORKER_RULES = protection_rules or load_chython_protection_rules()
    _PROTECTION_WORKER_RRSEQ_INDEX = rrseq_index
    _PROTECTION_WORKER_RULE_EXTRACTOR = None
    if config.collect_interval_rules:
        try:
            _PROTECTION_WORKER_RULE_EXTRACTOR = default_rule_extractor()
        except Exception:
            _PROTECTION_WORKER_RULE_EXTRACTOR = None


def _protection_route_worker(item: tuple[str, dict[str, Any]]) -> dict[str, Any]:
    """Run the worker entry point for protection route.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    route_id, route = item
    try:
        if _PROTECTION_WORKER_CONFIG is None or _PROTECTION_WORKER_RULES is None:
            raise RuntimeError("protection worker was not initialized")
        route_events, route_interval_rules, route_index = analyze_route_protection(
            route,
            route_id,
            _PROTECTION_WORKER_RULES,
            rrseq_index=_PROTECTION_WORKER_RRSEQ_INDEX,
            config=_PROTECTION_WORKER_CONFIG,
            rule_extractor=_PROTECTION_WORKER_RULE_EXTRACTOR,
        )
        route_single_rules = collect_single_rule_observations(
            route_events,
            route_index,
            _PROTECTION_WORKER_RULE_EXTRACTOR,
        )
        stats_row = route_stats_row(
            route_id,
            route_index,
            route_events,
            route_interval_rules,
        )
        return {
            "route_id": route_id,
            "events": route_events,
            "interval_rules": route_interval_rules,
            "single_rule_observations": route_single_rules,
            "route_stats_row": stats_row,
            "protection_free_route": not route_events,
            "debug_route": (
                route_index.route
                if _PROTECTION_WORKER_CONFIG.write_debug_json and route_events
                else None
            ),
            "error": None,
        }
    except Exception as exc:
        return {
            "route_id": route_id,
            "events": [],
            "interval_rules": [],
            "single_rule_observations": [],
            "route_stats_row": None,
            "protection_free_route": False,
            "debug_route": None,
            "error": {
                "route_id": route_id,
                "stage": "analyze_route_protection",
                "error_type": type(exc).__qualname__,
                "message": str(exc) or traceback.format_exc(limit=1).strip(),
            },
        }


def analyze_protection_in_routes(
    routes_json: Any,
    rrseq_index: dict[str, RRseqFamily] | None = None,
    config: ProtectionAnalysisConfig | None = None,
    *,
    protection_rules: dict[str, ProtectionRule] | None = None,
    limit: int | None = None,
    route_ids: set[str] | None = None,
    collect_interval_rules: bool | None = None,
    progress_interval: int = 0,
    n_cpu: int = 1,
) -> ProtectionAnalysisResult:
    """Analyze protection behavior across a route collection.

    The helper keeps protection detection, route tracing, and summary generation
    separate while sharing the same normalized route index.
    """
    from route_inspector.protection.chython_rules import load_chython_protection_rules

    config = config or ProtectionAnalysisConfig()
    protection_rules = protection_rules or load_chython_protection_rules()
    if collect_interval_rules is not None:
        config.collect_interval_rules = collect_interval_rules
    rule_extractor = None
    if config.collect_interval_rules:
        try:
            rule_extractor = default_rule_extractor()
        except Exception:
            rule_extractor = None

    route_stats_rows: list[dict[str, Any]] = []
    events: list[DeprotectionEvent] = []
    interval_rules: list[IntervalRuleObservation] = []
    single_rule_observations: list[ProtectionSingleRuleObservation] = []
    protection_free_routes = 0
    errors: list[dict[str, Any]] = []
    debug_routes: dict[str, dict[str, Any]] = {}
    routes_seen = 0
    route_work_items: list[tuple[str, dict[str, Any]]] = []
    for route_id_raw, route in route_access.route_items(routes_json):
        route_id = str(route_id_raw)
        if route_ids is not None and route_id not in route_ids:
            continue
        if limit is not None and len(route_work_items) >= limit:
            break
        route_work_items.append((route_id, route))
    route_by_id = {route_id: route for route_id, route in route_work_items}
    n_cpu = normalize_n_cpu(n_cpu)

    def consume_result(result: dict[str, Any]) -> None:
        """Merge one worker result into the aggregate state.

        The helper keeps protection detection, route tracing, and summary generation
        separate while sharing the same normalized route index.
        """
        nonlocal routes_seen, protection_free_routes
        routes_seen += 1
        error = result.get("error")
        if error:
            if not config.ignore_errors:
                raise RuntimeError(
                    f"route {error['route_id']} failed during protection analysis: "
                    f"{error['error_type']}: {error['message']}"
                )
            errors.append(error)
            try:
                route_index = build_route_index(route_by_id[result["route_id"]])
                route_stats_rows.append(
                    route_stats_row(result["route_id"], route_index, [], [])
                )
            except Exception:
                pass
            return

        events.extend(result["events"])
        interval_rules.extend(result["interval_rules"])
        single_rule_observations.extend(result.get("single_rule_observations", []))
        if result["route_stats_row"] is not None:
            route_stats_rows.append(result["route_stats_row"])
        if result.get("protection_free_route"):
            protection_free_routes += 1
        if result["debug_route"] is not None:
            debug_routes[result["route_id"]] = result["debug_route"]

        if progress_interval and routes_seen % progress_interval == 0:
            print(
                "[analyze-protection] processed "
                f"{routes_seen} routes; events={len(events)}; "
                f"failures={sum(1 for event in events if event.trace_status == 'failed')}; "
                f"ambiguous={sum(1 for event in events if event.trace_status == 'ambiguous')}",
                file=sys.stderr,
                flush=True,
            )

    if n_cpu > 1 and route_work_items:
        with ProcessPoolExecutor(
            max_workers=n_cpu,
            initializer=_init_protection_worker,
            initargs=(config, rrseq_index, None),
        ) as executor:
            for result in executor.map(_protection_route_worker, route_work_items):
                consume_result(result)
    else:
        try:
            for route_id, route in route_work_items:
                try:
                    route_events, route_interval_rules, route_index = (
                        analyze_route_protection(
                            route,
                            route_id,
                            protection_rules,
                            rrseq_index=rrseq_index,
                            config=config,
                            rule_extractor=rule_extractor,
                        )
                    )
                    route_single_rules = collect_single_rule_observations(
                        route_events,
                        route_index,
                        rule_extractor,
                    )
                    stats_row = route_stats_row(
                        route_id,
                        route_index,
                        route_events,
                        route_interval_rules,
                    )
                    result = {
                        "route_id": route_id,
                        "events": route_events,
                        "interval_rules": route_interval_rules,
                        "single_rule_observations": route_single_rules,
                        "route_stats_row": stats_row,
                        "protection_free_route": not route_events,
                        "debug_route": (
                            route_index.route
                            if config.write_debug_json and route_events
                            else None
                        ),
                        "error": None,
                    }
                except Exception as exc:
                    result = {
                        "route_id": route_id,
                        "events": [],
                        "interval_rules": [],
                        "single_rule_observations": [],
                        "route_stats_row": None,
                        "protection_free_route": False,
                        "debug_route": None,
                        "error": {
                            "route_id": route_id,
                            "stage": "analyze_route_protection",
                            "error_type": type(exc).__qualname__,
                            "message": str(exc)
                            or traceback.format_exc(limit=1).strip(),
                        },
                    }
                consume_result(result)
        finally:
            pass

    if progress_interval and routes_seen % progress_interval:
        print(
            "[analyze-protection] processed "
            f"{routes_seen} routes; events={len(events)}; "
            f"failures={sum(1 for event in events if event.trace_status == 'failed')}; "
            f"ambiguous={sum(1 for event in events if event.trace_status == 'ambiguous')}",
            file=sys.stderr,
            flush=True,
        )

    event_rows = [event_to_row(event) for event in events]
    interval_rule_rows = [interval_rule_to_row(obs) for obs in interval_rules]
    trace_failure_rows = [
        trace_failure_row(event)
        for event in events
        if event.trace_status in {"failed", "ambiguous"}
    ]
    group_summary_rows = summarize_groups(events, interval_rules)
    rule_family_rows = summarize_rule_families(events, interval_rules)
    single_rule_rows = summarize_single_rules(single_rule_observations)
    aggregate_single_rule_rows = summarize_aggregate_single_rules(
        single_rule_observations
    )

    top_pg_types = [
        {"pg_type": row["pg_type"], "popularity": row["popularity"]}
        for row in group_summary_rows[:20]
    ]
    n_resolved_stock, resolved_stock_lifetime_histogram = (
        resolved_stock_lifetime_summary(events)
    )
    summary = {
        "dataset": "",
        "n_routes": routes_seen,
        "n_routes_with_pg": len({event.route_id for event in events}),
        "n_protection_free_routes": protection_free_routes,
        "n_deprotection_events": len(events),
        "n_protection_single_rules": len(single_rule_rows),
        "n_protection_agg_single_rules": len(aggregate_single_rule_rows),
        "n_protection_single_rule_observations": len(single_rule_observations),
        "n_resolved_introduced": sum(
            1 for event in events if event.trace_status == "introduced"
        ),
        "n_resolved_protected_synthon": sum(
            1 for event in events if event.trace_status == "protected_synthon"
        ),
        "n_resolved_stock": n_resolved_stock,
        "resolved_stock_lifetime_histogram": resolved_stock_lifetime_histogram,
        "n_ambiguous": sum(1 for event in events if event.trace_status == "ambiguous"),
        "n_failed": sum(1 for event in events if event.trace_status == "failed"),
        "n_multicenter_deprotections": sum(
            1
            for event in events
            if event.multicenter_status
            in {"deprotection_plus_other", "deprotective_combo"}
        ),
        "n_deprotective_combo_events": sum(
            1 for event in events if event.multicenter_status == "deprotective_combo"
        ),
        "top_pg_types": top_pg_types,
        "top_pg_rule_families": rule_family_rows[:20],
        "config": config.raw_config
        or {
            "min_rrseq_cons_size": config.min_rrseq_cons_size,
            "max_rrseq_cons_size": config.max_rrseq_cons_size,
            "similarity_threshold": config.similarity_threshold,
            "include_multicenter": config.include_multicenter,
            "querycgr_compare": config.querycgr_compare,
        },
        "n_cpu": n_cpu,
        "software": {
            "rrseqs_commit": "",
            "chython_version": "",
            "synplanner_version": "",
        },
        "n_errors": len(errors),
        "errors": errors[:100],
        "n_chython_protection_rules": len(protection_rules),
    }
    return ProtectionAnalysisResult(
        route_stats_rows=route_stats_rows,
        event_rows=event_rows,
        interval_rule_rows=interval_rule_rows,
        single_rule_rows=single_rule_rows,
        aggregate_single_rule_rows=aggregate_single_rule_rows,
        group_summary_rows=group_summary_rows,
        rule_family_rows=rule_family_rows,
        trace_failure_rows=trace_failure_rows,
        summary=summary,
        debug_routes=debug_routes,
        trace_event_records=[deprotection_event_to_record(event) for event in events],
    )


@dataclass
class ProtectionOverrides:
    min_rrseq_cons_size: int | None = None
    max_rrseq_cons_size: int | None = None
    similarity_threshold: float | None = None
    include_multicenter: bool = False
    deprotection_first: bool = False
    querycgr_compare: bool = False
    write_debug_json: bool = False
    write_debug_svg: bool = False
    ignore_errors: bool = False
