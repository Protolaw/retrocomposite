"""Public ProtectingGroupStrategy extraction, catalog, and assessment API."""

from __future__ import annotations

from importlib import import_module

_PUBLIC_MODULES = {
    "PGStrategyNgramIdentity": "ngrams",
    "PGStrategyNgramOccurrence": "ngrams",
    "extract_pg_ngrams": "ngrams",
    "PGStrategyNgramMatch": "assessment",
    "RoutePGStrategyProcessor": "processor",
    "build_pg_strategy_library": "construction",
    "PGStrategyPublicationResult": "construction",
    "INCOMPLETE_PG_ASSESSMENT_LIMITATION": "assessment",
    "NO_DETECTED_PG_EVENTS_LIMITATION": "assessment",
    "PG_COMPONENT_UNAVAILABLE_LIMITATION": "assessment",
    "PG_STRATEGY_ASSESSMENT_SCHEMA_VERSION": "catalog",
    "PG_STRATEGY_AVAILABILITIES": "assessment",
    "PG_STRATEGY_CATALOG_SCHEMA_VERSION": "catalog",
    "PG_STRATEGY_IDENTITY_VERSION": "models",
    "PG_STRATEGY_INTERVAL_IDENTITY_VERSION": "models",
    "PG_STRATEGY_INTERVAL_OCCURRENCE_SCHEMA_VERSION": "models",
    "PG_STRATEGY_LIBRARY_FORMAT_VERSION": "catalog",
    "PG_STRATEGY_OCCURRENCE_SCHEMA_VERSION": "models",
    "PG_STRATEGY_SOURCE_TYPES": "models",
    "PG_STRATEGY_SCOPES": "assessment",
    "PG_STRATEGY_STATUSES": "assessment",
    "PGStrategyCoverage": "assessment",
    "PGStrategyEventMatch": "assessment",
    "PGStrategyIntervalSequenceIdentity": "models",
    "PGStrategyIntervalSequenceMatch": "assessment",
    "PGStrategyIntervalSequenceOccurrence": "models",
    "PGStrategyIntervalStepIdentity": "models",
    "PGStrategyIntervalStepMatch": "assessment",
    "PGStrategyIntervalStepOccurrence": "models",
    "PGStrategyLibraryEntry": "catalog",
    "PGStrategyLibraryManifest": "catalog",
    "PGStrategyScopeSupport": "assessment",
    "ProcessedRoutePGStrategies": "models",
    "ProtectingGroupStrategyIdentity": "models",
    "ProtectingGroupStrategyOccurrence": "models",
    "ReferencePGStrategyLibrary": "catalog",
    "RoutePGStrategyAssessment": "assessment",
    "annotate_pg_strategy_classifications": "processing",
    "assess_pg_strategies": "assessment",
    "extract_pg_strategies_from_prepared_route": "processing",
}

__all__ = sorted(_PUBLIC_MODULES)


def __getattr__(name: str):
    module_name = _PUBLIC_MODULES.get(name)
    if module_name is None:
        raise AttributeError(name)
    value = getattr(
        import_module(f"route_inspector.protection.strategies.{module_name}"),
        name,
    )
    globals()[name] = value
    return value
