"""Bounded format-4 PG publication, retaining every contiguous lifespan window."""

from __future__ import annotations

import csv
import hashlib
import json
import sqlite3
from collections import Counter
from contextlib import nullcontext
from pathlib import Path

from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.protection.strategies.catalog import (
    _COMPONENT_PATHS,
    _SCHEMA_SQL,
    PGStrategyLibraryManifest,
    _digest,
)
from route_inspector.protection.strategies.normalized import (
    GRAPH_PATH,
    GraphStore,
    window_record,
)
from route_inspector.rules.graph import canonical_json

PATHS = {**_COMPONENT_PATHS, "rule_graphs": GRAPH_PATH}
POLICY = {
    "version": 1,
    "graphs": "exact-representation-references",
    "windows": "all-contiguous",
}


def _support(kind, value, graphs):
    result = {key: value[key] for key in ("occurrence_id", "route")}
    result["occurrence_sha256"] = graphs.expanded_digest(value)
    if kind != "event":
        result.update(
            {key: value[key] for key in ("event_occurrence_id", "focal_pg_type")}
        )
    if kind == "interval_step":
        result["active_pg_types"] = value["active_pg_types"]
    elif kind in {"interval_sequence", "interval_ngram"}:
        result.update(
            {key: value[key] for key in ("active_pg_contexts", "step_occurrence_ids")}
        )
    if kind == "interval_ngram":
        result.update(
            {
                key: value[key]
                for key in ("start_index", "length", "reaction_node_paths")
            }
        )
    return result


def _schema(db):
    db.executescript(
        _SCHEMA_SQL
        + """
        CREATE TABLE rule_graphs(graph_id TEXT PRIMARY KEY, graph_json TEXT NOT NULL) WITHOUT ROWID;
        CREATE TABLE interval_ngram_occurrences(occurrence_id TEXT PRIMARY KEY,
            event_occurrence_id TEXT NOT NULL, occurrence_json TEXT NOT NULL);
        CREATE INDEX interval_ngrams_event ON interval_ngram_occurrences(event_occurrence_id);
        CREATE INDEX normalized_event_routes ON event_occurrences(dataset_id,source_identity,route_id);
        CREATE INDEX normalized_step_routes ON interval_step_occurrences(dataset_id,source_identity,route_id);
        CREATE TABLE graph_families(graph_id TEXT PRIMARY KEY, signature TEXT, family TEXT);
        CREATE INDEX graph_family_signature ON graph_families(signature);
        CREATE TABLE staged(kind TEXT, oid TEXT PRIMARY KEY, lookup_key TEXT,
            family TEXT, identity_json TEXT, support_json TEXT);
        CREATE INDEX staged_groups ON staged(kind, lookup_key, family, oid);
        CREATE TABLE processed_routes(dataset TEXT, source TEXT, route TEXT,
            PRIMARY KEY(dataset,source,route)) WITHOUT ROWID;
    """
    )
    db.execute("PRAGMA user_version=4")


def _stage(db, graphs, kind, value):
    identity = value["identity"]
    db.execute(
        "INSERT INTO staged VALUES(?,?,?,?,?,?)",
        (
            kind,
            value["occurrence_id"],
            identity["lookup_key"],
            graphs.group_key(identity),
            canonical_json(identity),
            canonical_json(_support(kind, value, graphs)),
        ),
    )
    if kind in {"event", "interval_step"}:
        encoded = canonical_json(value)
        route = value["route"]
        common = (route["dataset_id"], route["source_identity"], route["route_id"])
        if kind == "event":
            db.execute(
                "INSERT INTO event_occurrences VALUES(?,?,?,?,?,?)",
                (
                    value["occurrence_id"],
                    "",
                    *common,
                    encoded,
                ),
            )
        else:
            db.execute(
                "INSERT INTO interval_step_occurrences VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    value["occurrence_id"],
                    "",
                    value["event_occurrence_id"],
                    value["focal_pg_type"],
                    canonical_json(value["active_pg_types"]),
                    *common,
                    encoded,
                ),
            )
    elif kind == "interval_ngram":
        compact = {
            key: value[key]
            for key in ("occurrence_id", "event_occurrence_id", "start_index", "length")
        }
        db.execute(
            "INSERT INTO interval_ngram_occurrences VALUES(?,?,?)",
            (
                value["occurrence_id"],
                value["event_occurrence_id"],
                canonical_json(compact),
            ),
        )


def _stage_route(
    db, graphs, route, counters, event_routes, ngram_routes, histogram, *, stage=_stage
):
    key = (route.route.dataset_id, route.route.source_identity, route.route.route_id)
    db.execute("INSERT INTO processed_routes VALUES(?,?,?)", key)
    steps = {step.occurrence_id: step for step in route.interval_steps}
    sequences = {
        sequence.occurrence_id: sequence for sequence in route.interval_sequences
    }
    if len(steps) != len(route.interval_steps) or len(sequences) != len(
        route.interval_sequences
    ):
        raise ValueError("duplicate PG step or sequence provenance")
    consumed_steps, consumed_sequences = set(), set()
    for event in route.events:
        if event.route != route.route:
            raise ValueError("PG event belongs to another route")
        value = event.to_dict()
        value["identity"] = graphs.pack(value["identity"])
        stage(db, graphs, "event", value)
        counters["event_occurrence_count"] += 1
        counters["target_retained_event_count"] += event.terminus == "preserved"
        counters["deprotection_ended_event_count"] += event.terminus == "not_preserved"
        counters["unresolved_target_event_count"] += event.source_type == "unknown"
        counters["resolved_event_count"] += event.source_type != "unknown"
        counters[
            {
                "introduced": "introduced_event_count",
                "stock": "stock_event_count",
                "protected_synthon": "protected_synthon_event_count",
                "unknown": "_unknown",
            }[event.source_type]
        ] += 1
        if event.source_type != "unknown":
            event_routes.add(key)
        interval = []
        for i, step_id in enumerate(event.interval_step_occurrence_ids):
            step = steps[step_id]
            if (
                step_id in consumed_steps
                or step.route != event.route
                or step.event_occurrence_id != event.occurrence_id
                or step.focal_pg_type != event.pg_type
                or step.step_index != i
                or step.reaction_node_path != event.interval_reaction_node_paths[i]
            ):
                raise ValueError("inconsistent PG event/step provenance")
            consumed_steps.add(step_id)
            raw = step.to_dict()
            raw["identity"] = graphs.pack(raw["identity"])
            stage(db, graphs, "interval_step", raw)
            interval.append(raw)
            counters["interval_step_occurrence_count"] += 1
        if len(interval) != event.lifetime_steps:
            raise ValueError("PG lifespan disagrees with interval steps")
        if event.interval_sequence_occurrence_id:
            sequence = window_record(
                value, interval, 0, len(interval), graphs, ngram=False
            )
            original = sequences[event.interval_sequence_occurrence_id].to_dict()
            original["identity"] = graphs.pack(original["identity"])
            if original != sequence:
                raise ValueError("PG complete interval disagrees with event steps")
            consumed_sequences.add(event.interval_sequence_occurrence_id)
            stage(db, graphs, "interval_sequence", sequence)
            counters["interval_sequence_occurrence_count"] += 1
        if len(interval) >= 2:
            counters["interval_ngram_event_count"] += 1
            ngram_routes.add(key)
        for length in range(2, len(interval) + 1):
            for start in range(len(interval) - length + 1):
                gram = window_record(value, interval, start, length, graphs)
                stage(db, graphs, "interval_ngram", gram)
                histogram[str(length)] += 1
                counters["interval_ngram_occurrence_count"] += 1
    if consumed_steps != set(steps) or consumed_sequences != set(sequences):
        raise ValueError("orphan PG interval evidence")
    for diagnostic in route.diagnostics:
        db.execute(
            "INSERT INTO diagnostics(diagnostic_json) VALUES(?)",
            (canonical_json(diagnostic),),
        )
        counters["diagnostic_count"] += 1


def _entries(db, graphs):
    """Assign the legacy exact-equivalence IDs, one coarse bucket at a time."""
    for kind, lookup in db.execute(
        "SELECT DISTINCT kind,lookup_key FROM staged ORDER BY kind,lookup_key"
    ):
        groups = []
        for family, oid in db.execute(
            "SELECT family,MIN(oid) FROM staged WHERE kind=? AND lookup_key=? GROUP BY family",
            (kind, lookup),
        ):
            identity = json.loads(
                db.execute(
                    "SELECT identity_json FROM staged WHERE oid=?", (oid,)
                ).fetchone()[0]
            )
            groups.append((None, family, oid, identity))
        # Ordinal zero is unambiguous for a singleton bucket. Only collisions
        # need the expanded canonical representation to establish native order.
        if len(groups) > 1:
            groups = [
                (canonical_json(graphs.unpack(identity)), family, oid, identity)
                for _, family, oid, identity in groups
            ]
        for ordinal, (_, family, representative, identity) in enumerate(sorted(groups)):
            records = [
                json.loads(row[0])
                for row in db.execute(
                    "SELECT support_json FROM staged WHERE kind=? AND lookup_key=? AND family=? ORDER BY oid",
                    (kind, lookup, family),
                )
            ]
            routes = {
                tuple(
                    r["route"][k] for k in ("dataset_id", "source_identity", "route_id")
                )
                for r in records
            }
            entry_id = f"{lookup}~{ordinal:04d}"
            entry = dict(
                kind=kind,
                entry_id=entry_id,
                identity=identity,
                lookup_key=lookup,
                occurrence_count=len(records),
                route_count=len(routes),
                reference_routes=[
                    dict(zip(("dataset_id", "source_identity", "route_id"), r))
                    for r in sorted(routes)
                ],
                representative_occurrence_id=representative,
                support_records=records,
            )
            db.execute(
                "INSERT INTO entries VALUES(?,?,?,?)",
                (entry_id, kind, lookup, canonical_json(entry)),
            )
            if kind in {"event", "interval_step"}:
                table = (
                    "event_occurrences"
                    if kind == "event"
                    else "interval_step_occurrences"
                )
                db.execute(
                    f"UPDATE {table} SET entry_id=? WHERE occurrence_id IN "
                    "(SELECT oid FROM staged WHERE kind=? AND lookup_key=? AND family=?)",
                    (entry_id, kind, lookup, family),
                )
    db.commit()


def _jsonl(path, values, *, retain=True):
    path.parent.mkdir(parents=True, exist_ok=True)
    digest, size = hashlib.sha256(), 0
    with path.open("wb") if retain else nullcontext(None) as stream:
        for value in values:
            encoded = (canonical_json(value) + "\n").encode("utf-8")
            digest.update(encoded)
            size += len(encoded)
            if stream is not None:
                stream.write(encoded)
    return {"sha256": digest.hexdigest(), "size_bytes": size}


def _reports(db, root):
    specifications = (
        (
            "event",
            "report_events",
            (
                "entry_id",
                "pg_type",
                "source_type",
                "protected_functional_group",
                "route_count",
                "occurrence_count",
                "representative_occurrence_id",
            ),
        ),
        (
            "interval_step",
            "report_interval_steps",
            (
                "entry_id",
                "route_count",
                "occurrence_count",
                "representative_occurrence_id",
            ),
        ),
        (
            "interval_sequence",
            "report_interval_sequences",
            (
                "entry_id",
                "length",
                "route_count",
                "occurrence_count",
                "representative_occurrence_id",
            ),
        ),
        (
            "interval_ngram",
            "report_ngrams",
            ("entry_id", "length", "occurrence_count", "event_count", "route_count"),
        ),
    )
    for kind, name, fields in specifications:
        path = root / PATHS[name]
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields, delimiter="\t")
            writer.writeheader()
            for (row,) in db.execute(
                "SELECT entry_json FROM entries WHERE kind=? ORDER BY entry_id", (kind,)
            ):
                entry = json.loads(row)
                value = {**entry, **entry["identity"]}
                value["length"] = len(entry["identity"].get("rule_graphs", ()))
                value["event_count"] = (
                    len(
                        {r.get("event_occurrence_id") for r in entry["support_records"]}
                    )
                    if "support_records" in entry
                    else db.execute(
                        "SELECT COUNT(DISTINCT event_id) FROM memberships WHERE entry_id=?",
                        (entry["entry_id"],),
                    ).fetchone()[0]
                )
                writer.writerow({key: value[key] for key in fields})
    from route_inspector.protection.strategies.construction import _errors

    _errors(
        root / PATHS["errors"],
        (
            json.loads(r[0])
            for r in db.execute(
                "SELECT diagnostic_json FROM diagnostics ORDER BY ordinal"
            )
        ),
    )


def publication_id(profile, corpora, statistics, artifacts):
    return "pg_strategy_library_" + _digest(
        {
            "format": 4,
            "storage_policy": POLICY,
            "profile": profile,
            "reference_corpora": list(corpora),
            "statistics": statistics,
            "portable_artifacts": {
                k: v["sha256"]
                for k, v in artifacts.items()
                if k not in {"catalog", "summary"}
            },
        }
    )


def write_normalized(
    processed_routes,
    root,
    *,
    processing_profile,
    reference_corpora,
    include_sqlite=True,
    retain_portable=True,
):
    """Stage one route at a time; never materialize the corpus's graph windows."""
    root = Path(root)
    if not retain_portable and not include_sqlite:
        raise ValueError("verification-only reconstruction requires SQLite")
    root.mkdir(parents=True, exist_ok=True)
    path = root / PATHS["catalog"]
    db = sqlite3.connect(path, timeout=60)
    # Reclaim staging pages in place; VACUUM would duplicate a large publication.
    db.execute("PRAGMA auto_vacuum=INCREMENTAL")
    db.execute("PRAGMA cache_size=-16384")
    db.execute("PRAGMA temp_store=FILE")
    graphs = GraphStore(db)
    try:
        _schema(db)
        counters = Counter(
            {
                name: 0
                for name in (
                    "event_occurrence_count",
                    "interval_step_occurrence_count",
                    "interval_sequence_occurrence_count",
                    "interval_ngram_occurrence_count",
                    "interval_ngram_event_count",
                    "diagnostic_count",
                    "target_retained_event_count",
                    "deprotection_ended_event_count",
                    "unresolved_target_event_count",
                    "resolved_event_count",
                    "introduced_event_count",
                    "protected_synthon_event_count",
                    "stock_event_count",
                )
            }
        )
        event_routes, ngram_routes, histogram = set(), set(), Counter()
        for index, route in enumerate(processed_routes):
            _stage_route(
                db, graphs, route, counters, event_routes, ngram_routes, histogram
            )
            db.commit()
            if (index + 1) % 100 == 0:
                print(
                    f"[pg-normalize] {index + 1} routes; {counters['interval_ngram_occurrence_count']} windows",
                    flush=True,
                )
        _entries(db, graphs)
        graphs.clear()
        db.executescript(
            "DROP TABLE staged; DROP TABLE graph_families; DROP TABLE processed_routes;"
        )
        db.execute("PRAGMA incremental_vacuum").fetchall()
        counters.pop("_unknown", None)
        statistics = {
            **dict(counters),
            "route_count_with_resolved_events": len(event_routes),
            "interval_ngram_route_count": len(ngram_routes),
            "interval_ngram_length_histogram": dict(sorted(histogram.items())),
        }
        for kind in ("event", "interval_step", "interval_sequence", "interval_ngram"):
            statistics[f"{kind}_entry_count"] = db.execute(
                "SELECT COUNT(*) FROM entries WHERE kind=?", (kind,)
            ).fetchone()[0]
        # Canonicalize retained diagnostics independently of extraction order.
        db.executescript("""
            CREATE TABLE sorted_diagnostics AS SELECT diagnostic_json FROM diagnostics ORDER BY diagnostic_json;
            DELETE FROM diagnostics;
            INSERT INTO diagnostics SELECT rowid-1, diagnostic_json FROM sorted_diagnostics ORDER BY rowid;
            DROP TABLE sorted_diagnostics;
        """)
        portable = {}
        for name, kind in (
            ("event_entries", "event"),
            ("interval_step_entries", "interval_step"),
            ("interval_sequence_entries", "interval_sequence"),
            ("ngram_entries", "interval_ngram"),
        ):
            portable[name] = _jsonl(
                root / PATHS[name],
                (
                    json.loads(row[0])
                    for row in db.execute(
                        "SELECT entry_json FROM entries WHERE kind=? ORDER BY entry_id",
                        (kind,),
                    )
                ),
                retain=retain_portable,
            )
        for name, table in (
            ("event_occurrences", "event_occurrences"),
            ("interval_step_occurrences", "interval_step_occurrences"),
            ("ngram_occurrences", "interval_ngram_occurrences"),
        ):
            portable[name] = _jsonl(
                root / PATHS[name],
                (
                    json.loads(row[0])
                    for row in db.execute(
                        f"SELECT occurrence_json FROM {table} ORDER BY occurrence_id"
                    )
                ),
                retain=retain_portable,
            )
        portable["rule_graphs"] = _jsonl(
            root / PATHS["rule_graphs"],
            (
                {"graph_id": key, "graph": json.loads(value)}
                for key, value in db.execute(
                    "SELECT graph_id,graph_json FROM rule_graphs ORDER BY graph_id"
                )
            ),
            retain=retain_portable,
        )
        portable["diagnostics"] = _jsonl(
            root / PATHS["diagnostics"],
            (
                json.loads(row[0])
                for row in db.execute(
                    "SELECT diagnostic_json FROM diagnostics ORDER BY ordinal"
                )
            ),
            retain=retain_portable,
        )
        _reports(db, root)
        artifacts = {
            name: {
                "path": relative,
                **(
                    portable[name]
                    if name in portable
                    else {
                        "sha256": sha256_file(root / relative),
                        "size_bytes": (root / relative).stat().st_size,
                    }
                ),
            }
            for name, relative in sorted(PATHS.items())
            if name not in {"summary", "catalog"}
        }
        library_id = publication_id(
            processing_profile, reference_corpora, statistics, artifacts
        )
        (root / PATHS["summary"]).write_text(
            json.dumps({"library_id": library_id, **statistics}, indent=2) + "\n"
        )
        db.executemany(
            "INSERT INTO metadata VALUES(?,?)",
            (
                ("library_id", canonical_json(library_id)),
                ("statistics", canonical_json(statistics)),
            ),
        )
        from route_inspector.protection.strategies.browsing import (
            build_browse_tables,
            sqlite_browse_entries,
        )

        build_browse_tables(db, sqlite_browse_entries(db))
        db.commit()
        graphs.clear()
        db.execute("PRAGMA incremental_vacuum").fetchall()
    finally:
        graphs.clear()
        db.close()
    if not include_sqlite:
        path.unlink()
    for name in ("summary", "catalog") if include_sqlite else ("summary",):
        p = root / PATHS[name]
        artifacts[name] = {
            "path": PATHS[name],
            "sha256": sha256_file(p),
            "size_bytes": p.stat().st_size,
        }
    manifest = PGStrategyLibraryManifest(
        library_id,
        processing_profile,
        tuple(reference_corpora),
        statistics,
        artifacts,
        library_format_version=4,
        catalog_schema_version=4,
    )
    (root / "manifest.json").write_text(json.dumps(manifest.to_dict(), indent=2) + "\n")
    return manifest
