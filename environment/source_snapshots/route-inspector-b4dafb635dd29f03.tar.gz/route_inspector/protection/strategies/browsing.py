"""Derived SQLite navigation indexes; chemistry and provenance stay authoritative."""

import json

BROWSE_VERSION = 1
BROWSE_TABLES = ("events", "grams", "tactic_windows")


def build_browse_tables(connection, entries):
    """Build indexes from already validated serialized entries, without chemistry."""
    connection.executescript("""
        CREATE TABLE pg_browse_metadata(version INTEGER NOT NULL);
        CREATE TABLE pg_browse_events(id TEXT PRIMARY KEY, family TEXT, pg TEXT,
            origin TEXT, functional_group TEXT, route_id TEXT, terminus TEXT);
        CREATE INDEX pg_browse_event_routes ON pg_browse_events(route_id);
        CREATE INDEX pg_browse_event_types ON pg_browse_events(pg, origin, family);
        CREATE INDEX pg_browse_event_filters ON pg_browse_events(origin, terminus, id);
        CREATE TABLE pg_browse_grams(id TEXT PRIMARY KEY, event TEXT, payload TEXT);
        CREATE INDEX pg_browse_gram_events ON pg_browse_grams(event);
        CREATE TABLE pg_browse_tactic_windows(id TEXT PRIMARY KEY, event TEXT,
            entry TEXT, length INTEGER, payload TEXT);
        CREATE INDEX pg_browse_window_entry ON pg_browse_tactic_windows(entry, event);
        CREATE INDEX pg_browse_window_event ON pg_browse_tactic_windows(event, entry);
    """)
    with connection:
        for entry in entries:
            kind = entry["kind"]
            identity = entry["identity"]
            if kind == "event":
                terminus = (
                    "unavailable"
                    if identity.get("identity_version", 1) < 3
                    else "preserved"
                    if identity["endpoint_kind"] == "target"
                    else "not_preserved"
                )
                connection.executemany(
                    "INSERT INTO pg_browse_events VALUES(?,?,?,?,?,?,?)",
                    (
                        (
                            r["occurrence_id"],
                            entry["entry_id"],
                            identity["pg_type"],
                            identity["source_type"],
                            identity["protected_functional_group"],
                            r["route"]["route_id"],
                            terminus,
                        )
                        for r in entry["support_records"]
                    ),
                )
            elif kind in {"interval_step", "interval_ngram"}:
                for record in entry["support_records"]:
                    payload = {**record, "entry_id": entry["entry_id"]}
                    if kind == "interval_step":
                        payload.update(
                            length=1, step_occurrence_ids=[record["occurrence_id"]]
                        )
                    else:
                        payload.update(
                            route_count=entry["route_count"],
                            occurrence_count=entry["occurrence_count"],
                        )
                    encoded = json.dumps(payload)
                    if kind == "interval_ngram":
                        connection.execute(
                            "INSERT INTO pg_browse_grams VALUES(?,?,?)",
                            (
                                record["occurrence_id"],
                                record["event_occurrence_id"],
                                encoded,
                            ),
                        )
                    connection.execute(
                        "INSERT INTO pg_browse_tactic_windows VALUES(?,?,?,?,?)",
                        (
                            record["occurrence_id"],
                            record["event_occurrence_id"],
                            entry["entry_id"],
                            payload["length"],
                            encoded,
                        ),
                    )
        connection.execute(
            "INSERT INTO pg_browse_metadata VALUES(?)", (BROWSE_VERSION,)
        )


def sqlite_browse_entries(connection):
    return (
        json.loads(row[0])
        for row in connection.execute(
            "SELECT entry_json FROM entries WHERE kind IN ('event','interval_step','interval_ngram') ORDER BY entry_id"
        )
    )


def has_browse_tables(connection):
    tables = {
        r[0]
        for r in connection.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table','view')"
        )
    }
    if (
        not {"pg_browse_metadata", *(f"pg_browse_{name}" for name in BROWSE_TABLES)}
        <= tables
    ):
        return False
    return [
        tuple(r) for r in connection.execute("SELECT version FROM pg_browse_metadata")
    ] in ([(BROWSE_VERSION,)], [(2,)])
