"""Internal PG-interval similarity helpers used by scientific tutorials."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from route_inspector.rules.graph import (
    graph_coarse_signature,
    labelled_graphs_are_isomorphic,
    reaction_center_graph,
)


@dataclass(frozen=True)
class ContiguousNgramMatch:
    """One deterministic longest common contiguous window."""

    length: int = 0
    query_start: int | None = None
    reference_start: int | None = None

    def __post_init__(self) -> None:
        if self.length < 0:
            raise ValueError("n-gram length cannot be negative")
        has_positions = (
            self.query_start is not None and self.reference_start is not None
        )
        if (self.length > 0) != has_positions:
            raise ValueError("non-empty n-grams require query and Reference starts")

    @property
    def query_stop(self) -> int | None:
        return None if self.query_start is None else self.query_start + self.length

    @property
    def reference_stop(self) -> int | None:
        return (
            None if self.reference_start is None else self.reference_start + self.length
        )


def longest_common_contiguous_ngram(
    query: Sequence[Any],
    reference: Sequence[Any],
    equivalent: Callable[[Any, Any], bool],
) -> ContiguousNgramMatch:
    """Return the longest ordered contiguous match with deterministic ties."""

    best = ContiguousNgramMatch()
    for query_start in range(len(query)):
        for reference_start in range(len(reference)):
            length = 0
            while (
                query_start + length < len(query)
                and reference_start + length < len(reference)
                and equivalent(
                    query[query_start + length],
                    reference[reference_start + length],
                )
            ):
                length += 1
            candidate = ContiguousNgramMatch(
                length=length,
                query_start=query_start if length else None,
                reference_start=reference_start if length else None,
            )
            if candidate.length > best.length or (
                candidate.length == best.length
                and candidate.length > 0
                and (
                    candidate.query_start,
                    candidate.reference_start,
                )
                < (best.query_start, best.reference_start)
            ):
                best = candidate
    return best


def query_position_coverage(
    query: Sequence[Any],
    reference: Sequence[Any],
    equivalent: Callable[[Any, Any], bool],
) -> int:
    """Count query positions supported by at least one Reference position."""

    return sum(
        any(equivalent(query_item, reference_item) for reference_item in reference)
        for query_item in query
    )


@dataclass(frozen=True)
class PGIntervalEventSimilarity:
    """Similarity evidence for one query/Reference PG-event pair."""

    reference_event: Any
    reference_steps: tuple[Any, ...]
    class_ngram: ContiguousNgramMatch
    center_ngram: ContiguousNgramMatch
    exact_rule_ngram: ContiguousNgramMatch
    query_position_coverage: int
    exact_event: bool

    @property
    def selected_evidence(self) -> tuple[str, ContiguousNgramMatch]:
        if self.class_ngram.length:
            return "reaction class", self.class_ngram
        if self.center_ngram.length:
            return "reaction centre", self.center_ngram
        return "exact rule", self.exact_rule_ngram


@dataclass(frozen=True)
class PGIntervalEventRanking:
    """Reference cohort and deterministic route-deduplicated ranking."""

    candidates: tuple[PGIntervalEventSimilarity, ...]
    related_event_count: int
    related_route_count: int
    eligible_event_count: int
    eligible_route_count: int
    lifespan_filter_relaxed: bool
    max_available_lifespan: int | None


def _accepted_tier3_code(classification: Mapping[str, Any]) -> str | None:
    code = classification.get("tier3_code")
    if not classification.get("accepted") or code is None:
        return None
    text = str(code).strip()
    return text or None


def _route_sort_key(route_id: Any) -> tuple[int, int, str]:
    text = str(route_id)
    if text.isdigit():
        return 0, int(text), ""
    return 1, 0, text


def rank_pg_interval_event_candidates(
    query_event: Any,
    query_steps: Sequence[Any],
    reference_events: Sequence[Any],
    steps_by_event: Mapping[str, Sequence[Any]],
    query_classifications: Mapping[str, Mapping[str, Any]],
) -> PGIntervalEventRanking:
    """Rank Reference PG intervals without requiring exact endpoint identity."""

    query_steps = tuple(sorted(query_steps, key=lambda item: item.step_index))
    related = tuple(
        event
        for event in reference_events
        if event.pg_type == query_event.pg_type
        and event.protected_functional_group == query_event.protected_functional_group
        and event.source_type == query_event.source_type
    )
    preferred = tuple(
        event for event in related if event.lifetime_steps >= query_event.lifetime_steps
    )
    eligible = preferred or related
    lifespan_filter_relaxed = bool(related) and not bool(preferred)

    def class_equivalent(query_step: Any, reference_step: Any) -> bool:
        query_code = _accepted_tier3_code(
            query_classifications.get(query_step.occurrence_id, {})
        )
        reference_code = _accepted_tier3_code(reference_step.classification)
        return query_code is not None and query_code == reference_code

    center_graph_cache: dict[int, tuple[str, Mapping[str, Any]]] = {}
    center_pair_cache: dict[tuple[int, int], bool] = {}
    exact_pair_cache: dict[tuple[int, int], bool] = {}

    def center_graph(step: Any) -> tuple[str, Mapping[str, Any]]:
        key = id(step)
        cached = center_graph_cache.get(key)
        if cached is None:
            graph = reaction_center_graph(step.identity.rule_graph)
            cached = graph_coarse_signature(graph), graph
            center_graph_cache[key] = cached
        return cached

    def center_equivalent(query_step: Any, reference_step: Any) -> bool:
        key = id(query_step), id(reference_step)
        cached = center_pair_cache.get(key)
        if cached is None:
            query_signature, query_graph = center_graph(query_step)
            reference_signature, reference_graph = center_graph(reference_step)
            cached = query_signature == reference_signature and (
                labelled_graphs_are_isomorphic(query_graph, reference_graph)
            )
            center_pair_cache[key] = cached
        return cached

    def exact_rule_equivalent(query_step: Any, reference_step: Any) -> bool:
        key = id(query_step), id(reference_step)
        cached = exact_pair_cache.get(key)
        if cached is None:
            query_lookup = getattr(query_step.identity, "lookup_key", None)
            reference_lookup = getattr(reference_step.identity, "lookup_key", None)
            possible = (
                query_lookup is None
                or reference_lookup is None
                or query_lookup == reference_lookup
            )
            cached = possible and labelled_graphs_are_isomorphic(
                query_step.identity.rule_graph,
                reference_step.identity.rule_graph,
            )
            exact_pair_cache[key] = cached
        return cached

    similarities: list[PGIntervalEventSimilarity] = []
    for event in eligible:
        reference_steps = tuple(
            sorted(
                steps_by_event.get(event.occurrence_id, ()),
                key=lambda item: item.step_index,
            )
        )
        class_ngram = longest_common_contiguous_ngram(
            query_steps,
            reference_steps,
            class_equivalent,
        )
        center_ngram = longest_common_contiguous_ngram(
            query_steps,
            reference_steps,
            center_equivalent,
        )
        exact_rule_ngram = longest_common_contiguous_ngram(
            query_steps,
            reference_steps,
            exact_rule_equivalent,
        )
        coverage = query_position_coverage(
            query_steps,
            reference_steps,
            lambda query_step, reference_step: class_equivalent(
                query_step,
                reference_step,
            )
            or center_equivalent(query_step, reference_step),
        )
        similarities.append(
            PGIntervalEventSimilarity(
                reference_event=event,
                reference_steps=reference_steps,
                class_ngram=class_ngram,
                center_ngram=center_ngram,
                exact_rule_ngram=exact_rule_ngram,
                query_position_coverage=coverage,
                exact_event=query_event.identity.equivalent_to(event.identity),
            )
        )

    similarities.sort(
        key=lambda item: (
            -item.class_ngram.length,
            -item.center_ngram.length,
            -item.exact_rule_ngram.length,
            -item.query_position_coverage,
            abs(item.reference_event.lifetime_steps - query_event.lifetime_steps),
            _route_sort_key(item.reference_event.route.route_id),
            item.reference_event.occurrence_id,
        )
    )
    distinct_routes: list[PGIntervalEventSimilarity] = []
    seen_routes: set[str] = set()
    for item in similarities:
        route_id = str(item.reference_event.route.route_id)
        if route_id in seen_routes:
            continue
        seen_routes.add(route_id)
        distinct_routes.append(item)

    return PGIntervalEventRanking(
        candidates=tuple(distinct_routes),
        related_event_count=len(related),
        related_route_count=len({str(event.route.route_id) for event in related}),
        eligible_event_count=len(eligible),
        eligible_route_count=len({str(event.route.route_id) for event in eligible}),
        lifespan_filter_relaxed=lifespan_filter_relaxed,
        max_available_lifespan=max(
            (event.lifetime_steps for event in related),
            default=None,
        ),
    )


__all__ = [
    "ContiguousNgramMatch",
    "PGIntervalEventRanking",
    "PGIntervalEventSimilarity",
    "longest_common_contiguous_ngram",
    "query_position_coverage",
    "rank_pg_interval_event_candidates",
]
