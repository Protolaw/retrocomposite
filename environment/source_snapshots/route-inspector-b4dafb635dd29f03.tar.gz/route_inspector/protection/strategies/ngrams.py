"""Contiguous, event-qualified windows strictly inside a PG lifespan."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from route_inspector.protection.strategies.models import (
    PGStrategyIntervalSequenceIdentity,
    PGStrategyIntervalSequenceOccurrence,
    ProcessedRoutePGStrategies,
    _digest,
)

NGRAM_POLICY = {
    "version": 1,
    "min_length": 2,
    "max_length": None,
    "order": "synthetic",
    "endpoints": "excluded",
    "contiguous": True,
}


@dataclass(frozen=True)
class PGStrategyNgramIdentity(PGStrategyIntervalSequenceIdentity):
    """Ordered exact rule identity in a namespace separate from full intervals."""

    def __post_init__(self):
        supplied = self.lookup_key
        object.__setattr__(self, "lookup_key", "")
        super().__post_init__()
        if len(self.rule_graphs) < 2:
            raise ValueError("PG n-grams require at least two reactions")
        expected = self.lookup_key.replace(
            "pg_strategy_seq_i_", "pg_strategy_ngram_i_", 1
        )
        if supplied and supplied != expected:
            raise ValueError("PG n-gram lookup key disagrees with identity")
        object.__setattr__(self, "lookup_key", expected)


@dataclass(frozen=True, kw_only=True)
class PGStrategyNgramOccurrence(PGStrategyIntervalSequenceOccurrence):
    start_index: int
    reaction_node_paths: tuple[tuple[int, ...], ...]

    @property
    def length(self):
        return len(self.step_occurrence_ids)

    def __post_init__(self):
        super().__post_init__()
        if not isinstance(self.identity, PGStrategyNgramIdentity):
            raise ValueError("PG n-gram requires an n-gram identity")
        if self.start_index < 0 or len(self.reaction_node_paths) != self.length:
            raise ValueError("invalid PG n-gram positions")
        if any(
            not path or any(i < 0 for i in path) for path in self.reaction_node_paths
        ):
            raise ValueError("invalid PG n-gram reaction paths")
        if self.occurrence_id != ngram_occurrence_id(
            self.event_occurrence_id, self.start_index, self.length
        ):
            raise ValueError("PG n-gram occurrence ID disagrees with positions")

    def to_dict(self):
        return {
            **super().to_dict(),
            "start_index": self.start_index,
            "length": self.length,
            "reaction_node_paths": [list(p) for p in self.reaction_node_paths],
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]):
        from route_inspector.reference_library.models import ReferenceRouteKey

        result = cls(
            schema_version=int(value["schema_version"]),
            occurrence_id=str(value["occurrence_id"]),
            event_occurrence_id=str(value["event_occurrence_id"]),
            route=ReferenceRouteKey.from_dict(value["route"]),
            focal_pg_type=str(value["focal_pg_type"]),
            active_pg_contexts=tuple(tuple(c) for c in value["active_pg_contexts"]),
            step_occurrence_ids=tuple(value["step_occurrence_ids"]),
            identity=PGStrategyNgramIdentity.from_dict(value["identity"]),
            start_index=int(value["start_index"]),
            reaction_node_paths=tuple(tuple(p) for p in value["reaction_node_paths"]),
        )
        if int(value["length"]) != result.length:
            raise ValueError("PG n-gram length disagrees with steps")
        return result


def ngram_occurrence_id(event_id: str, start: int, length: int) -> str:
    return _digest(
        "pg_strategy_ngram_o_",
        {
            "schema_version": 1,
            "event_occurrence_id": event_id,
            "start_index": start,
            "length": length,
        },
    )


def extract_pg_ngrams(
    processed: ProcessedRoutePGStrategies,
) -> tuple[PGStrategyNgramOccurrence, ...]:
    steps = {step.occurrence_id: step for step in processed.interval_steps}
    result = []
    for event in processed.events:
        interval = tuple(steps[key] for key in event.interval_step_occurrence_ids)
        if len(interval) != event.lifetime_steps:
            raise ValueError("PG lifespan disagrees with interval steps")
        for i, step in enumerate(interval):
            if (
                step.event_occurrence_id != event.occurrence_id
                or step.route != event.route
                or step.step_index != i
                or step.reaction_node_path != event.interval_reaction_node_paths[i]
            ):
                raise ValueError(
                    "PG n-gram source interval has inconsistent provenance"
                )
        for length in range(2, len(interval) + 1):
            for start in range(len(interval) - length + 1):
                window = interval[start : start + length]
                result.append(
                    PGStrategyNgramOccurrence(
                        occurrence_id=ngram_occurrence_id(
                            event.occurrence_id, start, length
                        ),
                        event_occurrence_id=event.occurrence_id,
                        route=event.route,
                        focal_pg_type=event.pg_type,
                        active_pg_contexts=tuple(s.active_pg_types for s in window),
                        step_occurrence_ids=tuple(s.occurrence_id for s in window),
                        identity=PGStrategyNgramIdentity(
                            rule_graphs=tuple(s.identity.rule_graph for s in window)
                        ),
                        start_index=start,
                        reaction_node_paths=tuple(s.reaction_node_path for s in window),
                    )
                )
    return tuple(result)
