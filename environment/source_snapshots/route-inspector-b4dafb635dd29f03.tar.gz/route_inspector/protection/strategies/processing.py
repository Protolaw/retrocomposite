"""One-pass extraction of deprotection-anchored ProtectingGroupStrategy evidence."""

from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, replace
from functools import lru_cache
from typing import Any, Mapping, Sequence

from route_inspector.protection.analysis import (
    ProtectionAnalysisConfig,
    analyze_route_protection,
    build_route_index,
)
from route_inspector.protection.strategies.models import (
    PGStrategyIntervalSequenceIdentity,
    PGStrategyIntervalSequenceOccurrence,
    PGStrategyIntervalStepIdentity,
    PGStrategyIntervalStepOccurrence,
    ProcessedRoutePGStrategies,
    ProtectingGroupStrategyIdentity,
    ProtectingGroupStrategyOccurrence,
    stable_pg_strategy_occurrence_id,
    stable_pg_strategy_sequence_occurrence_id,
    stable_pg_strategy_step_occurrence_id,
)
from route_inspector.reference_library.models import ReferenceRouteKey
from route_inspector.rules.models import PreparedRouteRuleData, ReactionRuleStep


@lru_cache(maxsize=4096)
def _strategy_identity(**rules):
    return ProtectingGroupStrategyIdentity.from_rules(**rules)


@lru_cache(maxsize=8192)
def _step_identity(rule):
    return PGStrategyIntervalStepIdentity.from_rule(rule)


@lru_cache(maxsize=4096)
def _sequence_identity(rules):
    return PGStrategyIntervalSequenceIdentity(
        rule_graphs=tuple(_step_identity(rule).rule_graph for rule in rules)
    )


def _diagnostic(
    route: ReferenceRouteKey,
    *,
    stage: str,
    message: str,
    event_id: str = "",
    error_type: str = "PGStrategyExtractionError",
    details: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "route": route.to_dict(),
        "event_id": str(event_id),
        "stage": str(stage),
        "error_type": str(error_type),
        "message": str(message),
        "details": dict(details or {}),
    }


def _step_for_path(
    prepared: PreparedRouteRuleData,
    path: Sequence[int],
    *,
    protected_atom_ids: Sequence[int],
    label: str,
) -> ReactionRuleStep:
    normalized_path = tuple(int(index) for index in path)
    try:
        step = prepared.step_by_reaction_path[normalized_path]
    except KeyError as exc:
        raise ValueError(
            f"{label} has no extracted rule at path {normalized_path}"
        ) from exc
    protected = frozenset(int(atom_id) for atom_id in protected_atom_ids)
    rule_atoms = step.base_rule_atom_maps or step.center_atoms
    if protected and not (rule_atoms & protected):
        raise ValueError(
            f"{label} rule environment does not contain the traced protected atom set"
        )
    return step


def _resolved_event(event: Any) -> bool:
    resolved_sources = {"introduced", "protected_synthon", "stock"}
    return (
        str(event.trace_status) in resolved_sources
        and str(event.source_type) in resolved_sources
    )


def extract_pg_strategies_from_prepared_route(
    route: ReferenceRouteKey,
    prepared: PreparedRouteRuleData,
    *,
    protection_rules: Mapping[str, Any],
    config: ProtectionAnalysisConfig,
    detection_cache=None,
    detection_policy=None,
) -> ProcessedRoutePGStrategies:
    """Extract resolved PG events while reusing prepared route rules and paths."""

    try:
        route_index = build_route_index(prepared.route, normalized=True)
        event_config = replace(config, collect_interval_rules=False)
        native_events, _unused_rules, returned_index = analyze_route_protection(
            prepared.route,
            route.route_id,
            dict(protection_rules),
            config=event_config,
            route_index=route_index,
            detection_cache=detection_cache,
            detection_policy=detection_policy,
        )
    except Exception as exc:
        return ProcessedRoutePGStrategies(
            route=route,
            events=(),
            interval_steps=(),
            interval_sequences=(),
            diagnostics=(
                _diagnostic(
                    route,
                    stage="analyze_route_protection",
                    error_type=type(exc).__qualname__,
                    message=str(exc) or type(exc).__qualname__,
                ),
            ),
        )
    if returned_index is not route_index:
        raise ValueError("protection analysis did not reuse the supplied route index")

    from route_inspector.protection.targets import target_protection_events

    native_events.extend(
        target_protection_events(route_index, route.route_id, protection_rules, config)
    )
    diagnostics: list[dict[str, Any]] = []
    resolved_native: list[Any] = []
    for event in native_events:
        if _resolved_event(event) or getattr(event, "endpoint_kind", "") == "target":
            if event.source_type == "unknown":
                diagnostics.append(
                    _diagnostic(
                        route,
                        event_id=event.event_id,
                        stage="trace_target_pg",
                        error_type="UnresolvedTargetProtectionTrace",
                        message=event.failure_reason,
                        details={
                            "pg_type": event.pg_type,
                            "protected_atom_ids": list(event.protected_atom_ids),
                        },
                    )
                )
            resolved_native.append(event)
            continue
        diagnostics.append(
            _diagnostic(
                route,
                event_id=event.event_id,
                stage="trace_protected_group",
                error_type="UnresolvedProtectionTrace",
                message=event.failure_reason or f"trace status {event.trace_status}",
                details={
                    "pg_type": event.pg_type,
                    "trace_status": event.trace_status,
                    "source_type": event.source_type,
                    "candidate_next_nodes": list(event.trace_candidate_next_nodes),
                    "candidate_trace_count": event.trace_n_candidate_traces,
                },
            )
        )

    active_by_path: dict[tuple[int, ...], list[str]] = {}
    for event in resolved_native:
        for path in event.interval_reaction_node_paths:
            active_by_path.setdefault(tuple(path), []).append(str(event.pg_type))

    events: list[ProtectingGroupStrategyOccurrence] = []
    interval_steps: list[PGStrategyIntervalStepOccurrence] = []
    interval_sequences: list[PGStrategyIntervalSequenceOccurrence] = []
    for event in resolved_native:
        try:
            if not event.protected_functional_group:
                raise ValueError(
                    "resolved event lacks a protected-functional-group label"
                )
            endpoint_kind = getattr(event, "endpoint_kind", "deprotection")
            deprotection_step = None
            if endpoint_kind == "deprotection":
                deprotection_step = _step_for_path(
                    prepared,
                    event.deprotection_reaction_node_path,
                    protected_atom_ids=event.protected_atom_ids,
                    label="deprotection endpoint",
                )
            protection_step = None
            if event.source_type in {"introduced", "protected_synthon"}:
                protection_step = _step_for_path(
                    prepared,
                    event.protection_reaction_node_path,
                    protected_atom_ids=event.protected_atom_ids,
                    label="protection endpoint",
                )
            identity = deepcopy(
                _strategy_identity(
                    pg_type=event.pg_type,
                    protected_functional_group=event.protected_functional_group,
                    source_type=event.source_type,
                    deprotection_rule_smarts=deprotection_step.rule_smarts
                    if deprotection_step
                    else "",
                    endpoint_kind=endpoint_kind,
                    protection_rule_smarts=(
                        "" if protection_step is None else protection_step.rule_smarts
                    ),
                )
            )
            occurrence_id = stable_pg_strategy_occurrence_id(route, event.event_id)
            endpoint_paths = {
                tuple(event.deprotection_reaction_node_path),
                tuple(event.protection_reaction_node_path),
            }
            endpoint_paths.discard(())
            synthetic_interval_paths = tuple(
                reversed(
                    tuple(
                        path
                        for path in event.interval_reaction_node_paths
                        if tuple(path) not in endpoint_paths
                    )
                )
            )
            event_steps: list[PGStrategyIntervalStepOccurrence] = []
            interval_centers: list[tuple[int, ...]] = []
            for step_index, reaction_path in enumerate(synthetic_interval_paths):
                step = _step_for_path(
                    prepared,
                    reaction_path,
                    protected_atom_ids=(),
                    label=f"interval step {step_index}",
                )
                active = tuple(sorted(active_by_path.get(tuple(reaction_path), ())))
                if event.pg_type not in active:
                    raise ValueError(
                        f"interval step {step_index} lacks its focal PG context"
                    )
                step_occurrence = PGStrategyIntervalStepOccurrence(
                    occurrence_id=stable_pg_strategy_step_occurrence_id(
                        occurrence_id,
                        step_index,
                        reaction_path,
                    ),
                    event_occurrence_id=occurrence_id,
                    route=route,
                    focal_pg_type=event.pg_type,
                    active_pg_types=active,
                    step_index=step_index,
                    reaction_node_path=tuple(reaction_path),
                    reaction_smiles=step.reaction_smiles,
                    rule_smarts=step.rule_smarts,
                    identity=deepcopy(_step_identity(step.rule_smarts)),
                )
                event_steps.append(step_occurrence)
                interval_centers.append(tuple(sorted(step.center_atoms)))
            sequence = PGStrategyIntervalSequenceOccurrence(
                occurrence_id=stable_pg_strategy_sequence_occurrence_id(occurrence_id),
                event_occurrence_id=occurrence_id,
                route=route,
                focal_pg_type=event.pg_type,
                active_pg_contexts=tuple(step.active_pg_types for step in event_steps),
                step_occurrence_ids=tuple(step.occurrence_id for step in event_steps),
                identity=deepcopy(
                    _sequence_identity(tuple(step.rule_smarts for step in event_steps))
                ),
            )
            occurrence = ProtectingGroupStrategyOccurrence(
                occurrence_id=occurrence_id,
                native_event_id=event.event_id,
                route=route,
                identity=identity,
                pg_type=event.pg_type,
                protected_functional_group=event.protected_functional_group,
                source_type=event.source_type,
                protection_reaction_node_path=tuple(
                    event.protection_reaction_node_path
                ),
                deprotection_reaction_node_path=tuple(
                    event.deprotection_reaction_node_path
                ),
                stock_molecule_node_path=tuple(event.stock_molecule_node_path),
                interval_reaction_node_paths=synthetic_interval_paths,
                protected_molecule_node_paths=tuple(
                    tuple(path) for path in event.protected_molecule_node_paths
                ),
                protection_reaction_smiles=event.protection_reaction_smiles,
                deprotection_reaction_smiles=event.deprotection_reaction_smiles,
                protection_rule_smarts=(
                    "" if protection_step is None else protection_step.rule_smarts
                ),
                deprotection_rule_smarts=deprotection_step.rule_smarts
                if deprotection_step
                else "",
                protected_atom_ids=tuple(event.protected_atom_ids),
                source_fragment_atom_maps=tuple(event.source_fragment_atom_ids),
                lifetime_steps=len(synthetic_interval_paths),
                confidence=event.confidence,
                multicenter_status=event.multicenter_status,
                selective_deprotection=event.selective_deprotection,
                interval_step_occurrence_ids=tuple(
                    step.occurrence_id for step in event_steps
                ),
                interval_sequence_occurrence_id=sequence.occurrence_id,
                protection_center_atom_maps=(
                    ()
                    if protection_step is None
                    else tuple(sorted(protection_step.center_atoms))
                ),
                deprotection_center_atom_maps=tuple(
                    sorted(deprotection_step.center_atoms) if deprotection_step else ()
                ),
                interval_center_atom_maps=tuple(interval_centers),
                annotations={
                    "evidence_status": "observed_removal",
                    "trace_status": "resolved",
                    **getattr(event, "target_annotations", {}),
                    "classical_lifetime_steps": event.lifetime_steps,
                    "source_fragment_atom_maps": list(event.source_fragment_atom_ids),
                    "n_other_reaction_centers": event.n_other_reaction_centers,
                    "n_matching_pg_sites_before_deprotection": (
                        event.n_matching_pg_sites_before_deprotection
                    ),
                    "n_sites_deprotected": event.n_sites_deprotected,
                    "multiple_deprotection_rules": (event.multiple_deprotection_rules),
                    "matched_deprotection_rules": list(
                        event.matched_deprotection_rules
                    ),
                },
            )
        except Exception as exc:
            diagnostics.append(
                _diagnostic(
                    route,
                    event_id=event.event_id,
                    stage="construct_pg_strategy_occurrence",
                    error_type=type(exc).__qualname__,
                    message=str(exc) or type(exc).__qualname__,
                    details={"native_event": asdict(event)},
                )
            )
            continue
        events.append(occurrence)
        interval_steps.extend(event_steps)
        interval_sequences.append(sequence)

    events.sort(key=lambda item: item.occurrence_id)
    interval_steps.sort(key=lambda item: item.occurrence_id)
    interval_sequences.sort(key=lambda item: item.occurrence_id)
    diagnostics.sort(
        key=lambda item: (
            str(item.get("event_id", "")),
            str(item.get("stage", "")),
            str(item.get("message", "")),
        )
    )
    return ProcessedRoutePGStrategies(
        route=route,
        events=tuple(events),
        interval_steps=tuple(interval_steps),
        interval_sequences=tuple(interval_sequences),
        diagnostics=tuple(diagnostics),
    )


def annotate_pg_strategy_classifications(
    processed_routes: Sequence[ProcessedRoutePGStrategies],
    provider: Any,
    *,
    n_cpu: int = 1,
    worker_chunksize: int = 100,
    progress_callback: Any | None = None,
) -> tuple[ProcessedRoutePGStrategies, ...]:
    """Classify each distinct Reference interval reaction once and reattach results."""

    from route_inspector import chemistry
    from route_inspector.chemistry.classification.common import (
        diagnostics,
        reconcile_batch_results,
        record_id,
        result_attr,
    )
    from route_inspector.chemistry.classification.providers import ReactionRecord

    by_input: dict[str, list[PGStrategyIntervalStepOccurrence]] = {}
    mapped_by_input: dict[str, str] = {}
    for processed in processed_routes:
        for step in processed.interval_steps:
            classifier_input = chemistry.canonical_unmapped_reaction_string(
                step.reaction_smiles
            )
            if not classifier_input or ">>" not in classifier_input:
                raise ValueError(
                    f"cannot classify PG interval occurrence {step.occurrence_id}"
                )
            by_input.setdefault(classifier_input, []).append(step)
            mapped_by_input.setdefault(classifier_input, step.reaction_smiles)
    records = tuple(
        ReactionRecord(
            record_id=record_id(classifier_input),
            mapped_reaction=mapped_by_input[classifier_input],
            classifier_input=classifier_input,
        )
        for classifier_input in sorted(by_input)
    )
    if not records:
        return tuple(processed_routes)
    results = provider.classify_many(
        records,
        n_cpu=n_cpu,
        worker_chunksize=worker_chunksize,
        progress_callback=progress_callback,
    )
    reconciliation = reconcile_batch_results(
        (record.record_id for record in records),
        results,
        ignore_errors=False,
    )
    if (
        reconciliation.duplicate_ids
        or reconciliation.unexpected_ids
        or reconciliation.empty_result_ids
    ):
        raise RuntimeError("reaction-class provider returned an invalid result set")
    result_by_id = reconciliation.result_by_id
    classification_by_occurrence: dict[str, dict[str, Any]] = {}
    for classifier_input, steps in by_input.items():
        result = result_by_id.get(record_id(classifier_input))
        if result is None:
            raise RuntimeError("reaction-class provider omitted a requested reaction")
        status = str(result_attr(result, "status", "unclassified"))
        error = str(result_attr(result, "error", ""))
        if status == "error" or error:
            raise RuntimeError(error or "reaction-class provider returned an error")
        classification = {
            "classifier_input": classifier_input,
            "provider": str(result_attr(result, "provider_name", "")),
            "provider_version": str(result_attr(result, "provider_version", "")),
            "taxonomy": str(result_attr(result, "taxonomy_id", "")),
            "raw_code": result_attr(result, "raw_code", None),
            "raw_name": result_attr(result, "raw_name", None),
            "tier3_code": result_attr(result, "tier3_code", None),
            "tier3_name": result_attr(result, "tier3_name", None),
            "confidence": result_attr(result, "confidence", None),
            "status": status,
            "accepted": bool(result_attr(result, "accepted", False)),
            "diagnostics": diagnostics(result),
        }
        for step in steps:
            classification_by_occurrence[step.occurrence_id] = classification

    enriched: list[ProcessedRoutePGStrategies] = []
    for processed in processed_routes:
        enriched.append(
            replace(
                processed,
                interval_steps=tuple(
                    replace(
                        step,
                        classification=classification_by_occurrence[step.occurrence_id],
                    )
                    for step in processed.interval_steps
                ),
            )
        )
    return tuple(enriched)


__all__ = [
    "annotate_pg_strategy_classifications",
    "extract_pg_strategies_from_prepared_route",
]
