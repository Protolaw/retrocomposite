"""PG-only preparation of cleaned, continuously mapped routes."""

from __future__ import annotations

from dataclasses import replace

from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.protection.analysis import (
    PG_ORIGIN_POLICY,
    ProtectionAnalysisConfig,
    analyze_route_protection,
    build_route_index,
    protection_detection_policy,
)
from route_inspector.protection.chython_rules import load_chython_protection_rules
from route_inspector.protection.endpoints import ENDPOINT_POLICY
from route_inspector.protection.strategies.ngrams import NGRAM_POLICY
from route_inspector.protection.strategies.processing import (
    _resolved_event,
    _strategy_identity,
    extract_pg_strategies_from_prepared_route,
)
from route_inspector.protection.strategies.profile import _protection_rule_configuration
from route_inspector.reference_library.models import ReferenceRouteKey
from route_inspector.routes.validation import validate_routes_mapping
from route_inspector.rules.config import dependency_version, resolved_config_mapping
from route_inspector.rules.graph import GRAPH_SCHEMA_VERSION
from route_inspector.rules.models import RouteProcessingStats
from route_inspector.rules.preparation import prepare_route_rule_data


def _config_class():
    try:
        from synplan.chem.reaction.rules.config import RuleExtractionConfig
    except ImportError:
        from synplan.utils.config import RuleExtractionConfig
    return RuleExtractionConfig


def _restore_config(value):
    if isinstance(value, dict):
        if set(value) == {"object_type", "query_smarts"}:
            return value["query_smarts"]
        return {k: _restore_config(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_restore_config(v) for v in value]
    return value


class RoutePGStrategyProcessor:
    """Prepare single rules and PG evidence without extracting any tactics."""

    def __init__(
        self,
        rule_config,
        protection_config,
        *,
        source_id_adapter="paroutes-semicolon-v1",
        rule_extractor=None,
        protection_rules=None,
    ):
        from route_inspector.rules.extraction import SynPlannerRuleExtractor

        self.rule_extractor = (
            rule_extractor
            if rule_extractor is not None
            else SynPlannerRuleExtractor(rule_config)
        )
        self.protection_rules = (
            load_chython_protection_rules()
            if protection_rules is None
            else protection_rules
        )
        self.config = replace(protection_config, collect_interval_rules=False)
        self.source_id_adapter = source_id_adapter
        self._detection_cache = {}
        self._detection_policy = protection_detection_policy(
            self.protection_rules, self.config
        )
        self.profile = {
            "pg_processing_profile_version": 2,
            "endpoint_validation": dict(ENDPOINT_POLICY),
            "origin_policy": dict(PG_ORIGIN_POLICY),
            "input_state": "preprocessed",
            "mapping_validation": True,
            "source_id_adapter": source_id_adapter,
            "rule_extraction_config": resolved_config_mapping(rule_config),
            "implementation_versions": {
                "synplanner": dependency_version("SynPlanner"),
                "chython": dependency_version("chython-synplan"),
            },
            "protection_analysis_config": resolved_config_mapping(self.config),
            "protection_rules": _protection_rule_configuration(self.protection_rules),
            "rule_graph_schema_version": GRAPH_SCHEMA_VERSION,
            "ngram_policy": dict(NGRAM_POLICY),
        }

    @classmethod
    def from_config(
        cls, config, protection_config, *, source_id_adapter="paroutes-semicolon-v1"
    ):
        return cls(
            _config_class().from_yaml(str(resolve_existing_path(config))),
            ProtectionAnalysisConfig.from_yaml(
                resolve_existing_path(protection_config)
            ),
            source_id_adapter=source_id_adapter,
        )

    @classmethod
    def from_profile(cls, profile):
        if profile.get("pg_processing_profile_version") != 2:
            raise ValueError(
                "PG library lacks a compatible standalone processing profile for endpoint validation; rebuild with build-pg-strategy-library or use the legacy bundled assess-route workflow"
            )
        processor = cls(
            _config_class()(**_restore_config(profile["rule_extraction_config"])),
            ProtectionAnalysisConfig(**profile["protection_analysis_config"]),
            source_id_adapter=profile["source_id_adapter"],
        )
        if processor.profile != {k: v for k, v in profile.items() if k != "classifier"}:
            raise ValueError(
                "PG processing profile is incompatible with installed chemistry or detection rules"
            )
        return processor

    def process_route(self, route_id, route, *, dataset_id, source_identity):
        key = ReferenceRouteKey(str(dataset_id), str(source_identity), str(route_id))
        validation = validate_routes_mapping(
            {key.route_id: route}, dataset=key.dataset_id
        )
        if validation.records:
            raise ValueError(
                f"PG route {key.dataset_id}/{key.route_id}: mapping validation failed: {validation.summary()}"
            )
        return self.process_validated_route(
            route_id, route, dataset_id=dataset_id, source_identity=source_identity
        )

    def process_validated_route(self, route_id, route, *, dataset_id, source_identity):
        """Prepare a route whose exact mapped tree has already passed validation.

        This builds full library records without composing the same route CGR
        twice. Recovery uses recovery_lifecycles when only validation signatures
        are needed. General callers use process_route.
        """
        key = ReferenceRouteKey(str(dataset_id), str(source_identity), str(route_id))
        prepared = prepare_route_rule_data(
            route,
            self.rule_extractor,
            stats=RouteProcessingStats(),
            route_id=key.route_id,
            dataset_id=key.dataset_id,
            source_identity=key.source_identity,
            source_id_adapter=self.source_id_adapter,
        )
        return extract_pg_strategies_from_prepared_route(
            key,
            prepared,
            protection_rules=self.protection_rules,
            config=self.config,
            detection_cache=self._detection_cache,
            detection_policy=self._detection_policy,
        )

    def recovery_lifecycles(self, route):
        """Validate removed, introduced PGs without building library records.

        Requires the same preceding strict mapping check as process_validated_route.
        The proposal workflow already extracts query interval rules for retrieval
        and replay. Here the native detector traces the generated chemistry and
        checks extracted endpoint coverage/identities. Re-extracting candidate
        n-grams solely to build discarded library records is unnecessary.
        """
        # The preceding strict validator established continuous maps and exact
        # reaction/child correspondence. Do not normalize/remap this tree again.
        index = build_route_index(route, normalized=True)
        reactions = {tuple(r.node_path): r for r in index.reaction_records.values()}
        steps = {}
        try:
            events, _, _ = analyze_route_protection(
                index.route,
                "proposal",
                self.protection_rules,
                config=replace(self.config, collect_interval_rules=False),
                route_index=index,
                detection_cache=self._detection_cache,
                detection_policy=self._detection_policy,
            )
        except Exception:
            return ()
        signatures = []
        from route_inspector import chemistry

        for event in events:
            if event.source_type != "introduced" or not _resolved_event(event):
                continue
            try:
                if (
                    not event.protected_functional_group
                    or not event.protection_reaction_node_path
                    or event.source_fragment_atom_ids
                ):
                    continue
                endpoints = (
                    tuple(event.protection_reaction_node_path),
                    tuple(event.deprotection_reaction_node_path),
                )
                for path in endpoints:
                    if path not in steps:
                        steps[path], _ = self.rule_extractor.extract(
                            format(
                                chemistry.parse_reaction(
                                    reactions[path].reaction_smiles
                                ),
                                "m",
                            )
                        )
                    step = steps[path]
                    if step is None or not set(event.protected_atom_ids) & (
                        step.base_rule_atom_maps or step.center_atoms
                    ):
                        raise ValueError("endpoint rule lacks traced protected atoms")
                _strategy_identity(
                    pg_type=event.pg_type,
                    protected_functional_group=event.protected_functional_group,
                    source_type=event.source_type,
                    protection_rule_smarts=steps[endpoints[0]].rule_smarts,
                    deprotection_rule_smarts=steps[endpoints[1]].rule_smarts,
                    endpoint_kind="deprotection",
                )
                interval = tuple(
                    reversed(
                        tuple(
                            tuple(p)
                            for p in event.interval_reaction_node_paths
                            if tuple(p) not in endpoints
                        )
                    )
                )
                if any(p not in reactions for p in interval):
                    raise ValueError("lifecycle contains an unknown reaction path")
                signatures.append(
                    (
                        event.pg_type,
                        "introduced",
                        "not_preserved",
                        frozenset(event.protected_atom_ids),
                        len(interval),
                    )
                )
            except Exception:
                # Invalid/missing endpoint rules cannot validate a lifecycle.
                continue
        return tuple(signatures)
