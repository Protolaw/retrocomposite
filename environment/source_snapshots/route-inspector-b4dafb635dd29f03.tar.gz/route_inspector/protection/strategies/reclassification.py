"""Immutable reclassification of standalone PG artifacts."""

import shutil

from route_inspector.protection.strategies.catalog import ReferencePGStrategyLibrary
from route_inspector.protection.strategies.construction import _temporary
from route_inspector.reference_library.storage.artifacts import (
    _publish_directory_no_replace,
)
from route_inspector.rules.graph import canonical_json


def reclassify_standalone_pg_library(
    source,
    output_dir,
    provider,
    *,
    classifier_metadata=None,
    n_cpu=1,
    worker_chunksize=100,
    progress_callback=None,
):
    """Replace classification annotations, preserving all structural PG evidence."""
    from route_inspector.protection.strategies.catalog import (
        _sequence_occurrences_from_entries,
    )
    from route_inspector.protection.strategies.models import ProcessedRoutePGStrategies
    from route_inspector.protection.strategies.processing import (
        annotate_pg_strategy_classifications,
    )
    from route_inspector.reference_library.migration.pg_reclassification import (
        PGStrategyReclassificationResult,
    )

    destination, temporary = _temporary(output_dir)
    try:
        with ReferencePGStrategyLibrary.load(source, verification="full") as original:
            events = tuple(
                original.get_event_occurrence(r["occurrence_id"])
                for e in original.entries("event")
                for r in e.support_records
            )
            steps = tuple(
                original.get_interval_step(r["occurrence_id"])
                for e in original.entries("interval_step")
                for r in e.support_records
            )
            sequences = _sequence_occurrences_from_entries(
                original.entries("interval_sequence"), events, steps
            )
            from route_inspector.reference_library.models import ReferenceRouteKey

            routes = {e.route for e in events}
            routes.update(
                ReferenceRouteKey.from_dict(d["route"])
                for d in original.diagnostics
                if "route" in d
            )
            processed = tuple(
                ProcessedRoutePGStrategies(
                    route,
                    tuple(e for e in events if e.route == route),
                    tuple(s for s in steps if s.route == route),
                    tuple(s for s in sequences if s.route == route),
                    tuple(
                        d
                        for d in original.diagnostics
                        if d.get("route") == route.to_dict()
                    ),
                )
                for route in sorted(routes, key=lambda r: canonical_json(r.to_dict()))
            )
            enriched = annotate_pg_strategy_classifications(
                processed,
                provider,
                n_cpu=n_cpu,
                worker_chunksize=worker_chunksize,
                progress_callback=progress_callback,
            )
            classifier = {
                **(classifier_metadata or {}),
                "provider": provider.provider_name,
                "provider_version": provider.provider_version,
                "taxonomy": provider.taxonomy_id,
            }
            new = ReferencePGStrategyLibrary.from_processed_routes(
                enriched,
                processing_profile={
                    **original.manifest.processing_profile,
                    "classifier": classifier,
                },
                reference_corpora=original.manifest.reference_corpora,
                include_ngrams=original.manifest.library_format_version >= 2,
            )
            # Reclassification cannot drop diagnostics with no resolved event.
            if new.diagnostics != original.diagnostics:
                raise ValueError("PG reclassification lost diagnostic provenance")
            for kind in ("event", "interval_sequence", "interval_ngram"):
                if new.entries(kind) != original.entries(kind):
                    raise ValueError(f"PG reclassification changed {kind} evidence")
            new.write(
                temporary, include_sqlite="catalog" in original.manifest.artifacts
            )
            ReferencePGStrategyLibrary.verify(temporary)
            unique = len(
                {
                    s.classification.get("classifier_input")
                    for r in enriched
                    for s in r.interval_steps
                }
            )
            result = PGStrategyReclassificationResult(
                destination,
                "",
                new.library_id,
                str(provider.provider_name),
                str(provider.provider_version),
                str(provider.taxonomy_id),
                unique,
                len(steps),
            )
        _publish_directory_no_replace(temporary, destination)
        return result
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise
