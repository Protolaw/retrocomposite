"""Hierarchical Reference-corpus assessment of protecting-group strategies."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from typing import Any, ClassVar

from route_inspector.protection.strategies.catalog import (
    PGStrategyLibraryEntry,
    ReferencePGStrategyLibrary,
)
from route_inspector.protection.strategies.models import (
    PGStrategyIntervalSequenceOccurrence,
    PGStrategyIntervalStepOccurrence,
    ProcessedRoutePGStrategies,
    ProtectingGroupStrategyOccurrence,
)
from route_inspector.protection.strategies.ngrams import (
    PGStrategyNgramOccurrence,
    extract_pg_ngrams,
)
from route_inspector.reference_library.models import ReferenceRouteKey

PG_STRATEGY_AVAILABILITIES = frozenset(
    {"available", "library_component_unavailable", "extraction_incomplete"}
)
PG_STRATEGY_STATUSES = frozenset(
    {
        "fully_covered",
        "partially_novel",
        "strategy_novel",
        "no_detected_events",
        "assessment_incomplete",
        "library_component_unavailable",
    }
)
PG_STRATEGY_SCOPES = (
    "identical_event",
    "same_focal_pg",
    "identical_active_pg_multiset",
)

NO_DETECTED_PG_EVENTS_LIMITATION = (
    "No protecting-group event or target-retained candidate was detected under "
    "the stored rules; this does not establish that the route contains no "
    "protecting-group logic."
)
INCOMPLETE_PG_ASSESSMENT_LIMITATION = (
    "At least one protecting-group trace or endpoint-rule extraction was unresolved; "
    "coverage is partial and must not be interpreted as a complete route assessment."
)
PG_COMPONENT_UNAVAILABLE_LIMITATION = (
    "The Reference library has no ProtectingGroupStrategy component; tactic results "
    "remain valid, but protecting-group precedent is unavailable."
)


def _fraction(numerator: int, denominator: int) -> float | None:
    return None if denominator == 0 else numerator / denominator


@dataclass(frozen=True)
class PGStrategyCoverage:
    """Coverage for events, steps, or sequences with explicit gating counts."""

    scope: str
    total_count: int
    assessed_count: int
    known_count: int
    coverage_fraction: float | None

    def __post_init__(self) -> None:
        counts = tuple(
            int(value)
            for value in (self.total_count, self.assessed_count, self.known_count)
        )
        if any(value < 0 for value in counts):
            raise ValueError("PG strategy coverage counts must be non-negative")
        if (
            self.assessed_count > self.total_count
            or self.known_count > self.assessed_count
        ):
            raise ValueError("PG strategy coverage counts are inconsistent")
        expected = _fraction(self.known_count, self.assessed_count)
        if expected != self.coverage_fraction:
            raise ValueError("PG strategy coverage fraction disagrees with counts")

    def to_dict(self) -> dict[str, Any]:
        return {
            "scope": self.scope,
            "total_count": self.total_count,
            "assessed_count": self.assessed_count,
            "known_count": self.known_count,
            "coverage_fraction": self.coverage_fraction,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PGStrategyCoverage":
        return cls(
            scope=str(value["scope"]),
            total_count=int(value["total_count"]),
            assessed_count=int(value["assessed_count"]),
            known_count=int(value["known_count"]),
            coverage_fraction=(
                None
                if value.get("coverage_fraction") is None
                else float(value["coverage_fraction"])
            ),
        )


@dataclass(frozen=True)
class PGStrategyScopeSupport:
    """Reference support in one event/context scope, with auditable exemplar."""

    scope: str
    occurrence_count: int
    reference_route_ids: tuple[str, ...]
    representative_event: ProtectingGroupStrategyOccurrence | None
    representative_steps: tuple[PGStrategyIntervalStepOccurrence, ...] = ()

    def __post_init__(self) -> None:
        if self.scope not in PG_STRATEGY_SCOPES:
            raise ValueError(f"unsupported PG strategy support scope: {self.scope}")
        if int(self.occurrence_count) < 0:
            raise ValueError("support occurrence_count must be non-negative")
        route_ids = tuple(sorted(set(map(str, self.reference_route_ids))))
        object.__setattr__(self, "reference_route_ids", route_ids)
        if self.occurrence_count == 0:
            if (
                route_ids
                or self.representative_event is not None
                or self.representative_steps
            ):
                raise ValueError("zero support cannot contain Reference provenance")
        elif self.representative_event is None or not route_ids:
            raise ValueError("positive support requires Reference provenance")

    @property
    def route_count(self) -> int:
        return len(self.reference_route_ids)

    def to_dict(self) -> dict[str, Any]:
        return {
            "scope": self.scope,
            "occurrence_count": self.occurrence_count,
            "route_count": self.route_count,
            "reference_route_ids": list(self.reference_route_ids),
            "representative_event": (
                None
                if self.representative_event is None
                else self.representative_event.to_dict()
            ),
            "representative_steps": [
                step.to_dict() for step in self.representative_steps
            ],
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PGStrategyScopeSupport":
        raw_event = value.get("representative_event")
        result = cls(
            scope=str(value["scope"]),
            occurrence_count=int(value["occurrence_count"]),
            reference_route_ids=tuple(value.get("reference_route_ids") or ()),
            representative_event=(
                None
                if raw_event is None
                else ProtectingGroupStrategyOccurrence.from_dict(raw_event)
            ),
            representative_steps=tuple(
                PGStrategyIntervalStepOccurrence.from_dict(item)
                for item in value.get("representative_steps") or ()
            ),
        )
        if "route_count" in value and int(value["route_count"]) != result.route_count:
            raise ValueError("serialized PG support route_count is inconsistent")
        return result


@dataclass(frozen=True)
class PGStrategyEventMatch:
    """Exact event match, gated before any interval comparison."""

    occurrence: ProtectingGroupStrategyOccurrence
    reference_entry: PGStrategyLibraryEntry | None
    representative_occurrence: ProtectingGroupStrategyOccurrence | None

    @property
    def known(self) -> bool:
        return self.reference_entry is not None

    def __post_init__(self) -> None:
        if self.known != (self.representative_occurrence is not None):
            raise ValueError("event match and representative provenance disagree")
        if self.reference_entry is not None:
            if (
                self.reference_entry.kind != "event"
                or not self.reference_entry.identity.equivalent_to(
                    self.occurrence.identity
                )
            ):
                raise ValueError("Reference event entry is not exactly equivalent")

    def to_dict(self) -> dict[str, Any]:
        return {
            "occurrence": self.occurrence.to_dict(),
            "known": self.known,
            "reference_entry": None
            if self.reference_entry is None
            else self.reference_entry.to_dict(),
            "representative_occurrence": (
                None
                if self.representative_occurrence is None
                else self.representative_occurrence.to_dict()
            ),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PGStrategyEventMatch":
        raw_entry = value.get("reference_entry")
        raw_occurrence = value.get("representative_occurrence")
        result = cls(
            occurrence=ProtectingGroupStrategyOccurrence.from_dict(value["occurrence"]),
            reference_entry=None
            if raw_entry is None
            else PGStrategyLibraryEntry.from_dict(raw_entry),
            representative_occurrence=(
                None
                if raw_occurrence is None
                else ProtectingGroupStrategyOccurrence.from_dict(raw_occurrence)
            ),
        )
        if "known" in value and bool(value["known"]) != result.known:
            raise ValueError("serialized PG event known flag is inconsistent")
        return result


@dataclass(frozen=True)
class PGStrategyIntervalStepMatch:
    """Exact interval-step match in each allowed Reference scope."""

    occurrence: PGStrategyIntervalStepOccurrence
    event_known: bool
    reference_entry: PGStrategyLibraryEntry | None
    support_by_scope: Mapping[str, PGStrategyScopeSupport]

    def __post_init__(self) -> None:
        if set(self.support_by_scope) != set(PG_STRATEGY_SCOPES):
            raise ValueError("interval-step support must contain all PG scopes")
        if not self.event_known and self.reference_entry is not None:
            raise ValueError("a novel event cannot have an assessed interval step")
        if self.reference_entry is not None and (
            self.reference_entry.kind != "interval_step"
            or not self.reference_entry.identity.equivalent_to(self.occurrence.identity)
        ):
            raise ValueError("Reference interval-step entry is not exactly equivalent")

    def to_dict(self) -> dict[str, Any]:
        return {
            "occurrence": self.occurrence.to_dict(),
            "event_known": self.event_known,
            "reference_entry": None
            if self.reference_entry is None
            else self.reference_entry.to_dict(),
            "support_by_scope": {
                name: self.support_by_scope[name].to_dict()
                for name in PG_STRATEGY_SCOPES
            },
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PGStrategyIntervalStepMatch":
        raw_entry = value.get("reference_entry")
        return cls(
            occurrence=PGStrategyIntervalStepOccurrence.from_dict(value["occurrence"]),
            event_known=bool(value["event_known"]),
            reference_entry=None
            if raw_entry is None
            else PGStrategyLibraryEntry.from_dict(raw_entry),
            support_by_scope={
                name: PGStrategyScopeSupport.from_dict(item)
                for name, item in value["support_by_scope"].items()
            },
        )


@dataclass(frozen=True)
class PGStrategyIntervalSequenceMatch:
    """Exact ordered full-interval match in each allowed Reference scope."""

    occurrence: PGStrategyIntervalSequenceOccurrence
    event_known: bool
    reference_entry: PGStrategyLibraryEntry | None
    support_by_scope: Mapping[str, PGStrategyScopeSupport]

    def __post_init__(self) -> None:
        if set(self.support_by_scope) != set(PG_STRATEGY_SCOPES):
            raise ValueError("interval-sequence support must contain all PG scopes")
        if not self.event_known and self.reference_entry is not None:
            raise ValueError("a novel event cannot have an assessed interval sequence")
        if self.reference_entry is not None and (
            self.reference_entry.kind != "interval_sequence"
            or not self.reference_entry.identity.equivalent_to(self.occurrence.identity)
        ):
            raise ValueError(
                "Reference interval-sequence entry is not exactly equivalent"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "occurrence": self.occurrence.to_dict(),
            "event_known": self.event_known,
            "reference_entry": None
            if self.reference_entry is None
            else self.reference_entry.to_dict(),
            "support_by_scope": {
                name: self.support_by_scope[name].to_dict()
                for name in PG_STRATEGY_SCOPES
            },
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PGStrategyIntervalSequenceMatch":
        raw_entry = value.get("reference_entry")
        return cls(
            occurrence=PGStrategyIntervalSequenceOccurrence.from_dict(
                value["occurrence"]
            ),
            event_known=bool(value["event_known"]),
            reference_entry=None
            if raw_entry is None
            else PGStrategyLibraryEntry.from_dict(raw_entry),
            support_by_scope={
                name: PGStrategyScopeSupport.from_dict(item)
                for name, item in value["support_by_scope"].items()
            },
        )


@dataclass(frozen=True)
class PGStrategyNgramMatch:
    """Exact ordered lifespan n-gram match in each allowed Reference scope."""

    occurrence: PGStrategyNgramOccurrence
    event_known: bool
    reference_entry: PGStrategyLibraryEntry | None
    support_by_scope: Mapping[str, PGStrategyScopeSupport]

    def __post_init__(self) -> None:
        if set(self.support_by_scope) != set(PG_STRATEGY_SCOPES):
            raise ValueError("interval-sequence support must contain all PG scopes")
        if not self.event_known and self.reference_entry is not None:
            raise ValueError("a novel event cannot have an assessed interval sequence")
        if self.reference_entry is not None and (
            self.reference_entry.kind != "interval_ngram"
            or not self.reference_entry.identity.equivalent_to(self.occurrence.identity)
        ):
            raise ValueError(
                "Reference interval-sequence entry is not exactly equivalent"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "occurrence": self.occurrence.to_dict(),
            "event_known": self.event_known,
            "reference_entry": None
            if self.reference_entry is None
            else self.reference_entry.to_dict(),
            "support_by_scope": {
                name: self.support_by_scope[name].to_dict()
                for name in PG_STRATEGY_SCOPES
            },
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PGStrategyNgramMatch":
        raw_entry = value.get("reference_entry")
        return cls(
            occurrence=PGStrategyNgramOccurrence.from_dict(value["occurrence"]),
            event_known=bool(value["event_known"]),
            reference_entry=None
            if raw_entry is None
            else PGStrategyLibraryEntry.from_dict(raw_entry),
            support_by_scope={
                name: PGStrategyScopeSupport.from_dict(item)
                for name, item in value["support_by_scope"].items()
            },
        )


@dataclass(frozen=True)
class RoutePGStrategyAssessment:
    """Independent PG-strategy assessment for exactly one query route."""

    route: ReferenceRouteKey
    availability: str
    status: str
    trace_complete: bool
    event_matches: tuple[PGStrategyEventMatch, ...]
    interval_step_matches: tuple[PGStrategyIntervalStepMatch, ...]
    interval_sequence_matches: tuple[PGStrategyIntervalSequenceMatch, ...]
    event_coverage: PGStrategyCoverage
    interval_step_coverage: Mapping[str, PGStrategyCoverage]
    interval_sequence_coverage: Mapping[str, PGStrategyCoverage]
    diagnostics: tuple[Mapping[str, Any], ...] = ()
    limitation: str | None = None
    schema_version: int = 1
    ngram_availability: str = "unavailable"
    interval_ngram_matches: tuple[PGStrategyNgramMatch, ...] = ()
    interval_ngram_coverage: Mapping[str, Mapping[str, PGStrategyCoverage]] = field(
        default_factory=dict
    )

    _MATCH_FIELDS: ClassVar[tuple[str, ...]] = (
        "event_matches",
        "interval_step_matches",
        "interval_sequence_matches",
        "interval_ngram_matches",
    )

    def __post_init__(self) -> None:
        if int(self.schema_version) not in {1, 2}:
            raise ValueError("unsupported ProtectingGroupStrategy assessment schema")
        if self.ngram_availability not in {"available", "unavailable"}:
            raise ValueError("invalid PG n-gram availability")
        if self.ngram_availability == "unavailable" and (
            self.interval_ngram_matches or self.interval_ngram_coverage
        ):
            raise ValueError("unavailable PG n-grams cannot have matching evidence")
        if any(
            set(scopes) != set(PG_STRATEGY_SCOPES)
            for scopes in self.interval_ngram_coverage.values()
        ):
            raise ValueError("n-gram coverage must contain all PG scopes")
        if self.availability not in PG_STRATEGY_AVAILABILITIES:
            raise ValueError(
                f"unsupported PG assessment availability: {self.availability}"
            )
        if self.status not in PG_STRATEGY_STATUSES:
            raise ValueError(f"unsupported PG assessment status: {self.status}")
        if set(self.interval_step_coverage) != set(PG_STRATEGY_SCOPES):
            raise ValueError("step coverage must contain all PG scopes")
        if set(self.interval_sequence_coverage) != set(PG_STRATEGY_SCOPES):
            raise ValueError("sequence coverage must contain all PG scopes")
        if any(
            match.occurrence.route != self.route
            for name in self._MATCH_FIELDS
            for match in getattr(self, name)
        ):
            raise ValueError("all PG assessment occurrences must belong to its route")
        if self.trace_complete and self.diagnostics:
            raise ValueError("complete PG trace cannot retain unresolved diagnostics")

    def to_dict(self) -> dict[str, Any]:
        result = {
            "schema_version": self.schema_version,
            "route": self.route.to_dict(),
            "availability": self.availability,
            "status": self.status,
            "trace_complete": self.trace_complete,
            "event_matches": [item.to_dict() for item in self.event_matches],
            "interval_step_matches": [
                item.to_dict() for item in self.interval_step_matches
            ],
            "interval_sequence_matches": [
                item.to_dict() for item in self.interval_sequence_matches
            ],
            "event_coverage": self.event_coverage.to_dict(),
            "interval_step_coverage": {
                name: self.interval_step_coverage[name].to_dict()
                for name in PG_STRATEGY_SCOPES
            },
            "interval_sequence_coverage": {
                name: self.interval_sequence_coverage[name].to_dict()
                for name in PG_STRATEGY_SCOPES
            },
            "diagnostics": [dict(item) for item in self.diagnostics],
            "limitation": self.limitation,
        }

        if self.schema_version >= 2:
            result.update(
                ngram_availability=self.ngram_availability,
                interval_ngram_matches=[
                    m.to_dict() for m in self.interval_ngram_matches
                ],
                interval_ngram_coverage={
                    n: {scope: c.to_dict() for scope, c in scopes.items()}
                    for n, scopes in self.interval_ngram_coverage.items()
                },
            )
        return result

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RoutePGStrategyAssessment":
        """Load a persisted PG assessment record with schema validation."""

        return cls(
            schema_version=int(value["schema_version"]),
            ngram_availability=str(value.get("ngram_availability", "unavailable")),
            interval_ngram_matches=tuple(
                PGStrategyNgramMatch.from_dict(m)
                for m in value.get("interval_ngram_matches", ())
            ),
            interval_ngram_coverage={
                n: {
                    scope: PGStrategyCoverage.from_dict(c)
                    for scope, c in scopes.items()
                }
                for n, scopes in value.get("interval_ngram_coverage", {}).items()
            },
            route=ReferenceRouteKey.from_dict(value["route"]),
            availability=str(value["availability"]),
            status=str(value["status"]),
            trace_complete=bool(value["trace_complete"]),
            event_matches=tuple(
                PGStrategyEventMatch.from_dict(item)
                for item in value.get("event_matches") or ()
            ),
            interval_step_matches=tuple(
                PGStrategyIntervalStepMatch.from_dict(item)
                for item in value.get("interval_step_matches") or ()
            ),
            interval_sequence_matches=tuple(
                PGStrategyIntervalSequenceMatch.from_dict(item)
                for item in value.get("interval_sequence_matches") or ()
            ),
            event_coverage=PGStrategyCoverage.from_dict(value["event_coverage"]),
            interval_step_coverage={
                name: PGStrategyCoverage.from_dict(item)
                for name, item in value["interval_step_coverage"].items()
            },
            interval_sequence_coverage={
                name: PGStrategyCoverage.from_dict(item)
                for name, item in value["interval_sequence_coverage"].items()
            },
            diagnostics=tuple(value.get("diagnostics") or ()),
            limitation=(
                None if value.get("limitation") is None else str(value["limitation"])
            ),
        )


def _empty_support(scope: str) -> PGStrategyScopeSupport:
    return PGStrategyScopeSupport(scope, 0, (), None, ())


def _matching_support_records(
    entry: PGStrategyLibraryEntry,
    *,
    scope: str,
    query_event_entry_id: str,
    query_focal_pg: str,
    query_context: Any,
    library: ReferencePGStrategyLibrary,
) -> tuple[Mapping[str, Any], ...]:
    records = []
    for record in entry.support_records:
        event_occurrence_id = str(record["event_occurrence_id"])
        if scope == "identical_event":
            if (
                library.event_entry_id_for_occurrence(event_occurrence_id)
                != query_event_entry_id
            ):
                continue
        elif str(record["focal_pg_type"]) != query_focal_pg:
            continue
        if scope == "identical_active_pg_multiset":
            observed = record.get("active_pg_types", record.get("active_pg_contexts"))
            if observed != query_context:
                continue
        records.append(record)
    return tuple(sorted(records, key=lambda item: str(item["occurrence_id"])))


def _scope_support(
    scope: str,
    records: Sequence[Mapping[str, Any]],
    library: ReferencePGStrategyLibrary,
    *,
    sequence: bool,
) -> PGStrategyScopeSupport:
    if not records:
        return _empty_support(scope)
    representative = records[0]
    event = library.get_event_occurrence(str(representative["event_occurrence_id"]))
    if sequence:
        steps = tuple(
            library.get_interval_step(str(occurrence_id))
            for occurrence_id in representative.get("step_occurrence_ids") or ()
        )
    else:
        steps = (library.get_interval_step(str(representative["occurrence_id"])),)
    return PGStrategyScopeSupport(
        scope=scope,
        occurrence_count=len(records),
        reference_route_ids=tuple(
            str(record["route"]["route_id"]) for record in records
        ),
        representative_event=event,
        representative_steps=steps,
    )


def _coverage(
    scope: str,
    matches: Sequence[Any],
    *,
    total_count: int,
) -> PGStrategyCoverage:
    assessed = tuple(match for match in matches if match.event_known)
    known = sum(
        match.support_by_scope[scope].occurrence_count > 0 for match in assessed
    )
    return PGStrategyCoverage(
        scope, total_count, len(assessed), known, _fraction(known, len(assessed))
    )


def _assess_pg_strategies(
    processed: ProcessedRoutePGStrategies | None,
    library: ReferencePGStrategyLibrary | None,
    *,
    route: ReferenceRouteKey,
    extraction_error: Mapping[str, Any] | None = None,
) -> RoutePGStrategyAssessment:
    """Assess resolved events first, then exact steps and ordered intervals."""

    if library is None:
        zero = PGStrategyCoverage("events", 0, 0, 0, None)
        scoped = {
            scope: PGStrategyCoverage(scope, 0, 0, 0, None)
            for scope in PG_STRATEGY_SCOPES
        }
        return RoutePGStrategyAssessment(
            route=route,
            availability="library_component_unavailable",
            status="library_component_unavailable",
            trace_complete=True,
            event_matches=(),
            interval_step_matches=(),
            interval_sequence_matches=(),
            event_coverage=zero,
            interval_step_coverage=scoped,
            interval_sequence_coverage=scoped,
            limitation=PG_COMPONENT_UNAVAILABLE_LIMITATION,
        )
    diagnostics = tuple(
        ([dict(extraction_error)] if extraction_error is not None else [])
        + (
            [dict(item) for item in processed.diagnostics]
            if processed is not None
            else []
        )
    )
    if processed is None:
        processed = ProcessedRoutePGStrategies(route, (), (), (), diagnostics)
    event_matches = []
    event_entry_by_occurrence: dict[str, PGStrategyLibraryEntry] = {}
    for occurrence in processed.events:
        entry = library.event_entry(occurrence.identity)
        representative = None
        if entry is not None:
            event_entry_by_occurrence[occurrence.occurrence_id] = entry
            representative = library.get_event_occurrence(
                entry.representative_occurrence_id
            )
        event_matches.append(PGStrategyEventMatch(occurrence, entry, representative))

    step_matches = []
    for occurrence in processed.interval_steps:
        event_entry = event_entry_by_occurrence.get(occurrence.event_occurrence_id)
        entry = (
            None
            if event_entry is None
            else library.interval_step_entry(occurrence.identity)
        )
        support = {}
        for scope in PG_STRATEGY_SCOPES:
            records = (
                ()
                if entry is None
                else _matching_support_records(
                    entry,
                    scope=scope,
                    query_event_entry_id=""
                    if event_entry is None
                    else event_entry.entry_id,
                    query_focal_pg=occurrence.focal_pg_type,
                    query_context=list(occurrence.active_pg_types),
                    library=library,
                )
            )
            support[scope] = _scope_support(scope, records, library, sequence=False)
        step_matches.append(
            PGStrategyIntervalStepMatch(
                occurrence, event_entry is not None, entry, support
            )
        )

    sequence_matches = []
    for occurrence in processed.interval_sequences:
        event_entry = event_entry_by_occurrence.get(occurrence.event_occurrence_id)
        entry = (
            None
            if event_entry is None
            else library.interval_sequence_entry(occurrence.identity)
        )
        support = {}
        for scope in PG_STRATEGY_SCOPES:
            records = (
                ()
                if entry is None
                else _matching_support_records(
                    entry,
                    scope=scope,
                    query_event_entry_id=""
                    if event_entry is None
                    else event_entry.entry_id,
                    query_focal_pg=occurrence.focal_pg_type,
                    query_context=[
                        list(item) for item in occurrence.active_pg_contexts
                    ],
                    library=library,
                )
            )
            support[scope] = _scope_support(scope, records, library, sequence=True)
        sequence_matches.append(
            PGStrategyIntervalSequenceMatch(
                occurrence, event_entry is not None, entry, support
            )
        )

    event_known = sum(match.known for match in event_matches)
    event_coverage = PGStrategyCoverage(
        "events",
        len(event_matches),
        len(event_matches),
        event_known,
        _fraction(event_known, len(event_matches)),
    )
    step_coverage = {
        scope: _coverage(scope, step_matches, total_count=len(step_matches))
        for scope in PG_STRATEGY_SCOPES
    }
    sequence_coverage = {
        scope: _coverage(scope, sequence_matches, total_count=len(sequence_matches))
        for scope in PG_STRATEGY_SCOPES
    }
    trace_complete = not diagnostics
    if not trace_complete:
        availability = "extraction_incomplete"
        status = "assessment_incomplete"
        limitation = INCOMPLETE_PG_ASSESSMENT_LIMITATION
    elif not event_matches:
        availability = "available"
        status = "no_detected_events"
        limitation = NO_DETECTED_PG_EVENTS_LIMITATION
    elif event_known == 0:
        availability = "available"
        status = "strategy_novel"
        limitation = None
    elif (
        event_known == len(event_matches)
        and step_coverage["identical_event"].known_count == len(step_matches)
        and sequence_coverage["identical_event"].known_count == len(sequence_matches)
    ):
        availability = "available"
        status = "fully_covered"
        limitation = None
    else:
        availability = "available"
        status = "partially_novel"
        limitation = None
    return RoutePGStrategyAssessment(
        route=route,
        availability=availability,
        status=status,
        trace_complete=trace_complete,
        event_matches=tuple(event_matches),
        interval_step_matches=tuple(step_matches),
        interval_sequence_matches=tuple(sequence_matches),
        event_coverage=event_coverage,
        interval_step_coverage=step_coverage,
        interval_sequence_coverage=sequence_coverage,
        diagnostics=diagnostics,
        limitation=limitation,
    )


def assess_pg_strategies(processed, library, *, route, extraction_error=None):
    """Match PG lifecycles, full intervals, and available lifespan n-grams."""
    result = _assess_pg_strategies(
        processed, library, route=route, extraction_error=extraction_error
    )
    if library is None or library.manifest.library_format_version < 2:
        return result
    events = {
        m.occurrence.occurrence_id: m.reference_entry for m in result.event_matches
    }
    matches = []
    for occurrence in () if processed is None else extract_pg_ngrams(processed):
        event = events.get(occurrence.event_occurrence_id)
        entry = (
            None
            if event is None
            else library.find_entry(occurrence.identity, kind="interval_ngram")
        )
        support = {}
        for scope in PG_STRATEGY_SCOPES:
            records = (
                ()
                if entry is None
                else _matching_support_records(
                    entry,
                    scope=scope,
                    query_event_entry_id=event.entry_id,
                    query_focal_pg=occurrence.focal_pg_type,
                    query_context=[list(c) for c in occurrence.active_pg_contexts],
                    library=library,
                )
            )
            support[scope] = _scope_support(scope, records, library, sequence=True)
        matches.append(
            PGStrategyNgramMatch(occurrence, event is not None, entry, support)
        )
    coverage = {}
    for length in sorted({m.occurrence.length for m in matches}):
        group = [m for m in matches if m.occurrence.length == length]
        coverage[str(length)] = {
            scope: _coverage(scope, group, total_count=len(group))
            for scope in PG_STRATEGY_SCOPES
        }
    return replace(
        result,
        schema_version=2,
        ngram_availability="available",
        interval_ngram_matches=tuple(matches),
        interval_ngram_coverage=coverage,
    )


__all__ = [
    "INCOMPLETE_PG_ASSESSMENT_LIMITATION",
    "NO_DETECTED_PG_EVENTS_LIMITATION",
    "PG_COMPONENT_UNAVAILABLE_LIMITATION",
    "PG_STRATEGY_AVAILABILITIES",
    "PG_STRATEGY_SCOPES",
    "PG_STRATEGY_STATUSES",
    "PGStrategyNgramMatch",
    "PGStrategyCoverage",
    "PGStrategyEventMatch",
    "PGStrategyIntervalSequenceMatch",
    "PGStrategyIntervalStepMatch",
    "PGStrategyScopeSupport",
    "RoutePGStrategyAssessment",
    "assess_pg_strategies",
]
