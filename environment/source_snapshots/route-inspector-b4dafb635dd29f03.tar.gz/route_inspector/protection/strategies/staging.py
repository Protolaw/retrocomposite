"""Disk-staged PG records and globally deduplicated classification."""

from __future__ import annotations

import json
import sqlite3
import time
from typing import Any, Mapping

from route_inspector.infrastructure.progress import render_progress
from route_inspector.infrastructure.runtime import normalize_n_cpu
from route_inspector.reference_library.models import ReferenceRouteKey
from route_inspector.rules.graph import canonical_json


def _pg_record(processed: Any) -> str | None:
    if processed is None:
        return None
    return canonical_json(
        {
            "route": processed.route.to_dict(),
            "events": [event.to_dict() for event in processed.events],
            "interval_steps": [step.to_dict() for step in processed.interval_steps],
            "interval_sequences": [
                sequence.to_dict() for sequence in processed.interval_sequences
            ],
            "diagnostics": [dict(item) for item in processed.diagnostics],
        }
    )


def _processed_pg_from_record(value: Mapping[str, Any]) -> Any:
    from route_inspector.protection.strategies.models import (
        PGStrategyIntervalSequenceOccurrence,
        PGStrategyIntervalStepOccurrence,
        ProcessedRoutePGStrategies,
        ProtectingGroupStrategyOccurrence,
    )

    return ProcessedRoutePGStrategies(
        route=ReferenceRouteKey.from_dict(value["route"]),
        events=tuple(
            ProtectingGroupStrategyOccurrence.from_dict(item)
            for item in value.get("events", ())
        ),
        interval_steps=tuple(
            PGStrategyIntervalStepOccurrence.from_dict(item)
            for item in value.get("interval_steps", ())
        ),
        interval_sequences=tuple(
            PGStrategyIntervalSequenceOccurrence.from_dict(item)
            for item in value.get("interval_sequences", ())
        ),
        diagnostics=tuple(dict(item) for item in value.get("diagnostics", ())),
    )


def _classify_staged_pg(
    connection: sqlite3.Connection,
    provider: Any,
    *,
    n_cpu: int,
    worker_chunksize: int,
    progress_interval: int,
) -> None:
    if provider is None:
        classification = {
            "classifier_input": "",
            "provider": "none",
            "provider_version": "",
            "taxonomy": "none",
            "raw_code": None,
            "raw_name": None,
            "tier3_code": None,
            "tier3_name": None,
            "confidence": None,
            "status": "not_requested",
            "accepted": False,
            "diagnostics": {"reason": "Reaction-class annotation was disabled."},
        }
        for row in connection.execute(
            "SELECT input_ordinal, pg_json FROM route_results WHERE pg_json IS NOT NULL"
        ):
            value = json.loads(row["pg_json"])
            for step in value.get("interval_steps", ()):
                step["classification"] = classification
            connection.execute(
                "UPDATE route_results SET pg_json = ? WHERE input_ordinal = ?",
                (canonical_json(value), int(row["input_ordinal"])),
            )
        connection.commit()
        return

    from route_inspector import chemistry
    from route_inspector.chemistry.classification.common import (
        diagnostics,
        reconcile_batch_results,
        record_id,
        result_attr,
    )
    from route_inspector.chemistry.classification.providers import ReactionRecord

    connection.execute(
        """CREATE TABLE IF NOT EXISTS pg_classifier_inputs(
               classifier_input TEXT PRIMARY KEY,
               mapped_reaction TEXT NOT NULL,
               classification_json TEXT
           ) WITHOUT ROWID"""
    )
    _check_classifier_state(connection, provider)
    for row in connection.execute(
        "SELECT pg_json FROM route_results WHERE pg_json IS NOT NULL"
    ):
        value = json.loads(row["pg_json"])
        for step in value.get("interval_steps", ()):
            classifier_input = chemistry.canonical_unmapped_reaction_string(
                str(step["reaction_smiles"])
            )
            if not classifier_input or ">>" not in classifier_input:
                raise ValueError(
                    "cannot classify PG interval occurrence "
                    f"{step.get('occurrence_id', '')}"
                )
            connection.execute(
                """INSERT OR IGNORE INTO pg_classifier_inputs(
                       classifier_input, mapped_reaction
                   ) VALUES (?, ?)""",
                (classifier_input, str(step["reaction_smiles"])),
            )
    connection.commit()

    total = int(
        connection.execute("SELECT COUNT(*) FROM pg_classifier_inputs").fetchone()[0]
    )
    completed = int(
        connection.execute(
            "SELECT COUNT(*) FROM pg_classifier_inputs WHERE classification_json IS NOT NULL"
        ).fetchone()[0]
    )
    started = time.monotonic()
    batch_size = max(1, int(worker_chunksize))
    while completed < total:
        rows = tuple(
            connection.execute(
                """SELECT classifier_input, mapped_reaction
                   FROM pg_classifier_inputs
                   WHERE classification_json IS NULL
                   ORDER BY classifier_input LIMIT ?""",
                (batch_size,),
            )
        )
        if not rows:
            break
        records = tuple(
            ReactionRecord(
                record_id=record_id(str(row["classifier_input"])),
                mapped_reaction=str(row["mapped_reaction"]),
                classifier_input=str(row["classifier_input"]),
            )
            for row in rows
        )
        results = provider.classify_many(
            records,
            n_cpu=normalize_n_cpu(n_cpu),
            worker_chunksize=batch_size,
        )
        reconciliation = reconcile_batch_results(
            (record.record_id for record in records),
            results,
            ignore_errors=False,
        )
        if (
            reconciliation.duplicate_ids
            or reconciliation.unexpected_ids
            or reconciliation.empty_result_ids
        ):
            raise RuntimeError("reaction-class provider returned an invalid result set")
        updates = []
        for row, record in zip(rows, records):
            result = reconciliation.result_by_id.get(record.record_id)
            if result is None:
                raise RuntimeError(
                    "reaction-class provider omitted a requested reaction"
                )
            status = str(result_attr(result, "status", "unclassified"))
            error = str(result_attr(result, "error", ""))
            if status == "error" or error:
                raise RuntimeError(error or "reaction-class provider returned an error")
            classification = {
                "classifier_input": str(row["classifier_input"]),
                "provider": str(result_attr(result, "provider_name", "")),
                "provider_version": str(result_attr(result, "provider_version", "")),
                "taxonomy": str(result_attr(result, "taxonomy_id", "")),
                "raw_code": result_attr(result, "raw_code", None),
                "raw_name": result_attr(result, "raw_name", None),
                "tier3_code": result_attr(result, "tier3_code", None),
                "tier3_name": result_attr(result, "tier3_name", None),
                "confidence": result_attr(result, "confidence", None),
                "status": status,
                "accepted": bool(result_attr(result, "accepted", False)),
                "diagnostics": diagnostics(result),
            }
            updates.append(
                (canonical_json(classification), str(row["classifier_input"]))
            )
        # No part of a malformed provider batch is accepted. Previous batches
        # stay durable and can be reused even when a later batch is interrupted.
        with connection:
            connection.executemany(
                """UPDATE pg_classifier_inputs SET classification_json = ?
                   WHERE classifier_input = ?""",
                updates,
            )
        completed += len(rows)
        if progress_interval and (
            completed % progress_interval == 0 or completed == total
        ):
            render_progress(
                "pg-reaction-classes",
                completed,
                total,
                started,
                workers=normalize_n_cpu(n_cpu),
            )

    route_rows = connection.execute(
        """SELECT input_ordinal, pg_json FROM route_results
           WHERE pg_json IS NOT NULL ORDER BY input_ordinal"""
    )
    for row in route_rows:
        value = json.loads(row["pg_json"])
        enriched_steps = []
        for step_value in value.get("interval_steps", ()):
            classifier_input = chemistry.canonical_unmapped_reaction_string(
                str(step_value["reaction_smiles"])
            )
            classification_row = connection.execute(
                """SELECT classification_json FROM pg_classifier_inputs
                   WHERE classifier_input = ?""",
                (classifier_input,),
            ).fetchone()
            if classification_row is None or classification_row[0] is None:
                raise RuntimeError("PG classification staging is incomplete")
            step_value = dict(step_value)
            step_value["classification"] = json.loads(classification_row[0])
            enriched_steps.append(step_value)
        value["interval_steps"] = enriched_steps
        connection.execute(
            "UPDATE route_results SET pg_json = ? WHERE input_ordinal = ?",
            (canonical_json(value), int(row["input_ordinal"])),
        )
    connection.commit()


def _check_classifier_state(connection, provider):
    signature = {
        "provider": str(provider.provider_name),
        "provider_version": str(provider.provider_version),
        "taxonomy": str(provider.taxonomy_id),
    }
    encoded = canonical_json(signature)
    connection.execute(
        "CREATE TABLE IF NOT EXISTS pg_classifier_state(key TEXT PRIMARY KEY, value TEXT NOT NULL)"
    )
    saved = connection.execute(
        "SELECT value FROM pg_classifier_state WHERE key='provider'"
    ).fetchone()
    if saved is not None and saved[0] != encoded:
        raise ValueError(
            "PG classifier resume fingerprint differs from provider version/taxonomy"
        )
    if saved is None:
        # Older builds stored the provider identity on each committed result.
        # Check that evidence before adopting an existing classifier table.
        for row in connection.execute(
            """SELECT DISTINCT json_extract(classification_json, '$.provider'),
                      json_extract(classification_json, '$.provider_version'),
                      json_extract(classification_json, '$.taxonomy')
               FROM pg_classifier_inputs WHERE classification_json IS NOT NULL"""
        ):
            if tuple(row) != tuple(signature.values()):
                raise ValueError(
                    "PG classifier resume fingerprint differs in retained results"
                )
        connection.execute(
            "INSERT INTO pg_classifier_state VALUES('provider',?)", (encoded,)
        )
    connection.commit()
