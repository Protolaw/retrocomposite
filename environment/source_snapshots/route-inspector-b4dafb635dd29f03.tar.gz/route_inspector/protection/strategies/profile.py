"""PG scientific profile evidence independent of tactic extraction."""

import hashlib
import json
from typing import Any, Mapping


def _protection_rule_configuration(rules: Mapping[str, Any]) -> dict[str, Any]:
    """Return the complete deterministic rule evidence used for PG detection."""

    records = []
    for rule_id, rule in sorted(rules.items()):
        records.append(
            {
                "rule_id": str(rule_id),
                "name": str(rule.name),
                "query_smarts": str(rule.query),
                "product_smarts": str(rule.product_smarts),
                "atoms_to_keep": list(rule.atoms_to_keep),
                "atoms_to_add": [list(item) for item in rule.atoms_to_add],
                "protected_example": str(rule.protected_example),
                "cleaved_example": str(rule.cleaved_example),
                "decoys": list(rule.decoys),
                "source": str(rule.source),
            }
        )
    return {
        "rule_count": len(records),
        "rules_sha256": hashlib.sha256(
            json.dumps(records, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest(),
        "rules": records,
    }
