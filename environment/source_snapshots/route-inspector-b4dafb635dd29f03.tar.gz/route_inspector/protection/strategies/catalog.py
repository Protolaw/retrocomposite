"""Persisted, exact-equivalence Reference ProtectingGroupStrategy catalog."""

from __future__ import annotations

import csv
import hashlib
import json
import sqlite3
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from route_inspector.infrastructure.auditing import audit_scope
from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.protection.strategies.models import (
    PGStrategyIntervalSequenceIdentity,
    PGStrategyIntervalSequenceOccurrence,
    PGStrategyIntervalStepIdentity,
    PGStrategyIntervalStepOccurrence,
    ProcessedRoutePGStrategies,
    ProtectingGroupStrategyIdentity,
    ProtectingGroupStrategyOccurrence,
)
from route_inspector.protection.strategies.ngrams import (
    PGStrategyNgramIdentity,
    PGStrategyNgramOccurrence,
    extract_pg_ngrams,
)
from route_inspector.reference_library.models import ReferenceRouteKey
from route_inspector.rules.graph import canonical_json

PG_STRATEGY_LIBRARY_FORMAT_VERSION = 5
PG_STRATEGY_CATALOG_SCHEMA_VERSION = 5
PG_STRATEGY_ASSESSMENT_SCHEMA_VERSION = 2
_LAZY_ENTRY_CACHE_SIZE = 64

_COMPONENT_PATHS = {
    "catalog": "catalog.sqlite",
    "event_entries": "events/entries.jsonl",
    "event_occurrences": "provenance/events.jsonl",
    "interval_step_entries": "interval_steps/entries.jsonl",
    "interval_step_occurrences": "interval_steps/occurrences.jsonl",
    "interval_sequence_entries": "interval_sequences/entries.jsonl",
    "diagnostics": "diagnostics.jsonl",
    "report_events": "reports/events.tsv",
    "report_interval_steps": "reports/interval_steps.tsv",
    "report_interval_sequences": "reports/interval_sequences.tsv",
    "summary": "summary.json",
}
_NGRAM_PATHS = {
    "ngram_entries": "interval_ngrams/entries.jsonl",
    "ngram_occurrences": "interval_ngrams/occurrences.jsonl",
    "report_ngrams": "reports/interval_ngrams.tsv",
    "errors": "errors.tsv",
}
_LEGACY_PATHS = dict(_COMPONENT_PATHS)
_COMPONENT_PATHS.update(_NGRAM_PATHS)
_REQUIRED_ARTIFACTS = frozenset(set(_COMPONENT_PATHS) - {"catalog"})


def _digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _json_copy(value: Any) -> Any:
    return json.loads(canonical_json(value))


def _route_key(route: ReferenceRouteKey) -> tuple[str, str, str]:
    return route.dataset_id, route.source_identity, route.route_id


def _identity_from_dict(kind: str, value: Mapping[str, Any]) -> Any:
    if kind == "event":
        return ProtectingGroupStrategyIdentity.from_dict(value)
    if kind == "interval_step":
        return PGStrategyIntervalStepIdentity.from_dict(value)
    if kind == "interval_ngram":
        return PGStrategyNgramIdentity.from_dict(value)
    if kind == "interval_sequence":
        return PGStrategyIntervalSequenceIdentity.from_dict(value)
    raise ValueError(f"unsupported PG strategy entry kind: {kind}")


def _equivalent(left: Any, right: Any) -> bool:
    # These validated identity models include every graph label and edge. Exact
    # equality proves the identity mapping; other encodings still require iso.
    return left == right or bool(left.equivalent_to(right))


@dataclass(frozen=True)
class PGStrategyLibraryEntry:
    """One exact event, step, or ordered-sequence identity and its support."""

    kind: str
    entry_id: str
    identity: Any
    occurrence_count: int
    reference_routes: tuple[ReferenceRouteKey, ...]
    representative_occurrence_id: str
    support_records: tuple[Mapping[str, Any], ...] = ()

    def __post_init__(self) -> None:
        if self.kind not in {
            "event",
            "interval_step",
            "interval_sequence",
            "interval_ngram",
        }:
            raise ValueError("unsupported PG strategy entry kind")
        if not self.entry_id or int(self.occurrence_count) < 1:
            raise ValueError("PG strategy entries require an ID and occurrence support")
        routes = tuple(sorted(set(self.reference_routes), key=_route_key))
        if not routes:
            raise ValueError("PG strategy entries require Reference route support")
        records = tuple(_json_copy(record) for record in self.support_records)
        if len(records) != int(self.occurrence_count):
            raise ValueError("PG strategy support records must account for occurrences")
        occurrence_ids = [str(record.get("occurrence_id") or "") for record in records]
        if any(not value for value in occurrence_ids) or len(occurrence_ids) != len(
            set(occurrence_ids)
        ):
            raise ValueError("PG strategy support occurrence IDs must be unique")
        if self.representative_occurrence_id != min(occurrence_ids):
            raise ValueError("PG strategy representative occurrence is not canonical")
        object.__setattr__(self, "occurrence_count", int(self.occurrence_count))
        object.__setattr__(self, "reference_routes", routes)
        object.__setattr__(
            self,
            "support_records",
            tuple(sorted(records, key=lambda row: str(row["occurrence_id"]))),
        )

    @property
    def route_count(self) -> int:
        return len(self.reference_routes)

    @property
    def lookup_key(self) -> str:
        return str(self.identity.lookup_key)

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "entry_id": self.entry_id,
            "identity": self.identity.to_dict(),
            "lookup_key": self.lookup_key,
            "occurrence_count": self.occurrence_count,
            "route_count": self.route_count,
            "reference_routes": [route.to_dict() for route in self.reference_routes],
            "representative_occurrence_id": self.representative_occurrence_id,
            "support_records": [dict(record) for record in self.support_records],
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PGStrategyLibraryEntry":
        kind = str(value["kind"])
        entry = cls(
            kind=kind,
            entry_id=str(value["entry_id"]),
            identity=_identity_from_dict(kind, value["identity"]),
            occurrence_count=int(value["occurrence_count"]),
            reference_routes=tuple(
                ReferenceRouteKey.from_dict(route)
                for route in value.get("reference_routes") or ()
            ),
            representative_occurrence_id=str(value["representative_occurrence_id"]),
            support_records=tuple(value.get("support_records") or ()),
        )
        if value.get("lookup_key") != entry.lookup_key:
            raise ValueError("PG strategy entry lookup key is inconsistent")
        if int(value.get("route_count", -1)) != entry.route_count:
            raise ValueError("PG strategy entry route count is inconsistent")
        return entry


@dataclass(frozen=True)
class PGStrategyLibraryManifest:
    """Content-bound manifest for one peer PG-strategy component."""

    library_id: str
    processing_profile: Mapping[str, Any]
    reference_corpora: tuple[Mapping[str, Any], ...]
    statistics: Mapping[str, Any]
    artifacts: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)
    library_format_version: int = 1
    catalog_schema_version: int = 1

    def __post_init__(self) -> None:
        if int(self.library_format_version) not in {1, 2, 3, 4, 5}:
            raise ValueError("unsupported PG strategy library format")
        if int(self.catalog_schema_version) != int(self.library_format_version):
            raise ValueError("unsupported PG strategy catalog schema")
        if not str(self.library_id).startswith("pg_strategy_library_"):
            raise ValueError("invalid PG strategy library ID")
        object.__setattr__(
            self, "processing_profile", _json_copy(self.processing_profile)
        )
        object.__setattr__(
            self,
            "reference_corpora",
            tuple(_json_copy(item) for item in self.reference_corpora),
        )
        object.__setattr__(self, "statistics", _json_copy(self.statistics))
        object.__setattr__(self, "artifacts", _json_copy(self.artifacts))

    def to_dict(self) -> dict[str, Any]:
        return {
            "library_format_version": self.library_format_version,
            "catalog_schema_version": self.catalog_schema_version,
            "library_id": self.library_id,
            "processing_profile": dict(self.processing_profile),
            "reference_corpora": [dict(item) for item in self.reference_corpora],
            "statistics": dict(self.statistics),
            "artifacts": {
                name: dict(value) for name, value in sorted(self.artifacts.items())
            },
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PGStrategyLibraryManifest":
        return cls(
            library_format_version=int(value["library_format_version"]),
            catalog_schema_version=int(value["catalog_schema_version"]),
            library_id=str(value["library_id"]),
            processing_profile=value["processing_profile"],
            reference_corpora=tuple(value.get("reference_corpora") or ()),
            statistics=value.get("statistics") or {},
            artifacts=value.get("artifacts") or {},
        )


_SCHEMA_SQL = """
CREATE TABLE metadata(key TEXT PRIMARY KEY, value_json TEXT NOT NULL) WITHOUT ROWID;
CREATE TABLE entries(
    entry_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    lookup_key TEXT NOT NULL,
    entry_json TEXT NOT NULL
) WITHOUT ROWID;
CREATE INDEX entries_lookup ON entries(kind, lookup_key);
CREATE TABLE event_occurrences(
    occurrence_id TEXT PRIMARY KEY,
    entry_id TEXT NOT NULL REFERENCES entries(entry_id),
    dataset_id TEXT NOT NULL,
    source_identity TEXT NOT NULL,
    route_id TEXT NOT NULL,
    occurrence_json TEXT NOT NULL
) WITHOUT ROWID;
CREATE INDEX event_occurrences_entry ON event_occurrences(entry_id);
CREATE TABLE interval_step_occurrences(
    occurrence_id TEXT PRIMARY KEY,
    entry_id TEXT NOT NULL REFERENCES entries(entry_id),
    event_occurrence_id TEXT NOT NULL,
    focal_pg_type TEXT NOT NULL,
    active_pg_types_json TEXT NOT NULL,
    dataset_id TEXT NOT NULL,
    source_identity TEXT NOT NULL,
    route_id TEXT NOT NULL,
    occurrence_json TEXT NOT NULL
) WITHOUT ROWID;
CREATE INDEX interval_steps_entry ON interval_step_occurrences(entry_id);
CREATE INDEX interval_steps_event ON interval_step_occurrences(event_occurrence_id);
CREATE INDEX interval_steps_pg ON interval_step_occurrences(focal_pg_type);
CREATE TABLE diagnostics(
    ordinal INTEGER PRIMARY KEY,
    diagnostic_json TEXT NOT NULL
);
"""


def _support_record(occurrence: Any) -> dict[str, Any]:
    record = {
        "occurrence_id": occurrence.occurrence_id,
        "occurrence_sha256": _digest(occurrence.to_dict()),
        "route": occurrence.route.to_dict(),
    }
    if isinstance(occurrence, PGStrategyIntervalStepOccurrence):
        record.update(
            {
                "event_occurrence_id": occurrence.event_occurrence_id,
                "focal_pg_type": occurrence.focal_pg_type,
                "active_pg_types": list(occurrence.active_pg_types),
            }
        )
    elif isinstance(occurrence, PGStrategyIntervalSequenceOccurrence):
        record.update(
            {
                "event_occurrence_id": occurrence.event_occurrence_id,
                "focal_pg_type": occurrence.focal_pg_type,
                "active_pg_contexts": [
                    list(item) for item in occurrence.active_pg_contexts
                ],
                "step_occurrence_ids": list(occurrence.step_occurrence_ids),
            }
        )
    if isinstance(occurrence, PGStrategyNgramOccurrence):
        record.update(
            start_index=occurrence.start_index,
            length=occurrence.length,
            reaction_node_paths=[list(p) for p in occurrence.reaction_node_paths],
        )
    return record


def _build_entries(
    kind: str, occurrences: Sequence[Any]
) -> tuple[tuple[PGStrategyLibraryEntry, ...], dict[str, str]]:
    buckets: dict[str, list[list[Any]]] = defaultdict(list)
    for occurrence in sorted(occurrences, key=lambda item: item.occurrence_id):
        identity = occurrence.identity
        groups = buckets[identity.lookup_key]
        group = next(
            (
                candidate
                for candidate in groups
                if _equivalent(candidate[0].identity, identity)
            ),
            None,
        )
        if group is None:
            group = []
            groups.append(group)
        group.append(occurrence)
    entries: list[PGStrategyLibraryEntry] = []
    ownership: dict[str, str] = {}
    for lookup_key in sorted(buckets):
        groups = sorted(
            buckets[lookup_key],
            key=lambda group: canonical_json(group[0].identity.to_dict()),
        )
        for ordinal, group in enumerate(groups):
            entry_id = f"{lookup_key}~{ordinal:04d}"
            entry = PGStrategyLibraryEntry(
                kind=kind,
                entry_id=entry_id,
                identity=group[0].identity,
                occurrence_count=len(group),
                reference_routes=tuple(item.route for item in group),
                representative_occurrence_id=min(item.occurrence_id for item in group),
                support_records=tuple(_support_record(item) for item in group),
            )
            entries.append(entry)
            ownership.update({item.occurrence_id: entry_id for item in group})
    return tuple(entries), ownership


def _component_statistics(
    event_entries: Sequence[PGStrategyLibraryEntry],
    step_entries: Sequence[PGStrategyLibraryEntry],
    sequence_entries: Sequence[PGStrategyLibraryEntry],
    events: Sequence[ProtectingGroupStrategyOccurrence],
    steps: Sequence[PGStrategyIntervalStepOccurrence],
    diagnostics: Sequence[Mapping[str, Any]],
) -> dict[str, int]:
    return {
        **(
            {
                "target_retained_event_count": sum(
                    e.terminus == "preserved" for e in events
                ),
                "deprotection_ended_event_count": sum(
                    e.terminus == "not_preserved" for e in events
                ),
                "unresolved_target_event_count": sum(
                    e.source_type == "unknown" for e in events
                ),
                "resolved_event_count": sum(e.source_type != "unknown" for e in events),
            }
            if any(e.schema_version >= 3 for e in events)
            else {}
        ),
        "event_entry_count": len(event_entries),
        "event_occurrence_count": len(events),
        "interval_step_entry_count": len(step_entries),
        "interval_step_occurrence_count": len(steps),
        "interval_sequence_entry_count": len(sequence_entries),
        "interval_sequence_occurrence_count": sum(
            entry.occurrence_count for entry in sequence_entries
        ),
        "diagnostic_count": len(diagnostics),
        "route_count_with_resolved_events": len(
            {event.route for event in events if event.source_type != "unknown"}
        ),
        "introduced_event_count": sum(
            event.source_type == "introduced" for event in events
        ),
        "protected_synthon_event_count": sum(
            event.source_type == "protected_synthon" for event in events
        ),
        "stock_event_count": sum(event.source_type == "stock" for event in events),
    }


def _component_content(
    *,
    processing_profile: Mapping[str, Any],
    reference_corpora: Sequence[Mapping[str, Any]],
    entries: Sequence[PGStrategyLibraryEntry],
    events: Sequence[ProtectingGroupStrategyOccurrence],
    steps: Sequence[PGStrategyIntervalStepOccurrence],
    diagnostics: Sequence[Mapping[str, Any]],
    library_format_version: int = 1,
) -> dict[str, Any]:
    return {
        "format": library_format_version,
        "profile": _json_copy(processing_profile),
        "reference_corpora": [_json_copy(item) for item in reference_corpora],
        "entries": [
            entry.to_dict() for entry in sorted(entries, key=lambda item: item.entry_id)
        ],
        "events": [
            _digest(event.to_dict())
            for event in sorted(events, key=lambda item: item.occurrence_id)
        ],
        "steps": [
            _digest(step.to_dict())
            for step in sorted(steps, key=lambda item: item.occurrence_id)
        ],
        "diagnostics": [
            _digest(item) for item in sorted(diagnostics, key=canonical_json)
        ],
    }


def _sequence_occurrences_from_entries(
    sequence_entries: Sequence[PGStrategyLibraryEntry],
    events: Sequence[ProtectingGroupStrategyOccurrence],
    steps: Sequence[PGStrategyIntervalStepOccurrence],
) -> tuple[PGStrategyIntervalSequenceOccurrence, ...]:
    event_by_id = {event.occurrence_id: event for event in events}
    step_by_id = {step.occurrence_id: step for step in steps}
    if len(event_by_id) != len(events) or len(step_by_id) != len(steps):
        raise ValueError("PG strategy provenance contains duplicate occurrence IDs")
    sequences: list[PGStrategyIntervalSequenceOccurrence] = []
    sequence_by_event: dict[str, str] = {}
    for entry in sequence_entries:
        for record in entry.support_records:
            occurrence_id = str(record["occurrence_id"])
            event_occurrence_id = str(record["event_occurrence_id"])
            try:
                event = event_by_id[event_occurrence_id]
            except KeyError as exc:
                raise ValueError(
                    "PG interval sequence refers to an unknown event occurrence"
                ) from exc
            step_ids = tuple(map(str, record.get("step_occurrence_ids") or ()))
            try:
                sequence_steps = tuple(step_by_id[step_id] for step_id in step_ids)
            except KeyError as exc:
                raise ValueError(
                    "PG interval sequence refers to an unknown step occurrence"
                ) from exc
            contexts = tuple(
                tuple(map(str, context))
                for context in record.get("active_pg_contexts") or ()
            )
            occurrence_identity = PGStrategyIntervalSequenceIdentity(
                rule_graphs=tuple(step.identity.rule_graph for step in sequence_steps)
            )
            if not entry.identity.equivalent_to(occurrence_identity):
                raise ValueError(
                    "PG interval sequence identity disagrees with its entry"
                )
            sequence = PGStrategyIntervalSequenceOccurrence(
                occurrence_id=occurrence_id,
                event_occurrence_id=event_occurrence_id,
                route=ReferenceRouteKey.from_dict(record["route"]),
                focal_pg_type=str(record["focal_pg_type"]),
                active_pg_contexts=contexts,
                step_occurrence_ids=step_ids,
                identity=occurrence_identity,
            )
            if sequence.route != event.route or sequence.focal_pg_type != event.pg_type:
                raise ValueError("PG interval sequence disagrees with its event")
            for graph, context, step in zip(
                sequence.identity.rule_graphs,
                sequence.active_pg_contexts,
                sequence_steps,
            ):
                if (
                    step.event_occurrence_id != event_occurrence_id
                    or step.route != sequence.route
                    or step.focal_pg_type != sequence.focal_pg_type
                    or step.active_pg_types != context
                    or not PGStrategyIntervalStepIdentity(graph).equivalent_to(
                        step.identity
                    )
                ):
                    raise ValueError(
                        "PG interval sequence disagrees with its step provenance"
                    )
            if event_occurrence_id in sequence_by_event:
                raise ValueError("PG event has duplicate complete interval sequences")
            sequence_by_event[event_occurrence_id] = occurrence_id
            sequences.append(sequence)
    for event in events:
        event_steps = tuple(
            sorted(
                (
                    step
                    for step in steps
                    if step.event_occurrence_id == event.occurrence_id
                ),
                key=lambda step: step.step_index,
            )
        )
        if event.interval_step_occurrence_ids != tuple(
            step.occurrence_id for step in event_steps
        ):
            raise ValueError("PG event disagrees with its interval-step provenance")
        if sequence_by_event.get(event.occurrence_id) != (
            event.interval_sequence_occurrence_id
        ):
            raise ValueError("PG event disagrees with its interval-sequence provenance")
    return tuple(sequences)


def _ngrams_from_evidence(events, steps):
    if not events:
        return ()
    return extract_pg_ngrams(
        ProcessedRoutePGStrategies(events[0].route, tuple(events), tuple(steps), ())
    )


def _ngram_statistics(entries, occurrences):
    from collections import Counter

    return {
        "interval_ngram_entry_count": len(entries),
        "interval_ngram_occurrence_count": len(occurrences),
        "interval_ngram_event_count": len({o.event_occurrence_id for o in occurrences}),
        "interval_ngram_route_count": len({o.route for o in occurrences}),
        "interval_ngram_length_histogram": dict(
            sorted(Counter(str(o.length) for o in occurrences).items())
        ),
    }


def _verify_portable_component(
    manifest: PGStrategyLibraryManifest,
    entries: Sequence[PGStrategyLibraryEntry],
    events: Sequence[ProtectingGroupStrategyOccurrence],
    steps: Sequence[PGStrategyIntervalStepOccurrence],
    diagnostics: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, str], dict[str, str]]:
    event_entries, event_ownership = _build_entries("event", events)
    step_entries, step_ownership = _build_entries("interval_step", steps)
    persisted_sequences = tuple(
        entry for entry in entries if entry.kind == "interval_sequence"
    )
    sequences = _sequence_occurrences_from_entries(
        persisted_sequences,
        events,
        steps,
    )
    sequence_entries, _sequence_ownership = _build_entries(
        "interval_sequence", sequences
    )
    ngrams = (
        _ngrams_from_evidence(events, steps)
        if manifest.library_format_version >= 2
        else ()
    )
    ngram_entries, _ = _build_entries("interval_ngram", ngrams)
    rebuilt_entries = tuple(
        sorted(
            (*event_entries, *step_entries, *sequence_entries, *ngram_entries),
            key=lambda item: item.entry_id,
        )
    )
    if rebuilt_entries != tuple(sorted(entries, key=lambda item: item.entry_id)):
        raise ValueError("PG strategy entries disagree with occurrence provenance")
    statistics = _component_statistics(
        event_entries,
        step_entries,
        sequence_entries,
        events,
        steps,
        diagnostics,
    )
    if manifest.library_format_version >= 2:
        statistics.update(_ngram_statistics(ngram_entries, ngrams))
    if events and all(event.schema_version < 2 for event in events):
        statistics.pop("protected_synthon_event_count")
    elif not events and "protected_synthon_event_count" not in manifest.statistics:
        statistics.pop("protected_synthon_event_count")
    if dict(manifest.statistics) != statistics:
        raise ValueError("PG strategy manifest statistics disagree with provenance")
    content = _component_content(
        library_format_version=manifest.library_format_version,
        processing_profile=manifest.processing_profile,
        reference_corpora=manifest.reference_corpora,
        entries=rebuilt_entries,
        events=events,
        steps=steps,
        diagnostics=diagnostics,
    )
    if manifest.library_id != f"pg_strategy_library_{_digest(content)}":
        raise ValueError("PG strategy library_id does not bind its portable contents")
    return event_ownership, step_ownership


class ReferencePGStrategyLibrary:
    """Exact PG-strategy peer catalog with optional SQLite occurrence lookup."""

    def __init__(
        self,
        *,
        manifest: PGStrategyLibraryManifest,
        entries: Sequence[PGStrategyLibraryEntry] | None,
        event_occurrences: Sequence[ProtectingGroupStrategyOccurrence] | None,
        interval_steps: Sequence[PGStrategyIntervalStepOccurrence] | None,
        diagnostics: Sequence[Mapping[str, Any]] | None,
        event_ownership: Mapping[str, str],
        step_ownership: Mapping[str, str],
        directory: Path | None = None,
        connection: sqlite3.Connection | None = None,
    ) -> None:
        self.manifest = manifest
        self._entries = (
            None
            if entries is None
            else tuple(sorted(entries, key=lambda item: item.entry_id))
        )
        self._entry_by_id = {entry.entry_id: entry for entry in (self._entries or ())}
        self._buckets: dict[tuple[str, str], tuple[PGStrategyLibraryEntry, ...]] = {}
        mutable: dict[tuple[str, str], list[PGStrategyLibraryEntry]] = defaultdict(list)
        for entry in self._entries or ():
            mutable[(entry.kind, entry.lookup_key)].append(entry)
        self._buckets = {key: tuple(values) for key, values in mutable.items()}
        self._event_occurrences = (
            None
            if event_occurrences is None
            else {item.occurrence_id: item for item in event_occurrences}
        )
        self._interval_steps = (
            None
            if interval_steps is None
            else {item.occurrence_id: item for item in interval_steps}
        )
        self._event_ownership = dict(event_ownership)
        self._step_ownership = dict(step_ownership)
        self._diagnostics = (
            None
            if diagnostics is None
            else tuple(_json_copy(item) for item in diagnostics)
        )
        self.directory = directory
        self._connection = connection
        self._normalized_temporary = None
        self._normalized_graphs = None
        if manifest.library_format_version >= 4 and connection is not None:
            from route_inspector.protection.strategies.normalized import GraphStore

            self._normalized_graphs = GraphStore(connection)

    @property
    def library_id(self) -> str:
        return self.manifest.library_id

    @property
    def diagnostics(self) -> tuple[Mapping[str, Any], ...]:
        if self._diagnostics is None:
            if self._connection is None:
                raise RuntimeError("PG strategy library is closed")
            self._diagnostics = tuple(
                _json_copy(json.loads(row["diagnostic_json"]))
                for row in self._connection.execute(
                    "SELECT diagnostic_json FROM diagnostics ORDER BY ordinal"
                )
            )
        return self._diagnostics

    @classmethod
    def from_processed_routes(
        cls,
        processed_routes: Iterable[ProcessedRoutePGStrategies],
        *,
        processing_profile: Mapping[str, Any],
        reference_corpora: Sequence[Mapping[str, Any]],
        include_ngrams: bool = False,
    ) -> "ReferencePGStrategyLibrary":
        events_list, steps_list, sequences_list, diagnostics_list = [], [], [], []
        for route in processed_routes:
            events_list.extend(route.events)
            steps_list.extend(route.interval_steps)
            sequences_list.extend(route.interval_sequences)
            diagnostics_list.extend(route.diagnostics)
        events = tuple(events_list)
        steps = tuple(steps_list)
        sequences = tuple(sequences_list)
        diagnostics = tuple(sorted(diagnostics_list, key=canonical_json))
        event_entries, event_ownership = _build_entries("event", events)
        step_entries, step_ownership = _build_entries("interval_step", steps)
        sequence_entries, _sequence_ownership = _build_entries(
            "interval_sequence", sequences
        )
        ngrams = _ngrams_from_evidence(events, steps) if include_ngrams else ()
        ngram_entries, _ = _build_entries("interval_ngram", ngrams)
        entries = (*event_entries, *step_entries, *sequence_entries, *ngram_entries)
        statistics = _component_statistics(
            event_entries,
            step_entries,
            sequence_entries,
            events,
            steps,
            diagnostics,
        )
        if include_ngrams:
            statistics.update(_ngram_statistics(ngram_entries, ngrams))
        content = _component_content(
            library_format_version=(
                3 if any(e.schema_version >= 3 for e in events) else 2
            )
            if include_ngrams
            else 1,
            processing_profile=processing_profile,
            reference_corpora=reference_corpora,
            entries=entries,
            events=events,
            steps=steps,
            diagnostics=diagnostics,
        )
        manifest = PGStrategyLibraryManifest(
            library_format_version=(
                3 if any(e.schema_version >= 3 for e in events) else 2
            )
            if include_ngrams
            else 1,
            catalog_schema_version=(
                3 if any(e.schema_version >= 3 for e in events) else 2
            )
            if include_ngrams
            else 1,
            library_id=f"pg_strategy_library_{_digest(content)}",
            processing_profile=processing_profile,
            reference_corpora=tuple(reference_corpora),
            statistics=statistics,
        )
        return cls(
            manifest=manifest,
            entries=entries,
            event_occurrences=events,
            interval_steps=steps,
            diagnostics=diagnostics,
            event_ownership=event_ownership,
            step_ownership=step_ownership,
        )

    def close(self) -> None:
        if self._normalized_graphs is not None:
            self._normalized_graphs.clear()
        if self._connection is not None:
            self._connection.close()
            self._connection = None
        if self._normalized_temporary is not None:
            self._normalized_temporary.cleanup()
            self._normalized_temporary = None

    def __enter__(self) -> "ReferencePGStrategyLibrary":
        return self

    def __exit__(self, *_args: Any) -> None:
        self.close()

    def _entry_from_row(self, row: sqlite3.Row) -> PGStrategyLibraryEntry:
        entry_id = str(row["entry_id"])
        cached = self._entry_by_id.get(entry_id)
        if cached is not None:
            return cached
        value = json.loads(row["entry_json"])
        if self.manifest.library_format_version == 5:
            from route_inspector.protection.strategies.relational import expand_entry

            value = expand_entry(self._connection, value)
        if self._normalized_graphs is not None:
            value["identity"] = self._normalized_graphs.unpack(value["identity"])
        entry = PGStrategyLibraryEntry.from_dict(value)
        if (entry.entry_id, entry.kind, entry.lookup_key) != (
            entry_id,
            str(row["kind"]),
            str(row["lookup_key"]),
        ):
            raise ValueError("PG strategy entry columns disagree with its payload")
        if self._entries is None and len(self._entry_by_id) >= _LAZY_ENTRY_CACHE_SIZE:
            self._entry_by_id.pop(next(iter(self._entry_by_id)))
        if self.manifest.library_format_version != 5:
            self._entry_by_id[entry_id] = entry
        return entry

    def support_records(self, entry_id, *, offset=0, limit=20):
        """Retrieve one bounded page without expanding a complete family."""
        if self.manifest.library_format_version == 5:
            from route_inspector.protection.strategies.relational import supports

            return tuple(
                supports(self._connection, entry_id, offset=offset, limit=limit)
            )
        if offset < 0 or limit < 1:
            raise ValueError("invalid PG support page bounds")
        return self.entry(entry_id).support_records[offset : offset + limit]

    def entries(self, kind: str | None = None) -> tuple[PGStrategyLibraryEntry, ...]:
        if kind is not None and kind not in {
            "event",
            "interval_step",
            "interval_sequence",
            "interval_ngram",
        }:
            raise ValueError("unsupported PG strategy entry kind")
        if self._entries is not None:
            return tuple(
                entry for entry in self._entries if kind is None or entry.kind == kind
            )
        if self._connection is None:
            raise RuntimeError("PG strategy library is closed")
        sql = "SELECT * FROM entries"
        parameters: tuple[Any, ...] = ()
        if kind is not None:
            sql += " WHERE kind = ?"
            parameters = (kind,)
        sql += " ORDER BY entry_id"
        return tuple(
            self._entry_from_row(row)
            for row in self._connection.execute(sql, parameters)
        )

    def find_entry(self, identity: Any, *, kind: str) -> PGStrategyLibraryEntry | None:
        if self._entries is None:
            if self._connection is None:
                raise RuntimeError("PG strategy library is closed")
            candidates = (
                self._entry_from_row(row)
                for row in self._connection.execute(
                    """SELECT * FROM entries WHERE kind = ? AND lookup_key = ?
                       ORDER BY entry_id""",
                    (kind, identity.lookup_key),
                )
            )
        else:
            candidates = iter(self._buckets.get((kind, identity.lookup_key), ()))
        matches = [
            entry for entry in candidates if _equivalent(entry.identity, identity)
        ]
        if len(matches) > 1:
            raise RuntimeError("PG strategy identity matched multiple entries")
        return matches[0] if matches else None

    def event_entry(
        self, identity: ProtectingGroupStrategyIdentity
    ) -> PGStrategyLibraryEntry | None:
        return self.find_entry(identity, kind="event")

    def interval_step_entry(
        self, identity: PGStrategyIntervalStepIdentity
    ) -> PGStrategyLibraryEntry | None:
        return self.find_entry(identity, kind="interval_step")

    def interval_sequence_entry(
        self, identity: PGStrategyIntervalSequenceIdentity
    ) -> PGStrategyLibraryEntry | None:
        return self.find_entry(identity, kind="interval_sequence")

    def interval_ngram_entry(self, identity: PGStrategyNgramIdentity):
        return self.find_entry(identity, kind="interval_ngram")

    def _occurrence_payload(self, kind, row):
        if self._normalized_graphs is not None:
            from route_inspector.protection.strategies.normalized import read_occurrence

            return read_occurrence(self._connection, self._normalized_graphs, kind, row)
        return json.loads(row["occurrence_json"])

    def get_interval_ngram(self, occurrence_id: str) -> PGStrategyNgramOccurrence:
        if self.manifest.library_format_version < 2:
            raise ValueError(
                "PG n-gram evidence is unavailable in this historical library"
            )
        if self._connection is not None:
            row = self._connection.execute(
                "SELECT * FROM interval_ngram_occurrences WHERE occurrence_id = ?",
                (occurrence_id,),
            ).fetchone()
            if row is None:
                raise KeyError(occurrence_id)
            occurrence = PGStrategyNgramOccurrence.from_dict(
                self._occurrence_payload("interval_ngram", row)
            )
            if (
                row["occurrence_id"] != occurrence.occurrence_id
                or row["event_occurrence_id"] != occurrence.event_occurrence_id
            ):
                raise ValueError("PG n-gram SQLite columns disagree with provenance")
        else:
            record = next(
                (
                    r
                    for e in self.entries("interval_ngram")
                    for r in e.support_records
                    if r["occurrence_id"] == occurrence_id
                ),
                None,
            )
            if record is None:
                raise KeyError(occurrence_id)
            steps = tuple(
                self.get_interval_step(i) for i in record["step_occurrence_ids"]
            )
            occurrence = PGStrategyNgramOccurrence.from_dict(
                {
                    **record,
                    "schema_version": 1,
                    "identity": PGStrategyNgramIdentity(
                        rule_graphs=tuple(s.identity.rule_graph for s in steps)
                    ).to_dict(),
                }
            )
        if self.manifest.library_format_version == 5:
            self._validate_relational_occurrence(occurrence, kind="interval_ngram")
        else:
            entry = self.interval_ngram_entry(occurrence.identity)
            if (
                entry is None
                or _support_record(occurrence) not in entry.support_records
            ):
                raise ValueError("PG n-gram occurrence disagrees with owning entry")
        event = self.get_event_occurrence(occurrence.event_occurrence_id)
        start = occurrence.start_index
        end = start + occurrence.length
        if (
            end > event.lifetime_steps
            or len(event.interval_step_occurrence_ids) != event.lifetime_steps
        ):
            raise ValueError("PG n-gram occurrence disagrees with lifespan positions")
        steps = tuple(
            self.get_interval_step(i)
            for i in event.interval_step_occurrence_ids[start:end]
        )
        for index, step in enumerate(steps, start=start):
            if (
                step.event_occurrence_id != event.occurrence_id
                or step.route != event.route
                or step.step_index != index
                or step.reaction_node_path != event.interval_reaction_node_paths[index]
            ):
                raise ValueError(
                    "PG n-gram source interval has inconsistent provenance"
                )
        expected = PGStrategyNgramOccurrence(
            occurrence_id=occurrence_id,
            event_occurrence_id=event.occurrence_id,
            route=event.route,
            focal_pg_type=event.pg_type,
            active_pg_contexts=tuple(s.active_pg_types for s in steps),
            step_occurrence_ids=tuple(s.occurrence_id for s in steps),
            identity=PGStrategyNgramIdentity(
                rule_graphs=tuple(s.identity.rule_graph for s in steps)
            ),
            start_index=start,
            reaction_node_paths=tuple(s.reaction_node_path for s in steps),
        )
        if occurrence != expected:
            raise ValueError("PG n-gram occurrence disagrees with lifespan positions")
        return occurrence

    def event_entry_id_for_occurrence(self, occurrence_id: str) -> str:
        """Return the exact event entry owning one persisted occurrence."""

        normalized = str(occurrence_id)
        cached = self._event_ownership.get(normalized)
        if cached is not None:
            return cached
        if self._connection is None:
            raise KeyError(occurrence_id)
        row = self._connection.execute(
            "SELECT entry_id FROM event_occurrences WHERE occurrence_id = ?",
            (normalized,),
        ).fetchone()
        if row is None:
            raise KeyError(occurrence_id)
        entry_id = str(row["entry_id"])
        self._event_ownership[normalized] = entry_id
        return entry_id

    def entry(self, entry_id: str) -> PGStrategyLibraryEntry:
        """Return one entry by its deterministic component-local ID."""

        normalized = str(entry_id)
        cached = self._entry_by_id.get(normalized)
        if cached is not None:
            return cached
        if self._connection is None:
            raise KeyError(normalized)
        row = self._connection.execute(
            "SELECT * FROM entries WHERE entry_id = ?",
            (normalized,),
        ).fetchone()
        if row is None:
            raise KeyError(normalized)
        return self._entry_from_row(row)

    def _validate_relational_occurrence(self, occurrence, *, kind):
        row = self._connection.execute(
            "SELECT m.kind,m.occurrence_sha256,e.entry_json FROM memberships m "
            "JOIN entries e ON e.entry_id=m.entry_id WHERE m.occurrence_id=?",
            (occurrence.occurrence_id,),
        ).fetchone()
        if row is None or row[0] != kind:
            raise ValueError("PG occurrence has no owning membership")
        identity = self._normalized_graphs.unpack(json.loads(row[2])["identity"])
        if not _identity_from_dict(kind, identity).equivalent_to(occurrence.identity):
            raise ValueError("PG occurrence identity disagrees with its entry")
        if row[1] != _support_record(occurrence)["occurrence_sha256"]:
            raise ValueError("PG occurrence provenance disagrees with its membership")
        return occurrence

    def entry_summary_for_occurrence(self, occurrence_id):
        """Read scalar support/identity metadata without materializing a family."""
        if self.manifest.library_format_version == 5:
            row = self._connection.execute(
                "SELECT e.entry_json FROM entries e JOIN memberships m ON m.entry_id=e.entry_id WHERE m.occurrence_id=?",
                (occurrence_id,),
            ).fetchone()
            if row is None:
                raise KeyError(occurrence_id)
            return json.loads(row[0])
        step = self.get_interval_step(occurrence_id)
        return self.interval_step_entry(step.identity).to_dict()

    def _validate_occurrence(self, occurrence: Any, *, kind: str) -> Any:
        if self.manifest.library_format_version == 5:
            return self._validate_relational_occurrence(occurrence, kind=kind)
        ownership = self._event_ownership if kind == "event" else self._step_ownership
        try:
            entry = self.entry(ownership[occurrence.occurrence_id])
        except KeyError as exc:
            raise ValueError("PG occurrence has no owning library entry") from exc
        if entry.kind != kind or not entry.identity.equivalent_to(occurrence.identity):
            raise ValueError("PG occurrence identity disagrees with its entry")
        record = next(
            (
                item
                for item in entry.support_records
                if item["occurrence_id"] == occurrence.occurrence_id
            ),
            None,
        )
        if record != _support_record(occurrence):
            raise ValueError("PG occurrence provenance disagrees with its entry")
        return occurrence

    def get_event_occurrence(
        self, occurrence_id: str
    ) -> ProtectingGroupStrategyOccurrence:
        if self._event_occurrences is not None:
            occurrence = self._event_occurrences[str(occurrence_id)]
            return self._validate_occurrence(occurrence, kind="event")
        if self._connection is None:
            raise RuntimeError("PG strategy library is closed")
        row = self._connection.execute(
            "SELECT * FROM event_occurrences WHERE occurrence_id = ?",
            (str(occurrence_id),),
        ).fetchone()
        if row is None:
            raise KeyError(occurrence_id)
        occurrence = ProtectingGroupStrategyOccurrence.from_dict(
            self._occurrence_payload("event", row)
        )
        expected = (
            occurrence.occurrence_id,
            str(row["entry_id"]),
            occurrence.route.dataset_id,
            occurrence.route.source_identity,
            occurrence.route.route_id,
        )
        observed = tuple(row[name] for name in row.keys() if name != "occurrence_json")
        if observed != expected:
            raise ValueError("PG event occurrence columns disagree with its payload")
        self._event_ownership[occurrence.occurrence_id] = str(row["entry_id"])
        return self._validate_occurrence(occurrence, kind="event")

    def event_occurrences_for_entry(
        self, entry_id: str
    ) -> tuple[ProtectingGroupStrategyOccurrence, ...]:
        entry = self.entry(str(entry_id))
        if entry.kind != "event":
            raise ValueError("entry is not a PG event")
        return tuple(
            self.get_event_occurrence(str(record["occurrence_id"]))
            for record in entry.support_records
        )

    def get_interval_step(self, occurrence_id: str) -> PGStrategyIntervalStepOccurrence:
        if self._interval_steps is not None:
            occurrence = self._interval_steps[str(occurrence_id)]
            return self._validate_occurrence(occurrence, kind="interval_step")
        if self._connection is None:
            raise RuntimeError("PG strategy library is closed")
        row = self._connection.execute(
            "SELECT * FROM interval_step_occurrences WHERE occurrence_id = ?",
            (str(occurrence_id),),
        ).fetchone()
        if row is None:
            raise KeyError(occurrence_id)
        occurrence = PGStrategyIntervalStepOccurrence.from_dict(
            self._occurrence_payload("interval_step", row)
        )
        expected = (
            occurrence.occurrence_id,
            str(row["entry_id"]),
            occurrence.event_occurrence_id,
            occurrence.focal_pg_type,
            canonical_json(list(occurrence.active_pg_types)),
            occurrence.route.dataset_id,
            occurrence.route.source_identity,
            occurrence.route.route_id,
        )
        observed = tuple(row[name] for name in row.keys() if name != "occurrence_json")
        if observed != expected:
            raise ValueError("PG interval-step columns disagree with its payload")
        self._step_ownership[occurrence.occurrence_id] = str(row["entry_id"])
        return self._validate_occurrence(occurrence, kind="interval_step")

    def interval_step_occurrences_for_entry(
        self, entry_id: str
    ) -> tuple[PGStrategyIntervalStepOccurrence, ...]:
        entry = self.entry(str(entry_id))
        if entry.kind != "interval_step":
            raise ValueError("entry is not a PG interval step")
        return tuple(
            self.get_interval_step(str(record["occurrence_id"]))
            for record in entry.support_records
        )

    @staticmethod
    def _write_jsonl(path: Path, values: Iterable[Mapping[str, Any]]) -> None:
        with path.open("w", encoding="utf-8", newline="\n") as stream:
            for value in values:
                stream.write(canonical_json(value) + "\n")

    def write_component(self, root: Path, *, include_sqlite: bool) -> Path:
        return self.write(root / "pg_strategy", include_sqlite=include_sqlite)

    def write(self, directory: Path, *, include_sqlite: bool = True) -> Path:
        if self.manifest.library_format_version == 5:
            from route_inspector.protection.strategies.normalized_verify import (
                processed_routes,
            )
            from route_inspector.protection.strategies.relational import (
                write_relational,
            )

            manifest = write_relational(
                processed_routes(
                    self._connection,
                    self._normalized_graphs,
                    self.manifest.reference_corpora,
                ),
                directory,
                processing_profile=self.manifest.processing_profile,
                reference_corpora=self.manifest.reference_corpora,
                include_sqlite=include_sqlite,
            )
            if manifest.library_id != self.library_id:
                raise ValueError("relational PG rewrite changed its logical contents")
            return Path(directory) / "manifest.json"
        if self.manifest.library_format_version == 4:
            from route_inspector.protection.strategies.normalized_build import (
                write_normalized,
            )
            from route_inspector.protection.strategies.normalized_verify import (
                processed_routes,
            )

            manifest = write_normalized(
                processed_routes(
                    self._connection,
                    self._normalized_graphs,
                    self.manifest.reference_corpora,
                ),
                directory,
                processing_profile=self.manifest.processing_profile,
                reference_corpora=self.manifest.reference_corpora,
                include_sqlite=include_sqlite,
            )
            if manifest.library_id != self.library_id:
                raise ValueError("normalized PG rewrite changed its logical contents")
            return Path(directory) / "manifest.json"
        directory = Path(directory)
        for child in (
            "events",
            "provenance",
            "interval_steps",
            "interval_sequences",
            "interval_ngrams",
            "reports",
        ):
            (directory / child).mkdir(parents=True, exist_ok=True)
        event_entries = self.entries("event")
        step_entries = self.entries("interval_step")
        sequence_entries = self.entries("interval_sequence")
        event_occurrences = tuple(
            self.get_event_occurrence(record["occurrence_id"])
            for entry in event_entries
            for record in entry.support_records
        )
        interval_steps = tuple(
            self.get_interval_step(record["occurrence_id"])
            for entry in step_entries
            for record in entry.support_records
        )
        paths = {
            name: directory / relative
            for name, relative in _COMPONENT_PATHS.items()
            if name != "catalog"
            and (self.manifest.library_format_version >= 2 or name not in _NGRAM_PATHS)
        }
        self._write_jsonl(
            paths["event_entries"], (entry.to_dict() for entry in event_entries)
        )
        self._write_jsonl(
            paths["event_occurrences"],
            (
                item.to_dict()
                for item in sorted(
                    event_occurrences, key=lambda item: item.occurrence_id
                )
            ),
        )
        self._write_jsonl(
            paths["interval_step_entries"], (entry.to_dict() for entry in step_entries)
        )
        self._write_jsonl(
            paths["interval_step_occurrences"],
            (
                item.to_dict()
                for item in sorted(interval_steps, key=lambda item: item.occurrence_id)
            ),
        )
        self._write_jsonl(
            paths["interval_sequence_entries"],
            (entry.to_dict() for entry in sequence_entries),
        )
        self._write_jsonl(paths["diagnostics"], self.diagnostics)
        self._write_reports(paths, event_entries, step_entries, sequence_entries)
        if self.manifest.library_format_version >= 2:
            ngrams = _ngrams_from_evidence(event_occurrences, interval_steps)
            ngram_entries = self.entries("interval_ngram")
            self._write_jsonl(
                paths["ngram_entries"], (e.to_dict() for e in ngram_entries)
            )
            self._write_jsonl(
                paths["ngram_occurrences"],
                (o.to_dict() for o in sorted(ngrams, key=lambda o: o.occurrence_id)),
            )
            with paths["errors"].open("w", newline="", encoding="utf-8") as stream:
                fields = (
                    "dataset_id",
                    "route_id",
                    "event_id",
                    "stage",
                    "error_type",
                    "message",
                )
                writer = csv.DictWriter(
                    stream, fieldnames=fields, delimiter="\t", lineterminator="\n"
                )
                writer.writeheader()
                for d in self.diagnostics:
                    writer.writerow(
                        {
                            "dataset_id": d.get("route", {}).get("dataset_id", ""),
                            "route_id": d.get("route", {}).get("route_id", ""),
                            **{k: d.get(k, "") for k in fields[2:]},
                        }
                    )
            with paths["report_ngrams"].open(
                "w", newline="", encoding="utf-8"
            ) as stream:
                writer = csv.DictWriter(
                    stream,
                    fieldnames=(
                        "entry_id",
                        "length",
                        "occurrence_count",
                        "event_count",
                        "route_count",
                    ),
                    delimiter="\t",
                )
                writer.writeheader()
                for entry in ngram_entries:
                    writer.writerow(
                        dict(
                            entry_id=entry.entry_id,
                            length=len(entry.identity.rule_graphs),
                            occurrence_count=entry.occurrence_count,
                            event_count=len(
                                {
                                    r["event_occurrence_id"]
                                    for r in entry.support_records
                                }
                            ),
                            route_count=entry.route_count,
                        )
                    )
        summary = {"library_id": self.library_id, **dict(self.manifest.statistics)}
        paths["summary"].write_text(
            json.dumps(summary, indent=2) + "\n", encoding="utf-8"
        )
        if include_sqlite:
            sqlite_path = directory / _COMPONENT_PATHS["catalog"]
            self._write_sqlite(
                sqlite_path,
                event_entries,
                step_entries,
                sequence_entries,
                event_occurrences,
                interval_steps,
            )
            paths["catalog"] = sqlite_path
        artifacts = {
            name: {
                "path": path.relative_to(directory).as_posix(),
                "sha256": _sha256_file(path),
                "size_bytes": path.stat().st_size,
            }
            for name, path in sorted(paths.items())
        }
        manifest = PGStrategyLibraryManifest(
            library_format_version=self.manifest.library_format_version,
            catalog_schema_version=self.manifest.catalog_schema_version,
            library_id=self.library_id,
            processing_profile=self.manifest.processing_profile,
            reference_corpora=self.manifest.reference_corpora,
            statistics=self.manifest.statistics,
            artifacts=artifacts,
        )
        manifest_path = directory / "manifest.json"
        manifest_path.write_text(
            json.dumps(manifest.to_dict(), indent=2) + "\n", encoding="utf-8"
        )
        self.manifest = manifest
        return manifest_path

    @staticmethod
    def _write_reports(
        paths: Mapping[str, Path],
        event_entries: Sequence[PGStrategyLibraryEntry],
        step_entries: Sequence[PGStrategyLibraryEntry],
        sequence_entries: Sequence[PGStrategyLibraryEntry],
    ) -> None:
        def write(
            path: Path, fields: Sequence[str], rows: Iterable[Mapping[str, Any]]
        ) -> None:
            with path.open("w", encoding="utf-8", newline="") as stream:
                writer = csv.DictWriter(
                    stream, fieldnames=fields, delimiter="\t", lineterminator="\n"
                )
                writer.writeheader()
                writer.writerows(rows)

        write(
            paths["report_events"],
            (
                "entry_id",
                "pg_type",
                "source_type",
                "protected_functional_group",
                "route_count",
                "occurrence_count",
                "representative_occurrence_id",
            ),
            (
                {
                    "entry_id": entry.entry_id,
                    "pg_type": entry.identity.pg_type,
                    "source_type": entry.identity.source_type,
                    "protected_functional_group": entry.identity.protected_functional_group,
                    "route_count": entry.route_count,
                    "occurrence_count": entry.occurrence_count,
                    "representative_occurrence_id": entry.representative_occurrence_id,
                }
                for entry in event_entries
            ),
        )
        write(
            paths["report_interval_steps"],
            (
                "entry_id",
                "route_count",
                "occurrence_count",
                "representative_occurrence_id",
            ),
            (
                {
                    "entry_id": entry.entry_id,
                    "route_count": entry.route_count,
                    "occurrence_count": entry.occurrence_count,
                    "representative_occurrence_id": entry.representative_occurrence_id,
                }
                for entry in step_entries
            ),
        )
        write(
            paths["report_interval_sequences"],
            (
                "entry_id",
                "length",
                "route_count",
                "occurrence_count",
                "representative_occurrence_id",
            ),
            (
                {
                    "entry_id": entry.entry_id,
                    "length": len(entry.identity.rule_graphs),
                    "route_count": entry.route_count,
                    "occurrence_count": entry.occurrence_count,
                    "representative_occurrence_id": entry.representative_occurrence_id,
                }
                for entry in sequence_entries
            ),
        )

    def _write_sqlite(
        self,
        path: Path,
        event_entries: Sequence[PGStrategyLibraryEntry],
        step_entries: Sequence[PGStrategyLibraryEntry],
        sequence_entries: Sequence[PGStrategyLibraryEntry],
        events: Sequence[ProtectingGroupStrategyOccurrence],
        steps: Sequence[PGStrategyIntervalStepOccurrence],
    ) -> None:
        connection = sqlite3.connect(path)
        try:
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute(
                f"PRAGMA user_version = {self.manifest.catalog_schema_version}"
            )
            connection.executescript(_SCHEMA_SQL)
            if self.manifest.library_format_version >= 2:
                connection.executescript(
                    "CREATE TABLE interval_ngram_occurrences(occurrence_id TEXT PRIMARY KEY, event_occurrence_id TEXT NOT NULL, occurrence_json TEXT NOT NULL); CREATE INDEX interval_ngrams_event ON interval_ngram_occurrences(event_occurrence_id);"
                )
                connection.executemany(
                    "INSERT INTO interval_ngram_occurrences VALUES (?, ?, ?)",
                    (
                        (
                            o.occurrence_id,
                            o.event_occurrence_id,
                            canonical_json(o.to_dict()),
                        )
                        for o in _ngrams_from_evidence(events, steps)
                    ),
                )
            with connection:
                connection.executemany(
                    "INSERT INTO metadata VALUES (?, ?)",
                    (
                        (key, canonical_json(value))
                        for key, value in {
                            "library_id": self.library_id,
                            "statistics": dict(self.manifest.statistics),
                        }.items()
                    ),
                )
                connection.executemany(
                    "INSERT INTO entries VALUES (?, ?, ?, ?)",
                    (
                        (
                            entry.entry_id,
                            entry.kind,
                            entry.lookup_key,
                            canonical_json(entry.to_dict()),
                        )
                        for entry in self.entries()
                    ),
                )
                connection.executemany(
                    "INSERT INTO event_occurrences VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        (
                            event.occurrence_id,
                            self._event_ownership[event.occurrence_id],
                            event.route.dataset_id,
                            event.route.source_identity,
                            event.route.route_id,
                            canonical_json(event.to_dict()),
                        )
                        for event in events
                    ),
                )
                connection.executemany(
                    "INSERT INTO interval_step_occurrences VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        (
                            step.occurrence_id,
                            self._step_ownership[step.occurrence_id],
                            step.event_occurrence_id,
                            step.focal_pg_type,
                            canonical_json(list(step.active_pg_types)),
                            step.route.dataset_id,
                            step.route.source_identity,
                            step.route.route_id,
                            canonical_json(step.to_dict()),
                        )
                        for step in steps
                    ),
                )
                connection.executemany(
                    "INSERT INTO diagnostics VALUES (?, ?)",
                    (
                        (index, canonical_json(item))
                        for index, item in enumerate(self.diagnostics)
                    ),
                )
            from route_inspector.protection.strategies.browsing import (
                build_browse_tables,
                sqlite_browse_entries,
            )

            build_browse_tables(connection, sqlite_browse_entries(connection))
        finally:
            connection.close()

    @classmethod
    def _open_fast_sqlite(
        cls,
        directory: Path,
        manifest: PGStrategyLibraryManifest,
    ) -> "ReferencePGStrategyLibrary":
        path = directory / _COMPONENT_PATHS["catalog"]
        connection = sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA query_only = ON")
        try:
            if int(connection.execute("PRAGMA user_version").fetchone()[0]) != (
                manifest.catalog_schema_version
            ):
                raise ValueError("unsupported PG strategy SQLite schema")
            required_tables = {
                "metadata",
                "entries",
                "event_occurrences",
                "interval_step_occurrences",
                "diagnostics",
            }
            if manifest.library_format_version >= 2:
                required_tables.add("interval_ngram_occurrences")
            if manifest.library_format_version >= 4:
                required_tables.add("rule_graphs")
            observed_tables = {
                str(row["name"])
                for row in connection.execute(
                    "SELECT name FROM sqlite_master WHERE type IN ('table','view')"
                )
            }
            if not required_tables.issubset(observed_tables):
                raise ValueError("PG strategy SQLite catalog is missing tables")
            required_indexes = {
                "entries_lookup",
                "event_occurrences_entry",
                "interval_steps_entry",
                "interval_steps_event",
                "interval_steps_pg",
            }
            if manifest.library_format_version >= 2:
                required_indexes.add("interval_ngrams_event")
            observed_indexes = {
                str(row["name"])
                for row in connection.execute(
                    "SELECT name FROM sqlite_master WHERE type = 'index'"
                )
            }
            if not required_indexes.issubset(observed_indexes):
                raise ValueError("PG strategy SQLite catalog is missing indexes")
            metadata = {
                str(row["key"]): json.loads(row["value_json"])
                for row in connection.execute(
                    "SELECT key, value_json FROM metadata ORDER BY key"
                )
            }
            if metadata != {
                "library_id": manifest.library_id,
                "statistics": dict(manifest.statistics),
            }:
                raise ValueError("PG strategy SQLite metadata disagrees with manifest")
            return cls(
                manifest=manifest,
                entries=None,
                event_occurrences=None,
                interval_steps=None,
                diagnostics=None,
                event_ownership={},
                step_ownership={},
                directory=directory,
                connection=connection,
            )
        except Exception:
            connection.close()
            raise

    @classmethod
    @audit_scope
    def load(
        cls, root: str | Path, *, backend: str = "auto", verification: str = "fast"
    ) -> "ReferencePGStrategyLibrary":
        """Load a PG component using the Reference library's trust contract.

        ``fast`` trusts a previously verified, unchanged library. Existing
        structural and metadata checks are not a substitute for artifact
        hashes or the full portable-data audit. Exact matching is unchanged.
        Use ``full`` after building, importing, copying or updating a library;
        keep all files immutable while any loaded handle is in use. JSONL-only
        loading still takes the full-validation path.
        """
        if backend not in {"auto", "sqlite", "jsonl"}:
            raise ValueError("PG strategy backend must be auto, sqlite, or jsonl")
        if verification not in {"fast", "full"}:
            raise ValueError("PG strategy verification must be fast or full")
        supplied = Path(root).expanduser()
        direct = supplied / "manifest.json"
        direct_manifest = (
            json.loads(direct.read_text(encoding="utf-8")) if direct.is_file() else {}
        )
        directory = (
            supplied
            if str(direct_manifest.get("library_id", "")).startswith(
                "pg_strategy_library_"
            )
            else supplied / "pg_strategy"
        )
        manifest_path = directory / "manifest.json"
        manifest = PGStrategyLibraryManifest.from_dict(
            json.loads(manifest_path.read_text(encoding="utf-8"))
        )
        if manifest.library_format_version == 5:
            from route_inspector.protection.strategies.relational_verify import (
                load_relational,
            )

            return load_relational(
                cls, directory, manifest, backend=backend, verification=verification
            )
        if manifest.library_format_version == 4:
            from route_inspector.protection.strategies.normalized_verify import (
                load_normalized,
            )

            return load_normalized(
                cls, directory, manifest, backend=backend, verification=verification
            )
        artifacts = set(manifest.artifacts)
        allowed = (
            _COMPONENT_PATHS if manifest.library_format_version >= 2 else _LEGACY_PATHS
        )
        if not (set(allowed) - {"catalog"}) <= artifacts or not artifacts <= set(
            allowed
        ):
            raise ValueError(
                "PG strategy manifest artifact set is incomplete or unknown"
            )
        full = (
            verification == "full" or backend == "jsonl" or "catalog" not in artifacts
        )
        for name, descriptor in manifest.artifacts.items():
            if descriptor["path"] != _COMPONENT_PATHS[name]:
                raise ValueError(f"noncanonical PG strategy artifact path for {name}")
            path = directory / descriptor["path"]
            if not path.is_file() or path.stat().st_size != int(
                descriptor["size_bytes"]
            ):
                raise ValueError(
                    f"PG strategy artifact is missing or has wrong size: {name}"
                )
            if full and _sha256_file(path) != descriptor["sha256"]:
                raise ValueError(f"PG strategy artifact hash mismatch: {name}")
        use_sqlite = backend != "jsonl" and "catalog" in artifacts
        if backend == "sqlite" and "catalog" not in artifacts:
            raise FileNotFoundError(directory / _COMPONENT_PATHS["catalog"])
        if use_sqlite and not full:
            return cls._open_fast_sqlite(directory, manifest)
        entries: list[PGStrategyLibraryEntry] = []
        for name, expected_kind in (
            ("event_entries", "event"),
            ("interval_step_entries", "interval_step"),
            ("interval_sequence_entries", "interval_sequence"),
            *(
                (("ngram_entries", "interval_ngram"),)
                if manifest.library_format_version >= 2
                else ()
            ),
        ):
            artifact_entries: list[PGStrategyLibraryEntry] = []
            with (directory / _COMPONENT_PATHS[name]).open(encoding="utf-8") as stream:
                for line in stream:
                    if not line.strip():
                        continue
                    raw = json.loads(line)
                    entry = PGStrategyLibraryEntry.from_dict(raw)
                    if canonical_json(raw) != canonical_json(entry.to_dict()):
                        raise ValueError(f"{name} contains incomplete entry data")
                    if entry.kind != expected_kind:
                        raise ValueError(f"{name} contains the wrong entry kind")
                    artifact_entries.append(entry)
            if [entry.entry_id for entry in artifact_entries] != sorted(
                entry.entry_id for entry in artifact_entries
            ):
                raise ValueError(f"{name} is not canonically ordered")
            entries.extend(artifact_entries)
        if len({entry.entry_id for entry in entries}) != len(entries):
            raise ValueError("PG strategy entry sidecars contain duplicate IDs")
        event_ownership = {
            str(record["occurrence_id"]): entry.entry_id
            for entry in entries
            if entry.kind == "event"
            for record in entry.support_records
        }
        step_ownership = {
            str(record["occurrence_id"]): entry.entry_id
            for entry in entries
            if entry.kind == "interval_step"
            for record in entry.support_records
        }
        with (directory / _COMPONENT_PATHS["diagnostics"]).open(
            encoding="utf-8"
        ) as stream:
            diagnostics = tuple(
                _json_copy(json.loads(line)) for line in stream if line.strip()
            )
        if diagnostics != tuple(sorted(diagnostics, key=canonical_json)):
            raise ValueError("PG strategy diagnostics are not canonically ordered")

        def load_rows(name: str, factory: Any) -> tuple[Any, ...]:
            values = []
            with (directory / _COMPONENT_PATHS[name]).open(encoding="utf-8") as stream:
                for line in stream:
                    if not line.strip():
                        continue
                    raw = json.loads(line)
                    value = factory(raw)
                    if canonical_json(raw) != canonical_json(value.to_dict()):
                        raise ValueError(f"{name} contains incomplete occurrence data")
                    values.append(value)
            occurrence_ids = [value.occurrence_id for value in values]
            if occurrence_ids != sorted(occurrence_ids) or len(occurrence_ids) != len(
                set(occurrence_ids)
            ):
                raise ValueError(f"{name} is not canonically ordered and unique")
            return tuple(values)

        portable_events = None
        portable_steps = None
        if full:
            portable_events = load_rows(
                "event_occurrences", ProtectingGroupStrategyOccurrence.from_dict
            )
            portable_steps = load_rows(
                "interval_step_occurrences",
                PGStrategyIntervalStepOccurrence.from_dict,
            )
            event_ownership, step_ownership = _verify_portable_component(
                manifest, entries, portable_events, portable_steps, diagnostics
            )
            if manifest.library_format_version >= 2:
                persisted_ngrams = load_rows(
                    "ngram_occurrences", PGStrategyNgramOccurrence.from_dict
                )
                expected_ngrams = tuple(
                    sorted(
                        _ngrams_from_evidence(portable_events, portable_steps),
                        key=lambda o: o.occurrence_id,
                    )
                )
                if persisted_ngrams != expected_ngrams:
                    raise ValueError(
                        "PG n-gram provenance disagrees with complete lifespan windows"
                    )
            summary = json.loads(
                (directory / _COMPONENT_PATHS["summary"]).read_text(encoding="utf-8")
            )
            if summary != {
                "library_id": manifest.library_id,
                **dict(manifest.statistics),
            }:
                raise ValueError("PG strategy summary disagrees with its manifest")

        if use_sqlite:
            connection = sqlite3.connect(directory / _COMPONENT_PATHS["catalog"])
            connection.row_factory = sqlite3.Row
            if int(connection.execute("PRAGMA user_version").fetchone()[0]) != (
                manifest.catalog_schema_version
            ):
                connection.close()
                raise ValueError("unsupported PG strategy SQLite schema")
            integrity = connection.execute("PRAGMA integrity_check").fetchone()
            if integrity is None or str(integrity[0]).lower() != "ok":
                connection.close()
                raise ValueError("PG strategy SQLite integrity check failed")
            metadata = {
                str(row["key"]): json.loads(row["value_json"])
                for row in connection.execute("SELECT key, value_json FROM metadata")
            }
            if metadata != {
                "library_id": manifest.library_id,
                "statistics": dict(manifest.statistics),
            }:
                connection.close()
                raise ValueError("PG strategy SQLite metadata disagrees with manifest")
            sqlite_entries = tuple(
                PGStrategyLibraryEntry.from_dict(json.loads(row["entry_json"]))
                for row in connection.execute(
                    "SELECT entry_json FROM entries ORDER BY entry_id"
                )
            )
            if sqlite_entries != tuple(sorted(entries, key=lambda item: item.entry_id)):
                connection.close()
                raise ValueError("PG strategy SQLite entries disagree with sidecars")
            if manifest.library_format_version >= 2:
                rows = tuple(
                    connection.execute(
                        "SELECT occurrence_id, event_occurrence_id, occurrence_json FROM interval_ngram_occurrences ORDER BY occurrence_id"
                    )
                )
                expected = tuple(
                    (
                        o.occurrence_id,
                        o.event_occurrence_id,
                        canonical_json(o.to_dict()),
                    )
                    for o in expected_ngrams
                )
                if tuple(tuple(row) for row in rows) != expected:
                    connection.close()
                    raise ValueError(
                        "PG n-gram SQLite provenance disagrees with sidecars"
                    )
            library = cls(
                manifest=manifest,
                entries=entries,
                event_occurrences=None,
                interval_steps=None,
                diagnostics=diagnostics,
                event_ownership=event_ownership,
                step_ownership=step_ownership,
                directory=directory,
                connection=connection,
            )
        else:
            if portable_events is None or portable_steps is None:
                raise RuntimeError("portable PG strategy provenance was not loaded")
            library = cls(
                manifest=manifest,
                entries=entries,
                event_occurrences=portable_events,
                interval_steps=portable_steps,
                diagnostics=diagnostics,
                event_ownership=event_ownership,
                step_ownership=step_ownership,
                directory=directory,
            )
        if use_sqlite and full:
            try:
                for occurrence in portable_events:
                    if (
                        library.get_event_occurrence(occurrence.occurrence_id)
                        != occurrence
                    ):
                        raise ValueError(
                            "PG event SQLite provenance disagrees with sidecars"
                        )
                for occurrence in portable_steps:
                    if (
                        library.get_interval_step(occurrence.occurrence_id)
                        != occurrence
                    ):
                        raise ValueError(
                            "PG step SQLite provenance disagrees with sidecars"
                        )
            except Exception:
                library.close()
                raise
        return library

    @classmethod
    def verify(
        cls, root: str | Path, *, backend: str = "auto"
    ) -> PGStrategyLibraryManifest:
        with cls.load(root, backend=backend, verification="full") as library:
            return library.manifest


__all__ = [
    "PG_STRATEGY_ASSESSMENT_SCHEMA_VERSION",
    "PG_STRATEGY_CATALOG_SCHEMA_VERSION",
    "PG_STRATEGY_LIBRARY_FORMAT_VERSION",
    "PGStrategyLibraryEntry",
    "PGStrategyLibraryManifest",
    "ReferencePGStrategyLibrary",
]
