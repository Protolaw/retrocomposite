"""Reuse published PG lifespans, rules and classifications without chemistry."""

import json
from collections import defaultdict

from route_inspector.protection.strategies.models import (
    PGStrategyIntervalSequenceIdentity,
    PGStrategyIntervalSequenceOccurrence,
    ProcessedRoutePGStrategies,
)
from route_inspector.protection.strategies.staging import _pg_record
from route_inspector.reference_library.models import ReferenceRouteKey
from route_inspector.rules.graph import canonical_json


def seed_routes(db, library, route_ids):
    selected = set(map(str, route_ids))
    db.execute("CREATE TABLE IF NOT EXISTS pg_reuse_state(key TEXT PRIMARY KEY)")
    diagnostics = defaultdict(list)
    unassigned = []
    for diagnostic in library.diagnostics:
        route = diagnostic.get("route")
        key = route.get("route_id") if isinstance(route, dict) else None
        if key is None:
            unassigned.append(diagnostic)
        elif str(key) in selected:
            diagnostics[str(key)].append(diagnostic)
    corpus = library.manifest.reference_corpora[0]
    for route_id in sorted(selected):
        ordinal = db.execute(
            "SELECT ordinal FROM route_inputs WHERE route_id=?", (route_id,)
        ).fetchone()
        if ordinal is None:
            raise ValueError(f"reused PG route absent from input: {route_id}")
        if db.execute(
            "SELECT 1 FROM route_results WHERE route_id=?", (route_id,)
        ).fetchone():
            continue
        if library._connection is not None:
            ids = (
                r[0]
                for r in library._connection.execute(
                    "SELECT occurrence_id FROM event_occurrences WHERE route_id=? ORDER BY occurrence_id",
                    (route_id,),
                )
            )
            events = tuple(library.get_event_occurrence(oid) for oid in ids)
        else:
            events = tuple(
                e
                for e in library._event_occurrences.values()
                if e.route.route_id == route_id
            )
        steps, sequences = [], []
        for event in events:
            interval = tuple(
                library.get_interval_step(oid)
                for oid in event.interval_step_occurrence_ids
            )
            steps.extend(interval)
            if event.interval_sequence_occurrence_id:
                sequences.append(
                    PGStrategyIntervalSequenceOccurrence(
                        occurrence_id=event.interval_sequence_occurrence_id,
                        event_occurrence_id=event.occurrence_id,
                        route=event.route,
                        focal_pg_type=event.pg_type,
                        active_pg_contexts=tuple(s.active_pg_types for s in interval),
                        step_occurrence_ids=event.interval_step_occurrence_ids,
                        identity=PGStrategyIntervalSequenceIdentity(
                            rule_graphs=tuple(s.identity.rule_graph for s in interval)
                        ),
                    )
                )
        processed = ProcessedRoutePGStrategies(
            ReferenceRouteKey(
                corpus["dataset_id"], corpus["source_identity"], route_id
            ),
            events,
            tuple(steps),
            tuple(sequences),
            tuple(diagnostics[route_id]),
        )
        db.execute(
            "INSERT INTO route_results VALUES(?,?,?)",
            (ordinal[0], route_id, _pg_record(processed)),
        )
        db.commit()
    if (
        unassigned
        and not db.execute(
            "SELECT 1 FROM pg_reuse_state WHERE key='global_diagnostics'"
        ).fetchone()
    ):
        row = db.execute(
            "SELECT input_ordinal,pg_json FROM route_results ORDER BY input_ordinal LIMIT 1"
        ).fetchone()
        if row is None:
            raise ValueError("cannot retain unassigned PG diagnostics without a route")
        value = json.loads(row[1])
        value["diagnostics"].extend(unassigned)
        db.execute(
            "UPDATE route_results SET pg_json=? WHERE input_ordinal=?",
            (canonical_json(value), row[0]),
        )
        db.execute("INSERT INTO pg_reuse_state VALUES('global_diagnostics')")
        db.commit()
