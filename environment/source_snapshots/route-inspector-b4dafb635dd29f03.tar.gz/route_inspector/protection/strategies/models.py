"""Versioned ProtectingGroupStrategy identities and occurrence provenance."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from route_inspector.reference_library.models import ReferenceRouteKey
from route_inspector.rules.graph import (
    canonical_json,
    graph_coarse_signature,
    labelled_graphs_are_isomorphic,
    rule_smarts_to_graph,
)

PG_STRATEGY_IDENTITY_VERSION = 3
PG_STRATEGY_OCCURRENCE_SCHEMA_VERSION = 3
_SUPPORTED_PG_STRATEGY_IDENTITY_VERSIONS = frozenset({1, 2, 3})
_SUPPORTED_PG_STRATEGY_OCCURRENCE_SCHEMAS = frozenset({1, 2, 3})
PG_STRATEGY_SOURCE_TYPES = frozenset(
    {"introduced", "protected_synthon", "stock", "unknown"}
)
PG_STRATEGY_INTERVAL_IDENTITY_VERSION = 1
PG_STRATEGY_INTERVAL_OCCURRENCE_SCHEMA_VERSION = 1


def _json_object(value: Mapping[str, Any] | None, *, label: str) -> dict[str, Any]:
    try:
        copied = json.loads(canonical_json(dict(value or {})))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must contain finite JSON data") from exc
    if not isinstance(copied, dict):
        raise ValueError(f"{label} must be a JSON object")
    return copied


def _path(value: Sequence[Any]) -> tuple[int, ...]:
    path = tuple(int(index) for index in value)
    if any(index < 0 for index in path):
        raise ValueError("route-node paths must contain non-negative indices")
    return path


def _digest(prefix: str, payload: Mapping[str, Any]) -> str:
    digest = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
    return f"{prefix}{digest}"


@dataclass(frozen=True)
class ProtectingGroupStrategyIdentity:
    """Exact map-independent identity of a PG lifecycle or target candidate."""

    pg_type: str
    protected_functional_group: str
    source_type: str
    deprotection_rule_graph: Mapping[str, Any] | None
    protection_rule_graph: Mapping[str, Any] | None = None
    lookup_key: str = ""
    identity_version: int = PG_STRATEGY_IDENTITY_VERSION
    endpoint_kind: str = "deprotection"

    def __post_init__(self) -> None:
        pg_type = str(self.pg_type).strip()
        protected_group = str(self.protected_functional_group).strip()
        source_type = str(self.source_type)
        if not pg_type or not protected_group:
            raise ValueError(
                "PG strategy identity requires PG and functional-group names"
            )
        identity_version = int(self.identity_version)
        if source_type not in PG_STRATEGY_SOURCE_TYPES:
            raise ValueError(
                "PG strategy source_type must be introduced, protected_synthon, "
                "stock, or unknown"
            )
        if identity_version not in _SUPPORTED_PG_STRATEGY_IDENTITY_VERSIONS:
            raise ValueError("unsupported PG strategy identity version")
        if source_type == "protected_synthon" and identity_version < 2:
            raise ValueError("protected_synthon requires PG strategy identity v2")
        if self.endpoint_kind not in {"deprotection", "target"}:
            raise ValueError("invalid PG endpoint kind")
        if self.endpoint_kind == "target" and identity_version < 3:
            raise ValueError("target endpoint requires PG identity v3")
        if self.source_type == "unknown" and (
            identity_version < 3 or self.endpoint_kind != "target"
        ):
            raise ValueError("unknown source is only valid for target candidates")
        deprotection = None
        deprotection_signature = None
        if self.endpoint_kind == "deprotection":
            deprotection = _json_object(
                self.deprotection_rule_graph, label="deprotection_rule_graph"
            )
            deprotection_signature = graph_coarse_signature(deprotection)
        elif self.deprotection_rule_graph is not None:
            raise ValueError("target endpoint cannot contain a deprotection rule")
        protection = None
        protection_signature = None
        if self.protection_rule_graph is not None:
            protection = _json_object(
                self.protection_rule_graph,
                label="protection_rule_graph",
            )
            protection_signature = graph_coarse_signature(protection)
        if source_type in {"introduced", "protected_synthon"} and protection is None:
            raise ValueError(
                f"{source_type} PG strategy identity requires a source-endpoint rule"
            )
        if source_type == "stock" and protection is not None:
            raise ValueError(
                "stock PG strategy identity cannot contain a protection rule"
            )
        signature = {
            "identity_version": identity_version,
            "pg_type": pg_type,
            "protected_functional_group": protected_group,
            "source_type": source_type,
            "deprotection_rule_signature": deprotection_signature,
            "protection_rule_signature": protection_signature,
        }
        if identity_version >= 3:
            signature["endpoint_kind"] = self.endpoint_kind
        expected = _digest("pg_strategy_i_", signature)
        if self.lookup_key and str(self.lookup_key) != expected:
            raise ValueError("PG strategy lookup_key disagrees with its identity")
        object.__setattr__(self, "pg_type", pg_type)
        object.__setattr__(self, "protected_functional_group", protected_group)
        object.__setattr__(self, "source_type", source_type)
        object.__setattr__(self, "deprotection_rule_graph", deprotection)
        object.__setattr__(self, "protection_rule_graph", protection)
        object.__setattr__(self, "lookup_key", expected)
        object.__setattr__(self, "identity_version", identity_version)

    @classmethod
    def from_rules(
        cls,
        *,
        pg_type: str,
        protected_functional_group: str,
        source_type: str,
        deprotection_rule_smarts: str,
        protection_rule_smarts: str = "",
        endpoint_kind: str = "deprotection",
    ) -> "ProtectingGroupStrategyIdentity":
        return cls(
            pg_type=pg_type,
            protected_functional_group=protected_functional_group,
            source_type=source_type,
            endpoint_kind=endpoint_kind,
            deprotection_rule_graph=(
                rule_smarts_to_graph(deprotection_rule_smarts)
                if deprotection_rule_smarts
                else None
            ),
            protection_rule_graph=(
                rule_smarts_to_graph(protection_rule_smarts)
                if protection_rule_smarts
                else None
            ),
        )

    def equivalent_to(self, other: object) -> bool:
        if not isinstance(other, ProtectingGroupStrategyIdentity):
            return False
        if (
            self.identity_version != other.identity_version
            or self.lookup_key != other.lookup_key
            or self.pg_type != other.pg_type
            or self.protected_functional_group != other.protected_functional_group
            or self.source_type != other.source_type
        ):
            return False
        if self.endpoint_kind != other.endpoint_kind:
            return False
        if (
            self.deprotection_rule_graph is None
            or other.deprotection_rule_graph is None
        ):
            if self.deprotection_rule_graph is not other.deprotection_rule_graph:
                return False
        elif not labelled_graphs_are_isomorphic(
            self.deprotection_rule_graph, other.deprotection_rule_graph
        ):
            return False
        if self.protection_rule_graph is None or other.protection_rule_graph is None:
            return self.protection_rule_graph is other.protection_rule_graph
        return labelled_graphs_are_isomorphic(
            self.protection_rule_graph,
            other.protection_rule_graph,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "identity_version": self.identity_version,
            "lookup_key": self.lookup_key,
            "pg_type": self.pg_type,
            "protected_functional_group": self.protected_functional_group,
            "source_type": self.source_type,
            "deprotection_rule_graph": (
                dict(self.deprotection_rule_graph)
                if self.deprotection_rule_graph is not None
                else None
            ),
            **(
                {"endpoint_kind": self.endpoint_kind}
                if self.identity_version >= 3
                else {}
            ),
            "protection_rule_graph": (
                None
                if self.protection_rule_graph is None
                else dict(self.protection_rule_graph)
            ),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ProtectingGroupStrategyIdentity":
        return cls(
            identity_version=int(value["identity_version"]),
            lookup_key=str(value.get("lookup_key") or ""),
            pg_type=str(value["pg_type"]),
            protected_functional_group=str(value["protected_functional_group"]),
            source_type=str(value["source_type"]),
            endpoint_kind=value.get("endpoint_kind", "deprotection"),
            deprotection_rule_graph=value["deprotection_rule_graph"],
            protection_rule_graph=value.get("protection_rule_graph"),
        )


@dataclass(frozen=True)
class PGStrategyIntervalStepIdentity:
    """Exact map-independent identity of one reaction inside a PG interval."""

    rule_graph: Mapping[str, Any]
    lookup_key: str = ""
    identity_version: int = PG_STRATEGY_INTERVAL_IDENTITY_VERSION

    def __post_init__(self) -> None:
        if int(self.identity_version) != PG_STRATEGY_INTERVAL_IDENTITY_VERSION:
            raise ValueError("unsupported PG interval-step identity version")
        graph = _json_object(self.rule_graph, label="rule_graph")
        signature = graph_coarse_signature(graph)
        expected = _digest(
            "pg_strategy_step_i_",
            {"identity_version": self.identity_version, "graph_signature": signature},
        )
        if self.lookup_key and str(self.lookup_key) != expected:
            raise ValueError("PG interval-step lookup_key disagrees with its identity")
        object.__setattr__(self, "rule_graph", graph)
        object.__setattr__(self, "lookup_key", expected)
        object.__setattr__(
            self, "identity_version", PG_STRATEGY_INTERVAL_IDENTITY_VERSION
        )

    @classmethod
    def from_rule(cls, rule_smarts: str) -> "PGStrategyIntervalStepIdentity":
        return cls(rule_graph=rule_smarts_to_graph(rule_smarts))

    def equivalent_to(self, other: object) -> bool:
        return (
            isinstance(other, PGStrategyIntervalStepIdentity)
            and self.identity_version == other.identity_version
            and self.lookup_key == other.lookup_key
            and labelled_graphs_are_isomorphic(self.rule_graph, other.rule_graph)
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "identity_version": self.identity_version,
            "lookup_key": self.lookup_key,
            "rule_graph": dict(self.rule_graph),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PGStrategyIntervalStepIdentity":
        return cls(
            identity_version=int(value["identity_version"]),
            lookup_key=str(value.get("lookup_key") or ""),
            rule_graph=value["rule_graph"],
        )


@dataclass(frozen=True)
class PGStrategyIntervalSequenceIdentity:
    """Exact ordered sequence of structural rules inside one PG interval."""

    rule_graphs: tuple[Mapping[str, Any], ...]
    lookup_key: str = ""
    identity_version: int = PG_STRATEGY_INTERVAL_IDENTITY_VERSION

    def __post_init__(self) -> None:
        if int(self.identity_version) != PG_STRATEGY_INTERVAL_IDENTITY_VERSION:
            raise ValueError("unsupported PG interval-sequence identity version")
        graphs = tuple(
            _json_object(graph, label="rule_graph") for graph in self.rule_graphs
        )
        signatures = [graph_coarse_signature(graph) for graph in graphs]
        expected = _digest(
            "pg_strategy_seq_i_",
            {
                "identity_version": self.identity_version,
                "ordered_graph_signatures": signatures,
            },
        )
        if self.lookup_key and str(self.lookup_key) != expected:
            raise ValueError(
                "PG interval-sequence lookup_key disagrees with its identity"
            )
        object.__setattr__(self, "rule_graphs", graphs)
        object.__setattr__(self, "lookup_key", expected)
        object.__setattr__(
            self, "identity_version", PG_STRATEGY_INTERVAL_IDENTITY_VERSION
        )

    @classmethod
    def from_rules(cls, rules: Sequence[str]) -> "PGStrategyIntervalSequenceIdentity":
        return cls(rule_graphs=tuple(rule_smarts_to_graph(rule) for rule in rules))

    def equivalent_to(self, other: object) -> bool:
        return (
            isinstance(other, PGStrategyIntervalSequenceIdentity)
            and self.identity_version == other.identity_version
            and self.lookup_key == other.lookup_key
            and len(self.rule_graphs) == len(other.rule_graphs)
            and all(
                labelled_graphs_are_isomorphic(left, right)
                for left, right in zip(self.rule_graphs, other.rule_graphs)
            )
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "identity_version": self.identity_version,
            "lookup_key": self.lookup_key,
            "rule_graphs": [dict(graph) for graph in self.rule_graphs],
        }

    @classmethod
    def from_dict(
        cls, value: Mapping[str, Any]
    ) -> "PGStrategyIntervalSequenceIdentity":
        return cls(
            identity_version=int(value["identity_version"]),
            lookup_key=str(value.get("lookup_key") or ""),
            rule_graphs=tuple(value.get("rule_graphs") or ()),
        )


@dataclass(frozen=True)
class PGStrategyIntervalStepOccurrence:
    """One exact intervening reaction with PG-context and class provenance."""

    occurrence_id: str
    event_occurrence_id: str
    route: ReferenceRouteKey
    focal_pg_type: str
    active_pg_types: tuple[str, ...]
    step_index: int
    reaction_node_path: tuple[int, ...]
    reaction_smiles: str
    rule_smarts: str
    identity: PGStrategyIntervalStepIdentity
    classification: Mapping[str, Any] = field(default_factory=dict)
    schema_version: int = PG_STRATEGY_INTERVAL_OCCURRENCE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if int(self.schema_version) != PG_STRATEGY_INTERVAL_OCCURRENCE_SCHEMA_VERSION:
            raise ValueError("unsupported PG interval-step occurrence schema")
        if not self.occurrence_id or not self.event_occurrence_id:
            raise ValueError("PG interval-step occurrence requires stable IDs")
        if not isinstance(self.route, ReferenceRouteKey):
            raise TypeError("route must be a ReferenceRouteKey")
        if int(self.step_index) < 0:
            raise ValueError("PG interval step_index must be non-negative")
        if not self.focal_pg_type or self.focal_pg_type not in self.active_pg_types:
            raise ValueError("active PG context must contain the focal PG")
        object.__setattr__(self, "step_index", int(self.step_index))
        object.__setattr__(self, "reaction_node_path", _path(self.reaction_node_path))
        object.__setattr__(
            self, "active_pg_types", tuple(sorted(map(str, self.active_pg_types)))
        )
        object.__setattr__(
            self,
            "classification",
            _json_object(self.classification, label="classification"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "occurrence_id": self.occurrence_id,
            "event_occurrence_id": self.event_occurrence_id,
            "route": self.route.to_dict(),
            "focal_pg_type": self.focal_pg_type,
            "active_pg_types": list(self.active_pg_types),
            "step_index": self.step_index,
            "reaction_node_path": list(self.reaction_node_path),
            "reaction_smiles": self.reaction_smiles,
            "rule_smarts": self.rule_smarts,
            "identity": self.identity.to_dict(),
            "classification": dict(self.classification),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PGStrategyIntervalStepOccurrence":
        return cls(
            schema_version=int(value["schema_version"]),
            occurrence_id=str(value["occurrence_id"]),
            event_occurrence_id=str(value["event_occurrence_id"]),
            route=ReferenceRouteKey.from_dict(value["route"]),
            focal_pg_type=str(value["focal_pg_type"]),
            active_pg_types=tuple(value.get("active_pg_types") or ()),
            step_index=int(value["step_index"]),
            reaction_node_path=_path(value["reaction_node_path"]),
            reaction_smiles=str(value["reaction_smiles"]),
            rule_smarts=str(value["rule_smarts"]),
            identity=PGStrategyIntervalStepIdentity.from_dict(value["identity"]),
            classification=value.get("classification") or {},
        )


@dataclass(frozen=True)
class PGStrategyIntervalSequenceOccurrence:
    """One ordered complete interval linked to its exact step occurrences."""

    occurrence_id: str
    event_occurrence_id: str
    route: ReferenceRouteKey
    focal_pg_type: str
    active_pg_contexts: tuple[tuple[str, ...], ...]
    step_occurrence_ids: tuple[str, ...]
    identity: PGStrategyIntervalSequenceIdentity
    schema_version: int = PG_STRATEGY_INTERVAL_OCCURRENCE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if int(self.schema_version) != PG_STRATEGY_INTERVAL_OCCURRENCE_SCHEMA_VERSION:
            raise ValueError("unsupported PG interval-sequence occurrence schema")
        if not self.occurrence_id or not self.event_occurrence_id:
            raise ValueError("PG interval-sequence occurrence requires stable IDs")
        if not isinstance(self.route, ReferenceRouteKey):
            raise TypeError("route must be a ReferenceRouteKey")
        if not self.focal_pg_type:
            raise ValueError("PG interval sequence requires a focal PG")
        if len(self.active_pg_contexts) != len(self.step_occurrence_ids):
            raise ValueError("PG interval sequence context and step lengths differ")
        if len(self.identity.rule_graphs) != len(self.step_occurrence_ids):
            raise ValueError("PG interval sequence identity and step lengths differ")
        normalized_contexts = tuple(
            tuple(sorted(map(str, context))) for context in self.active_pg_contexts
        )
        if any(self.focal_pg_type not in context for context in normalized_contexts):
            raise ValueError(
                "every interval-sequence context must contain the focal PG"
            )
        if len(set(self.step_occurrence_ids)) != len(self.step_occurrence_ids):
            raise ValueError("PG interval sequence contains duplicate step IDs")
        object.__setattr__(self, "active_pg_contexts", normalized_contexts)
        object.__setattr__(
            self, "step_occurrence_ids", tuple(map(str, self.step_occurrence_ids))
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "occurrence_id": self.occurrence_id,
            "event_occurrence_id": self.event_occurrence_id,
            "route": self.route.to_dict(),
            "focal_pg_type": self.focal_pg_type,
            "active_pg_contexts": [list(item) for item in self.active_pg_contexts],
            "step_occurrence_ids": list(self.step_occurrence_ids),
            "identity": self.identity.to_dict(),
        }

    @classmethod
    def from_dict(
        cls, value: Mapping[str, Any]
    ) -> "PGStrategyIntervalSequenceOccurrence":
        return cls(
            schema_version=int(value["schema_version"]),
            occurrence_id=str(value["occurrence_id"]),
            event_occurrence_id=str(value["event_occurrence_id"]),
            route=ReferenceRouteKey.from_dict(value["route"]),
            focal_pg_type=str(value["focal_pg_type"]),
            active_pg_contexts=tuple(
                tuple(context) for context in value.get("active_pg_contexts") or ()
            ),
            step_occurrence_ids=tuple(value.get("step_occurrence_ids") or ()),
            identity=PGStrategyIntervalSequenceIdentity.from_dict(value["identity"]),
        )


@dataclass(frozen=True)
class ProtectingGroupStrategyOccurrence:
    """A deprotection-ended lifecycle or target-retained candidate in a route."""

    occurrence_id: str
    native_event_id: str
    route: ReferenceRouteKey
    identity: ProtectingGroupStrategyIdentity
    pg_type: str
    protected_functional_group: str
    source_type: str
    protection_reaction_node_path: tuple[int, ...]
    deprotection_reaction_node_path: tuple[int, ...]
    stock_molecule_node_path: tuple[int, ...]
    interval_reaction_node_paths: tuple[tuple[int, ...], ...]
    protected_molecule_node_paths: tuple[tuple[int, ...], ...]
    protection_reaction_smiles: str
    deprotection_reaction_smiles: str
    protection_rule_smarts: str
    deprotection_rule_smarts: str
    protected_atom_ids: tuple[int, ...]
    lifetime_steps: int
    confidence: str
    multicenter_status: str
    selective_deprotection: bool
    source_fragment_atom_maps: tuple[int, ...] = ()
    interval_step_occurrence_ids: tuple[str, ...] = ()
    interval_sequence_occurrence_id: str = ""
    protection_center_atom_maps: tuple[int, ...] = ()
    deprotection_center_atom_maps: tuple[int, ...] = ()
    interval_center_atom_maps: tuple[tuple[int, ...], ...] = ()
    annotations: Mapping[str, Any] = field(default_factory=dict)
    schema_version: int = PG_STRATEGY_OCCURRENCE_SCHEMA_VERSION

    @property
    def terminus(self):
        if self.schema_version < 3:
            return "unavailable"
        return (
            "preserved" if self.identity.endpoint_kind == "target" else "not_preserved"
        )

    def __post_init__(self) -> None:
        schema_version = int(self.schema_version)
        if schema_version not in _SUPPORTED_PG_STRATEGY_OCCURRENCE_SCHEMAS:
            raise ValueError("unsupported PG strategy occurrence schema")
        if self.source_type == "protected_synthon" and schema_version < 2:
            raise ValueError("protected_synthon requires PG strategy occurrence v2")
        if not self.occurrence_id or not self.native_event_id:
            raise ValueError("PG strategy occurrence requires stable IDs")
        if not isinstance(self.route, ReferenceRouteKey):
            raise TypeError("route must be a ReferenceRouteKey")
        if self.identity.pg_type != self.pg_type:
            raise ValueError("PG occurrence type disagrees with its identity")
        if self.identity.protected_functional_group != self.protected_functional_group:
            raise ValueError(
                "PG occurrence functional group disagrees with its identity"
            )
        if self.identity.source_type != self.source_type:
            raise ValueError("PG occurrence source disagrees with its identity")
        if (
            self.source_type in {"introduced", "protected_synthon"}
            and not self.protection_reaction_node_path
        ):
            raise ValueError(
                f"{self.source_type} PG occurrence requires a source-endpoint path"
            )
        if (
            self.source_type in {"stock", "protected_synthon"}
            and not self.stock_molecule_node_path
            and self.identity.endpoint_kind != "target"
        ):
            raise ValueError(
                f"{self.source_type} PG occurrence requires a stock molecule path"
            )
        source_fragment = tuple(sorted(map(int, self.source_fragment_atom_maps)))
        if self.source_type == "protected_synthon":
            if not source_fragment:
                raise ValueError(
                    "protected_synthon occurrence requires mapped source-fragment evidence"
                )
            if not set(self.protected_atom_ids) <= set(source_fragment):
                raise ValueError(
                    "protected_synthon source fragment must contain the protected center"
                )
        elif source_fragment:
            raise ValueError(
                "source_fragment_atom_maps are exclusive to protected_synthon"
            )
        if self.identity.endpoint_kind == "target":
            if schema_version < 3:
                raise ValueError("target endpoint requires occurrence v3")
            if (
                self.deprotection_reaction_node_path
                or self.deprotection_reaction_smiles
                or self.deprotection_rule_smarts
            ):
                raise ValueError(
                    "target occurrence cannot contain a deprotection endpoint"
                )
        if self.source_type == "unknown" and self.interval_reaction_node_paths:
            raise ValueError("unresolved target trace cannot contain lifespan evidence")
        if int(self.lifetime_steps) < 0:
            raise ValueError("PG lifetime cannot be negative")
        if int(self.lifetime_steps) != len(self.interval_reaction_node_paths):
            raise ValueError("PG lifetime disagrees with its interval paths")
        if len(self.interval_step_occurrence_ids) != len(
            self.interval_reaction_node_paths
        ):
            raise ValueError("PG interval paths and step occurrence links differ")
        if not self.interval_sequence_occurrence_id:
            raise ValueError(
                "PG occurrence requires its complete interval sequence link"
            )
        object.__setattr__(
            self,
            "protection_reaction_node_path",
            _path(self.protection_reaction_node_path),
        )
        object.__setattr__(
            self,
            "deprotection_reaction_node_path",
            _path(self.deprotection_reaction_node_path),
        )
        object.__setattr__(
            self, "stock_molecule_node_path", _path(self.stock_molecule_node_path)
        )
        object.__setattr__(
            self,
            "interval_reaction_node_paths",
            tuple(_path(path) for path in self.interval_reaction_node_paths),
        )
        object.__setattr__(
            self,
            "protected_molecule_node_paths",
            tuple(_path(path) for path in self.protected_molecule_node_paths),
        )
        object.__setattr__(
            self, "protected_atom_ids", tuple(sorted(map(int, self.protected_atom_ids)))
        )
        object.__setattr__(self, "source_fragment_atom_maps", source_fragment)
        object.__setattr__(self, "schema_version", schema_version)
        object.__setattr__(
            self,
            "protection_center_atom_maps",
            tuple(sorted(map(int, self.protection_center_atom_maps))),
        )
        object.__setattr__(
            self,
            "deprotection_center_atom_maps",
            tuple(sorted(map(int, self.deprotection_center_atom_maps))),
        )
        interval_centers = tuple(
            tuple(sorted(map(int, values))) for values in self.interval_center_atom_maps
        )
        if len(interval_centers) != len(self.interval_reaction_node_paths):
            raise ValueError("PG interval paths and reaction-center evidence differ")
        object.__setattr__(self, "interval_center_atom_maps", interval_centers)
        object.__setattr__(self, "lifetime_steps", int(self.lifetime_steps))
        object.__setattr__(
            self, "annotations", _json_object(self.annotations, label="annotations")
        )

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "schema_version": self.schema_version,
            "occurrence_id": self.occurrence_id,
            "native_event_id": self.native_event_id,
            "route": self.route.to_dict(),
            "identity": self.identity.to_dict(),
            "pg_type": self.pg_type,
            "protected_functional_group": self.protected_functional_group,
            "source_type": self.source_type,
            "protection_reaction_node_path": list(self.protection_reaction_node_path),
            "deprotection_reaction_node_path": list(
                self.deprotection_reaction_node_path
            ),
            "stock_molecule_node_path": list(self.stock_molecule_node_path),
            "interval_reaction_node_paths": [
                list(path) for path in self.interval_reaction_node_paths
            ],
            "protected_molecule_node_paths": [
                list(path) for path in self.protected_molecule_node_paths
            ],
            "protection_reaction_smiles": self.protection_reaction_smiles,
            "deprotection_reaction_smiles": self.deprotection_reaction_smiles,
            "protection_rule_smarts": self.protection_rule_smarts,
            "deprotection_rule_smarts": self.deprotection_rule_smarts,
            "protected_atom_ids": list(self.protected_atom_ids),
            "lifetime_steps": self.lifetime_steps,
            "confidence": self.confidence,
            "multicenter_status": self.multicenter_status,
            "selective_deprotection": self.selective_deprotection,
            "interval_step_occurrence_ids": list(self.interval_step_occurrence_ids),
            "interval_sequence_occurrence_id": self.interval_sequence_occurrence_id,
            "protection_center_atom_maps": list(self.protection_center_atom_maps),
            "deprotection_center_atom_maps": list(self.deprotection_center_atom_maps),
            "interval_center_atom_maps": [
                list(item) for item in self.interval_center_atom_maps
            ],
            "annotations": dict(self.annotations),
        }
        if self.schema_version >= 3:
            payload["pg_terminus"] = self.terminus
            payload["target_molecule_node_path"] = (
                [] if self.identity.endpoint_kind == "target" else None
            )
        if self.schema_version >= 2:
            payload["source_fragment_atom_maps"] = list(self.source_fragment_atom_maps)
        return payload

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ProtectingGroupStrategyOccurrence":
        return cls(
            schema_version=int(value["schema_version"]),
            occurrence_id=str(value["occurrence_id"]),
            native_event_id=str(value["native_event_id"]),
            route=ReferenceRouteKey.from_dict(value["route"]),
            identity=ProtectingGroupStrategyIdentity.from_dict(value["identity"]),
            pg_type=str(value["pg_type"]),
            protected_functional_group=str(value["protected_functional_group"]),
            source_type=str(value["source_type"]),
            protection_reaction_node_path=_path(
                value.get("protection_reaction_node_path") or ()
            ),
            deprotection_reaction_node_path=_path(
                value["deprotection_reaction_node_path"]
            ),
            stock_molecule_node_path=_path(value.get("stock_molecule_node_path") or ()),
            interval_reaction_node_paths=tuple(
                _path(path) for path in value.get("interval_reaction_node_paths") or ()
            ),
            protected_molecule_node_paths=tuple(
                _path(path) for path in value.get("protected_molecule_node_paths") or ()
            ),
            protection_reaction_smiles=str(
                value.get("protection_reaction_smiles") or ""
            ),
            deprotection_reaction_smiles=str(value["deprotection_reaction_smiles"]),
            protection_rule_smarts=str(value.get("protection_rule_smarts") or ""),
            deprotection_rule_smarts=str(value["deprotection_rule_smarts"]),
            protected_atom_ids=tuple(value.get("protected_atom_ids") or ()),
            source_fragment_atom_maps=tuple(
                value.get("source_fragment_atom_maps") or ()
            ),
            lifetime_steps=int(value["lifetime_steps"]),
            confidence=str(value.get("confidence") or ""),
            multicenter_status=str(value.get("multicenter_status") or ""),
            selective_deprotection=bool(value.get("selective_deprotection", False)),
            interval_step_occurrence_ids=tuple(
                value.get("interval_step_occurrence_ids") or ()
            ),
            interval_sequence_occurrence_id=str(
                value.get("interval_sequence_occurrence_id") or ""
            ),
            protection_center_atom_maps=tuple(
                value.get("protection_center_atom_maps") or ()
            ),
            deprotection_center_atom_maps=tuple(
                value.get("deprotection_center_atom_maps") or ()
            ),
            interval_center_atom_maps=tuple(
                tuple(item) for item in value.get("interval_center_atom_maps") or ()
            ),
            annotations=value.get("annotations") or {},
        )


@dataclass(frozen=True)
class ProcessedRoutePGStrategies:
    """Resolved events, interval evidence, and retained trace diagnostics for a route."""

    route: ReferenceRouteKey
    events: tuple[ProtectingGroupStrategyOccurrence, ...]
    interval_steps: tuple[PGStrategyIntervalStepOccurrence, ...]
    interval_sequences: tuple[PGStrategyIntervalSequenceOccurrence, ...]
    diagnostics: tuple[Mapping[str, Any], ...] = ()

    @property
    def complete(self) -> bool:
        return not self.diagnostics


def stable_pg_strategy_occurrence_id(
    route: ReferenceRouteKey,
    native_event_id: str,
) -> str:
    return _digest(
        "pg_strategy_o_",
        {
            "schema_version": PG_STRATEGY_OCCURRENCE_SCHEMA_VERSION,
            "route": route.to_dict(),
            "native_event_id": str(native_event_id),
        },
    )


def stable_pg_strategy_step_occurrence_id(
    event_occurrence_id: str,
    step_index: int,
    reaction_node_path: Sequence[int],
) -> str:
    return _digest(
        "pg_strategy_step_o_",
        {
            "schema_version": PG_STRATEGY_INTERVAL_OCCURRENCE_SCHEMA_VERSION,
            "event_occurrence_id": str(event_occurrence_id),
            "step_index": int(step_index),
            "reaction_node_path": list(map(int, reaction_node_path)),
        },
    )


def stable_pg_strategy_sequence_occurrence_id(event_occurrence_id: str) -> str:
    return _digest(
        "pg_strategy_seq_o_",
        {
            "schema_version": PG_STRATEGY_INTERVAL_OCCURRENCE_SCHEMA_VERSION,
            "event_occurrence_id": str(event_occurrence_id),
        },
    )


__all__ = [
    "PG_STRATEGY_IDENTITY_VERSION",
    "PG_STRATEGY_SOURCE_TYPES",
    "PG_STRATEGY_INTERVAL_IDENTITY_VERSION",
    "PG_STRATEGY_INTERVAL_OCCURRENCE_SCHEMA_VERSION",
    "PG_STRATEGY_OCCURRENCE_SCHEMA_VERSION",
    "PGStrategyIntervalSequenceIdentity",
    "PGStrategyIntervalSequenceOccurrence",
    "PGStrategyIntervalStepIdentity",
    "PGStrategyIntervalStepOccurrence",
    "ProcessedRoutePGStrategies",
    "ProtectingGroupStrategyIdentity",
    "ProtectingGroupStrategyOccurrence",
    "stable_pg_strategy_occurrence_id",
    "stable_pg_strategy_sequence_occurrence_id",
    "stable_pg_strategy_step_occurrence_id",
]
