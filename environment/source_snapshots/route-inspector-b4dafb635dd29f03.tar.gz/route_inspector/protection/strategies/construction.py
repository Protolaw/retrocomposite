"""Bounded standalone PG extraction, classification, and atomic publication."""

from __future__ import annotations

import csv
import json
import sqlite3
import tempfile
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from pathlib import Path

from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.infrastructure.runtime import (
    normalize_n_cpu,
    setup_runtime_cache_dirs,
)
from route_inspector.protection.strategies.catalog import ReferencePGStrategyLibrary
from route_inspector.protection.strategies.staging import (
    _classify_staged_pg,
    _pg_record,
    _processed_pg_from_record,
)
from route_inspector.reference_library.storage.artifacts import (
    _publish_directory_no_replace,
)
from route_inspector.routes.io import iter_route_json_file
from route_inspector.rules.graph import canonical_json


@dataclass(frozen=True)
class PGStrategyPublicationResult:
    output_path: Path
    manifest: object


def _temporary(output_dir):
    destination = Path(output_dir).expanduser()
    if destination.exists():
        raise FileExistsError(f"output already exists: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    return destination, Path(
        tempfile.mkdtemp(
            prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent
        )
    )


def _stage_inputs(
    connection, routes_json, limit=None, route_id=None, *, route_ids=None, resume=False
):
    if limit is not None and limit < 0:
        raise ValueError("route limit must be nonnegative")
    if not resume:
        connection.executescript(
            "CREATE TABLE route_inputs(ordinal INTEGER PRIMARY KEY, route_id TEXT UNIQUE, sort_class INTEGER, sort_number INTEGER, sort_text TEXT, route_json TEXT); CREATE TABLE route_results(input_ordinal INTEGER PRIMARY KEY, route_id TEXT UNIQUE, pg_json TEXT);"
        )
        selected = None if route_ids is None else {str(key) for key in route_ids}
        seen = set()
        for ordinal, (key, route) in enumerate(iter_route_json_file(routes_json)):
            key = str(key)
            if selected is not None and key not in selected:
                continue
            seen.add(key)
            connection.execute(
                "INSERT INTO route_inputs VALUES (?, ?, ?, ?, ?, ?)",
                (
                    ordinal,
                    key,
                    0 if key.isdigit() else 1,
                    int(key) if key.isdigit() else None,
                    key,
                    canonical_json(route),
                ),
            )
        if selected is not None and selected - seen:
            raise ValueError(
                f"selected PG route IDs are absent from source: {sorted(selected - seen)}"
            )
        connection.commit()
    sql = "SELECT ordinal, route_id, route_json FROM route_inputs"
    params = []
    if route_id is not None:
        sql += " WHERE route_id = ?"
        params.append(str(route_id))
    sql += " ORDER BY sort_class, sort_number, sort_text, ordinal"
    if limit is not None:
        sql += " LIMIT ?"
        params.append(limit)
    return (
        (int(r[0]), str(r[1]), json.loads(r[2]))
        for r in connection.execute(
            "SELECT * FROM ("
            + sql
            + ") WHERE ordinal NOT IN (SELECT input_ordinal FROM route_results)",
            params,
        )
    )


_WORKER = None


def _init_worker(processor, dataset, source):
    global _WORKER
    setup_runtime_cache_dirs()
    _WORKER = (processor, dataset, source)


def _process(item):
    ordinal, route_id, route = item
    processor, dataset, source = _WORKER
    return ordinal, processor.process_route(
        route_id, route, dataset_id=dataset, source_identity=source
    )


def _extract(connection, items, processor, dataset, source, n_cpu, progress_interval):
    workers = normalize_n_cpu(n_cpu)
    started = time.monotonic()
    count = 0

    def store(result):
        nonlocal count
        ordinal, processed = result
        fatal = [
            d
            for d in processed.diagnostics
            if d.get("stage") == "analyze_route_protection"
        ]
        if fatal:
            raise RuntimeError(
                f"PG tracing infrastructure failed for route {processed.route.route_id}: {fatal[0]['message']}"
            )
        connection.execute(
            "INSERT INTO route_results VALUES (?, ?, ?)",
            (ordinal, processed.route.route_id, _pg_record(processed)),
        )
        count += 1
        if progress_interval and count % progress_interval == 0:
            print(
                f"[pg-routes] {count} routes processed in {time.monotonic() - started:.1f}s"
            )
        connection.commit()
        if count % 25 == 0:
            from route_inspector.infrastructure.build_workspace import (
                check_disk_headroom,
            )

            check_disk_headroom(
                Path(connection.execute("PRAGMA database_list").fetchone()[2]).parent
            )

    if workers == 1:
        for ordinal, key, route in items:
            store(
                (
                    ordinal,
                    processor.process_route(
                        key, route, dataset_id=dataset, source_identity=source
                    ),
                )
            )
    else:
        from route_inspector.infrastructure.worker_spool import results

        with ProcessPoolExecutor(
            max_workers=workers,
            initializer=_init_worker,
            initargs=(processor, dataset, source),
        ) as executor:
            database = Path(connection.execute("PRAGMA database_list").fetchone()[2])
            for result in results(
                executor,
                _process,
                items,
                database.parent / "worker-results",
                workers=workers,
            ):
                store(result)
    return count


def _results(connection):
    for row in connection.execute(
        "SELECT pg_json FROM route_results ORDER BY input_ordinal"
    ):
        yield _processed_pg_from_record(json.loads(row[0]))


def _errors(path, diagnostics):
    with Path(path).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=(
                "dataset_id",
                "route_id",
                "event_id",
                "stage",
                "error_type",
                "message",
            ),
            delimiter="\t",
        )
        writer.writeheader()
        for d in diagnostics:
            writer.writerow(
                {
                    "dataset_id": d.get("route", {}).get("dataset_id", ""),
                    "route_id": d.get("route", {}).get("route_id", ""),
                    **{
                        k: d.get(k, "")
                        for k in ("event_id", "stage", "error_type", "message")
                    },
                }
            )


def build_pg_strategy_library(
    routes_json,
    output_dir,
    processor,
    provider,
    *,
    reference_id,
    source_identity=None,
    n_cpu=1,
    limit=None,
    progress_interval=250,
    include_sqlite=True,
    worker_chunksize=100,
    classifier_metadata=None,
    route_ids=None,
    work_dir=None,
    resume=False,
    memory_budget_mb=512,
    reuse_library=None,
    reuse_route_ids=(),
):
    """Build, fully verify, and atomically publish a standalone PG vocabulary.

    ``provider=None`` explicitly omits optional reaction-class annotations.
    ``route_ids`` selects original source IDs without renumbering or changing
    the full source fingerprint. Every selected route still passes validation.
    """
    setup_runtime_cache_dirs()
    from route_inspector.infrastructure.build_workspace import BuildWorkspace

    reused_routes = set(map(str, reuse_route_ids))
    digest = sha256_file(Path(routes_json))
    job = BuildWorkspace(
        output_dir,
        work_dir=work_dir,
        resume=resume,
        memory_budget_mb=memory_budget_mb,
        fingerprint=dict(
            builder="pg-v5",
            source=digest,
            profile=processor.profile,
            reference_id=reference_id,
            source_identity=source_identity,
            classifier=classifier_metadata or {},
            provider=None if provider is None else provider.provider_name,
            limit=limit,
            route_ids=None if route_ids is None else sorted(str(k) for k in route_ids),
            include_sqlite=include_sqlite,
            **(
                {
                    "reuse_library_id": reuse_library.library_id,
                    "reuse_route_ids": sorted(reuse_route_ids),
                }
                if reuse_library
                else {}
            ),
        ),
    )
    job.__enter__()
    destination, temporary = job.output, job.publication
    try:
        source = source_identity or f"sha256:{digest}"
        staging = job.root / "construction.sqlite"
        if not job.done("inputs"):
            staging.unlink(missing_ok=True)
        with sqlite3.connect(staging) as connection:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA journal_mode=TRUNCATE")
            connection.execute("PRAGMA cache_size=-16384")
            items = _stage_inputs(
                connection,
                routes_json,
                limit,
                route_ids=route_ids,
                resume=job.done("inputs"),
            )
            job.checkpoint("inputs")
            _extract(
                connection,
                (item for item in items if item[1] not in reused_routes),
                processor,
                reference_id,
                source,
                n_cpu,
                progress_interval,
            )
            job.checkpoint("extracted")
            if not job.done("classified"):
                _classify_staged_pg(
                    connection,
                    provider,
                    n_cpu=n_cpu,
                    worker_chunksize=worker_chunksize,
                    progress_interval=progress_interval,
                )
                job.checkpoint("classified")
            if reuse_library is not None and not job.done("reused"):
                from route_inspector.protection.strategies.reuse import seed_routes

                if processor.profile != {
                    k: v
                    for k, v in reuse_library.manifest.processing_profile.items()
                    if k != "classifier"
                }:
                    raise ValueError("reused PG processing profile differs")
                seed_routes(connection, reuse_library, reuse_route_ids)
                job.checkpoint("reused")
            count = connection.execute("SELECT COUNT(*) FROM route_results").fetchone()[
                0
            ]
            corpus = {
                "dataset_id": reference_id,
                "source_identity": source,
                "input_sha256": digest,
                "route_count": count,
                "route_ids": [
                    r[0]
                    for r in connection.execute(
                        "SELECT route_id FROM route_results ORDER BY route_id"
                    )
                ],
            }
            classifier = (
                {
                    "provider": "none",
                    "provider_version": "",
                    "taxonomy": "none",
                    "status": "not_requested",
                }
                if provider is None
                else {
                    **(classifier_metadata or {}),
                    "provider": provider.provider_name,
                    "provider_version": provider.provider_version,
                    "taxonomy": provider.taxonomy_id,
                }
            )
            if (
                reuse_library is not None
                and route_ids is not None
                and set(map(str, route_ids)) <= reused_routes
            ):
                classifier = dict(
                    reuse_library.manifest.processing_profile["classifier"]
                )
            from route_inspector.protection.strategies.relational import (
                IncompletePGPublication,
                write_relational,
            )

            publication_options = dict(
                processing_profile={**processor.profile, "classifier": classifier},
                reference_corpora=(corpus,),
                include_sqlite=include_sqlite,
            )
            try:
                write_relational(
                    _results(connection),
                    temporary,
                    resume=(temporary / "catalog.sqlite").exists(),
                    **publication_options,
                )
            except IncompletePGPublication:
                # Keep the damaged catalog as evidence outside the publication.
                # Recreate serialization from the already classified records.
                (temporary / "catalog.sqlite").rename(
                    job.root / f"incomplete-catalog-{time.time_ns()}.sqlite"
                )
                write_relational(_results(connection), temporary, **publication_options)
        job.checkpoint("serialized")
        job.check_space()
        manifest = ReferencePGStrategyLibrary.verify(temporary)
        if sha256_file(Path(routes_json)) != digest:
            raise ValueError("PG source changed during construction")
        job.checkpoint("verified")
        _publish_directory_no_replace(temporary, destination)
        job.checkpoint("published")
        return PGStrategyPublicationResult(destination, manifest)
    finally:
        job.__exit__(None, None, None)


def repack_pg_strategy_library(
    library_path, output_dir, *, work_dir=None, resume=False, memory_budget_mb=512
):
    """Publish normalized storage from existing evidence without chemistry extraction."""
    from route_inspector.infrastructure.build_workspace import BuildWorkspace
    from route_inspector.protection.strategies.normalized_verify import processed_routes
    from route_inspector.protection.strategies.relational import write_relational

    with ReferencePGStrategyLibrary.load(library_path, verification="full") as source:
        if source.manifest.library_format_version < 4:
            raise ValueError(
                "PG repacking currently requires graph-normalized format 4 or 5"
            )
        with BuildWorkspace(
            output_dir,
            work_dir=work_dir,
            resume=resume,
            memory_budget_mb=memory_budget_mb,
            fingerprint=dict(
                builder="pg-repack-v5",
                library_id=source.library_id,
                artifacts=dict(source.manifest.artifacts),
            ),
        ) as job:
            manifest = write_relational(
                processed_routes(
                    source._connection,
                    source._normalized_graphs,
                    source.manifest.reference_corpora,
                ),
                job.publication,
                processing_profile=source.manifest.processing_profile,
                reference_corpora=source.manifest.reference_corpora,
                resume=(job.publication / "catalog.sqlite").exists(),
            )
            if manifest.statistics != source.manifest.statistics:
                raise ValueError("PG repack changed scientific counts")
            job.checkpoint("serialized")
            verified = ReferencePGStrategyLibrary.verify(job.publication)
            job.checkpoint("verified")
            _publish_directory_no_replace(job.publication, job.output)
            job.checkpoint("published")
            return PGStrategyPublicationResult(job.output, verified)
