"""Format-4 graph references and bounded reconstruction of PG windows.

Graph keys identify exact serialized representations. Isomorphic representations
remain available separately; scientific families are established by exact iso.
"""

from __future__ import annotations

import hashlib
import json

from route_inspector.infrastructure.auditing import audit_remember
from route_inspector.infrastructure.build_workspace import ByteMemo
from route_inspector.rules.graph import (
    canonical_json,
    graph_coarse_signature,
    labelled_graphs_are_isomorphic,
)

GRAPH_PATH = "rules/graphs.jsonl"
GRAPH_KEYS = {"rule_graph", "protection_rule_graph", "deprotection_rule_graph"}


class GraphStore:
    """SQLite-backed graph interning with fixed-size read caches."""

    def __init__(self, connection):
        self.db = connection
        from pathlib import Path

        path = connection.execute("PRAGMA database_list").fetchone()[2]
        if path:
            stat = Path(path).stat()
            self.audit_namespace = (
                path,
                stat.st_dev,
                stat.st_ino,
                stat.st_size,
                stat.st_mtime_ns,
                stat.st_ctime_ns,
            )
        else:
            self.audit_namespace = id(connection)
        self.encoded = ByteMemo(self._encoded)
        self.graph = ByteMemo(self._graph)
        self.signature = ByteMemo(self._signature)
        self.family = ByteMemo(self._family, max_bytes=2 * 1024 * 1024)

    def _encoded(self, key):
        return audit_remember(
            "pg_graph", (self.audit_namespace, key), lambda: self._encoded_uncached(key)
        )

    def _encoded_uncached(self, key):
        row = self.db.execute(
            "SELECT graph_json FROM rule_graphs WHERE graph_id=?", (key,)
        ).fetchone()
        if row is None:
            raise ValueError(f"missing PG rule graph: {key}")
        value = str(row[0])
        if hashlib.sha256(value.encode()).hexdigest() != key:
            raise ValueError("PG rule graph key disagrees with its contents")
        return value

    def _graph(self, key):
        return json.loads(self.encoded(key))

    def _signature(self, key):
        return graph_coarse_signature(self.graph(key))

    def intern(self, graph):
        encoded = canonical_json(graph)
        key = hashlib.sha256(encoded.encode()).hexdigest()
        if (
            self.db.execute(
                "SELECT 1 FROM rule_graphs WHERE graph_id=?", (key,)
            ).fetchone()
            is None
        ):
            self.db.execute("INSERT INTO rule_graphs VALUES (?,?)", (key, encoded))
        if self.encoded(key) != encoded:
            raise ValueError("PG graph digest collision")
        return {"graph_ref": key}

    def pack(self, identity):
        result = dict(identity)
        for key in GRAPH_KEYS & result.keys():
            if result[key] is not None:
                result[key] = self.intern(result[key])
        if "rule_graphs" in result:
            result["rule_graphs"] = [self.intern(g) for g in result["rule_graphs"]]
        return result

    def unpack(self, identity):
        result = dict(identity)

        def resolve(ref):
            if not isinstance(ref, dict) or set(ref) != {"graph_ref"}:
                raise ValueError("invalid normalized PG graph reference")
            return self.graph(ref["graph_ref"])

        for key in GRAPH_KEYS & result.keys():
            if result[key] is not None:
                result[key] = resolve(result[key])
        if "rule_graphs" in result:
            result["rule_graphs"] = [resolve(g) for g in result["rule_graphs"]]
        return result

    def _family(self, key):
        """Use a coarse bucket only to locate exact-isomorphism candidates."""
        row = self.db.execute(
            "SELECT family FROM graph_families WHERE graph_id=?", (key,)
        ).fetchone()
        if row is not None:
            return row[0]
        signature = canonical_json(self.signature(key))
        family = key
        for (candidate,) in self.db.execute(
            "SELECT DISTINCT family FROM graph_families WHERE signature=?", (signature,)
        ):
            if labelled_graphs_are_isomorphic(self.graph(key), self.graph(candidate)):
                family = candidate
                break
        self.db.execute(
            "INSERT INTO graph_families VALUES (?,?,?)", (key, signature, family)
        )
        return family

    def group_key(self, identity):
        value = dict(identity)
        value.pop("lookup_key", None)
        for key in GRAPH_KEYS & value.keys():
            if value[key] is not None:
                value[key] = self.family(value[key]["graph_ref"])
        if "rule_graphs" in value:
            value["rule_graphs"] = [
                self.family(ref["graph_ref"]) for ref in value["rule_graphs"]
            ]
        return hashlib.sha256(canonical_json(value).encode()).hexdigest()

    def sequence_identity(self, references, *, ngram=False):
        signatures = [self.signature(ref["graph_ref"]) for ref in references]
        digest = hashlib.sha256(
            canonical_json(
                {"identity_version": 1, "ordered_graph_signatures": signatures}
            ).encode()
        ).hexdigest()
        return {
            "identity_version": 1,
            "lookup_key": f"pg_strategy_{'ngram' if ngram else 'seq'}_i_{digest}",
            "rule_graphs": list(references),
        }

    def expanded_digest(self, value):
        """Hash canonical logical JSON without constructing its graph copies."""
        digest = hashlib.sha256()

        def emit(item, *, identity=False):
            if isinstance(item, dict):
                if identity and set(item) == {"graph_ref"}:
                    digest.update(self.encoded(item["graph_ref"]).encode())
                    return
                digest.update(b"{")
                for i, key in enumerate(sorted(item)):
                    if i:
                        digest.update(b",")
                    digest.update(canonical_json(key).encode() + b":")
                    emit(item[key], identity=identity or key == "identity")
                digest.update(b"}")
            elif isinstance(item, (tuple, list)):
                digest.update(b"[")
                for i, child in enumerate(item):
                    if i:
                        digest.update(b",")
                    emit(child, identity=identity)
                digest.update(b"]")
            else:
                digest.update(canonical_json(item).encode())

        emit(value)
        return digest.hexdigest()

    def clear(self):
        self.encoded.cache_clear()
        self.graph.cache_clear()
        self.signature.cache_clear()
        self.family.cache_clear()


def window_record(event, steps, start, length, graphs, *, ngram=True):
    """Reconstruct one exact ordered window from its retained source steps."""
    from route_inspector.protection.strategies.ngrams import ngram_occurrence_id

    if start < 0 or length < (2 if ngram else 0) or start + length > len(steps):
        raise ValueError("PG window lies outside its event lifespan")
    window = steps[start : start + length]
    result = {
        "schema_version": 1,
        "occurrence_id": ngram_occurrence_id(event["occurrence_id"], start, length)
        if ngram
        else event["interval_sequence_occurrence_id"],
        "event_occurrence_id": event["occurrence_id"],
        "route": event["route"],
        "focal_pg_type": event["pg_type"],
        "active_pg_contexts": [s["active_pg_types"] for s in window],
        "step_occurrence_ids": [s["occurrence_id"] for s in window],
        "identity": graphs.sequence_identity(
            [s["identity"]["rule_graph"] for s in window], ngram=ngram
        ),
    }
    if ngram:
        result.update(
            start_index=start,
            length=length,
            reaction_node_paths=[s["reaction_node_path"] for s in window],
        )
    return result


def read_occurrence(connection, graphs, kind, row):
    value = json.loads(row["occurrence_json"])
    if kind == "interval_ngram":
        if set(value) != {
            "occurrence_id",
            "event_occurrence_id",
            "start_index",
            "length",
        }:
            raise ValueError("invalid normalized PG window record")
        event_row = connection.execute(
            "SELECT occurrence_json FROM event_occurrences WHERE occurrence_id=?",
            (value["event_occurrence_id"],),
        ).fetchone()
        if event_row is None:
            raise ValueError("PG window refers to a missing event")
        event = json.loads(event_row[0])
        steps = []
        for key in event["interval_step_occurrence_ids"]:
            step_row = connection.execute(
                "SELECT occurrence_json FROM interval_step_occurrences WHERE occurrence_id=?",
                (key,),
            ).fetchone()
            if step_row is None:
                raise ValueError("PG window refers to a missing step")
            steps.append(json.loads(step_row[0]))
        restored = window_record(
            event, steps, value["start_index"], value["length"], graphs
        )
        if restored["occurrence_id"] != value["occurrence_id"]:
            raise ValueError("PG window ID disagrees with its positions")
        value = restored
    value["identity"] = graphs.unpack(value["identity"])
    return value
