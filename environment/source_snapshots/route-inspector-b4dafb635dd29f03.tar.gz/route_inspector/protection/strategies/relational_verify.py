"""Independent streaming PG validation without constructing another library."""

from __future__ import annotations

import json
import sqlite3
import tempfile
from itertools import zip_longest
from pathlib import Path

from route_inspector.infrastructure.auditing import audit_progress
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.protection.strategies import relational as storage
from route_inspector.protection.strategies.normalized import GraphStore, window_record
from route_inspector.protection.strategies.normalized_verify import (
    _check_portable_catalog,
    processed_routes,
)
from route_inspector.rules.graph import canonical_json


def rows(root, name):
    previous = None
    with (root / storage.PATHS[name]).open() as stream:
        for line in stream:
            value = json.loads(line)
            if line != canonical_json(value) + "\n":
                raise ValueError("noncanonical PG portable record")
            key = value.get(
                "occurrence_id",
                value.get("entry_id", value.get("graph_id", canonical_json(value))),
            )
            if previous is not None and (
                key < previous or (name != "diagnostics" and key == previous)
            ):
                raise ValueError("unordered or duplicate PG portable records")
            previous = key
            yield value


def import_portable(root, db):
    storage.schema(db)
    for value in rows(root, "rule_graphs"):
        db.execute(
            "INSERT INTO rule_graphs VALUES(?,?)",
            (value["graph_id"], canonical_json(value["graph"])),
        )
    for name, kind in (
        ("event_entries", "event"),
        ("interval_step_entries", "interval_step"),
        ("interval_sequence_entries", "interval_sequence"),
        ("ngram_entries", "interval_ngram"),
    ):
        for value in rows(root, name):
            if value["kind"] != kind:
                raise ValueError("wrong PG entry kind")
            db.execute(
                "INSERT INTO entries VALUES(?,?,?,?)",
                (value["entry_id"], kind, value["lookup_key"], canonical_json(value)),
            )
    for value in rows(root, "memberships"):
        if set(value) != set(storage.MEMBERS.split(",")):
            raise ValueError("invalid PG membership fields")
        db.execute(
            "INSERT INTO memberships(" + storage.MEMBERS + ") VALUES(?,?,?,?,?,?,?)",
            tuple(value[k] for k in storage.MEMBERS.split(",")),
        )
    for name, kind, table in (
        ("event_occurrences", "event", "event_occurrences"),
        ("interval_step_occurrences", "interval_step", "interval_step_occurrences"),
    ):
        for value in rows(root, name):
            member = db.execute(
                "SELECT entry_id,kind FROM memberships WHERE occurrence_id=?",
                (value["occurrence_id"],),
            ).fetchone()
            if member is None or member[1] != kind:
                raise ValueError("PG occurrence has no matching membership")
            fields = (value["occurrence_id"], member[0])
            if kind == "interval_step":
                fields += (
                    value["event_occurrence_id"],
                    value["focal_pg_type"],
                    canonical_json(value["active_pg_types"]),
                )
            fields += tuple(
                value["route"][k] for k in ("dataset_id", "source_identity", "route_id")
            ) + (canonical_json(value),)
            db.execute(
                f"INSERT INTO {table} VALUES({','.join('?' for _ in fields)})", fields
            )
    for i, value in enumerate(rows(root, "diagnostics")):
        db.execute("INSERT INTO diagnostics VALUES(?,?)", (i, canonical_json(value)))
    db.commit()


def validate_evidence(db, graphs, manifest):
    # These temporary indexes hold only keys and one identity per exact family.
    # They are independent of the builder's entry/group assignments.
    db.executescript("""
        CREATE TEMP TABLE graph_families(graph_id TEXT PRIMARY KEY,signature TEXT,family TEXT);
        CREATE INDEX temp.verify_graph_signature ON graph_families(signature);
        CREATE TEMP TABLE expected(oid TEXT PRIMARY KEY,kind TEXT,lookup_key TEXT,family TEXT);
        CREATE INDEX temp.expected_groups ON expected(kind,lookup_key,family,oid);
        CREATE TEMP TABLE expected_families(kind TEXT,lookup_key TEXT,family TEXT,
            representative TEXT,identity_json TEXT, PRIMARY KEY(kind,lookup_key,family));
    """)

    def check(kind, raw):
        oid = raw["occurrence_id"]
        identity = raw["identity"]
        family = graphs.group_key(identity)
        member = db.execute(
            "SELECT " + storage.MEMBERS + " FROM memberships WHERE occurrence_id=?",
            (oid,),
        ).fetchone()
        expected = (
            oid,
            kind,
            oid if kind == "event" else raw["event_occurrence_id"],
            raw.get("start_index", raw.get("step_index", 0)),
            raw.get(
                "length",
                1
                if kind == "interval_step"
                else len(raw.get("step_occurrence_ids", ())),
            ),
            graphs.expanded_digest(raw),
        )
        if member is None or (member[0], *tuple(member)[2:]) != expected:
            raise ValueError("PG membership disagrees with complete lifespan evidence")
        db.execute(
            "INSERT INTO expected VALUES(?,?,?,?)",
            (oid, kind, identity["lookup_key"], family),
        )
        db.execute(
            """INSERT INTO expected_families VALUES(?,?,?,?,?)
            ON CONFLICT(kind,lookup_key,family) DO UPDATE SET representative=excluded.representative,identity_json=excluded.identity_json
            WHERE excluded.representative<expected_families.representative""",
            (kind, identity["lookup_key"], family, oid, canonical_json(identity)),
        )

    audit_progress("Checking PG lifespans and windows", force=True)
    for completed, route in enumerate(
        processed_routes(db, graphs, manifest.reference_corpora), 1
    ):
        audit_progress("Checking PG lifespans and windows: routes", completed)
        steps = {s.occurrence_id: s for s in route.interval_steps}
        used = set()
        for event in route.events:
            value = event.to_dict()
            value["identity"] = graphs.pack(value["identity"])
            check("event", value)
            interval = []
            for i, key in enumerate(event.interval_step_occurrence_ids):
                step = steps.get(key)
                if (
                    step is None
                    or key in used
                    or step.event_occurrence_id != event.occurrence_id
                    or step.route != event.route
                    or step.focal_pg_type != event.pg_type
                    or step.step_index != i
                    or step.reaction_node_path != event.interval_reaction_node_paths[i]
                ):
                    raise ValueError("PG interval provenance disagrees with its event")
                used.add(key)
                raw = step.to_dict()
                raw["identity"] = graphs.pack(raw["identity"])
                check("interval_step", raw)
                interval.append(raw)
            if len(interval) != event.lifetime_steps:
                raise ValueError("PG lifespan disagrees with its interval")
            if event.interval_sequence_occurrence_id:
                check(
                    "interval_sequence",
                    window_record(
                        value, interval, 0, len(interval), graphs, ngram=False
                    ),
                )
            for length in range(2, len(interval) + 1):
                for start in range(len(interval) - length + 1):
                    check(
                        "interval_ngram",
                        window_record(value, interval, start, length, graphs),
                    )
        if used != set(steps):
            raise ValueError("orphan PG interval step")
        db.commit()
    if (
        db.execute("SELECT COUNT(*) FROM expected").fetchone()
        != db.execute("SELECT COUNT(*) FROM memberships").fetchone()
    ):
        raise ValueError("unexpected PG memberships outside complete lifespan evidence")
    entry_count = 0
    for kind, lookup in db.execute(
        "SELECT DISTINCT kind,lookup_key FROM expected_families ORDER BY kind,lookup_key"
    ):
        families = list(
            db.execute(
                "SELECT family,representative,identity_json FROM expected_families WHERE kind=? AND lookup_key=?",
                (kind, lookup),
            )
        )
        families.sort(key=lambda r: canonical_json(graphs.unpack(json.loads(r[2]))))
        for ordinal, (family, representative, identity) in enumerate(families):
            entry_id = f"{lookup}~{ordinal:04d}"
            row = db.execute(
                "SELECT entry_json FROM entries WHERE entry_id=?", (entry_id,)
            ).fetchone()
            if row is None:
                raise ValueError("missing exact PG family")
            count = db.execute(
                "SELECT COUNT(*) FROM expected WHERE kind=? AND lookup_key=? AND family=?",
                (kind, lookup, family),
            ).fetchone()[0]
            mismatches = db.execute(
                "SELECT COUNT(*) FROM expected x JOIN memberships m ON m.occurrence_id=x.oid WHERE x.kind=? AND x.lookup_key=? AND x.family=? AND m.entry_id!=?",
                (kind, lookup, family, entry_id),
            ).fetchone()[0]
            route_count = db.execute(
                "SELECT COUNT(*) FROM (SELECT DISTINCT e.dataset_id,e.source_identity,e.route_id FROM memberships m JOIN event_occurrences e ON e.occurrence_id=m.event_id WHERE m.entry_id=?)",
                (entry_id,),
            ).fetchone()[0]
            expected = dict(
                kind=kind,
                entry_id=entry_id,
                lookup_key=lookup,
                identity=json.loads(identity),
                representative_occurrence_id=representative,
                occurrence_count=count,
                route_count=route_count,
            )
            actual = json.loads(row[0])
            if manifest.library_format_version == 4:
                if actual != storage.expand_entry(db, expected):
                    raise ValueError("PG legacy support differs from provenance")
                actual = {
                    k: v
                    for k, v in actual.items()
                    if k not in {"support_records", "reference_routes"}
                }
            if mismatches or actual != expected:
                raise ValueError(
                    "PG entry identity or support counts disagree with provenance"
                )
            entry_count += 1
    if entry_count != db.execute("SELECT COUNT(*) FROM entries").fetchone()[0]:
        raise ValueError("orphan PG entry")
    if storage.statistics(db) != dict(manifest.statistics):
        raise ValueError("PG statistics disagree with evidence")


def check_navigation(db):
    storage.register_browse(db)
    if db.execute("PRAGMA user_version").fetchone() == (5,):
        # A changed payload expression can leave all scalar counts intact.
        # Check the derived views as well as their evidence below.
        with sqlite3.connect(":memory:") as expected_db:
            storage.schema(expected_db)
            storage.browse_schema(expected_db)
            for name, sql in expected_db.execute(
                "SELECT name,sql FROM sqlite_master WHERE type='view'"
            ):
                stored = db.execute(
                    "SELECT sql FROM sqlite_master WHERE type='view' AND name=?",
                    (name,),
                ).fetchone()
                if stored is None or " ".join(stored[0].split()) != " ".join(
                    sql.split()
                ):
                    raise ValueError("PG derived view disagrees with its schema")
    expected = db.execute("""SELECT occurrence_id,entry_id,json_extract(occurrence_json,'$.pg_type'),
        json_extract(occurrence_json,'$.source_type'),json_extract(occurrence_json,'$.identity.protected_functional_group'),route_id,
        CASE WHEN json_extract(occurrence_json,'$.identity.identity_version')<3 THEN 'unavailable'
        WHEN json_extract(occurrence_json,'$.identity.endpoint_kind')='target' THEN 'preserved' ELSE 'not_preserved' END
        FROM event_occurrences ORDER BY occurrence_id""")
    actual = db.execute("SELECT * FROM pg_browse_events ORDER BY id")
    if any(a != b for a, b in zip_longest(expected, actual)):
        raise ValueError("PG browse SQLite contents disagree with evidence")
    for view, columns, condition in (
        ("pg_browse_grams", "occurrence_id,event_id", "kind='interval_ngram'"),
        (
            "pg_browse_tactic_windows",
            "occurrence_id,event_id,entry_id,length",
            "kind IN ('interval_step','interval_ngram')",
        ),
    ):
        selected = "id,event" if view == "pg_browse_grams" else "id,event,entry,length"
        if any(
            a != b
            for a, b in zip_longest(
                db.execute(f"SELECT {selected} FROM {view} ORDER BY id"),
                db.execute(
                    f"SELECT {columns} FROM memberships WHERE {condition} ORDER BY occurrence_id"
                ),
            )
        ):
            raise ValueError("PG browse SQLite contents disagree with memberships")


def load_relational(cls, root, manifest, *, backend, verification):
    root = Path(root)
    required = set(storage.PATHS) - {"catalog"}
    if not required <= set(manifest.artifacts) <= set(storage.PATHS):
        raise ValueError("incomplete relational PG artifacts")
    full = (
        verification == "full"
        or backend == "jsonl"
        or "catalog" not in manifest.artifacts
    )
    for name, descriptor in manifest.artifacts.items():
        path = root / storage.PATHS[name]
        if (
            descriptor["path"] != storage.PATHS[name]
            or not path.is_file()
            or path.stat().st_size != descriptor["size_bytes"]
        ):
            raise ValueError(f"missing or invalid PG artifact: {name}")
        if full and sha256_file(path) != descriptor["sha256"]:
            raise ValueError(f"PG artifact hash mismatch: {name}")
    if (
        storage.publication_id(
            manifest.processing_profile,
            manifest.reference_corpora,
            manifest.statistics,
            manifest.artifacts,
        )
        != manifest.library_id
    ):
        raise ValueError("relational PG publication identity mismatch")
    if backend == "sqlite" and "catalog" not in manifest.artifacts:
        raise FileNotFoundError(root / storage.PATHS["catalog"])
    if not full:
        return cls._open_fast_sqlite(root, manifest)
    temporary = tempfile.TemporaryDirectory(prefix="pg-verify-")
    scratch = Path(temporary.name)
    portable_only = "catalog" not in manifest.artifacts
    db = (
        sqlite3.connect(scratch / "catalog.sqlite")
        if portable_only
        else sqlite3.connect(
            f"{(root / storage.PATHS['catalog']).resolve().as_uri()}?mode=ro", uri=True
        )
    )
    db.execute("PRAGMA temp_store=FILE")
    db.execute("PRAGMA cache_size=-16384")
    graphs = GraphStore(db)
    try:
        if portable_only:
            import_portable(root, db)
        _check_portable_catalog(root, db)
        for expected, actual in zip_longest(
            rows(root, "memberships"),
            db.execute(
                "SELECT " + storage.MEMBERS + " FROM memberships ORDER BY occurrence_id"
            ),
        ):
            if (
                expected is None
                or actual is None
                or expected != dict(zip(storage.MEMBERS.split(","), actual))
            ):
                raise ValueError("PG memberships disagree with SQLite")
        if db.execute("PRAGMA integrity_check").fetchone() != ("ok",) or db.execute(
            "PRAGMA user_version"
        ).fetchone() != (5,):
            raise ValueError("PG SQLite integrity/schema failure")
        for (key,) in db.execute("SELECT graph_id FROM rule_graphs"):
            graphs.signature(key)
        validate_evidence(db, graphs, manifest)
        # Reports are small projections, never a second occurrence catalogue.
        storage.legacy._reports(db, scratch)
        for name in (
            "report_events",
            "report_interval_steps",
            "report_interval_sequences",
            "report_ngrams",
            "errors",
        ):
            if (
                sha256_file(scratch / storage.PATHS[name])
                != manifest.artifacts[name]["sha256"]
            ):
                raise ValueError(f"PG report disagrees with evidence: {name}")
        if json.loads((root / storage.PATHS["summary"]).read_text()) != {
            "library_id": manifest.library_id,
            **dict(manifest.statistics),
        }:
            raise ValueError("PG summary disagrees with evidence")
        if portable_only:
            storage.browse_schema(db)
            db.executemany(
                "INSERT INTO metadata VALUES(?,?)",
                (
                    ("library_id", canonical_json(manifest.library_id)),
                    ("statistics", canonical_json(manifest.statistics)),
                ),
            )
            db.commit()
        check_navigation(db)
        if not portable_only:
            return cls._open_fast_sqlite(root, manifest)
        library = cls._open_fast_sqlite(scratch, manifest)
        library.directory = root
        library._normalized_temporary = temporary
        temporary = None
        return library
    finally:
        graphs.clear()
        db.close()
        if temporary is not None:
            temporary.cleanup()
