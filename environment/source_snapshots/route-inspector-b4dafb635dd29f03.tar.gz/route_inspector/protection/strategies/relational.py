"""Format-5 PG evidence: one membership row per occurrence, lazy support views."""

from __future__ import annotations

import json
import sqlite3
from collections import Counter
from pathlib import Path

from route_inspector.infrastructure.build_workspace import check_disk_headroom
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.protection.strategies import normalized_build as legacy
from route_inspector.protection.strategies.catalog import (
    PGStrategyLibraryManifest,
    _digest,
)
from route_inspector.protection.strategies.normalized import GraphStore
from route_inspector.rules.graph import canonical_json

PATHS = {**legacy.PATHS, "memberships": "provenance/memberships.jsonl"}
KINDS = ("event", "interval_step", "interval_sequence", "interval_ngram")
MEMBERS = "occurrence_id,entry_id,kind,event_id,start_index,length,occurrence_sha256"


class IncompletePGPublication(ValueError):
    """An older interrupted seal discarded staging state without a checkpoint."""


def _seal_publication(db, seal):
    # sqlite3 does not implicitly begin a transaction for DDL. Explicitly bind
    # all three drops to the seal, including process termination between them.
    db.execute("BEGIN IMMEDIATE")
    with db:
        for table in ("staged", "graph_families", "processed_routes"):
            db.execute(f"DROP TABLE {table}")
        db.execute(
            "INSERT INTO build_state VALUES(?,?)", ("sealed", canonical_json(seal))
        )


def schema(db):
    legacy._schema(db)
    db.executescript("""
        DROP TABLE interval_ngram_occurrences;
        CREATE TABLE memberships(member_id INTEGER PRIMARY KEY,
            occurrence_id TEXT UNIQUE NOT NULL, entry_id TEXT NOT NULL,
            kind TEXT NOT NULL, event_id TEXT NOT NULL,
            start_index INTEGER NOT NULL, length INTEGER NOT NULL,
            occurrence_sha256 TEXT NOT NULL);
        CREATE INDEX membership_entries ON memberships(entry_id,occurrence_id);
        CREATE INDEX interval_ngrams_event ON memberships(event_id,kind,start_index,length);
        CREATE INDEX membership_kinds ON memberships(kind,occurrence_id);
        CREATE VIEW interval_ngram_occurrences AS
            SELECT occurrence_id,event_id AS event_occurrence_id,
                json_object('event_occurrence_id',event_id,'length',length,
                    'occurrence_id',occurrence_id,'start_index',start_index) AS occurrence_json
            FROM memberships WHERE kind='interval_ngram';
        CREATE TABLE build_state(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        PRAGMA user_version=5;
    """)


def stage(db, graphs, kind, value):
    """Retain scalar membership and the base event/step, never copied support JSON."""
    identity = value["identity"]
    oid = value["occurrence_id"]
    db.execute(
        "INSERT INTO staged VALUES(?,?,?,?,?,?)",
        (
            kind,
            oid,
            identity["lookup_key"],
            graphs.group_key(identity),
            canonical_json(identity),
            "{}",
        ),
    )
    db.execute(
        "INSERT INTO memberships(" + MEMBERS + ") VALUES(?,?,?,?,?,?,?)",
        (
            oid,
            "",
            kind,
            oid if kind == "event" else value["event_occurrence_id"],
            value.get("start_index", value.get("step_index", 0)),
            value.get(
                "length",
                1
                if kind == "interval_step"
                else len(value.get("step_occurrence_ids", ())),
            ),
            graphs.expanded_digest(value),
        ),
    )
    if kind not in {"event", "interval_step"}:
        return
    route = value["route"]
    common = (oid, "")
    if kind == "interval_step":
        common += (
            value["event_occurrence_id"],
            value["focal_pg_type"],
            canonical_json(value["active_pg_types"]),
        )
    common += tuple(route[k] for k in ("dataset_id", "source_identity", "route_id")) + (
        canonical_json(value),
    )
    table = "event_occurrences" if kind == "event" else "interval_step_occurrences"
    db.execute(f"INSERT INTO {table} VALUES({','.join('?' for _ in common)})", common)


def aggregate(db, graphs):
    for group_number, (kind, lookup) in enumerate(
        db.execute(
            "SELECT DISTINCT kind,lookup_key FROM staged ORDER BY kind,lookup_key"
        ),
        1,
    ):
        if db.execute(
            "SELECT 1 FROM entries WHERE kind=? AND lookup_key=?", (kind, lookup)
        ).fetchone():
            continue
        # Only a hash-collision bucket is held; support never enters this list.
        groups = []
        for family, oid in db.execute(
            "SELECT family,MIN(oid) FROM staged WHERE kind=? AND lookup_key=? GROUP BY family",
            (kind, lookup),
        ):
            raw = db.execute(
                "SELECT identity_json FROM staged WHERE oid=?", (oid,)
            ).fetchone()[0]
            groups.append((family, oid, json.loads(raw)))
        ordered = (
            sorted(groups, key=lambda g: canonical_json(graphs.unpack(g[2])))
            if len(groups) > 1
            else groups
        )
        for ordinal, (family, representative, identity) in enumerate(ordered):
            entry_id = f"{lookup}~{ordinal:04d}"
            db.execute(
                "UPDATE memberships SET entry_id=? WHERE occurrence_id IN (SELECT oid FROM staged WHERE kind=? AND lookup_key=? AND family=?)",
                (entry_id, kind, lookup, family),
            )
            count = db.execute(
                "SELECT COUNT(*) FROM memberships WHERE entry_id=?", (entry_id,)
            ).fetchone()[0]
            route_count = db.execute(
                "SELECT COUNT(*) FROM (SELECT DISTINCT e.dataset_id,e.source_identity,e.route_id FROM memberships m JOIN event_occurrences e ON e.occurrence_id=m.event_id WHERE m.entry_id=?)",
                (entry_id,),
            ).fetchone()[0]
            entry = dict(
                kind=kind,
                entry_id=entry_id,
                identity=identity,
                lookup_key=lookup,
                occurrence_count=count,
                route_count=route_count,
                representative_occurrence_id=representative,
            )
            db.execute(
                "INSERT OR REPLACE INTO entries VALUES(?,?,?,?)",
                (entry_id, kind, lookup, canonical_json(entry)),
            )
            if kind in {"event", "interval_step"}:
                table = (
                    "event_occurrences"
                    if kind == "event"
                    else "interval_step_occurrences"
                )
                db.execute(
                    f"UPDATE {table} SET entry_id=? WHERE occurrence_id IN (SELECT occurrence_id FROM memberships WHERE entry_id=?)",
                    (entry_id, entry_id),
                )
        if group_number % 100 == 0:
            db.commit()
    db.commit()


def base_event(db, event_id):
    row = db.execute(
        "SELECT occurrence_json FROM event_occurrences WHERE occurrence_id=?",
        (event_id,),
    ).fetchone()
    if row is None:
        raise ValueError("PG membership has a missing event")
    return json.loads(row[0])


def event_steps(db, event):
    for key in event["interval_step_occurrence_ids"]:
        row = db.execute(
            "SELECT occurrence_json FROM interval_step_occurrences WHERE occurrence_id=?",
            (key,),
        ).fetchone()
        if row is None:
            raise ValueError("PG event has a missing interval step")
        yield json.loads(row[0])


def support_record(db, oid):
    row = db.execute(
        "SELECT " + MEMBERS + " FROM memberships WHERE occurrence_id=?", (oid,)
    ).fetchone()
    if row is None:
        raise KeyError(oid)
    oid, entry, kind, event_id, start, length, digest = tuple(row)
    event = base_event(db, event_id)
    result = dict(occurrence_id=oid, route=event["route"], occurrence_sha256=digest)
    if kind == "event":
        return result
    result.update(event_occurrence_id=event_id, focal_pg_type=event["pg_type"])
    if kind == "interval_step":
        raw = json.loads(
            db.execute(
                "SELECT occurrence_json FROM interval_step_occurrences WHERE occurrence_id=?",
                (oid,),
            ).fetchone()[0]
        )
        result["active_pg_types"] = raw["active_pg_types"]
    else:
        steps = list(event_steps(db, event))[start : start + length]
        result.update(
            active_pg_contexts=[s["active_pg_types"] for s in steps],
            step_occurrence_ids=[s["occurrence_id"] for s in steps],
        )
        if kind == "interval_ngram":
            result.update(
                start_index=start,
                length=length,
                reaction_node_paths=[s["reaction_node_path"] for s in steps],
            )
    return result


def supports(db, entry_id, *, offset=0, limit=None):
    if offset < 0 or (limit is not None and limit < 1):
        raise ValueError("invalid PG support page bounds")
    sql = "SELECT occurrence_id FROM memberships WHERE entry_id=? ORDER BY occurrence_id LIMIT ? OFFSET ?"
    for (oid,) in db.execute(sql, (entry_id, -1 if limit is None else limit, offset)):
        yield support_record(db, oid)


def expand_entry(db, value):
    entry = dict(value)
    entry["reference_routes"] = [
        dict(zip(("dataset_id", "source_identity", "route_id"), tuple(row)))
        for row in db.execute(
            "SELECT DISTINCT e.dataset_id,e.source_identity,e.route_id FROM memberships m JOIN event_occurrences e ON e.occurrence_id=m.event_id WHERE m.entry_id=? ORDER BY e.dataset_id,e.source_identity,e.route_id",
            (entry["entry_id"],),
        )
    ]
    entry["support_records"] = list(supports(db, entry["entry_id"]))
    return entry


def browse_payload(db, oid):
    row = db.execute(
        "SELECT entry_id,kind,length FROM memberships WHERE occurrence_id=?", (oid,)
    ).fetchone()
    if row is None:
        raise ValueError("missing PG browse membership")
    entry, kind, length = tuple(row)
    value = {**support_record(db, oid), "entry_id": entry}
    if kind == "interval_step":
        value.update(length=1, step_occurrence_ids=[oid])
    else:
        summary = json.loads(
            db.execute(
                "SELECT entry_json FROM entries WHERE entry_id=?", (entry,)
            ).fetchone()[0]
        )
        value.update(
            route_count=summary["route_count"],
            occurrence_count=summary["occurrence_count"],
        )
    return canonical_json(value)


def register_browse(db):
    db.create_function("ri_pg_support", 1, lambda oid: browse_payload(db, oid))


def browse_schema(db):
    db.executescript("""
        CREATE TABLE pg_browse_metadata(version INTEGER NOT NULL);
        INSERT INTO pg_browse_metadata VALUES(2);
        CREATE TABLE pg_browse_events(id TEXT PRIMARY KEY,family TEXT,pg TEXT,
            origin TEXT,functional_group TEXT,route_id TEXT,terminus TEXT);
        CREATE INDEX pg_browse_event_routes ON pg_browse_events(route_id);
        CREATE INDEX pg_browse_event_types ON pg_browse_events(pg,origin,family);
        CREATE INDEX pg_browse_event_filters ON pg_browse_events(origin,terminus,id);
        INSERT INTO pg_browse_events SELECT occurrence_id,entry_id,
            json_extract(occurrence_json,'$.pg_type'),json_extract(occurrence_json,'$.source_type'),
            json_extract(occurrence_json,'$.identity.protected_functional_group'),route_id,
            CASE WHEN json_extract(occurrence_json,'$.identity.identity_version')<3 THEN 'unavailable'
                 WHEN json_extract(occurrence_json,'$.identity.endpoint_kind')='target' THEN 'preserved'
                 ELSE 'not_preserved' END FROM event_occurrences;
        CREATE VIEW pg_browse_grams AS SELECT occurrence_id AS id,event_id AS event,
            ri_pg_support(occurrence_id) AS payload FROM memberships WHERE kind='interval_ngram';
        CREATE VIEW pg_browse_tactic_windows AS SELECT occurrence_id AS id,event_id AS event,
            entry_id AS entry,length,ri_pg_support(occurrence_id) AS payload
            FROM memberships WHERE kind IN ('interval_step','interval_ngram');
    """)


def statistics(db):
    result = {
        f"{kind}_occurrence_count": db.execute(
            "SELECT COUNT(*) FROM memberships WHERE kind=?", (kind,)
        ).fetchone()[0]
        for kind in KINDS
    }
    for kind in KINDS:
        result[f"{kind}_entry_count"] = db.execute(
            "SELECT COUNT(*) FROM entries WHERE kind=?", (kind,)
        ).fetchone()[0]

    def count(condition):
        return db.execute(
            "SELECT COUNT(*) FROM event_occurrences WHERE " + condition
        ).fetchone()[0]

    result.update(
        target_retained_event_count=count(
            "json_extract(occurrence_json,'$.pg_terminus')='preserved'"
        ),
        deprotection_ended_event_count=count(
            "json_extract(occurrence_json,'$.pg_terminus')='not_preserved'"
        ),
        unresolved_target_event_count=count(
            "json_extract(occurrence_json,'$.source_type')='unknown'"
        ),
        resolved_event_count=count(
            "json_extract(occurrence_json,'$.source_type')!='unknown'"
        ),
        introduced_event_count=count(
            "json_extract(occurrence_json,'$.source_type')='introduced'"
        ),
        stock_event_count=count(
            "json_extract(occurrence_json,'$.source_type')='stock'"
        ),
        protected_synthon_event_count=count(
            "json_extract(occurrence_json,'$.source_type')='protected_synthon'"
        ),
        diagnostic_count=db.execute("SELECT COUNT(*) FROM diagnostics").fetchone()[0],
        route_count_with_resolved_events=db.execute(
            "SELECT COUNT(*) FROM (SELECT DISTINCT dataset_id,source_identity,route_id FROM event_occurrences WHERE json_extract(occurrence_json,'$.source_type')!='unknown')"
        ).fetchone()[0],
        interval_ngram_event_count=db.execute(
            "SELECT COUNT(DISTINCT event_id) FROM memberships WHERE kind='interval_ngram'"
        ).fetchone()[0],
        interval_ngram_route_count=db.execute(
            "SELECT COUNT(*) FROM (SELECT DISTINCT e.dataset_id,e.source_identity,e.route_id FROM memberships m JOIN event_occurrences e ON e.occurrence_id=m.event_id WHERE m.kind='interval_ngram')"
        ).fetchone()[0],
        interval_ngram_length_histogram={
            str(length): count
            for length, count in db.execute(
                "SELECT length,COUNT(*) FROM memberships WHERE kind='interval_ngram' GROUP BY length"
            )
        },
    )
    return result


def publication_id(profile, corpora, stats, artifacts):
    return "pg_strategy_library_" + _digest(
        dict(
            format=5,
            storage_policy="relational-evidence-v1",
            profile=profile,
            reference_corpora=list(corpora),
            statistics=stats,
            portable_artifacts={
                k: v["sha256"]
                for k, v in artifacts.items()
                if k not in {"catalog", "summary"}
            },
        )
    )


def write_relational(
    processed_routes,
    root,
    *,
    processing_profile,
    reference_corpora,
    include_sqlite=True,
    resume=False,
):
    """Write all evidence, committing one complete route at a time."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    path = root / PATHS["catalog"]
    exists = path.exists()
    if exists and not resume:
        raise FileExistsError(path)
    fingerprint = canonical_json(
        dict(profile=processing_profile, corpora=list(reference_corpora), version=5)
    )
    db = sqlite3.connect(path)
    db.execute("PRAGMA auto_vacuum=INCREMENTAL")
    db.execute("PRAGMA journal_mode=TRUNCATE")
    db.execute("PRAGMA cache_size=-16384")
    db.execute("PRAGMA temp_store=FILE")
    graphs = GraphStore(db)
    try:
        if not exists:
            schema(db)
            db.execute(
                "INSERT INTO build_state VALUES(?,?)", ("fingerprint", fingerprint)
            )
            db.commit()
        elif db.execute(
            "SELECT value FROM build_state WHERE key='fingerprint'"
        ).fetchone() != (fingerprint,):
            raise ValueError("incompatible PG resume inputs")
        sealed = db.execute(
            "SELECT value FROM build_state WHERE key='sealed'"
        ).fetchone()
        if sealed is None:
            tables = {
                row[0]
                for row in db.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            }
            if not {"staged", "graph_families", "processed_routes"} <= tables:
                raise IncompletePGPublication(
                    "PG publication has no seal and is missing staging tables; "
                    "resume the PG builder using its retained extraction checkpoint"
                )
            for i, route in enumerate(processed_routes):
                if i % 25 == 0:
                    check_disk_headroom(root)
                key = (
                    route.route.dataset_id,
                    route.route.source_identity,
                    route.route.route_id,
                )
                if db.execute(
                    "SELECT 1 FROM processed_routes WHERE dataset=? AND source=? AND route=?",
                    key,
                ).fetchone():
                    continue
                try:
                    legacy._stage_route(
                        db,
                        graphs,
                        route,
                        Counter(),
                        set(),
                        set(),
                        Counter(),
                        stage=stage,
                    )
                    db.commit()
                except BaseException:
                    db.rollback()
                    graphs.clear()
                    raise
                if (i + 1) % 100 == 0:
                    print(f"[pg-relational] {i + 1} routes committed", flush=True)
            aggregate(db, graphs)
            stats = statistics(db)
            db.executescript(
                "CREATE TEMP TABLE sorted_diagnostics AS SELECT diagnostic_json FROM diagnostics ORDER BY diagnostic_json; DELETE FROM diagnostics; INSERT INTO diagnostics SELECT rowid-1,diagnostic_json FROM sorted_diagnostics ORDER BY rowid; DROP TABLE sorted_diagnostics;"
            )
            portable = {}
            for name, kind in (
                ("event_entries", "event"),
                ("interval_step_entries", "interval_step"),
                ("interval_sequence_entries", "interval_sequence"),
                ("ngram_entries", "interval_ngram"),
            ):
                portable[name] = legacy._jsonl(
                    root / PATHS[name],
                    (
                        json.loads(r[0])
                        for r in db.execute(
                            "SELECT entry_json FROM entries WHERE kind=? ORDER BY entry_id",
                            (kind,),
                        )
                    ),
                )
            for name, table in (
                ("event_occurrences", "event_occurrences"),
                ("interval_step_occurrences", "interval_step_occurrences"),
                ("ngram_occurrences", "interval_ngram_occurrences"),
            ):
                portable[name] = legacy._jsonl(
                    root / PATHS[name],
                    (
                        json.loads(r[0])
                        for r in db.execute(
                            f"SELECT occurrence_json FROM {table} ORDER BY occurrence_id"
                        )
                    ),
                )
            portable["rule_graphs"] = legacy._jsonl(
                root / PATHS["rule_graphs"],
                (
                    {"graph_id": k, "graph": json.loads(v)}
                    for k, v in db.execute(
                        "SELECT graph_id,graph_json FROM rule_graphs ORDER BY graph_id"
                    )
                ),
            )
            portable["memberships"] = legacy._jsonl(
                root / PATHS["memberships"],
                (
                    dict(zip(MEMBERS.split(","), tuple(r)))
                    for r in db.execute(
                        "SELECT " + MEMBERS + " FROM memberships ORDER BY occurrence_id"
                    )
                ),
            )
            portable["diagnostics"] = legacy._jsonl(
                root / PATHS["diagnostics"],
                (
                    json.loads(r[0])
                    for r in db.execute(
                        "SELECT diagnostic_json FROM diagnostics ORDER BY ordinal"
                    )
                ),
            )
            legacy._reports(db, root)
            artifacts = {
                name: dict(
                    path=relative,
                    **(
                        portable[name]
                        if name in portable
                        else dict(
                            sha256=sha256_file(root / relative),
                            size_bytes=(root / relative).stat().st_size,
                        )
                    ),
                )
                for name, relative in PATHS.items()
                if name not in {"catalog", "summary"}
            }
            library_id = publication_id(
                processing_profile, reference_corpora, stats, artifacts
            )
            (root / PATHS["summary"]).write_text(
                json.dumps(dict(library_id=library_id, **stats), indent=2) + "\n"
            )
            db.execute("DELETE FROM metadata")
            db.executemany(
                "INSERT INTO metadata VALUES(?,?)",
                (
                    ("library_id", canonical_json(library_id)),
                    ("statistics", canonical_json(stats)),
                ),
            )
            if not db.execute(
                "SELECT 1 FROM sqlite_master WHERE name='pg_browse_metadata'"
            ).fetchone():
                browse_schema(db)
            db.commit()
            # Scratch state stays in the durable build workspace until publication.
            _seal_publication(
                db, dict(statistics=stats, library_id=library_id, artifacts=artifacts)
            )
        else:
            seal = json.loads(sealed[0])
            stats, library_id, artifacts = (
                seal["statistics"],
                seal["library_id"],
                seal["artifacts"],
            )
        graphs.clear()
        db.execute("PRAGMA incremental_vacuum").fetchall()
    finally:
        graphs.clear()
        db.close()
    if not include_sqlite:
        path.unlink()
    for name in ("summary", "catalog") if include_sqlite else ("summary",):
        p = root / PATHS[name]
        artifacts[name] = dict(
            path=PATHS[name], sha256=sha256_file(p), size_bytes=p.stat().st_size
        )
    manifest = PGStrategyLibraryManifest(
        library_id,
        processing_profile,
        tuple(reference_corpora),
        stats,
        artifacts,
        library_format_version=5,
        catalog_schema_version=5,
    )
    (root / "manifest.json").write_text(json.dumps(manifest.to_dict(), indent=2) + "\n")
    return manifest
