"""Stream portable format-4 data through independent provenance reconstruction."""

from __future__ import annotations

import json
import sqlite3
import tempfile
from itertools import zip_longest
from pathlib import Path

from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.protection.strategies.models import (
    PGStrategyIntervalSequenceOccurrence,
    PGStrategyIntervalStepOccurrence,
    ProcessedRoutePGStrategies,
    ProtectingGroupStrategyOccurrence,
)
from route_inspector.protection.strategies.normalized import GraphStore, window_record
from route_inspector.protection.strategies.normalized_build import (
    PATHS,
    _schema,
    publication_id,
)
from route_inspector.reference_library.models import ReferenceRouteKey
from route_inspector.rules.graph import canonical_json


def _rows(root, name, key):
    previous = None
    with (root / PATHS[name]).open(encoding="utf-8") as stream:
        for line in stream:
            value = json.loads(line)
            if line != canonical_json(value) + "\n":
                raise ValueError(f"noncanonical normalized PG artifact: {name}")
            current = value[key] if key else canonical_json(value)
            if previous is not None and (
                current < previous or (key and current == previous)
            ):
                raise ValueError(
                    f"unordered or duplicate normalized PG artifact: {name}"
                )
            previous = current
            yield value


def import_portable(root, db):
    """Import normalized records without ever expanding the complete catalog."""
    _schema(db)
    db.execute("CREATE TABLE owners(kind TEXT,oid TEXT PRIMARY KEY,entry_id TEXT)")
    for value in _rows(root, "rule_graphs", "graph_id"):
        if set(value) != {"graph_id", "graph"}:
            raise ValueError("invalid PG graph record")
        db.execute(
            "INSERT INTO rule_graphs VALUES(?,?)",
            (value["graph_id"], canonical_json(value["graph"])),
        )
    for name, kind in (
        ("event_entries", "event"),
        ("interval_step_entries", "interval_step"),
        ("interval_sequence_entries", "interval_sequence"),
        ("ngram_entries", "interval_ngram"),
    ):
        for value in _rows(root, name, "entry_id"):
            if value["kind"] != kind:
                raise ValueError("PG entry has the wrong kind")
            db.execute(
                "INSERT INTO entries VALUES(?,?,?,?)",
                (value["entry_id"], kind, value["lookup_key"], canonical_json(value)),
            )
            db.executemany(
                "INSERT INTO owners VALUES(?,?,?)",
                (
                    (kind, r["occurrence_id"], value["entry_id"])
                    for r in value["support_records"]
                ),
            )
    for name, kind, table in (
        ("event_occurrences", "event", "event_occurrences"),
        ("interval_step_occurrences", "interval_step", "interval_step_occurrences"),
    ):
        for value in _rows(root, name, "occurrence_id"):
            owner = db.execute(
                "SELECT entry_id FROM owners WHERE kind=? AND oid=?",
                (kind, value["occurrence_id"]),
            ).fetchone()
            if owner is None:
                raise ValueError("PG occurrence has no owning entry")
            route = value["route"]
            common = (value["occurrence_id"], owner[0])
            if kind == "interval_step":
                common += (
                    value["event_occurrence_id"],
                    value["focal_pg_type"],
                    canonical_json(value["active_pg_types"]),
                )
            common += tuple(
                route[k] for k in ("dataset_id", "source_identity", "route_id")
            ) + (canonical_json(value),)
            db.execute(
                f"INSERT INTO {table} VALUES({','.join('?' for _ in common)})", common
            )
    for value in _rows(root, "ngram_occurrences", "occurrence_id"):
        db.execute(
            "INSERT INTO interval_ngram_occurrences VALUES(?,?,?)",
            (
                value["occurrence_id"],
                value["event_occurrence_id"],
                canonical_json(value),
            ),
        )
    for i, value in enumerate(_rows(root, "diagnostics", None)):
        db.execute("INSERT INTO diagnostics VALUES(?,?)", (i, canonical_json(value)))
    db.commit()


def processed_routes(db, graphs, corpora):
    """Reconstruct complete intervals from base events/steps, never from n-grams."""
    keys = set(
        tuple(row)
        for row in db.execute(
            "SELECT DISTINCT dataset_id,source_identity,route_id FROM event_occurrences UNION SELECT DISTINCT dataset_id,source_identity,route_id FROM interval_step_occurrences"
        )
    )
    roster = {
        (c["dataset_id"], c["source_identity"], str(r))
        for c in corpora
        for r in c.get("route_ids", ())
    }
    if roster and not keys <= roster:
        raise ValueError("PG occurrences lie outside the declared corpus")
    keys.update(roster)
    diagnostics = {}
    unassigned = []
    for (row,) in db.execute(
        "SELECT diagnostic_json FROM diagnostics ORDER BY ordinal"
    ):
        value = json.loads(row)
        route = value.get("route", {})
        key = tuple(route.get(k) for k in ("dataset_id", "source_identity", "route_id"))
        if key in keys:
            diagnostics.setdefault(key, []).append(value)
        else:
            unassigned.append(value)
    if not keys and unassigned:
        raise ValueError("diagnostics require a source corpus route")
    for key in sorted(keys):
        raw_events, raw_steps = [], []
        for table, destination in (
            ("event_occurrences", raw_events),
            ("interval_step_occurrences", raw_steps),
        ):
            for (row,) in db.execute(
                f"SELECT occurrence_json FROM {table} WHERE dataset_id=? AND source_identity=? AND route_id=? ORDER BY occurrence_id",
                key,
            ):
                destination.append(json.loads(row))
        events, steps, sequences = [], [], []
        by_id = {s["occurrence_id"]: s for s in raw_steps}
        for raw in raw_events:
            expanded = {**raw, "identity": graphs.unpack(raw["identity"])}
            event = ProtectingGroupStrategyOccurrence.from_dict(expanded)
            if event.to_dict() != expanded:
                raise ValueError("incomplete normalized PG event")
            events.append(event)
            if event.interval_sequence_occurrence_id:
                sequence = window_record(
                    raw,
                    [by_id[k] for k in event.interval_step_occurrence_ids],
                    0,
                    event.lifetime_steps,
                    graphs,
                    ngram=False,
                )
                sequence["identity"] = graphs.unpack(sequence["identity"])
                sequences.append(
                    PGStrategyIntervalSequenceOccurrence.from_dict(sequence)
                )
        for raw in raw_steps:
            expanded = {**raw, "identity": graphs.unpack(raw["identity"])}
            step = PGStrategyIntervalStepOccurrence.from_dict(expanded)
            if step.to_dict() != expanded:
                raise ValueError("incomplete normalized PG step")
            steps.append(step)
        yield ProcessedRoutePGStrategies(
            ReferenceRouteKey(*key),
            tuple(events),
            tuple(steps),
            tuple(sequences),
            tuple(diagnostics.get(key, ())) + tuple(unassigned),
        )
        unassigned.clear()


def _same_rows(left, right, sql):
    sentinel = object()
    if any(
        a != b
        for a, b in zip_longest(
            left.execute(sql), right.execute(sql), fillvalue=sentinel
        )
    ):
        raise ValueError("PG SQLite contents disagree with normalized sidecars")


def _check_portable_catalog(root, db):
    """Stream-check base records instead of making a second disk-sized copy."""
    specifications = [
        (
            "event_entries",
            "SELECT entry_json FROM entries WHERE kind='event' ORDER BY entry_id",
            "entry_id",
        ),
        (
            "interval_step_entries",
            "SELECT entry_json FROM entries WHERE kind='interval_step' ORDER BY entry_id",
            "entry_id",
        ),
        (
            "interval_sequence_entries",
            "SELECT entry_json FROM entries WHERE kind='interval_sequence' ORDER BY entry_id",
            "entry_id",
        ),
        (
            "ngram_entries",
            "SELECT entry_json FROM entries WHERE kind='interval_ngram' ORDER BY entry_id",
            "entry_id",
        ),
        (
            "event_occurrences",
            "SELECT occurrence_json FROM event_occurrences ORDER BY occurrence_id",
            "occurrence_id",
        ),
        (
            "interval_step_occurrences",
            "SELECT occurrence_json FROM interval_step_occurrences ORDER BY occurrence_id",
            "occurrence_id",
        ),
        (
            "ngram_occurrences",
            "SELECT occurrence_json FROM interval_ngram_occurrences ORDER BY occurrence_id",
            "occurrence_id",
        ),
        (
            "diagnostics",
            "SELECT diagnostic_json FROM diagnostics ORDER BY ordinal",
            None,
        ),
    ]
    for name, sql, key in specifications:
        for portable, row in zip_longest(_rows(root, name, key), db.execute(sql)):
            if portable is None or row is None or canonical_json(portable) != row[0]:
                raise ValueError(f"PG {name} disagrees with SQLite contents")
    for portable, row in zip_longest(
        _rows(root, "rule_graphs", "graph_id"),
        db.execute("SELECT graph_id,graph_json FROM rule_graphs ORDER BY graph_id"),
    ):
        if (
            portable is None
            or row is None
            or portable != {"graph_id": row[0], "graph": json.loads(row[1])}
        ):
            raise ValueError("PG graph dictionary disagrees with SQLite contents")


def load_normalized(cls, root, manifest, *, backend, verification):
    root = Path(root)
    required = set(PATHS) - {"catalog"}
    if not required <= set(manifest.artifacts) <= set(PATHS):
        raise ValueError("incomplete normalized PG artifacts")
    full = (
        verification == "full"
        or backend == "jsonl"
        or "catalog" not in manifest.artifacts
    )
    for name, descriptor in manifest.artifacts.items():
        path = root / PATHS[name]
        if (
            descriptor["path"] != PATHS[name]
            or not path.is_file()
            or path.stat().st_size != descriptor["size_bytes"]
        ):
            raise ValueError(f"missing or invalid PG artifact: {name}")
        if full and sha256_file(path) != descriptor["sha256"]:
            raise ValueError(f"PG artifact hash mismatch: {name}")
    if (
        publication_id(
            manifest.processing_profile,
            manifest.reference_corpora,
            manifest.statistics,
            manifest.artifacts,
        )
        != manifest.library_id
    ):
        raise ValueError("normalized PG publication identity mismatch")
    if backend == "sqlite" and "catalog" not in manifest.artifacts:
        raise FileNotFoundError(root / PATHS["catalog"])
    if not full:
        return cls._open_fast_sqlite(root, manifest)
    temporary = tempfile.TemporaryDirectory(prefix="pg-verify-")
    scratch = Path(temporary.name)
    db = (
        sqlite3.connect(
            f"{(root / PATHS['catalog']).resolve().as_uri()}?mode=ro", uri=True
        )
        if "catalog" in manifest.artifacts
        else sqlite3.connect(scratch / "catalog.sqlite")
    )
    graphs = GraphStore(db)
    try:
        if "catalog" in manifest.artifacts:
            _check_portable_catalog(root, db)
        else:
            import_portable(root, db)
        # Check every graph, including representations that were accidentally orphaned.
        for (key,) in db.execute("SELECT graph_id FROM rule_graphs ORDER BY graph_id"):
            graphs.signature(key)
        from route_inspector.protection.strategies import relational
        from route_inspector.protection.strategies.relational_verify import (
            check_navigation,
            validate_evidence,
        )

        _legacy_memberships(db)
        validate_evidence(db, graphs, manifest)
        relational.legacy._reports(db, scratch)
        for name in (
            "report_events",
            "report_interval_steps",
            "report_interval_sequences",
            "report_ngrams",
            "errors",
        ):
            if sha256_file(scratch / PATHS[name]) != manifest.artifacts[name]["sha256"]:
                raise ValueError(f"PG report disagrees with evidence: {name}")
        if json.loads((root / PATHS["summary"]).read_text()) != {
            "library_id": manifest.library_id,
            **dict(manifest.statistics),
        }:
            raise ValueError("PG summary disagrees with evidence")
        if db.execute("PRAGMA integrity_check").fetchone() != ("ok",):
            raise ValueError("PG SQLite integrity failure")
        if "catalog" in manifest.artifacts:
            check_navigation(db)
            for table, condition in (
                ("pg_browse_grams", "kind='interval_ngram'"),
                (
                    "pg_browse_tactic_windows",
                    "kind IN ('interval_step','interval_ngram')",
                ),
            ):
                for oid, payload in db.execute(
                    f"SELECT id,payload FROM {table} ORDER BY id"
                ):
                    if json.loads(payload) != json.loads(
                        relational.browse_payload(db, oid)
                    ):
                        raise ValueError(
                            "PG browse SQLite contents disagree with lifespan evidence"
                        )
        if backend != "jsonl" and "catalog" in manifest.artifacts:
            return cls._open_fast_sqlite(root, manifest)
        if "catalog" in manifest.artifacts:
            # A requested portable verification can return the same fully checked
            # logical reader; it has already compared every portable record.
            return cls._open_fast_sqlite(root, manifest)
        from route_inspector.protection.strategies.browsing import (
            build_browse_tables,
            sqlite_browse_entries,
        )

        build_browse_tables(db, sqlite_browse_entries(db))
        db.executemany(
            "INSERT INTO metadata VALUES(?,?)",
            (
                ("library_id", canonical_json(manifest.library_id)),
                ("statistics", canonical_json(manifest.statistics)),
            ),
        )
        db.commit()
        library = cls._open_fast_sqlite(scratch, manifest)
        library.directory = root
        library._normalized_temporary = temporary
        temporary = None
        return library
    finally:
        graphs.clear()
        db.close()
        if temporary is not None:
            temporary.cleanup()


def _legacy_memberships(db):
    """Index legacy support keys for validation without copying their payloads."""
    db.executescript("""
        CREATE TEMP TABLE memberships(occurrence_id TEXT PRIMARY KEY, entry_id TEXT,
            kind TEXT,event_id TEXT,start_index INTEGER,length INTEGER,occurrence_sha256 TEXT);
        CREATE INDEX temp.verify_members_entry ON memberships(entry_id,occurrence_id);
        CREATE INDEX temp.verify_members_kind ON memberships(kind,occurrence_id);
    """)
    for (encoded,) in db.execute("SELECT entry_json FROM entries ORDER BY entry_id"):
        entry = json.loads(encoded)
        kind = entry["kind"]
        for support in entry["support_records"]:
            oid = support["occurrence_id"]
            event = oid if kind == "event" else support["event_occurrence_id"]
            start = support.get("start_index", 0)
            length = support.get("length", len(support.get("step_occurrence_ids", ())))
            if kind == "interval_step":
                row = db.execute(
                    "SELECT json_extract(occurrence_json,'$.step_index') FROM interval_step_occurrences WHERE occurrence_id=?",
                    (oid,),
                ).fetchone()
                if row is None:
                    raise ValueError("PG support points to a missing step")
                start, length = row[0], 1
            if kind == "interval_ngram":
                raw = db.execute(
                    "SELECT occurrence_json FROM interval_ngram_occurrences WHERE occurrence_id=?",
                    (oid,),
                ).fetchone()
                expected = dict(
                    occurrence_id=oid,
                    event_occurrence_id=event,
                    start_index=start,
                    length=length,
                )
                if raw is None or json.loads(raw[0]) != expected:
                    raise ValueError("PG window differs from its support positions")
            db.execute(
                "INSERT INTO memberships VALUES(?,?,?,?,?,?,?)",
                (
                    oid,
                    entry["entry_id"],
                    kind,
                    event,
                    start,
                    length,
                    support["occurrence_sha256"],
                ),
            )
    if (
        db.execute("SELECT COUNT(*) FROM interval_ngram_occurrences").fetchone()
        != db.execute(
            "SELECT COUNT(*) FROM memberships WHERE kind='interval_ngram'"
        ).fetchone()
    ):
        raise ValueError("PG has orphan n-gram windows")
    db.commit()
