"""Mapped evidence for removal and transfer of a protecting fragment."""

ENDPOINT_POLICY = {
    "version": 1,
    "alkyne_tms_terminal_restoration": 1,
    "removal": "cleavage-and-fragment-fate",
    "atom_addition_rules": "existing-checks",
    "target_lineage": 1,
    "heteroaryl_n_thp_lactam_representation": 1,
}


def lactam_thp_mappings(molecule):
    """Recognize the canonical pyridazinone form of an aromatic N-THP site."""
    from chython import smarts

    query = smarts("[N;D3;r6:1]-;!@[C;D3;y2;z1;r6]1[O;D2][C;D2][C;D2][C;D2][C;D2]1")
    for mapping in query.get_mapping(molecule):
        anchor = mapping[1]
        if not any(
            anchor in ring
            and len(ring) == 6
            and sum(molecule.atom(n).atomic_number == 7 for n in ring) == 2
            and sum(
                int(bond) == 2
                for a, b, bond in molecule.bonds()
                if a in ring and b in ring
            )
            == 2
            for ring in molecule.sssr
        ):
            continue
        scaffold = set(molecule._bonds[anchor]) - set(mapping.values())
        if not any(molecule.atom(n).atomic_number == 7 for n in scaffold):
            continue
        if not any(
            molecule.atom(n).atomic_number == 6
            and any(
                molecule.atom(o).atomic_number == 8 and int(bond) == 2
                for o, bond in molecule._bonds[n].items()
            )
            for n in scaffold
        ):
            continue
        yield mapping


def removal_endpoint_valid(rule, reactant, product, mapping):
    """Check a specific site, never an equivalent site in another product."""
    if rule.atoms_to_add:
        return True
    if product is None or not set(rule.atoms_to_keep) <= mapping.keys():
        return False
    anchors = {mapping[n] for n in rule.atoms_to_keep}
    fragment = set(mapping.values()) - anchors
    boundary = [(a, b) for a in anchors for b in reactant._bonds[a] if b in fragment]
    if not anchors or not fragment or not boundary or not anchors <= set(product):
        return False
    if any(b in product._bonds[a] for a, b in boundary):
        return False
    if rule.name == "alkyne_tms":
        other, terminal = mapping[1], mapping[2]
        bond = product._bonds[terminal].get(other)
        if (
            bond is None
            or int(bond) != 3
            or product.atom(terminal).implicit_hydrogens != 1
        ):
            return False
    # Products are separate connected molecules: PG atoms in a detached
    # byproduct are allowed, but migration into the retained molecule is not.
    return not fragment.intersection(product)


def installed_sites(product, reactants, rules):
    """Identify new protected sites whose masking fragment has a mapped donor.

    This is structural installation evidence, not a claim of synthetic intent.
    """
    from route_inspector.protection.analysis import matching_site_mappings

    reactant_sets = [(m, set(m)) for m in reactants]
    for rule in rules.values():
        if rule.atoms_to_add:
            continue
        for anchors, mapping in matching_site_mappings(product, rule):
            fragment = set(mapping.values()) - set(anchors)
            if not fragment:
                continue
            for donor, atoms in reactant_sets:
                if fragment <= atoms and not set(anchors) <= atoms:
                    yield rule, anchors, fragment, donor


def is_pg_donation(protected_atoms, product, reactants, rules):
    """A purported deprotected center instead became another site's mask."""
    return any(
        set(protected_atoms) & fragment
        for _, _, fragment, _ in installed_sites(product, reactants, rules)
    )
