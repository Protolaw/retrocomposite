from lazy_object_proxy import Proxy

# Chython SMARTS uses ``yN`` for the number of heteroatom neighbours and ``xN``
# for Daylight ring connectivity.  Older Chython rule tables used ``xN`` for the
# former meaning; retaining that legacy spelling silently changes query semantics
# in current Chython.


def _rules():
    """Return the project-local protecting-group rule table.

    The copied rule table keeps project-specific protecting-group definitions available
    even when the installed chython package changes.
    """
    from chython import smarts

    rules = {}

    rules["hydroxyl_tosyl"] = (
        smarts(
            "[O;D2:1]-;!@[S;D4;y3](=O)(=O)-[c;r6]1:[c;D2]:[c;D2]:[c;D3]([C;D1;H3]):[c;D2]:[c;D2]:1"
        ),
        [1],
        [],
        "CCOS(=O)(=O)c1ccc(C)cc1",
        "CCO",
        ["CCOS(=O)(=O)c1ccccc1", "CCOS(=O)(=O)c1cc(C)ccc1", "CCNS(=O)(=O)c1ccc(C)cc1"],
    )

    # The primary-amine nitrogen becomes the pyrrole ring nitrogen during
    # protection and survives cleavage of both ring attachments.
    # Walia et al., J. Org. Chem. 2013, DOI: 10.1021/jo401778e.
    rules["amine_dmp"] = (
        smarts("[n;D3;r5:1]1:[c;D3]([C;D1;H3]):[c;D2;H1]:[c;D2;H1]:[c;D3]:1-[C;D1;H3]"),
        [1],
        [],
        "CCn1c(C)ccc1C",
        "CCN",
        ["Cc1ccc(C)[nH]1", "CCn1cccc1", "CCn1cc(C)cc1C", "CCn1c(CC)ccc1C"],
    )

    rules["heteroaryl_n_methoxy_benzyl"] = (
        smarts(
            "[n;D3:1]-;!@[C;D2;z1;y1]-[c;r6]1:[c;D2]:[c;D2]:[c;D3]([O;D2;y0][C;D1;H3]):[c;D2]:[c;D2]:1"
        ),
        [1],
        [],
        "COc1ccc(Cn2cccc2)cc1",
        "[nH]1cccc1",
        ["COc1ccc(CNC)cc1", "COc1cc(Cn2cccc2)ccc1", "CCOc1ccc(Cn2cccc2)cc1"],
    )

    rules["hydroxyl_thiocarbamate"] = (
        smarts("[O;D2:1]-;!@[C;y3;z2](=[S;D1])[N;D3;y0]([C;D1])[C;D1]"),
        [1],  # atoms to keep
        [],  # atoms to add (atom_number, atom_type, bond_type)
        "CC(C)OC(=S)N(C)C",  # protected
        "CC(C)O",  # cleaved
        [],  # optional decoys
    )

    rules["hydroxyl_fmoc"] = (
        smarts(
            "[O;D2:1]-;!@[C;z2;y3](=O)[O;D2;y0]-[C;D2;y1;z1][C;D3;z1;y0;r5]1[C;a;r6]:2:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D3]:2-[C;a;r6]:3:[C;D2]:[C;D2]:[C;D2]:[C;D2]:C1:3"
        ),
        [1],
        [],
        "CC(C)OC(=O)OCC1c2ccccc2-c2ccccc21",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_troc"] = (
        smarts(
            "[O;D2:1]-;!@[C;z2;y3](=O)[O;D2;y0]-[C;D2][C;D4;y3]([Cl;D1])([Cl;D1])[Cl;D1]"
        ),
        [1],
        [],
        "CC(C)OC(=O)OCC(Cl)(Cl)Cl",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_teoc"] = (
        smarts(
            "[O;D2:1]-;!@[C;z2;y3](=O)[O;D2;y0]-[C;D2;z1;y1][C;D2;y1;z1][Si;D4;z1;y0]([C;D1])([C;D1])[C;D1]"
        ),
        [1],
        [],
        "CC(C)OC(=O)OCC[Si](C)(C)C",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_alloc"] = (
        smarts("[O;D2:1]-;!@[C;z2;y3](=O)[O;D2;y0]-[C;D2;z1;y1][C;D2;y0;z2]=[C;D1]"),
        [1],
        [],
        "CC(C)OC(=O)OCC=C",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_tms"] = (
        smarts("[O;D2:1]-;!@[Si;D4;z1;y1]([C;D1])([C;D1])[C;D1]"),
        [1],
        [],
        "CC(C)O[Si](C)(C)C",
        "CC(C)O",
        ["CC(C)O[SiH](C)C", "CC(C)O[Si](C)(C)OC", "CC(C)O[Si](C)(C)CC"],
    )

    rules["hydroxyl_tes"] = (
        smarts(
            "[O;D2:1]-;!@[Si;D4;z1;y1]([C;D2;y1;z1][C;D1])([C;D2;y1;z1][C;D1])[C;D2;y1;z1][C;D1]"
        ),
        [1],
        [],
        "CC(C)O[Si](CC)(CC)CC",
        "CC(C)O",
        ["CC(C)O[SiH](C)C", "CC(C)O[Si](C)(C)OC"],
    )

    rules["hydroxyl_tbs"] = (
        smarts(
            "[O;D2:1]-;!@[Si;D4;z1;y1]([C;D1])([C;D1])[C;D4;y1;z1]([C;D1])([C;D1])[C;D1]"
        ),
        [1],
        [],
        "CC(C)O[Si](C)(C)C(C)(C)C",
        "CC(C)O",
        ["CC(C)O[SiH](C)C", "CC(C)O[Si](C)(C)OC"],
    )

    rules["hydroxyl_tips"] = (
        smarts(
            "[O;D2:1]-;!@[Si;D4;z1;y1]([C;D3;z1;y1]([C;D1])[C;D1])([C;D3;z1;y1]([C;D1])[C;D1])[C;D3;z1;y1]([C;D1])[C;D1]"
        ),
        [1],
        [],
        "CC(C)O[Si](C(C)C)(C(C)C)C(C)C",
        "CC(C)O",
        ["CC(C)O[SiH](C)C", "CC(C)O[Si](C)(C)OC"],
    )

    rules["hydroxyl_tbdps"] = (
        smarts(
            "[O;D2:1]-;!@[Si;D4;z1;y1]([C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)([C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)[C;D4;y1;z1]([C;D1])([C;D1])[C;D1]"
        ),
        [1],
        [],
        "CC(C)O[Si](c1ccccc1)(c1ccccc1)C(C)(C)C",
        "CC(C)O",
        ["CC(C)O[SiH](C)C", "CC(C)O[Si](c1ccc(C)cc1)(c1ccccc1)C(C)(C)C"],
    )

    rules["hydroxyl_o_nitrobenzyl"] = (
        smarts(
            "[O;D2:1]-;!@[C;D2;z1;y1]-[C;a;r6]:1:[C;D3;y1]([N+](=O)[O-]):[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)OCc1c([N+](=O)[O-])cccc1",
        "CC(C)O",
        ["CC(C)OC(OC)c1c(N(=O)=O)cccc1"],
    )

    rules["hydroxyl_methoxy_benzyl"] = (
        smarts(
            "[O;D2:1]-;!@[C;D2;z1;y1]-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)OCc1ccc(OC)cc1",
        "CC(C)O",
        ["CC(C)OCc1ccc(OCC)cc1", "CC(C)OCc1cc(OC)ccc1"],
    )

    rules["hydroxyl_dimethoxybenzyl"] = (
        smarts(
            "[O;D2:1]-;!@[C;D2;z1;y1]-[C;a;r6]:1:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)OCc1c(OC)cc(OC)cc1",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_naphthyl"] = (
        smarts(
            "[O;D2:1]-;!@[C;D2;z1;y1]-[C;a;r6]:1:[C;D2]:[C;D3]:2:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D3]:2:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)OCc1ccc2ccccc2c1",
        "CC(C)O",
        ["CC(C)OCc1ccccc1"],
    )

    rules["hydroxyl_bom"] = (
        smarts(
            "[O;D2:1]-;!@[C;D2;y2;z1][O;D2;y0][C;D2;z1;y1]-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)OCOCc1ccccc1",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_piv"] = (
        smarts("[O;D2:1]-;!@[C;z2;y2](=O)-[C;D4;y0;z1]([C;D1])([C;D1])[C;D1]"),
        [1],
        [],
        "CC(C)OC(=O)C(C)(C)C",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_methoxy_benzoate"] = (
        smarts(
            "[O;D2:1]-;!@[C;z2;y2](=O)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)OC(=O)c1ccc(OC)cc1",
        "CC(C)O",
        ["C1=CC=C(C=C1)C(=O)OC(C)C"],
    )

    rules["hydroxyl_benzoate"] = (
        smarts(
            "[O;D2:1]-;!@[C;z2;y2](=O)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)OC(=O)c1ccccc1",
        "CC(C)O",
        ["COC1=CC=C(C=C1)C(=O)OC(C)C"],
    )

    rules["hydroxyl_tfa"] = (
        smarts("[O;D2:1]-;!@[C;z2;y2](=O)-[C;D4;z1;y3](F)(F)F"),
        [1],
        [],
        "CC(C)OC(=O)C(F)(F)F",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_mom"] = (
        smarts("[O;D2:1]-;!@[C;D2;y2;z1][O;D2;y0][C;D1]"),
        [1],
        [],
        "CC(C)OCOC",
        "CC(C)O",
        ["CC(C)OC(C)OC"],
    )

    rules["hydroxyl_mem"] = (
        smarts(
            "[O;D2:1]-;!@[C;D2;y2;z1][O;D2;y0][C;D2;z1;y1][C;D2;z1;y1][O;D2;y0][C;D1]"
        ),
        [1],
        [],
        "COCCOCOC(C)C",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_thp"] = (
        smarts("[O;D2:1]-;!@[C;D3;y2;z1;r6]1[O;D2][C;D2][C;D2][C;D2][C;D2]1"),
        [1],
        [],
        "CC(C)OC1CCCCO1",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_ee"] = (
        smarts("[O;D2:1]-;!@[C;D3;y2;z1]([O;D2;y0][C;D2;y1;z1][C;D1])[C;D1]"),
        [1],
        [],
        "CC(C)OC(C)OCC",
        "CC(C)O",
        ["CC(C)OC(CC)OCC"],
    )

    rules["hydroxyl_mop"] = (
        smarts("[O;D2:1]-;!@[C;D4;y2;z1]([O;D2;y0][C;D1])([C;D1])[C;D1]"),
        [1],
        [],
        "CC(C)OC(C)(C)OC",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_sem"] = (
        smarts(
            "[O;D2:1]-;!@[C;D2;y2;z1][O;D2;y0][C;D2;z1;y1][C;D2;z1;y1][Si;D4;z1;y0]([C;D1])([C;D1])[C;D1]"
        ),
        [1],
        [],
        "CC(C)OCOCC[Si](C)(C)C",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_tritil"] = (
        smarts(
            "[O;D2:1]-;!@[C;D4;z1;y1](-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)(-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)OC(c1ccccc1)(c1ccccc1)c1ccccc1",
        "CC(C)O",
        ["COc1ccc(cc1)C(OC(C)C)(c1ccccc1)c1ccc(OC)cc1"],
    )

    rules["hydroxyl_dimetoxy_tritil"] = (
        smarts(
            "[O;D2:1]-;!@[C;D4;z1;y1](-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1)(-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "COc1ccc(cc1)C(OC(C)C)(c1ccccc1)c1ccc(OC)cc1",
        "CC(C)O",
        ["CC(C)OC(c1ccccc1)(c1ccccc1)c1ccccc1"],
    )

    rules["hydroxyl_chloro_tritil"] = (
        smarts(
            "[O;D2:1]-;!@[C;D4;z1;y1](-[C;a;r6]:1:[C;D3;y1]([Cl;D1]):[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)(-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)OC(c1c(Cl)cccc1)(c1ccccc1)c1ccccc1",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_mmt"] = (
        smarts(
            "[O;D2:1]-;!@[C;D4;z1;y1](-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1)(-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "c1ccc(cc1)C(OC(C)C)(c1ccccc1)c1ccc(OC)cc1",
        "CC(C)O",
        ["CC(C)OC(c1ccccc1)(c1ccccc1)c1ccccc1"],
    )

    rules["hydroxyl_mpe"] = (
        smarts(
            "[O;D2:1]-;!@[C;D4;y1;z1]([C;D1])([C;D2;y0;z1][C;D1])[C;D2;y0;z1][C;D1]"
        ),
        [1],
        [],
        "CC(C)OC(CC)(CC)C",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_trifluoroethyl"] = (
        smarts("[O;D2:1]-;!@[C;D2;y1;z1][C;D4;y3;z1](F)(F)F"),
        [1],
        [],
        "CC(C)OCC(F)(F)F",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_dmab_enamine"] = (
        smarts(
            "[O;D2:1]-;!@[C;D2;y1;z1]-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y1](:[C;D2]:[C;D2]:1)-[N;D2;y0;z1]-[C;z2;y1;D3]([C;D2;y0;z1][C;D3;y0;z1]([C;D1])[C;D1])=[C;D3;r6;y0;z2]1[C;y1;z2;D3](=O)[C;D2][C;D4;y0;z1]([C;D1])([C;D1])[C;D2][C;D3;y1;z2]1=O"
        ),
        [1],
        [],
        "CC(C)CC(Nc1ccc(COC(C)=O)cc1)=C1C(=O)CC(C)(C)CC1=O",
        "CC(O)=O",
        [],
    )

    rules["hydroxyl_dmab_imine"] = (
        smarts(
            "[O;D2:1]-;!@[C;D2;y1;z1]-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y1](:[C;D2]:[C;D2]:1)-[N;D2;y0;z2]=[C;y1;D3]([C;D2;y0;z1][C;D3;y0;z1]([C;D1])[C;D1])-[C;D3;r6;y0;z1]1[C;y1;z2;D3](=O)[C;D2][C;D4;y0;z1]([C;D1])([C;D1])[C;D2][C;D3;y1;z2]1=O"
        ),
        [1],
        [],
        "CC(C)CC(=Nc1ccc(COC(C)=O)cc1)C1C(=O)CC(C)(C)CC1=O",
        "CC(O)=O",
        [],
    )

    rules["diol_12_acetone"] = (
        smarts(
            "[O;D2;y0;r5:1]1-;@[C;D4;y2;z1]([C;D1])([C;D1])-[O;D2;y0:2][C:3]!#[C:4]1"
        ),
        [1, 2, 3, 4],
        [],
        "CC1COC(C)(C)O1",
        "CC(O)CO",
        [],
    )

    rules["diol_13_acetone"] = (
        smarts(
            "[O;D2;y0;r6:1]1-;@[C;D4;y2;z1]([C;D1])([C;D1])-[O;D2;y0:2][C:3][C:4]!#[C:5]1"
        ),
        [1, 2, 3, 4, 5],
        [],
        "CC1CCOC(C)(C)O1",
        "CC(O)CCO",
        [],
    )

    rules["hydroxyl_amine_acetone"] = (
        smarts("[O;D2;y0;r5:1]1-;@[C;D4;y2;z1]([C;D1])([C;D1])-[N;z1:2][C:3]!#[C:4]1"),
        [1, 2, 3, 4],
        [],
        "CC1CN(C(C)=O)C(C)(C)O1",
        "CC(O)CNC(C)=O",
        [],
    )

    rules["diol_12_formalin"] = (
        smarts("[O;D2;y0;r5:1]1-;@[C;D2;y2;z1]-[O;D2;y0:2][C:3]!#[C:4]1"),
        [1, 2, 3, 4],
        [],
        "CC1COCO1",
        "CC(O)CO",
        [],
    )

    rules["diol_13_formalin"] = (
        smarts("[O;D2;y0;r6:1]1-;@[C;D2;y2;z1]-[O;D2;y0:2][C:3][C:4]!#[C:5]1"),
        [1, 2, 3, 4, 5],
        [],
        "CC1CCOCO1",
        "CC(O)CCO",
        [],
    )

    rules["diol_12_cyclopentanone"] = (
        smarts(
            "[O;D2;y0;r5:1]1-;@[C;D4;y2;z1]2([C;D2;y0;z1][C;D2;y0;z1][C;D2;y0;z1][C;D2;y0;z1]2)-[O;D2;y0:2][C:3]!#[C:4]1"
        ),
        [1, 2, 3, 4],
        [],
        "CC1COC2(CCCC2)O1",
        "CC(O)CO",
        [],
    )

    rules["diol_13_cyclopentanone"] = (
        smarts(
            "[O;D2;y0;r6:1]1-;@[C;D4;y2;z1]2([C;D2;y0;z1][C;D2;y0;z1][C;D2;y0;z1][C;D2;y0;z1]2)-[O;D2;y0:2][C:3][C:4]!#[C:5]1"
        ),
        [1, 2, 3, 4, 5],
        [],
        "CC1CCOC2(CCCC2)O1",
        "CC(O)CCO",
        [],
    )

    rules["diol_12_cyclohexanone"] = (
        smarts(
            "[O;D2;y0;r5:1]1-;@[C;D4;y2;z1]2([C;D2;y0;z1][C;D2;y0;z1][C;D2;y0;z1][C;D2;y0;z1][C;D2;y0;z1]2)-[O;D2;y0:2][C:3]!#[C:4]1"
        ),
        [1, 2, 3, 4],
        [],
        "CC1COC2(CCCCC2)O1",
        "CC(O)CO",
        [],
    )

    rules["diol_13_cyclohexanone"] = (
        smarts(
            "[O;D2;y0;r6:1]1-;@[C;D4;y2;z1]2([C;D2;y0;z1][C;D2;y0;z1][C;D2;y0;z1][C;D2;y0;z1][C;D2;y0;z1]2)-[O;D2;y0:2][C:3][C:4]!#[C:5]1"
        ),
        [1, 2, 3, 4, 5],
        [],
        "CC1CCOC2(CCCCC2)O1",
        "CC(O)CCO",
        [],
    )

    rules["diol_12_diacetal"] = (
        smarts(
            "[O;D2;y0;r6:1]1-;@[C;D4;y2;z1]([O;D2;y0][C;D1])([C;D1])[C;D4;y2;z1]([O;D2;y0][C;D1])([C;D1])-[O;D2;y0:2][C:3]!#[C:4]1"
        ),
        [1, 2, 3, 4],
        [],
        "COC1(C)OCC(C)OC1(C)OC",
        "CC(O)CO",
        [],
    )

    rules["diol_13_diacetal"] = (
        smarts(
            "[O;D2;y0;r7:1]1-;@[C;D4;y2;z1]([O;D2;y0][C;D1])([C;D1])[C;D4;y2;z1]([O;D2;y0][C;D1])([C;D1])-[O;D2;y0:2][C:3][C:4]!#[C:5]1"
        ),
        [1, 2, 3, 4, 5],
        [],
        "COC1(C)OCCC(C)OC1(C)OC",
        "CC(O)CCO",
        [],
    )

    rules["diol_12_benzylidene"] = (
        smarts(
            "[O;D2;y0;r5:1]1-;@[C;D3;y2;z1]([C;a;r6]:2:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:2)-[O;D2;y0:2][C:3]!#[C:4]1"
        ),
        [1, 2, 3, 4],
        [],
        "CC1COC(O1)c1ccccc1",
        "CC(O)CO",
        [],
    )

    rules["diol_13_benzylidene"] = (
        smarts(
            "[O;D2;y0;r6:1]1-;@[C;D3;y2;z1]([C;a;r6]:2:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:2)-[O;D2;y0:2][C:3][C:4]!#[C:5]1"
        ),
        [1, 2, 3, 4, 5],
        [],
        "CC1CCOC(O1)c1ccccc1",
        "CC(O)CCO",
        [],
    )

    rules["carbonyl_dithiolane"] = (
        smarts(
            "[C;D3,D4;z1;y2;r5:1]1[S;D2;y0;z1][C;D2;y1;z1][C;D2;y1;z1][S;D2;y0;z1]1"
        ),
        [1],
        [(1, "O", 2)],
        "CC1SCCS1",
        "CC=O",
        [],
    )

    rules["carbonyl_dithiane"] = (
        smarts(
            "[C;D3,D4;z1;y2;r6:1]1[S;D2;y0;z1][C;D2;y1;z1][C;D2;y0;z1][C;D2;y1;z1][S;D2;y0;z1]1"
        ),
        [1],
        [(1, "O", 2)],
        "CC1SCCCS1",
        "CC=O",
        [],
    )

    rules["carbonyl_dimethylsulfide"] = (
        smarts("[C;D3,D4;z1;y2:1](-;!@[S;D2][C;D1])-;!@[S;D2][C;D1]"),
        [1],
        [(1, "O", 2)],
        "CSC(CC)SC",
        "CCC=O",
        [],
    )

    rules["carbonyl_dioxolane"] = (
        smarts("[C;D3,D4;z1;y2;r5:1]1[O;D2;y0][C;D2;y1;z1][C;D2;y1;z1][O;D2;y0]1"),
        [1],
        [(1, "O", 2)],
        "CC1OCCO1",
        "CC=O",
        [],
    )

    rules["carbonyl_dioxane"] = (
        smarts(
            "[C;D3,D4;z1;y2;r6:1]1[O;D2;y0][C;D2;y1;z1][C;D2;y0;z1][C;D2;y1;z1][O;D2;y0]1"
        ),
        [1],
        [(1, "O", 2)],
        "CC1OCCCO1",
        "CC=O",
        [],
    )

    rules["carbonyl_dimethoxy"] = (
        smarts("[C;D3,D4;z1;y2:1](-;!@[O;D2;y0][C;D1])-;!@[O;D2;y0][C;D1]"),
        [1],
        [(1, "O", 2)],
        "COC(C)OC",
        "CC=O",
        [],
    )

    rules["carboxyl_trioxabicyclooctane"] = (
        smarts(
            "[C;D4;y3;r6:1]12-;@[O;D2][C;D2;y1;z1][C;D4;y0;z1]([C;D1])([C;D2;y1;z1][O;D2]1)[C;D2;y1;z1][O;D2]2"
        ),
        [1],
        [(1, "O", 2), (1, "O", 1)],
        "CC(C)C12OCC(C)(CO1)CO2",
        "CC(C)C(O)=O",
        ["CC(C)C12OCC(CC)(CO1)CO2", "CC(C)C12OC(C)C(C)(CO1)CO2"],
    )

    rules["alkyne_tms"] = (
        smarts("[C:1]#[C;D2:2]-;!@[Si;D4]([C;D1;H3])([C;D1;H3])[C;D1;H3]"),
        [1, 2],
        [],
        "CC#C[Si](C)(C)C",
        "CC#C",
        ["CC#C[Si](CC)(C)C", "CC=[CH][Si](C)(C)C", "CO[Si](C)(C)C"],
    )

    rules["carboxyl_tmse"] = (
        smarts(
            "[C:1](=[O;D1])-[O;D2]-[C;D2;H2]-[C;D2;H2]-[Si;D4]([C;D1;H3])([C;D1;H3])[C;D1;H3]"
        ),
        [1],
        [(1, "O", 1)],
        "CC(=O)OCC[Si](C)(C)C",
        "CC(=O)O",
        [
            "CC(=O)OC",
            "CC(=O)OCC",
            "CC(=O)OC[Si](C)(C)C",
            "CC(=O)OCCC[Si](C)(C)C",
            "CC(=O)OCC[Si](CC)(C)C",
        ],
    )

    rules["carboxyl_methyl"] = (
        smarts("[C:1](=[O;D1])-[O;D2]-[C;D1;H3]"),
        [1],
        [(1, "O", 1)],
        "CC(=O)OC",
        "CC(=O)O",
        ["CC(=O)OCC", "CC(=O)OCCC", "CC(=O)OCC[Si](C)(C)C"],
    )

    rules["carboxyl_ethyl"] = (
        smarts("[C:1](=[O;D1])-[O;D2]-[C;D2]-[C;D1]"),
        [1],
        [(1, "O", 1)],
        "CC(=O)OCC",
        "CC(=O)O",
        ["CC(=O)OC"],
    )

    rules["carboxyl_butyl"] = (
        smarts("[C:1](=[O;D1])-[O;D2]-[C;D2]-[C;D2]-[C;D2]-[C;D1]"),
        [1],
        [(1, "O", 1)],
        "CC(=O)OCCCC",
        "CC(=O)O",
        [],
    )

    rules["amine_methylcarbamate"] = (
        smarts("[N;D2,D3:1]-;!@[C;z2;y3](=O)[O;D2;y0][C;D1]"),
        [1],
        [],
        "c1ccccc1NC(=O)OC",
        "c1ccccc1N",
        ["c1ccccc1NC(=O)OCC"],
    )

    rules["amine_acetamide"] = (
        smarts("[N;D2,D3:1]-;!@[C;z2;y2](=O)[C;D1]"),
        [1],
        [],
        "CC(=O)Nc1ccccc1",
        "c1ccccc1N",
        [],
    )

    # Requested project ID: amine_tbh. Chemically this is pivaloyl (Piv), not Boc.
    rules["amine_tbh"] = (
        smarts("[N;D2,D3:1]-;!@[C;D3;z2;y2](=O)[C;D4;z1;y0]([C;D1])([C;D1])[C;D1]"),
        [1],
        [],
        "CC(C)(C)C(=O)Nc1ccccc1",
        "Nc1ccccc1",
        [
            "CC(C)(C)OC(=O)Nc1ccccc1",
            "CC(=O)Nc1ccccc1",
            "CC(C)C(=O)Nc1ccccc1",
            "CC(C)(C)C(=O)Oc1ccccc1",
        ],
    )

    rules["amine_ethylcarbamate"] = (
        smarts("[N;D2,D3:1]-;!@[C;z2;y3](=O)[O;D2;y0][C;D2;y1;z1][C;D1]"),
        [1],
        [],
        "c1ccccc1NC(=O)OCC",
        "c1ccccc1N",
        [],
    )

    rules["amine_alloc"] = (
        smarts("[N;D2,D3:1]-;!@[C;z2;y3](=O)[O;D2;y0]-[C;D2;z1;y1][C;D2;y0;z2]=[C;D1]"),
        [1],
        [],
        "c1ccccc1NC(=O)OCC=C",
        "c1ccccc1N",
        ["c1ccccc1NC(=O)OCC=CC"],
    )

    rules["amine_teoc"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;z2;y3](=O)[O;D2;y0]-[C;D2;z1;y1][C;D2;y1;z1][Si;D4;z1;y0]([C;D1])([C;D1])[C;D1]"
        ),
        [1],
        [],
        "c1ccccc1NC(=O)OCC[Si](C)(C)C",
        "c1ccccc1N",
        [],
    )

    # MEM also masks sulfonamide NH; retain the original nitrogen on cleavage.
    rules["amine_mem"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;D2;y2;z1][O;D2;y0][C;D2;z1;y1][C;D2;z1;y1][O;D2;y0][C;D1]"
        ),
        [1],
        [],
        "CS(=O)(=O)N(c1ccccc1)COCCOC",
        "CS(=O)(=O)Nc1ccccc1",
        ["CN(C)COC", "CN(C)COCC[Si](C)(C)C", "CN(C)CCOCC", "COCCOCOc1ccccc1"],
    )

    rules["amine_sem"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;D2;y2;z1][O;D2;y0]-[C;D2;z1;y1][C;D2;y1;z1][Si;D4;z1;y0]([C;D1])([C;D1])[C;D1]"
        ),
        [1],
        [],
        "CN(C)COCC[Si](C)(C)C",
        "CNC",
        [],
    )

    rules["amine_troc"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;z2;y3](=O)[O;D2;y0]-[C;D2][C;D4;y3]([Cl;D1])([Cl;D1])[Cl;D1]"
        ),
        [1],
        [],
        "c1ccccc1NC(=O)OCC(Cl)(Cl)Cl",
        "c1ccccc1N",
        ["c1ccccc1NC(=O)OC(C)C(Cl)(Cl)Cl"],
    )

    rules["amine_cbz"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;z2;y3](=O)-[O;D2;y0][C;D2;y1;z1][C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "c1ccccc1NC(=O)OCc2ccccc2",
        "c1ccccc1N",
        ["c1ccccc1NC(=O)OC(C)c2ccccc2"],
    )

    rules["amine_chloro_cbz"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;z2;y3](=O)-[O;D2;y0][C;D2;y1;z1][C;a;r6]:1:[C;D3;y1]([Cl;D1]):[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "Clc1ccccc1COC(=O)Nc1ccccc1",
        "c1ccccc1N",
        ["c1ccccc1NC(=O)OC(C)c2ccccc2"],
    )

    rules["amine_phenylsulfonyl"] = (
        smarts(
            "[N;D2,D3:1]-;!@[S;D4;y3](=O)(=O)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "c1ccccc1S(=O)(=O)Nc1ccccc1",
        "c1ccccc1N",
        [],
    )

    rules["amine_tosyl"] = (
        smarts(
            "[N;D2,D3:1]-;!@[S;D4;y3](=O)(=O)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y0]([C;D1]):[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "Cc1ccc(cc1)S(=O)(=O)Nc1ccccc1",
        "c1ccccc1N",
        [],
    )

    rules["amine_nosyl"] = (
        smarts(
            "[N;D2,D3:1]-;!@[S;D4;y3](=O)(=O)-[C;a;r6]:1:[C;D3;y1]([N+](=O)[O-]):[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "[O-][N+](=O)c1ccccc1S(=O)(=O)Nc1ccccc1",
        "c1ccccc1N",
        [],
    )

    rules["amine_boc"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;z2;y3](=O)-[O;D2;y0]-[C;D4;y1;z1]([C;D1])([C;D1])[C;D1]"
        ),
        [1],
        [],
        "c1ccccc1NC(=O)OC(C)(C)C",
        "c1ccccc1N",
        [],
    )

    rules["amine_tfa"] = (
        smarts("[N;D2,D3:1]-;!@[C;z2;y2](=O)-[C;D4;z1;y3](F)(F)F"),
        [1],
        [],
        "CNC(=O)C(F)(F)F",
        "CN",
        [],
    )

    rules["amine_fmoc"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;z2;y3](=O)[O;D2;y0]-[C;D2;y1;z1][C;D3;z1;y0;r5]1[C;a;r6]:2:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D3]:2-[C;a;r6]:3:[C;D2]:[C;D2]:[C;D2]:[C;D2]:C1:3"
        ),
        [1],
        [],
        "O=C(Nc1ccccc1)OCC1c2ccccc2-c2ccccc12",
        "c1ccccc1N",
        [],
    )

    rules["amine_pbf"] = (
        smarts(
            "[N;D2,D3:1]-;!@[S;D4;y3](=O)(=O)-[C;a;r6]:1:[C;D3;y0]([C;D1]):[C;D3;y0]([C;D1]):[C;D3;y1]:2-[O;D2;y0;r5][C;D4;y1]([C;D1])([C;D1])[C;D2;y0;z1][C;D3]:2:[C;D3;y0]([C;D1]):1"
        ),
        [1],
        [],
        "CN(C)S(=O)(=O)c1c(C)c2CC(C)(C)Oc2c(C)c1C",
        "CNC",
        [],
    )

    rules["amine_mtr"] = (
        smarts(
            "[N;D2,D3:1]-;!@[S;D4;y3](=O)(=O)-[C;a;r6]:1:[C;D3;y0]([C;D1]):[C;D3;y0]([C;D1]):[C;D3;y1](-;!@[O;D2;y0][C;D1]):[C;D2]:[C;D3;y0]([C;D1]):1"
        ),
        [1],
        [],
        "COc1c(C)c(C)c(S(=O)(=O)N(C)C)c(C)c1",
        "CNC",
        [],
    )

    rules["amine_dde_enamine"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;z2;y1;D3]([C;D1])=[C;D3;r6;y0;z2]1[C;y1;z2;D3](=O)[C;D2][C;D4;y0;z1]([C;D1])([C;D1])[C;D2][C;D3;y1;z2]1=O"
        ),
        [1],
        [],
        "CC(C)NC(C)=C1C(=O)CC(C)(C)CC1=O",
        "CC(C)N",
        [],
    )

    rules["amine_dde_imine"] = (
        smarts(
            "[N;D2:1]=;!@[C;y1;D3]([C;D1])-[C;D3;r6;y0;z1]1[C;y1;z2;D3](=O)[C;D2][C;D4;y0;z1]([C;D1])([C;D1])[C;D2][C;D3;y1;z2]1=O"
        ),
        [1],
        [],
        "CC(C)N=C(C)C1C(=O)CC(C)(C)CC1=O",
        "CC(C)N",
        [],
    )

    rules["amine_ivdde_enamine"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;z2;y1;D3]([C;D2;y0;z1][C;D3;y0;z1]([C;D1])[C;D1])=[C;D3;r6;y0;z2]1[C;y1;z2;D3](=O)[C;D2][C;D4;y0;z1]([C;D1])([C;D1])[C;D2][C;D3;y1;z2]1=O"
        ),
        [1],
        [],
        "CC(C)CC(NC(C)C)=C1C(=O)CC(C)(C)CC1=O",
        "CC(C)N",
        [],
    )

    rules["amine_ivdde_imine"] = (
        smarts(
            "[N;D2:1]=;!@[C;y1;D3]([C;D2;y0;z1][C;D3;y0;z1]([C;D1])[C;D1])-[C;D3;r6;y0;z1]1[C;y1;z2;D3](=O)[C;D2][C;D4;y0;z1]([C;D1])([C;D1])[C;D2][C;D3;y1;z2]1=O"
        ),
        [1],
        [],
        "CC(C)CC(=NC(C)C)C1C(=O)CC(C)(C)CC1=O",
        "CC(C)N",
        [],
    )

    rules["amine_benzyl"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;D2;z1;y1]-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)NCc1ccccc1",
        "CC(C)N",
        [],
    )

    rules["amine_methoxy_benzyl"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;D2;z1;y1]-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)NCc1ccc(OC)cc1",
        "CC(C)N",
        [],
    )

    rules["amine_dimethoxybenzyl"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;D2;z1;y1]-[C;a;r6]:1:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)NCc1c(OC)cc(OC)cc1",
        "CC(C)N",
        [],
    )

    rules["amine_mtt"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;D4;z1;y1](-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y0]([C;D1]):[C;D2]:[C;D2]:1)(-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)NC(c1ccccc1)(c1ccccc1)c1ccc(C)cc1",
        "CC(C)N",
        [],
    )

    rules["amine_bhoc"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;z2;y3](=O)[O;D2;y0]-[C;D3;z1;y1](-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CNC(=O)OC(c1ccccc1)c1ccccc1",
        "CN",
        [],
    )

    rules["amine_tritil"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;D4;z1;y1](-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)(-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)NC(c1ccccc1)(c1ccccc1)c1ccccc1",
        "CC(C)N",
        [],
    )

    rules["amine_chloro_tritil"] = (
        smarts(
            "[N;D2,D3:1]-;!@[C;D4;z1;y1](-[C;a;r6]:1:[C;D3;y1]([Cl;D1]):[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)(-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)NC(c1c(Cl)cccc1)(c1ccccc1)c1ccccc1",
        "CC(C)N",
        [],
    )

    # N-protected aromatic heterocycles are distinct from non-aromatic amines.
    # Explicit [n] patterns avoid broadening the existing [N] rule semantics.
    rules["heteroaryl_n_tosyl"] = (
        smarts(
            "[n;D3:1]-;!@[S;D4;y3](=O)(=O)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y0]([C;D1]):[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "Cc1ccc(S(=O)(=O)n2cccc2)cc1",
        "[nH]1cccc1",
        ["Cc1ccc(S(=O)(=O)NC)cc1", "O=S(=O)(c1ccccc1)n1cccc1"],
    )

    rules["heteroaryl_n_thp"] = (
        smarts("[n;D3:1]-;!@[C;D3;y2;z1;r6]1[O;D2][C;D2][C;D2][C;D2][C;D2]1"),
        [1],
        [],
        "c1ccn(C2CCCCO2)c1",
        "[nH]1cccc1",
        ["CNC1CCCCO1", "c1ccn(C2CCCO2)c1", "c1ccn(C2CCCCC2)c1"],
    )

    rules["heteroaryl_n_boc"] = (
        smarts(
            "[n;D3:1]-;!@[C;z2;y3](=O)-[O;D2;y0]-[C;D4;y1;z1]([C;D1])([C;D1])[C;D1]"
        ),
        [1],
        [],
        "CC(C)(C)OC(=O)n1cccc1",
        "[nH]1cccc1",
        ["CC(C)(C)OC(=O)NC", "COC(=O)n1cccc1", "CC(=O)n1cccc1"],
    )

    rules["heteroaryl_n_sem"] = (
        smarts(
            "[n;D3:1]-;!@[C;D2;y2;z1][O;D2;y0]-[C;D2;z1;y1][C;D2;y1;z1][Si;D4;z1;y0]([C;D1])([C;D1])[C;D1]"
        ),
        [1],
        [],
        "C[Si](C)(C)CCOCn1cccc1",
        "[nH]1cccc1",
        ["C[Si](C)(C)CCOCNC", "COCn1cccc1", "C[Si](C)(C)COCn1cccc1"],
    )

    # Cleavage must remove both imide carbonyl attachments while retaining N.
    rules["amine_phthalimide"] = (
        smarts(
            "[N;D3;y0:1]1-[C;D3;z2](=[O;D1])-[c;r6]2:[c;D2]:[c;D2]:[c;D2]:[c;D2]:[c;r6]:2-[C;D3;z2]-1=[O;D1]"
        ),
        [1],
        [],
        "CCN1C(=O)c2ccccc2C1=O",
        "CCN",
        [
            "O=C1NC(=O)c2ccccc21",
            "CN1C(=O)CCC1=O",
            "CN1C(=O)c2ccccc2C1",
            "ON1C(=O)c2ccccc2C1=O",
        ],
    )

    rules["thiol_tritil"] = (
        smarts(
            "[S;D2;y0;z1:1]-;!@[C;D4;z1;y1](-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)(-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)SC(c1ccccc1)(c1ccccc1)c1ccccc1",
        "CC(C)S",
        [],
    )

    rules["thiol_mmt"] = (
        smarts(
            "[S;D2;y0;z1:1]-;!@[C;D4;z1;y1](-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1)(-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "c1ccc(cc1)C(SC(C)C)(c1ccccc1)c1ccc(OC)cc1",
        "CC(C)S",
        [],
    )

    rules["thiol_dimetoxy_tritil"] = (
        smarts(
            "[S;D2;y0;z1:1]-;!@[C;D4;z1;y1](-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1)(-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "COc1ccc(cc1)C(SC(C)C)(c1ccccc1)c1ccc(OC)cc1",
        "CC(C)S",
        [],
    )

    rules["thiol_chloro_tritil"] = (
        smarts(
            "[S;D2;y0;z1:1]-;!@[C;D4;z1;y1](-[C;a;r6]:1:[C;D3;y1]([Cl;D1]):[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)(-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1)-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)SC(c1c(Cl)cccc1)(c1ccccc1)c1ccccc1",
        "CC(C)S",
        [],
    )

    rules["thiol_benzyl"] = (
        smarts(
            "[S;D2;y0;z1:1]-;!@[C;D2;z1;y1]-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)SCc1ccccc1",
        "CC(C)S",
        [],
    )

    rules["thiol_tbu"] = (
        smarts("[S;D2;y0;z1:1]-;!@[C;D4;y1;z1]([C;D1])([C;D1])[C;D1]"),
        [1],
        [],
        "CC(C)SC(C)(C)C",
        "CC(C)S",
        [],
    )

    rules["thiol_stbu"] = (
        smarts("[S;D2;y1;z1:1]-;!@[S;D2;z1;y1]-[C;D4;y1;z1]([C;D1])([C;D1])[C;D1]"),
        [1],
        [],
        "CC(C)SSC(C)(C)C",
        "CC(C)S",
        [],
    )

    rules["thiol_strimethoxyphenyl"] = (
        smarts(
            "[S;D2;y1;z1:1]-;!@[S;D2;z1;y1]-[C;a;r6]:1:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D3;y1]:1[O;D2;y0][C;D1]"
        ),
        [1],
        [],
        "COc1cc(OC)c(SSC(C)C)c(OC)c1",
        "CC(C)S",
        [],
    )

    rules["thiol_amine_dimethoxybenzyl"] = (
        smarts(
            "[S;D2;r5;y0;z1:1]1[C:3][C:4][N;z1:2]-[C;D3;y2;z1]1-[C;a;r6]:1:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D3;y1]([O;D2;y0][C;D1]):[C;D2]:[C;D2]:1"
        ),
        [1, 2, 3, 4],
        [],
        "COc1ccc(C2NC(C)CS2)c(OC)c1",
        "NC(C)CS",
        [],
    )

    # hydroxyl Boc: O-C(=O)-O-C(C)(C)C  (tert-butoxycarbonyl on O)
    rules["hydroxyl_boc"] = (
        smarts("[O;D2:1]-;!@[C;z2;y3](=O)[O;D2;y0]-[C;D4;y1;z1]([C;D1])([C;D1])[C;D1]"),
        [1],
        [],
        "CC(C)OC(=O)OC(C)(C)C",
        "CC(C)O",
        [],
    )

    # General patterns that are subsets of more specific ones above.
    # Must come last to prevent false matches due to atom overlap.

    rules["hydroxyl_tbu"] = (
        smarts("[O;D2:1]-;!@[C;D4;y1;z1]([C;D1])([C;D1])[C;D1]"),
        [1],
        [],
        "CC(C)OC(C)(C)C",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_allyl"] = (
        smarts("[O;D2:1]-;!@[C;D2;z1;y1][C;D2;y0;z2]=[C;D1]"),
        [1],
        [],
        "CC(C)OCC=C",
        "CC(C)O",
        [],
    )

    rules["hydroxyl_benzyl"] = (
        smarts(
            "[O;D2:1]-;!@[C;D2;z1;y1]-[C;a;r6]:1:[C;D2]:[C;D2]:[C;D2]:[C;D2]:[C;D2]:1"
        ),
        [1],
        [],
        "CC(C)OCc1ccccc1",
        "CC(C)O",
        ["CC(C)OCc1cccc(C)c1", "CC(C)OC(C)c1ccccc1"],
    )

    rules["hydroxyl_acyl"] = (
        smarts("[O;D2:1]-;!@[C;z2;y2](=O)-[C;D1]"),
        [1],
        [],
        "CC(C)OC(=O)C",
        "CC(C)O",
        ["CC(C)OC(=O)CC"],
    )

    rules["hydroxyl_methyl"] = (
        smarts("[O;D2:1]-;!@[C;D1]"),
        [1],
        [],
        "CC(C)OC",
        "CC(C)O",
        ["CC(C)OCC"],
    )

    return rules


rules = Proxy(_rules)


__all__ = ["rules"]
