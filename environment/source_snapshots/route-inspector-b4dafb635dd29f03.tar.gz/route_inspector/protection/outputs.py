from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from route_inspector.infrastructure.artifacts import write_json
from route_inspector.infrastructure.text import write_tsv
from route_inspector.protection.analysis import ProtectionAnalysisResult

ROUTE_STATS_FIELDS = [
    "route_id",
    "target_smiles",
    "n_steps",
    "n_molecule_nodes",
    "n_reaction_nodes",
    "n_in_stock_leaves",
    "n_protecting_groups_total",
    "n_pg_types",
    "pg_types",
    "n_pg_introduced",
    "n_pg_protected_synthon",
    "n_pg_stock",
    "n_pg_ambiguous",
    "n_pg_failed",
    "n_deprotection_events",
    "n_multicenter_deprotection_events",
    "n_deprotective_combo_events",
    "max_simultaneous_pg",
    "mean_pg_lifetime_steps",
    "median_pg_lifetime_steps",
    "n_interval_rrseq_cons",
    "n_unique_interval_rrseq_cons_families",
]

EVENT_FIELDS = [
    "event_id",
    "route_id",
    "target_smiles",
    "pg_type",
    "protected_functional_group",
    "source_type",
    "trace_status",
    "confidence",
    "deprotection_node_id",
    "deprotection_reaction_smiles",
    "protection_node_id",
    "protection_reaction_smiles",
    "stock_node_id",
    "stock_smiles",
    "protected_precursor_smiles",
    "deprotected_product_smiles",
    "protected_atom_ids",
    "source_fragment_atom_ids",
    "protected_substructure_smiles",
    "depth_deprotection_from_target",
    "depth_source_from_target",
    "lifetime_steps",
    "n_intervening_steps",
    "multicenter_status",
    "n_other_reaction_centers",
    "n_matching_pg_sites_before_deprotection",
    "n_sites_deprotected",
    "selective_deprotection",
    "multiple_deprotection_rules",
    "matched_deprotection_rules",
    "failure_reason",
    "interval_reaction_ids",
    "deprotection_reaction_node_path",
    "protected_precursor_molecule_node_path",
    "protection_reaction_node_path",
    "stock_molecule_node_path",
    "interval_reaction_node_paths",
    "protected_molecule_node_paths",
    "trace_last_successful_node_path",
    "trace_last_successful_node_id",
    "trace_last_successful_smiles",
    "trace_candidate_next_nodes",
    "trace_n_candidate_traces",
    "trace_debug_message",
]

INTERVAL_RULE_FIELDS = [
    "event_id",
    "route_id",
    "pg_type",
    "trace_status",
    "interval_step_ids",
    "interval_reaction_smiles",
    "single_step_rules",
    "rrseq_size",
    "rrseq_smarts",
    "rrseq_querycgr",
    "rrseq_querycgr_hash",
    "rrseq_family_id",
    "rrseq_support_in_routes",
    "is_full_interval_rule",
    "is_adjacent_window_rule",
    "macro_depth_saving",
    "min_distance_pg_to_reaction_center",
    "median_distance_pg_to_reaction_center",
    "first_reaction_after_source",
    "last_reaction_before_deprotection",
]

SINGLE_RULE_FIELDS = [
    "source_pg_type",
    "rule",
    "route_count",
    "rule_count",
    "route_ids",
]

AGG_SINGLE_RULE_FIELDS = [
    "rule",
    "pg_types",
    "route_count",
    "rulec_count",
    "route_ids",
]

GROUP_SUMMARY_FIELDS = [
    "pg_type",
    "popularity",
    "route_count",
    "target_count",
    "introduced_count",
    "protected_synthon_count",
    "stock_count",
    "ambiguous_count",
    "failed_count",
    "introduction_fraction",
    "protected_synthon_fraction",
    "stock_fraction",
    "failure_fraction",
    "median_lifetime_steps",
    "mean_lifetime_steps",
    "max_lifetime_steps",
    "n_unique_rrseq_cons",
    "n_unique_rrseq_families",
    "top_rrseq_families",
    "top_first_reactions_after_source",
    "top_last_reactions_before_deprotection",
    "top_protected_functional_groups",
    "n_multicenter_deprotection_events",
    "n_deprotective_combo_events",
    "n_selective_deprotections",
    "selective_deprotection_fraction",
]

RULE_FAMILY_FIELDS = [
    "pg_type",
    "rrseq_family_id",
    "family_popularity",
    "route_count",
    "target_count",
    "representative_rrseq_smarts",
    "family_size_rules",
    "median_pairwise_similarity",
    "min_pairwise_similarity",
    "max_pairwise_similarity",
    "example_route_ids",
    "example_event_ids",
    "example_target_smiles",
    "interpretation_label",
]

TRACE_FAILURE_FIELDS = [
    "event_id",
    "route_id",
    "pg_type",
    "deprotection_node_id",
    "deprotection_reaction_node_path",
    "protected_precursor_molecule_node_path",
    "protected_precursor_smiles",
    "protected_atom_ids",
    "trace_status",
    "failure_reason",
    "last_successful_node_id",
    "last_successful_node_path",
    "last_successful_smiles",
    "candidate_next_nodes",
    "n_candidate_traces",
    "debug_message",
]


def dataset_prefix_from_routes_path(routes_json: Path) -> str:
    """Infer the dataset prefix from a routes JSON path.

    Output formatting is kept separate from route tracing so protection analysis can
    write stable TSV and JSON artifacts from the same in-memory results.
    """
    stem = routes_json.stem
    stem = re.sub(r"[-_]?routes$", "", stem)
    return stem or "routes"


def write_protection_outputs(
    result: ProtectionAnalysisResult,
    output_dir: Path,
    *,
    dataset_prefix: str,
) -> dict[str, Any]:
    """Write protection outputs to disk.

    Output formatting is kept separate from route tracing so protection analysis can
    write stable TSV and JSON artifacts from the same in-memory results.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    prefix = output_dir / dataset_prefix
    paths = {
        "route_stats": prefix.with_name(f"{prefix.name}_protection_route_stats.tsv"),
        "events": prefix.with_name(f"{prefix.name}_protection_events.tsv"),
        "interval_rules": prefix.with_name(
            f"{prefix.name}_protection_interval_rules.tsv"
        ),
        "single_rules": prefix.with_name(f"{prefix.name}_protection_single_rules.tsv"),
        "agg_single_rule": prefix.with_name(
            f"{prefix.name}_protection_agg_single_rule.tsv"
        ),
        "group_summary": prefix.with_name(
            f"{prefix.name}_protection_group_summary.tsv"
        ),
        "rule_families": prefix.with_name(
            f"{prefix.name}_protection_rule_families.tsv"
        ),
        "trace_failures": prefix.with_name(
            f"{prefix.name}_protection_trace_failures.tsv"
        ),
        "summary": prefix.with_name("summary.json"),
    }
    for stale_path in (
        prefix.with_name(f"{prefix.name}_protection_network_edges.tsv"),
        prefix.with_name(f"{prefix.name}_protection_free_routes.tsv"),
    ):
        if stale_path.exists():
            stale_path.unlink()

    write_tsv(paths["route_stats"], ROUTE_STATS_FIELDS, result.route_stats_rows)
    write_tsv(paths["events"], EVENT_FIELDS, result.event_rows)
    write_tsv(
        paths["interval_rules"],
        INTERVAL_RULE_FIELDS,
        result.interval_rule_rows,
    )
    write_tsv(
        paths["single_rules"],
        SINGLE_RULE_FIELDS,
        result.single_rule_rows,
    )
    write_tsv(
        paths["agg_single_rule"],
        AGG_SINGLE_RULE_FIELDS,
        result.aggregate_single_rule_rows,
    )
    write_tsv(
        paths["group_summary"],
        GROUP_SUMMARY_FIELDS,
        result.group_summary_rows,
    )
    write_tsv(
        paths["rule_families"],
        RULE_FAMILY_FIELDS,
        result.rule_family_rows,
    )
    write_tsv(
        paths["trace_failures"],
        TRACE_FAILURE_FIELDS,
        result.trace_failure_rows,
    )
    summary = dict(result.summary)
    summary["dataset"] = dataset_prefix
    summary["output_files"] = {key: str(path) for key, path in paths.items()}
    write_json(paths["summary"], summary)

    if result.debug_routes:
        debug_dir = output_dir / "debug" / "routes"
        for route_id, route in result.debug_routes.items():
            safe_route_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(route_id))
            write_json(debug_dir / f"{safe_route_id}.json", {str(route_id): route})

    return {"output_files": {key: str(path) for key, path in paths.items()}}
