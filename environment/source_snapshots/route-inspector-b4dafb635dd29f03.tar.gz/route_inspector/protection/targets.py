"""Target-anchored structural PG candidates with exact mapped branch lineage."""

import hashlib
import json
from dataclasses import dataclass, field

from route_inspector import chemistry
from route_inspector.protection.analysis import (
    DeprotectionEvent,
    _mapped_fragment_signature,
    matching_site_mappings,
    phthalimide_nitrogen_donor,
    protected_functional_group,
)


@dataclass
class TargetProtectionEvent(DeprotectionEvent):
    endpoint_kind: str = "target"
    target_annotations: dict = field(default_factory=dict)


def target_protection_events(index, route_id, rules, config):
    """Trace actual target patterns; never infer retention from PG type alone."""
    parsed = {}

    def molecule(node_id):
        if node_id not in parsed:
            parsed[node_id] = chemistry.parse_molecule(
                index.molecule_records[node_id].smiles
            )
        return parsed[node_id]

    root_id = next(k for k, v in index.molecule_records.items() if not v.node_path)
    target = molecule(root_id)
    sites = []
    seen = set()
    for rule in rules.values():
        for anchors, mapping in matching_site_mappings(target, rule):
            matched = frozenset(mapping.values())
            key = (rule.name, tuple(sorted(anchors)), matched)
            if key not in seen:
                sites.append((rule, tuple(sorted(anchors)), matched))
                seen.add(key)
    # A generic ether embedded in a fully matched carbamate/acetal is not
    # an additional protected substrate. Keep maximal structural witnesses;
    # equally specific, chemically ambiguous interpretations remain explicit.
    sites = [
        (r, a, m)
        for r, a, m in sites
        if not any(m < other_m and set(a) <= other_m for _, _, other_m in sites)
    ]
    events = []
    for rule, anchors, matched in sites:
        if phthalimide_nitrogen_donor(index, rule.name, root_id, anchors, matched):
            continue
        mask = matched - set(anchors)
        current = root_id
        visited, mol_ids = [], []
        source = "unknown"
        reason = "trace_depth_exceeded"
        protection = None
        stock = None
        precursor_evidence = []
        source_fragment = ()
        for _ in range(config.max_trace_depth):
            mol_ids.append(current)
            record = index.molecule_records[current]
            reactions = index.children_by_mol.get(current, ())
            if not reactions:
                if record.node.get("in_stock"):
                    source, stock, reason = "stock", record, ""
                else:
                    reason = "unresolved_leaf"
                break
            candidates = []
            fragment_candidates = []
            expected_fragment = _mapped_fragment_signature(molecule(current), matched)
            for rid in reactions:
                for child in index.reaction_records[rid].child_mol_ids:
                    cmol = molecule(child)
                    if (
                        expected_fragment is not None
                        and _mapped_fragment_signature(cmol, matched)
                        == expected_fragment
                    ):
                        fragment_candidates.append((rid, child))
                    if any(
                        tuple(sorted(a)) == anchors
                        and frozenset(mp.values()) == matched
                        for a, mp in matching_site_mappings(cmol, rule)
                    ):
                        candidates.append((rid, child))
            candidates = sorted(set(candidates))
            fragment_candidates = sorted(set(fragment_candidates))
            if len(set(candidates) | set(fragment_candidates)) > 1:
                reason = "ambiguous_ancestry"
                break
            if len(candidates) == 1:
                rid, current = candidates[0]
                visited.append(rid)
                continue
            if candidates or len(reactions) != 1:
                reason = "ambiguous_ancestry"
                break
            if fragment_candidates:
                rid, child = fragment_candidates[0]
                record = index.molecule_records[child]
                if not index.children_by_mol.get(child) and record.node.get("in_stock"):
                    source, stock, reason = "protected_synthon", record, ""
                    protection = index.reaction_records[rid]
                    source_fragment = tuple(sorted(matched))
                else:
                    reason = "unresolved_fragment_ancestry"
                break
            reaction = index.reaction_records[reactions[0]]
            children = [molecule(k) for k in reaction.child_mol_ids]
            # Establish installation only if the substrate atoms already exist
            # together in a precursor. Newly constructed substrate sites remain
            # structural candidates rather than assumed protection reactions.
            if not any(set(anchors) <= set(c) for c in children):
                reason = "substrate_site_constructed"
                break
            source, protection, reason = "introduced", reaction, ""
            for child_id in reaction.child_mol_ids:
                cmol = molecule(child_id)
                if not mask or not mask <= set(cmol):
                    continue
                for precursor_rule in rules.values():
                    for _, pm in matching_site_mappings(cmol, precursor_rule):
                        if mask & set(pm.values()):
                            precursor_evidence.append(
                                {
                                    "pg_type": precursor_rule.name,
                                    "molecule_node_path": list(
                                        index.molecule_records[child_id].node_path
                                    ),
                                    "matched_atom_maps": sorted(pm.values()),
                                    "transferred_atom_maps": sorted(mask),
                                }
                            )
            break
        resolved = source != "unknown"
        interval_paths = (
            tuple(index.reaction_records[r].node_path for r in visited)
            if resolved
            else ()
        )
        event_id = (
            "pg_target_"
            + hashlib.sha256(
                json.dumps(
                    [str(route_id), rule.name, anchors, sorted(matched)],
                    separators=(",", ":"),
                ).encode()
            ).hexdigest()
        )
        events.append(
            TargetProtectionEvent(
                event_id=event_id,
                route_id=str(route_id),
                target_smiles=index.target_smiles,
                pg_type=rule.name,
                protected_functional_group=protected_functional_group(
                    rule.name, target, anchors
                ),
                source_type=source,
                trace_status=source,
                confidence="structural_candidate",
                deprotection_node_id="",
                deprotection_reaction_smiles="",
                protected_atom_ids=anchors,
                lifetime_steps=len(interval_paths),
                interval_reaction_node_paths=interval_paths,
                protected_molecule_node_paths=tuple(
                    index.molecule_records[m].node_path for m in mol_ids
                ),
                protection_node_id=protection.node_id if protection else "",
                protection_reaction_node_path=protection.node_path
                if protection
                else (),
                protection_reaction_smiles=protection.reaction_smiles
                if protection
                else "",
                stock_molecule_node_path=stock.node_path if stock else (),
                source_fragment_atom_ids=source_fragment,
                failure_reason=reason,
                target_annotations={
                    "evidence_status": "observed_installation"
                    if source == "introduced"
                    else "structural_candidate",
                    "trace_status": "resolved" if resolved else "unresolved",
                    "trace_failure_reason": reason,
                    "masking_fragment_atom_maps": sorted(mask),
                    "target_matched_atom_maps": sorted(matched),
                    "precursor_types": sorted(
                        {p["pg_type"] for p in precursor_evidence}
                    ),
                    "precursor_lineage": sorted(
                        {
                            json.dumps(p, sort_keys=True): p for p in precursor_evidence
                        }.values(),
                        key=lambda p: (p["pg_type"], p["molecule_node_path"]),
                    ),
                },
            )
        )
    return events
