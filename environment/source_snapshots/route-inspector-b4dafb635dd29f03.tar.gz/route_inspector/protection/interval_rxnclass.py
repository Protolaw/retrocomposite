"""Introduced protecting-group interval rule and reaction-class sequences."""

from __future__ import annotations

import json
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import route_inspector.routes.access as route_access
from route_inspector import chemistry
from route_inspector.chemistry.classification.common import (
    diagnostics,
    provider_metadata,
    reconcile_batch_results,
    record_id,
    result_accepted,
    result_attr,
)
from route_inspector.chemistry.classification.providers import (
    ReactionRecord as ClassifierReactionRecord,
)
from route_inspector.infrastructure.artifacts import (
    dataset_prefix_from_path,
    reference_sort_key,
    stage_output_dir,
    write_standard_sidecars,
)
from route_inspector.infrastructure.paths import relative_path, resolve_existing_path
from route_inspector.infrastructure.runtime import normalize_n_cpu
from route_inspector.infrastructure.text import read_json, read_tsv_rows, write_tsv
from route_inspector.protection.analysis import RouteIndex, build_route_index
from route_inspector.rules.config import RuleExtractionSettings
from route_inspector.rules.extraction import SynPlannerRuleExtractor

UNEXTRACTED = "UNEXTRACTED"
UNCLASSIFIED = "UNCLASSIFIED"
STAGE_NAME = "protection_interval_rxnclass"
COMMAND_NAME = "classify-protection-interval-reactions"

ERROR_FIELDS = [
    "dataset",
    "route_id",
    "event_id",
    "reaction_steps",
    "reaction_smiles",
    "stage",
    "error_type",
    "message",
    "reaction_node_path",
]
EVENT_FIELDS = [
    "event_id",
    "route_id",
    "target_smiles",
    "pg_type",
    "protected_functional_group",
    "confidence",
    "protection_node_id",
    "protection_reaction_step",
    "protection_provenance_status",
    "deprotection_node_id",
    "deprotection_reaction_step",
    "deprotection_provenance_status",
    "interval_size",
    "interval_reaction_steps",
    "interval_reaction_node_ids",
    "interval_reaction_node_paths",
    "interval_reaction_smiles",
    "PG_interval_rule_sequence",
    "rule_extraction_status",
    "Rxn_class_sequence",
    "Rxn_class_names",
    "rxn_class_status",
]
RULE_SEQUENCE_FIELDS = [
    "PG_interval_rule_sequence",
    "interval_size",
    "route_popularity",
    "event_count",
    "rule_template_variant_count",
    "Reference",
    "Event_ids",
    "PG_types",
    "Target_molecules",
]
RULE_SEQUENCE_BY_PG_FIELDS = ["pg_type", *RULE_SEQUENCE_FIELDS]
CLASS_SEQUENCE_FIELDS = [
    "Rxn_class_sequence",
    "Rxn_class_names",
    "interval_size",
    "route_popularity",
    "event_count",
    "rule_template_variant_count",
    "Reference",
    "Event_ids",
    "PG_types",
    "Target_molecules",
]
CLASS_SEQUENCE_BY_PG_FIELDS = ["pg_type", *CLASS_SEQUENCE_FIELDS]
REFERENCE_STEP_FIELDS = [
    "dataset",
    "event_id",
    "route_id",
    "pg_type",
    "protection_reaction_step",
    "deprotection_reaction_step",
    "reaction_step",
    "step_index",
    "reaction_node_id",
    "reaction_node_path",
    "mapped_reaction",
    "extracted_rule",
    "rule_extraction_status",
    "classifier_input",
    "provider",
    "provider_version",
    "taxonomy",
    "raw_code",
    "raw_name",
    "tier3_code",
    "tier3_name",
    "diagnostic_code",
    "diagnostic_name",
    "confidence",
    "status",
    "accepted",
    "diagnostics",
    "error",
]


@dataclass
class IntervalStep:
    """One exact route reaction strictly inside an introduced-PG interval."""

    event_id: str
    route_id: str
    pg_type: str
    node_id: str
    node_path: tuple[int, ...]
    reaction_step: str
    step_index: int
    mapped_reaction: str
    extracted_rule: str = ""
    query_cgr_key: str = ""
    rule_error: str = ""
    classifier_input: str = ""
    classifier_record_id: str = ""
    result: Any | None = None
    class_error: str = ""

    @property
    def accepted(self) -> bool:
        return result_accepted(self.result, error=self.class_error)


@dataclass
class IntervalEvent:
    """One introduced protecting-group event and its intervening reactions."""

    values: dict[str, str]
    protection_reaction_step: str
    deprotection_reaction_step: str
    protection_provenance_status: str
    deprotection_provenance_status: str
    steps: list[IntervalStep] = field(default_factory=list)

    @property
    def event_id(self) -> str:
        return self.values["event_id"]

    @property
    def route_id(self) -> str:
        return self.values["route_id"]

    @property
    def pg_type(self) -> str:
        return self.values["pg_type"]

    @property
    def target_smiles(self) -> str:
        return self.values.get("target_smiles", "")

    @property
    def interval_size(self) -> int:
        return len(self.steps)

    @property
    def rule_complete(self) -> bool:
        return bool(self.steps) and all(step.extracted_rule for step in self.steps)

    @property
    def class_complete(self) -> bool:
        return bool(self.steps) and all(step.accepted for step in self.steps)

    @property
    def rule_sequence(self) -> tuple[str, ...]:
        return tuple(step.extracted_rule or UNEXTRACTED for step in self.steps)

    @property
    def query_cgr_sequence(self) -> tuple[str, ...]:
        return tuple(step.query_cgr_key for step in self.steps)

    @property
    def class_sequence(self) -> tuple[str, ...]:
        return tuple(
            str(result_attr(step.result, "tier3_code", ""))
            if step.accepted
            else UNCLASSIFIED
            for step in self.steps
        )

    @property
    def class_names(self) -> tuple[str, ...]:
        return tuple(
            str(result_attr(step.result, "tier3_name", "")) or code
            if code != UNCLASSIFIED
            else UNCLASSIFIED
            for step, code in zip(self.steps, self.class_sequence)
        )


def _reaction_paths(index: RouteIndex) -> dict[str, tuple[int, ...]]:
    """Map indexed reaction IDs to exact route-node paths."""

    path_by_node: dict[int, tuple[int, ...]] = {}

    def visit(node: dict[str, Any], path: tuple[int, ...]) -> None:
        for child_index, child in enumerate(node.get("children") or ()):
            if not isinstance(child, dict):
                continue
            child_path = (*path, child_index)
            if child.get("type") == "reaction":
                path_by_node[id(child)] = child_path
            visit(child, child_path)

    visit(index.route, ())
    paths = {
        node_id: path_by_node[id(record.node)]
        for node_id, record in index.reaction_records.items()
        if id(record.node) in path_by_node
    }
    if len(paths) != len(index.reaction_records):
        raise ValueError("could not assign exact paths to every indexed reaction")
    return paths


def _reaction_provenance_status(
    expected: str,
    actual: str,
    *,
    allow_reverse: bool,
) -> str:
    """Classify exact endpoint provenance without accepting different chemistry."""

    try:
        expected_reaction = chemistry.parse_reaction(expected)
        actual_reaction = chemistry.parse_reaction(actual)
        if chemistry.exact_mapped_reactions_correspond(
            expected_reaction,
            actual_reaction,
        ):
            return "exact_mapped"
        if chemistry.canonical_unmapped_reaction_string(
            expected
        ) == chemistry.canonical_unmapped_reaction_string(actual):
            return "forward_graph_equivalent"
        if allow_reverse:
            from chython.containers import ReactionContainer

            reversed_expected = ReactionContainer(
                tuple(expected_reaction.products),
                tuple(expected_reaction.reactants),
                tuple(expected_reaction.reagents),
            )
            reversed_text = format(reversed_expected, "m")
            if chemistry.canonical_unmapped_reaction_string(
                reversed_text
            ) == chemistry.canonical_unmapped_reaction_string(actual):
                return "reverse_graph_equivalent"
    except Exception as exc:
        raise ValueError(
            f"could not compare mapped reaction provenance: {exc}"
        ) from exc
    return "stale"


def _validate_event_fields(fieldnames: Sequence[str]) -> None:
    required = {
        "event_id",
        "route_id",
        "target_smiles",
        "pg_type",
        "trace_status",
        "protection_node_id",
        "protection_reaction_smiles",
        "deprotection_node_id",
        "deprotection_reaction_smiles",
        "lifetime_steps",
    }
    missing = sorted(required - set(fieldnames))
    if missing:
        raise ValueError(
            "protection-event TSV lacks required columns: " + ", ".join(missing)
        )


def _reconstruct_event(
    values: dict[str, str],
    route: dict[str, Any],
) -> IntervalEvent:
    route_id = str(values["route_id"])
    event_id = str(values["event_id"])
    index = build_route_index(route)
    paths = _reaction_paths(index)

    protection_id = str(values.get("protection_node_id", ""))
    deprotection_id = str(values.get("deprotection_node_id", ""))
    if not protection_id or protection_id not in index.reaction_records:
        raise ValueError(
            f"route {route_id} event {event_id}: protection reaction "
            f"{protection_id or '<empty>'} is absent"
        )
    if not deprotection_id or deprotection_id not in index.reaction_records:
        raise ValueError(
            f"n1 route {route_id} event {event_id}: deprotection reaction "
            f"{deprotection_id or '<empty>'} is absent"
        )

    protection_record = index.reaction_records[protection_id]
    deprotection_record = index.reaction_records[deprotection_id]
    protection_provenance_status = _reaction_provenance_status(
        values.get("protection_reaction_smiles", ""),
        protection_record.reaction_smiles,
        allow_reverse=True,
    )
    if protection_provenance_status == "stale":
        raise ValueError(
            f"route {route_id} event {event_id}: protection reaction provenance is stale"
        )
    deprotection_provenance_status = _reaction_provenance_status(
        values.get("deprotection_reaction_smiles", ""),
        deprotection_record.reaction_smiles,
        allow_reverse=False,
    )
    if deprotection_provenance_status == "stale":
        raise ValueError(
            f"route {route_id} event {event_id}: deprotection reaction provenance is stale"
        )

    protection_path = paths[protection_id]
    deprotection_path = paths[deprotection_id]
    if (
        len(protection_path) <= len(deprotection_path)
        or protection_path[: len(deprotection_path)] != deprotection_path
    ):
        raise ValueError(
            f"route {route_id} event {event_id}: protection reaction is not a "
            "descendant of deprotection on one exact branch"
        )

    interval_records = [
        (node_id, path, index.reaction_records[node_id])
        for node_id, path in paths.items()
        if (
            len(deprotection_path) < len(path) < len(protection_path)
            and path[: len(deprotection_path)] == deprotection_path
            and protection_path[: len(path)] == path
        )
    ]
    interval_records.sort(key=lambda item: len(item[1]))
    expected_lifetime = int(values["lifetime_steps"])
    if len(interval_records) != expected_lifetime:
        raise ValueError(
            f"route {route_id} event {event_id}: reconstructed interval has "
            f"{len(interval_records)} reactions but lifetime_steps={expected_lifetime}"
        )

    event = IntervalEvent(
        values=dict(values),
        protection_reaction_step=f"r{protection_record.depth}",
        deprotection_reaction_step=f"r{deprotection_record.depth}",
        protection_provenance_status=protection_provenance_status,
        deprotection_provenance_status=deprotection_provenance_status,
    )
    for step_index, (node_id, node_path, record) in enumerate(interval_records):
        event.steps.append(
            IntervalStep(
                event_id=event_id,
                route_id=route_id,
                pg_type=event.pg_type,
                node_id=node_id,
                node_path=node_path,
                reaction_step=f"r{record.depth}",
                step_index=step_index,
                mapped_reaction=record.reaction_smiles,
            )
        )
    return event


def reconstruct_introduced_intervals(
    routes_json: route_access.RouteCollection,
    fieldnames: Sequence[str],
    event_rows: Iterable[Mapping[str, Any]],
    *,
    limit_events: int | None = None,
) -> list[IntervalEvent]:
    """Reconstruct exact strictly-intervening reactions for introduced events."""

    _validate_event_fields(fieldnames)
    introduced = [
        {key: "" if value is None else str(value) for key, value in row.items()}
        for row in event_rows
        if str(row.get("trace_status", "")) == "introduced"
    ]
    if limit_events is not None:
        if int(limit_events) < 0:
            raise ValueError("--limit-events must be non-negative")
        introduced = introduced[: int(limit_events)]

    seen: set[str] = set()
    events: list[IntervalEvent] = []
    for values in introduced:
        event_id = values["event_id"]
        if event_id in seen:
            raise ValueError(f"duplicate protection event ID: {event_id}")
        seen.add(event_id)
        route_id = values["route_id"]
        try:
            route = route_access.route_by_id(routes_json, route_id)
        except Exception as exc:
            raise ValueError(
                f"route {route_id} event {event_id}: route ID is absent"
            ) from exc
        events.append(_reconstruct_event(values, route))
    return events


def _error_row(
    dataset: str,
    step: IntervalStep,
    *,
    stage: str,
    error_type: str,
    message: str,
) -> dict[str, Any]:
    return {
        "dataset": dataset,
        "route_id": step.route_id,
        "event_id": step.event_id,
        "reaction_steps": step.reaction_step,
        "reaction_smiles": step.mapped_reaction,
        "stage": stage,
        "error_type": error_type,
        "message": message,
        "reaction_node_path": json.dumps(list(step.node_path)),
    }


def _default_rule_extractor(rule_config: Path) -> SynPlannerRuleExtractor:
    args = RuleExtractionSettings(
        config=rule_config,
        environment_atom_count=1,
        include_rings=False,
        keep_leaving_groups=True,
        keep_incoming_groups=False,
        reactor_validation=False,
    )
    return SynPlannerRuleExtractor.from_args(args)


def _extract_rules(
    events: Sequence[IntervalEvent],
    *,
    extractor: Any,
    dataset: str,
    ignore_errors: bool,
) -> list[dict[str, Any]]:
    errors: list[dict[str, Any]] = []
    for event in events:
        for step in event.steps:
            try:
                extracted, _cache_hit = extractor.extract(step.mapped_reaction)
                if extracted is None:
                    step.rule_error = "rule extractor returned no rule"
                    errors.append(
                        _error_row(
                            dataset,
                            step,
                            stage="rule_extraction",
                            error_type="RuleNotExtracted",
                            message=step.rule_error,
                        )
                    )
                    continue
                step.extracted_rule = extracted.rule_smarts
                step.query_cgr_key = extracted.query_cgr_key
            except Exception as exc:
                step.rule_error = str(exc) or type(exc).__name__
                errors.append(
                    _error_row(
                        dataset,
                        step,
                        stage="rule_extraction",
                        error_type=type(exc).__name__,
                        message=step.rule_error,
                    )
                )
                if not ignore_errors:
                    raise RuntimeError(
                        f"rule extraction failed for {dataset} route {step.route_id} "
                        f"{step.reaction_step}: {exc}"
                    ) from exc
    return errors


def _classify_steps(
    events: Sequence[IntervalEvent],
    *,
    provider: Any,
    dataset: str,
    n_cpu: int,
    worker_chunksize: int,
    progress_interval: int,
    ignore_errors: bool,
) -> tuple[list[dict[str, Any]], int, int]:
    errors: list[dict[str, Any]] = []
    steps_by_input: dict[str, list[IntervalStep]] = defaultdict(list)
    first_mapped: dict[str, str] = {}
    all_steps = [step for event in events for step in event.steps]

    for step in all_steps:
        try:
            step.classifier_input = chemistry.canonical_unmapped_reaction_string(
                step.mapped_reaction
            )
            if not step.classifier_input or ">>" not in step.classifier_input:
                raise ValueError("canonical reaction is empty or has no reaction arrow")
            step.classifier_record_id = record_id(step.classifier_input)
            steps_by_input[step.classifier_input].append(step)
            first_mapped.setdefault(step.classifier_input, step.mapped_reaction)
        except Exception as exc:
            step.class_error = str(exc)
            errors.append(
                _error_row(
                    dataset,
                    step,
                    stage="reaction_classification",
                    error_type=type(exc).__name__,
                    message=f"could not canonicalize classifier input: {exc}",
                )
            )
            if not ignore_errors:
                raise

    records = [
        ClassifierReactionRecord(
            record_id=record_id(classifier_input),
            mapped_reaction=first_mapped[classifier_input],
            classifier_input=classifier_input,
        )
        for classifier_input in sorted(first_mapped)
    ]
    last_reported = 0

    def report_progress(completed: int, total: int) -> None:
        nonlocal last_reported
        if progress_interval <= 0:
            return
        if completed == total or completed - last_reported >= progress_interval:
            print(
                f"[{COMMAND_NAME}] classified {completed}/{total} unique reactions",
                file=sys.stderr,
                flush=True,
            )
            last_reported = completed

    try:
        results = provider.classify_many(
            records,
            n_cpu=n_cpu,
            worker_chunksize=worker_chunksize,
            progress_callback=report_progress if progress_interval > 0 else None,
        )
    except Exception as exc:
        if not ignore_errors:
            raise
        results = []
        for step in all_steps:
            if step.class_error:
                continue
            step.class_error = f"provider batch failed: {exc}"
            errors.append(
                _error_row(
                    dataset,
                    step,
                    stage="reaction_classification",
                    error_type="ProviderBatchError",
                    message=step.class_error,
                )
            )

    reconciliation = reconcile_batch_results(
        (record.record_id for record in records),
        results,
        ignore_errors=ignore_errors,
    )
    result_by_id = reconciliation.result_by_id
    for duplicate_id in reconciliation.duplicate_ids:
        for step in all_steps:
            if step.classifier_record_id != duplicate_id or step.class_error:
                continue
            step.class_error = "reaction-class provider returned a duplicate record ID"
            errors.append(
                _error_row(
                    dataset,
                    step,
                    stage="reaction_classification",
                    error_type="DuplicateProviderResult",
                    message=step.class_error,
                )
            )
    for result_id in reconciliation.unexpected_ids:
        errors.append(
            {
                "dataset": dataset,
                "route_id": "",
                "event_id": "",
                "reaction_steps": "",
                "reaction_smiles": "",
                "stage": "reaction_classification",
                "error_type": "UnexpectedProviderResult",
                "message": f"provider returned unknown record ID {result_id}",
                "reaction_node_path": "",
            }
        )
    for _index in range(reconciliation.empty_result_ids):
        errors.append(
            {
                "dataset": dataset,
                "route_id": "",
                "event_id": "",
                "reaction_steps": "",
                "reaction_smiles": "",
                "stage": "reaction_classification",
                "error_type": "EmptyProviderRecordId",
                "message": "provider returned an empty record ID",
                "reaction_node_path": "",
            }
        )

    for classifier_input, matching_steps in steps_by_input.items():
        result = result_by_id.get(record_id(classifier_input))
        for step in matching_steps:
            if step.class_error:
                continue
            step.result = result
            if result is None:
                step.class_error = "reaction-class provider returned no result"
            elif bool(result_attr(result, "accepted", False)) and not result_accepted(
                result
            ):
                step.class_error = "provider accepted a non-numeric or non-Tier-3 code"
            elif str(result_attr(result, "status", "")) == "error" or str(
                result_attr(result, "error", "")
            ):
                step.class_error = str(
                    result_attr(result, "error", "provider classification failed")
                )
            if step.class_error:
                errors.append(
                    _error_row(
                        dataset,
                        step,
                        stage="reaction_classification",
                        error_type="ProviderClassificationError",
                        message=step.class_error,
                    )
                )
                if not ignore_errors:
                    raise RuntimeError(
                        f"classification failed for {dataset} route {step.route_id} "
                        f"{step.reaction_step}: {step.class_error}"
                    )

    return errors, len({step.mapped_reaction for step in all_steps}), len(records)


def _event_row(event: IntervalEvent) -> dict[str, Any]:
    if not event.steps:
        rule_status = class_status = "empty"
    else:
        rule_status = "complete" if event.rule_complete else "partial"
        class_status = "complete" if event.class_complete else "partial"
    return {
        "event_id": event.event_id,
        "route_id": event.route_id,
        "target_smiles": event.target_smiles,
        "pg_type": event.pg_type,
        "protected_functional_group": event.values.get(
            "protected_functional_group", ""
        ),
        "confidence": event.values.get("confidence", ""),
        "protection_node_id": event.values.get("protection_node_id", ""),
        "protection_reaction_step": event.protection_reaction_step,
        "protection_provenance_status": event.protection_provenance_status,
        "deprotection_node_id": event.values.get("deprotection_node_id", ""),
        "deprotection_reaction_step": event.deprotection_reaction_step,
        "deprotection_provenance_status": event.deprotection_provenance_status,
        "interval_size": event.interval_size,
        "interval_reaction_steps": ",".join(step.reaction_step for step in event.steps),
        "interval_reaction_node_ids": ",".join(step.node_id for step in event.steps),
        "interval_reaction_node_paths": json.dumps(
            [list(step.node_path) for step in event.steps], separators=(",", ":")
        ),
        "interval_reaction_smiles": json.dumps(
            [step.mapped_reaction for step in event.steps], separators=(",", ":")
        ),
        "PG_interval_rule_sequence": "$".join(event.rule_sequence),
        "rule_extraction_status": rule_status,
        "Rxn_class_sequence": "$".join(event.class_sequence),
        "Rxn_class_names": "$".join(event.class_names),
        "rxn_class_status": class_status,
    }


def _reference_rows(
    events: Sequence[IntervalEvent],
    *,
    dataset: str,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for event in events:
        for step in event.steps:
            result = step.result
            result_diagnostics = diagnostics(result)
            rows.append(
                {
                    "dataset": dataset,
                    "event_id": event.event_id,
                    "route_id": event.route_id,
                    "pg_type": event.pg_type,
                    "protection_reaction_step": event.protection_reaction_step,
                    "deprotection_reaction_step": event.deprotection_reaction_step,
                    "reaction_step": step.reaction_step,
                    "step_index": step.step_index,
                    "reaction_node_id": step.node_id,
                    "reaction_node_path": json.dumps(list(step.node_path)),
                    "mapped_reaction": step.mapped_reaction,
                    "extracted_rule": step.extracted_rule or UNEXTRACTED,
                    "rule_extraction_status": (
                        "complete" if step.extracted_rule else "unextracted"
                    ),
                    "classifier_input": step.classifier_input,
                    "provider": str(result_attr(result, "provider_name", "")),
                    "provider_version": str(
                        result_attr(result, "provider_version", "")
                    ),
                    "taxonomy": str(result_attr(result, "taxonomy_id", "")),
                    "raw_code": str(result_attr(result, "raw_code", "")),
                    "raw_name": str(result_attr(result, "raw_name", "")),
                    "tier3_code": (
                        str(result_attr(result, "tier3_code", ""))
                        if step.accepted
                        else UNCLASSIFIED
                    ),
                    "tier3_name": (
                        str(result_attr(result, "tier3_name", ""))
                        if step.accepted
                        else UNCLASSIFIED
                    ),
                    "diagnostic_code": str(
                        result_diagnostics.get("neural_code")
                        or result_diagnostics.get("diagnostic_code")
                        or ""
                    ),
                    "diagnostic_name": str(
                        result_diagnostics.get("neural_name")
                        or result_diagnostics.get("diagnostic_name")
                        or ""
                    ),
                    "confidence": result_attr(result, "confidence", ""),
                    "status": str(
                        result_attr(
                            result,
                            "status",
                            "error" if step.class_error else "unclassified",
                        )
                    ),
                    "accepted": "true" if step.accepted else "false",
                    "diagnostics": json.dumps(
                        result_diagnostics, sort_keys=True, separators=(",", ":")
                    ),
                    "error": " | ".join(
                        value for value in (step.rule_error, step.class_error) if value
                    ),
                }
            )
    return rows


def _aggregate_row(
    aggregate: dict[str, Any],
    *,
    sequence_field: str,
    names_field: str | None = None,
    pg_type: str | None = None,
) -> dict[str, Any]:
    route_ids = sorted(aggregate["route_ids"], key=reference_sort_key)
    row = {
        sequence_field: aggregate["representative"],
        "interval_size": aggregate["interval_size"],
        "route_popularity": len(route_ids),
        "event_count": len(aggregate["event_ids"]),
        "rule_template_variant_count": len(aggregate["rule_variants"]),
        "Reference": ",".join(route_ids),
        "Event_ids": ",".join(sorted(aggregate["event_ids"])),
        "PG_types": ",".join(sorted(aggregate["pg_types"])),
        "Target_molecules": ",".join(sorted(aggregate["targets"])),
    }
    if names_field is not None:
        row[names_field] = aggregate["representative_names"]
    if pg_type is not None:
        row["pg_type"] = pg_type
    return row


def _sort_aggregate_rows(rows: list[dict[str, Any]], sequence_field: str) -> None:
    rows.sort(
        key=lambda row: (
            -int(row["route_popularity"]),
            -int(row["event_count"]),
            -int(row["rule_template_variant_count"]),
            str(row[sequence_field]),
            str(row.get("pg_type", "")),
        )
    )


def _aggregate_rule_sequences(
    events: Sequence[IntervalEvent],
    *,
    by_pg: bool,
) -> list[dict[str, Any]]:
    groups: dict[tuple[Any, ...], dict[str, Any]] = {}
    for event in events:
        if not event.rule_complete:
            continue
        identity = event.query_cgr_sequence
        key = ((event.pg_type,) if by_pg else ()) + (
            event.interval_size,
            identity,
        )
        sequence = "$".join(event.rule_sequence)
        aggregate = groups.setdefault(
            key,
            {
                "representative": sequence,
                "interval_size": event.interval_size,
                "route_ids": set(),
                "event_ids": set(),
                "pg_types": set(),
                "targets": set(),
                "rule_variants": set(),
            },
        )
        aggregate["representative"] = min(aggregate["representative"], sequence)
        aggregate["route_ids"].add(event.route_id)
        aggregate["event_ids"].add(event.event_id)
        aggregate["pg_types"].add(event.pg_type)
        aggregate["targets"].add(event.target_smiles)
        aggregate["rule_variants"].add(sequence)

    rows = [
        _aggregate_row(
            aggregate,
            sequence_field="PG_interval_rule_sequence",
            pg_type=str(key[0]) if by_pg else None,
        )
        for key, aggregate in groups.items()
    ]
    _sort_aggregate_rows(rows, "PG_interval_rule_sequence")
    return rows


def _aggregate_class_sequences(
    events: Sequence[IntervalEvent],
    *,
    provider_name: str,
    taxonomy: str,
    by_pg: bool,
) -> list[dict[str, Any]]:
    groups: dict[tuple[Any, ...], dict[str, Any]] = {}
    for event in events:
        if not event.class_complete:
            continue
        sequence_tuple = event.class_sequence
        key = ((event.pg_type,) if by_pg else ()) + (
            provider_name,
            taxonomy,
            sequence_tuple,
        )
        sequence = "$".join(sequence_tuple)
        names = "$".join(event.class_names)
        aggregate = groups.setdefault(
            key,
            {
                "representative": sequence,
                "representative_names": names,
                "interval_size": event.interval_size,
                "route_ids": set(),
                "event_ids": set(),
                "pg_types": set(),
                "targets": set(),
                "rule_variants": set(),
                "name_variants": set(),
            },
        )
        aggregate["route_ids"].add(event.route_id)
        aggregate["event_ids"].add(event.event_id)
        aggregate["pg_types"].add(event.pg_type)
        aggregate["targets"].add(event.target_smiles)
        if event.rule_complete:
            aggregate["rule_variants"].add("$".join(event.rule_sequence))
        aggregate["name_variants"].add(names)
        aggregate["representative_names"] = min(aggregate["name_variants"])

    rows = [
        _aggregate_row(
            aggregate,
            sequence_field="Rxn_class_sequence",
            names_field="Rxn_class_names",
            pg_type=str(key[0]) if by_pg else None,
        )
        for key, aggregate in groups.items()
    ]
    _sort_aggregate_rows(rows, "Rxn_class_sequence")
    return rows


def _write_outputs(
    output_dir: Path,
    dataset: str,
    events: Sequence[IntervalEvent],
    *,
    provider_name: str,
    taxonomy: str,
) -> tuple[dict[str, Path], dict[str, int]]:
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "events": output_dir / f"{dataset}_protection_interval_events.tsv",
        "rule_sequences": (
            output_dir / f"{dataset}_protection_interval_rule_sequences.tsv"
        ),
        "rule_sequences_by_pg": (
            output_dir / f"{dataset}_protection_interval_rule_sequences_by_pg.tsv"
        ),
        "class_sequences": (
            output_dir / f"{dataset}_protection_interval_class_sequences.tsv"
        ),
        "class_sequences_by_pg": (
            output_dir / f"{dataset}_protection_interval_class_sequences_by_pg.tsv"
        ),
        "reference_steps": (
            output_dir / f"{dataset}_protection_interval_reference_steps.tsv"
        ),
    }
    event_rows = [_event_row(event) for event in events]
    rule_rows = _aggregate_rule_sequences(events, by_pg=False)
    rule_by_pg_rows = _aggregate_rule_sequences(events, by_pg=True)
    class_rows = _aggregate_class_sequences(
        events,
        provider_name=provider_name,
        taxonomy=taxonomy,
        by_pg=False,
    )
    class_by_pg_rows = _aggregate_class_sequences(
        events,
        provider_name=provider_name,
        taxonomy=taxonomy,
        by_pg=True,
    )
    write_tsv(paths["events"], EVENT_FIELDS, event_rows)
    write_tsv(paths["rule_sequences"], RULE_SEQUENCE_FIELDS, rule_rows)
    write_tsv(
        paths["rule_sequences_by_pg"],
        RULE_SEQUENCE_BY_PG_FIELDS,
        rule_by_pg_rows,
    )
    write_tsv(paths["class_sequences"], CLASS_SEQUENCE_FIELDS, class_rows)
    write_tsv(
        paths["class_sequences_by_pg"],
        CLASS_SEQUENCE_BY_PG_FIELDS,
        class_by_pg_rows,
    )
    write_tsv(
        paths["reference_steps"],
        REFERENCE_STEP_FIELDS,
        _reference_rows(events, dataset=dataset),
    )
    return paths, {
        "unique_rule_sequences": len(rule_rows),
        "unique_rule_sequences_by_pg": len(rule_by_pg_rows),
        "unique_class_sequences": len(class_rows),
        "unique_class_sequences_by_pg": len(class_by_pg_rows),
    }


def classify_protection_interval_reactions(
    routes_json: str | Path,
    protection_events: str | Path,
    *,
    output_dir: str | Path | None = None,
    rule_config: str
    | Path = "route_inspector/configs/rule_extraction_functional_groups.yaml",
    backend: str = "reactionclassifier",
    reaction_classifier_path: str | Path | None = None,
    namerxn_executable: str | Path | None = None,
    tier: int = 3,
    label_policy: str = "confirmed-or-neural",
    n_cpu: int | None = 1,
    worker_chunksize: int = 100,
    torch_threads: int = 1,
    device: str = "cpu",
    limit_events: int | None = None,
    ignore_errors: bool = False,
    progress_interval: int = 100,
    provider: Any | None = None,
    rule_extractor: Any | None = None,
    cli_args: object | None = None,
    argv: list[str] | None = None,
) -> dict[str, Any]:
    """Extract and classify reactions strictly inside introduced-PG intervals."""

    routes_path = resolve_existing_path(routes_json)
    events_path = resolve_existing_path(protection_events)
    rule_config_path = resolve_existing_path(rule_config)
    if not routes_path.is_file():
        raise FileNotFoundError(f"routes JSON not found: {routes_path}")
    if not events_path.is_file():
        raise FileNotFoundError(f"protection-event TSV not found: {events_path}")
    if not rule_config_path.is_file():
        raise FileNotFoundError(f"rule extraction config not found: {rule_config_path}")
    if int(worker_chunksize) < 1:
        raise ValueError("--worker-chunksize must be positive")

    dataset = dataset_prefix_from_path(routes_path)
    route_collection = read_json(routes_path)
    fieldnames, source_rows = read_tsv_rows(events_path)
    events = reconstruct_introduced_intervals(
        route_collection,
        fieldnames,
        source_rows,
        limit_events=limit_events,
    )

    extractor = rule_extractor or _default_rule_extractor(rule_config_path)
    errors = _extract_rules(
        events,
        extractor=extractor,
        dataset=dataset,
        ignore_errors=ignore_errors,
    )

    if provider is None:
        from route_inspector.chemistry.classification.providers import create_provider

        provider = create_provider(
            backend,
            reaction_classifier_path=reaction_classifier_path,
            namerxn_executable=namerxn_executable,
            tier=tier,
            label_policy=label_policy,
            torch_threads=torch_threads,
            device=device,
        )
    provider_name, provider_version, taxonomy = provider_metadata(provider)
    workers = normalize_n_cpu(n_cpu)
    class_errors, unique_mapped, unique_inputs = _classify_steps(
        events,
        provider=provider,
        dataset=dataset,
        n_cpu=workers,
        worker_chunksize=int(worker_chunksize),
        progress_interval=int(progress_interval),
        ignore_errors=ignore_errors,
    )
    errors.extend(class_errors)
    provider_name, provider_version, taxonomy = provider_metadata(provider)

    output_path = (
        Path(output_dir).expanduser()
        if output_dir is not None
        else stage_output_dir(Path("outputs"), dataset, STAGE_NAME)
    )
    output_files, aggregate_counts = _write_outputs(
        output_path,
        dataset,
        events,
        provider_name=provider_name or backend,
        taxonomy=taxonomy,
    )

    interval_histogram = dict(
        sorted(Counter(event.interval_size for event in events).items())
    )
    all_steps = [step for event in events for step in event.steps]
    class_status_counts = Counter(
        str(
            result_attr(
                step.result,
                "status",
                "error" if step.class_error else "unclassified",
            )
        )
        for step in all_steps
    )
    summary: dict[str, Any] = {
        "dataset": dataset,
        "backend": provider_name or backend,
        "provider_version": provider_version,
        "taxonomy": taxonomy,
        "tier": int(tier),
        "label_policy": label_policy,
        "sequence_definition": "strictly_between_endpoints_retrosynthetic_order",
        "introduced_events": len(events),
        "introduced_routes": len({event.route_id for event in events}),
        "zero_length_intervals": sum(not event.steps for event in events),
        "nonempty_intervals": sum(bool(event.steps) for event in events),
        "interval_length_histogram": {
            str(size): count for size, count in interval_histogram.items()
        },
        "interval_step_occurrences": len(all_steps),
        "interval_reconstruction_errors": 0,
        "protection_provenance_status_counts": dict(
            sorted(
                Counter(event.protection_provenance_status for event in events).items()
            )
        ),
        "deprotection_provenance_status_counts": dict(
            sorted(
                Counter(
                    event.deprotection_provenance_status for event in events
                ).items()
            )
        ),
        "unique_mapped_reactions": unique_mapped,
        "unique_classifier_inputs": unique_inputs,
        "rule_complete_events": sum(event.rule_complete for event in events),
        "rule_incomplete_events": sum(
            bool(event.steps) and not event.rule_complete for event in events
        ),
        "class_complete_events": sum(event.class_complete for event in events),
        "class_incomplete_events": sum(
            bool(event.steps) and not event.class_complete for event in events
        ),
        "classification_status_counts": dict(sorted(class_status_counts.items())),
        "n_errors": len(errors),
        **aggregate_counts,
        "n_cpu": workers,
        "worker_chunksize": int(worker_chunksize),
        "progress_interval": int(progress_interval),
        "input_files": {
            "routes_json": relative_path(routes_path),
            "protection_events": relative_path(events_path),
            "rule_config": relative_path(rule_config_path),
        },
        "output_directory": relative_path(output_path),
        "output_files": {
            key: relative_path(path) for key, path in sorted(output_files.items())
        },
        "sidecar_files": {
            "summary": relative_path(output_path / "summary.json"),
            "errors": relative_path(output_path / "errors.tsv"),
            "manifest": relative_path(output_path / "manifest.json"),
        },
    }
    sidecars = write_standard_sidecars(
        output_path,
        command_name=COMMAND_NAME,
        summary=summary,
        errors=errors,
        error_fieldnames=ERROR_FIELDS,
        input_files=[routes_path, events_path, rule_config_path],
        output_files=output_files,
        config_path=rule_config_path,
        cli_args=cli_args,
        argv=argv,
        extra_manifest={
            "backend": provider_name or backend,
            "taxonomy": taxonomy,
            "tier": int(tier),
            "label_policy": label_policy,
        },
    )
    return {**summary, "sidecar_files": sidecars}


__all__ = [
    "COMMAND_NAME",
    "IntervalEvent",
    "IntervalStep",
    "classify_protection_interval_reactions",
    "reconstruct_introduced_intervals",
]
