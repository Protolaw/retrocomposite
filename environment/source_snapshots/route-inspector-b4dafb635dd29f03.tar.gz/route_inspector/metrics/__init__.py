"""Route comparison metrics and independent baselines."""
