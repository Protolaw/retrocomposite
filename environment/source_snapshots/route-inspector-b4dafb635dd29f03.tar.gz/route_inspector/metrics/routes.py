"""Small, shared route-topology descriptors used by scientific workflows."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


def route_topology_metrics(route: Mapping[str, Any]) -> dict[str, int | str]:
    """Return PaRoutes-compatible route length, leaves, and topology.

    The longest linear route is the maximum number of reaction nodes on a
    root-to-leaf path. Leaves are deduplicated by the preprocessed route's
    ``metadata.original_smiles`` value, following the PaRoutes convention.
    """

    if route.get("type") != "mol":
        raise ValueError("a route must have a molecule root")
    total_reactions = 0
    leaf_smiles: set[str] = set()

    def visit(node: Mapping[str, Any]) -> int:
        nonlocal total_reactions
        node_type = node.get("type")
        if node_type not in {"mol", "reaction"}:
            raise ValueError(f"unsupported route node type: {node_type!r}")
        if node_type == "reaction":
            total_reactions += 1

        children = tuple(
            child
            for child in (node.get("children") or ())
            if isinstance(child, Mapping)
        )
        if node_type == "mol" and not children:
            metadata = node.get("metadata") or {}
            original_smiles = str(metadata.get("original_smiles") or "")
            if not original_smiles:
                raise ValueError("cleaned route leaf requires metadata.original_smiles")
            leaf_smiles.add(original_smiles)

        child_depth = max((visit(child) for child in children), default=0)
        return int(node_type == "reaction") + child_depth

    longest_linear_route = visit(route)
    return {
        "total_reaction_count": total_reactions,
        "longest_linear_route": longest_linear_route,
        "distinct_leaf_count": len(leaf_smiles),
        "topology": (
            "convergent" if total_reactions > longest_linear_route else "linear"
        ),
    }
