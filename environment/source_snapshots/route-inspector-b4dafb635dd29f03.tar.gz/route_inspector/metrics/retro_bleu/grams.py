"""Extract topology-contiguous SynPlanner rule n-grams from route trees.

The traversal follows the parent-to-child reaction relationships used by Retro-BLEU,
but the tokens are Chython/SynPlanner rules rather than RDChiral templates.  Unlike an
RRseq_cons, a Retro-BLEU gram has no reaction-center continuity requirement.

Paper: https://doi.org/10.1039/D3DD00219E
Reference implementation: https://github.com/catalystforyou/Retro-BLEU
"""

from __future__ import annotations

import hashlib
import json
import traceback
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import route_inspector.routes.access as route_access
import route_inspector.rules.extraction as _owner_extraction
import route_inspector.rules.identity as _owner_identity
import route_inspector.rules.models as _owner_models
import route_inspector.rules.preparation as _owner_preparation
from route_inspector.infrastructure.artifacts import (
    reference_sort_key,
    write_json,
    write_standard_sidecars,
)
from route_inspector.infrastructure.text import write_tsv
from route_inspector.routes import normalization as routes
from route_inspector.rules.config import RuleExtractionSettings

RETRO_BLEU_GRAM_OCCURRENCE_SCHEMA_VERSION = 1
RETRO_BLEU_GRAM_FIELDS = [
    "retro_bleu_gram",
    "gram_length",
    "popularity",
    "occurrence_count",
    "Reference",
    "Target_molecules",
]
RETRO_BLEU_ERROR_FIELDS = [
    "dataset",
    "route_id",
    "reaction_step",
    "stage",
    "error_type",
    "message",
    "reaction_smiles",
]


@dataclass(frozen=True)
class _ReactionNodeRecord:
    reaction_node_path: tuple[int, ...]
    target_molecule_path: tuple[int, ...]
    reaction_step: str
    reaction_smiles: str
    target_smiles: str
    child_reaction_paths: tuple[tuple[int, ...], ...]


@dataclass(frozen=True)
class RetroBleuGramOccurrence:
    """One exact contiguous reaction-node path in a source route."""

    occurrence_id: str
    dataset: str
    route_id: str
    route_target_smiles: str
    segment_target_smiles: str
    raw_sequence: tuple[str, ...]
    query_cgr_keys: tuple[str, ...]
    reaction_smiles: tuple[str, ...]
    reaction_steps: tuple[str, ...]
    reaction_node_paths: tuple[tuple[int, ...], ...]
    target_molecule_paths: tuple[tuple[int, ...], ...]

    @property
    def gram_length(self) -> int:
        return len(self.raw_sequence)

    @property
    def identity(self) -> tuple[int, tuple[str, ...]]:
        return self.gram_length, self.query_cgr_keys

    @property
    def raw_retro_bleu_gram(self) -> str:
        return "$".join(self.raw_sequence)

    def to_dict(self, representative: tuple[str, ...]) -> dict[str, Any]:
        return {
            "schema_version": RETRO_BLEU_GRAM_OCCURRENCE_SCHEMA_VERSION,
            "occurrence_id": self.occurrence_id,
            "dataset": self.dataset,
            "route_id": self.route_id,
            "route_target_smiles": self.route_target_smiles,
            "segment_target_smiles": self.segment_target_smiles,
            "gram_length": self.gram_length,
            "retro_bleu_gram": "$".join(representative),
            "raw_retro_bleu_gram": self.raw_retro_bleu_gram,
            "raw_sequence": list(self.raw_sequence),
            "query_cgr_keys": list(self.query_cgr_keys),
            "reaction_smiles": list(self.reaction_smiles),
            "reaction_steps": list(self.reaction_steps),
            "reaction_node_paths": [list(path) for path in self.reaction_node_paths],
            "target_molecule_paths": [
                list(path) for path in self.target_molecule_paths
            ],
        }


@dataclass(frozen=True)
class RetroBleuGramAggregate:
    """One length-scoped QueryCGR-equivalent gram family."""

    representative: tuple[str, ...]
    query_cgr_keys: tuple[str, ...]
    route_ids: tuple[str, ...]
    target_molecules: tuple[str, ...]
    occurrence_count: int

    @property
    def gram_length(self) -> int:
        return len(self.representative)

    @property
    def retro_bleu_gram(self) -> str:
        return "$".join(self.representative)

    def to_tsv_row(self) -> dict[str, Any]:
        return {
            "retro_bleu_gram": self.retro_bleu_gram,
            "gram_length": self.gram_length,
            "popularity": len(self.route_ids),
            "occurrence_count": self.occurrence_count,
            "Reference": ",".join(self.route_ids),
            "Target_molecules": ",".join(self.target_molecules),
        }


@dataclass
class RetroBleuGramResult:
    """In-memory Retro-BLEU gram extraction result."""

    dataset: str
    routes_seen: int
    routes_with_grams: int
    reactions_seen: int
    reaction_rules_extracted: int
    skipped_reactions: int
    occurrences: tuple[RetroBleuGramOccurrence, ...]
    aggregates_by_length: dict[int, tuple[RetroBleuGramAggregate, ...]]
    representatives_by_identity: dict[tuple[int, tuple[str, ...]], tuple[str, ...]]
    errors: tuple[dict[str, Any], ...]
    min_length: int
    max_length: int
    unique_reactions_seen: int
    extra_summary: dict[str, Any] = field(default_factory=dict)

    def summary(self) -> dict[str, Any]:
        occurrence_counts = {
            str(length): sum(
                aggregate.occurrence_count
                for aggregate in self.aggregates_by_length.get(length, ())
            )
            for length in range(self.min_length, self.max_length + 1)
        }
        unique_counts = {
            str(length): len(self.aggregates_by_length.get(length, ()))
            for length in range(self.min_length, self.max_length + 1)
        }
        # Exact SMARTS grams can be counted as shown below. However, exact SMARTS
        # comparison is usually atom-mapping-sensitive, so we report the more
        # reliable QueryCGR-based unique gram count directly instead, even though
        # computing QueryCGR identities can be slower.
        # exact_counts = {
        #     str(length): len(
        #         {
        #             occurrence.raw_sequence
        #             for occurrence in self.occurrences
        #             if occurrence.gram_length == length
        #         }
        #     )
        #     for length in range(self.min_length, self.max_length + 1)
        # }
        return {
            "dataset": self.dataset,
            "routes_seen": self.routes_seen,
            "routes_with_retro_bleu_grams": self.routes_with_grams,
            "reactions_seen": self.reactions_seen,
            "unique_reactions_seen": self.unique_reactions_seen,
            "reaction_rules_extracted": self.reaction_rules_extracted,
            "skipped_reactions": self.skipped_reactions,
            "errors": len(self.errors),
            "min_length": self.min_length,
            "max_length": self.max_length,
            "occurrences_by_length": occurrence_counts,
            # "exact_smarts_grams_by_length": exact_counts,
            "unique_grams_by_length": unique_counts,
            "occurrence_schema_version": RETRO_BLEU_GRAM_OCCURRENCE_SCHEMA_VERSION,
            "definition": (
                "Contiguous parent-to-child route reaction paths represented by "
                "Chython/SynPlanner rules, without a reaction-center-overlap "
                "requirement. Rules are ordered retrosynthetically and joined by $."
            ),
            **self.extra_summary,
        }


def _validate_lengths(min_length: int, max_length: int) -> None:
    if min_length < 2:
        raise ValueError("min_length must be at least 2")
    if max_length < min_length:
        raise ValueError("max_length must be greater than or equal to min_length")


def _default_rule_extractor() -> _owner_extraction.SynPlannerRuleExtractor:
    args = RuleExtractionSettings(
        config=None,
        environment_atom_count=1,
        include_rings=False,
        keep_leaving_groups=True,
        keep_incoming_groups=False,
        reactor_validation=False,
    )
    return _owner_extraction.SynPlannerRuleExtractor.from_args(args)


def _stable_occurrence_id(
    dataset: str,
    route_id: str,
    reaction_node_paths: Iterable[tuple[int, ...]],
) -> str:
    payload = json.dumps(
        {
            "dataset": dataset,
            "route_id": route_id,
            "reaction_node_paths": [list(path) for path in reaction_node_paths],
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return "rbg_" + hashlib.sha256(payload.encode("utf-8")).hexdigest()[:24]


def _error_record(
    *,
    dataset: str,
    route_id: Any,
    reaction_step: str,
    stage: str,
    exc: Exception,
    reaction_smiles: str = "",
) -> dict[str, Any]:
    return {
        "dataset": dataset,
        "route_id": str(route_id),
        "reaction_step": reaction_step,
        "stage": stage,
        "error_type": type(exc).__qualname__,
        "message": str(exc) or traceback.format_exc(limit=1).strip(),
        "reaction_smiles": reaction_smiles,
    }


def _index_reaction_nodes(
    route: dict[str, Any],
) -> tuple[tuple[tuple[int, ...], ...], dict[tuple[int, ...], _ReactionNodeRecord]]:
    records: dict[tuple[int, ...], _ReactionNodeRecord] = {}
    reaction_index = 0

    def visit_molecule(
        molecule_node: dict[str, Any],
        molecule_path: tuple[int, ...],
    ) -> tuple[tuple[int, ...], ...]:
        nonlocal reaction_index
        roots: list[tuple[int, ...]] = []
        for child_index, child in enumerate(molecule_node.get("children") or ()):
            if not isinstance(child, dict) or child.get("type") != "reaction":
                continue
            reaction_path = molecule_path + (child_index,)
            step = f"r{reaction_index}"
            reaction_index += 1
            child_reactions: list[tuple[int, ...]] = []
            for molecule_index, molecule_child in enumerate(
                child.get("children") or ()
            ):
                if (
                    not isinstance(molecule_child, dict)
                    or molecule_child.get("type") != "mol"
                ):
                    continue
                child_reactions.extend(
                    visit_molecule(
                        molecule_child,
                        reaction_path + (molecule_index,),
                    )
                )
            try:
                reaction_smiles = route_access.reaction_smiles_from_node(child)
            except Exception:
                reaction_smiles = ""
            records[reaction_path] = _ReactionNodeRecord(
                reaction_node_path=reaction_path,
                target_molecule_path=molecule_path,
                reaction_step=step,
                reaction_smiles=reaction_smiles,
                target_smiles=route_access.molecule_node_smiles(molecule_node),
                child_reaction_paths=tuple(child_reactions),
            )
            roots.append(reaction_path)
        return tuple(roots)

    roots = visit_molecule(route, ())
    return roots, records


def _route_sort_key(value: str) -> tuple[int, Any]:
    return reference_sort_key(value)


def _prepare_route_items(
    routes_json: Any,
    *,
    dataset: str,
) -> tuple[list[tuple[Any, dict[str, Any]]], list[dict[str, Any]], int]:
    prepared: list[tuple[Any, dict[str, Any]]] = []
    errors: list[dict[str, Any]] = []
    routes_seen = 0
    for route_id, route in route_access.route_items(routes_json):
        routes_seen += 1
        try:
            prepared.append((route_id, routes.normalized_route_for_analysis(route)))
        except Exception as exc:
            errors.append(
                _error_record(
                    dataset=dataset,
                    route_id=route_id,
                    reaction_step="",
                    stage="normalize_route",
                    exc=exc,
                )
            )
    return prepared, errors, routes_seen


def _collect_unique_reaction_smiles(
    prepared_routes: Iterable[tuple[Any, dict[str, Any]]],
) -> set[str]:
    unique: set[str] = set()
    for _route_id, route in prepared_routes:
        _roots, records = _index_reaction_nodes(route)
        unique.update(
            record.reaction_smiles
            for record in records.values()
            if record.reaction_smiles
        )
    return unique


def _aggregate_occurrences(
    occurrences: Iterable[RetroBleuGramOccurrence],
) -> tuple[
    dict[int, tuple[RetroBleuGramAggregate, ...]],
    dict[tuple[int, tuple[str, ...]], tuple[str, ...]],
]:
    grouped: dict[tuple[int, tuple[str, ...]], list[RetroBleuGramOccurrence]] = (
        defaultdict(list)
    )
    for occurrence in occurrences:
        grouped[occurrence.identity].append(occurrence)

    representatives: dict[tuple[int, tuple[str, ...]], tuple[str, ...]] = {}
    aggregates: dict[int, list[RetroBleuGramAggregate]] = defaultdict(list)
    for identity, members in grouped.items():
        representative = min(
            (member.raw_sequence for member in members),
            key=lambda sequence: "$".join(sequence),
        )
        representatives[identity] = representative
        route_ids = tuple(
            sorted({member.route_id for member in members}, key=_route_sort_key)
        )
        target_molecules = tuple(
            sorted({member.segment_target_smiles for member in members})
        )
        aggregate = RetroBleuGramAggregate(
            representative=representative,
            query_cgr_keys=identity[1],
            route_ids=route_ids,
            target_molecules=target_molecules,
            occurrence_count=len(members),
        )
        aggregates[identity[0]].append(aggregate)

    return (
        {
            length: tuple(sorted(values, key=_aggregate_sort_key))
            for length, values in aggregates.items()
        },
        representatives,
    )


def _aggregate_sort_key(
    aggregate: RetroBleuGramAggregate,
) -> tuple[int, int, str]:
    """Order gram rows by popularity, frequency, then stable identity."""

    return (
        -len(aggregate.route_ids),
        -aggregate.occurrence_count,
        aggregate.retro_bleu_gram,
    )


def _extract_from_prepared_routes(
    prepared_routes: Iterable[tuple[Any, dict[str, Any]]],
    *,
    rule_extractor: Any,
    dataset: str,
    min_length: int,
    max_length: int,
    preparation_errors: Iterable[dict[str, Any]] = (),
    routes_seen: int | None = None,
) -> RetroBleuGramResult:
    _validate_lengths(min_length, max_length)
    prepared_routes = list(prepared_routes)
    errors = list(preparation_errors)
    occurrences: list[RetroBleuGramOccurrence] = []
    reactions_seen = 0
    reaction_rules_extracted = 0
    skipped_reactions = 0
    routes_with_grams = 0
    unique_reactions: set[str] = set()

    for route_id, route in prepared_routes:
        route_id_text = str(route_id)
        _roots, records = _index_reaction_nodes(route)
        reactions_seen += len(records)
        valid_steps: dict[tuple[int, ...], _owner_models.ReactionRuleStep] = {}
        for record in sorted(
            records.values(), key=lambda item: int(item.reaction_step[1:])
        ):
            reaction_smiles = record.reaction_smiles
            if reaction_smiles:
                unique_reactions.add(reaction_smiles)
            if not reaction_smiles:
                skipped_reactions += 1
                errors.append(
                    _error_record(
                        dataset=dataset,
                        route_id=route_id,
                        reaction_step=record.reaction_step,
                        stage="read_reaction_smiles",
                        exc=ValueError("reaction node has no mapped reaction SMILES"),
                    )
                )
                continue
            try:
                step, _cache_hit = rule_extractor.extract(reaction_smiles)
            except Exception as exc:
                skipped_reactions += 1
                errors.append(
                    _error_record(
                        dataset=dataset,
                        route_id=route_id,
                        reaction_step=record.reaction_step,
                        stage="extract_reaction_rule",
                        exc=exc,
                        reaction_smiles=reaction_smiles,
                    )
                )
                continue
            if step is None:
                skipped_reactions += 1
                errors.append(
                    _error_record(
                        dataset=dataset,
                        route_id=route_id,
                        reaction_step=record.reaction_step,
                        stage="extract_reaction_rule",
                        exc=_owner_models.RuleExtractionError(
                            "SynPlanner skipped the reaction or produced no rule"
                        ),
                        reaction_smiles=reaction_smiles,
                    )
                )
                continue
            reaction_rules_extracted += 1
            valid_steps[record.reaction_node_path] = step

        route_occurrences_before = len(occurrences)

        def extend(path: tuple[tuple[int, ...], ...]) -> None:
            current_path = path[-1]
            if current_path not in valid_steps:
                return
            if len(path) >= min_length:
                selected_records = tuple(records[item] for item in path)
                selected_steps = tuple(valid_steps[item] for item in path)
                raw_sequence = tuple(step.rule_smarts for step in selected_steps)
                query_cgr_keys = tuple(
                    step.query_cgr_key
                    or _owner_identity.rule_querycgr_identity(step.rule_smarts)
                    for step in selected_steps
                )
                occurrences.append(
                    RetroBleuGramOccurrence(
                        occurrence_id=_stable_occurrence_id(
                            dataset,
                            route_id_text,
                            path,
                        ),
                        dataset=dataset,
                        route_id=route_id_text,
                        route_target_smiles=_owner_preparation.route_target_smiles(
                            route
                        ),
                        segment_target_smiles=selected_records[0].target_smiles,
                        raw_sequence=raw_sequence,
                        query_cgr_keys=query_cgr_keys,
                        reaction_smiles=tuple(
                            record.reaction_smiles for record in selected_records
                        ),
                        reaction_steps=tuple(
                            record.reaction_step for record in selected_records
                        ),
                        reaction_node_paths=path,
                        target_molecule_paths=tuple(
                            record.target_molecule_path for record in selected_records
                        ),
                    )
                )
            if len(path) >= max_length:
                return
            for child_path in records[current_path].child_reaction_paths:
                if child_path in valid_steps:
                    extend((*path, child_path))

        for start_path in records:
            if start_path in valid_steps:
                extend((start_path,))

        if len(occurrences) > route_occurrences_before:
            routes_with_grams += 1

    occurrences.sort(
        key=lambda occurrence: (
            _route_sort_key(occurrence.route_id),
            occurrence.reaction_node_paths,
            occurrence.gram_length,
        )
    )
    aggregates, representatives = _aggregate_occurrences(occurrences)
    return RetroBleuGramResult(
        dataset=dataset,
        routes_seen=(len(prepared_routes) if routes_seen is None else routes_seen),
        routes_with_grams=routes_with_grams,
        reactions_seen=reactions_seen,
        reaction_rules_extracted=reaction_rules_extracted,
        skipped_reactions=skipped_reactions,
        occurrences=tuple(occurrences),
        aggregates_by_length=aggregates,
        representatives_by_identity=representatives,
        errors=tuple(errors),
        min_length=min_length,
        max_length=max_length,
        unique_reactions_seen=len(unique_reactions),
    )


def retro_bleu_grams(
    routes_json: Any,
    *,
    rule_extractor: Any | None = None,
    dataset: str = "",
    min_length: int = 2,
    max_length: int = 5,
) -> RetroBleuGramResult:
    """Extract topology-contiguous Chython/SynPlanner rule grams."""

    _validate_lengths(min_length, max_length)
    prepared, errors, routes_seen = _prepare_route_items(
        routes_json,
        dataset=dataset,
    )
    return _extract_from_prepared_routes(
        prepared,
        rule_extractor=rule_extractor or _default_rule_extractor(),
        dataset=dataset,
        min_length=min_length,
        max_length=max_length,
        preparation_errors=errors,
        routes_seen=routes_seen,
    )


def write_retro_bleu_gram_outputs(
    result: RetroBleuGramResult,
    output_dir: Path,
    *,
    routes_json_path: Path | None = None,
    config_path: Path | None = None,
    cli_args: Any | None = None,
) -> dict[str, str]:
    """Write aggregate grams, exact occurrences, and standard sidecars."""

    output_dir = Path(output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    dataset = result.dataset or "dataset"
    output_files: dict[str, Path] = {}
    for length in range(result.min_length, result.max_length + 1):
        path = output_dir / f"{dataset}_t{length}_retro_bleu_grams.tsv"
        write_tsv(
            path,
            RETRO_BLEU_GRAM_FIELDS,
            (
                aggregate.to_tsv_row()
                for aggregate in sorted(
                    result.aggregates_by_length.get(length, ()),
                    key=_aggregate_sort_key,
                )
            ),
        )
        output_files[f"t{length}_grams"] = path

    occurrences_path = output_dir / f"{dataset}_retro_bleu_gram_occurrences.json"
    write_json(
        occurrences_path,
        [
            occurrence.to_dict(result.representatives_by_identity[occurrence.identity])
            for occurrence in result.occurrences
        ],
    )
    output_files["occurrences"] = occurrences_path

    summary = result.summary()
    summary["routes_json"] = str(routes_json_path) if routes_json_path else ""
    summary["output_directory"] = str(output_dir)
    summary["output_files"] = {
        key: str(path) for key, path in sorted(output_files.items())
    }

    sidecars = write_standard_sidecars(
        output_dir,
        command_name="extract-retro-bleu-grams",
        summary=summary,
        errors=result.errors,
        error_fieldnames=RETRO_BLEU_ERROR_FIELDS,
        input_files=([routes_json_path] if routes_json_path else []),
        output_files=output_files,
        config_path=config_path,
        cli_args=cli_args,
    )
    return {
        **{key: str(path) for key, path in output_files.items()},
        **sidecars,
    }


def _limited_routes(routes_json: Any, limit: int | None) -> Any:
    if limit is None:
        return routes_json
    if limit < 0:
        raise ValueError("limit must be non-negative")
    if isinstance(routes_json, list):
        return routes_json[:limit]
    if isinstance(routes_json, dict):
        return dict(list(routes_json.items())[:limit])
    raise TypeError(f"unsupported routes JSON root: {type(routes_json)!r}")


__all__ = [
    "RETRO_BLEU_ERROR_FIELDS",
    "RETRO_BLEU_GRAM_FIELDS",
    "RETRO_BLEU_GRAM_OCCURRENCE_SCHEMA_VERSION",
    "RetroBleuGramAggregate",
    "RetroBleuGramOccurrence",
    "RetroBleuGramResult",
    "retro_bleu_grams",
    "write_retro_bleu_gram_outputs",
]
