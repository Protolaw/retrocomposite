"""Prepared-route extraction of Retro-BLEU-like rule bigrams.

One occurrence is an ordered pair of directly adjacent reaction nodes. It does
not require reaction-centre continuity and never bridges a reaction for which
rule extraction failed.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Mapping

from route_inspector.metrics.retro_bleu.grams import _index_reaction_nodes
from route_inspector.rules.models import PreparedRouteRuleData, ReactionRuleStep
from route_inspector.rules.preparation import route_target_smiles

RETRO_BLEU_BIGRAM_OCCURRENCE_SCHEMA_VERSION = 1


def _stable_occurrence_id(
    *,
    dataset_id: str,
    source_identity: str,
    route_id: str,
    reaction_node_paths: tuple[tuple[int, ...], tuple[int, ...]],
) -> str:
    payload = json.dumps(
        {
            "schema_version": RETRO_BLEU_BIGRAM_OCCURRENCE_SCHEMA_VERSION,
            "dataset_id": dataset_id,
            "source_identity": source_identity,
            "route_id": route_id,
            "reaction_node_paths": [list(path) for path in reaction_node_paths],
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return f"retro_bleu_bigram_o_{digest[:24]}"


def _path(value: Any, *, field: str) -> tuple[int, ...]:
    try:
        path = tuple(int(index) for index in value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field} must be an integer node path") from exc
    if any(index < 0 for index in path):
        raise ValueError(f"{field} cannot contain negative indices")
    return path


@dataclass(frozen=True)
class RetroBleuBigramStep:
    """One selected rule tied to its exact route reaction occurrence."""

    rule_smarts: str
    reaction_smiles: str
    reaction_node_path: tuple[int, ...]
    target_molecule_path: tuple[int, ...]
    target_smiles: str
    center_atom_maps: tuple[int, ...]
    query_cgr_key: str = ""

    def __post_init__(self) -> None:
        rule_smarts = str(self.rule_smarts)
        reaction_smiles = str(self.reaction_smiles)
        if not rule_smarts or not reaction_smiles:
            raise ValueError("bigram steps require rule SMARTS and reaction SMILES")
        reaction_path = _path(self.reaction_node_path, field="reaction_node_path")
        target_path = _path(self.target_molecule_path, field="target_molecule_path")
        centers = tuple(sorted({int(atom_map) for atom_map in self.center_atom_maps}))
        if any(atom_map <= 0 for atom_map in centers):
            raise ValueError("center_atom_maps must contain positive atom maps")
        object.__setattr__(self, "rule_smarts", rule_smarts)
        object.__setattr__(self, "reaction_smiles", reaction_smiles)
        object.__setattr__(self, "reaction_node_path", reaction_path)
        object.__setattr__(self, "target_molecule_path", target_path)
        object.__setattr__(self, "target_smiles", str(self.target_smiles))
        object.__setattr__(self, "center_atom_maps", centers)
        object.__setattr__(self, "query_cgr_key", str(self.query_cgr_key))

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_smarts": self.rule_smarts,
            "reaction_smiles": self.reaction_smiles,
            "reaction_node_path": list(self.reaction_node_path),
            "target_molecule_path": list(self.target_molecule_path),
            "target_smiles": self.target_smiles,
            "center_atom_maps": list(self.center_atom_maps),
            "query_cgr_key": self.query_cgr_key,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RetroBleuBigramStep":
        return cls(
            rule_smarts=str(value["rule_smarts"]),
            reaction_smiles=str(value["reaction_smiles"]),
            reaction_node_path=_path(
                value["reaction_node_path"], field="reaction_node_path"
            ),
            target_molecule_path=_path(
                value["target_molecule_path"], field="target_molecule_path"
            ),
            target_smiles=str(value.get("target_smiles") or ""),
            center_atom_maps=tuple(int(item) for item in value["center_atom_maps"]),
            query_cgr_key=str(value.get("query_cgr_key") or ""),
        )


@dataclass(frozen=True)
class RetroBleuBigramOccurrence:
    """One ordered, directly adjacent two-rule path in a route."""

    occurrence_id: str
    dataset_id: str
    source_identity: str
    route_id: str
    route_target_smiles: str
    segment_target_smiles: str
    steps: tuple[RetroBleuBigramStep, RetroBleuBigramStep]
    schema_version: int = RETRO_BLEU_BIGRAM_OCCURRENCE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if int(self.schema_version) != RETRO_BLEU_BIGRAM_OCCURRENCE_SCHEMA_VERSION:
            raise ValueError(
                "unsupported Retro-BLEU-like bigram occurrence schema version"
            )
        for name in ("occurrence_id", "dataset_id", "source_identity", "route_id"):
            value = str(getattr(self, name))
            if not value:
                raise ValueError(f"bigram occurrence requires non-empty {name}")
            object.__setattr__(self, name, value)
        steps = tuple(self.steps)
        if len(steps) != 2 or not all(
            isinstance(step, RetroBleuBigramStep) for step in steps
        ):
            raise ValueError("a Retro-BLEU-like bigram requires exactly two steps")
        if steps[0].reaction_node_path == steps[1].reaction_node_path:
            raise ValueError("bigram steps must refer to distinct reaction nodes")
        object.__setattr__(self, "steps", steps)
        object.__setattr__(self, "route_target_smiles", str(self.route_target_smiles))
        object.__setattr__(
            self, "segment_target_smiles", str(self.segment_target_smiles)
        )

    @property
    def rule_smarts(self) -> tuple[str, str]:
        return self.steps[0].rule_smarts, self.steps[1].rule_smarts

    @property
    def reaction_node_paths(self) -> tuple[tuple[int, ...], tuple[int, ...]]:
        return self.steps[0].reaction_node_path, self.steps[1].reaction_node_path

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "occurrence_id": self.occurrence_id,
            "dataset_id": self.dataset_id,
            "source_identity": self.source_identity,
            "route_id": self.route_id,
            "route_target_smiles": self.route_target_smiles,
            "segment_target_smiles": self.segment_target_smiles,
            "gram_length": 2,
            "rule_smarts": list(self.rule_smarts),
            "reaction_node_paths": [list(path) for path in self.reaction_node_paths],
            "steps": [step.to_dict() for step in self.steps],
            "definition": (
                "ordered directly adjacent parent-to-child reaction rules without "
                "a reaction-centre continuity requirement"
            ),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RetroBleuBigramOccurrence":
        raw_steps = value.get("steps")
        if not isinstance(raw_steps, list) or len(raw_steps) != 2:
            raise ValueError("bigram occurrence steps must be a two-item array")
        occurrence = cls(
            occurrence_id=str(value["occurrence_id"]),
            dataset_id=str(value["dataset_id"]),
            source_identity=str(value["source_identity"]),
            route_id=str(value["route_id"]),
            route_target_smiles=str(value.get("route_target_smiles") or ""),
            segment_target_smiles=str(value.get("segment_target_smiles") or ""),
            steps=(
                RetroBleuBigramStep.from_dict(raw_steps[0]),
                RetroBleuBigramStep.from_dict(raw_steps[1]),
            ),
            schema_version=int(value.get("schema_version", -1)),
        )
        if int(value.get("gram_length", 2)) != 2:
            raise ValueError("Retro-BLEU-like bigram gram_length must be 2")
        if (
            "rule_smarts" in value
            and tuple(value["rule_smarts"]) != occurrence.rule_smarts
        ):
            raise ValueError("serialized rule_smarts disagree with bigram steps")
        return occurrence


def _bigram_step(
    step: ReactionRuleStep,
    *,
    reaction_node_path: tuple[int, ...],
    target_molecule_path: tuple[int, ...],
) -> RetroBleuBigramStep:
    return RetroBleuBigramStep(
        rule_smarts=step.rule_smarts,
        reaction_smiles=step.reaction_smiles,
        reaction_node_path=reaction_node_path,
        target_molecule_path=target_molecule_path,
        target_smiles=step.target_smiles,
        center_atom_maps=tuple(sorted(step.center_atoms)),
        query_cgr_key=step.query_cgr_key,
    )


def extract_prepared_retro_bleu_bigrams(
    prepared: PreparedRouteRuleData,
    *,
    route_id: Any,
    dataset_id: str,
    source_identity: str,
) -> tuple[RetroBleuBigramOccurrence, ...]:
    """Enumerate direct parent-to-child rule pairs from one prepared route."""

    if not isinstance(prepared, PreparedRouteRuleData):
        raise TypeError("prepared must be PreparedRouteRuleData")
    resolved_route_id = str(route_id)
    resolved_dataset_id = str(dataset_id)
    resolved_source_identity = str(source_identity)
    if not resolved_route_id or not resolved_dataset_id or not resolved_source_identity:
        raise ValueError("dataset_id, source_identity, and route_id must be non-empty")

    _roots, records = _index_reaction_nodes(prepared.route)
    valid_steps = prepared.step_by_reaction_path
    occurrences: list[RetroBleuBigramOccurrence] = []
    for parent_path in sorted(records):
        parent_step = valid_steps.get(parent_path)
        if parent_step is None:
            continue
        parent_record = records[parent_path]
        for child_path in sorted(parent_record.child_reaction_paths):
            child_step = valid_steps.get(child_path)
            if child_step is None:
                continue
            child_record = records[child_path]
            paths = (parent_path, child_path)
            occurrences.append(
                RetroBleuBigramOccurrence(
                    occurrence_id=_stable_occurrence_id(
                        dataset_id=resolved_dataset_id,
                        source_identity=resolved_source_identity,
                        route_id=resolved_route_id,
                        reaction_node_paths=paths,
                    ),
                    dataset_id=resolved_dataset_id,
                    source_identity=resolved_source_identity,
                    route_id=resolved_route_id,
                    route_target_smiles=route_target_smiles(prepared.route),
                    segment_target_smiles=parent_record.target_smiles,
                    steps=(
                        _bigram_step(
                            parent_step,
                            reaction_node_path=parent_path,
                            target_molecule_path=parent_record.target_molecule_path,
                        ),
                        _bigram_step(
                            child_step,
                            reaction_node_path=child_path,
                            target_molecule_path=child_record.target_molecule_path,
                        ),
                    ),
                )
            )
    occurrences.sort(key=lambda item: (item.reaction_node_paths, item.occurrence_id))
    return tuple(occurrences)


__all__ = [
    "RETRO_BLEU_BIGRAM_OCCURRENCE_SCHEMA_VERSION",
    "RetroBleuBigramOccurrence",
    "RetroBleuBigramStep",
    "extract_prepared_retro_bleu_bigrams",
]
