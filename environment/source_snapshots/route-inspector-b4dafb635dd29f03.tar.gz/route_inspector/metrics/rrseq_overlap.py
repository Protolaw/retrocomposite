"""Order-sensitive overlap scores computed from supplied rule sets."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class RRseqSet:
    source: str
    popularity_by_rule: dict[str, int]
    references_by_rule: dict[str, set[str]]
    rows_seen: int = 0
    parse_errors: int = 0

    @property
    def rules(self) -> set[str]:
        """Return the normalized rule strings represented by this scored set.

        The scorer normalizes rule sequences before comparison so order-sensitive
        rrseqs can be matched exactly and weighted by popularity.
        """
        return set(self.popularity_by_rule)

    @property
    def total_popularity(self) -> int:
        """Return the summed popularity across all rules in the set.

        The scorer normalizes rule sequences before comparison so order-sensitive
        rrseqs can be matched exactly and weighted by popularity.
        """
        return sum(self.popularity_by_rule.values())


@dataclass
class RRseqClassificationSet:
    source: str
    positive_weight_by_rule: dict[str, int]
    negative_weight_by_rule: dict[str, int]
    rows_seen: int = 0
    parse_errors: int = 0

    def weights(self, rule: str) -> tuple[int, int]:
        """Return per-rule weights keyed by normalized rrseq rule.

        The scorer normalizes rule sequences before comparison so order-sensitive
        rrseqs can be matched exactly and weighted by popularity.
        """
        return (
            self.positive_weight_by_rule.get(rule, 0),
            self.negative_weight_by_rule.get(rule, 0),
        )


def ratio(numerator: int | float, denominator: int | float) -> float:
    """Return a safe numerator-to-denominator ratio.

    The scorer normalizes rule sequences before comparison so order-sensitive rrseq
    rules can be matched exactly and weighted by popularity.
    """
    if denominator == 0:
        return 0.0
    return numerator / denominator


def normalize_rrseq(rule: str) -> str:
    """Normalize rrseq rule for route-inspector processing.

    The scorer normalizes rule sequences before comparison so order-sensitive rrseq
    rules can be matched exactly and weighted by popularity.
    """
    parts = [part.strip() for part in rule.split("$") if part.strip()]
    if len(parts) < 2:
        raise ValueError("rrseq rule must contain at least two rule SMARTS")
    return "$".join(parts)


def empty_classification_set() -> RRseqClassificationSet:
    """Create an empty scored rule set for a classification bucket.

    Classification-aware scores reward overlap with positive composite rules and
    penalize overlap with rules already explained by default templates.
    """
    return RRseqClassificationSet(
        source="",
        positive_weight_by_rule={},
        negative_weight_by_rule={},
    )


def overlap_score_row(
    extracted: RRseqSet,
    reference: RRseqSet,
    classifications: RRseqClassificationSet | None = None,
) -> dict[str, Any]:
    """Build the summary row for one overlap score bucket.

    The scorer normalizes rule sequences before comparison so order-sensitive rrseq
    rules can be matched exactly and weighted by popularity.
    """
    overlap = extracted.rules & reference.rules
    union = extracted.rules | reference.rules
    overlapping_popularity = sum(extracted.popularity_by_rule[rule] for rule in overlap)
    classifications = classifications or empty_classification_set()

    positive_overlap_popularity = 0.0
    negative_overlap_popularity = 0.0
    classified_overlap_rules = 0
    positive_overlap_rules = 0
    negative_overlap_rules = 0
    mixed_overlap_rules = 0
    for rule in overlap:
        positive_weight, negative_weight = classifications.weights(rule)
        classification_weight = positive_weight + negative_weight
        if classification_weight == 0:
            continue

        classified_overlap_rules += 1
        if positive_weight:
            positive_overlap_rules += 1
        if negative_weight:
            negative_overlap_rules += 1
        if positive_weight and negative_weight:
            mixed_overlap_rules += 1

        extracted_popularity = extracted.popularity_by_rule[rule]
        positive_overlap_popularity += extracted_popularity * ratio(
            positive_weight,
            classification_weight,
        )
        negative_overlap_popularity += extracted_popularity * ratio(
            negative_weight,
            classification_weight,
        )

    return {
        "extracted_tsv": extracted.source,
        "reference_routes_json": reference.source,
        "classification_tsv": classifications.source,
        "extracted_rows": extracted.rows_seen,
        "reference_routes": reference.rows_seen,
        "classification_rows": classifications.rows_seen,
        "extracted_unique_rrseq_cons": len(extracted.rules),
        "reference_unique_rrseq_cons": len(reference.rules),
        "overlap_unique_rrseq_cons": len(overlap),
        "classified_overlap_unique_rrseq_cons": classified_overlap_rules,
        "positive_overlap_unique_rrseq_cons": positive_overlap_rules,
        "negative_overlap_unique_rrseq_cons": negative_overlap_rules,
        "mixed_classification_overlap_unique_rrseq_cons": mixed_overlap_rules,
        "extracted_overlap_ratio": ratio(len(overlap), len(extracted.rules)),
        "reference_coverage_ratio": ratio(len(overlap), len(reference.rules)),
        "jaccard": ratio(len(overlap), len(union)),
        "extracted_popularity": extracted.total_popularity,
        "overlapping_popularity": overlapping_popularity,
        "popularity_overlap_ratio": ratio(
            overlapping_popularity,
            extracted.total_popularity,
        ),
        "positive_overlapping_popularity": positive_overlap_popularity,
        "negative_overlapping_popularity": negative_overlap_popularity,
        "pos_overlap": ratio(
            positive_overlap_popularity,
            extracted.total_popularity,
        ),
        "neg_overlap": ratio(
            negative_overlap_popularity,
            extracted.total_popularity,
        ),
        "extracted_parse_errors": extracted.parse_errors,
        "reference_errors": reference.parse_errors,
        "classification_parse_errors": classifications.parse_errors,
    }


def matched_rule_rows(
    extracted: RRseqSet,
    reference: RRseqSet,
    classifications: RRseqClassificationSet | None = None,
) -> list[dict[str, Any]]:
    """Build detailed rows for matched rrseqs.

    The scorer normalizes rule sequences before comparison so order-sensitive rrseq
    rules can be matched exactly and weighted by popularity.
    """
    rows = []
    classifications = classifications or empty_classification_set()
    for rule in sorted(
        extracted.rules,
        key=lambda item: (-extracted.popularity_by_rule[item], item),
    ):
        reference_ids = sorted(reference.references_by_rule.get(rule, set()))
        positive_weight, negative_weight = classifications.weights(rule)
        classification_weight = positive_weight + negative_weight
        if positive_weight and negative_weight:
            classification = "mixed"
        elif positive_weight:
            classification = "positive"
        elif negative_weight:
            classification = "negative"
        else:
            classification = "unclassified"
        rows.append(
            {
                "RRseq_cons": rule,
                "present_in_reference": bool(reference_ids),
                "classification": classification,
                "classification_positive_weight": positive_weight,
                "classification_negative_weight": negative_weight,
                "classification_positive_share": ratio(
                    positive_weight,
                    classification_weight,
                ),
                "classification_negative_share": ratio(
                    negative_weight,
                    classification_weight,
                ),
                "extracted_popularity": extracted.popularity_by_rule[rule],
                "extracted_reference_ids": ",".join(
                    sorted(extracted.references_by_rule.get(rule, set()))
                ),
                "reference_route_ids": ",".join(reference_ids),
            }
        )
    return rows
