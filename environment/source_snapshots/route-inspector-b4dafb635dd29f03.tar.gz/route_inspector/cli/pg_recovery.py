"""PG counterfactual corpus and proposal commands."""

from pathlib import Path

from route_inspector.cli.common import workflow_request
from route_inspector.workflows.requests import (
    ProposePgStrategiesRequest,
    StripPgRoutesRequest,
)


def add_strip_arguments(parser):
    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--eligibility",
        choices=("ngram", "all"),
        default="ngram",
        help="Exclude zero/empty lifespans and direct PG exchanges, or retain all structurally strippable routes for comparison",
    )


def add_propose_arguments(parser):
    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--reference-routes-json", type=Path, required=True)
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--max-proposals",
        type=int,
        default=20,
        help="Combined proposal cap for exact and reduced-context tiers",
    )
    parser.add_argument(
        "--max-attempts",
        type=int,
        default=256,
        help="Combined attempt cap for exact and reduced-context tiers",
    )
    parser.add_argument(
        "--max-center-proposals",
        type=int,
        default=20,
        help="Additional proposal cap per route for environment-0 fallback",
    )
    parser.add_argument(
        "--max-center-attempts",
        type=int,
        default=256,
        help="Additional attempt cap per route for environment-0 fallback",
    )
    parser.add_argument(
        "--identical-source-policy",
        choices=("exclude", "allow_diagnostic"),
        default="exclude",
        help="Exclude identical original routes (default), or allow them for an explicitly labeled self-reference consistency diagnostic; all chemistry checks remain required",
    )
    parser.add_argument("--max-site-matches", type=int, default=256)
    parser.add_argument(
        "--replay-selectivity",
        choices=("warn_competing", "strict"),
        default="warn_competing",
        help="Retain reproduced intended products with competition warnings (default), or reject competition",
    )
    parser.add_argument(
        "--max-selectivity-applications",
        type=int,
        default=256,
        help="Maximum distinct compatible mapped patches per replay check; duplicate mappings and incompatible sites are counted separately",
    )
    parser.add_argument(
        "--endpoint-search",
        choices=("matched_event", "same_pg_library"),
        default="same_pg_library",
        help="After matched-event search, try independent pure endpoint pairs for the same PG from the reference library",
    )
    parser.add_argument("--max-endpoint-attempts", type=int, default=256)
    parser.add_argument("--max-endpoint-proposals", type=int, default=20)
    parser.add_argument(
        "--placement-fallback",
        choices=("query_groups", "related_families", "same_pg", "off"),
        default="query_groups",
        help="After related-family search, let query sites nominate other PG families using explicitly weaker transformation evidence",
    )
    parser.add_argument(
        "--boundary-search",
        choices=("reference_neighbors", "off"),
        default="reference_neighbors",
        help="For still-empty routes, match recorded reference reactions immediately before installation or after removal and place protection on the corresponding side",
    )
    parser.add_argument(
        "--evidence-retrieval",
        choices=(
            "exact_then_reduced_context_then_center_only",
            "exact_then_reduced_context",
            "exact",
        ),
        default="exact_then_reduced_context_then_center_only",
        help="Prefer full rules, then one neighbour shell, then centre-only matches where neither stronger tier matches the same query window and PG type",
    )
    parser.add_argument(
        "--max-lifetime-extension",
        type=int,
        default=8,
        help="Maximum total additional reactions around a matched window",
    )
    parser.add_argument(
        "--lifetime-search",
        choices=("expand", "matched_window"),
        default="expand",
        help="Search nearby PG endpoints, or retain matched-window boundaries for comparison",
    )
    parser.add_argument(
        "--site-discovery",
        choices=("functional_group_core", "reference_context"),
        default="functional_group_core",
        help="Use broader functional-group cores, or the previous context matcher for controlled comparisons; both require rule replay and selectivity",
    )


def run_strip(args):
    from route_inspector.workflows.pg_recovery import strip_pg_routes

    strip_pg_routes(workflow_request(StripPgRoutesRequest, args))
    return 0


def run_propose(args):
    from route_inspector.workflows.pg_recovery import propose_pg_strategies

    propose_pg_strategies(workflow_request(ProposePgStrategiesRequest, args))
    return 0
