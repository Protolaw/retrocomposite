"""Combine the four existing tactic protection/deprotection reports."""

from __future__ import annotations

import argparse
from pathlib import Path

from route_inspector.workflows.source_motifs import write_aggregate


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis-root", type=Path, default=Path("outputs/n1"))
    parser.add_argument("--output", type=Path)
    parser.add_argument(
        "--examples",
        type=Path,
        help="Saved examples JSON; defaults to the analysis-root examples file if present",
    )
    parser.add_argument(
        "--replace", action="store_true", help="Replace the aggregate Markdown only"
    )
    args = parser.parse_args(argv)
    output = args.output or args.analysis_root / "namerxn_protection_statistics.md"
    if output.exists() and not args.replace:
        parser.error("Output exists; pass --replace to regenerate the aggregate")
    examples = args.examples
    if examples is None:
        candidate = args.analysis_root / "rrsubtree_protection_free_examples.json"
        examples = candidate if candidate.exists() else None
    write_aggregate(args.analysis_root, output, examples=examples, replace=args.replace)
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
