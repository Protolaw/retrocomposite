"""CLI parsers and runners for protection analysis."""

from __future__ import annotations

import argparse
from pathlib import Path

import route_inspector.workflows.protection_classes as _owner_protection_classes
from route_inspector.cli.common import add_parallel_arguments


def add_protection_arguments(parser: argparse.ArgumentParser) -> None:
    """Add protection options to an argparse parser.

    The parser mutation is kept in one place so terminal commands, tests, and notebook
    examples expose the same options and defaults.
    """
    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--rrseq-cons-tsv",
        "--rrseq-tsv",
        dest="rrseq_tsv",
        type=Path,
        nargs="+",
        default=None,
        help="Optional RRseq_cons TSV files or directories.",
    )
    parser.add_argument(
        "--composite-rules-tsv",
        type=Path,
        nargs="+",
        default=None,
        help=(
            "Reserved provenance inputs recorded in the manifest; "
            "not used by protection analysis in v1."
        ),
    )
    parser.add_argument("--config", type=Path, default=None)
    parser.add_argument("--route-ids-file", type=Path, default=None)
    parser.add_argument("--limit", "--max-routes", type=int, default=None)
    parser.add_argument(
        "--min-rrseq-cons-size",
        "--min-rrseq-size",
        dest="min_rrseq_cons_size",
        type=int,
        default=None,
    )
    parser.add_argument(
        "--max-rrseq-cons-size",
        "--max-rrseq-size",
        dest="max_rrseq_cons_size",
        type=int,
        default=None,
    )
    parser.add_argument("--similarity-threshold", type=float, default=None)
    parser.add_argument("--include-multicenter", action="store_true")
    parser.add_argument("--deprotection-first", action="store_true")
    parser.add_argument("--querycgr-compare", action="store_true")
    parser.add_argument("--write-debug-json", action="store_true")
    parser.add_argument("--write-debug-svg", action="store_true")
    parser.add_argument("--ignore-errors", action="store_true")
    parser.add_argument(
        "--progress-interval",
        type=int,
        default=100,
        help="Print route-level progress every N processed routes. Use 0 to disable.",
    )
    add_parallel_arguments(parser)


def add_protection_interval_rxnclass_arguments(
    parser: argparse.ArgumentParser,
) -> None:
    """Add introduced-PG interval reaction-classification options."""

    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--protection-events", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument(
        "--rule-config",
        type=Path,
        default=Path("route_inspector/configs/rule_extraction_functional_groups.yaml"),
    )
    parser.add_argument(
        "--backend",
        choices=("reactionclassifier", "namerxn"),
        default="reactionclassifier",
    )
    parser.add_argument("--reaction-classifier-path", type=Path, default=None)
    parser.add_argument(
        "--namerxn-path",
        "--namerxn-executable",
        dest="namerxn_executable",
        type=Path,
        default=None,
        help="NameRXN executable or HazELNut project directory.",
    )
    parser.add_argument("--tier", type=int, choices=(3,), default=3)
    parser.add_argument(
        "--label-policy",
        choices=("confirmed-only", "confirmed-or-neural"),
        default="confirmed-or-neural",
    )
    add_parallel_arguments(parser)
    parser.add_argument("--worker-chunksize", type=int, default=100)
    parser.add_argument("--torch-threads", type=int, default=1)
    parser.add_argument("--device", choices=("cpu",), default="cpu")
    parser.add_argument("--limit-events", type=int, default=None)
    parser.add_argument("--ignore-errors", action="store_true")
    parser.add_argument("--progress-interval", type=int, default=100)


def run_protection_interval_rxnclass(args: argparse.Namespace) -> int:
    """Run introduced-PG interval reaction classification lazily."""

    return _owner_protection_classes.run(args)
