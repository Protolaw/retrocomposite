"""CLI parser and runner for certified composite companion libraries."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from route_inspector.cli.common import (
    add_parallel_arguments,
    add_rule_extraction_arguments,
)
from route_inspector.composite_rules.overlap import DEFAULT_OVERLAP_CACHE_ROOT


def add_composite_library_build_arguments(parser: argparse.ArgumentParser) -> None:
    """Add deterministic companion-library construction arguments."""

    from route_inspector.cli.common import add_build_storage_arguments

    add_build_storage_arguments(parser)
    parser.add_argument("--reference-library", type=Path, required=True)
    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--kinds",
        nargs="+",
        choices=("rrseq_cons", "rrsubtree_cons"),
        default=("rrsubtree_cons",),
    )
    add_rule_extraction_arguments(parser)
    parser.set_defaults(
        config=Path("route_inspector/configs/rule_extraction_small.yaml")
    )
    parser.add_argument(
        "--max-replay-outcomes",
        type=int,
        default=256,
        help="Maximum unique outcomes examined per rule application.",
    )
    parser.add_argument(
        "--max-variants",
        type=int,
        default=256,
        help="Maximum generated subtree variants retained per occurrence.",
    )
    parser.add_argument(
        "--application-timeout-seconds",
        type=float,
        default=300.0,
        help="Wall-clock limit for one occurrence's construction and replay.",
    )
    parser.add_argument(
        "--allow-ambiguous",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Certify mapped source outcomes even when other outcomes exist "
            "(default: enabled; --no-allow-ambiguous requires uniqueness)."
        ),
    )
    parser.add_argument(
        "--sqlite-catalog",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    parser.add_argument(
        "--extractor-cache-size",
        type=int,
        default=16,
        help="Maximum recent pseudo-reaction extractions retained in memory.",
    )
    parser.add_argument("--limit-occurrences", type=int, default=None)
    parser.add_argument("--progress-interval", type=int, default=25)
    add_parallel_arguments(parser)
    parser.add_argument("--ignore-errors", action="store_true")
    parser.add_argument(
        "--single-step-overlap",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Prepare exact single-step overlap before publishing (default: enabled).",
    )
    parser.add_argument(
        "--overlap-cache-dir",
        type=Path,
        default=DEFAULT_OVERLAP_CACHE_ROOT,
        help="Identity-keyed overlap cache root; defaults to the GUI cache in this workspace.",
    )


def run_composite_library_build(args: argparse.Namespace) -> int:
    """Adapt CLI options and render publication results."""
    from route_inspector.cli.common import workflow_request
    from route_inspector.workflows.composites import publish_composite_library
    from route_inspector.workflows.requests import BuildCompositeLibraryRequest

    result = publish_composite_library(
        workflow_request(BuildCompositeLibraryRequest, args),
        progress=lambda state, message: print(message, file=sys.stderr, flush=True),
    )
    overlap_result = result.overlap
    print(
        "built composite library "
        f"{result.library_id}: {result.certified_links} certified links, "
        f"{len(result.errors)} retained diagnostics"
    )
    if overlap_result is not None:
        destination, summary = overlap_result
        print(
            f"single-step overlap: {summary['matched_composites']} matched, "
            f"{summary['unmatched_composites']} unmatched; "
            f"{summary['successful_reactions']}/{summary['total_reactions']} reactions extracted, "
            f"{summary['failed_reactions']} failed, {summary['skipped_reactions']} skipped; "
            f"{summary['composite_identity_statuses'].get('failed_source_attempts', 0)} "
            f"composite source reconstructions failed; cache: {destination} "
            "(see summary.json and errors.tsv)"
        )
    return 0


__all__ = [
    "add_composite_library_build_arguments",
    "run_composite_library_build",
]
