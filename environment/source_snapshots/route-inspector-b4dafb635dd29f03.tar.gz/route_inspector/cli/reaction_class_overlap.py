"""Compare n1/n5 tactic pools after Tier-3 reaction-class generalization.

The analysis consumes persisted occurrence provenance from two Reference tactic
libraries.  It classifies each distinct canonical, atom-map-free source reaction
once, then replaces the selected reaction in every RRSeq/RRSubtree occurrence by
its provider-specific Tier-3 code.  Composite rules are deliberately outside this
analysis because a net composite is not an elementary classifiable reaction."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence

from route_inspector.chemistry.classification.providers import (
    create_provider,
)
from route_inspector.tactics.classification.overlap import (
    DEFAULT_CANONICALIZATION_TIMEOUT,
)
from route_inspector.workflows.reaction_class_overlap import (
    build_reaction_class_overlap_analysis,
)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--left-library",
        default="outputs/reference_libraries/n1-cgr-v2",
    )
    parser.add_argument(
        "--right-library",
        default="outputs/reference_libraries/n5-cgr-v2",
    )
    parser.add_argument(
        "--output-dir",
        default=("outputs/library_overlap/n1_n5-cgr-v2-namerxn-tier3"),
    )
    parser.add_argument("--left-label", default="n1")
    parser.add_argument("--right-label", default="n5")
    parser.add_argument(
        "--backend",
        choices=("namerxn", "reactionclassifier"),
        default="namerxn",
    )
    parser.add_argument(
        "--namerxn-path",
        help="NameRXN executable or HazELNut project directory.",
    )
    parser.add_argument("--reaction-classifier-path")
    parser.add_argument("--tier", type=int, default=3)
    parser.add_argument("--label-policy", default="confirmed-or-neural")
    parser.add_argument("--torch-threads", type=int, default=1)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--n-cpu", type=int, default=1)
    parser.add_argument("--batch-size", type=int, default=5000)
    parser.add_argument(
        "--canonicalization-timeout",
        type=float,
        default=DEFAULT_CANONICALIZATION_TIMEOUT,
        help="Per-source-reaction Chython timeout in seconds; zero disables it.",
    )
    parser.add_argument(
        "--verification",
        choices=("fast", "full"),
        default="fast",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    provider = create_provider(
        args.backend,
        reaction_classifier_path=args.reaction_classifier_path,
        namerxn_path=args.namerxn_path,
        tier=args.tier,
        label_policy=args.label_policy,
        torch_threads=args.torch_threads,
        device=args.device,
    )
    summary = build_reaction_class_overlap_analysis(
        left_library_path=args.left_library,
        right_library_path=args.right_library,
        output_dir=args.output_dir,
        provider=provider,
        left_label=args.left_label,
        right_label=args.right_label,
        verification=args.verification,
        n_cpu=args.n_cpu,
        batch_size=args.batch_size,
        canonicalization_timeout=args.canonicalization_timeout,
    )
    print(json.dumps(summary["panels"], indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
