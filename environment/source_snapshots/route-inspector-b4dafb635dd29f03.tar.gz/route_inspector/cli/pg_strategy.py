"""Standalone PG library commands."""

import argparse
from pathlib import Path

from route_inspector.cli.common import (
    add_parallel_arguments,
    add_source_id_adapter_argument,
    workflow_request,
)
from route_inspector.workflows.requests import (
    AssessPgStrategiesRequest,
    BuildPgStrategyLibraryRequest,
)


def add_build_arguments(parser):
    from route_inspector.cli.common import add_build_storage_arguments

    add_build_storage_arguments(parser)
    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--reference-id", required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source-identity")
    add_source_id_adapter_argument(parser)
    add_parallel_arguments(parser)
    parser.add_argument(
        "--sqlite-catalog", action=argparse.BooleanOptionalAction, default=True
    )
    parser.add_argument("--limit", type=int)
    parser.add_argument("--progress-interval", type=int, default=250)
    parser.add_argument(
        "--pg-strategy-config",
        type=Path,
        default=Path("route_inspector/configs/protection_analysis.yaml"),
        help="Protecting-group detection and tracing YAML.",
    )
    parser.add_argument(
        "--pg-reaction-class-backend",
        choices=("reactionclassifier", "namerxn", "none"),
        default="reactionclassifier",
        help="Optional reaction-class annotations; 'none' builds PG evidence without class labels.",
    )
    parser.add_argument(
        "--reaction-classifier-path",
        type=Path,
        default=None,
        help="Optional ReactionClassifier checkout or src directory.",
    )
    parser.add_argument(
        "--namerxn-path",
        "--namerxn-executable",
        dest="namerxn_executable",
        type=Path,
        default=None,
        help=(
            "Optional NameRXN executable or HazELNut project directory used "
            "only for the PG component."
        ),
    )
    parser.add_argument(
        "--pg-label-policy",
        choices=("confirmed-only", "confirmed-or-neural"),
        default="confirmed-or-neural",
    )
    parser.add_argument("--pg-worker-chunksize", type=int, default=100)
    parser.add_argument("--pg-torch-threads", type=int, default=1)
    parser.add_argument("--pg-device", choices=("cpu",), default="cpu")


def add_assess_arguments(parser):
    parser.add_argument(
        "--routes-json", "--route", dest="routes_json", type=Path, required=True
    )
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--route-id")
    parser.add_argument("--dataset-id")
    parser.add_argument("--source-identity")
    parser.add_argument("--verification", choices=("fast", "full"), default="fast")
    parser.add_argument("--progress-interval", type=int, default=250)
    add_parallel_arguments(parser)


def add_verify_arguments(parser):
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument(
        "--backend", choices=("auto", "sqlite", "jsonl"), default="auto"
    )


def run_build(args):
    from route_inspector.workflows.pg_strategy import run_build_pg_strategy_library

    return run_build_pg_strategy_library(
        workflow_request(BuildPgStrategyLibraryRequest, args)
    )


def run_assess(args):
    from route_inspector.workflows.pg_strategy import assess_pg_strategy_routes

    return assess_pg_strategy_routes(workflow_request(AssessPgStrategiesRequest, args))


def run_verify(args):
    from route_inspector.protection.strategies.catalog import ReferencePGStrategyLibrary

    manifest = ReferencePGStrategyLibrary.verify(args.library, backend=args.backend)
    print(f"verified PG strategy library {manifest.library_id}")
    return 0


def add_repack_arguments(parser):
    from route_inspector.cli.common import add_build_storage_arguments

    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    add_build_storage_arguments(parser)


def run_repack(args):
    from route_inspector.workflows.requests import RepackPgStrategyLibraryRequest

    args = workflow_request(RepackPgStrategyLibraryRequest, args)
    from route_inspector.protection.strategies.construction import (
        repack_pg_strategy_library,
    )

    result = repack_pg_strategy_library(
        args.library,
        args.output_dir,
        work_dir=args.work_dir,
        resume=args.resume,
        memory_budget_mb=args.memory_budget_mb,
    )
    print(f"repacked PG library {result.manifest.library_id} at {result.output_path}")
    return 0
