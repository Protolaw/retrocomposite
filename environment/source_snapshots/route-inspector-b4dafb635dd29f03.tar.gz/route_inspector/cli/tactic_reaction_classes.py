"""NameRXN protection/deprotection statistics from selected tactic source steps."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from route_inspector.workflows.source_motifs import (
    SourceMotifClassificationRequest,
    run,
)


def main(argv=None, *, default_kind="rrsubtree_cons"):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--kind",
        choices=["rrseq_cons", "rrseq_gap", "rrsubtree_cons", "rrsubtree_gap"],
        default=default_kind,
    )
    parser.add_argument(
        "--reference-library", type=Path, default=Path("outputs/reference_libraries/n1")
    )
    parser.add_argument(
        "--routes-json", type=Path, default=Path("data/clean/n1_routes.json")
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--namerxn-path",
        default="outputs/NameRXN/HazELNut",
        help="Executable, PATH command, or HazELNut directory",
    )
    parser.add_argument(
        "--namerxn-def", type=Path, help="Optional namerxn.def for readable class names"
    )
    parser.add_argument("--batch-size", type=int, default=100)
    parser.add_argument(
        "--prepare-only",
        action="store_true",
        help="Verify source links without running NameRXN",
    )
    args = parser.parse_args(argv)
    if args.batch_size < 1:
        parser.error("--batch-size must be positive")
    request = SourceMotifClassificationRequest(**vars(args))
    result = run(
        request,
        progress=lambda done, total: print(
            f"Classified {done}/{total} source reactions",
            flush=True,
        ),
    )
    print(json.dumps(result.summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
