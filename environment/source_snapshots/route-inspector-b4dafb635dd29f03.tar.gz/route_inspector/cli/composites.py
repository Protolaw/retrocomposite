"""CLI argument builders for composite-rule commands."""

from __future__ import annotations

import argparse
from pathlib import Path

from route_inspector.cli.common import (
    add_parallel_arguments,
    add_rule_extraction_arguments,
)


def add_composite_extraction_arguments(parser: argparse.ArgumentParser) -> None:
    """Add composite extraction options to an argparse parser.

    The parser mutation is kept in one place so terminal commands, tests, and notebook
    examples expose the same options and defaults.
    """
    parser.add_argument(
        "--rrseq-cons-tsv",
        "--rrseq-tsv",
        dest="rrseq_tsv",
        type=Path,
        nargs="+",
        required=True,
        help="One or more RRseq_cons TSV files or directories containing them.",
    )
    parser.add_argument(
        "--rrseq-cons-occurrences",
        "--rrseq-occurrences",
        dest="rrseq_occurrences",
        type=Path,
        nargs="+",
        default=None,
        help=(
            "Authoritative *_rrseq_cons_occurrences.json sidecar(s). "
            "When omitted, matching sidecars are discovered beside the RRseq_cons TSVs."
        ),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help=(
            "Output TSV file or output directory. When a directory is given, "
            "<prefix>_composite_rules.tsv and sidecar files are written there."
        ),
    )
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--output-smi", "--output_smi", type=Path, default=None)
    parser.add_argument("--summary", type=Path, default=None)
    parser.add_argument("--errors", type=Path, default=None)
    parser.add_argument("--validation-output", type=Path, default=None)
    parser.add_argument("--validation-errors", type=Path, default=None)
    parser.add_argument("--certified-output", type=Path, default=None)
    add_rule_extraction_arguments(parser)
    parser.add_argument("--limit-rows", type=int, default=None)
    parser.add_argument("--limit-applications", type=int, default=None)
    parser.add_argument(
        "--max-replay-outcomes",
        type=int,
        default=256,
        help="Maximum unique composite outcomes examined per source occurrence.",
    )
    parser.add_argument(
        "--application-timeout-seconds",
        type=float,
        default=300.0,
        help=(
            "Maximum wall-clock seconds for replay, extraction, and validation "
            "of one exact occurrence. Timed-out occurrences are reported as "
            "inconclusive and do not enter certified output."
        ),
    )
    parser.add_argument(
        "--allow-ambiguous",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Certify mapped source outcomes even when other outcomes exist "
            "(default: enabled; --no-allow-ambiguous requires uniqueness)."
        ),
    )
    parser.add_argument(
        "--allow-legacy-unvalidated",
        action="store_true",
        help=(
            "Allow aggregate RRseq_cons TSVs without occurrence provenance. "
            "Legacy rows remain explicitly unvalidated."
        ),
    )
    parser.add_argument("--ignore-errors", action="store_true")
    parser.add_argument("--progress-interval", type=int, default=250)
    add_parallel_arguments(parser)


def add_gapped_composite_collection_arguments(parser: argparse.ArgumentParser) -> None:
    """Add RRseq_gap occurrence inputs for analysis-only gapped composites."""
    parser.add_argument(
        "--rrseq-gap-occurrences",
        dest="rrseq_gap_occurrences",
        type=Path,
        nargs="+",
        required=True,
        help="Extractor-owned *_rrseq_gap_occurrences.json sidecar(s) or directories.",
    )
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--summary", type=Path, default=None)
    parser.add_argument("--limit-occurrences", type=int, default=None)
    parser.add_argument(
        "--context-radius",
        type=int,
        default=2,
        help="Mapped local-environment radius used by factorability classification.",
    )
    parser.add_argument(
        "--max-replay-outcomes",
        type=int,
        default=256,
        help="Maximum selected-only replay outcomes examined per occurrence.",
    )
    parser.add_argument("--require-unique-replay", action="store_true")
    parser.add_argument("--protection-events", type=Path, default=None)
    parser.add_argument(
        "--detect-complementary",
        action="store_true",
        help=(
            "Enable the experimental complementary-restoration heuristic. "
            "Disabled by default pending a validated detector."
        ),
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help=(
            "Optional SynPlanner context configuration; defaults to "
            "route_inspector/configs/rule_extraction_functional_groups.yaml. Gapped collection "
            "always uses radius two, multicenter rules, the functional-group settings, "
            "and no leaving/incoming expansion."
        ),
    )
    add_parallel_arguments(parser)


def add_composite_classification_arguments(parser: argparse.ArgumentParser) -> None:
    """Add composite classification options to an argparse parser.

    The parser mutation is kept in one place so terminal commands, tests, and notebook
    examples expose the same options and defaults.
    """
    parser.add_argument("--composite-rules-tsv", type=Path, required=True)
    parser.add_argument("--default-rules-tsv", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--summary", type=Path, default=None)
    add_parallel_arguments(parser)


def add_composite_unwrap_arguments(parser: argparse.ArgumentParser) -> None:
    """Add composite unwrap options to an argparse parser.

    The parser mutation is kept in one place so terminal commands, tests, and notebook
    examples expose the same options and defaults.
    """
    parser.add_argument("--smiles", required=True, help="Target molecule SMILES.")
    rule_source = parser.add_mutually_exclusive_group(required=True)
    rule_source.add_argument("--composite-rule", help="Composite rule SMARTS.")
    rule_source.add_argument(
        "--composite-rule-tsv",
        type=Path,
        help="TSV containing an Composite_rule column.",
    )
    parser.add_argument("--row", type=int, default=0, help="0-based TSV row index.")
    parser.add_argument("--route-id", type=int, default=0)
    parser.add_argument("--output-json", type=Path, default=None)
    parser.add_argument("--output-svg", type=Path, default=None)
    parser.add_argument("--labeled", action="store_true")
    parser.add_argument("--do-not-mark-leaves-in-stock", action="store_true")
