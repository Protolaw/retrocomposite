"""CLI argument builders for route-motif and Retro-BLEU extraction."""

from __future__ import annotations

import argparse
from pathlib import Path

from route_inspector.cli.common import (
    add_extraction_identity_arguments,
    add_parallel_arguments,
    add_rule_extraction_arguments,
    add_source_id_adapter_argument,
)


def add_retro_bleu_gram_arguments(parser: argparse.ArgumentParser) -> None:
    """Add topology-contiguous Chython/SynPlanner gram options."""

    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Output directory. Defaults to outputs/<dataset>/13_retro_bleu.",
    )
    add_rule_extraction_arguments(parser)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--min-length", type=int, default=2)
    parser.add_argument("--max-length", type=int, default=5)
    parser.add_argument("--progress-interval", type=int, default=250)
    add_parallel_arguments(parser)
    parser.add_argument(
        "--worker-chunksize",
        type=int,
        default=16,
        help="Number of unique reactions sent to each extraction worker batch.",
    )


def add_route_motif_extraction_arguments(
    parser: argparse.ArgumentParser,
) -> None:
    """Add one-pass RRSeq and RRSubtree extraction options."""

    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=("Output root. Defaults to outputs/<dataset>/14_route_motifs."),
    )
    add_rule_extraction_arguments(parser)
    add_source_id_adapter_argument(parser)
    add_extraction_identity_arguments(parser)
    parser.add_argument(
        "--context-history",
        type=Path,
        default=None,
        help=(
            "Optional authoritative RouteContextHistory JSONL sidecar used to "
            "enrich exact t1 and RRSeq occurrences."
        ),
    )
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--rrseq-min-length", type=int, default=2)
    parser.add_argument("--rrseq-max-length", type=int, default=20)
    parser.add_argument("--rrsubtree-min-size", type=int, default=3)
    parser.add_argument("--rrsubtree-max-size", type=int, default=12)
    parser.add_argument(
        "--rrsubtree-max-candidates-per-route",
        type=int,
        default=100_000,
        help=(
            "Fail one route instead of truncating when tree enumeration "
            "exceeds this candidate count."
        ),
    )
    parser.add_argument(
        "--skip-routes-without-rrseqs-output",
        action="store_true",
        help=(
            "Do not write route-tree sidecars for routes without either "
            "RRSeq kind; counts and reasons remain in child summaries."
        ),
    )
    parser.add_argument(
        "--ignore-errors",
        action="store_true",
        help="Retain route-level diagnostics and continue processing.",
    )
    parser.add_argument("--progress-interval", type=int, default=250)
