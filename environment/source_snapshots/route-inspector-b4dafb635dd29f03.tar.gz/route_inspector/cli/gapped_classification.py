from __future__ import annotations

import argparse
from pathlib import Path

from route_inspector.workflows.gapped_classification import run


def add_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--rrseq-gap-occurrences",
        "--gapped-occurrences",
        dest="rrseq_gap_occurrences",
        type=Path,
        nargs="+",
        required=True,
        help="Exact *_rrseq_gap_occurrences.json sidecar(s) or directories.",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--output-prefix", default=None)
    parser.add_argument("--context-radius", type=int, default=2)
    parser.add_argument("--max-replay-outcomes", type=int, default=256)
    parser.add_argument("--require-unique-replay", action="store_true")
    parser.add_argument("--protection-events", type=Path, default=None)
    parser.add_argument(
        "--detect-complementary",
        action="store_true",
        help=(
            "Enable the experimental complementary-restoration heuristic. "
            "Disabled by default pending a validated detector."
        ),
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Classify exact gapped RRSeqs by structural factorability."
    )
    add_arguments(parser)
    return run(parser.parse_args(argv))
