"""Canonical CLI command definitions."""

from __future__ import annotations

import route_inspector.cli.gapped_classification as _gapped_arguments
import route_inspector.workflows.composite_classification as _owner_composite_classification
import route_inspector.workflows.composite_collection as _owner_composite_collection
import route_inspector.workflows.composite_unwrap as _owner_composite_unwrap
import route_inspector.workflows.diagnostics as _owner_diagnostics
import route_inspector.workflows.gapped_classification as _owner_gapped_classification
import route_inspector.workflows.retro_bleu as _owner_retro_bleu
import route_inspector.workflows.rrseq as _owner_corpus
import route_inspector.workflows.rrseq_unwrap as _owner_rrseq_unwrap
from route_inspector.cli import library_updates as _library_updates_cli
from route_inspector.cli import pg_recovery as _pg_recovery_cli
from route_inspector.cli import pg_strategy as _pg_cli
from route_inspector.cli import registry as _registry
from route_inspector.cli.common import (
    add_parallel_arguments as add_parallel_arguments,
)
from route_inspector.cli.common import (
    add_rule_extraction_arguments as add_rule_extraction_arguments,
)
from route_inspector.cli.common import (
    add_source_id_adapter_argument as add_source_id_adapter_argument,
)
from route_inspector.cli.composite_library import (
    add_composite_library_build_arguments,
    run_composite_library_build,
)
from route_inspector.cli.composites import (
    add_composite_classification_arguments,
    add_composite_extraction_arguments,
    add_composite_unwrap_arguments,
    add_gapped_composite_collection_arguments,
)
from route_inspector.cli.counterfactuals import (
    add_c3_counterfactual_arguments,
    run_c3_counterfactual_reassembly,
)
from route_inspector.cli.evidence import (
    add_context_history_arguments,
    add_generated_route_inspection_arguments,
    add_occurrence_context_migration_arguments,
    add_reference_index_arguments,
    run_context_history_annotation,
    run_generated_route_inspection,
    run_occurrence_context_migration,
    run_reference_index_build,
)
from route_inspector.cli.gui import add_gui_arguments, run_gui
from route_inspector.cli.motifs import (
    add_retro_bleu_gram_arguments,
    add_route_motif_extraction_arguments,
)
from route_inspector.cli.protection import (
    add_protection_arguments,
    add_protection_interval_rxnclass_arguments,
    run_protection_interval_rxnclass,
)
from route_inspector.cli.reference_assessment import (
    add_route_assessment_reference_arguments,
    add_route_corpus_assessment_arguments,
    run_route_assessment_reference_build,
    run_route_corpus_assessment,
)
from route_inspector.cli.reference_library import (
    add_pg_strategy_reclassification_arguments,
    add_reference_library_build_arguments,
    add_reference_library_verification_arguments,
    add_route_assessment_arguments,
    run_pg_strategy_reclassification,
    run_reference_library_build,
    run_reference_library_verification,
    run_route_assessment,
)
from route_inspector.cli.routes import (
    add_atom_provenance_arguments,
    add_preprocess_routes_arguments,
    run_preprocess_routes,
)
from route_inspector.cli.rrseq import (
    add_rrseq_extraction_arguments,
    add_rrseq_unwrap_arguments,
    add_rxnclass_rrseq_arguments,
    add_scoring_arguments,
    run_rrseq_scoring,
    run_rxnclass_rrseqs,
)
from route_inspector.workflows import motifs as motif_pipeline
from route_inspector.workflows.protection import (
    read_protection_route_ids as read_protection_route_ids,
)
from route_inspector.workflows.protection import run_protection_analysis


def _add_rrseq_gap_arguments(parser) -> None:
    add_rrseq_extraction_arguments(parser, "gap")


def _command_specs() -> tuple[_registry.CommandSpec, ...]:
    """Return the ordered public command registry."""

    return (
        _registry.CommandSpec(
            "append-library-routes",
            "Append routes and reuse unchanged tactic, PG and composite evidence.",
            _library_updates_cli.add_arguments,
            _library_updates_cli.run_append,
        ),
        _registry.CommandSpec(
            "replace-library-routes",
            "Replace routes and reuse unchanged tactic, PG and composite evidence.",
            _library_updates_cli.add_arguments,
            _library_updates_cli.run_replace,
        ),
        _registry.CommandSpec(
            "strip-pg-routes",
            "Strip introduced, removed PG lifecycles into a counterfactual corpus.",
            _pg_recovery_cli.add_strip_arguments,
            _pg_recovery_cli.run_strip,
        ),
        _registry.CommandSpec(
            "propose-pg-strategies",
            "Transfer PG n-gram evidence and evaluate original route recovery.",
            _pg_recovery_cli.add_propose_arguments,
            _pg_recovery_cli.run_propose,
        ),
        _registry.CommandSpec(
            "gui",
            "Explore routes and tactics in a local browser.",
            add_gui_arguments,
            run_gui,
        ),
        _registry.CommandSpec(
            "extract-rrseq-cons",
            "Extract consecutive reaction-rule sequences (RRseq_cons).",
            add_rrseq_extraction_arguments,
            _owner_corpus.run,
        ),
        _registry.CommandSpec(
            "extract-rrseq-gap",
            "Extract analysis-only gapped reaction-rule sequences (RRseq_gap).",
            _add_rrseq_gap_arguments,
            _owner_corpus.run_gapped,
        ),
        _registry.CommandSpec(
            "extract-route-motifs",
            "Extract both RRSeq kinds and consecutive/gapped RRSubtrees in one route preparation.",
            add_route_motif_extraction_arguments,
            motif_pipeline.run,
        ),
        _registry.CommandSpec(
            "extract-composite-rules",
            "Extract composite rules from executable RRseq_cons TSVs.",
            add_composite_extraction_arguments,
            _owner_composite_collection.run,
        ),
        _registry.CommandSpec(
            "collect-gapped-composite-rules",
            "Build selected-center SMARTS from analysis-only RRseq_gap occurrences.",
            add_gapped_composite_collection_arguments,
            _owner_composite_collection.run_gapped,
        ),
        _registry.CommandSpec(
            "classify-gapped-rrseqs",
            (
                "Classify exact gapped RRSeq occurrences by factorability; "
                "complementary detection is experimental and opt-in."
            ),
            _gapped_arguments.add_arguments,
            _owner_gapped_classification.run,
        ),
        _registry.CommandSpec(
            "extract-retro-bleu-grams",
            "Extract topology-contiguous Chython/SynPlanner reaction-rule n-grams.",
            add_retro_bleu_gram_arguments,
            _owner_retro_bleu.run,
        ),
        _registry.CommandSpec(
            "classify-composite-rules",
            "Classify composite rules as positive or negative.",
            add_composite_classification_arguments,
            _owner_composite_classification.run,
        ),
        _registry.CommandSpec(
            "classify-rrseq-cons-reactions",
            (
                "Classify representative RRseq_cons source reactions and aggregate "
                "provider-specific Tier-3 reaction-class sequences."
            ),
            add_rxnclass_rrseq_arguments,
            run_rxnclass_rrseqs,
        ),
        _registry.CommandSpec(
            "classify-protection-interval-reactions",
            (
                "Extract and classify reactions strictly between introduced "
                "protection and deprotection steps."
            ),
            add_protection_interval_rxnclass_arguments,
            run_protection_interval_rxnclass,
        ),
        _registry.CommandSpec(
            "unwrap-rrseq-cons",
            "Apply an executable RRseq_cons to a target molecule.",
            add_rrseq_unwrap_arguments,
            _owner_rrseq_unwrap.run,
        ),
        _registry.CommandSpec(
            "unwrap-composite-rule",
            "Apply one composite rule to a target molecule.",
            add_composite_unwrap_arguments,
            _owner_composite_unwrap.run,
        ),
        _registry.CommandSpec(
            "score-rrseq-cons-overlap",
            "Score extracted RRseq_cons values against reference route JSON.",
            add_scoring_arguments,
            run_rrseq_scoring,
        ),
        _registry.CommandSpec(
            "analyze-protection",
            "Analyze route-level protection/deprotection strategies.",
            add_protection_arguments,
            run_protection_analysis,
        ),
        _registry.CommandSpec(
            "preprocess-routes",
            (
                "Normalize PaRoutes datasets and split protection-related "
                "multicenter reactions."
            ),
            add_preprocess_routes_arguments,
            run_preprocess_routes,
        ),
        _registry.CommandSpec(
            "audit-route-provenance",
            "Audit product-only mapped atoms in normalized forward reactions.",
            add_atom_provenance_arguments,
            _owner_diagnostics.run,
        ),
        _registry.CommandSpec(
            "annotate-context-history",
            "Build one authoritative route-wide functional-group history sidecar.",
            add_context_history_arguments,
            run_context_history_annotation,
        ),
        _registry.CommandSpec(
            "migrate-occurrence-context",
            (
                "Reconstruct cached exact t1 evidence and attach route-context "
                "references to historical occurrence sidecars."
            ),
            add_occurrence_context_migration_arguments,
            run_occurrence_context_migration,
        ),
        _registry.CommandSpec(
            "build-reference-index",
            "Build an atomic all-corpus SQLite index from exact occurrence sidecars.",
            add_reference_index_arguments,
            run_reference_index_build,
        ),
        _registry.CommandSpec(
            "inspect-generated-routes",
            "Return counts and exact precedents for mapping-certified generated routes.",
            add_generated_route_inspection_arguments,
            run_generated_route_inspection,
        ),
        _registry.CommandSpec(
            "build-pg-strategy-library",
            "Build a standalone PG lifespan library from cleaned routes.",
            _pg_cli.add_build_arguments,
            _pg_cli.run_build,
        ),
        _registry.CommandSpec(
            "repack-pg-strategy-library",
            "Normalize an existing PG library without repeating chemistry extraction.",
            _pg_cli.add_repack_arguments,
            _pg_cli.run_repack,
        ),
        _registry.CommandSpec(
            "assess-pg-strategies",
            "Assess PG lifespans and n-grams against a standalone library.",
            _pg_cli.add_assess_arguments,
            _pg_cli.run_assess,
        ),
        _registry.CommandSpec(
            "verify-pg-strategy-library",
            "Fully verify a PG library and its lifespan n-grams.",
            _pg_cli.add_verify_arguments,
            _pg_cli.run_verify,
        ),
        _registry.CommandSpec(
            "build-reference-library",
            ("Build a versioned RRSeq/RRSubtree tactic library from Reference routes."),
            add_reference_library_build_arguments,
            run_reference_library_build,
        ),
        _registry.CommandSpec(
            "build-composite-library",
            (
                "Build certified RRSeq/RRSubtree composite decompositions "
                "from a Reference library."
            ),
            add_composite_library_build_arguments,
            run_composite_library_build,
        ),
        _registry.CommandSpec(
            "reclassify-pg-strategy-library",
            "Publish a NameRXN-classified sibling of an existing PG library.",
            add_pg_strategy_reclassification_arguments,
            run_pg_strategy_reclassification,
        ),
        _registry.CommandSpec(
            "verify-reference-library",
            "Run the complete integrity and scientific audit of a Reference library.",
            add_reference_library_verification_arguments,
            run_reference_library_verification,
        ),
        _registry.CommandSpec(
            "build-route-assessment-reference",
            "Freeze an n1 CGR-key precedent index for corpus assessment.",
            add_route_assessment_reference_arguments,
            run_route_assessment_reference_build,
        ),
        _registry.CommandSpec(
            "assess-routes",
            "Assess a complete query corpus against a frozen precedent index.",
            add_route_corpus_assessment_arguments,
            run_route_corpus_assessment,
        ),
        _registry.CommandSpec(
            "assess-route",
            "Assess exact known and novel route tactics against a Reference library.",
            add_route_assessment_arguments,
            run_route_assessment,
        ),
        _registry.CommandSpec(
            "counterfactual-reassembly-rrseq-free",
            (
                "Test reversed adjacent-rule replay in routes containing neither "
                "RRSeq kind."
            ),
            add_c3_counterfactual_arguments,
            run_c3_counterfactual_reassembly,
        ),
    )
