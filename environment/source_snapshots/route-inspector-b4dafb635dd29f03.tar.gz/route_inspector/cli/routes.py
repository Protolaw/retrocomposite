"""CLI parsers and lazy runners for route preparation and diagnostics."""

from __future__ import annotations

import argparse
from pathlib import Path

import route_inspector.workflows.preprocessing as _owner_preprocessing
from route_inspector.cli.common import (
    add_parallel_arguments,
    add_rule_extraction_arguments,
)


def add_preprocess_routes_arguments(parser: argparse.ArgumentParser) -> None:
    """Add PaRoutes preprocessing options to an argparse parser."""
    parser.add_argument("--input-dir", type=Path, default=Path("data/raw"))
    parser.add_argument("--output-dir", type=Path, default=Path("data/clean"))
    parser.add_argument(
        "--summary-dir",
        type=Path,
        default=None,
        help=(
            "Optional output root for generated preprocessing reports. When set, "
            "files are written under <summary-dir>/<dataset>/00_preprocess/."
        ),
    )
    parser.add_argument(
        "--datasets",
        nargs="+",
        default=["n1_routes.json", "n5_routes.json"],
        help=(
            "Dataset filenames to preprocess. Missing underscore names are resolved "
            "against the PaRoutes hyphenated filenames when needed."
        ),
    )
    add_rule_extraction_arguments(parser)
    parser.add_argument("--protection-config", type=Path, default=None)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--ignore-errors", action="store_true")
    parser.add_argument(
        "--compact-reports",
        action="store_true",
        help="Write cleaned routes and summary counts only; omit large per-route report payloads.",
    )
    parser.add_argument(
        "--cache-reset-interval",
        type=int,
        default=0,
        help="Clear the per-reaction preprocessing cache every N routes (0 disables it).",
    )
    parser.add_argument(
        "--progress-interval",
        type=int,
        default=100,
        help="Print route-level progress every N processed routes. Use 0 to disable.",
    )
    add_parallel_arguments(parser)


def add_atom_provenance_arguments(parser: argparse.ArgumentParser) -> None:
    """Add route-level atom-provenance diagnostic options."""
    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument(
        "--output-dir",
        type=Path,
        required=True,
        help="Directory for atom-provenance TSV and JSON diagnostic artifacts.",
    )


def run_preprocess_routes(args: argparse.Namespace) -> int:
    """Run PaRoutes preprocessing using configured inputs."""

    from route_inspector.cli.common import workflow_request
    from route_inspector.workflows.requests import PreprocessRoutesRequest

    return _owner_preprocessing.run(workflow_request(PreprocessRoutesRequest, args))
