"""CLI adapter for counterfactual route reassembly experiments."""

from __future__ import annotations

import argparse
from pathlib import Path

from route_inspector.cli.common import add_parallel_arguments


def add_c3_counterfactual_arguments(parser: argparse.ArgumentParser) -> None:
    """Add the Experiment C3 command-line arguments."""

    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--reference-library", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--max-replay-outcomes", type=int, default=256)
    parser.add_argument("--max-counterfactuals-per-pair", type=int, default=256)
    parser.add_argument(
        "--pair-timeout-seconds",
        type=float,
        default=300.0,
        help="Hard timeout per adjacent pair; use 0 to disable.",
    )
    parser.add_argument("--progress-interval", type=int, default=25)
    parser.add_argument("--ignore-errors", action="store_true")
    parser.add_argument(
        "--reaction-class-backend",
        choices=("none", "reactionclassifier", "namerxn"),
        default="none",
    )
    parser.add_argument("--reaction-classifier-path", type=Path, default=None)
    parser.add_argument(
        "--namerxn-path",
        "--namerxn-executable",
        dest="namerxn_path",
        type=Path,
        default=None,
        help="NameRXN executable or HazELNut project directory.",
    )
    parser.add_argument(
        "--reaction-class-label-policy",
        choices=("confirmed-only", "confirmed-or-neural"),
        default="confirmed-or-neural",
    )
    parser.add_argument("--reaction-class-worker-chunksize", type=int, default=100)
    parser.add_argument("--reaction-class-torch-threads", type=int, default=1)
    parser.add_argument(
        "--reaction-class-device",
        choices=("cpu",),
        default="cpu",
    )
    add_parallel_arguments(parser)


def run_c3_counterfactual_reassembly(args: argparse.Namespace) -> int:
    """Run and publish the RRSeq-free counterfactual experiment."""

    from route_inspector.routes.counterfactuals import C3ReplayLimits
    from route_inspector.workflows.counterfactuals import (
        generate_rrseq_free_counterfactuals,
    )

    result = generate_rrseq_free_counterfactuals(
        args.routes_json,
        args.reference_library,
        args.config,
        args.output_dir,
        n_cpu=args.n_cpu,
        limits=C3ReplayLimits(
            max_replay_outcomes=args.max_replay_outcomes,
            max_counterfactuals_per_pair=args.max_counterfactuals_per_pair,
            pair_timeout_seconds=(
                None if args.pair_timeout_seconds == 0 else args.pair_timeout_seconds
            ),
        ),
        progress_interval=args.progress_interval,
        ignore_errors=args.ignore_errors,
        reaction_class_backend=(
            None
            if args.reaction_class_backend == "none"
            else args.reaction_class_backend
        ),
        reaction_classifier_path=args.reaction_classifier_path,
        namerxn_path=args.namerxn_path,
        reaction_class_label_policy=args.reaction_class_label_policy,
        reaction_class_torch_threads=args.reaction_class_torch_threads,
        reaction_class_device=args.reaction_class_device,
        reaction_class_worker_chunksize=args.reaction_class_worker_chunksize,
    )
    print(
        f"built {result.manifest['experiment_id']}: "
        f"{result.statistics['eligible_route_count']} eligible routes, "
        f"{result.statistics['routes_with_published_alternative']} alternatives"
    )
    print(
        "phase timings (seconds): "
        + ", ".join(
            f"{name}={seconds:.2f}" for name, seconds in result.phase_timings.items()
        )
    )
    return 0


__all__ = [
    "add_c3_counterfactual_arguments",
    "run_c3_counterfactual_reassembly",
]
