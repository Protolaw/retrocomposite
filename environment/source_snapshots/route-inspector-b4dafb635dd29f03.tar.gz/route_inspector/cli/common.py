"""Shared CLI argument builders."""

from __future__ import annotations

import argparse
from pathlib import Path

from route_inspector.datasets.paroutes.source_ids import PAROUTES_SOURCE_ID_ADAPTER
from route_inspector.datasets.source_ids import SOURCE_ID_ADAPTER_CHOICES


def add_rule_extraction_arguments(
    parser: argparse.ArgumentParser,
    *,
    config_required: bool = False,
) -> None:
    """Add rule extraction options to an argparse parser.

    The parser mutation is kept in one place so terminal commands, tests, and notebook
    examples expose the same options and defaults.
    """
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        required=config_required,
    )
    if config_required:
        # A persisted reference index is keyed by the canonical extraction
        # configuration hash.  Per-flag overrides would either be ignored by
        # RuleExtractionConfig.from_yaml or silently make that provenance false.
        return
    parser.add_argument("--environment-atom-count", type=int, default=1)
    parser.add_argument("--include-rings", action="store_true")
    parser.add_argument("--keep-leaving-groups", action="store_true", default=True)
    parser.add_argument(
        "--drop-leaving-groups",
        dest="keep_leaving_groups",
        action="store_false",
    )
    parser.add_argument("--keep-incoming-groups", action="store_true")
    parser.add_argument("--reactor-validation", action="store_true")


def add_parallel_arguments(parser: argparse.ArgumentParser) -> None:
    """Add parallel options to an argparse parser.

    The parser mutation is kept in one place so terminal commands, tests, and notebook
    examples expose the same options and defaults.
    """
    parser.add_argument(
        "--n_cpu",
        "--n-cpu",
        type=int,
        default=1,
        dest="n_cpu",
        help="Number of worker processes to use. Use 1 for sequential execution.",
    )


def add_extraction_identity_arguments(parser: argparse.ArgumentParser) -> None:
    """Add stable corpus/source identity overrides for occurrence extraction."""

    parser.add_argument(
        "--dataset-id",
        default=None,
        help=(
            "Stable corpus identity; defaults to the dataset inferred from "
            "--routes-json. Use the same value as annotate-context-history."
        ),
    )
    parser.add_argument(
        "--source-identity",
        default=None,
        help=(
            "Stable source identity; defaults to the resolved routes path. Use "
            "the same value as annotate-context-history."
        ),
    )


def add_source_id_adapter_argument(parser: argparse.ArgumentParser) -> None:
    """Add the corpus-specific source provenance policy."""

    parser.add_argument(
        "--source-id-adapter",
        choices=SOURCE_ID_ADAPTER_CHOICES,
        default=PAROUTES_SOURCE_ID_ADAPTER,
        help=(
            "How reaction metadata IDs are interpreted. The PaRoutes default keeps "
            "the full record ID and parses the component before ';' as the source "
            "document; 'raw' preserves opaque IDs and leaves document IDs empty."
        ),
    )


def workflow_request(request_type, args):
    """Translate parsed options into a typed request at the interface boundary."""
    from dataclasses import fields

    names = {field.name for field in fields(request_type)}
    values = {key: value for key, value in vars(args).items() if not callable(value)}
    unknown = values.keys() - names
    if unknown:
        raise ValueError(f"unrecognized workflow options: {sorted(unknown)}")
    return request_type(**values)


def add_build_storage_arguments(parser):
    """Optional durable build controls shared by library construction commands."""
    from pathlib import Path

    parser.add_argument(
        "--work-dir",
        type=Path,
        help="Durable build workspace; defaults beside the output.",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume a compatible retained build checkpoint.",
    )
    parser.add_argument(
        "--memory-budget-mb",
        type=int,
        default=512,
        help="Application buffer budget in MiB; chemistry-worker RSS is additional (default: 512).",
    )
