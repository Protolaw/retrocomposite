"""Route-level append and replacement of immutable library revisions."""

from pathlib import Path

from route_inspector.cli.common import (
    add_build_storage_arguments,
    add_parallel_arguments,
    workflow_request,
)
from route_inspector.datasets.bindings import DATASETS
from route_inspector.workflows.requests import (
    AppendLibraryRoutesRequest,
    ReplaceLibraryRoutesRequest,
)


def add_arguments(parser):
    parser.add_argument(
        "--routes-json",
        type=Path,
        required=True,
        help="Complete current source JSON matching the baseline libraries.",
    )
    parser.add_argument(
        "--changes-json",
        type=Path,
        required=True,
        help="JSON object keyed by stable route IDs, containing only new/replacement routes.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        required=True,
        help="New revision directory; existing publications are never overwritten.",
    )
    for name in ("reference-library", "pg-library", "composite-library"):
        parser.add_argument(f"--{name}", type=Path)
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("route_inspector/configs/rule_extraction_small.yaml"),
        help="Same tactic/composite extraction configuration as the baseline.",
    )
    add_build_storage_arguments(parser)
    add_parallel_arguments(parser)
    parser.add_argument("--progress-interval", type=int, default=25)
    parser.add_argument(
        "--ignore-errors",
        action="store_true",
        help="Retain failed NEW composite constructions as diagnostics; extraction still fails closed.",
    )
    parser.add_argument("--reaction-classifier-path", type=Path)
    parser.add_argument("--namerxn-executable", type=Path)
    parser.add_argument(
        "--gui-dataset",
        choices=DATASETS,
        help="Atomically activate the complete verified revision in the GUI.",
    )
    parser.add_argument("--workspace", type=Path, default=Path("."))


def _run(args, mode):
    from route_inspector.workflows.library_updates import update_library_routes

    request_type = (
        AppendLibraryRoutesRequest if mode == "append" else ReplaceLibraryRoutesRequest
    )
    result = update_library_routes(workflow_request(request_type, args), mode=mode)
    print(f"Published {mode} revision at {result}")
    return 0


def run_append(args):
    return _run(args, "append")


def run_replace(args):
    return _run(args, "replace")
