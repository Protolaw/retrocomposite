"""CLI adapters for frozen corpus-level Reference assessment."""

from __future__ import annotations

import argparse
from pathlib import Path


def _add_verification(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--verification",
        choices=("fast", "full"),
        default="fast",
        help=(
            "Use fast manifest/catalog checks (default), or hash and audit every "
            "declared source artifact."
        ),
    )


def add_route_assessment_reference_arguments(
    parser: argparse.ArgumentParser,
) -> None:
    """Add arguments for freezing one Reference precedent index."""

    parser.add_argument("--reference-library", type=Path, required=True)
    parser.add_argument("--composite-library", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    _add_verification(parser)


def run_route_assessment_reference_build(args: argparse.Namespace) -> int:
    """Build the immutable CGR-key Reference index."""

    from route_inspector.workflows.corpus_assessment import (
        build_route_assessment_reference,
    )

    library = build_route_assessment_reference(
        args.reference_library,
        args.composite_library,
        args.output_dir,
        verification=args.verification,
    )
    try:
        print(
            f"built {library.reference_id}: "
            f"{library.manifest['statistics']['family_count']} families"
        )
    finally:
        library.close()
    return 0


def add_route_corpus_assessment_arguments(parser: argparse.ArgumentParser) -> None:
    """Add arguments for assessing one complete query corpus."""

    parser.add_argument("--reference-assessment", type=Path, required=True)
    parser.add_argument("--query-reference-library", type=Path, required=True)
    parser.add_argument("--query-composite-library", type=Path, required=True)
    parser.add_argument("--query-routes-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    _add_verification(parser)


def run_route_corpus_assessment(args: argparse.Namespace) -> int:
    """Assess all query routes against a frozen CGR-key precedent index."""

    from route_inspector.workflows.corpus_assessment import assess_route_corpus

    manifest = assess_route_corpus(
        args.reference_assessment,
        args.query_reference_library,
        args.query_composite_library,
        args.query_routes_json,
        args.output_dir,
        verification=args.verification,
    )
    print(
        f"built {manifest['assessment_id']}: "
        f"{manifest['statistics']['query_route_count']} query routes"
    )
    return 0


__all__ = [
    "add_route_assessment_reference_arguments",
    "add_route_corpus_assessment_arguments",
    "run_route_assessment_reference_build",
    "run_route_corpus_assessment",
]
