"""Persist source-bound NameRxn annotations without extracting reaction rules."""

import argparse
import json
from pathlib import Path

from route_inspector.workflows.reaction_annotations import annotate_routes


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--routes", type=Path, default=Path("data/clean/n1_routes.json")
    )
    parser.add_argument(
        "--library", type=Path, default=Path("outputs/reference_libraries/n1")
    )
    parser.add_argument("--dataset", default="n1")
    parser.add_argument("--namerxn-path", type=Path, required=True)
    parser.add_argument(
        "--output-dir", type=Path, default=Path("outputs/n1/namerxn_annotations")
    )
    parser.add_argument("--batch-size", type=int, default=100)
    args = parser.parse_args(argv)
    summary = annotate_routes(
        routes_path=args.routes,
        library_dir=args.library,
        executable=args.namerxn_path,
        output_dir=args.output_dir,
        dataset_id=args.dataset,
        batch_size=args.batch_size,
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
