"""CLI parsers and lazy runners for Reference tactic libraries."""

from __future__ import annotations

import argparse
from pathlib import Path

from route_inspector.cli.common import (
    add_parallel_arguments,
    add_source_id_adapter_argument,
)


def _add_processing_arguments(
    parser: argparse.ArgumentParser,
    *,
    assessment: bool,
) -> None:
    parser.add_argument(
        "--config",
        type=Path,
        required=True,
        help=(
            "SynPlanner rule-extraction YAML. Assessment requires the same "
            "scientific configuration recorded by the Reference library."
        ),
    )
    parser.add_argument(
        "--input-state",
        choices=("raw", "preprocessed"),
        default=None if assessment else "preprocessed",
        help=(
            "Whether routes still require reaction-granularity preprocessing. "
            "Assessment defaults to the state recorded by the library."
        ),
    )
    parser.add_argument(
        "--protection-config",
        type=Path,
        default=None,
        help=(
            "Optional protection/preprocessing YAML. It affects compatibility "
            "when --input-state=raw, but never tactic identity directly."
        ),
    )
    add_source_id_adapter_argument(parser)
    if assessment:
        parser.set_defaults(source_id_adapter=None)
    parser.add_argument(
        "--rrseq-min-length", type=int, default=None if assessment else 2
    )
    parser.add_argument(
        "--rrseq-max-length", type=int, default=None if assessment else 20
    )
    parser.add_argument(
        "--rrsubtree-min-size", type=int, default=None if assessment else 3
    )
    parser.add_argument(
        "--rrsubtree-max-size", type=int, default=None if assessment else 12
    )
    parser.add_argument(
        "--rrsubtree-max-candidates-per-route",
        type=int,
        default=None if assessment else 100_000,
    )
    parser.add_argument(
        "--classify-gap-factorability",
        action=argparse.BooleanOptionalAction,
        default=None if assessment else False,
        help=(
            "Attach occurrence-level RRSeq-gap factorability evidence. "
            "Factorability is not part of normalized tactic identity."
        ),
    )
    parser.add_argument(
        "--factorability-context-radius",
        type=int,
        default=None if assessment else 2,
    )
    parser.add_argument(
        "--factorability-max-replay-outcomes",
        type=int,
        default=None if assessment else 256,
    )
    parser.add_argument(
        "--factorability-require-unique-replay",
        action=argparse.BooleanOptionalAction,
        default=None if assessment else False,
        help=(
            "Require one unique selected-only replay outcome when classifying "
            "RRSeq-gap factorability. Assessment inherits the library setting."
        ),
    )


def add_reference_library_build_arguments(parser: argparse.ArgumentParser) -> None:
    """Add the one-command Reference-corpus library workflow."""

    from route_inspector.cli.common import add_build_storage_arguments

    add_build_storage_arguments(parser)
    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--reference-id",
        required=True,
        help="Stable scientific identifier for the Reference route corpus.",
    )
    parser.add_argument(
        "--source-identity",
        default=None,
        help=(
            "Stable source identity. Defaults to a content-derived SHA-256 "
            "identity rather than a workstation path."
        ),
    )
    _add_processing_arguments(parser, assessment=False)
    add_parallel_arguments(parser)
    parser.add_argument(
        "--sqlite-catalog",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Include the optional SQLite lazy-lookup accelerator. "
            "Use --no-sqlite-catalog for a JSONL-only portable library."
        ),
    )
    parser.add_argument(
        "--retro-bleu-bigrams",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Include exact ordered topology-contiguous rule bigrams as a "
            "supplementary Reference-evidence component."
        ),
    )
    parser.add_argument(
        "--audit-key-isomorphism",
        action="store_true",
        help=(
            "Run the optional legacy graph-isomorphism audit for possible "
            "CGR-key family splits. The report never changes catalog identities "
            "or the library ID."
        ),
    )
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--progress-interval", type=int, default=250)


def add_pg_strategy_reclassification_arguments(
    parser: argparse.ArgumentParser,
) -> None:
    """Add provider-only PG classification migration options."""

    parser.add_argument("--source-library", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--namerxn-path",
        "--namerxn-executable",
        dest="namerxn_executable",
        type=Path,
        default=None,
        help=(
            "NameRXN executable or HazELNut project directory. If omitted, "
            "the namerxn command is resolved from PATH."
        ),
    )
    parser.add_argument("--worker-chunksize", type=int, default=500)


def add_route_assessment_arguments(parser: argparse.ArgumentParser) -> None:
    """Add exact known/novel assessment options for one or a few routes."""

    parser.add_argument(
        "--routes-json", "--route", dest="routes_json", type=Path, required=True
    )
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--verification",
        choices=("fast", "full"),
        default="fast",
        help=(
            "Library verification policy: fast (default) trusts a previously "
            "verified, unchanged library and skips whole-file hash checks on "
            "the SQLite path; full audits persisted integrity and scientific "
            "consistency before assessment. Both retain exact candidate matching."
        ),
    )
    parser.add_argument("--route-id", default=None)
    parser.add_argument("--dataset-id", default=None)
    parser.add_argument(
        "--source-identity",
        default=None,
        help=(
            "Stable query-source identity. Defaults to a content-derived "
            "SHA-256 identity."
        ),
    )
    _add_processing_arguments(parser, assessment=True)
    parser.add_argument(
        "--pg-strategies",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Assess PG strategies automatically when available, or disable them "
            "explicitly with --no-pg-strategies."
        ),
    )
    parser.add_argument("--limit", type=int, default=None)


def add_reference_library_verification_arguments(
    parser: argparse.ArgumentParser,
) -> None:
    """Add the explicit complete Reference-library audit."""

    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument(
        "--backend",
        choices=("auto", "sqlite", "jsonl"),
        default="auto",
        help="Backend whose complete persisted contract should be verified.",
    )


def run_reference_library_build(args: argparse.Namespace) -> int:
    """Build a reloadable Reference tactic library lazily."""

    from route_inspector.cli.common import workflow_request
    from route_inspector.workflows.reference_library import run_build_reference_library
    from route_inspector.workflows.requests import BuildReferenceLibraryRequest

    return run_build_reference_library(
        workflow_request(BuildReferenceLibraryRequest, args)
    )


def run_pg_strategy_reclassification(args: argparse.Namespace) -> int:
    """Publish a provider-specific NameRXN PG-library sibling."""

    from route_inspector.chemistry.classification.providers import create_provider
    from route_inspector.reference_library.migration.pg_reclassification import (
        reclassify_pg_strategy_library_to_directory,
    )

    provider = create_provider(
        "namerxn",
        namerxn_path=args.namerxn_executable,
    )
    print(
        "[reclassify-pg-strategy-library] classifying PG interval reactions "
        f"with NameRXN {provider.provider_version}",
        flush=True,
    )

    def report_progress(completed: int, total: int) -> None:
        width = 30
        filled = width if total == 0 else int(width * completed / total)
        bar = "#" * filled + "-" * (width - filled)
        end = "\n" if completed == total else ""
        print(
            f"\r[NameRXN] [{bar}] {completed}/{total}",
            end=end,
            flush=True,
        )

    result = reclassify_pg_strategy_library_to_directory(
        args.source_library,
        args.output_dir,
        provider,
        classifier_metadata={
            "acceptance_policy": "recognized-numeric-tier3",
            "device": "cpu",
        },
        worker_chunksize=args.worker_chunksize,
        progress_callback=report_progress,
    )
    print(
        "[reclassify-pg-strategy-library] wrote "
        f"{result.interval_step_occurrences} interval-step occurrences "
        f"({result.unique_classifier_inputs} unique classifier inputs) to "
        f"{result.output_path}",
        flush=True,
    )
    return 0


def run_reference_library_verification(args: argparse.Namespace) -> int:
    """Run every persisted scientific and integrity check."""

    from route_inspector.reference_library import ReferenceTacticLibrary

    manifest = ReferenceTacticLibrary.verify(
        args.library,
        backend=args.backend,
    )
    print(f"verified Reference tactic library {manifest.library_id}")
    return 0


def run_route_assessment(args: argparse.Namespace) -> int:
    """Assess new routes against a persisted Reference tactic library lazily."""

    from route_inspector.cli.common import workflow_request
    from route_inspector.workflows.reference_library import run_assess_routes
    from route_inspector.workflows.requests import AssessRouteRequest

    return run_assess_routes(workflow_request(AssessRouteRequest, args))


__all__ = [
    "add_pg_strategy_reclassification_arguments",
    "add_reference_library_build_arguments",
    "add_reference_library_verification_arguments",
    "add_route_assessment_arguments",
    "run_pg_strategy_reclassification",
    "run_reference_library_build",
    "run_reference_library_verification",
    "run_route_assessment",
]
