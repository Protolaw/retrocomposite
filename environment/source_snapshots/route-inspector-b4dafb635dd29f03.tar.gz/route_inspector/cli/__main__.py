"""Support ``python -m route_inspector.cli`` alongside the installed command."""

from route_inspector.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
