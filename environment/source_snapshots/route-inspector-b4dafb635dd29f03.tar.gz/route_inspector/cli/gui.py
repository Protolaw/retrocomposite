"""Optional GUI launcher; normal CLI commands do not import web dependencies."""

from pathlib import Path


def add_gui_arguments(parser):
    parser.add_argument("--workspace", type=Path, default=Path.cwd())
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Bind address (default: loopback). Containers may use 0.0.0.0 with a localhost-only published port.",
    )
    parser.add_argument(
        "--ssl-certfile", type=Path, help="Certificate PEM; pair with --ssl-keyfile."
    )
    parser.add_argument(
        "--ssl-keyfile", type=Path, help="Private key PEM; pair with --ssl-certfile."
    )
    parser.add_argument(
        "--http",
        action="store_true",
        help="Explicitly disable HTTPS (for an existing secure local proxy/tunnel).",
    )


def run_gui(args):
    if not 1 <= args.port <= 65535:
        raise ValueError("port must be between 1 and 65535")
    try:
        from route_inspector.gui.app import launch
    except ModuleNotFoundError as exc:
        if exc.name != "nicegui":
            raise
        raise RuntimeError(
            "GUI dependencies are missing; install route-inspector[gui]"
        ) from exc
    launch(
        args.workspace.resolve(strict=True),
        args.port,
        host=args.host,
        https=not args.http,
        ssl_certfile=args.ssl_certfile,
        ssl_keyfile=args.ssl_keyfile,
    )
    return 0
