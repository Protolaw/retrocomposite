"""CLI argument builders and lazy runners for RRSeq commands."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import route_inspector.workflows.reaction_classes as _owner_reaction_classes
from route_inspector.cli.common import (
    add_extraction_identity_arguments,
    add_parallel_arguments,
    add_rule_extraction_arguments,
    add_source_id_adapter_argument,
)


def add_rrseq_extraction_arguments(
    parser: argparse.ArgumentParser,
    sequence_kind: str = "cons",
) -> None:
    """Add RRseq_cons/RRseq_gap extraction options to a parser.

    The parser mutation is kept in one place so terminal commands, tests, and notebook
    examples expose the same options and defaults.
    """
    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help=(
            "Output prefix/path. Separate files are written as "
            "<prefix>_t<size>_rrseq_cons.tsv or *_rrseq_gap.tsv."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=(
            "Directory where standard <dataset>_t<size> rule files and sidecars "
            "are written. The dataset is inferred from --routes-json."
        ),
    )
    add_rule_extraction_arguments(parser)
    add_source_id_adapter_argument(parser)
    add_extraction_identity_arguments(parser)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--min-length", type=int, default=2)
    parser.add_argument("--max-length", type=int, default=20)
    parser.add_argument(
        "--context-history",
        type=Path,
        default=None,
        help=(
            "Optional authoritative RouteContextHistory JSONL sidecar. Exact t1 and "
            "RRSeq occurrences are projected and receive route/projection references."
        ),
    )
    variant = "gap" if sequence_kind == "gap" else "cons"
    parser.add_argument(
        f"--routes-without-rrseq-{variant}-output",
        "--routes-without-rrseqs-output",
        dest="routes_without_rrseqs_output",
        type=Path,
        default=None,
        help=(
            "Optional path for routes that were processed successfully but "
            "did not produce the selected RRSeq variant, as a get_route_svg_from_json-"
            "readable JSON lookup. Defaults to "
            "<output-prefix>_routes_without_rrseq_<cons|gap>.json."
        ),
    )
    parser.add_argument(
        f"--skip-routes-without-rrseq-{variant}-output",
        "--skip-routes-without-rrseqs-output",
        dest="skip_routes_without_rrseqs_output",
        action="store_true",
        help=(
            "Do not write the routes_without_rrseq_<cons|gap> JSON sidecar. "
            "This is much faster and lighter for very large route collections; "
            "summary counts and reasons are still reported."
        ),
    )
    parser.add_argument(
        "--unique-reactions-first",
        action="store_true",
        help=(
            "Use a two-pass extraction plan: scan routes for unique normalized "
            "reaction SMILES, extract each unique reaction rule once, then "
            "compose route RRSeqs from the precomputed rule cache."
        ),
    )
    parser.add_argument("--ignore-errors", action="store_true")
    parser.add_argument("--progress-interval", type=int, default=250)
    add_parallel_arguments(parser)
    parser.add_argument(
        "--worker-chunksize",
        type=int,
        default=16,
        help=(
            "Number of routes sent to each worker task during parallel rrseq "
            "extraction. Larger values reduce multiprocessing overhead."
        ),
    )
    parser.add_argument(
        "--max-pending-chunks",
        type=int,
        default=None,
        help=(
            "Maximum queued worker chunks for parallel rrseq extraction. "
            "Defaults to 2 * n_cpu."
        ),
    )


def add_rxnclass_rrseq_arguments(parser: argparse.ArgumentParser) -> None:
    """Add dynamic Tier-3 reaction-class sequence options."""

    parser.add_argument(
        "--rrseq-cons-tsv",
        dest="rrseq_cons_tsv",
        type=Path,
        nargs="+",
        required=True,
        help="One or more RRseq_cons TSV files or directories containing them.",
    )
    parser.add_argument(
        "--rrseq-cons-occurrences",
        dest="rrseq_cons_occurrences",
        type=Path,
        nargs="+",
        default=None,
        help=(
            "Authoritative *_rrseq_cons_occurrences.json sidecar(s). When omitted, "
            "matching versioned sidecars are discovered beside the RRseq_cons TSVs."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Output directory. Defaults to outputs/<dataset>/31_rxnclass_rrseqs.",
    )
    parser.add_argument(
        "--mode",
        choices=("dynamic",),
        default="dynamic",
        help="Reaction-class source mode. Static restoration is not yet implemented.",
    )
    parser.add_argument(
        "--backend",
        choices=("reactionclassifier", "namerxn"),
        default="reactionclassifier",
        help="Reaction-classification provider used for this output directory.",
    )
    parser.add_argument(
        "--reaction-classifier-path",
        type=Path,
        default=None,
        help="Optional ReactionClassifier checkout or src directory.",
    )
    parser.add_argument(
        "--namerxn-path",
        "--namerxn-executable",
        dest="namerxn_executable",
        type=Path,
        default=None,
        help=(
            "NameRXN executable or HazELNut project directory. "
            "The --namerxn-executable spelling is retained as an alias."
        ),
    )
    parser.add_argument(
        "--tier",
        type=int,
        choices=(3,),
        default=3,
        help="Taxonomy depth. Only Tier 3 is supported in this version.",
    )
    parser.add_argument(
        "--label-policy",
        choices=("confirmed-only", "confirmed-or-neural"),
        default="confirmed-or-neural",
        help=(
            "Acceptance policy. By default, valid neural Tier-3 predictions "
            "are included and remain identified as neural_only in the audit."
        ),
    )
    add_parallel_arguments(parser)
    parser.add_argument(
        "--worker-chunksize",
        type=int,
        default=100,
        help="Number of canonical reactions assigned per worker task.",
    )
    parser.add_argument(
        "--torch-threads",
        type=int,
        default=1,
        help="PyTorch intra-process thread count for each classifier worker.",
    )
    parser.add_argument(
        "--device",
        choices=("cpu",),
        default="cpu",
        help="Classifier device. This version supports CPU execution only.",
    )
    parser.add_argument("--limit-rows", type=int, default=None)
    parser.add_argument(
        "--ignore-errors",
        action="store_true",
        help=(
            "Retain per-reaction classification failures as UNCLASSIFIED. "
            "Input/provenance and provider setup failures remain fatal."
        ),
    )
    parser.add_argument(
        "--progress-interval",
        type=int,
        default=250,
        help="Report progress every N unique classifier inputs; use 0 to disable.",
    )


def add_rrseq_unwrap_arguments(parser: argparse.ArgumentParser) -> None:
    """Add executable RRseq_cons unwrap options to an argparse parser.

    The parser mutation is kept in one place so terminal commands, tests, and notebook
    examples expose the same options and defaults.
    """
    parser.add_argument("--smiles", required=True, help="Target molecule SMILES.")
    rule_source = parser.add_mutually_exclusive_group(required=True)
    rule_source.add_argument(
        "--rrseq-cons",
        "--rrseq",
        dest="rrseq",
        help="RRseq_cons rule string.",
    )
    rule_source.add_argument(
        "--rrseq-cons-tsv",
        "--rrseq-tsv",
        dest="rrseq_tsv",
        type=Path,
        help="TSV containing an RRseq_cons column.",
    )
    parser.add_argument("--row", type=int, default=0, help="0-based TSV row index.")
    parser.add_argument("--route-id", type=int, default=0)
    parser.add_argument("--output-json", type=Path, default=None)
    parser.add_argument("--output-svg", type=Path, default=None)
    parser.add_argument("--labeled", action="store_true")
    parser.add_argument("--do-not-mark-leaves-in-stock", action="store_true")


def add_scoring_arguments(parser: argparse.ArgumentParser) -> None:
    """Add scoring options to an argparse parser.

    The parser mutation is kept in one place so terminal commands, tests, and notebook
    examples expose the same options and defaults.
    """
    parser.add_argument(
        "--extracted-tsv",
        "--rrseq-cons-tsv",
        "--rrseq-tsv",
        type=Path,
        nargs="+",
        required=True,
        dest="extracted_tsv",
        help="One or more extracted RRseq_cons TSV files or directories.",
    )
    parser.add_argument(
        "--reference-routes-json",
        "--routes-json",
        type=Path,
        required=True,
        dest="reference_routes_json",
        help="Reference route JSON. RRseq_cons values are extracted from this file.",
    )
    parser.add_argument(
        "--classification-tsv",
        type=Path,
        nargs="+",
        default=None,
        help=(
            "Optional classified composite rule TSV files or directories. "
            "Their RRseq_cons links are used to compute pos_overlap and "
            "neg_overlap."
        ),
    )
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=None)
    add_rule_extraction_arguments(parser)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--min-length", type=int, default=2)
    parser.add_argument("--max-length", type=int, default=20)
    parser.add_argument("--ignore-errors", action="store_true")
    parser.add_argument("--progress-interval", type=int, default=250)
    add_parallel_arguments(parser)


def run_rxnclass_rrseqs(args: argparse.Namespace) -> int:
    """Run dynamic Tier-3 RRseq_cons reaction classification lazily."""

    summary = _owner_reaction_classes.classify_reactions(args)
    print(json.dumps(summary, indent=2))
    return 0


def run_rrseq_scoring(args) -> int:
    """Present the scoring workflow result at the terminal boundary."""
    from route_inspector.workflows.scoring import score_reference_routes

    summary = score_reference_routes(args)
    print(json.dumps(summary, indent=2), flush=True)
    return 0
