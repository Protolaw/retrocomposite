"""Declarative construction of the top-level command registry."""

from __future__ import annotations

import argparse
from collections.abc import Callable, Iterable
from dataclasses import dataclass

ArgumentBuilder = Callable[[argparse.ArgumentParser], None]
CommandHandler = Callable[[argparse.Namespace], int]


@dataclass(frozen=True, slots=True)
class CommandSpec:
    """One canonical public command."""

    name: str
    help: str
    configure: ArgumentBuilder
    handler: CommandHandler


def build_parser(
    *,
    version: str,
    commands: Iterable[CommandSpec],
) -> argparse.ArgumentParser:
    """Build the public parser from ordered command specifications."""

    parser = argparse.ArgumentParser(prog="route-inspector")
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {version}",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command in commands:
        command_parser = subparsers.add_parser(
            command.name,
            help=command.help,
        )
        command.configure(command_parser)
        command_parser.set_defaults(func=command.handler)
    return parser
