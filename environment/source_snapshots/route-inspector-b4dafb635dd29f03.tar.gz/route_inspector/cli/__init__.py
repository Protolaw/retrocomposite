"""The canonical route-inspector command-line interface."""

from __future__ import annotations

import argparse

from route_inspector import __version__
from route_inspector.cli.commands import _command_specs
from route_inspector.cli.common import workflow_request
from route_inspector.cli.registry import build_parser as registry_parser
from route_inspector.workflows import requests


def build_parser() -> argparse.ArgumentParser:
    return registry_parser(version=__version__, commands=_command_specs())


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    handler = args.func
    if args.command == "gui":
        return handler(args)
    request_name = "".join(word.title() for word in args.command.split("-")) + "Request"
    return handler(workflow_request(getattr(requests, request_name), args))
