"""CLI parsers and lazy runners for evidence and context workflows."""

from __future__ import annotations

import argparse
from pathlib import Path

from route_inspector.cli.common import (
    add_rule_extraction_arguments,
    add_source_id_adapter_argument,
)


def add_context_history_arguments(parser: argparse.ArgumentParser) -> None:
    """Add authoritative route-wide functional-group history options."""

    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--dataset-id", default=None)
    parser.add_argument(
        "--source-identity",
        default=None,
        help="Stable source identity; defaults to the resolved routes path.",
    )
    parser.add_argument(
        "--protection-events",
        type=Path,
        default=None,
        help="Optional mapped protection-event TSV, JSON, or JSONL overlay.",
    )
    parser.add_argument(
        "--protection-overlay-policy",
        choices=("strict", "reject-unlinked"),
        default="strict",
        help=(
            "How mapped protection events that cannot be linked to exactly one "
            "FG lineage are handled. 'strict' fails the stage; "
            "'reject-unlinked' retains them in an explicit rejection sidecar "
            "and excludes them from histories and downstream evidence."
        ),
    )
    parser.add_argument(
        "--write-enriched-routes",
        action="store_true",
        help="Also write a convenience route JSON; the JSONL sidecar remains authoritative.",
    )
    parser.add_argument("--limit", type=int, default=None)


def add_occurrence_context_migration_arguments(
    parser: argparse.ArgumentParser,
) -> None:
    """Add cached legacy occurrence/context migration options."""

    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument(
        "--historical-occurrences",
        type=Path,
        nargs="+",
        required=True,
        help="Historical exact t1, RRSeq-cons, or RRSeq-gap JSON/JSONL sidecars.",
    )
    parser.add_argument(
        "--context-history",
        type=Path,
        required=True,
        help="Authoritative mapping-validated RouteContextHistory JSONL sidecar.",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--dataset-id",
        required=True,
        help="Explicit corpus identity assigned to reconstructed exact t1 records.",
    )
    parser.add_argument(
        "--source-identity",
        default=None,
        help=(
            "Stable identity used by the historical occurrence IDs; defaults to the "
            "resolved --routes-json path."
        ),
    )
    add_source_id_adapter_argument(parser)
    add_rule_extraction_arguments(parser, config_required=True)


def add_reference_index_arguments(parser: argparse.ArgumentParser) -> None:
    """Add all-corpus SQLite evidence-index options."""

    parser.add_argument(
        "--config",
        type=Path,
        required=True,
        help=(
            "Rule-extraction YAML used to create the exact occurrence sidecars; "
            "its canonical hash is recorded in the index metadata."
        ),
    )
    parser.add_argument(
        "--occurrences",
        type=Path,
        nargs="+",
        required=True,
        help="Exact t1, RRSeq-cons, or RRSeq-gap occurrence JSON/JSONL sidecars.",
    )
    parser.add_argument(
        "--context-history",
        type=Path,
        nargs="+",
        required=True,
        help="Authoritative route context-history JSONL sidecars.",
    )
    parser.add_argument(
        "--composite-certificates",
        type=Path,
        nargs="*",
        default=(),
        help="Occurrence-level validated consecutive-composite certificates.",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--dataset-id",
        default=None,
        help=(
            "Fallback corpus identity used only by records that do not already carry "
            "dataset_id; mixed-corpus IDs are preserved."
        ),
    )
    parser.add_argument(
        "--export-dir",
        type=Path,
        default=None,
        help="Optional deterministic TSV/JSONL report directory.",
    )
    parser.add_argument("--batch-size", type=int, default=1000)


def add_generated_route_inspection_arguments(
    parser: argparse.ArgumentParser,
) -> None:
    """Add counts-only generated-route evidence inspection options."""

    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--reference-index", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--dataset-id", default=None)
    parser.add_argument(
        "--source-identity",
        default=None,
        help="Stable generated-input identity; defaults to the resolved routes path.",
    )
    add_source_id_adapter_argument(parser)
    parser.add_argument(
        "--context-history",
        type=Path,
        default=None,
        help="Reuse a persisted history sidecar instead of annotating again.",
    )
    parser.add_argument(
        "--write-enriched-routes",
        action="store_true",
        help="Also write a convenience route JSON; the history JSONL stays authoritative.",
    )
    add_rule_extraction_arguments(parser, config_required=True)
    parser.add_argument("--min-length", type=int, default=2)
    parser.add_argument("--max-length", type=int, default=20)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--progress-interval", type=int, default=250)


def run_context_history_annotation(args: argparse.Namespace) -> int:
    """Annotate one mapping-certified route collection lazily."""

    from route_inspector.workflows import evidence as evidence_workflows

    return evidence_workflows.run_annotate_context_history(args)


def run_occurrence_context_migration(args: argparse.Namespace) -> int:
    """Reconstruct exact t1 evidence and attach authoritative history references."""

    from route_inspector.workflows.context import run_migrate_occurrence_context

    return run_migrate_occurrence_context(args)


def run_reference_index_build(args: argparse.Namespace) -> int:
    """Build the all-corpus SQLite evidence index lazily."""

    from route_inspector.workflows import evidence as evidence_workflows

    return evidence_workflows.run_build_reference_index(args)


def run_generated_route_inspection(args: argparse.Namespace) -> int:
    """Inspect generated routes against exact reference evidence lazily."""

    from route_inspector.workflows import evidence as evidence_workflows

    return evidence_workflows.run_inspect_generated_routes(args)
