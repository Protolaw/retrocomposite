"""Route-level motif extraction and scientific route-inspection tools."""

from __future__ import annotations

import tomllib
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as distribution_version
from pathlib import Path

_DISTRIBUTION_NAME = "route-inspector"


def _source_version() -> str | None:
    """Read the sole version source when running an uninstalled checkout."""

    pyproject = Path(__file__).resolve().parents[1] / "pyproject.toml"
    try:
        project = tomllib.loads(pyproject.read_text(encoding="utf-8"))["project"]
    except (FileNotFoundError, KeyError, OSError, tomllib.TOMLDecodeError):
        return None
    value = project.get("version")
    return str(value) if value else None


def _package_version() -> str:
    source_version = _source_version()
    if source_version is not None:
        return source_version
    try:
        return distribution_version(_DISTRIBUTION_NAME)
    except PackageNotFoundError:
        return "0.0.0+unknown"


__version__ = _package_version()

__all__ = ["__version__"]
