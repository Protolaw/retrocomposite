"""Pure mapped reaction-change extraction used by multiple workflows."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any


def reaction_side_bonds(
    molecules: Iterable[Any],
    center_atoms: frozenset[int],
) -> dict[tuple[int, int], str]:
    bonds: dict[tuple[int, int], str] = {}
    for molecule in molecules:
        for atom_1, atom_2, bond in molecule.bonds():
            atom_1 = int(atom_1)
            atom_2 = int(atom_2)
            if atom_1 not in center_atoms and atom_2 not in center_atoms:
                continue
            key = (min(atom_1, atom_2), max(atom_1, atom_2))
            try:
                value = str(int(bond))
            except Exception:
                value = str(bond)
            bonds[key] = value
    return bonds


def component_forward_change(
    reaction: Any,
    center_atoms: frozenset[int],
) -> dict[str, Any]:
    reactant_bonds = reaction_side_bonds(reaction.reactants, center_atoms)
    product_bonds = reaction_side_bonds(reaction.products, center_atoms)
    reactant_keys = set(reactant_bonds)
    product_keys = set(product_bonds)

    formed = tuple(sorted(product_keys - reactant_keys))
    broken = tuple(sorted(reactant_keys - product_keys))
    changed = tuple(
        sorted(
            key
            for key in reactant_keys & product_keys
            if reactant_bonds[key] != product_bonds[key]
        )
    )

    if formed and not broken:
        kind = "bond_forming"
    elif broken and not formed:
        kind = "bond_breaking"
    elif formed and broken:
        kind = "bond_forming_and_breaking"
    elif changed:
        kind = "bond_order_change"
    else:
        kind = "other"

    return {
        "forward_change_kind": kind,
        "forward_bonds_formed": formed,
        "forward_bonds_broken": broken,
        "forward_bonds_changed": changed,
    }
