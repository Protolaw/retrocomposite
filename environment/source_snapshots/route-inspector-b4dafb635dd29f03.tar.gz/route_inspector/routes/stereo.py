"""Read-only classification of recorded, constitutionally unchanged reactions.

Chython supplies symmetry-aware stereochemical identity while preserving
stored structures and persistent atom-map correspondences.
Generated constitutional templates do not use this opt-in policy.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from functools import lru_cache
from typing import Any

from route_inspector import chemistry
from route_inspector.chemistry.stereo import unmapped_stereo_signature
from route_inspector.routes.molecular_identity import molecule_multisets_equivalent


@dataclass(frozen=True)
class StereoReactionClassification:
    classification: str
    reason: str

    @property
    def accepted(self) -> bool:
        return self.classification == "stereo_only"


@lru_cache(maxsize=16384)
def stereo_component_signature(
    side_smiles: str, *, remove_stereo: bool = False
) -> tuple[str, ...]:
    """Canonical unmapped component multiset, retaining isotope and atom state.

    Sorting retains multiplicity. Clearing maps before serialization prevents
    global renumbering from affecting molecular identity. No stored SMILES or
    cached Chython object is modified, and parse failures are never accepted.
    """
    return tuple(
        sorted(
            unmapped_stereo_signature(text, remove_stereo=remove_stereo)
            for text in side_smiles.split(".")
        )
    )


def _reaction_signatures(
    reaction_smiles: str, *, remove_stereo: bool = False
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    left, _reagents, right = reaction_smiles.split(">")
    return (
        stereo_component_signature(left, remove_stereo=remove_stereo),
        stereo_component_signature(right, remove_stereo=remove_stereo),
    )


def _unchanged_mapped_state(reaction: Any) -> bool:
    products = {frozenset(molecule): molecule for molecule in reaction.products}
    if len(products) != len(reaction.products) or len(products) != len(
        reaction.reactants
    ):
        return False
    seen: set[frozenset[int]] = set()
    for molecule in reaction.reactants:
        ids = frozenset(molecule)
        other = products.get(ids)
        if ids in seen or other is None:
            return False
        seen.add(ids)
        if chemistry.exact_map_identity_mapping(molecule, other) is None:
            return False
    return True


def classify_recorded_noop(
    reaction_smiles: str, metadata: Mapping[str, Any]
) -> StereoReactionClassification | None:
    """Classify constitutional no-ops; return None for constitutional changes.

    Acceptance requires the original record and step-local mapped reaction as
    independent provenance, not a user-supplied ``transformation_kind`` label.
    """
    reaction = chemistry.parse_reaction(reaction_smiles)
    if not molecule_multisets_equivalent(reaction.reactants, reaction.products):
        return None
    try:
        signatures = _reaction_signatures(reaction_smiles)
        if signatures[0] == signatures[1]:
            return StereoReactionClassification(
                "graph_identical_noop_reaction",
                "reactant and product component multisets are identical including stereo",
            )
        stripped = _reaction_signatures(reaction_smiles, remove_stereo=True)
        if stripped[0] != stripped[1] or not _unchanged_mapped_state(reaction):
            return StereoReactionClassification(
                "stereo_only_map_state_mismatch",
                "a stereo-only step must preserve mapped bonds and atom states",
            )
        recorded = metadata.get("original_rxn_smiles") or metadata.get("rsmi")
        local = metadata.get("smiles")
        if not recorded or not local:
            return StereoReactionClassification(
                "stereo_preservation_failure",
                "original and step-local mapped reactions are required to verify stereo",
            )
        for label, text in (
            ("original", recorded),
            ("enriched", metadata.get("enriched_rxn_smiles") or recorded),
            ("step-local mapped", local),
        ):
            if _reaction_signatures(text) != signatures:
                return StereoReactionClassification(
                    "stereo_preservation_failure",
                    f"{label} reaction differs stereochemically from the normalized reaction",
                )
        local_reaction = chemistry.parse_reaction(local)
        if not _unchanged_mapped_state(local_reaction):
            return StereoReactionClassification(
                "stereo_only_map_state_mismatch",
                "step-local maps do not preserve the constitutional graph and atom states",
            )
    except Exception as exc:
        return StereoReactionClassification(
            "stereo_comparison_error", f"{type(exc).__name__}: {exc}"
        )
    return StereoReactionClassification(
        "stereo_only",
        "recorded stereo change or specification survives mapping and normalization; "
        "mapped constitutional graph and atom states are unchanged",
    )
