"""Conservative reconstruction and edit accounting for inferred split steps."""

from typing import Any


def restore_disappearing_group(product: Any, source: Any, rule: Any) -> Any:
    """Restore a complete source fragment, never a truncated centre-only group.

    Traversal stops at product atoms. Every attachment to the retained scaffold
    must belong to this centre, so a fragment spanning independent centres is
    rejected rather than assigned an arbitrary owner.
    """
    retained = set(product)
    missing = set(source) - retained
    selected = set(rule.center_atoms)
    selected.update(n for bond in rule.forward_bonds_broken for n in bond)
    restore = selected & missing
    pending = list(restore)
    adjacency: dict[int, set[int]] = {n: set() for n in source}
    for a, b, _ in source.bonds():
        adjacency[a].add(b)
        adjacency[b].add(a)
    while pending:
        for neighbor in adjacency[pending.pop()] & missing - restore:
            restore.add(neighbor)
            pending.append(neighbor)
    attachments = {n for a in restore for n in adjacency[a] if n in retained}
    if not attachments <= set(rule.center_atoms):
        raise ValueError("restored fragment crosses reaction-center boundaries")
    # Stereo signs depend on neighbor ordering. Until fragment reattachment
    # explicitly transports that ordering, retain such reactions unresolved.
    if any(source.atom(n).stereo is not None for n in restore) or any(
        bond.stereo is not None and (a in restore or b in restore)
        for a, b, bond in source.bonds()
    ):
        raise ValueError("restored fragment requires stereochemical reconstruction")

    result = product.copy()
    for n in sorted(restore | selected):
        atom = source.atom(n)
        if not result.has_atom(n):
            result.add_atom(
                atom.copy(),
                n,
                charge=atom.charge,
                is_radical=atom.is_radical,
                _skip_calculation=True,
            )
        else:
            result.atom(n).charge = atom.charge
            result.atom(n).is_radical = atom.is_radical
    broken = {tuple(sorted(pair)) for pair in rule.forward_bonds_broken}
    for a, b, bond in source.bonds():
        if a in restore or b in restore or tuple(sorted((a, b))) in broken:
            if not result.has_bond(a, b):
                result.add_bond(a, b, int(bond), _skip_calculation=True)
    result.fix_structure()
    # Bulk graph edits and charge setters need not mark retained attachment
    # atoms as changed. Refresh their hydrogens as well (e.g. aromatic N-oxide).
    for n in result:
        result.calc_implicit(n)
    # Recalculate aromatic valences in a Kekule representation. In particular,
    # calc_implicit alone leaves valid aromatic [n+] with an unknown H count.
    result.kekule()
    result.thiele()
    result.fix_stereo()
    if result.check_valence():
        raise ValueError("mapped intermediate has invalid atom valence")
    return result


def side_state(molecules: Any) -> dict[tuple, Any]:
    state: dict[tuple, Any] = {}
    for molecule in molecules:
        for n, atom in molecule.atoms():
            key = ("atom", n)
            if key in state:
                raise ValueError("duplicate atom maps in mapped split side")
            state[key] = (
                atom.atomic_number,
                atom.isotope,
                atom.charge,
                atom.is_radical,
                atom.implicit_hydrogens or 0,
            )
        for a, b, bond in molecule.bonds():
            state[("bond", *sorted((a, b)))] = int(bond)
    return state


def state_changes(before: dict, after: dict) -> dict:
    return {
        key: (before.get(key), after.get(key))
        for key in before.keys() | after.keys()
        if before.get(key) != after.get(key)
    }


def validate_edit_partition(original: Any, steps: list[Any]) -> None:
    """Require disjoint edits whose union is exactly the recorded reaction."""
    expected = state_changes(
        side_state(original.reactants), side_state(original.products)
    )
    observed: dict = {}
    for step in steps:
        edits = state_changes(side_state(step.reactants), side_state(step.products))
        if observed.keys() & edits.keys():
            raise ValueError("mapped split has overlapping atom or bond edits")
        observed.update(edits)
    if observed != expected:
        raise ValueError("mapped split does not exactly partition the original edits")
