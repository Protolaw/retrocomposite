"""Stable output paths, columns, and serialization for atom-provenance audits."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from route_inspector.infrastructure.artifacts import write_json
from route_inspector.infrastructure.text import write_tsv
from route_inspector.routes.diagnostics import AtomProvenanceAuditResult

ATOM_PROVENANCE_FIELDS = [
    "dataset",
    "route_id",
    "reaction_step",
    "category",
    "single_precursor_no_reagent",
    "reaction_record_id",
    "reactant_count",
    "product_count",
    "product_only_atom_count",
    "product_only_map_ids",
    "product_only_formula",
    "product_only_map_signature_mismatch_ids",
    "provenance_certainty",
    "raw_product_unmapped_formula",
    "element_balance_surplus_atom_count",
    "element_balance_surplus_formula",
    "raw_reactant_unmapped_atom_count",
    "raw_reagent_unmapped_atom_count",
    "raw_product_unmapped_atom_count",
    "raw_reaction_has_unmapped_atoms",
    "target_molecule",
    "normalized_reaction_smiles",
    "raw_reaction_smiles",
]


ATOM_PROVENANCE_ERROR_FIELDS = [
    "dataset",
    "route_id",
    "reaction_step",
    "stage",
    "error_type",
    "message",
    "reaction_smiles",
]


def atom_provenance_output_paths(
    output_dir: Path,
    dataset: str,
) -> dict[str, Path]:
    """Return standard output paths for a provenance audit."""

    output_dir = Path(output_dir)
    return {
        "atoms_from_nowhere": output_dir / f"{dataset}_atoms_from_nowhere.tsv",
        "single_precursor_atoms_from_nowhere": (
            output_dir / f"{dataset}_single_precursor_atoms_from_nowhere.tsv"
        ),
        "summary": output_dir / "summary.json",
        "atom_provenance_errors": (
            output_dir / f"{dataset}_atoms_from_nowhere_errors.tsv"
        ),
    }


def _compact_row(record: dict[str, Any]) -> dict[str, Any]:
    row = {}
    for field in ATOM_PROVENANCE_FIELDS:
        value = record.get(field, "")
        if isinstance(value, (list, tuple, dict)):
            value = json.dumps(value, sort_keys=True, separators=(",", ":"))
        row[field] = value
    return row


def write_atom_provenance_outputs(
    result: AtomProvenanceAuditResult,
    paths: dict[str, Path],
    *,
    input_file: Path | None = None,
) -> dict[str, Any]:
    """Write event, error, and summary artifacts for an audit result."""

    write_tsv(
        paths["atoms_from_nowhere"],
        ATOM_PROVENANCE_FIELDS,
        (_compact_row(record) for record in result.records),
    )
    write_tsv(
        paths["single_precursor_atoms_from_nowhere"],
        ATOM_PROVENANCE_FIELDS,
        (
            _compact_row(record)
            for record in result.records
            if (
                record["single_precursor_no_reagent"]
                and int(record["product_only_atom_count"]) > 0
            )
        ),
    )
    write_tsv(
        paths["atom_provenance_errors"],
        ATOM_PROVENANCE_ERROR_FIELDS,
        result.parse_errors,
    )
    summary = result.summary()
    if input_file is not None:
        summary["input_file"] = str(input_file)
    summary["output_files"] = {key: str(path) for key, path in paths.items()}
    write_json(paths["summary"], summary)
    return summary
