"""Audited removal of whole inputs with no mapped atoms in a local target.

Non-contributing is a representation-level statement, not a claim that a
reagent was chemically unnecessary. No bonded fragments are stripped.
"""

from __future__ import annotations

import copy
import hashlib
import json
from collections import Counter

from chython.containers import ReactionContainer

from route_inspector import chemistry
from route_inspector.routes.access import walk_route_nodes as walk
from route_inspector.routes.alignment import mapped_molecules_stereo_equal

POLICY = "zero_local_target_atom_overlap_v1"


class ReactantCleanupError(ValueError):
    """Cleanup cannot establish an exact, source-complete mapped match."""


def verify_explicit_maps(route):
    """Run before normalization can fill any missing source atom maps."""
    from route_inspector.routes.access import reaction_smiles_from_node
    from route_inspector.routes.validation import validate_raw_reaction_atom_mapping

    for path, node in walk(route):
        if node.get("type") == "reaction":
            issues = validate_raw_reaction_atom_mapping(reaction_smiles_from_node(node))
            if issues:
                raise ReactantCleanupError(
                    f"unsafe input atom maps at {path}: {issues[0]['stage']}"
                )


def cleanup_route_reactants(route, *, audit=None, allow_stereo_only_reactions=False):
    """Return a cleaned copy, or the identical original object on any failure.

    The input must already be route-normalized. The optional audit receives
    occurrence-level decisions, including full archived removed subtrees.
    Successful modifications are committed only after strict route validation.
    """
    from route_inspector.routes.access import (
        molecule_node_smiles,
        reaction_smiles_from_node,
    )
    from route_inspector.routes.validation import validate_routes_mapping

    candidate = copy.deepcopy(route)
    entries = []
    pid = str(route.get("metadata", {}).get("path_id", ""))
    context = {
        "path_id": pid,
        "step_id": "",
        "source_row": "",
        "original_node_path": [],
        "node_path": [],
    }

    def visit(node, parent=None, original_path=(), path=()):
        nonlocal context
        removed_indexes = set()
        if node.get("type") == "reaction":
            meta = node.get("metadata", {})
            context = {
                "path_id": pid,
                "step_id": meta.get("step_id", ""),
                "source_row": meta.get("source_row", ""),
                "original_node_path": list(original_path),
                "node_path": list(path),
            }
            text = reaction_smiles_from_node(node)
            reaction = chemistry.parse_reaction(text)
            if len(reaction.products) != 1:
                raise ReactantCleanupError("unsupported multi-product reaction")
            target = reaction.products[0]
            if parent is None or not mapped_molecules_stereo_equal(
                target, chemistry.parse_molecule(molecule_node_smiles(parent))
            ):
                raise ReactantCleanupError(
                    "local target differs from the mapped parent molecule"
                )
            target_ids = set(target)
            sources = {i: a for m in reaction.reactants for i, a in m.atoms()}
            for i, atom in target.atoms():
                if i not in sources or (atom.atomic_number, atom.isotope) != (
                    sources[i].atomic_number,
                    sources[i].isotope,
                ):
                    raise ReactantCleanupError(
                        "product atom lacks a same-element/isotope reactant source"
                    )
            children = node.get("children") or []
            if len(children) != len(reaction.reactants) or any(
                c.get("type") != "mol" for c in children
            ):
                raise ReactantCleanupError(
                    "reaction/child component multiplicity mismatch"
                )
            molecules = [
                chemistry.parse_molecule(molecule_node_smiles(c)) for c in children
            ]
            matched, removed = set(), []
            for component_index, molecule in enumerate(reaction.reactants):
                matches = [
                    i
                    for i, child in enumerate(molecules)
                    if i not in matched
                    and set(child) == set(molecule)
                    and mapped_molecules_stereo_equal(molecule, child)
                ]
                if len(matches) != 1:
                    raise ReactantCleanupError(
                        "ambiguous or missing exact mapped reactant-child match"
                    )
                child_index = matches[0]
                matched.add(child_index)
                if set(molecule) & target_ids:
                    continue
                child = children[child_index]
                removed_indexes.add(child_index)
                identity = json.dumps(
                    [
                        POLICY,
                        pid,
                        meta.get("source_row"),
                        original_path,
                        component_index,
                        text,
                    ],
                    separators=(",", ":"),
                )
                record = {
                    **context,
                    "cleanup_id": "cleanup_"
                    + hashlib.sha256(identity.encode()).hexdigest()[:24],
                    "policy": POLICY,
                    "status": "proposed",
                    "reason": "zero mapped atom overlap with the local target",
                    "component_index": component_index,
                    "original_child_path": list((*original_path, child_index)),
                    "component_smiles": format(molecule, "m"),
                    "removed_atom_maps": sorted(molecule),
                    "map_namespace": "pre_cleanup_route_global",
                    "donor_role": child.get("metadata", {}).get("role", ""),
                    "pruned_reaction_nodes": sum(
                        n.get("type") == "reaction" for _, n in walk(child)
                    ),
                    "pre_cleanup_reaction_smiles": text,
                    "removed_subtree": copy.deepcopy(child),
                }
                entries.append(record)
                removed.append(record)
            if removed:
                retained = tuple(
                    m.copy() for m in reaction.reactants if set(m) & target_ids
                )
                if not retained:
                    raise ReactantCleanupError("cleanup would remove every reactant")
                cleaned = ReactionContainer(
                    retained,
                    tuple(m.copy() for m in reaction.products),
                    tuple(m.copy() for m in reaction.reagents),
                    meta=dict(reaction.meta),
                    name=reaction.name,
                )
                node["smiles"] = format(cleaned, "m")
                node.setdefault("metadata", {}).setdefault(
                    "reactant_cleanup", []
                ).append(
                    {
                        "policy": POLICY,
                        "pre_cleanup_reaction_smiles": text,
                        "original_node_path": list(original_path),
                        "removed_components": copy.deepcopy(removed),
                    }
                )
        # Top-down: never visit or separately count the removed branch's inputs.
        retained_children = []
        for old_index, child in enumerate(node.get("children") or []):
            if old_index in removed_indexes:
                continue
            new_index = len(retained_children)
            visit(child, node, (*original_path, old_index), (*path, new_index))
            retained_children.append(child)
        if "children" in node:
            node["children"] = retained_children

    try:
        verify_explicit_maps(route)
        visit(candidate)
        if not entries:
            return route
        records = validate_routes_mapping(
            {pid or "route": candidate},
            dataset="ABSynth",
            allow_stereo_only_reactions=allow_stereo_only_reactions,
        ).records
        if records:
            raise ReactantCleanupError(
                "final route validation: " + json.dumps(records, sort_keys=True)
            )
    except Exception as exc:
        for entry in entries:
            entry.update(status="rolled_back", reason=f"{type(exc).__name__}: {exc}")
        entries.append(
            {
                **context,
                "policy": POLICY,
                "status": "unresolved",
                "reason": f"{type(exc).__name__}: {exc}",
            }
        )
        if audit is not None:
            audit.extend(entries)
        return route
    for entry in entries:
        entry["status"] = "removed"
    for _, node in walk(candidate):
        for event in node.get("metadata", {}).get("reactant_cleanup", []):
            for entry in event["removed_components"]:
                entry["status"] = "removed"
    candidate.setdefault("metadata", {})["reactant_cleanup_policy"] = POLICY
    if audit is not None:
        audit.extend(entries)
    return candidate


def cleanup_summary(entries):
    removed = [e for e in entries if e["status"] == "removed"]
    return {
        "policy": POLICY,
        "components_removed": len(removed),
        "routes_modified": len({e["path_id"] for e in removed}),
        "pruned_reaction_nodes": sum(e["pruned_reaction_nodes"] for e in removed),
        "unresolved_routes": len(
            {e["path_id"] for e in entries if e["status"] != "removed"}
        ),
        "decision_counts": dict(Counter(e["status"] for e in entries)),
    }


def archived_nodes(route):
    """Visit archived source nodes, including archives inherited by a branch."""
    for _, node in walk(route):
        for event in node.get("metadata", {}).get("reactant_cleanup", []):
            for entry in event["removed_components"]:
                subtree = entry["removed_subtree"]
                yield from (n for _, n in walk(subtree))
                yield from archived_nodes(subtree)


def write_cleanup_audit(directory, entries):
    """Write compact decisions plus lossless, occurrence-addressed archives."""
    from route_inspector.infrastructure.hashing import file_record
    from route_inspector.infrastructure.text import write_tsv

    fields = [
        "path_id",
        "step_id",
        "source_row",
        "original_node_path",
        "node_path",
        "cleanup_id",
        "policy",
        "status",
        "reason",
        "component_index",
        "original_child_path",
        "component_smiles",
        "removed_atom_maps",
        "map_namespace",
        "donor_role",
        "pruned_reaction_nodes",
        "pre_cleanup_reaction_smiles",
    ]
    ordered = sorted(
        entries,
        key=lambda e: (
            str(e["path_id"]),
            e["original_node_path"],
            e.get("component_index", -1),
        ),
    )
    serial = [
        {
            k: json.dumps(e[k], sort_keys=True)
            if isinstance(e[k], (list, dict))
            else e[k]
            for k in fields
            if k in e
        }
        for e in ordered
    ]
    write_tsv(directory / "reactant_cleanup.tsv", fields, serial)
    write_tsv(
        directory / "reactant_cleanup_errors.tsv",
        fields,
        [r for r in serial if r["status"] != "removed"],
    )
    with (directory / "removed_reactant_subtrees.jsonl").open("w") as stream:
        for e in ordered:
            if "removed_subtree" in e:
                stream.write(json.dumps(e, sort_keys=True) + "\n")
    return {
        "summary": cleanup_summary(entries),
        "artifacts": [
            file_record(directory / n)
            for n in (
                "reactant_cleanup.tsv",
                "reactant_cleanup_errors.tsv",
                "removed_reactant_subtrees.jsonl",
            )
        ],
    }
