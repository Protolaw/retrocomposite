"""Read-only component comparison shared by route validation policies."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from route_inspector import chemistry


def molecule_multisets_equivalent(
    left: Iterable[Any],
    right: Iterable[Any],
) -> bool:
    """Compare component multisets by constitutional graph identity."""

    left = tuple(left)
    right = tuple(right)
    if len(left) != len(right):
        return False
    used: set[int] = set()
    for left_molecule in left:
        for index, right_molecule in enumerate(right):
            if index in used:
                continue
            if chemistry.molecules_equivalent(left_molecule, right_molecule):
                used.add(index)
                break
        else:
            return False
    return True
