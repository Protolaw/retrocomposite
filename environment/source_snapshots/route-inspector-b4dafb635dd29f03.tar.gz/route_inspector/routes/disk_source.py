"""Read-only route mapping backed by a reusable, fingerprinted SQLite spool."""

import json
import sqlite3
from collections.abc import Mapping
from decimal import Decimal
from pathlib import Path

from route_inspector.routes.io import iter_route_json_file


def _route_json(route):
    # ijson uses Decimal for non-integral numbers. Match the existing source
    # reader's JSON-number semantics while keeping strings and atom maps intact.
    def encode(value):
        if isinstance(value, Decimal):
            return float(value)
        raise TypeError(f"unsupported route metadata: {type(value).__name__}")

    return json.dumps(
        route, default=encode, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    )


class DiskRouteSource(Mapping):
    def __init__(self, source, path, digest):
        self.db = sqlite3.connect(Path(path))
        self.db.execute("PRAGMA journal_mode=TRUNCATE")
        self.db.execute("PRAGMA cache_size=-8192")
        self.db.executescript(
            "CREATE TABLE IF NOT EXISTS source_metadata(digest TEXT); CREATE TABLE IF NOT EXISTS routes(id TEXT PRIMARY KEY,payload TEXT);"
        )
        row = self.db.execute("SELECT digest FROM source_metadata").fetchone()
        if row is not None:
            if row[0] != digest:
                self.db.close()
                raise ValueError("source route spool fingerprint mismatch")
            return
        with self.db:
            self.db.execute("DELETE FROM routes")
            for key, route in iter_route_json_file(source):
                self.db.execute(
                    "INSERT INTO routes VALUES(?,?)", (str(key), _route_json(route))
                )
            self.db.execute("INSERT INTO source_metadata VALUES(?)", (digest,))

    def __getitem__(self, key):
        row = self.db.execute(
            "SELECT payload FROM routes WHERE id=?", (str(key),)
        ).fetchone()
        if row is None:
            raise KeyError(key)
        return json.loads(row[0])

    def __contains__(self, key):
        return (
            self.db.execute("SELECT 1 FROM routes WHERE id=?", (str(key),)).fetchone()
            is not None
        )

    def __iter__(self):
        return (row[0] for row in self.db.execute("SELECT id FROM routes ORDER BY id"))

    def __len__(self):
        return self.db.execute("SELECT COUNT(*) FROM routes").fetchone()[0]

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.db.close()
