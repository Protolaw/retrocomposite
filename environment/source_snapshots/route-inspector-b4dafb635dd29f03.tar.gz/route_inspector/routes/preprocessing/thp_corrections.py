"""Conservative DHP-to-THP correspondence repair before route normalization."""

import re
from copy import deepcopy

from route_inspector import chemistry
from route_inspector.routes.access import reaction_nodes, reaction_smiles_from_node

THP_CORRECTION_ID = "thp-enol-ether-correspondence-v1"


def _ring_bonds(molecule, ring):
    return {
        tuple(sorted((a, b))): bond.order
        for a, b, bond in molecule.bonds()
        if a in ring and b in ring
    }


def repair_thp_reaction(text):
    """Return a working reaction and witnesses, or the unchanged input.

    Only isolated, neutral, unsubstituted DHP donors and a single N/O/S-H
    addition qualify. A ring reflection changes maps only, never a structure.
    Source IDs, route IDs, atom numbers and SMILES traversal order are irrelevant.
    """
    sides = text.split(">")
    if len(sides) != 3 or "=" not in sides[0] or "O" not in sides[0]:
        return text, []
    explicit = []
    for side in (sides[0], sides[2]):
        maps = list(map(int, re.findall(r":(\d+)\]", side)))
        if not maps or len(maps) != len(set(maps)) or min(maps) < 1:
            return text, []
        explicit.append(set(maps))
    reaction = chemistry.parse_reaction(text)
    replacements, edits = {}, []
    for index, donor in enumerate(reaction.reactants):
        ring = set(donor)
        if (
            len(ring) != 6
            or sorted(donor.atom(n).atomic_number for n in ring) != [6] * 5 + [8]
            or not ring <= explicit[0] & explicit[1]
            or any(
                donor.atom(n).charge
                or donor.atom(n).is_radical
                or donor.atom(n).isotope is not None
                or donor.atom(n).stereo is not None
                or len(donor.environment(n)) != 2
                for n in ring
            )
        ):
            continue
        bonds = _ring_bonds(donor, ring)
        if (
            len(donor.sssr) != 1
            or len(bonds) != 6
            or sorted(bonds.values()) != [1] * 5 + [2]
        ):
            continue
        oxygen = next(n for n in ring if donor.atom(n).atomic_number == 8)
        alpha = {n for n, _, _ in donor.environment(oxygen)}
        double = next(pair for pair, order in bonds.items() if order == 2)
        if oxygen in double or len(alpha & set(double)) != 1:
            continue
        alkene_alpha = next(iter(alpha & set(double)))
        products = [m for m in reaction.products if ring <= set(m)]
        if len(products) != 1:
            continue
        product = products[0]
        after = _ring_bonds(product, ring)
        attachments = [
            (n, a) for n in ring for a, _, _ in product.environment(n) if a not in ring
        ]
        if (
            set(after) != set(bonds)
            or set(after.values()) != {1}
            or len(attachments) != 1
        ):
            continue
        attached, external = attachments[0]
        if (
            attached not in alpha
            or attached == alkene_alpha
            or external not in explicit[0]
        ):
            continue
        sources = [m for m in reaction.reactants if external in set(m)]
        if len(sources) != 1:
            continue
        source = sources[0]
        before_atom, after_atom = source.atom(external), product.atom(external)
        if (
            before_atom.atomic_number not in (7, 8, 16)
            or before_atom.atomic_number != after_atom.atomic_number
            or before_atom.charge != after_atom.charge
            or before_atom.is_radical
            or after_atom.is_radical
            or before_atom.isotope != after_atom.isotope
            or before_atom.implicit_hydrogens is None
            or after_atom.implicit_hydrogens != before_atom.implicit_hydrogens - 1
            or {(n, b.order) for n, b, _ in source.environment(external)}
            != {
                (n, b.order)
                for n, b, _ in product.environment(external)
                if n != attached
            }
            or any(
                product.atom(n).atomic_number != donor.atom(n).atomic_number
                or product.atom(n).isotope is not None
                or product.atom(n).charge
                or product.atom(n).is_radical
                or product.atom(n).implicit_hydrogens
                != (0 if n == oxygen else 1 if n == attached else 2)
                for n in ring
            )
        ):
            continue
        chain = [attached]
        while len(chain) < 5:
            remaining = [
                n
                for n, _, _ in donor.environment(chain[-1])
                if n != oxygen and n not in chain
            ]
            if len(remaining) != 1:
                break
            chain.append(remaining[0])
        if len(chain) != 5:
            continue
        permutation = dict(zip(chain, reversed(chain)))
        permutation[oxygen] = oxygen
        fixed = donor.copy()
        fixed.remap(permutation)
        if not chemistry.molecules_equivalent(donor, fixed):
            continue
        replacements[index] = fixed
        edits.append(
            {
                "reactant_index": index,
                "ring_atom_maps": sorted(ring),
                "oxygen_map": oxygen,
                "attachment_atom_map": external,
                "attachment_element": after_atom.atomic_symbol,
                "product_attachment_carbon_map": attached,
                "original_alkene_carbon_map": alkene_alpha,
                "reactant_atom_map_permutation": {
                    str(k): v for k, v in permutation.items()
                },
            }
        )
    if not edits:
        return text, []
    # Preserve product and reagent strings exactly, including stereochemistry.
    return (
        ".".join(
            format(replacements.get(i, m), "m")
            for i, m in enumerate(reaction.reactants)
        )
        + ">"
        + sides[1]
        + ">"
        + sides[2],
        edits,
    )


def correct_thp_correspondence(route):
    """Repair working source reactions and retain original source evidence.

    Only uniquely matched terminal stock DHP donors qualify. Reactions already
    split by preprocessing are excluded: repair the original raw source instead.
    """
    corrected = route
    for path, node in reaction_nodes(route):
        metadata = node.get("metadata") or {}
        if metadata.get("route_preprocessing_split"):
            continue
        text = reaction_smiles_from_node(node)
        fixed, edits = repair_thp_reaction(text)
        if not edits:
            continue
        reaction = chemistry.parse_reaction(text)
        children = node.get("children") or []
        parent = route
        for i in path[:-1]:
            parent = parent["children"][i]
        if len(reaction.products) != 1 or not chemistry.molecules_equivalent(
            chemistry.parse_molecule(parent["smiles"]), reaction.products[0]
        ):
            continue
        donors_valid = True
        for edit in edits:
            donor = reaction.reactants[edit["reactant_index"]]
            matches = [
                c
                for c in children
                if c.get("type") == "mol"
                and chemistry.molecules_equivalent(
                    chemistry.parse_molecule(c["smiles"]), donor
                )
            ]
            if (
                len(matches) != 1
                or matches[0].get("children")
                or matches[0].get("in_stock") is not True
            ):
                donors_valid = False
                break
        if not donors_valid:
            continue
        if corrected is route:
            corrected = deepcopy(route)
        repaired = corrected
        for i in path:
            repaired = repaired["children"][i]
        repaired["smiles"] = fixed
        repaired.setdefault("metadata", {}).setdefault("smiles", text)
        repaired["metadata"]["mapping_correction_id"] = THP_CORRECTION_ID
        repaired["metadata"].pop("reaction_hash", None)
        corrected.setdefault("metadata", {}).setdefault(
            "source_corrections", []
        ).append(
            {
                "correction_id": THP_CORRECTION_ID,
                "source_record_id": metadata.get("ID", ""),
                "reaction_node_path": list(path),
                "original_reaction_smiles": text,
                "original_reaction_metadata": deepcopy(metadata),
                "corrected_reaction_smiles": fixed,
                "removed_reaction_count": 0,
                "reactant_structures_unchanged": True,
                "product_structures_and_maps_unchanged": True,
                "atom_id_scope": "source_reaction_before_route_normalization",
                "edits": edits,
            }
        )
    return corrected
