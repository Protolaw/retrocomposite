"""Auditable structural repairs applied before mapping and centre detection."""

from copy import deepcopy
from functools import lru_cache

from route_inspector import chemistry
from route_inspector.routes.access import (
    molecule_node_smiles,
    reaction_smiles_from_node,
)

TBS_CORRECTION_ID = "tbs-misplaced-methyls-v1"


@lru_cache(maxsize=1)
def _corrupted_tbs_pattern():
    from chython import smarts

    # The complete defect, not a generic SiH2 or silyl-ether match:
    # tBu-SiH2-O-C(Me)2-aryl -> tBu-Si(Me)2-O-CH2-aryl.
    return smarts(
        "[Si;D2;H2;+0:1](-[C;D4;H0;+0:2]"
        "(-[C;D1;H3;+0:3])(-[C;D1;H3;+0:4])-[C;D1;H3;+0:5])"
        "-[O;D2;H0;+0:6]-[C;D4;H0;+0:7]"
        "(-[C;D1;H3;+0:8])(-[C;D1;H3;+0:9])-[c:10]"
    )


def _repair_molecule(molecule):
    matches = list(_corrupted_tbs_pattern().get_mapping(molecule))
    if not matches:
        return molecule, []
    repaired = molecule.copy()
    edits = []
    seen = set()
    for match in matches:
        silicon, carbon = match[1], match[7]
        if silicon in seen:
            continue
        if any(molecule.atom(n).is_radical for n in match.values()):
            continue
        seen.add(silicon)
        methyls = sorted((match[8], match[9]))
        for methyl in methyls:
            repaired.delete_bond(carbon, methyl, _skip_calculation=True)
            repaired.add_bond(silicon, methyl, 1, _skip_calculation=True)
        edits.append(
            {
                "silicon_atom_id": silicon,
                "alcohol_carbon_atom_id": carbon,
                "methyl_atom_ids": methyls,
            }
        )
    if edits:
        repaired.fix_structure()
        repaired.fix_stereo()
    return repaired, edits


def correct_corrupted_tbs_route(route):
    """Move misplaced methyls onto Si without adding atoms or changing input.

    This curated structural policy is independent of dataset/route/source IDs.
    It operates on working molecules and both reaction sides before normalization;
    recorded metadata and original molecules remain available as source evidence.
    Other SiH2 environments are deliberately outside this correction's scope.
    """
    from chython.containers import ReactionContainer

    def has_candidate(node):
        text = (
            node.get("smiles")
            or (node.get("metadata") or {}).get("smiles")
            or (node.get("metadata") or {}).get("mapped_reaction_smiles")
            or (node.get("metadata") or {}).get("rsmi")
            or ""
        )
        return "SiH2" in text or any(
            has_candidate(child) for child in node.get("children", []) or []
        )

    if not has_candidate(route):
        return route
    changes = []

    def visit(node, path):
        kind = node.get("type")
        text = (
            (
                reaction_smiles_from_node(node)
                if kind == "reaction"
                else molecule_node_smiles(node)
            )
            if kind in {"mol", "reaction"}
            else ""
        )
        # Avoid parsing unrelated records, including existing malformed inputs
        # which must retain the workflow's normal error handling.
        if "SiH2" in text:
            edits = []
            if kind == "mol":
                molecule, edits = _repair_molecule(chemistry.parse_molecule(text))
                repaired_text = format(molecule, "m")
            else:
                reaction = chemistry.parse_reaction(text)
                components = {}
                for side in ("reactants", "products", "reagents"):
                    components[side] = []
                    for i, molecule in enumerate(getattr(reaction, side)):
                        repaired, molecule_edits = _repair_molecule(molecule)
                        components[side].append(repaired)
                        edits.extend(
                            {"side": side, "component_index": i, **e}
                            for e in molecule_edits
                        )
                repaired_text = format(
                    ReactionContainer(
                        tuple(components["reactants"]),
                        tuple(components["products"]),
                        tuple(components["reagents"]),
                        meta=dict(reaction.meta),
                        name=reaction.name,
                    ),
                    "m",
                )
            if edits:
                metadata = node.setdefault("metadata", {})
                changes.append(
                    {
                        "node_path": list(path),
                        "node_type": kind,
                        "source_record_id": metadata.get(
                            "ID", metadata.get("source_record_id", "")
                        ),
                        "original_smiles": text,
                        "corrected_smiles": repaired_text,
                        "original_metadata": deepcopy(metadata),
                        "edits": edits,
                        "atom_id_scope": "parsed_source_node_before_route_normalization",
                    }
                )
                metadata.setdefault(
                    "smiles" if kind == "reaction" else "original_smiles", text
                )
                metadata.pop("reaction_hash", None)
                metadata["structural_correction_id"] = TBS_CORRECTION_ID
                node["smiles"] = repaired_text
                if kind == "mol":
                    metadata["mapped_smiles"] = repaired_text
                    if "mapped_smiles" in node:
                        node["mapped_smiles"] = repaired_text
        for i, child in enumerate(node.get("children", []) or []):
            visit(child, (*path, i))

    corrected = deepcopy(route)
    visit(corrected, ())
    if not changes:
        return route
    corrected.setdefault("metadata", {}).setdefault("source_corrections", []).append(
        {
            "correction_id": TBS_CORRECTION_ID,
            "source_record_id": "",
            "removed_reaction_count": 0,
            "policy": "structural_methyl_transfer",
            "atom_inventory_preserved": True,
            "occurrences": changes,
        }
    )
    return corrected
