"""Canonical clean-route chemistry with recorded inputs kept as provenance."""

from __future__ import annotations

import copy
from typing import Any

from route_inspector import chemistry
from route_inspector.routes.access import (
    RouteNormalizationError,
    molecule_node_smiles,
    reaction_smiles_from_node,
)
from route_inspector.routes.normalization import normalize_route_tree


def canonicalize_route_tree(route: dict[str, Any]) -> dict[str, Any]:
    """Align source maps, canonicalize copies, then verify tree-edge alignment.

    Use the same strict product preparation as SynPlanner's rule application.
    Original reaction fields and molecule strings remain available in metadata.
    A failed preparation or changed atom inventory rejects the route rather than
    publishing a mixture of canonical and unprepared chemistry.
    """
    from chython.containers import ReactionContainer
    from synplan.chem.utils import validate_and_canonicalize

    source = copy.deepcopy(route)

    def retain_source(node: dict[str, Any]) -> None:
        if node.get("type") == "reaction":
            metadata = node.setdefault("metadata", {})
            metadata.setdefault("smiles", reaction_smiles_from_node(node))
        for child in node.get("children", []) or []:
            retain_source(child)

    retain_source(source)
    prepared = normalize_route_tree(source)

    def canonical(molecule: Any, path: tuple[int, ...]) -> Any:
        result = validate_and_canonicalize(molecule.copy())
        if result is None:
            raise RouteNormalizationError(
                f"SynPlanner canonicalization failed at node path {list(path)}"
            )
        before = {n: (a.atomic_number, a.isotope) for n, a in molecule.atoms()}
        after = {n: (a.atomic_number, a.isotope) for n, a in result.atoms()}
        if before != after:
            raise RouteNormalizationError(
                "Canonicalization changed mapped atom inventory at node path "
                f"{list(path)}"
            )
        return result

    def visit(node: dict[str, Any], path: tuple[int, ...]) -> None:
        metadata = node.setdefault("metadata", {})
        if node.get("type") == "mol":
            text = molecule_node_smiles(node)
            metadata.setdefault("original_smiles", text)
            molecule = canonical(chemistry.parse_molecule(text), path)
            node["smiles"] = metadata["mapped_smiles"] = format(molecule, "m")
            if "mapped_smiles" in node:
                node["mapped_smiles"] = node["smiles"]
        elif node.get("type") == "reaction":
            text = reaction_smiles_from_node(node)
            metadata.setdefault("precanonical_mapped_reaction_smiles", text)
            reaction = chemistry.parse_reaction(text)
            result = ReactionContainer(
                tuple(canonical(m, path) for m in reaction.reactants),
                tuple(canonical(m, path) for m in reaction.products),
                tuple(canonical(m, path) for m in reaction.reagents),
                meta=dict(reaction.meta),
                name=reaction.name,
            )
            node["smiles"] = format(result, "m")
        for i, child in enumerate(node.get("children", []) or []):
            visit(child, (*path, i))

    visit(prepared, ())
    prepared = normalize_route_tree(prepared)
    prepared.setdefault("metadata", {})["route_canonicalization"] = {
        "method": "synplanner_validate_and_canonicalize",
        "policy_version": 1,
        "atom_inventory_preserved": True,
    }
    return prepared
