"""Mapped, inferred decomposition of PG removal followed by functionalization."""

from copy import deepcopy

from chython.containers import ReactionContainer

from route_inspector import chemistry
from route_inspector.protection.analysis import (
    matching_site_mappings,
    phthalimide_nitrogen_donor,
)
from route_inspector.protection.endpoints import removal_endpoint_valid
from route_inspector.routes.mapped_intermediates import side_state
from route_inspector.routes.provenance import raw_source_record_id
from route_inspector.routes.split_validation import (
    validate_generated_reaction_has_structural_change,
)

FUSED_PG_POLICY = {"version": 1, "order": "deprotection-first", "inferred": True}


def prepared(molecule):
    """Repair implicit H/aromaticity after graph edits without dropping stereo."""
    molecule.fix_structure()
    molecule.kekule()
    for n in molecule:
        molecule.calc_implicit(n)
    molecule.thiele()
    molecule.fix_stereo()
    if molecule.check_valence():
        raise ValueError("invalid valence in inferred PG intermediate")
    return molecule


def remove_atoms(molecule, atoms):
    # Work in Kekule form so removing a mask on aromatic N restores [nH].
    m = molecule.copy()
    m.kekule()
    return prepared(m.substructure(set(m) - set(atoms)))


def bonds(m):
    return {tuple(sorted((a, b))): int(o) for a, b, o in m.bonds()}


def validate_sequence(original, steps):
    """Compose steps exactly, permitting the temporary H of free NH/OH.

    Each input component must be available, each heavy bond edit occurs once,
    and the final mapped state must equal the original recorded products.
    """
    pool = [m for m in original.reactants]
    edited = set()
    original_bonds = {k: v for m in original.reactants for k, v in bonds(m).items()}
    final_bonds = {k: v for m in original.products for k, v in bonds(m).items()}
    for step in steps:
        validate_generated_reaction_has_structural_change(step)
        for source in step.reactants:
            state = side_state([source])
            found = next(
                (i for i, m in enumerate(pool) if side_state([m]) == state), None
            )
            if found is None:
                raise ValueError(
                    "inferred step consumes an unavailable mapped molecule"
                )
            pool.pop(found)
        before = {k: v for m in step.reactants for k, v in bonds(m).items()}
        after = {k: v for m in step.products for k, v in bonds(m).items()}
        changes = {
            k for k in before.keys() | after.keys() if before.get(k) != after.get(k)
        }
        if edited & changes:
            raise ValueError("inferred steps repeat a heavy bond edit")
        edited |= changes
        pool.extend(step.products)
    if side_state(pool) != side_state(original.products):
        raise ValueError("inferred steps do not reproduce the recorded final state")
    expected = {
        k
        for k in original_bonds.keys() | final_bonds.keys()
        if original_bonds.get(k) != final_bonds.get(k)
    }
    if edited != expected:
        raise ValueError("inferred steps do not account for all original bond edits")


def candidates(index, record, rules):
    reaction = chemistry.parse_reaction(record.reaction_smiles)
    if len(reaction.products) != 1:
        return reaction, []
    product = reaction.products[0]
    found = {}
    for ri, source in enumerate(reaction.reactants):
        for rule in rules.values():
            if rule.atoms_to_add or rule.name == "hydroxyl_tosyl":
                continue  # Oxygen-mapping-suspicious substitutions require separate review.
            for anchors, mapping in matching_site_mappings(source, rule):
                if not removal_endpoint_valid(rule, source, product, mapping):
                    continue
                mask = set(mapping.values()) - set(anchors)
                active = [
                    a
                    for a in anchors
                    if source.atom(a).atomic_number in {7, 8, 16}
                    and set(source._bonds[a]) & mask
                ]
                if not active:
                    continue
                # Acetic anhydride is an acyl donor, not a protected alcohol.
                if rule.name == "hydroxyl_acyl" and any(
                    source.atom(b).atomic_number == 6
                    and any(
                        source.atom(c).atomic_number == 8 and int(o) == 2
                        for c, o in source._bonds[b].items()
                    )
                    for a in active
                    for b in source._bonds[a]
                    if b not in mask
                ):
                    continue
                # N-acetylhydroxylamine is a nitrogen reagent, not a scaffold amine.
                if rule.name == "amine_acetamide" and not any(
                    source.atom(b).atomic_number == 6
                    for a in active
                    for b in source._bonds[a]
                    if b not in mask
                ):
                    continue
                if not any(
                    set(product._bonds[a]) - set(source._bonds[a]) for a in active
                ):
                    continue
                if any(
                    not (set(source._bonds[a]) - mask) <= set(product._bonds[a])
                    for a in active
                ):
                    continue
                precursor = next(
                    (
                        mid
                        for mid in record.child_mol_ids
                        if set(mapping.values())
                        <= set(
                            chemistry.parse_molecule(index.molecule_records[mid].smiles)
                        )
                    ),
                    None,
                )
                if phthalimide_nitrogen_donor(
                    index, rule.name, precursor, anchors, mapping.values()
                ):
                    continue
                found[(ri, tuple(sorted(mask)))] = (ri, rule.name, tuple(active), mask)
    return reaction, list(found.values())


def pyridazinone_sequence(reaction, candidate):
    """Narrow structural recipe for the five transformations exemplified by 4826."""
    ri, pg, anchors, mask = candidate
    if pg != "heteroaryl_n_thp" or len(anchors) != 1:
        return None
    source, product = reaction.reactants[ri], reaction.products[0]
    n = anchors[0]
    additions = set(product._bonds[n]) - set(source._bonds[n])
    if len(additions) != 1:
        return None
    alkyl = next(iter(additions))
    donors = [m for m in reaction.reactants if m.has_atom(alkyl) and not m.has_atom(n)]
    if len(donors) != 1:
        return None
    donor = donors[0]
    bromines = [
        b
        for b in donor._bonds[alkyl]
        if donor.atom(b).atomic_number == 35 and not product.has_atom(b)
    ]
    cls = [
        (a, b)
        for a in source
        for b in source._bonds[a]
        if source.atom(a).atomic_number == 6
        and source.atom(b).atomic_number == 17
        and not product.has_atom(b)
    ]
    oxygen_links = [
        (a, b)
        for a in source
        if product.has_atom(a)
        for b in product._bonds[a]
        if not source.has_atom(b) and product.atom(b).atomic_number == 8
    ]
    if len(bromines) != 1 or len(cls) != 2 or len(oxygen_links) != 1:
        return None
    aryl_c, oxygen = oxygen_links[0]
    phenols = [m for m in reaction.reactants if m.has_atom(oxygen)]
    if len(phenols) != 1 or not any(a == aryl_c for a, _ in cls):
        return None
    phenol = phenols[0]
    methyls = [
        (o, c)
        for o in donor
        if donor.atom(o).atomic_number == 8 and product.has_atom(o)
        for c in donor._bonds[o]
        if donor.atom(c).atomic_number == 6
        and not product.has_atom(c)
        and len(donor._bonds[c]) == 1
    ]
    if len(methyls) != 1:
        return None
    # Derive each intermediate from recorded molecular states.
    attached_cl = next(b for a, b in cls if a == aryl_c)
    other_cl = next(b for a, b in cls if a != aryl_c)
    first = remove_atoms(source, {attached_cl}) | phenol
    first.add_bond(aryl_c, oxygen, 1)
    first = prepared(first)
    second = remove_atoms(first, mask)
    third = remove_atoms(second, {other_cl})
    # Restore the methyl ester on the recorded product. This preserves any
    # recorded substitution stereochemistry at the alkylated carbon, instead
    # of losing it while deleting Br and assigning it to hydrolysis afterward.
    ester_o, methyl_c = methyls[0]
    fourth = product.copy() | donor.substructure({methyl_c})
    fourth.add_bond(ester_o, methyl_c, 1)
    fourth = prepared(fourth)
    return [
        ("aryl_oxygen_substitution", (source, phenol), first),
        ("deprotection", (first,), second),
        ("dechlorination", (second,), third),
        ("N_alkylation", (third, donor), fourth),
        ("ester_hydrolysis", (fourth,), product),
    ]


def make_sequence(reaction, matches):
    if len(matches) == 1:
        special = pyridazinone_sequence(reaction, matches[0])
        if special is not None:
            return special
    if len(matches) != 1:
        raise ValueError(
            "multiple fused PG sites require an unambiguous joint decomposition"
        )
    ri, _pg, _anchors, mask = matches[0]
    source = reaction.reactants[ri]
    intermediate = remove_atoms(source, mask)
    remaining = tuple(
        intermediate if i == ri else m for i, m in enumerate(reaction.reactants)
    )
    return [
        ("deprotection", (source,), intermediate),
        ("subsequent_transformation", remaining, reaction.products[0]),
    ]


def replacement(index, record, matches, reaction, route_id):
    sequence = make_sequence(reaction, matches)
    steps = [ReactionContainer(inputs, (product,)) for _, inputs, product in sequence]
    validate_sequence(reaction, steps)
    # Original subtrees are attached once, at their first consuming step.
    available = []
    for mid in record.child_mol_ids:
        m = index.molecule_records[mid]
        available.append((chemistry.parse_molecule(m.smiles), deepcopy(m.node)))
    original_metadata = deepcopy(record.node.get("metadata", {}))
    source_id = raw_source_record_id(original_metadata)
    generated = []
    for forward, ((role, inputs, product), step) in enumerate(zip(sequence, steps), 1):
        children = []
        for m in inputs:
            pos = next(
                (
                    i
                    for i, (candidate, _) in enumerate(available)
                    if side_state([candidate]) == side_state([m])
                ),
                None,
            )
            if pos is None:
                raise ValueError("missing original subtree for inferred step")
            children.append(available.pop(pos)[1])
        text = format(step, "m")
        evidence = {
            "route_id": str(route_id),
            "original_reaction_id": record.node_id,
            "original_reaction_node_path": list(record.node_path),
            "original_reaction_smiles": record.reaction_smiles,
            "original_metadata": original_metadata,
            "original_source_record_id": source_id,
            "split_method": "pg_fused_decomposition",
            "inferred": True,
            "policy_version": 1,
            "decomposition_role": role,
            "forward_step": forward,
            "split_step": len(sequence) - forward + 1,
            "split_steps": len(sequence),
            "pg_types": sorted({m[1] for m in matches}),
        }
        node = {
            "type": "reaction",
            "smiles": text,
            "metadata": {"ID": source_id, "route_preprocessing_split": evidence},
            "children": children,
        }
        mol = {
            "type": "mol",
            "smiles": format(product, "m"),
            "mapped_smiles": format(product, "m"),
            "in_stock": False,
            "children": [node],
        }
        available.append((product, mol))
        generated.append(text)
    if len(available) != 1:
        raise ValueError("inferred sequence leaves an unconsumed original subtree")
    return available[0][1]["children"][0], {
        "reaction_id": record.node_id,
        "reaction_node_path": list(record.node_path),
        "split_method": "pg_fused_decomposition",
        "protection_related": True,
        "pg_types": sorted({m[1] for m in matches}),
        "generated_reactions": generated,
        "original_reaction_smiles": record.reaction_smiles,
        "inferred": True,
    }


def split_fused_pg_reactions(index, rules, route_id):
    """Apply validated replacements bottom-up, returning changes and diagnostics."""
    changes, unresolved = [], []
    for rid in reversed(index.reaction_order):
        record = index.reaction_records[rid]
        if (
            record.node.get("metadata", {})
            .get("route_preprocessing_split", {})
            .get("split_method")
            == "pg_fused_decomposition"
        ):
            continue
        reaction, matches = candidates(index, record, rules)
        if not matches:
            continue
        try:
            node, change = replacement(index, record, matches, reaction, route_id)
        except Exception as exc:
            unresolved.append(
                {
                    "reaction_id": rid,
                    "reaction_node_path": list(record.node_path),
                    "reason": "fused_pg_decomposition_failed",
                    "message": str(exc),
                }
            )
            continue
        record.node.clear()
        record.node.update(node)
        changes.append(change)
    return changes, unresolved
