"""Incremental route JSON transport with complete-document validation."""

import json
from pathlib import Path
from typing import Any, Iterable, Iterator

import ijson

import route_inspector.routes.access as route_access
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.text import open_text


def _validate_route(route_id: Any, route: Any) -> dict[str, Any]:
    if not isinstance(route, dict) or route.get("type") != "mol":
        raise ValueError(f"route {route_id!r} does not have a molecule root")
    return route


def iter_route_json_file(path: str | Path) -> Iterator[tuple[Any, dict[str, Any]]]:
    """Yield a route list, ID mapping, or single molecule-root route from JSON."""

    with Path(path).open("rb") as stream:
        yield from iter_route_json_stream(stream)


def iter_route_json_stream(stream) -> Iterator[tuple[Any, dict[str, Any]]]:
    """Parse a seekable binary stream without reopening its source path.

    Rewind after detecting the existing collection format. Callers that hash
    reads must reset their digest on that rewind, then exhaust this iterator.
    """
    parser = ijson.parse(stream)
    try:
        _prefix, first_event, _value = next(parser)
    except StopIteration as exc:
        raise ValueError("route JSON is empty") from exc
    if first_event == "start_array":
        root_kind = "array"
    elif first_event == "start_map":
        try:
            _prefix, second_event, _value = next(parser)
        except StopIteration as exc:
            raise ValueError("route JSON object is incomplete") from exc
        if second_event == "end_map":
            root_kind = "mapping"
        elif second_event != "map_key":
            raise ValueError("route JSON has an unsupported top-level object")
        else:
            try:
                _prefix, value_event, _value = next(parser)
            except StopIteration as exc:
                raise ValueError("route JSON object is incomplete") from exc
            root_kind = "mapping" if value_event == "start_map" else "route"
    else:
        raise ValueError("route JSON root must be an array or object")
    del parser
    stream.seek(0)
    if root_kind == "array":
        for route_id, route in enumerate(ijson.items(stream, "item")):
            yield route_id, _validate_route(route_id, route)
        return
    if root_kind == "mapping":
        for route_id, route in ijson.kvitems(stream, ""):
            yield route_id, _validate_route(route_id, route)
        return
    routes = ijson.items(stream, "")
    route = _validate_route("0", next(routes))
    # Consume the complete document, including validation of trailing bytes.
    for _ in routes:
        raise ValueError("route JSON contains multiple root values")
    yield from route_access.route_items(route)


def limited_route_items(
    routes_json: Any,
    limit: int | None,
) -> list[tuple[Any, dict[str, Any]]]:
    """Yield route items after applying the optional route limit.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    items = []
    for index, item in enumerate(route_access.route_items(routes_json), start=1):
        if limit is not None and index > limit:
            break
        items.append(item)
    return items


def iter_route_items_from_json_file(
    path: Path,
    limit: int | None,
    *,
    chunk_size: int = 1024 * 1024,
) -> Iterable[tuple[Any, dict[str, Any]]]:
    """Stream top-level route entries from a list or dict JSON file.

    The PaRoutes/all-routes files can be larger than 1 GB. Loading the entire
    JSON before honoring ``--limit`` adds a large fixed cost and puts pressure on
    multiprocessing. This parser keeps only a small text buffer and the current
    route object in memory.
    """

    decoder = json.JSONDecoder()
    path = resolve_existing_path(path)

    with open_text(path) as file:
        buffer = ""
        position = 0
        eof = False

        def compact_buffer() -> None:
            """Discard consumed text from the streaming JSON parser buffer.

            The helper feeds rule extraction, center-overlap filtering, or final TSV
            aggregation without changing the original route JSON in place.
            """
            nonlocal buffer, position
            if position:
                buffer = buffer[position:]
                position = 0

        def read_more() -> None:
            """Read the next chunk for streaming JSON parsing.

            The helper feeds rule extraction, center-overlap filtering, or final TSV
            aggregation without changing the original route JSON in place.
            """
            nonlocal buffer, eof
            compact_buffer()
            chunk = file.read(chunk_size)
            if chunk:
                buffer += chunk
            else:
                eof = True

        def ensure_buffer() -> None:
            """Fill the streaming JSON parser buffer before decoding continues.

            The helper feeds rule extraction, center-overlap filtering, or final TSV
            aggregation without changing the original route JSON in place.
            """
            if position >= len(buffer) and not eof:
                read_more()

        def skip_whitespace() -> None:
            """Advance the streaming JSON parser past insignificant whitespace.

            The helper feeds rule extraction, center-overlap filtering, or final TSV
            aggregation without changing the original route JSON in place.
            """
            nonlocal position
            while True:
                ensure_buffer()
                while position < len(buffer) and buffer[position].isspace():
                    position += 1
                if position < len(buffer) or eof:
                    return

        def expect_character(expected: str) -> None:
            """Consume the expected character from the streaming JSON parser.

            The helper feeds rule extraction, center-overlap filtering, or final TSV
            aggregation without changing the original route JSON in place.
            """
            nonlocal position
            skip_whitespace()
            ensure_buffer()
            if position >= len(buffer):
                raise ValueError(f"expected {expected!r}, reached end of JSON")
            actual = buffer[position]
            if actual != expected:
                raise ValueError(f"expected {expected!r}, got {actual!r}")
            position += 1

        def decode_next() -> Any:
            """Decode the next route object from the streaming JSON parser.

            The helper feeds rule extraction, center-overlap filtering, or final TSV
            aggregation without changing the original route JSON in place.
            """
            nonlocal position
            skip_whitespace()
            while True:
                try:
                    value, end = decoder.raw_decode(buffer, position)
                    position = end
                    return value
                except json.JSONDecodeError:
                    if eof:
                        raise
                    read_more()

        read_more()
        skip_whitespace()
        ensure_buffer()
        if position >= len(buffer):
            return

        root_start = buffer[position]
        position += 1
        seen = 0

        if root_start == "[":
            route_id = 0
            skip_whitespace()
            ensure_buffer()
            if position < len(buffer) and buffer[position] == "]":
                return
            while True:
                route = decode_next()
                yield route_id, route
                seen += 1
                if limit is not None and seen >= limit:
                    return
                route_id += 1

                skip_whitespace()
                ensure_buffer()
                if position >= len(buffer):
                    raise ValueError("unexpected end of JSON array")
                separator = buffer[position]
                position += 1
                if separator == "]":
                    return
                if separator != ",":
                    raise ValueError(f"expected ',' or ']', got {separator!r}")

        elif root_start == "{":
            skip_whitespace()
            ensure_buffer()
            if position < len(buffer) and buffer[position] == "}":
                return
            while True:
                route_id = decode_next()
                if not isinstance(route_id, str):
                    raise ValueError("top-level route JSON object keys must be strings")
                expect_character(":")
                route = decode_next()
                yield route_id, route
                seen += 1
                if limit is not None and seen >= limit:
                    return

                skip_whitespace()
                ensure_buffer()
                if position >= len(buffer):
                    raise ValueError("unexpected end of JSON object")
                separator = buffer[position]
                position += 1
                if separator == "}":
                    return
                if separator != ",":
                    raise ValueError(f"expected ',' or '}}', got {separator!r}")
        else:
            raise TypeError(f"unsupported routes JSON root: {root_start!r}")


def filtered_route_items_from_json_file(
    path: Path,
    limit: int | None,
    failed_route_ids: set[Any],
) -> Iterable[tuple[Any, dict[str, Any]]]:
    """Stream route items from JSON while applying optional route-ID filters.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    for route_id, route in iter_route_items_from_json_file(path, limit):
        if route_id in failed_route_ids:
            continue
        yield route_id, route
