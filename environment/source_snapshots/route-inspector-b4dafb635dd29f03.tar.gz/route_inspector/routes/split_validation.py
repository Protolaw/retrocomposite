"""Validation helpers for generated multicentre-reaction split routes."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from route_inspector import chemistry
from route_inspector.routes import access as routes
from route_inspector.routes.molecular_identity import (
    molecule_multisets_equivalent,
)


def validate_generated_reaction_has_structural_change(reaction: Any) -> None:
    """Reject a generated reaction whose sides differ only by atom mapping."""

    if molecule_multisets_equivalent(reaction.reactants, reaction.products):
        raise ValueError("generated split contains a graph-identical no-op reaction")


def _children_match_components(
    reaction_node: dict[str, Any],
    components: Iterable[Any],
) -> bool:
    parsed_children = []
    for child in reaction_node.get("children", []) or []:
        if not isinstance(child, dict) or child.get("type") != "mol":
            continue
        try:
            parsed_children.append(
                chemistry.parse_molecule(routes.molecule_node_smiles(child))
            )
        except Exception:
            return False
    return molecule_multisets_equivalent(parsed_children, tuple(components))


def orient_and_validate_generated_split_route(
    generated_root: dict[str, Any],
) -> None:
    """Convert retro-reactor records to forward route edges and reject no-ops."""

    from chython.containers import ReactionContainer

    def visit_molecule(node: dict[str, Any]) -> None:
        try:
            parent_molecule = chemistry.parse_molecule(
                routes.molecule_node_smiles(node)
            )
        except Exception as exc:
            raise ValueError(
                f"could not parse generated route molecule: {exc}"
            ) from exc

        for reaction_node in node.get("children", []) or []:
            if (
                not isinstance(reaction_node, dict)
                or reaction_node.get("type") != "reaction"
            ):
                continue
            try:
                reaction = chemistry.parse_reaction(
                    routes.reaction_smiles_from_node(reaction_node)
                )
            except Exception as exc:
                raise ValueError(
                    f"could not parse generated split reaction: {exc}"
                ) from exc

            validate_generated_reaction_has_structural_change(reaction)

            parent_matches_forward = any(
                chemistry.molecules_equivalent(product, parent_molecule)
                for product in reaction.products
            )
            children_match_forward = _children_match_components(
                reaction_node,
                reaction.reactants,
            )
            parent_matches_retro = any(
                chemistry.molecules_equivalent(reactant, parent_molecule)
                for reactant in reaction.reactants
            )
            children_match_retro = _children_match_components(
                reaction_node,
                reaction.products,
            )

            forward = parent_matches_forward and children_match_forward
            retro = parent_matches_retro and children_match_retro
            if retro and not forward:
                reaction = ReactionContainer(
                    tuple(molecule.copy() for molecule in reaction.products),
                    tuple(molecule.copy() for molecule in reaction.reactants),
                    tuple(molecule.copy() for molecule in reaction.reagents),
                    meta=dict(getattr(reaction, "meta", {}) or {}),
                    name=getattr(reaction, "name", None),
                )
                reaction_node["smiles"] = format(reaction, "m")
            elif not forward:
                raise ValueError(
                    "generated split reaction matches neither the forward nor "
                    "retrosynthetic route-edge direction"
                )

            for molecule_child in reaction_node.get("children", []) or []:
                if (
                    isinstance(molecule_child, dict)
                    and molecule_child.get("type") == "mol"
                ):
                    visit_molecule(molecule_child)

    visit_molecule(generated_root)
