"""Version-scoped SynPlanner route import, traversal, and CGR adaptations."""

from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
from importlib.metadata import version
from typing import Any


@lru_cache(maxsize=8)
def _installed_synplanner_version(provider):
    """Package versions are fixed for this process; retain injectable providers."""
    return provider("SynPlanner")


def route_cgr_compatibility_policy() -> str:
    """Identify the narrowly versioned RouteCGR electronic-state adapter."""

    return (
        "synplanner-1.8.0-state-and-stereo-v1"
        if _installed_synplanner_version(version) == "1.8.0"
        else "native"
    )


def _restore_route_cgr_electronic_history(cgr: Any) -> None:
    """Repair the 1.8.0 stale-atom replacement regression, not target chemistry.

    Chython CGR composition can retain an earlier atom object's product state
    while its state dictionaries correctly contain the final state. SynPlanner
    1.8.0 replaces those atoms to attach route labels; replacement copies the
    stale object state back into the dictionaries. Its chronological per-step
    labels still retain the original states.

    Fold ONLY those labels: first reactant state -> last product state. Never
    consult the expected target. Require the observed mismatch to be exactly
    the known stale-first-product pattern; other inconsistencies fail closed.
    Both native CGR state tables and atom objects are synchronized by the
    supported replace_atom API. No input reactions or molecular graphs change.
    """

    for atom_id, atom in list(cgr.atoms()):
        states = getattr(atom, "route_atom_step_states", None)
        if not states:
            raise ValueError(
                f"SynPlanner 1.8.0 CGR atom {atom_id} lacks electronic-state history"
            )
        first, last = states[min(states)], states[max(states)]
        expected = (first[0], last[1], first[2], last[3])
        observed = (
            cgr._charges[atom_id],
            cgr._p_charges[atom_id],
            cgr._radicals[atom_id],
            cgr._p_radicals[atom_id],
        )
        atom_state = (atom.charge, atom.p_charge, atom.is_radical, atom.p_is_radical)
        if observed == expected and atom_state == expected:
            continue
        if observed not in (expected, tuple(first)) or atom_state not in (
            expected,
            tuple(first),
        ):
            raise ValueError(
                f"SynPlanner 1.8.0 CGR atom {atom_id} has an unexpected "
                "electronic-state/history inconsistency"
            )
        corrected = atom.copy()
        (
            corrected._charge,
            corrected._p_charge,
            corrected._is_radical,
            corrected._p_is_radical,
        ) = expected
        cgr.replace_atom(atom_id, corrected)


def build_route_cgr(*args: Any, **kwargs: Any) -> Any:
    """Build with SynPlanner and repair its known 1.8.0 state-copy regression.

    The strict route-target validator still independently compares the result
    with the recorded target, including charges and radicals. No global
    monkeypatches or installed dependency files are changed.
    """

    from synplan.chem.reaction.routes.representation.route_cgr import (
        build_route_cgr as native_build,
    )

    result = native_build(*args, **kwargs)
    if result.ok and route_cgr_compatibility_policy() != "native":
        _restore_route_cgr_electronic_history(result.cgr)
    return result


def compose_route_cgr(
    tree_or_routes: Any,
    route_id: Any,
    preserve_transient_bonds: bool = True,
    return_reactions_dict: bool = False,
) -> Any:
    """Return the legacy result shape using the same state-safe builder."""

    return build_route_cgr(
        tree_or_routes,
        route_id,
        preserve_transient_bonds,
        include_reactions=return_reactions_dict,
    ).as_legacy_dict(include_reactions=return_reactions_dict)


def tree_route_node_ids(tree: Any, node_id: Any) -> tuple[Any, ...]:
    """Resolve the root-to-node path across the 1.8 Tree API move."""

    method = getattr(tree, "route_node_ids", None)
    if method is not None:
        return tuple(method(node_id))
    from synplan.chem.reaction.routes.traversal import route_node_ids

    return tuple(route_node_ids(tree.parents, node_id))


def _read_route_reaction(text: str) -> Any:
    """Return a private copy of a strictly parsed, stereo-preserving reaction."""
    from synplan.chem.stereo import parse_smiles_preserving_stereo

    from route_inspector import chemistry

    original = _cached_route_reaction(
        text, parse_smiles_preserving_stereo, chemistry.parse_reaction
    )
    reaction = original.copy()
    reaction.meta.update(deepcopy(original.meta))
    return reaction


@lru_cache(maxsize=512)
def _cached_route_reaction(text: str, strict_parser, fallback_parser) -> Any:
    """Strictly parse, normalizing only independently verified redundant slashes."""

    try:
        return strict_parser(text)
    except ValueError as error:
        if str(error) != "directional bond has no assigned stereo element":
            raise
        from route_inspector.routes.alignment import mapped_stereo_signature

        canonical = format(fallback_parser(text), "m")
        before, after = text.split(">"), canonical.split(">")
        if (
            len(before) != 3
            or len(after) != 3
            or any(
                mapped_stereo_signature(left) != mapped_stereo_signature(right)
                for left, right in zip(before, after)
                if left or right
            )
        ):
            raise ValueError(
                "canonical reaction spelling changes mapped structure or stereo"
            ) from error
        # The original failure must disappear under strict parsing. Chython's
        # map-retaining comparison above must also retain all assigned stereo,
        # states and component multiplicities, including the middle field.
        reaction = strict_parser(canonical)
        reaction.meta["route_inspector_smiles_normalization"] = {
            "method": "verified_redundant_directional_bonds",
            "original_smiles": text,
        }
        return reaction


def make_route_cgr_dict(routes_json: Any) -> dict:
    """Import 1.8 route steps without dropping redundant-slash legacy routes.

    Preserve original child order, repeated occurrences and mapped stereo.
    Do not edit source trees or silently discard failing routes. Other releases
    continue using their native importer.
    """

    from synplan.chem.reaction.routes.io.json import make_dict

    if route_cgr_compatibility_policy() == "native":
        return make_dict(routes_json)
    from synplan.chem.reaction.routes.io.metadata import restore_reaction_metadata

    from route_inspector.routes.access import route_items

    result = {}
    for route_id, root in route_items(routes_json):
        reactions = []

        def collect(node):
            for child in node.get("children") or ():
                collect(child)
            if node.get("type") == "reaction":
                reaction = _read_route_reaction(node["smiles"])
                restore_reaction_metadata(reaction, node.get("meta"))
                reactions.append(reaction)

        collect(root)
        result[int(route_id)] = dict(enumerate(reactions))
    return result
