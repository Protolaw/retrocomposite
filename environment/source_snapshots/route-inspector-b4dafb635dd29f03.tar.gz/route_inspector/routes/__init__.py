"""Shared route operations, independent of dataset and command workflows."""
