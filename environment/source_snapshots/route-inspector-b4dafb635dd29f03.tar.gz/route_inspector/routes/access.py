"""Occurrence-aware route access without normalization dependencies."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

RouteCollection = list[dict[str, Any]] | Mapping[Any, Any]


class RouteNormalizationError(ValueError):
    """Raised when route-level atom identity cannot be propagated safely."""

    def __init__(
        self, message: str, *, reaction_node_path: tuple[int, ...] | None = None
    ) -> None:
        super().__init__(message)
        self.reaction_node_path = reaction_node_path


def route_items(
    routes_json: RouteCollection,
) -> Iterable[tuple[Any, dict[str, Any]]]:
    """Yield IDs and roots from a route list, ID mapping, or single molecule root."""

    if isinstance(routes_json, list):
        yield from enumerate(routes_json)
        return
    if isinstance(routes_json, Mapping):
        if routes_json.get("type") == "mol":
            metadata = routes_json.get("metadata") or {}
            yield metadata.get("route_id", "0"), routes_json
            return
        yield from routes_json.items()
        return
    raise TypeError(f"unsupported routes JSON root: {type(routes_json)!r}")


def route_by_id(routes_json: RouteCollection, route_id: Any) -> dict[str, Any]:
    """Return a molecule-root route while accepting list, integer, or string IDs."""

    root: Any
    if isinstance(routes_json, list):
        try:
            route_index = int(route_id)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"route ID {route_id!r} is not a valid list index"
            ) from exc
        if route_index < 0 or route_index >= len(routes_json):
            raise ValueError(f"route ID {route_id!r} not found in routes_json")
        root = routes_json[route_index]
    elif isinstance(routes_json, Mapping):
        candidates: list[Any] = [route_id, str(route_id)]
        try:
            candidates.append(int(route_id))
        except (TypeError, ValueError):
            pass
        for candidate in candidates:
            try:
                if candidate in routes_json:
                    root = routes_json[candidate]
                    break
            except TypeError:
                continue
        else:
            raise ValueError(f"route ID {route_id!r} not found in routes_json")
    else:
        raise TypeError(f"unsupported routes JSON root: {type(routes_json)!r}")

    if not isinstance(root, dict) or root.get("type") != "mol":
        raise ValueError(f"route {route_id!r} does not have a molecule root")
    return root


def count_reaction_nodes(node: dict[str, Any]) -> int:
    """Count reaction nodes recursively in a route tree."""

    return int(node.get("type") == "reaction") + sum(
        count_reaction_nodes(child)
        for child in node.get("children", []) or []
        if isinstance(child, dict)
    )


def reaction_smiles_from_node(node: dict[str, Any]) -> str:
    """Read mapped reaction SMILES from a PaRoutes reaction node."""

    metadata = node.get("metadata") or {}
    reaction_smiles = (
        node.get("smiles")
        or metadata.get("smiles")
        or metadata.get("mapped_reaction_smiles")
        or metadata.get("rsmi")
    )
    if not reaction_smiles:
        raise ValueError("reaction node has no mapped reaction SMILES")
    return reaction_smiles


def molecule_node_smiles(node: dict[str, Any]) -> str:
    """Read the primary molecule SMILES from a PaRoutes molecule node."""

    metadata = node.get("metadata") or {}
    return node.get("smiles") or metadata.get("smiles") or ""


def molecule_node_mapped_smiles(node: dict[str, Any]) -> str:
    """Read a molecule node's explicitly mapped SMILES when available."""

    metadata = node.get("metadata") or {}
    return (
        node.get("mapped_smiles")
        or metadata.get("mapped_smiles")
        or metadata.get("mapped_molecule_smiles")
        or ""
    )


def walk_route_nodes(node, path=()):
    """Yield every original occurrence in child order, including repeated inputs."""
    yield path, node
    for index, child in enumerate(node.get("children") or []):
        yield from walk_route_nodes(child, (*path, index))


def reaction_nodes(node, path=()):
    """Yield reaction occurrences with stable child-index paths."""
    for node_path, current in walk_route_nodes(node, path):
        if current.get("type") == "reaction":
            yield node_path, current
