"""Route-level diagnostics for atom provenance and mapping quality.

The atom-provenance audit operates on each recorded source reaction before route
normalization and multicentre splitting. It uses explicit atom-map properties
from the source SMILES rather than Chython container indices, because Chython
assigns integer indices to atoms that were not explicitly mapped. The audit is
independent of RRSeq extraction and reports provenance gaps without editing a
route."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Any, Iterable

import route_inspector.routes.access as route_access
from route_inspector import chemistry


def reaction_occurrences(route: dict[str, Any]) -> Iterable[dict[str, Any]]:
    """Yield reaction nodes in deterministic target-to-leaf preorder."""

    reaction_index = 0

    def visit_molecule(molecule_node: dict[str, Any]) -> Iterable[dict[str, Any]]:
        nonlocal reaction_index
        for child in molecule_node.get("children") or ():
            if not isinstance(child, dict) or child.get("type") != "reaction":
                continue
            current_index = reaction_index
            reaction_index += 1
            metadata = molecule_node.get("metadata") or {}
            yield {
                "reaction_step": f"r{current_index}",
                "target_molecule": (
                    metadata.get("mapped_smiles")
                    or molecule_node.get("smiles")
                    or metadata.get("smiles")
                    or ""
                ),
                "node": child,
            }
            for molecule_child in child.get("children") or ():
                if (
                    isinstance(molecule_child, dict)
                    and molecule_child.get("type") == "mol"
                ):
                    yield from visit_molecule(molecule_child)

    yield from visit_molecule(route)


def _raw_reaction_sides(reaction_smiles: str) -> tuple[str, str, str]:
    parts = reaction_smiles.split(">")
    if len(parts) != 3:
        raise ValueError("reaction SMILES must contain two > separators")
    return parts[0], parts[1], parts[2]


def _chython_side_atoms(side_smiles: str) -> tuple[list[dict[str, Any]], int]:
    """Parse source atoms while preserving whether a map was explicitly written."""

    atoms: list[dict[str, Any]] = []
    component_count = 0
    for component_index, component_smiles in enumerate(
        component for component in side_smiles.split(".") if component
    ):
        molecule = chemistry.parse_molecule(component_smiles)
        component_count += 1
        for _, atom in molecule.atoms():
            atomic_number = int(atom.atomic_number)
            if atomic_number == 1:
                continue
            # Chython assigns container indices to atoms without source map tokens.
            # The parser-retained value is None for those atoms and preserves an
            # explicitly written map, including :0.
            parsed_mapping = atom._parsed_mapping
            atoms.append(
                {
                    "map_id": 0 if parsed_mapping is None else int(parsed_mapping),
                    "element": atom.atomic_symbol,
                    "atomic_number": atomic_number,
                    "isotope": int(atom.isotope or 0),
                    "formal_charge": int(atom.charge),
                    "component_index": component_index,
                    "component_smiles": component_smiles,
                }
            )
    return atoms, component_count


def _invariant_atom_signature(atom: dict[str, Any]) -> tuple[int, int]:
    return int(atom["atomic_number"]), int(atom["isotope"])


def _source_atom_provenance(reaction_smiles: str) -> dict[str, Any]:
    reactant_smiles, reagent_smiles, product_smiles = _raw_reaction_sides(
        reaction_smiles
    )
    reactant_atoms, reactant_count = _chython_side_atoms(reactant_smiles)
    reagent_atoms, reagent_count = _chython_side_atoms(reagent_smiles)
    product_atoms, product_count = _chython_side_atoms(product_smiles)

    reactant_by_map = {
        int(atom["map_id"]): atom for atom in reactant_atoms if int(atom["map_id"]) > 0
    }
    product_by_map = {
        int(atom["map_id"]): atom for atom in product_atoms if int(atom["map_id"]) > 0
    }
    absent_maps = {map_id for map_id in product_by_map if map_id not in reactant_by_map}
    signature_mismatches = {
        map_id
        for map_id in set(product_by_map) & set(reactant_by_map)
        if _invariant_atom_signature(product_by_map[map_id])
        != _invariant_atom_signature(reactant_by_map[map_id])
    }
    product_only_maps = tuple(sorted(absent_maps | signature_mismatches))
    product_only_atoms = [product_by_map[map_id] for map_id in product_only_maps]
    unmapped_product_atoms = [
        atom for atom in product_atoms if int(atom["map_id"]) == 0
    ]
    reactant_elements = Counter(atom["element"] for atom in reactant_atoms)
    product_elements = Counter(atom["element"] for atom in product_atoms)
    element_surplus = {
        element: count - reactant_elements[element]
        for element, count in product_elements.items()
        if count > reactant_elements[element]
    }
    element_surplus_atoms = [
        atom
        for element, surplus_count in sorted(element_surplus.items())
        for atom in [
            candidate for candidate in product_atoms if candidate["element"] == element
        ][:surplus_count]
    ]

    return {
        "reactant_count": reactant_count,
        "reagent_count": reagent_count,
        "product_count": product_count,
        "product_only_map_ids": product_only_maps,
        "product_only_atoms": product_only_atoms,
        "product_only_map_signature_mismatch_ids": tuple(sorted(signature_mismatches)),
        "raw_reactant_unmapped_atom_count": sum(
            int(atom["map_id"]) == 0 for atom in reactant_atoms
        ),
        "raw_reagent_unmapped_atom_count": sum(
            int(atom["map_id"]) == 0 for atom in reagent_atoms
        ),
        "raw_product_unmapped_atom_count": len(unmapped_product_atoms),
        "raw_product_unmapped_atoms": unmapped_product_atoms,
        "element_balance_surplus_atom_count": sum(element_surplus.values()),
        "element_balance_surplus_atoms": element_surplus_atoms,
    }


def _element_formula(records: Iterable[dict[str, Any]]) -> str:
    counts = Counter(record["element"] for record in records)
    return "".join(
        f"{element}{count if count != 1 else ''}"
        for element, count in sorted(counts.items())
    )


def _error_record(
    *,
    dataset: str,
    route_id: Any,
    reaction_step: str,
    stage: str,
    exc: Exception,
    reaction_smiles: str,
) -> dict[str, Any]:
    return {
        "dataset": dataset,
        "route_id": str(route_id),
        "reaction_step": reaction_step,
        "stage": stage,
        "error_type": type(exc).__qualname__,
        "message": str(exc),
        "reaction_smiles": reaction_smiles,
    }


def _route_id_sort_key(value: Any) -> tuple[int, Any]:
    value = str(value)
    if value.isdigit():
        return (0, int(value))
    return (1, value)


@dataclass(frozen=True)
class AtomProvenanceAuditResult:
    """Event-level results from the recorded-source provenance audit."""

    dataset: str
    routes_seen: int
    reactions_seen: int
    records: tuple[dict[str, Any], ...]
    parse_errors: tuple[dict[str, Any], ...]

    def summary(self) -> dict[str, Any]:
        confirmed = [
            record
            for record in self.records
            if int(record["product_only_atom_count"]) > 0
        ]
        unverifiable = [
            record
            for record in self.records
            if int(record["product_only_atom_count"]) == 0
            and int(record["raw_product_unmapped_atom_count"]) > 0
        ]
        affected_route_ids = sorted(
            {str(record["route_id"]) for record in confirmed},
            key=_route_id_sort_key,
        )
        single_precursor = [
            record for record in confirmed if record["single_precursor_no_reagent"]
        ]
        single_precursor_route_ids = sorted(
            {str(record["route_id"]) for record in single_precursor},
            key=_route_id_sort_key,
        )
        return {
            "dataset": self.dataset,
            "routes_seen": self.routes_seen,
            "reactions_seen": self.reactions_seen,
            "reactions_with_product_only_non_hydrogen_atoms_without_input": len(
                confirmed
            ),
            "routes_with_product_only_non_hydrogen_atoms_without_input": len(
                affected_route_ids
            ),
            "reactions_with_product_only_non_hydrogen_atoms_without_reactant": len(
                confirmed
            ),
            "reactions_with_unmapped_product_atoms_unverifiable": len(unverifiable),
            "single_precursor_no_reagent_cases": len(single_precursor),
            "routes_with_single_precursor_no_reagent_cases": len(
                single_precursor_route_ids
            ),
            "parse_errors": len(self.parse_errors),
            "parse_error_examples": list(self.parse_errors[:25]),
            "affected_route_ids": affected_route_ids,
            "definition": (
                "A confirmed event contains an explicitly mapped non-hydrogen "
                "atom in the recorded source product whose map is absent from the "
                "recorded reactant side, or is reused there for a different "
                "element/isotope, or has a positive product-side elemental "
                "balance that proves a minimum number of atoms lack a source. "
                "Other unmapped product atoms are retained as unverifiable rather "
                "than silently treated as mapped atoms."
            ),
        }


def audit_atom_provenance(
    routes_json: Any,
    *,
    dataset: str = "",
    limit: int | None = None,
) -> AtomProvenanceAuditResult:
    """Audit product atom provenance in recorded source route reactions."""

    records: list[dict[str, Any]] = []
    parse_errors: list[dict[str, Any]] = []
    routes_seen = 0
    reactions_seen = 0

    for route_index, (route_id, route) in enumerate(
        route_access.route_items(routes_json),
        start=1,
    ):
        if limit is not None and route_index > limit:
            break
        routes_seen += 1
        for occurrence in reaction_occurrences(route):
            reactions_seen += 1
            node = occurrence["node"]
            metadata = node.get("metadata") or {}
            raw_smiles = str(
                metadata.get("smiles")
                or metadata.get("mapped_reaction_smiles")
                or metadata.get("rsmi")
                or node.get("smiles")
                or ""
            )
            normalized_smiles = str(node.get("smiles") or "")
            try:
                source_info = _source_atom_provenance(raw_smiles)
            except Exception as exc:
                parse_errors.append(
                    _error_record(
                        dataset=dataset,
                        route_id=route_id,
                        reaction_step=occurrence["reaction_step"],
                        stage="parse_raw_reaction_atom_maps",
                        exc=exc,
                        reaction_smiles=raw_smiles,
                    )
                )
                continue

            product_only_maps = source_info["product_only_map_ids"]
            unmapped_product_count = source_info["raw_product_unmapped_atom_count"]
            element_surplus_count = source_info["element_balance_surplus_atom_count"]
            if (
                not product_only_maps
                and not unmapped_product_count
                and not element_surplus_count
            ):
                continue

            raw_counts = {
                key: source_info[key]
                for key in (
                    "raw_reactant_unmapped_atom_count",
                    "raw_reagent_unmapped_atom_count",
                    "raw_product_unmapped_atom_count",
                )
            }
            confirmed = bool(product_only_maps or element_surplus_count)
            product_only_count = max(len(product_only_maps), element_surplus_count)
            if product_only_maps and element_surplus_count:
                provenance_certainty = (
                    "confirmed_by_explicit_atom_maps_and_element_balance"
                )
            elif product_only_maps:
                provenance_certainty = "confirmed_by_explicit_atom_maps"
            elif element_surplus_count:
                provenance_certainty = "confirmed_by_element_balance"
            else:
                provenance_certainty = "unverifiable_missing_product_atom_maps"
            record = {
                "dataset": dataset,
                "route_id": str(route_id),
                "reaction_step": occurrence["reaction_step"],
                "category": (
                    "product_only_non_hydrogen_atoms_without_reactant"
                    if confirmed
                    else "unmapped_product_non_hydrogen_atoms_unverifiable"
                ),
                "single_precursor_no_reagent": bool(
                    source_info["reactant_count"] == 1
                    and source_info["reagent_count"] == 0
                ),
                "reaction_record_id": metadata.get("ID", metadata.get("id", "")),
                "reactant_count": source_info["reactant_count"],
                "product_count": source_info["product_count"],
                "product_only_atom_count": product_only_count,
                "product_only_map_ids": product_only_maps,
                "product_only_formula": _element_formula(
                    (
                        source_info["product_only_atoms"]
                        if len(product_only_maps) >= element_surplus_count
                        else source_info["element_balance_surplus_atoms"]
                    )
                ),
                "element_balance_surplus_atom_count": element_surplus_count,
                "element_balance_surplus_formula": _element_formula(
                    source_info["element_balance_surplus_atoms"]
                ),
                "product_only_map_signature_mismatch_ids": source_info[
                    "product_only_map_signature_mismatch_ids"
                ],
                "provenance_certainty": provenance_certainty,
                "raw_product_unmapped_formula": _element_formula(
                    source_info["raw_product_unmapped_atoms"]
                ),
                **raw_counts,
                "raw_reaction_has_unmapped_atoms": any(raw_counts.values()),
                "target_molecule": occurrence["target_molecule"],
                "normalized_reaction_smiles": normalized_smiles,
                "raw_reaction_smiles": raw_smiles,
            }
            records.append(record)

    records.sort(
        key=lambda record: (
            _route_id_sort_key(record["route_id"]),
            record["reaction_step"],
        )
    )
    return AtomProvenanceAuditResult(
        dataset=dataset,
        routes_seen=routes_seen,
        reactions_seen=reactions_seen,
        records=tuple(records),
        parse_errors=tuple(parse_errors),
    )
