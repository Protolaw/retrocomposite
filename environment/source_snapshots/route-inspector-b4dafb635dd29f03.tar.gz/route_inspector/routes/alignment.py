"""Read-only stereo-aware witnesses for continuous route atom identities.

Chython proposes isomorphisms and verifies atom/bond states and stereo.
All comparisons are read-only; remapping uses private copies.
No minimum-number-of-remaps claim is made for a witness.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Iterable, Mapping

from route_inspector import chemistry
from route_inspector.chemistry.mapping import _state_preserving_mapping
from route_inspector.chemistry.stereo import (
    map_ordered_signature as _map_ordered_signature,
)
from route_inspector.chemistry.stereo import (
    stereo_molecule,
)
from route_inspector.routes.stereo import stereo_component_signature


@dataclass(frozen=True)
class StereoAlignment:
    mapping: chemistry.AtomMapping
    method: str
    candidates_examined: int


def _valid_state_mapping(left: Any, right: Any, mapping: Mapping[int, int]) -> bool:
    return (
        left.atoms_count == right.atoms_count
        and left.bonds_count == right.bonds_count
        and set(mapping) == set(left)
        and len(set(mapping.values())) == len(mapping)
        and set(mapping.values()) == set(right)
        and _state_preserving_mapping(left, right, dict(mapping))
    )


@lru_cache(maxsize=16384)
def mapped_stereo_signature(text: str) -> str:
    """Map-ordered native stereo identity, independent of component order.

    Parse components separately to preserve a leading chiral atom's parity.
    """
    return ".".join(
        sorted(
            _map_ordered_signature(stereo_molecule(part)) for part in text.split(".")
        )
    )


def mapped_molecules_stereo_equal(left: Any, right: Any) -> bool:
    """Compare exact persistent-map graph state and mapped stereochemistry."""
    identity = {int(atom): int(atom) for atom in left}
    if not _valid_state_mapping(left, right, identity):
        return False
    return _map_ordered_signature(left) == _map_ordered_signature(right)


def stereo_preserving_alignment(
    left: Any,
    right: Any,
    *,
    max_mappings: int = chemistry.DEFAULT_MAX_STATE_PRESERVING_MAPPINGS,
) -> StereoAlignment | None:
    """Return a fully verified stereo/state witness, not an optimal remapping.

    A non-identical unparseable stereo representation fails closed. Chython's
    unfiltered search is bounded and never accepts an unverified candidate.
    Cached molecules and the caller's containers are never modified.
    """
    if max_mappings < 1:
        raise ValueError("max_mappings must be at least 1")
    if left.atoms_count != right.atoms_count or left.bonds_count != right.bonds_count:
        return None
    if mapped_molecules_stereo_equal(left, right):
        return StereoAlignment(
            tuple((int(atom), int(atom)) for atom in sorted(left)), "identity", 0
        )

    def verified(mapping: dict[int, int]) -> bool:
        if not _valid_state_mapping(left, right, mapping):
            return False
        proposal = left.copy()
        proposal.remap(mapping)
        return mapped_molecules_stereo_equal(proposal, right)

    for count, raw in enumerate(
        left.get_mapping(right, automorphism_filter=False), start=1
    ):
        if count > max_mappings:
            raise chemistry.MoleculeAlignmentLimitError(
                f"no verified stereo/state witness within {max_mappings} graph mappings"
            )
        proposal = {int(source): int(target) for source, target in raw.items()}
        if verified(proposal):
            return StereoAlignment(
                tuple(sorted(proposal.items())), "chython_stereo_witness", count
            )
    return None


def find_stereo_matching_molecule(
    candidates: Iterable[Any],
    reference: Any | None,
    *,
    fallback_smiles: str = "",
    excluded_indexes: set[int] | None = None,
) -> tuple[int, Any] | tuple[None, None]:
    """Match components without conflating stereoisomers or multiplicity."""
    if reference is None:
        if not fallback_smiles:
            return None, None
        reference = chemistry.parse_molecule(fallback_smiles)
    excluded = excluded_indexes or set()
    for index, candidate in enumerate(candidates):
        if index in excluded:
            continue
        if not chemistry.mapped_molecules_correspond(candidate, reference):
            continue
        if str(candidate) == str(reference) or (
            stereo_component_signature(format(candidate, "m"))
            == stereo_component_signature(format(reference, "m"))
        ):
            return index, candidate
    return None, None


def mapped_component_multisets_equal(left: Iterable[Any], right: Iterable[Any]) -> bool:
    """Check one-to-one component identity, stereo and unique persistent maps."""
    left, right = tuple(left), tuple(right)
    if len(left) != len(right):
        return False

    def indexed(components: tuple[Any, ...]) -> dict[frozenset[int], Any] | None:
        result: dict[frozenset[int], Any] = {}
        seen: set[int] = set()
        for molecule in components:
            ids = frozenset(int(atom) for atom in molecule)
            if not ids or seen & ids or any(atom <= 0 for atom in ids):
                return None
            seen.update(ids)
            result[ids] = molecule
        return result

    left_index, right_index = indexed(left), indexed(right)
    if (
        left_index is None
        or right_index is None
        or left_index.keys() != right_index.keys()
    ):
        return False
    return all(
        mapped_molecules_stereo_equal(molecule, right_index[ids])
        for ids, molecule in left_index.items()
    )
