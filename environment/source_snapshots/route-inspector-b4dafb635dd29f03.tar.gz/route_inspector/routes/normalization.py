"""Continuous route atom-map normalization."""

from __future__ import annotations

import copy
from typing import Any

from route_inspector import chemistry
from route_inspector.routes.access import (
    RouteNormalizationError,
    molecule_node_smiles,
    reaction_smiles_from_node,
)


def _reaction_atom_ids(reaction: Any) -> set[int]:
    atom_ids: set[int] = set()
    for molecule in reaction.reactants + reaction.products + reaction.reagents:
        atom_ids.update(int(atom_id) for atom_id in molecule)
    return atom_ids


def _remap_molecule(molecule: Any, mapping: dict[int, int]) -> Any:
    molecule_copy = molecule.copy()
    molecule_mapping = {
        atom_id: mapping[atom_id]
        for atom_id in molecule_copy
        if atom_id in mapping and atom_id != mapping[atom_id]
    }
    if molecule_mapping:
        molecule_copy.remap(molecule_mapping)
    return molecule_copy


def _remap_reaction(reaction: Any, mapping: dict[int, int]) -> Any:
    from chython.containers import ReactionContainer

    return ReactionContainer(
        tuple(_remap_molecule(molecule, mapping) for molecule in reaction.reactants),
        tuple(_remap_molecule(molecule, mapping) for molecule in reaction.products),
        tuple(_remap_molecule(molecule, mapping) for molecule in reaction.reagents),
        meta=dict(getattr(reaction, "meta", {}) or {}),
        name=getattr(reaction, "name", None),
    )


def _set_molecule_node_mapped_smiles(node: dict[str, Any], molecule: Any) -> None:
    metadata = node.setdefault("metadata", {})
    metadata.setdefault("original_smiles", molecule_node_smiles(node))
    metadata["mapped_smiles"] = format(molecule, "m")
    node["smiles"] = metadata["mapped_smiles"]


def _anchor_route_target_map_one(route: dict[str, Any]) -> None:
    """Ensure the route target owns map 1 using one global bijective swap."""

    try:
        target = chemistry.parse_molecule(molecule_node_smiles(route))
    except Exception:
        return
    target_atom_ids = sorted(int(atom_id) for atom_id in target)
    if not target_atom_ids or 1 in target_atom_ids:
        return

    target_anchor = target_atom_ids[0]
    mapping = {1: target_anchor, target_anchor: 1}

    def remap_node(node: dict[str, Any]) -> None:
        if node.get("type") == "reaction":
            reaction = chemistry.parse_reaction(reaction_smiles_from_node(node))
            node["smiles"] = format(_remap_reaction(reaction, mapping), "m")
        elif node.get("type") == "mol":
            molecule = chemistry.parse_molecule(molecule_node_smiles(node))
            _set_molecule_node_mapped_smiles(
                node,
                _remap_molecule(molecule, mapping),
            )
            if "mapped_smiles" in node:
                node["mapped_smiles"] = node["smiles"]
        for child in node.get("children", []) or []:
            if isinstance(child, dict):
                remap_node(child)

    remap_node(route)
    route.setdefault("metadata", {})["route_map_normalization"] = {
        "method": "target_map_one_anchor",
        "swapped_ids": [1, target_anchor],
    }


def normalize_route_tree(
    route: dict[str, Any],
    *,
    anchor_target_map_one: bool = False,
    alignment_policy: str = "minimum_map_changes",
    alignment_audit: list[dict[str, Any]] | None = None,
    remove_noncontributing_reactants: bool = False,
    reactant_cleanup_audit: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Return a route copy with globally consistent atom-map identities.

    Reaction ``metadata.smiles`` remains the recorded step-local input.  The
    continuously mapped reaction is written to reaction ``smiles``.  Molecule input
    SMILES are retained in ``metadata.original_smiles`` and their normalized mapped
    representation is stored in both ``smiles`` and ``metadata.mapped_smiles``.
    When ``anchor_target_map_one`` is true, a final global swap ensures that
    the route target contains map 1 for SynPlanner RouteCGR/SB-CGR composition.
    The opt-in stereo_preserving_witness policy verifies stereo with persistent
    maps and does not require proof of a minimum number of numerical remaps.
    An optional audit receives occurrence-level records, including on failure.
    Opt-in reactant cleanup runs after alignment/anchoring and preserves the
    normalized route on cleanup failure. Its audit includes removed subtrees.
    """

    if remove_noncontributing_reactants:
        from route_inspector.routes.cleanup import verify_explicit_maps

        verify_explicit_maps(route)
    if alignment_policy not in {"minimum_map_changes", "stereo_preserving_witness"}:
        raise ValueError(f"unsupported alignment policy: {alignment_policy!r}")
    stereo_policy = alignment_policy == "stereo_preserving_witness"
    if stereo_policy:
        from route_inspector.routes.alignment import (
            find_stereo_matching_molecule,
            stereo_preserving_alignment,
        )

        find_match = find_stereo_matching_molecule
    else:
        find_match = chemistry.find_matching_molecule
    route = copy.deepcopy(route)
    if stereo_policy:
        route.setdefault("metadata", {})["route_alignment_normalization"] = {
            "policy": alignment_policy,
            "minimum_remaps_proven": False,
        }
    all_original_atom_ids: set[int] = set()

    def audit_alignment(
        node: dict[str, Any],
        path: tuple[int, ...],
        method: str,
        status: str,
        reason: str = "",
        examined: int = 0,
    ) -> None:
        if alignment_audit is not None:
            metadata = node.get("metadata") or {}
            alignment_audit.append(
                {
                    "source_row": metadata.get("source_row", ""),
                    "path_id": metadata.get("path_id", ""),
                    "step_id": metadata.get("step_id", ""),
                    "reaction_node_path": ".".join(map(str, path)),
                    "alignment_policy": alignment_policy,
                    "method": method,
                    "status": status,
                    "reason": reason,
                    "candidates_examined": examined,
                }
            )

    def collect_original_atom_ids(node: dict[str, Any]) -> None:
        if node.get("type") == "reaction":
            node["smiles"] = reaction_smiles_from_node(node)
            try:
                all_original_atom_ids.update(
                    _reaction_atom_ids(chemistry.parse_reaction(node["smiles"]))
                )
            except Exception:
                pass
        for child in node.get("children", []) or []:
            if isinstance(child, dict):
                collect_original_atom_ids(child)

    collect_original_atom_ids(route)
    used_atom_ids: set[int] = set()
    next_atom_id = max(all_original_atom_ids or {0}) + 1

    def fresh_atom_id() -> int:
        nonlocal next_atom_id
        while next_atom_id in used_atom_ids:
            next_atom_id += 1
        atom_id = next_atom_id
        used_atom_ids.add(atom_id)
        next_atom_id += 1
        return atom_id

    def complete_mapping(reaction: Any, alignment: dict[int, int]) -> dict[int, int]:
        mapping: dict[int, int] = dict(alignment)
        for target_atom_id in alignment.values():
            used_atom_ids.add(int(target_atom_id))

        for atom_id in sorted(_reaction_atom_ids(reaction)):
            if atom_id in mapping:
                continue
            if atom_id in used_atom_ids:
                mapping[atom_id] = fresh_atom_id()
            else:
                mapping[atom_id] = atom_id
                used_atom_ids.add(atom_id)
        return mapping

    def visit_molecule(
        node: dict[str, Any],
        expected_molecule: Any | None = None,
        path: tuple[int, ...] = (),
    ) -> None:
        if expected_molecule is not None:
            _set_molecule_node_mapped_smiles(node, expected_molecule)

        for child_index, child in enumerate(node.get("children", []) or []):
            if not isinstance(child, dict) or child.get("type") != "reaction":
                continue
            reaction_path = path + (child_index,)
            try:
                reaction = chemistry.parse_reaction(reaction_smiles_from_node(child))
            except Exception:
                visit_reaction_children(child, reaction_path=reaction_path)
                continue

            try:
                product_index, product = find_match(
                    reaction.products,
                    expected_molecule,
                    fallback_smiles=molecule_node_smiles(node),
                )
            except Exception as exc:
                audit_alignment(
                    child, reaction_path, "component_match", "failed", str(exc)
                )
                raise RouteNormalizationError(
                    f"product component comparison failed: {exc}",
                    reaction_node_path=reaction_path,
                ) from exc
            alignment: dict[int, int] = {}
            if product is not None:
                if expected_molecule is None:
                    alignment = {int(atom_id): int(atom_id) for atom_id in product}
                    audit_alignment(child, reaction_path, "root_identity", "valid")
                else:
                    try:
                        if stereo_policy:
                            witness = stereo_preserving_alignment(
                                product, expected_molecule
                            )
                            state_mapping = (
                                witness.mapping if witness is not None else None
                            )
                            if witness is not None:
                                audit_alignment(
                                    child,
                                    reaction_path,
                                    witness.method,
                                    "valid",
                                    examined=witness.candidates_examined,
                                )
                        else:
                            state_mapping = chemistry.state_preserving_molecule_mapping(
                                product,
                                expected_molecule,
                            )
                    except chemistry.MoleculeAlignmentLimitError as exc:
                        audit_alignment(
                            child, reaction_path, "search_limit", "failed", str(exc)
                        )
                        raise RouteNormalizationError(
                            "could not exhaustively preserve the source "
                            "product-to-target match at path "
                            f"{path}: {exc}",
                            reaction_node_path=reaction_path,
                        ) from exc
                    except Exception as exc:
                        audit_alignment(
                            child,
                            reaction_path,
                            "stereo_comparison",
                            "failed",
                            str(exc),
                        )
                        raise RouteNormalizationError(
                            f"stereo/state alignment failed: {exc}",
                            reaction_node_path=reaction_path,
                        ) from exc
                    if state_mapping is None:
                        audit_alignment(
                            child,
                            reaction_path,
                            "no_alignment",
                            "failed",
                            "no state/stereo-preserving graph alignment exists",
                        )
                        raise RouteNormalizationError(
                            "could not preserve the source product-to-target "
                            f"match at path {path}: no state-preserving graph "
                            "alignment exists",
                            reaction_node_path=reaction_path,
                        )
                    alignment = dict(state_mapping)
                mapping = complete_mapping(reaction, alignment)
                normalized_reaction = _remap_reaction(reaction, mapping)
                child["smiles"] = format(normalized_reaction, "m")
                if product_index is not None:
                    normalized_products = list(normalized_reaction.products)
                    if product_index < len(normalized_products):
                        _set_molecule_node_mapped_smiles(
                            node,
                            normalized_products[product_index],
                        )
                visit_reaction_children(
                    child,
                    normalized_reaction,
                    reaction_path=reaction_path,
                )
            else:
                if stereo_policy:
                    audit_alignment(
                        child,
                        reaction_path,
                        "product_component_match",
                        "failed",
                        "no stereo-equivalent product component",
                    )
                    raise RouteNormalizationError(
                        "no stereo-equivalent product component",
                        reaction_node_path=reaction_path,
                    )
                mapping = complete_mapping(reaction, {})
                normalized_reaction = _remap_reaction(reaction, mapping)
                child["smiles"] = format(normalized_reaction, "m")
                visit_reaction_children(
                    child,
                    normalized_reaction,
                    reaction_path=reaction_path,
                )

    def visit_reaction_children(
        reaction_node: dict[str, Any],
        reaction: Any | None = None,
        reaction_path: tuple[int, ...] = (),
    ) -> None:
        if reaction is None:
            try:
                reaction = chemistry.parse_reaction(
                    reaction_smiles_from_node(reaction_node)
                )
            except Exception:
                for child_index, child in enumerate(
                    reaction_node.get("children", []) or []
                ):
                    if isinstance(child, dict) and child.get("type") == "mol":
                        visit_molecule(
                            child,
                            path=reaction_path + (child_index,),
                        )
                return

        used_reactant_indexes: set[int] = set()
        reactants = list(reaction.reactants)
        for child_index, child in enumerate(reaction_node.get("children", []) or []):
            if not isinstance(child, dict) or child.get("type") != "mol":
                continue
            try:
                reactant_index, reactant = find_match(
                    reactants,
                    None,
                    fallback_smiles=molecule_node_smiles(child),
                    excluded_indexes=used_reactant_indexes,
                )
                if stereo_policy and reactant is None:
                    raise ValueError(
                        f"no stereo-equivalent reactant for child {child_index}"
                    )
            except Exception as exc:
                audit_alignment(
                    reaction_node,
                    reaction_path,
                    "reactant_component_match",
                    "failed",
                    str(exc),
                )
                raise RouteNormalizationError(
                    f"reactant component comparison failed: {exc}",
                    reaction_node_path=reaction_path,
                ) from exc
            if reactant_index is not None:
                used_reactant_indexes.add(reactant_index)
            visit_molecule(
                child,
                reactant,
                reaction_path + (child_index,),
            )

    visit_molecule(route)
    if anchor_target_map_one:
        _anchor_route_target_map_one(route)
    if remove_noncontributing_reactants:
        from route_inspector.routes.cleanup import cleanup_route_reactants

        route = cleanup_route_reactants(
            route,
            audit=reactant_cleanup_audit,
            allow_stereo_only_reactions=stereo_policy,
        )
    return route


def normalized_route_for_analysis(route: dict[str, Any]) -> dict[str, Any]:
    """Reuse a route marked by preprocessing, otherwise normalize a fresh copy."""

    metadata = route.get("metadata") or {}
    if isinstance(metadata.get("route_preprocessing"), dict):
        return route
    return normalize_route_tree(route)


__all__ = ["normalize_route_tree", "normalized_route_for_analysis"]
