"""Serializable records for RRSeq-free counterfactual reassembly."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Mapping

C3_SCHEMA_VERSION = 1
C3Status = Literal[
    "commutable_unique",
    "commutable_ambiguous",
    "noncommutable",
    "unresolved",
]
_C3_STATUSES = frozenset(
    {
        "commutable_unique",
        "commutable_ambiguous",
        "noncommutable",
        "unresolved",
    }
)


def _path(value: Any, *, field_name: str) -> tuple[int, ...]:
    try:
        path = tuple(int(index) for index in value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be an integer node path") from exc
    if any(index < 0 for index in path):
        raise ValueError(f"{field_name} cannot contain negative indices")
    return path


@dataclass(frozen=True, slots=True)
class C3ReplayLimits:
    """Enumeration bounds for one reversed adjacent-rule replay."""

    max_replay_outcomes: int = 256
    max_counterfactuals_per_pair: int = 256
    pair_timeout_seconds: float | None = 300.0

    def __post_init__(self) -> None:
        if int(self.max_replay_outcomes) < 1:
            raise ValueError("max_replay_outcomes must be at least 1")
        if int(self.max_counterfactuals_per_pair) < 1:
            raise ValueError("max_counterfactuals_per_pair must be at least 1")
        object.__setattr__(self, "max_replay_outcomes", int(self.max_replay_outcomes))
        object.__setattr__(
            self,
            "max_counterfactuals_per_pair",
            int(self.max_counterfactuals_per_pair),
        )
        if self.pair_timeout_seconds is not None:
            timeout = float(self.pair_timeout_seconds)
            if timeout <= 0:
                raise ValueError("pair_timeout_seconds must be positive or None")
            object.__setattr__(self, "pair_timeout_seconds", timeout)

    def to_dict(self) -> dict[str, int | float | None]:
        return {
            "max_replay_outcomes": self.max_replay_outcomes,
            "max_counterfactuals_per_pair": self.max_counterfactuals_per_pair,
            "pair_timeout_seconds": self.pair_timeout_seconds,
        }


@dataclass(frozen=True)
class AdjacentPairAssessment:
    """Complete scientific result for one topology-adjacent rule pair."""

    source_route_id: str
    pair_identity: str
    reference_bigram_occurrence_id: str
    first_reaction_path: tuple[int, ...]
    second_reaction_path: tuple[int, ...]
    status: C3Status
    replay_outcome_count: int
    matching_boundary_count: int
    unique_counterfactual_count: int
    original_intermediate: str
    counterfactual_intermediates: tuple[str, ...]
    boundary_precursors: tuple[str, ...]
    original_bigram_occurrence: Mapping[str, Any]
    counterfactual_bigram_occurrences: tuple[Mapping[str, Any], ...] = ()
    counterfactual_ids: tuple[str, ...] = ()
    r1_center_maps: tuple[int, ...] = ()
    r2_center_maps: tuple[int, ...] = ()
    center_overlap: tuple[int, ...] = ()
    minimum_center_graph_distance: int | None = None
    original_route_cgr_fingerprint: Mapping[str, Any] | None = None
    counterfactual_route_cgr_fingerprints: tuple[Mapping[str, Any], ...] = ()
    route_cgr_hashes: tuple[str, ...] = ()
    reaction_classes: Mapping[str, Any] = field(default_factory=dict)
    truncated: bool = False
    error_type: str | None = None
    error_message: str | None = None
    schema_version: int = C3_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if int(self.schema_version) != C3_SCHEMA_VERSION:
            raise ValueError("unsupported adjacent-pair assessment schema version")
        for name in (
            "source_route_id",
            "pair_identity",
            "reference_bigram_occurrence_id",
        ):
            value = str(getattr(self, name))
            if not value:
                raise ValueError(f"AdjacentPairAssessment requires {name}")
            object.__setattr__(self, name, value)
        if self.status not in _C3_STATUSES:
            raise ValueError(f"unsupported C3 status: {self.status!r}")
        object.__setattr__(
            self,
            "first_reaction_path",
            _path(self.first_reaction_path, field_name="first_reaction_path"),
        )
        object.__setattr__(
            self,
            "second_reaction_path",
            _path(self.second_reaction_path, field_name="second_reaction_path"),
        )
        if not self.first_reaction_path or not self.second_reaction_path:
            raise ValueError("C3 reaction paths cannot be empty")
        for name in (
            "replay_outcome_count",
            "matching_boundary_count",
            "unique_counterfactual_count",
        ):
            value = int(getattr(self, name))
            if value < 0:
                raise ValueError(f"{name} cannot be negative")
            object.__setattr__(self, name, value)
        object.__setattr__(
            self,
            "counterfactual_intermediates",
            tuple(str(value) for value in self.counterfactual_intermediates),
        )
        object.__setattr__(
            self,
            "boundary_precursors",
            tuple(str(value) for value in self.boundary_precursors),
        )
        object.__setattr__(
            self,
            "counterfactual_ids",
            tuple(str(value) for value in self.counterfactual_ids),
        )
        for name in ("r1_center_maps", "r2_center_maps", "center_overlap"):
            object.__setattr__(
                self,
                name,
                tuple(sorted({int(value) for value in getattr(self, name)})),
            )
        distance = self.minimum_center_graph_distance
        if distance is not None and int(distance) < 0:
            raise ValueError("minimum_center_graph_distance cannot be negative")
        if distance is not None:
            object.__setattr__(self, "minimum_center_graph_distance", int(distance))
        if self.status == "commutable_unique" and self.unique_counterfactual_count != 1:
            raise ValueError("commutable_unique requires exactly one counterfactual")
        if (
            self.status == "commutable_ambiguous"
            and self.unique_counterfactual_count < 2
        ):
            raise ValueError("commutable_ambiguous requires multiple counterfactuals")
        if self.status == "noncommutable" and self.unique_counterfactual_count:
            raise ValueError("noncommutable cannot contain a certified counterfactual")
        if self.truncated and self.status != "unresolved":
            raise ValueError("truncated C3 replay must be unresolved")

    @property
    def resolved(self) -> bool:
        return self.status != "unresolved"

    @property
    def commutable(self) -> bool:
        return self.status in {"commutable_unique", "commutable_ambiguous"}

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "experiment": "C3",
            "source_route_id": self.source_route_id,
            "pair_identity": self.pair_identity,
            "reference_bigram_occurrence_id": self.reference_bigram_occurrence_id,
            "first_reaction_path": list(self.first_reaction_path),
            "second_reaction_path": list(self.second_reaction_path),
            "status": self.status,
            "resolved": self.resolved,
            "commutable": self.commutable,
            "replay_outcome_count": self.replay_outcome_count,
            "matching_boundary_count": self.matching_boundary_count,
            "unique_counterfactual_count": self.unique_counterfactual_count,
            "original_intermediate": self.original_intermediate,
            "counterfactual_intermediates": list(self.counterfactual_intermediates),
            "boundary_precursors": list(self.boundary_precursors),
            "original_bigram_occurrence": dict(self.original_bigram_occurrence),
            "counterfactual_bigram_occurrences": [
                dict(value) for value in self.counterfactual_bigram_occurrences
            ],
            "counterfactual_ids": list(self.counterfactual_ids),
            "reaction_center_relationship": {
                "r1_center_maps": list(self.r1_center_maps),
                "r2_center_maps": list(self.r2_center_maps),
                "center_overlap": list(self.center_overlap),
                "minimum_center_graph_distance": self.minimum_center_graph_distance,
            },
            "route_cgr_certification": {
                "original_fingerprint": (
                    None
                    if self.original_route_cgr_fingerprint is None
                    else dict(self.original_route_cgr_fingerprint)
                ),
                "counterfactual_fingerprints": [
                    dict(value) for value in self.counterfactual_route_cgr_fingerprints
                ],
                "diagnostic_hashes": list(self.route_cgr_hashes),
                "comparison": "complete_order_agnostic_fingerprint_equality",
                "preserve_transient_bonds": True,
            },
            "reaction_classes": dict(self.reaction_classes),
            "truncated": self.truncated,
            "error_type": self.error_type,
            "error_message": self.error_message,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "AdjacentPairAssessment":
        centers = value.get("reaction_center_relationship") or {}
        certification = value.get("route_cgr_certification") or {}
        result = cls(
            schema_version=int(value.get("schema_version", -1)),
            source_route_id=str(value["source_route_id"]),
            pair_identity=str(value["pair_identity"]),
            reference_bigram_occurrence_id=str(value["reference_bigram_occurrence_id"]),
            first_reaction_path=_path(
                value["first_reaction_path"], field_name="first_reaction_path"
            ),
            second_reaction_path=_path(
                value["second_reaction_path"], field_name="second_reaction_path"
            ),
            status=str(value["status"]),
            replay_outcome_count=int(value["replay_outcome_count"]),
            matching_boundary_count=int(value["matching_boundary_count"]),
            unique_counterfactual_count=int(value["unique_counterfactual_count"]),
            original_intermediate=str(value.get("original_intermediate") or ""),
            counterfactual_intermediates=tuple(
                str(item) for item in value.get("counterfactual_intermediates", ())
            ),
            boundary_precursors=tuple(
                str(item) for item in value.get("boundary_precursors", ())
            ),
            original_bigram_occurrence=dict(
                value.get("original_bigram_occurrence") or {}
            ),
            counterfactual_bigram_occurrences=tuple(
                dict(item)
                for item in value.get("counterfactual_bigram_occurrences", ())
            ),
            counterfactual_ids=tuple(
                str(item) for item in value.get("counterfactual_ids", ())
            ),
            r1_center_maps=tuple(
                int(item) for item in centers.get("r1_center_maps", ())
            ),
            r2_center_maps=tuple(
                int(item) for item in centers.get("r2_center_maps", ())
            ),
            center_overlap=tuple(
                int(item) for item in centers.get("center_overlap", ())
            ),
            minimum_center_graph_distance=centers.get("minimum_center_graph_distance"),
            original_route_cgr_fingerprint=(
                None
                if certification.get("original_fingerprint") is None
                else dict(certification["original_fingerprint"])
            ),
            counterfactual_route_cgr_fingerprints=tuple(
                dict(item)
                for item in certification.get("counterfactual_fingerprints", ())
            ),
            route_cgr_hashes=tuple(
                str(item) for item in certification.get("diagnostic_hashes", ())
            ),
            reaction_classes=dict(value.get("reaction_classes") or {}),
            truncated=bool(value.get("truncated", False)),
            error_type=(
                None if value.get("error_type") is None else str(value["error_type"])
            ),
            error_message=(
                None
                if value.get("error_message") is None
                else str(value["error_message"])
            ),
        )
        for field_name in ("resolved", "commutable"):
            if field_name in value and bool(value[field_name]) != bool(
                getattr(result, field_name)
            ):
                raise ValueError(f"serialized {field_name} is inconsistent")
        return result


@dataclass(frozen=True)
class C3PublicationResult:
    """Result returned after atomic C3 artifact publication."""

    output_path: Path
    manifest: Mapping[str, Any]
    statistics: Mapping[str, Any]
    phase_timings: Mapping[str, float]


__all__ = [
    "AdjacentPairAssessment",
    "C3PublicationResult",
    "C3ReplayLimits",
    "C3Status",
    "C3_SCHEMA_VERSION",
]
