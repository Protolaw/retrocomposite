"""Chemistry and route reconstruction for C3 counterfactual reassembly."""

from __future__ import annotations

import copy
import hashlib
import signal
from collections import deque
from dataclasses import dataclass, replace
from typing import Any, Mapping, Sequence

from route_inspector import chemistry
from route_inspector.composite_rules.validation import compare_precursor_multisets
from route_inspector.metrics.retro_bleu.bigrams import (
    RetroBleuBigramOccurrence,
    RetroBleuBigramStep,
)
from route_inspector.reference_library.bigram_catalog import (
    ReferenceBigramOccurrence,
)
from route_inspector.reference_library.profile import canonical_json
from route_inspector.routes.access import (
    molecule_node_mapped_smiles,
    molecule_node_smiles,
    reaction_smiles_from_node,
)
from route_inspector.routes.counterfactuals.models import (
    AdjacentPairAssessment,
    C3ReplayLimits,
)
from route_inspector.routes.normalization import normalize_route_tree
from route_inspector.routes.validation import validate_routes_mapping
from route_inspector.tactics.rrseq.unwrap import ChythonOneShotTraceAdapter


@dataclass(frozen=True)
class _Segment:
    target_node: Mapping[str, Any]
    parent_reaction: Mapping[str, Any]
    intermediate_node: Mapping[str, Any]
    child_reaction: Mapping[str, Any]
    boundary_nodes: tuple[Mapping[str, Any], ...]


@dataclass(frozen=True)
class _LocalRealization:
    first_outcome: Any
    second_outcome: Any
    expanded_component_index: int
    terminal_molecules: tuple[Any, ...]
    first_forward_reaction: Any
    second_forward_reaction: Any
    fingerprint: str
    route_cgr_fingerprint: Mapping[str, Any]
    route_cgr_hash: str


@dataclass(frozen=True)
class _ValidatedCounterfactual:
    counterfactual_id: str
    route: Mapping[str, Any]
    bigram_occurrence: Mapping[str, Any]
    intermediate_smiles: str
    realization_fingerprint: str
    route_cgr_fingerprint: Mapping[str, Any]
    route_cgr_hash: str


@dataclass(frozen=True)
class _PairReplayResult:
    assessment: AdjacentPairAssessment
    counterfactuals: tuple[_ValidatedCounterfactual, ...]


def _node_at_path(root: Mapping[str, Any], path: Sequence[int]) -> Mapping[str, Any]:
    node: Mapping[str, Any] = root
    for index in path:
        children = node.get("children") or ()
        try:
            child = children[int(index)]
        except (IndexError, TypeError) as exc:
            raise ValueError(f"route node path does not exist: {list(path)}") from exc
        if not isinstance(child, Mapping):
            raise ValueError(f"route node path reaches a non-object: {list(path)}")
        node = child
    return node


def _molecule_smiles(node: Mapping[str, Any]) -> str:
    value = molecule_node_mapped_smiles(dict(node)) or molecule_node_smiles(dict(node))
    if not value:
        raise ValueError("route molecule node has no SMILES")
    return value


def _molecule_children(node: Mapping[str, Any]) -> tuple[Mapping[str, Any], ...]:
    children = tuple(node.get("children") or ())
    if any(not isinstance(child, Mapping) for child in children):
        raise ValueError("route children must be JSON objects")
    selected = tuple(child for child in children if child.get("type") == "mol")
    if len(selected) != len(children):
        raise ValueError("reaction children must all be molecule nodes")
    return selected


def _reaction_children(node: Mapping[str, Any]) -> tuple[Mapping[str, Any], ...]:
    children = tuple(node.get("children") or ())
    if any(not isinstance(child, Mapping) for child in children):
        raise ValueError("route children must be JSON objects")
    selected = tuple(child for child in children if child.get("type") == "reaction")
    if len(selected) != len(children):
        raise ValueError("molecule children must all be reaction nodes")
    return selected


def _resolve_segment(
    route: Mapping[str, Any],
    occurrence: ReferenceBigramOccurrence,
) -> _Segment:
    native = occurrence.occurrence
    parent_path, child_path = native.reaction_node_paths
    if len(child_path) != len(parent_path) + 2 or child_path[: len(parent_path)] != (
        parent_path
    ):
        raise ValueError("bigram paths are not an immediate parent-to-child pair")
    precursor_index = child_path[len(parent_path)]
    child_reaction_index = child_path[-1]
    target_path = parent_path[:-1]
    if native.steps[0].target_molecule_path != target_path:
        raise ValueError("parent target path disagrees with bigram provenance")
    intermediate_path = parent_path + (precursor_index,)
    if native.steps[1].target_molecule_path != intermediate_path:
        raise ValueError("child target path disagrees with bigram provenance")

    target_node = _node_at_path(route, target_path)
    parent_reaction = _node_at_path(route, parent_path)
    intermediate_node = _node_at_path(route, intermediate_path)
    child_reaction = _node_at_path(route, child_path)
    if target_node.get("type") != "mol" or intermediate_node.get("type") != "mol":
        raise ValueError("bigram targets must be molecule nodes")
    if parent_reaction.get("type") != "reaction":
        raise ValueError("first bigram path is not a reaction node")
    if child_reaction.get("type") != "reaction":
        raise ValueError("second bigram path is not a reaction node")
    for step, reaction_node in zip(native.steps, (parent_reaction, child_reaction)):
        try:
            recorded = chemistry.parse_reaction(step.reaction_smiles)
            routed = chemistry.parse_reaction(
                reaction_smiles_from_node(dict(reaction_node))
            )
        except Exception as exc:
            raise ValueError(
                "could not validate persisted bigram reaction provenance"
            ) from exc
        if not chemistry.exact_mapped_reactions_correspond(recorded, routed):
            raise ValueError(
                "persisted bigram reaction does not match its exact route path"
            )
    parent_reactions = _reaction_children(target_node)
    if parent_path[-1] >= len(target_node.get("children") or ()):
        raise ValueError("parent reaction index is outside its target children")
    if sum(child is parent_reaction for child in parent_reactions) != 1:
        raise ValueError("parent target does not uniquely own the selected reaction")
    intermediate_reactions = _reaction_children(intermediate_node)
    if (
        child_reaction_index >= len(intermediate_node.get("children") or ())
        or sum(child is child_reaction for child in intermediate_reactions) != 1
    ):
        raise ValueError(
            "intermediate does not uniquely own the selected child reaction"
        )
    if len(intermediate_reactions) != 1:
        raise ValueError(
            "C3 does not reconstruct molecule nodes with alternative reaction children"
        )

    parent_precursors = _molecule_children(parent_reaction)
    if precursor_index >= len(parent_precursors):
        raise ValueError("child reaction precursor index is outside parent precursors")
    if parent_precursors[precursor_index] is not intermediate_node:
        raise ValueError("child reaction is not below the indexed parent precursor")
    boundary = tuple(_molecule_children(child_reaction)) + tuple(
        node for index, node in enumerate(parent_precursors) if index != precursor_index
    )
    if not boundary:
        raise ValueError("adjacent pair has an empty precursor frontier")
    return _Segment(
        target_node=target_node,
        parent_reaction=parent_reaction,
        intermediate_node=intermediate_node,
        child_reaction=child_reaction,
        boundary_nodes=boundary,
    )


def _canonical_molecule(molecule: Any) -> str:
    value = molecule.copy()
    try:
        value.clean_stereo()
    except Exception:
        pass
    return chemistry.canonical_molecule_string(value)


def _canonical_multiset(molecules: Sequence[Any]) -> tuple[str, ...]:
    return tuple(sorted(_canonical_molecule(molecule) for molecule in molecules))


def _invalid_valence_atom_maps(molecules: Sequence[Any]) -> tuple[int, ...]:
    """Return mapped atoms with invalid valence in generated molecules."""

    invalid: set[int] = set()
    for molecule in molecules:
        invalid.update(int(atom_map) for atom_map in molecule.check_valence())
    return tuple(sorted(invalid))


def _forward_reaction(outcome: Any) -> Any:
    from chython.containers import ReactionContainer

    return ReactionContainer(
        reactants=tuple(molecule.copy() for molecule in outcome.products),
        products=(outcome.reaction.reactants[0].copy(),),
    )


def _compose_local_route_cgr(reactions: Sequence[Any]) -> tuple[Mapping[str, Any], str]:
    from synplan.chem.reaction.routes.representation import (
        route_cgr_fingerprint_without_route_order,
    )

    from route_inspector.routes.synplanner import compose_route_cgr

    result = compose_route_cgr(
        {0: {index: reaction for index, reaction in enumerate(reactions)}},
        0,
        preserve_transient_bonds=True,
    )
    if not result or result.get("cgr") is None:
        raise ValueError("two-step RouteCGR composition did not produce a graph")
    fingerprint = route_cgr_fingerprint_without_route_order(result["cgr"])
    digest = hashlib.sha256(canonical_json(fingerprint).encode("utf-8")).hexdigest()
    return fingerprint, digest


def _original_route_cgr(
    occurrence: ReferenceBigramOccurrence,
) -> tuple[Mapping[str, Any], str]:
    from chython import smiles

    parent, child = occurrence.occurrence.steps
    # Synthetic chronology runs from the child precursor step to the parent step.
    return _compose_local_route_cgr(
        (smiles(child.reaction_smiles), smiles(parent.reaction_smiles))
    )


def _pair_identity(
    occurrence: ReferenceBigramOccurrence,
    *,
    source_library_id: str,
) -> str:
    native = occurrence.occurrence
    payload = {
        "experiment": "C3",
        "source_library_id": str(source_library_id),
        "source_identity": native.source_identity,
        "route_id": native.route_id,
        "reaction_node_paths": [list(path) for path in native.reaction_node_paths],
        "query_cgr_keys": [step.query_cgr_key for step in native.steps],
    }
    return (
        "c3_pair_" + hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
    )


def _realization_fingerprint(
    *,
    expanded_component_index: int,
    intermediate: Any,
    first_forward: Any,
    second_forward: Any,
    terminal: Sequence[Any],
) -> str:
    payload = {
        "expanded_component_index": int(expanded_component_index),
        "intermediate": _canonical_molecule(intermediate),
        "first_forward_reaction": str(first_forward),
        "second_forward_reaction": str(second_forward),
        "terminal_precursors": list(_canonical_multiset(terminal)),
    }
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def _counterfactual_id(
    occurrence: ReferenceBigramOccurrence,
    realization_fingerprint: str,
) -> str:
    native = occurrence.occurrence
    payload = {
        "experiment": "C3",
        "source_identity": native.source_identity,
        "route_id": native.route_id,
        "reaction_node_paths": [list(path) for path in native.reaction_node_paths],
        "query_cgr_keys": [step.query_cgr_key for step in native.steps],
        "realization_fingerprint": realization_fingerprint,
    }
    return (
        "c3_counterfactual_"
        + hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
    )


def _minimum_center_distance(
    intermediate: Any,
    first_centers: Sequence[int],
    second_centers: Sequence[int],
) -> int | None:
    atom_ids = {int(atom_id) for atom_id, _atom in intermediate.atoms()}
    left = {int(value) for value in first_centers if int(value) in atom_ids}
    right = {int(value) for value in second_centers if int(value) in atom_ids}
    if not left or not right:
        return None
    if left & right:
        return 0
    adjacency = {atom_id: set() for atom_id in atom_ids}
    for atom_a, atom_b, _bond in intermediate.bonds():
        adjacency[int(atom_a)].add(int(atom_b))
        adjacency[int(atom_b)].add(int(atom_a))

    queue = deque((atom, 0) for atom in sorted(left))
    visited = set(left)
    while queue:
        atom, distance = queue.popleft()
        for neighbor in sorted(adjacency[atom]):
            if neighbor in visited:
                continue
            if neighbor in right:
                return distance + 1
            visited.add(neighbor)
            queue.append((neighbor, distance + 1))
    return None


def _unique_boundary_assignment(
    boundary_nodes: Sequence[Mapping[str, Any]],
    generated: Sequence[Any],
    *,
    lineage_atom_ids: set[int],
) -> tuple[int, ...]:
    if len(boundary_nodes) != len(generated):
        raise ValueError("generated and recorded boundary sizes differ")
    expected = [
        chemistry.parse_molecule(_molecule_smiles(node)) for node in boundary_nodes
    ]
    candidates: list[list[int]] = []
    for molecule in expected:
        row = []
        for index, product in enumerate(generated):
            comparison = compare_precursor_multisets(
                (molecule,),
                (product,),
                lineage_atom_ids=lineage_atom_ids,
            )
            if comparison.chemistry_equivalent and comparison.mapping_consistent:
                row.append(index)
        candidates.append(row)
    if any(not row for row in candidates):
        raise ValueError("recorded boundary has no lineage-consistent assignment")

    assignments: list[tuple[int, ...]] = []

    def visit(position: int, used: set[int], selected: list[int]) -> None:
        if len(assignments) > 1:
            return
        if position == len(candidates):
            assignments.append(tuple(selected))
            return
        for generated_index in candidates[position]:
            if generated_index in used:
                continue
            used.add(generated_index)
            selected.append(generated_index)
            visit(position + 1, used, selected)
            selected.pop()
            used.remove(generated_index)

    visit(0, set(), [])
    if not assignments:
        raise ValueError("recorded boundary has no complete assignment")
    if len(assignments) != 1:
        raise ValueError("recorded boundary reattachment is ambiguous")
    return assignments[0]


def _reaction_metadata(
    *,
    occurrence: ReferenceBigramOccurrence,
    counterfactual_id: str,
    source_rule_position: int,
    original_path: Sequence[int],
    realization_fingerprint: str,
) -> dict[str, Any]:
    return {
        "counterfactual_reassembly": {
            "experiment": "C3",
            "counterfactual_id": counterfactual_id,
            "source_route_id": occurrence.route.route_id,
            "source_reference_bigram_occurrence_id": (
                occurrence.reference_occurrence_id
            ),
            "source_rule_position": int(source_rule_position),
            "original_reaction_path": list(original_path),
            "realization_fingerprint": realization_fingerprint,
        }
    }


def _generated_molecule_node(molecule: Any) -> dict[str, Any]:
    return {
        "type": "mol",
        "smiles": format(molecule, "m"),
        "mapped_smiles": format(molecule, "m"),
        "in_stock": False,
    }


def _build_complete_route(
    source_route: Mapping[str, Any],
    occurrence: ReferenceBigramOccurrence,
    segment: _Segment,
    realization: _LocalRealization,
    *,
    counterfactual_id: str,
    source_library_id: str,
    rule_extractor: Any,
) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    native = occurrence.occurrence
    parent_path, _child_path = native.reaction_node_paths
    target_path = parent_path[:-1]
    target_molecule = chemistry.parse_molecule(_molecule_smiles(segment.target_node))
    assignment = _unique_boundary_assignment(
        segment.boundary_nodes,
        realization.terminal_molecules,
        lineage_atom_ids={int(atom) for atom in target_molecule},
    )

    first_products = list(realization.first_outcome.products)
    second_products = list(realization.second_outcome.products)
    invalid_valence = _invalid_valence_atom_maps(first_products + second_products)
    if invalid_valence:
        raise ValueError(
            "generated counterfactual molecule has invalid valence at atom maps "
            f"{list(invalid_valence)}"
        )
    first_children = [_generated_molecule_node(product) for product in first_products]
    expanded_index = realization.expanded_component_index
    second_children = [_generated_molecule_node(product) for product in second_products]
    first_children[expanded_index]["children"] = [
        {
            "type": "reaction",
            "smiles": format(realization.first_forward_reaction, "m"),
            "metadata": {
                "smiles": format(realization.first_forward_reaction, "m"),
                **_reaction_metadata(
                    occurrence=occurrence,
                    counterfactual_id=counterfactual_id,
                    source_rule_position=1,
                    original_path=native.reaction_node_paths[0],
                    realization_fingerprint=realization.fingerprint,
                ),
            },
            "children": second_children,
        }
    ]
    first_reaction = {
        "type": "reaction",
        "smiles": format(realization.second_forward_reaction, "m"),
        "metadata": {
            "smiles": format(realization.second_forward_reaction, "m"),
            **_reaction_metadata(
                occurrence=occurrence,
                counterfactual_id=counterfactual_id,
                source_rule_position=2,
                original_path=native.reaction_node_paths[1],
                realization_fingerprint=realization.fingerprint,
            ),
        },
        "children": first_children,
    }

    terminal_nodes = second_children + [
        node for index, node in enumerate(first_children) if index != expanded_index
    ]
    terminal_molecules = second_products + [
        product
        for index, product in enumerate(first_products)
        if index != expanded_index
    ]
    if tuple(terminal_molecules) != realization.terminal_molecules:
        raise RuntimeError("generated route frontier ordering is inconsistent")
    for boundary_index, generated_index in enumerate(assignment):
        terminal_nodes[generated_index].clear()
        terminal_nodes[generated_index].update(
            copy.deepcopy(dict(segment.boundary_nodes[boundary_index]))
        )

    alternative = copy.deepcopy(dict(source_route))
    target_copy = _node_at_path(alternative, target_path)
    if not isinstance(target_copy, dict):
        raise ValueError("counterfactual target node is not mutable")
    children = list(target_copy.get("children") or ())
    children[parent_path[-1]] = first_reaction
    target_copy["children"] = children
    root_metadata = alternative.setdefault("metadata", {})
    root_metadata["counterfactual_reassembly"] = {
        "experiment": "C3",
        "counterfactual_id": counterfactual_id,
        "source_route_id": native.route_id,
        "source_identity": native.source_identity,
        "source_pair_identity": _pair_identity(
            occurrence, source_library_id=source_library_id
        ),
        "source_reference_bigram_occurrence_id": occurrence.reference_occurrence_id,
        "original_intermediate": _molecule_smiles(segment.intermediate_node),
        "counterfactual_intermediate": format(
            realization.first_outcome.products[expanded_index], "m"
        ),
        "realization_fingerprint": realization.fingerprint,
    }

    normalized = normalize_route_tree(alternative)
    validation = validate_routes_mapping(
        {counterfactual_id: normalized},
        dataset=f"{native.dataset_id}-C3",
    )
    if validation.records or validation.passed_route_ids != (counterfactual_id,):
        first = validation.records[0] if validation.records else {}
        raise ValueError(
            "complete counterfactual route failed mapping/RouteCGR validation: "
            f"{first.get('stage', 'unknown')} {first.get('message', '')}".strip()
        )

    generated_parent_path = parent_path
    generated_child_path = parent_path + (expanded_index, 0)
    generated_parent = _node_at_path(normalized, generated_parent_path)
    generated_child = _node_at_path(normalized, generated_child_path)
    extracted_first, _ = rule_extractor.extract(
        str(generated_parent.get("smiles") or "")
    )
    extracted_second, _ = rule_extractor.extract(
        str(generated_child.get("smiles") or "")
    )
    if extracted_first is None or extracted_second is None:
        raise ValueError("generated step rule extraction returned no rule")

    generated_target = _node_at_path(normalized, target_path)
    generated_intermediate = _node_at_path(normalized, parent_path + (expanded_index,))
    swapped_steps = (
        RetroBleuBigramStep(
            rule_smarts=native.steps[1].rule_smarts,
            reaction_smiles=str(generated_parent["smiles"]),
            reaction_node_path=generated_parent_path,
            target_molecule_path=target_path,
            target_smiles=_molecule_smiles(generated_target),
            center_atom_maps=native.steps[1].center_atom_maps,
            query_cgr_key=native.steps[1].query_cgr_key,
        ),
        RetroBleuBigramStep(
            rule_smarts=native.steps[0].rule_smarts,
            reaction_smiles=str(generated_child["smiles"]),
            reaction_node_path=generated_child_path,
            target_molecule_path=parent_path + (expanded_index,),
            target_smiles=_molecule_smiles(generated_intermediate),
            center_atom_maps=native.steps[0].center_atom_maps,
            query_cgr_key=native.steps[0].query_cgr_key,
        ),
    )
    occurrence_digest = hashlib.sha256(
        canonical_json(
            {
                "counterfactual_id": counterfactual_id,
                "reaction_node_paths": [
                    list(generated_parent_path),
                    list(generated_child_path),
                ],
            }
        ).encode("utf-8")
    ).hexdigest()
    counter_bigram = RetroBleuBigramOccurrence(
        occurrence_id=f"retro_bleu_bigram_o_{occurrence_digest[:24]}",
        dataset_id=f"{native.dataset_id}-C3",
        source_identity=f"counterfactual:{counterfactual_id}",
        route_id=counterfactual_id,
        route_target_smiles=_molecule_smiles(normalized),
        segment_target_smiles=_molecule_smiles(generated_target),
        steps=swapped_steps,
    )
    return normalized, counter_bigram.to_dict()


def _enumerate_local_realizations(
    occurrence: ReferenceBigramOccurrence,
    segment: _Segment,
    *,
    limits: C3ReplayLimits,
    adapter: ChythonOneShotTraceAdapter,
) -> tuple[
    tuple[_LocalRealization, ...],
    int,
    int,
    bool,
    Mapping[str, Any],
    str,
    Exception | None,
]:
    from chython.reactor import Reactor

    native = occurrence.occurrence
    target = chemistry.parse_molecule(_molecule_smiles(segment.target_node))
    boundary = tuple(
        chemistry.parse_molecule(_molecule_smiles(node))
        for node in segment.boundary_nodes
    )
    child_reactor = Reactor.from_smarts(
        native.steps[1].rule_smarts,
        delete_atoms=True,
        one_shot=True,
        automorphism_filter=True,
    )
    parent_reactor = Reactor.from_smarts(
        native.steps[0].rule_smarts,
        delete_atoms=True,
        one_shot=True,
        automorphism_filter=True,
    )
    first_enumeration = adapter.enumerate(
        child_reactor,
        target,
        max_unique_outcomes=limits.max_replay_outcomes,
    )
    first_by_multiset: dict[tuple[str, ...], Any] = {}
    for outcome in first_enumeration.outcomes:
        first_by_multiset.setdefault(_canonical_multiset(outcome.products), outcome)
    replay_outcome_count = len(first_by_multiset)
    truncated = first_enumeration.truncated
    original_fingerprint, original_hash = _original_route_cgr(occurrence)
    matching_boundaries: set[tuple[str, ...]] = set()
    realizations: dict[str, _LocalRealization] = {}
    composition_errors: list[Exception] = []
    pair_replays_seen = 0

    for first_outcome in first_by_multiset.values():
        if _invalid_valence_atom_maps(first_outcome.products):
            continue
        for component_index, component in enumerate(first_outcome.products):
            enumeration = adapter.enumerate(
                parent_reactor,
                component,
                max_unique_outcomes=limits.max_replay_outcomes,
            )
            if enumeration.truncated:
                truncated = True
            for second_outcome in enumeration.outcomes:
                pair_replays_seen += 1
                if pair_replays_seen > limits.max_replay_outcomes:
                    truncated = True
                    break
                if _invalid_valence_atom_maps(second_outcome.products):
                    continue
                terminal = (
                    tuple(second_outcome.products)
                    + tuple(first_outcome.products[:component_index])
                    + tuple(first_outcome.products[component_index + 1 :])
                )
                comparison = compare_precursor_multisets(boundary, terminal)
                if not comparison.chemistry_equivalent:
                    continue
                matching_boundaries.add(_canonical_multiset(terminal))
                first_forward = _forward_reaction(second_outcome)
                second_forward = _forward_reaction(first_outcome)
                try:
                    counter_fingerprint, counter_hash = _compose_local_route_cgr(
                        (first_forward, second_forward)
                    )
                except Exception as exc:
                    composition_errors.append(exc)
                    continue
                if counter_fingerprint != original_fingerprint:
                    continue
                fingerprint = _realization_fingerprint(
                    expanded_component_index=component_index,
                    intermediate=component,
                    first_forward=first_forward,
                    second_forward=second_forward,
                    terminal=terminal,
                )
                realizations.setdefault(
                    fingerprint,
                    _LocalRealization(
                        first_outcome=first_outcome,
                        second_outcome=second_outcome,
                        expanded_component_index=component_index,
                        terminal_molecules=terminal,
                        first_forward_reaction=first_forward,
                        second_forward_reaction=second_forward,
                        fingerprint=fingerprint,
                        route_cgr_fingerprint=counter_fingerprint,
                        route_cgr_hash=counter_hash,
                    ),
                )
                if len(realizations) > limits.max_counterfactuals_per_pair:
                    truncated = True
                    break
            if truncated and (
                pair_replays_seen > limits.max_replay_outcomes
                or len(realizations) > limits.max_counterfactuals_per_pair
            ):
                break
        if truncated and (
            pair_replays_seen > limits.max_replay_outcomes
            or len(realizations) > limits.max_counterfactuals_per_pair
        ):
            break
    retained = tuple(realizations[key] for key in sorted(realizations))[
        : limits.max_counterfactuals_per_pair
    ]
    return (
        retained,
        replay_outcome_count,
        len(matching_boundaries),
        truncated,
        original_fingerprint,
        original_hash,
        composition_errors[0] if composition_errors else None,
    )


def _unresolved_assessment(
    occurrence: ReferenceBigramOccurrence,
    *,
    source_library_id: str,
    segment: _Segment | None,
    error: Exception,
    replay_outcome_count: int = 0,
    matching_boundary_count: int = 0,
    truncated: bool = False,
    original_fingerprint: Mapping[str, Any] | None = None,
    original_hash: str = "",
) -> AdjacentPairAssessment:
    native = occurrence.occurrence
    centers_1 = native.steps[0].center_atom_maps
    centers_2 = native.steps[1].center_atom_maps
    intermediate = (
        "" if segment is None else _molecule_smiles(segment.intermediate_node)
    )
    center_distance = None
    if segment is not None:
        try:
            center_distance = _minimum_center_distance(
                chemistry.parse_molecule(intermediate),
                centers_1,
                centers_2,
            )
        except Exception:
            # The primary unresolved reason remains authoritative; unavailable
            # centre distance is represented by None.
            center_distance = None
    return AdjacentPairAssessment(
        source_route_id=native.route_id,
        pair_identity=_pair_identity(
            occurrence,
            source_library_id=source_library_id,
        ),
        reference_bigram_occurrence_id=occurrence.reference_occurrence_id,
        first_reaction_path=native.reaction_node_paths[0],
        second_reaction_path=native.reaction_node_paths[1],
        status="unresolved",
        replay_outcome_count=replay_outcome_count,
        matching_boundary_count=matching_boundary_count,
        unique_counterfactual_count=0,
        original_intermediate=intermediate,
        counterfactual_intermediates=(),
        boundary_precursors=(
            ()
            if segment is None
            else tuple(_molecule_smiles(node) for node in segment.boundary_nodes)
        ),
        original_bigram_occurrence=native.to_dict(),
        r1_center_maps=centers_1,
        r2_center_maps=centers_2,
        center_overlap=tuple(set(centers_1) & set(centers_2)),
        minimum_center_graph_distance=center_distance,
        original_route_cgr_fingerprint=original_fingerprint,
        route_cgr_hashes=((original_hash,) if original_hash else ()),
        truncated=truncated,
        error_type=type(error).__name__,
        error_message=str(error) or type(error).__name__,
    )


def _assess_adjacent_pair_impl(
    source_route: Mapping[str, Any],
    occurrence: ReferenceBigramOccurrence,
    *,
    source_library_id: str,
    rule_extractor: Any,
    limits: C3ReplayLimits,
    adapter: ChythonOneShotTraceAdapter | None = None,
) -> _PairReplayResult:
    if not isinstance(occurrence, ReferenceBigramOccurrence):
        raise TypeError("occurrence must be a ReferenceBigramOccurrence")
    if not occurrence.route_without_rrseq:
        raise ValueError("C3 accepts only manifest-defined no-RRSeq occurrences")
    native = occurrence.occurrence
    if not all(step.query_cgr_key for step in native.steps):
        raise ValueError("C3 requires persisted query_cgr_key provenance")

    segment: _Segment | None = None
    try:
        segment = _resolve_segment(source_route, occurrence)
        intermediate_molecule = chemistry.parse_molecule(
            _molecule_smiles(segment.intermediate_node)
        )
        (
            realizations,
            replay_count,
            boundary_count,
            truncated,
            original_fingerprint,
            original_hash,
            composition_error,
        ) = _enumerate_local_realizations(
            occurrence,
            segment,
            limits=limits,
            adapter=adapter or ChythonOneShotTraceAdapter(),
        )
        if truncated:
            error = RuntimeError("bounded reversed replay reached an enumeration limit")
            return _PairReplayResult(
                _unresolved_assessment(
                    occurrence,
                    source_library_id=source_library_id,
                    segment=segment,
                    error=error,
                    replay_outcome_count=replay_count,
                    matching_boundary_count=boundary_count,
                    truncated=True,
                    original_fingerprint=original_fingerprint,
                    original_hash=original_hash,
                ),
                (),
            )
        if composition_error is not None:
            return _PairReplayResult(
                _unresolved_assessment(
                    occurrence,
                    source_library_id=source_library_id,
                    segment=segment,
                    error=composition_error,
                    replay_outcome_count=replay_count,
                    matching_boundary_count=boundary_count,
                    original_fingerprint=original_fingerprint,
                    original_hash=original_hash,
                ),
                (),
            )

        validated: dict[str, _ValidatedCounterfactual] = {}
        reconstruction_errors: list[Exception] = []
        for realization in realizations:
            counterfactual_id = _counterfactual_id(occurrence, realization.fingerprint)
            try:
                route, counter_bigram = _build_complete_route(
                    source_route,
                    occurrence,
                    segment,
                    realization,
                    counterfactual_id=counterfactual_id,
                    source_library_id=source_library_id,
                    rule_extractor=rule_extractor,
                )
            except Exception as exc:
                reconstruction_errors.append(exc)
                continue
            validated.setdefault(
                realization.fingerprint,
                _ValidatedCounterfactual(
                    counterfactual_id=counterfactual_id,
                    route=route,
                    bigram_occurrence=counter_bigram,
                    intermediate_smiles=format(
                        realization.first_outcome.products[
                            realization.expanded_component_index
                        ],
                        "m",
                    ),
                    realization_fingerprint=realization.fingerprint,
                    route_cgr_fingerprint=realization.route_cgr_fingerprint,
                    route_cgr_hash=realization.route_cgr_hash,
                ),
            )
        accepted = tuple(validated[key] for key in sorted(validated))
        if reconstruction_errors:
            error = (
                reconstruction_errors[0]
                if reconstruction_errors
                else ValueError(
                    "certified local replay produced no validated complete route"
                )
            )
            return _PairReplayResult(
                _unresolved_assessment(
                    occurrence,
                    source_library_id=source_library_id,
                    segment=segment,
                    error=error,
                    replay_outcome_count=replay_count,
                    matching_boundary_count=boundary_count,
                    original_fingerprint=original_fingerprint,
                    original_hash=original_hash,
                ),
                (),
            )

        status = (
            "commutable_unique"
            if len(accepted) == 1
            else "commutable_ambiguous"
            if len(accepted) > 1
            else "noncommutable"
        )
        for counterfactual in accepted:
            metadata = counterfactual.route.get("metadata")
            if not isinstance(metadata, dict):
                raise RuntimeError("validated counterfactual route lost root metadata")
            metadata["counterfactual_reassembly"]["pair_status"] = status
        center_distance = _minimum_center_distance(
            intermediate_molecule,
            native.steps[0].center_atom_maps,
            native.steps[1].center_atom_maps,
        )
        assessment = AdjacentPairAssessment(
            source_route_id=native.route_id,
            pair_identity=_pair_identity(
                occurrence,
                source_library_id=source_library_id,
            ),
            reference_bigram_occurrence_id=occurrence.reference_occurrence_id,
            first_reaction_path=native.reaction_node_paths[0],
            second_reaction_path=native.reaction_node_paths[1],
            status=status,
            replay_outcome_count=replay_count,
            matching_boundary_count=boundary_count,
            unique_counterfactual_count=len(accepted),
            original_intermediate=_molecule_smiles(segment.intermediate_node),
            counterfactual_intermediates=tuple(
                value.intermediate_smiles for value in accepted
            ),
            boundary_precursors=tuple(
                _molecule_smiles(node) for node in segment.boundary_nodes
            ),
            original_bigram_occurrence=native.to_dict(),
            counterfactual_bigram_occurrences=tuple(
                value.bigram_occurrence for value in accepted
            ),
            counterfactual_ids=tuple(value.counterfactual_id for value in accepted),
            r1_center_maps=native.steps[0].center_atom_maps,
            r2_center_maps=native.steps[1].center_atom_maps,
            center_overlap=tuple(
                set(native.steps[0].center_atom_maps)
                & set(native.steps[1].center_atom_maps)
            ),
            minimum_center_graph_distance=center_distance,
            original_route_cgr_fingerprint=original_fingerprint,
            counterfactual_route_cgr_fingerprints=tuple(
                value.route_cgr_fingerprint for value in accepted
            ),
            route_cgr_hashes=(original_hash,)
            + tuple(value.route_cgr_hash for value in accepted),
        )
        return _PairReplayResult(assessment, accepted)
    except Exception as exc:
        return _PairReplayResult(
            _unresolved_assessment(
                occurrence,
                source_library_id=source_library_id,
                segment=segment,
                error=exc,
            ),
            (),
        )


def _assess_adjacent_pair(
    source_route: Mapping[str, Any],
    occurrence: ReferenceBigramOccurrence,
    *,
    source_library_id: str,
    rule_extractor: Any,
    limits: C3ReplayLimits,
    adapter: ChythonOneShotTraceAdapter | None = None,
) -> _PairReplayResult:
    """Apply the fail-closed hard timeout around one complete pair assessment."""

    timeout_seconds = limits.pair_timeout_seconds
    if timeout_seconds is None:
        return _assess_adjacent_pair_impl(
            source_route,
            occurrence,
            source_library_id=source_library_id,
            rule_extractor=rule_extractor,
            limits=limits,
            adapter=adapter,
        )
    if not all(
        hasattr(signal, name)
        for name in ("SIGALRM", "ITIMER_REAL", "getitimer", "setitimer")
    ):
        return _PairReplayResult(
            _unresolved_assessment(
                occurrence,
                source_library_id=source_library_id,
                segment=None,
                error=RuntimeError(
                    "per-pair C3 timeout requires POSIX setitimer support"
                ),
            ),
            (),
        )

    previous_handler = signal.getsignal(signal.SIGALRM)
    previous_timer = signal.getitimer(signal.ITIMER_REAL)

    def raise_timeout(_signum: int, _frame: Any) -> None:
        raise TimeoutError(
            f"C3 pair replay exceeded {float(timeout_seconds):g} seconds"
        )

    handler_set = False
    try:
        signal.signal(signal.SIGALRM, raise_timeout)
        handler_set = True
        signal.setitimer(signal.ITIMER_REAL, float(timeout_seconds))
    except ValueError:
        if handler_set:
            signal.signal(signal.SIGALRM, previous_handler)
        return _PairReplayResult(
            _unresolved_assessment(
                occurrence,
                source_library_id=source_library_id,
                segment=None,
                error=RuntimeError(
                    "per-pair C3 timeout requires the process main thread"
                ),
            ),
            (),
        )
    try:
        return _assess_adjacent_pair_impl(
            source_route,
            occurrence,
            source_library_id=source_library_id,
            rule_extractor=rule_extractor,
            limits=limits,
            adapter=adapter,
        )
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0.0)
        signal.signal(signal.SIGALRM, previous_handler)
        if previous_timer[0] > 0 or previous_timer[1] > 0:
            signal.setitimer(
                signal.ITIMER_REAL,
                previous_timer[0],
                previous_timer[1],
            )


def assess_adjacent_pair_commutability(
    source_route: Mapping[str, Any],
    occurrence: ReferenceBigramOccurrence,
    *,
    source_library_id: str,
    rule_extractor: Any,
    limits: C3ReplayLimits | None = None,
    adapter: ChythonOneShotTraceAdapter | None = None,
) -> AdjacentPairAssessment:
    """Replay one no-RRSeq adjacent pair in reverse order and certify its route."""

    return _assess_adjacent_pair(
        source_route,
        occurrence,
        source_library_id=source_library_id,
        rule_extractor=rule_extractor,
        limits=limits or C3ReplayLimits(),
        adapter=adapter,
    ).assessment


def with_reaction_classes(
    assessment: AdjacentPairAssessment,
    reaction_classes: Mapping[str, Any],
) -> AdjacentPairAssessment:
    """Attach optional provider-neutral source-step annotations."""

    return replace(assessment, reaction_classes=dict(reaction_classes))


__all__ = [
    "assess_adjacent_pair_commutability",
]
