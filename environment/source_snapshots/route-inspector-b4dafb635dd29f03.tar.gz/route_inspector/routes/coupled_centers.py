"""Evidence for retaining recorded transformations with coupled centres."""


def nitro_transformation_evidence(reaction, center_components):
    """Keep a transformed carbon-bound nitro group within its recorded reaction."""
    centers = tuple(frozenset(c) for c in center_components)
    if len(centers) < 2:
        return None

    def groups(molecules):
        found = {}
        for molecule in molecules:
            adjacency = {n: {} for n in molecule}
            for a, b, bond in molecule.bonds():
                adjacency[a][b] = adjacency[b][a] = bond.order
            for n, atom in molecule.atoms():
                if (
                    atom.atomic_number != 7
                    or atom.charge != 1
                    or len(adjacency[n]) != 3
                ):
                    continue
                oxygens = [
                    o for o in adjacency[n] if molecule.atom(o).atomic_number == 8
                ]
                carbons = [
                    c for c in adjacency[n] if molecule.atom(c).atomic_number == 6
                ]
                if len(oxygens) != 2 or len(carbons) != 1:
                    continue
                if any(len(adjacency[o]) != 1 for o in oxygens):
                    continue
                if sorted(
                    (adjacency[n][o], molecule.atom(o).charge) for o in oxygens
                ) != [(1, -1), (2, 0)]:
                    continue
                found[n] = (carbons[0], *sorted(oxygens))
        return found

    before, after = groups(reaction.reactants), groups(reaction.products)
    changed = [n for n in before.keys() | after.keys() if before.get(n) != after.get(n)]
    changed = [n for n in changed if any(n in center for center in centers)]
    if not changed:
        return None
    # TODO: Generalize coupled-transform recognition beyond this nitro exception.
    # Distinguish atom-correspondence artifacts from genuinely independent centres.
    return {
        "policy": "retain_nitro_transformation_v1",
        "reason": "nitro_transformation_retained_as_recorded",
        "disposition": "retain_recorded_reaction",
        "center_components": [sorted(c) for c in centers],
        "nitro_nitrogen_atom_ids": sorted(changed),
        "experimental_independence_asserted": False,
    }


def shared_disappearing_fragment_evidence(reaction, center_components):
    """Return a witness only when all centres are linked through leaving atoms.

    Connectivity uses the recorded reactant graph restricted to atoms absent
    from every product. It never links centres merely because they are close
    in the retained scaffold, and never claims an experimental mechanism.
    """
    centers = tuple(frozenset(c) for c in center_components)
    if len(centers) < 2:
        return None
    retained = {n for molecule in reaction.products for n in molecule}
    links = {i: set() for i in range(len(centers))}
    witnesses = []
    for molecule in reaction.reactants:
        adjacency = {n: set() for n in molecule}
        for a, b, _ in molecule.bonds():
            adjacency[a].add(b)
            adjacency[b].add(a)
        missing = set(molecule) - retained
        while missing:
            fragment = {min(missing)}
            pending = list(fragment)
            while pending:
                for neighbor in adjacency[pending.pop()] & missing - fragment:
                    fragment.add(neighbor)
                    pending.append(neighbor)
            missing -= fragment
            boundary = {n for a in fragment for n in adjacency[a] if n in retained}
            touched = [
                i for i, center in enumerate(centers) if center & (fragment | boundary)
            ]
            # A wholly discarded reagent provides no retained attachment witness.
            if not boundary or len(touched) < 2:
                continue
            for i in touched:
                links[i].update(touched)
            witnesses.append(
                {
                    "fragment_atom_ids": sorted(fragment),
                    "retained_attachment_atom_ids": sorted(boundary),
                    "center_component_indices": touched,
                }
            )
    connected = {0}
    pending = [0]
    while pending:
        for neighbor in links[pending.pop()] - connected:
            connected.add(neighbor)
            pending.append(neighbor)
    if len(connected) != len(centers):
        return None
    return {
        "policy": "shared_disappearing_fragment_v1",
        "reason": "all_centers_linked_through_disappearing_source_fragments",
        "disposition": "retain_recorded_reaction",
        "center_components": [sorted(c) for c in centers],
        "shared_fragments": witnesses,
        "experimental_independence_asserted": False,
    }
