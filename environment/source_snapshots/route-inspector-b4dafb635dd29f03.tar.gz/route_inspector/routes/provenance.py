"""Source-record provenance adapters for route reaction nodes.

The route corpora handled by Route Inspector do not share one source identifier
schema.  This module keeps the raw identifier lossless and makes parsing an
explicit, versioned adapter decision rather than embedding PaRoutes assumptions in
the occurrence/index code."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Protocol

RAW_SOURCE_ID_ADAPTER = "raw"


@dataclass(frozen=True)
class SourceIdentifiers:
    """Normalized identifiers derived from one reaction node's metadata."""

    source_record_id: str = ""
    source_document_id: str = ""
    adapter: str = "raw"

    def to_dict(self) -> dict[str, str]:
        return {
            "source_record_id": self.source_record_id,
            "source_document_id": self.source_document_id,
            "source_id_adapter": self.adapter,
        }


class SourceIdAdapter(Protocol):
    """Interface for corpus-specific source identifier parsing."""

    name: str

    def parse(self, metadata: Mapping[str, Any]) -> SourceIdentifiers:
        """Return normalized identifiers without altering the raw metadata."""


def raw_source_record_id(metadata: Mapping[str, Any]) -> str:
    """Return the first lossless reaction-record identifier in known fields.

    Generated preprocessing split nodes retain the originating value in their
    split metadata.  That nested value takes precedence over a generated node ID.
    """

    split = metadata.get("route_preprocessing_split")
    if isinstance(split, Mapping):
        value = split.get("original_source_record_id")
        if value not in (None, ""):
            return str(value)
        original = split.get("original_metadata")
        if isinstance(original, Mapping):
            for key in ("ID", "id", "source_record_id", "source_id"):
                value = original.get(key)
                if value not in (None, ""):
                    return str(value)

    for key in ("ID", "id", "source_record_id", "source_id"):
        value = metadata.get(key)
        if value not in (None, ""):
            return str(value)
    return ""


@dataclass(frozen=True)
class RawMetadataSourceIdAdapter:
    """Preserve a raw source-record ID without corpus-specific parsing."""

    name: str = RAW_SOURCE_ID_ADAPTER

    def parse(self, metadata: Mapping[str, Any]) -> SourceIdentifiers:
        value = raw_source_record_id(metadata)
        return SourceIdentifiers(
            source_record_id=value,
            source_document_id="",
            adapter=self.name,
        )
