"""Strict route-level atom-map validation for preprocessed route trees."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from route_inspector import chemistry
from route_inspector.infrastructure.text import write_tsv
from route_inspector.routes import access as routes
from route_inspector.routes.molecular_identity import molecule_multisets_equivalent
from route_inspector.routes.stereo import (
    classify_recorded_noop,
    stereo_component_signature,
)

ROUTE_MAPPING_VALIDATION_FIELDS = [
    "dataset",
    "route_id",
    "status",
    "stage",
    "reaction_step",
    "reaction_node_path",
    "message",
    "target_atom_count",
    "target_map_ids",
    "sb_cgr_target_atom_count",
    "sb_cgr_target_map_ids",
]


class RouteMappingValidationError(ValueError):
    """Raised when strict preprocessing validation finds invalid routes."""


@dataclass(frozen=True)
class _RawAtomToken:
    """One atom read directly from a reaction-SMILES side before parsing."""

    ordinal: int
    text: str
    map_id: int | None
    map_text: str | None
    identity: tuple[str, int | None]


_BRACKET_ATOM_RE = re.compile(
    r"^(?:(?P<isotope>[0-9]+))?(?P<symbol>\*|[A-Z][a-z]?|[a-z]{1,2})"
)
_MAP_SUFFIX_RE = re.compile(r":([^:]*)$")
_POSITIVE_MAP_RE = re.compile(r"[1-9][0-9]*")
_UNBRACKETED_TWO_CHARACTER_ATOMS = frozenset({"Br", "Cl", "as", "se"})
_UNBRACKETED_ONE_CHARACTER_ATOMS = frozenset("BCNOPSFIbcnops*")


def _route_id_sort_key(value: Any) -> tuple[int, Any]:
    value = str(value)
    if value.isdigit():
        return (0, int(value))
    return (1, value)


def _path_text(path: tuple[int, ...]) -> str:
    return ".".join(str(index) for index in path)


def _map_ids(molecule: Any) -> tuple[int, ...]:
    return tuple(sorted(int(atom_id) for atom_id in molecule))


def _issue(
    *,
    dataset: str,
    route_id: Any,
    stage: str,
    message: str,
    reaction_step: str = "",
    reaction_node_path: tuple[int, ...] | str = "",
    target: Any | None = None,
    sb_target: Any | None = None,
) -> dict[str, Any]:
    return {
        "dataset": dataset,
        "route_id": str(route_id),
        "status": "failed",
        "stage": stage,
        "reaction_step": reaction_step,
        "reaction_node_path": (
            _path_text(reaction_node_path)
            if isinstance(reaction_node_path, tuple)
            else reaction_node_path
        ),
        "message": message,
        "target_atom_count": (int(target.atoms_count) if target is not None else ""),
        "target_map_ids": list(_map_ids(target)) if target is not None else [],
        "sb_cgr_target_atom_count": (
            int(sb_target.atoms_count) if sb_target is not None else ""
        ),
        "sb_cgr_target_map_ids": (
            list(_map_ids(sb_target)) if sb_target is not None else []
        ),
    }


def _atom_identity(symbol: str, isotope: str | None) -> tuple[str, int | None]:
    """Normalize only the element/isotope identity that maps must preserve."""

    if symbol == "D":
        return ("H", 2)
    if symbol == "T":
        return ("H", 3)
    if symbol not in {"*"}:
        symbol = symbol[0].upper() + symbol[1:].lower()
    return (symbol, int(isotope) if isotope is not None else None)


def _raw_side_atom_tokens(
    side_text: str,
) -> tuple[tuple[_RawAtomToken, ...], tuple[str, ...]]:
    """Lex reaction-side atoms without asking Chython to assign atom numbers.

    A mapped SMILES atom must be bracketed, so the scanner only needs to
    distinguish bracket atoms from the unbracketed organic subset. Chython remains
    the authority for complete SMILES syntax after this mapping-only preflight.
    """

    tokens: list[_RawAtomToken] = []
    syntax_errors: list[str] = []
    index = 0
    graph_text = side_text.strip()
    while index < len(graph_text):
        character = graph_text[index]
        if character == "[":
            closing = graph_text.find("]", index + 1)
            if closing < 0:
                syntax_errors.append(
                    f"unterminated bracket atom beginning at character {index}"
                )
                break
            text = graph_text[index : closing + 1]
            content = text[1:-1]
            atom_match = _BRACKET_ATOM_RE.match(content)
            if atom_match is None:
                syntax_errors.append(
                    f"could not identify bracket atom {text!r} at character {index}"
                )
                index = closing + 1
                continue
            map_match = _MAP_SUFFIX_RE.search(content)
            map_text = map_match.group(1) if map_match is not None else None
            map_id = (
                int(map_text) if map_text is not None and map_text.isdigit() else None
            )
            tokens.append(
                _RawAtomToken(
                    ordinal=len(tokens) + 1,
                    text=text,
                    map_id=map_id,
                    map_text=map_text,
                    identity=_atom_identity(
                        atom_match.group("symbol"), atom_match.group("isotope")
                    ),
                )
            )
            index = closing + 1
            continue

        two_character = graph_text[index : index + 2]
        if two_character in _UNBRACKETED_TWO_CHARACTER_ATOMS:
            atom_text = two_character
        elif character in _UNBRACKETED_ONE_CHARACTER_ATOMS:
            atom_text = character
        elif character.isalpha():
            # This may ultimately be rejected by the chemistry parser, but it is
            # still unsafe to let a possible atom pass the explicit-map boundary.
            atom_text = two_character if two_character.isalpha() else character
        else:
            index += 1
            continue
        tokens.append(
            _RawAtomToken(
                ordinal=len(tokens) + 1,
                text=atom_text,
                map_id=None,
                map_text=None,
                identity=_atom_identity(atom_text, None),
            )
        )
        index += len(atom_text)
    return tuple(tokens), tuple(syntax_errors)


def _raw_mapping_issue(
    *,
    dataset: str,
    route_id: Any,
    stage: str,
    message: str,
    reaction_step: str,
    reaction_node_path: tuple[int, ...],
) -> dict[str, Any]:
    return _issue(
        dataset=dataset,
        route_id=route_id,
        stage=stage,
        message=message,
        reaction_step=reaction_step,
        reaction_node_path=reaction_node_path,
    )


def validate_raw_reaction_atom_mapping(
    reaction_smiles: str,
    *,
    dataset: str = "",
    route_id: Any = "",
    reaction_step: str = "",
    reaction_node_path: tuple[int, ...] = (),
) -> list[dict[str, Any]]:
    """Reject unsafe raw reaction maps without constructing a Chython reaction.

    Every reactant and product atom requires one explicit positive map ID. IDs
    must be unique within each side, and an ID shared across the arrow must retain
    its element and isotope. Atoms in the middle reagent field are intentionally
    outside the reaction mapping contract.
    """

    if not isinstance(reaction_smiles, str):
        return [
            _raw_mapping_issue(
                dataset=dataset,
                route_id=route_id,
                stage="raw_reaction_smiles_syntax",
                message="reaction SMILES must be text",
                reaction_step=reaction_step,
                reaction_node_path=reaction_node_path,
            )
        ]
    core_text = reaction_smiles.strip()
    if " |" in core_text:
        core_text = core_text.split(" |", 1)[0]
    if any(character.isspace() for character in core_text):
        return [
            _raw_mapping_issue(
                dataset=dataset,
                route_id=route_id,
                stage="raw_reaction_smiles_syntax",
                message=(
                    "reaction SMILES contains whitespace before the optional "
                    "CXSMILES suffix"
                ),
                reaction_step=reaction_step,
                reaction_node_path=reaction_node_path,
            )
        ]
    fields = core_text.split(">")
    if len(fields) != 3:
        return [
            _raw_mapping_issue(
                dataset=dataset,
                route_id=route_id,
                stage="raw_reaction_smiles_syntax",
                message=(
                    "reaction SMILES requires exactly two '>' delimiters before "
                    "raw atom-map validation"
                ),
                reaction_step=reaction_step,
                reaction_node_path=reaction_node_path,
            )
        ]

    atoms_by_side: dict[str, tuple[_RawAtomToken, ...]] = {}
    duplicate_ids_by_side: dict[str, set[int]] = {}
    issues: list[dict[str, Any]] = []
    for side_name, side_text in (("reactant", fields[0]), ("product", fields[2])):
        atoms, syntax_errors = _raw_side_atom_tokens(side_text)
        atoms_by_side[side_name] = atoms
        if syntax_errors:
            issues.append(
                _raw_mapping_issue(
                    dataset=dataset,
                    route_id=route_id,
                    stage="raw_reaction_smiles_syntax",
                    message=f"{side_name} side: {'; '.join(syntax_errors)}",
                    reaction_step=reaction_step,
                    reaction_node_path=reaction_node_path,
                )
            )

        missing = [atom for atom in atoms if atom.map_text is None]
        invalid = [
            atom
            for atom in atoms
            if atom.map_text is not None
            and _POSITIVE_MAP_RE.fullmatch(atom.map_text) is None
        ]
        if missing:
            examples = ", ".join(
                f"atom {atom.ordinal} {atom.text!r}" for atom in missing[:8]
            )
            suffix = "" if len(missing) <= 8 else f", ... ({len(missing)} total)"
            issues.append(
                _raw_mapping_issue(
                    dataset=dataset,
                    route_id=route_id,
                    stage="raw_reaction_unmapped_atoms",
                    message=(
                        f"{side_name} side has atoms without an explicit positive "
                        f"atom-map ID: {examples}{suffix}"
                    ),
                    reaction_step=reaction_step,
                    reaction_node_path=reaction_node_path,
                )
            )
        if invalid:
            details = ", ".join(
                f"atom {atom.ordinal} {atom.text!r} map={atom.map_text!r}"
                for atom in invalid[:8]
            )
            suffix = "" if len(invalid) <= 8 else f", ... ({len(invalid)} total)"
            issues.append(
                _raw_mapping_issue(
                    dataset=dataset,
                    route_id=route_id,
                    stage="raw_reaction_nonpositive_map_ids",
                    message=(
                        f"{side_name} side has invalid or non-positive atom-map "
                        f"IDs: {details}{suffix}"
                    ),
                    reaction_step=reaction_step,
                    reaction_node_path=reaction_node_path,
                )
            )

        positive_ids = [
            int(atom.map_text)
            for atom in atoms
            if atom.map_text is not None
            and _POSITIVE_MAP_RE.fullmatch(atom.map_text) is not None
        ]
        duplicates = sorted(
            map_id for map_id, count in Counter(positive_ids).items() if count > 1
        )
        duplicate_ids_by_side[side_name] = set(duplicates)
        if duplicates:
            issues.append(
                _raw_mapping_issue(
                    dataset=dataset,
                    route_id=route_id,
                    stage="raw_reaction_duplicate_map_ids",
                    message=(
                        f"{side_name} side repeats atom-map IDs: "
                        + ",".join(map(str, duplicates))
                    ),
                    reaction_step=reaction_step,
                    reaction_node_path=reaction_node_path,
                )
            )

    identity_by_side: dict[str, dict[int, tuple[str, int | None]]] = {}
    for side_name, atoms in atoms_by_side.items():
        identity_by_side[side_name] = {
            int(atom.map_text): atom.identity
            for atom in atoms
            if atom.map_text is not None
            and _POSITIVE_MAP_RE.fullmatch(atom.map_text) is not None
        }
    reactant_identities = identity_by_side["reactant"]
    product_identities = identity_by_side["product"]
    mismatches = [
        map_id
        for map_id in sorted(reactant_identities.keys() & product_identities.keys())
        if map_id
        not in (duplicate_ids_by_side["reactant"] | duplicate_ids_by_side["product"])
        and reactant_identities[map_id] != product_identities[map_id]
    ]
    if mismatches:
        details = ", ".join(
            f"{map_id}:{reactant_identities[map_id]}->{product_identities[map_id]}"
            for map_id in mismatches
        )
        issues.append(
            _raw_mapping_issue(
                dataset=dataset,
                route_id=route_id,
                stage="raw_reaction_map_identity_mismatch",
                message=(
                    "atom-map IDs shared across the reaction change element or "
                    f"isotope: {details}"
                ),
                reaction_step=reaction_step,
                reaction_node_path=reaction_node_path,
            )
        )
    return issues


def validate_raw_route_reaction_mapping(
    route_id: Any,
    route: dict[str, Any],
    *,
    dataset: str = "",
) -> tuple[list[dict[str, Any]], int]:
    """Preflight every raw route reaction before any chemistry parser is called."""

    issues: list[dict[str, Any]] = []
    reaction_index = 1

    def visit(node: dict[str, Any], path: tuple[int, ...]) -> None:
        nonlocal reaction_index
        for child_index, reaction_node in enumerate(node.get("children") or ()):
            if not isinstance(reaction_node, dict):
                continue
            child_path = path + (child_index,)
            if reaction_node.get("type") == "reaction":
                step = f"r{reaction_index}"
                reaction_index += 1
                try:
                    reaction_smiles = routes.reaction_smiles_from_node(reaction_node)
                except Exception as exc:
                    issues.append(
                        _issue(
                            dataset=dataset,
                            route_id=route_id,
                            stage="parse_route_reaction",
                            message=str(exc),
                            reaction_step=step,
                            reaction_node_path=child_path,
                        )
                    )
                else:
                    issues.extend(
                        validate_raw_reaction_atom_mapping(
                            reaction_smiles,
                            dataset=dataset,
                            route_id=route_id,
                            reaction_step=step,
                            reaction_node_path=child_path,
                        )
                    )
            visit(reaction_node, child_path)

    visit(route, ())
    return issues, reaction_index - 1


def _exact_indexes(candidates: Iterable[Any], expected: Any) -> list[int]:
    return [
        index
        for index, candidate in enumerate(candidates)
        if chemistry.exact_map_identity_mapping(candidate, expected) is not None
    ]


def _graph_indexes(candidates: Iterable[Any], expected: Any) -> list[int]:
    indexes = []
    for index, candidate in enumerate(candidates):
        try:
            if chemistry.molecules_equivalent(candidate, expected):
                indexes.append(index)
        except Exception:
            continue
    return indexes


def _mapped_bond_orders(molecule: Any) -> dict[tuple[int, int], int]:
    return {
        tuple(sorted((int(atom1), int(atom2)))): int(bond)
        for atom1, atom2, bond in molecule.bonds()
    }


def _mapped_skeleton_identity(left: Any, right: Any) -> bool:
    """Compare mapped atoms and bonds while excluding derived atom state."""

    try:
        if (
            left.atoms_count != right.atoms_count
            or left.bonds_count != right.bonds_count
            or set(_map_ids(left)) != set(_map_ids(right))
        ):
            return False
        for atom_id in left:
            left_atom = left.atom(atom_id)
            right_atom = right.atom(atom_id)
            if (
                left_atom.atomic_number,
                left_atom.isotope,
            ) != (
                right_atom.atomic_number,
                right_atom.isotope,
            ):
                return False
        return _mapped_bond_orders(left) == _mapped_bond_orders(right)
    except (AttributeError, KeyError, TypeError, ValueError):
        return False


def _mapped_skeleton_indexes(
    candidates: Iterable[Any],
    expected: Any,
) -> list[int]:
    return [
        index
        for index, candidate in enumerate(candidates)
        if _mapped_skeleton_identity(candidate, expected)
    ]


def _reaction_span(route: dict[str, Any]) -> str:
    reaction_count = routes.count_reaction_nodes(route)
    if reaction_count < 1:
        return ""
    if reaction_count == 1:
        return "r1"
    return f"r1-r{reaction_count}"


def _sb_product_bond_orders(sb_cgr: Any) -> dict[tuple[int, int], int]:
    bonds: dict[tuple[int, int], int] = {}
    for atom1, atom2, bond in sb_cgr.bonds():
        product_order = getattr(bond, "p_order", None)
        if product_order is None:
            continue
        bonds[tuple(sorted((int(atom1), int(atom2))))] = int(product_order)
    return bonds


def _duplicate_map_ids(molecules: Iterable[Any]) -> tuple[int, ...]:
    seen: set[int] = set()
    duplicates: set[int] = set()
    for molecule in molecules:
        for atom_id in molecule:
            atom_id = int(atom_id)
            if atom_id in seen:
                duplicates.add(atom_id)
            seen.add(atom_id)
    return tuple(sorted(duplicates))


def _cached_positive_edges(route, cache, allow_stereo_only_reactions):
    """Reuse successful local checks; failures use the full provenance traversal.

    A unit contains one molecule, all consuming reactions immediately below it,
    and their input molecules. Every raw reaction and parent/child edge is thus
    checked, while the separate whole-route CGR validation remains mandatory.
    """
    if not isinstance(route, dict) or route.get("type") != "mol":
        return None
    unit = {k: v for k, v in route.items() if k != "children"}
    unit["children"] = []
    descendants = []
    for reaction in route.get("children") or ():
        if not isinstance(reaction, dict) or reaction.get("type") != "reaction":
            return None
        local = {k: v for k, v in reaction.items() if k != "children"}
        local["children"] = []
        for child in reaction.get("children") or ():
            if not isinstance(child, dict) or child.get("type") != "mol":
                return None
            local["children"].append(
                {k: v for k, v in child.items() if k != "children"} | {"children": []}
            )
            descendants.append(child)
        unit["children"].append(local)
    try:
        key = (allow_stereo_only_reactions, json.dumps(unit, sort_keys=True))
    except (TypeError, ValueError):
        return None
    if key not in cache:
        failures, count = validate_route_edges(
            "local", unit, allow_stereo_only_reactions=allow_stereo_only_reactions
        )
        if failures:
            return None
        cache[key] = count
        if len(cache) > 8192:
            cache.pop(next(iter(cache)))
    count = cache[key]
    for child in descendants:
        child_count = _cached_positive_edges(child, cache, allow_stereo_only_reactions)
        if child_count is None:
            return None
        count += child_count
    return count


def validate_route_edges(
    route_id: Any,
    route: dict[str, Any],
    *,
    dataset: str = "",
    allow_stereo_only_reactions: bool = False,
    positive_cache: dict | None = None,
) -> tuple[list[dict[str, Any]], int]:
    """Validate exact edges, optionally preserving evidenced stereo-only steps.

    The opt-in exception requires original/step-local reaction provenance and
    stereo-aware edge equivalence; it never accepts genuinely identical steps.
    """

    if positive_cache is not None:
        cached_count = _cached_positive_edges(
            route, positive_cache, allow_stereo_only_reactions
        )
        if cached_count is not None:
            return [], cached_count
    raw_mapping_issues, raw_reaction_count = validate_raw_route_reaction_mapping(
        route_id,
        route,
        dataset=dataset,
    )
    if raw_mapping_issues:
        return raw_mapping_issues, raw_reaction_count

    issues: list[dict[str, Any]] = []
    reaction_index = 1

    def visit_molecule(node: dict[str, Any], path: tuple[int, ...]) -> None:
        nonlocal reaction_index
        mapped_smiles = routes.molecule_node_mapped_smiles(
            node
        ) or routes.molecule_node_smiles(node)
        try:
            parent_molecule = chemistry.parse_molecule(mapped_smiles)
        except Exception as exc:
            issues.append(
                _issue(
                    dataset=dataset,
                    route_id=route_id,
                    stage="parse_route_molecule",
                    message=str(exc),
                    reaction_node_path=path,
                )
            )
            return

        for child_index, reaction_node in enumerate(node.get("children") or ()):
            if (
                not isinstance(reaction_node, dict)
                or reaction_node.get("type") != "reaction"
            ):
                continue
            step = f"r{reaction_index}"
            reaction_index += 1
            reaction_path = path + (child_index,)
            try:
                reaction = chemistry.parse_reaction(
                    routes.reaction_smiles_from_node(reaction_node)
                )
            except Exception as exc:
                issues.append(
                    _issue(
                        dataset=dataset,
                        route_id=route_id,
                        stage="parse_route_reaction",
                        message=str(exc),
                        reaction_step=step,
                        reaction_node_path=reaction_path,
                        target=parent_molecule,
                    )
                )
                continue

            for side_name, side in (
                ("reactants", reaction.reactants),
                ("products", reaction.products),
            ):
                duplicates = _duplicate_map_ids(side)
                if duplicates:
                    issues.append(
                        _issue(
                            dataset=dataset,
                            route_id=route_id,
                            stage=f"duplicate_{side_name}_map_ids",
                            message=(
                                "atom-map IDs occur in more than one component: "
                                + ",".join(map(str, duplicates))
                            ),
                            reaction_step=step,
                            reaction_node_path=reaction_path,
                            target=parent_molecule,
                        )
                    )

            noop_stage = ""
            noop_message = ""
            if allow_stereo_only_reactions:
                classification = classify_recorded_noop(
                    routes.reaction_smiles_from_node(reaction_node),
                    reaction_node.get("metadata") or {},
                )
                if classification is not None:
                    if not classification.accepted:
                        noop_stage = classification.classification
                        noop_message = classification.reason
                    else:
                        # Constitutional checks cannot detect a wrong
                        # stereoisomer on a recorded molecule node.
                        try:
                            left, _middle, right = routes.reaction_smiles_from_node(
                                reaction_node
                            ).split(">")
                            child_smiles = ".".join(
                                routes.molecule_node_mapped_smiles(child)
                                or routes.molecule_node_smiles(child)
                                for child in reaction_node.get("children") or ()
                                if isinstance(child, dict)
                                and child.get("type") == "mol"
                            )
                            if stereo_component_signature(
                                left
                            ) != stereo_component_signature(
                                child_smiles
                            ) or stereo_component_signature(mapped_smiles)[
                                0
                            ] not in stereo_component_signature(right):
                                noop_stage = "stereo_route_edge_mismatch"
                                noop_message = "stereo-only reaction differs from its molecule nodes"
                        except Exception as exc:
                            noop_stage = "stereo_comparison_error"
                            noop_message = f"{type(exc).__name__}: {exc}"
            elif molecule_multisets_equivalent(reaction.reactants, reaction.products):
                noop_stage = "graph_identical_noop_reaction"
                noop_message = (
                    "reaction reactant and product component multisets "
                    "are constitutionally identical"
                )
            if noop_stage:
                issues.append(
                    _issue(
                        dataset=dataset,
                        route_id=route_id,
                        stage=noop_stage,
                        message=noop_message,
                        reaction_step=step,
                        reaction_node_path=reaction_path,
                        target=parent_molecule,
                    )
                )
            exact_products = _exact_indexes(reaction.products, parent_molecule)
            if len(exact_products) != 1:
                state_products = _mapped_skeleton_indexes(
                    reaction.products,
                    parent_molecule,
                )
                graph_products = _graph_indexes(reaction.products, parent_molecule)
                if state_products:
                    stage = "product_parent_atom_state_mismatch"
                    message = (
                        "reaction product and parent preserve the exact mapped "
                        "skeleton but differ in atom state"
                    )
                elif graph_products:
                    stage = "product_parent_map_mismatch"
                    message = (
                        "reaction product matches the parent constitutionally "
                        "but not by persistent mapped topology"
                    )
                else:
                    stage = "product_parent_graph_mismatch"
                    message = (
                        "reaction does not contain the parent molecular graph "
                        "as exactly one product"
                    )
                issues.append(
                    _issue(
                        dataset=dataset,
                        route_id=route_id,
                        stage=stage,
                        message=message,
                        reaction_step=step,
                        reaction_node_path=reaction_path,
                        target=parent_molecule,
                    )
                )

            used_reactants: set[int] = set()
            for molecule_child_index, molecule_child in enumerate(
                reaction_node.get("children") or ()
            ):
                if (
                    not isinstance(molecule_child, dict)
                    or molecule_child.get("type") != "mol"
                ):
                    continue
                child_path = reaction_path + (molecule_child_index,)
                child_smiles = routes.molecule_node_mapped_smiles(
                    molecule_child
                ) or routes.molecule_node_smiles(molecule_child)
                try:
                    child_molecule = chemistry.parse_molecule(child_smiles)
                except Exception as exc:
                    issues.append(
                        _issue(
                            dataset=dataset,
                            route_id=route_id,
                            stage="parse_reactant_child",
                            message=str(exc),
                            reaction_step=step,
                            reaction_node_path=child_path,
                            target=parent_molecule,
                        )
                    )
                    continue

                exact_reactants = [
                    index
                    for index in _exact_indexes(reaction.reactants, child_molecule)
                    if index not in used_reactants
                ]
                if len(exact_reactants) == 1:
                    used_reactants.add(exact_reactants[0])
                else:
                    state_reactants = [
                        index
                        for index in _mapped_skeleton_indexes(
                            reaction.reactants,
                            child_molecule,
                        )
                        if index not in used_reactants
                    ]
                    graph_reactants = [
                        index
                        for index in _graph_indexes(
                            reaction.reactants,
                            child_molecule,
                        )
                        if index not in used_reactants
                    ]
                    if state_reactants:
                        stage = "reactant_child_atom_state_mismatch"
                        message = (
                            "reaction reactant and route child preserve the "
                            "exact mapped skeleton but differ in atom state"
                        )
                    elif graph_reactants:
                        stage = "reactant_child_map_mismatch"
                        message = (
                            "reaction reactant matches the route child "
                            "constitutionally but not by persistent mapped topology"
                        )
                    else:
                        stage = "reactant_child_graph_mismatch"
                        message = (
                            "route child does not match an unused reaction "
                            "reactant molecular graph"
                        )
                    issues.append(
                        _issue(
                            dataset=dataset,
                            route_id=route_id,
                            stage=stage,
                            message=message,
                            reaction_step=step,
                            reaction_node_path=child_path,
                            target=child_molecule,
                        )
                    )
                visit_molecule(molecule_child, child_path)

    visit_molecule(route, ())
    return issues, reaction_index - 1


def _load_route_cgr_backend() -> tuple[Any, Any, Any]:
    from synplan.chem.reaction.routes.representation.sb_cgr import compose_sb_cgr

    from route_inspector.routes.synplanner import build_route_cgr, make_route_cgr_dict

    return make_route_cgr_dict, build_route_cgr, compose_sb_cgr


def validate_route_cgr_target(
    route_id: Any,
    route: dict[str, Any],
    *,
    dataset: str = "",
    backend: tuple[Any, Any, Any] | None = None,
) -> list[dict[str, Any]]:
    """Compose RouteCGR/SB-CGR and verify its mapped product-side target."""

    reaction_step = _reaction_span(route)

    target_smiles = routes.molecule_node_mapped_smiles(
        route
    ) or routes.molecule_node_smiles(route)
    try:
        target = chemistry.parse_molecule(target_smiles)
    except Exception as exc:
        return [
            _issue(
                dataset=dataset,
                route_id=route_id,
                stage="parse_route_target",
                message=str(exc),
                reaction_step=reaction_step,
            )
        ]

    make_dict, build_route_cgr, compose_sb_cgr = backend or _load_route_cgr_backend()
    try:
        reaction_routes = make_dict({0: route})
        if not reaction_routes.get(0):
            return [
                _issue(
                    dataset=dataset,
                    route_id=route_id,
                    stage="route_cgr_empty_route",
                    message="route has no reactions to compose",
                    reaction_step=reaction_step,
                    target=target,
                )
            ]
        build_result = build_route_cgr(reaction_routes, 0)
        if not getattr(build_result, "ok", False):
            diagnostic = getattr(build_result, "diagnostic", None)
            message = getattr(
                diagnostic,
                "message",
                "SynPlanner did not produce a RouteCGR",
            )
            return [
                _issue(
                    dataset=dataset,
                    route_id=route_id,
                    stage="compose_route_cgr",
                    message=message,
                    reaction_step=reaction_step,
                    target=target,
                )
            ]
        sb_cgr = compose_sb_cgr(build_result.cgr)
    except Exception as exc:
        return [
            _issue(
                dataset=dataset,
                route_id=route_id,
                stage="compose_route_cgr_or_sb_cgr",
                message=f"{type(exc).__qualname__}: {exc}",
                reaction_step=reaction_step,
                target=target,
            )
        ]

    target_ids = set(_map_ids(target))
    sb_ids = set(_map_ids(sb_cgr))
    if target_ids != sb_ids:
        missing = sorted(target_ids - sb_ids)
        extra = sorted(sb_ids - target_ids)
        return [
            _issue(
                dataset=dataset,
                route_id=route_id,
                stage="sb_cgr_target_map_id_set_mismatch",
                message=(
                    "SB-CGR product-side target map IDs differ from the route "
                    f"target; missing={missing}, extra={extra}"
                ),
                reaction_step=reaction_step,
                target=target,
                sb_target=sb_cgr,
            )
        ]

    atom_identity_mismatches = []
    electronic_state_mismatches = []
    for atom_id in sorted(target_ids):
        target_atom = target.atom(atom_id)
        sb_atom = sb_cgr.atom(atom_id)
        if (
            target_atom.atomic_number,
            target_atom.isotope,
        ) != (
            sb_atom.atomic_number,
            sb_atom.isotope,
        ):
            atom_identity_mismatches.append(atom_id)
        if (
            target_atom.charge != sb_cgr._p_charges[atom_id]
            or target_atom.is_radical != sb_cgr._p_radicals[atom_id]
        ):
            electronic_state_mismatches.append(atom_id)

    issues: list[dict[str, Any]] = []
    if atom_identity_mismatches:
        issues.append(
            _issue(
                dataset=dataset,
                route_id=route_id,
                stage="sb_cgr_target_atom_identity_mismatch",
                message=(
                    "SB-CGR product-side element/isotope differs at maps "
                    + ",".join(map(str, atom_identity_mismatches))
                ),
                reaction_step=reaction_step,
                target=target,
                sb_target=sb_cgr,
            )
        )
    if electronic_state_mismatches:
        issues.append(
            _issue(
                dataset=dataset,
                route_id=route_id,
                stage="sb_cgr_target_electronic_state_mismatch",
                message=(
                    "SB-CGR product-side charge/radical differs at maps "
                    + ",".join(map(str, electronic_state_mismatches))
                ),
                reaction_step=reaction_step,
                target=target,
                sb_target=sb_cgr,
            )
        )

    target_bonds = _mapped_bond_orders(target)
    sb_bonds = _sb_product_bond_orders(sb_cgr)
    if target_bonds != sb_bonds:
        changed_bonds = sorted(
            bond
            for bond in set(target_bonds) | set(sb_bonds)
            if target_bonds.get(bond) != sb_bonds.get(bond)
        )
        issues.append(
            _issue(
                dataset=dataset,
                route_id=route_id,
                stage="sb_cgr_target_bond_mismatch",
                message=(
                    "SB-CGR product-side mapped bond endpoints/orders differ "
                    f"for {changed_bonds}"
                ),
                reaction_step=reaction_step,
                target=target,
                sb_target=sb_cgr,
            )
        )
    return issues


@dataclass(frozen=True)
class RouteMappingValidationResult:
    """Dataset-level strict mapping-validation results."""

    dataset: str
    routes_seen: int
    reactions_seen: int
    records: tuple[dict[str, Any], ...]
    passed_route_ids: tuple[str, ...]

    def summary(self) -> dict[str, Any]:
        failed_route_ids = sorted(
            {
                str(record["route_id"])
                for record in self.records
                if str(record["route_id"]) not in {"", "*"}
            },
            key=_route_id_sort_key,
        )
        by_stage = Counter(record["stage"] for record in self.records)
        return {
            "dataset": self.dataset,
            "routes_seen": self.routes_seen,
            "reactions_seen": self.reactions_seen,
            "routes_passed": len(self.passed_route_ids),
            "routes_failed": len(failed_route_ids),
            "validation_failures": len(self.records),
            "failures_by_stage": dict(sorted(by_stage.items())),
            "failed_route_ids": failed_route_ids,
            "definition": (
                "A route passes only when every raw reactant and product atom has "
                "one explicit positive map ID, IDs are unique per reaction side "
                "and element/isotope-consistent across the arrow, every represented "
                "tree edge preserves exact mapped graph and atom state, and the "
                "SynPlanner RouteCGR reduced to SB-CGR preserves the target's "
                "product-side map IDs, atom identities, electronic state, and "
                "mapped bonds."
            ),
        }


def validate_routes_mapping(
    routes_json: Any,
    *,
    dataset: str = "",
    backend: tuple[Any, Any, Any] | None = None,
    allow_stereo_only_reactions: bool = False,
    edge_cache: dict | None = None,
) -> RouteMappingValidationResult:
    """Validate raw maps, exact edges, and RouteCGR-to-SB-CGR target recovery."""

    records: list[dict[str, Any]] = []
    passed: list[str] = []
    routes_seen = 0
    reactions_seen = 0
    dependency_error: Exception | None = None
    if backend is None:
        try:
            backend = _load_route_cgr_backend()
        except Exception as exc:
            dependency_error = exc

    for route_id, route in routes.route_items(routes_json):
        routes_seen += 1
        route_records, reaction_count = validate_route_edges(
            route_id,
            route,
            dataset=dataset,
            allow_stereo_only_reactions=allow_stereo_only_reactions,
            positive_cache=edge_cache,
        )
        reactions_seen += reaction_count
        raw_mapping_failed = any(
            str(record.get("stage", "")).startswith("raw_reaction_")
            for record in route_records
        )
        if raw_mapping_failed:
            # Do not hand an unsafe reaction to RouteCGR/SB-CGR, whose parser can
            # otherwise manufacture atom numbers and obscure the original defect.
            pass
        elif dependency_error is not None:
            route_records.append(
                _issue(
                    dataset=dataset,
                    route_id=route_id,
                    stage="route_cgr_dependency_error",
                    message=(
                        f"{type(dependency_error).__qualname__}: {dependency_error}"
                    ),
                    reaction_step=(
                        "r1"
                        if reaction_count == 1
                        else f"r1-r{reaction_count}"
                        if reaction_count > 1
                        else ""
                    ),
                )
            )
        else:
            route_records.extend(
                validate_route_cgr_target(
                    route_id,
                    route,
                    dataset=dataset,
                    backend=backend,
                )
            )
        if route_records:
            records.extend(route_records)
        else:
            passed.append(str(route_id))

    records.sort(
        key=lambda record: (
            _route_id_sort_key(record["route_id"]),
            record["reaction_step"],
            record["stage"],
        )
    )
    return RouteMappingValidationResult(
        dataset=dataset,
        routes_seen=routes_seen,
        reactions_seen=reactions_seen,
        records=tuple(records),
        passed_route_ids=tuple(sorted(passed, key=_route_id_sort_key)),
    )


def write_route_mapping_validation(
    result: RouteMappingValidationResult,
    path: Path,
) -> dict[str, Any]:
    """Write failure-level validation evidence and return its summary."""

    def rows() -> Iterable[dict[str, Any]]:
        for record in result.records:
            row = {}
            for field in ROUTE_MAPPING_VALIDATION_FIELDS:
                value = record.get(field, "")
                if isinstance(value, (list, tuple, dict)):
                    value = json.dumps(value, sort_keys=True, separators=(",", ":"))
                row[field] = value
            yield row

    write_tsv(path, ROUTE_MAPPING_VALIDATION_FIELDS, rows())
    summary = result.summary()
    summary["validation_file"] = str(path)
    return summary


__all__ = [
    "ROUTE_MAPPING_VALIDATION_FIELDS",
    "RouteMappingValidationError",
    "RouteMappingValidationResult",
    "validate_route_cgr_target",
    "validate_route_edges",
    "validate_raw_reaction_atom_mapping",
    "validate_raw_route_reaction_mapping",
    "validate_routes_mapping",
    "write_route_mapping_validation",
]
