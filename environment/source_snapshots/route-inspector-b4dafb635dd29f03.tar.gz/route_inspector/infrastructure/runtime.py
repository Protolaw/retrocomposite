"""Runtime cache setup and process metadata without domain dependencies."""

from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path

from route_inspector.infrastructure.paths import PROJECT_ROOT


def setup_runtime_cache_dirs() -> None:
    """Create runtime cache directories used by plotting and chemistry dependencies.

    Keeping this helper in the IO layer avoids duplicating low-level file and table
    behavior in the chemistry-focused modules.
    """
    cache_root = Path(tempfile.gettempdir()) / "route-inspector"
    os.environ.setdefault("MPLCONFIGDIR", str(cache_root / "matplotlib"))
    os.environ.setdefault("XDG_CACHE_HOME", str(cache_root / "cache"))
    Path(os.environ["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)
    Path(os.environ["XDG_CACHE_HOME"]).mkdir(parents=True, exist_ok=True)


def normalize_n_cpu(n_cpu: int | None) -> int:
    """Normalize n CPU for route-inspector processing.

    Keeping this helper in the IO layer avoids duplicating low-level file and table
    behavior in the chemistry-focused modules.
    """
    if n_cpu is None:
        return 1
    n_cpu = int(n_cpu)
    if n_cpu == 0:
        return os.cpu_count() or 1
    return max(1, n_cpu)


def git_commit_hash(*, project_root: Path = PROJECT_ROOT) -> str:
    """Return this source checkout's commit, never an ancestor repository's."""

    # Git searches parent directories.  An installed wheel inside an unrelated
    # repository or virtual environment must not inherit that repository's HEAD.
    if not (project_root / ".git").exists():
        return ""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=project_root,
            check=False,
            capture_output=True,
            text=True,
        )
    except Exception:
        return ""
    if result.returncode != 0:
        return ""
    return result.stdout.strip()
