"""Filesystem publication primitives; domain error contracts stay with callers."""

from __future__ import annotations

import ctypes
import errno
import logging
import os
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any

_AT_FDCWD = -100
_RENAME_NOREPLACE = 1
_RENAME_EXCL = 4


def publish_directory_no_replace(source: Path, destination: Path) -> None:
    """Atomically publish a directory while refusing an existing target."""

    if os.name == "nt":
        # Windows rename already has no-replace behavior.
        os.rename(source, destination)
        return
    libc = ctypes.CDLL(None, use_errno=True)
    darwin = sys.platform == "darwin"
    rename = getattr(libc, "renamex_np" if darwin else "renameat2", None)
    if rename is None:
        raise OSError(
            errno.ENOSYS,
            "atomic no-replace directory publication is unsupported",
            str(destination),
        )
    rename.argtypes = (
        (ctypes.c_char_p, ctypes.c_char_p, ctypes.c_uint)
        if darwin
        else (
            ctypes.c_int,
            ctypes.c_char_p,
            ctypes.c_int,
            ctypes.c_char_p,
            ctypes.c_uint,
        )
    )
    rename.restype = ctypes.c_int
    arguments = (
        (os.fsencode(source), os.fsencode(destination), _RENAME_EXCL)
        if darwin
        else (
            _AT_FDCWD,
            os.fsencode(source),
            _AT_FDCWD,
            os.fsencode(destination),
            _RENAME_NOREPLACE,
        )
    )
    result = rename(*arguments)
    if result == 0:
        return
    error_number = ctypes.get_errno()
    if error_number in (errno.EEXIST, errno.ENOTEMPTY):
        raise FileExistsError(
            error_number,
            "destination already exists",
            str(destination),
        )
    raise OSError(error_number, os.strerror(error_number), str(destination))


def atomic_text_path(path: Path) -> tuple[Path, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    stream = os.fdopen(descriptor, "w", encoding="utf-8", newline="")
    return Path(name), stream


def publish_files_with_rollback(files: list[tuple[Path, Path]]) -> None:
    """Replace a staged file set, restoring prior files on a caught failure.

    Callers must serialize writers and finish generating every source first.
    Each replacement is atomic, but unrelated paths cannot provide simultaneous
    visibility or a power-loss transaction. Staged files must be on the same
    filesystem as their destination. Recovery backups survive a failed rollback.
    """
    sources = {source.resolve() for source, _target in files}
    targets = [target.resolve() for _source, target in files]
    if (
        len(sources) != len(files)
        or len(set(targets)) != len(targets)
        or sources.intersection(targets)
    ):
        raise ValueError("publication sources and destinations must be distinct")
    for source, target in files:
        if not source.is_file() or source.is_symlink():
            raise ValueError(f"publication source is not a regular file: {source}")
        if target.is_symlink():
            raise ValueError(f"publication destination is a symlink: {target}")
        if target.exists() and not target.is_file():
            raise ValueError(f"publication destination is not a regular file: {target}")

    backups: dict[Path, Path | None] = {}
    backup_dirs: list[Path] = []
    published: list[Path] = []
    keep_backups = False
    try:
        # Prepare recovery copies for the whole set before replacing anything.
        for _source, target in files:
            target.parent.mkdir(parents=True, exist_ok=True)
            backups[target] = None
            if target.exists():
                directory = Path(
                    tempfile.mkdtemp(
                        prefix=f".{target.name}.rollback-", dir=target.parent
                    )
                )
                backup_dirs.append(directory)
                backup = directory / "previous"
                try:
                    os.link(target, backup)
                except OSError:
                    shutil.copy2(target, backup)
                backups[target] = backup
        for source, target in files:
            os.replace(source, target)
            published.append(target)
    except BaseException as failure:
        recovery_errors = []
        for target in reversed(published):
            try:
                backup = backups[target]
                if backup is None:
                    target.unlink()
                else:
                    os.replace(backup, target)
            except OSError as error:
                recovery_errors.append(f"{target}: {error}")
        if recovery_errors:
            keep_backups = True
            raise RuntimeError(
                "publication rollback failed; recovery backups retained in "
                f"{backup_dirs}: {'; '.join(recovery_errors)}"
            ) from failure
        raise
    finally:
        if not keep_backups:
            for directory in backup_dirs:
                try:
                    (directory / "previous").unlink(missing_ok=True)
                    directory.rmdir()
                except OSError:
                    logging.getLogger(__name__).warning(
                        "Could not remove publication backup directory %s", directory
                    )
