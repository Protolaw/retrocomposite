"""Durable, exclusively owned library workspaces and bounded application caches."""

from __future__ import annotations

import fcntl
import json
import os
import shutil
import sys
import tempfile
from collections import OrderedDict
from contextvars import ContextVar
from dataclasses import fields, is_dataclass
from decimal import Decimal
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

BUFFER_BUDGET = ContextVar("library_buffer_budget", default=512 * 1024 * 1024)


def runtime_versions():
    result = {"python": f"{sys.version_info.major}.{sys.version_info.minor}"}
    for name in ("chython-synplan", "SynPlanner"):
        try:
            result[name] = version(name)
        except PackageNotFoundError:
            result[name] = "unavailable"
    return result


def retained_size(value):
    """Count Python containers and their contents once, including UTF-8 keys."""
    seen = set()

    def size(obj):
        key = id(obj)
        if key in seen:
            return 0
        seen.add(key)
        total = sys.getsizeof(obj)
        if is_dataclass(obj) and not isinstance(obj, type):
            total += sum(size(getattr(obj, f.name)) for f in fields(obj))
        elif isinstance(obj, dict):
            total += sum(size(k) + size(v) for k, v in obj.items())
        elif isinstance(obj, (tuple, list, set, frozenset)):
            total += sum(size(v) for v in obj)
        return total

    return size(value)


class ByteMemo:
    """A callable LRU that never retains an object exceeding its byte budget."""

    def __init__(self, function, *, max_bytes=None):
        self.function = function
        self.max_bytes = (
            min(16 * 1024 * 1024, BUFFER_BUDGET.get() // 16)
            if max_bytes is None
            else max_bytes
        )
        self.values = OrderedDict()
        self.bytes = 0

    def __call__(self, *args):
        if args in self.values:
            value, size = self.values.pop(args)
            self.values[args] = (value, size)
            return value
        value = self.function(*args)
        size = retained_size((args, value))
        if size <= self.max_bytes:
            while self.values and self.bytes + size > self.max_bytes:
                _, (_, old) = self.values.popitem(last=False)
                self.bytes -= old
            self.values[args] = (value, size)
            self.bytes += size
        return value

    def cache_clear(self):
        self.values.clear()
        self.bytes = 0


def check_disk_headroom(path, required_bytes=None):
    required = (
        max(256 * 1024 * 1024, 2 * BUFFER_BUDGET.get())
        if required_bytes is None
        else required_bytes
    )
    if shutil.disk_usage(path).free < required:
        raise OSError(
            f"insufficient disk headroom; checkpoint retained at {path}; free space and resume"
        )


def _fingerprint_value(value):
    if isinstance(value, Decimal):
        return {"decimal": str(value)}
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"unsupported build fingerprint value: {type(value).__name__}")


class BuildWorkspace:
    """Checkpoint metadata stays outside the atomically published directory."""

    def __init__(
        self, output, *, work_dir=None, resume=False, memory_budget_mb=512, fingerprint
    ):
        if memory_budget_mb < 32:
            raise ValueError("memory budget must be at least 32 MiB")
        self.output = Path(output).expanduser()
        self.root = (
            Path(work_dir)
            if work_dir is not None
            else self.output.parent / f".{self.output.name}.build"
        )
        self.publication = self.root / "publication"
        self.resume = resume
        self.budget = int(memory_budget_mb) * 1024 * 1024
        self.fingerprint = json.loads(
            json.dumps(
                {"version": 1, "runtime": runtime_versions(), "inputs": fingerprint},
                sort_keys=True,
                default=_fingerprint_value,
            )
        )
        self.state = {}
        self.lock = None
        self.token = None

    def __enter__(self):
        if self.output.exists():
            raise FileExistsError(self.output)
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock = (self.root / "build.lock").open("a+")
        try:
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            state = self.root / "state.json"
            if state.exists():
                self.state = json.loads(state.read_text())
                if not self.resume:
                    raise FileExistsError(
                        f"build workspace exists; use --resume: {self.root}"
                    )
                if self.state["fingerprint"] != self.fingerprint:
                    if (
                        "input_content_sha256" in self.fingerprint["inputs"]
                        and "input_content_sha256"
                        not in self.state["fingerprint"]["inputs"]
                    ):
                        raise ValueError(
                            "build resume checkpoint lacks a verified input content fingerprint; "
                            f"checkpoint retained at {self.root}; use a new work directory"
                        )
                    raise ValueError(
                        "build resume fingerprint differs from source, configuration, algorithm or chemistry runtime"
                    )
            else:
                if self.resume:
                    raise ValueError(f"no checkpoint to resume: {self.root}")
                self.state = {"fingerprint": self.fingerprint, "completed": []}
                self.checkpoint()
            self.publication.mkdir(exist_ok=True)
            self.token = BUFFER_BUDGET.set(self.budget)
            self.check_space()
            return self
        except BaseException:
            if self.token is not None:
                BUFFER_BUDGET.reset(self.token)
                self.token = None
            self.lock.close()
            raise

    def check_space(self, required_bytes=None):
        check_disk_headroom(
            self.root,
            max(256 * 1024 * 1024, 2 * self.budget)
            if required_bytes is None
            else required_bytes,
        )

    def done(self, phase):
        return phase in self.state["completed"]

    def checkpoint(self, phase=None):
        if phase is not None and phase not in self.state["completed"]:
            self.state["completed"].append(phase)
        fd, path = tempfile.mkstemp(prefix=".state-", dir=self.root)
        try:
            with os.fdopen(fd, "w") as stream:
                json.dump(self.state, stream, sort_keys=True, indent=2)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(path, self.root / "state.json")
        finally:
            Path(path).unlink(missing_ok=True)

    def __exit__(self, *exc):
        if self.token is not None:
            BUFFER_BUDGET.reset(self.token)
        if self.lock is not None:
            self.lock.close()
