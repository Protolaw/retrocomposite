"""Filesystem location helpers independent of artifact and dataset policy."""

from __future__ import annotations

import os
import shlex
import sys
from pathlib import Path
from typing import Any

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = PACKAGE_ROOT.parent
WORKSPACE_ROOT = PROJECT_ROOT.parent


def relative_path(value: str | Path, *, base_dir: Path = PROJECT_ROOT) -> str:
    """Serialize a path relative to the project root (or a supplied base)."""
    if isinstance(value, str) and not value:
        return ""
    path = Path(value)
    if not path.is_absolute():
        return str(path)
    try:
        return os.path.relpath(path, start=base_dir)
    except (OSError, ValueError):
        return str(path)


def relativeize_paths(value: Any, *, base_dir: Path = PROJECT_ROOT) -> Any:
    """Recursively convert absolute path values to relative strings."""
    if isinstance(value, Path):
        return relative_path(value, base_dir=base_dir)
    if isinstance(value, dict):
        return {
            key: relativeize_paths(item, base_dir=base_dir)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple, set)):
        return [relativeize_paths(item, base_dir=base_dir) for item in value]
    if isinstance(value, str) and Path(value).is_absolute():
        return relative_path(value, base_dir=base_dir)
    return value


def resolve_output_path(
    *,
    output: Path | None,
    output_dir: Path | None,
    default_filename: str,
) -> Path:
    """Resolve explicit file output or directory-based default output path."""
    if output is not None:
        return Path(output).expanduser()
    if output_dir is None:
        raise ValueError("either --output or --output-dir is required")
    return Path(output_dir).expanduser() / default_filename


def cli_command_text(
    argv: list[str] | None = None,
    *,
    base_dir: Path = PROJECT_ROOT,
) -> str:
    """Return a shell-escaped command line with relative path arguments."""
    argv = list(sys.argv if argv is None else argv)
    normalized: list[str] = []
    for part in argv:
        if "=" in part and part.startswith("-"):
            option, value = part.split("=", 1)
            if Path(value).is_absolute():
                part = f"{option}={relative_path(value, base_dir=base_dir)}"
        elif Path(part).is_absolute():
            part = relative_path(part, base_dir=base_dir)
        normalized.append(part)
    return " ".join(shlex.quote(part) for part in normalized)


def resolve_existing_path(
    path: str | Path,
    *,
    package_root: Path = PACKAGE_ROOT,
    project_root: Path = PROJECT_ROOT,
    workspace_root: Path = WORKSPACE_ROOT,
) -> Path:
    """Resolve a user, checkout-relative, or packaged resource path.

    Built-in ``route_inspector/configs/...`` paths resolve inside the installed
    package even without a checkout. Existing user files take precedence.
    The legacy ``configs/...`` spelling remains a compatibility alias for saved
    workflows; it does not require a second configuration directory.
    """
    path = Path(path).expanduser()
    if path.exists() or path.is_absolute():
        return path

    candidates = [Path.cwd() / path]
    if path.parts[:2] == ("route_inspector", "configs"):
        candidates.append(package_root.joinpath(*path.parts[1:]))
    candidates.extend(
        [
            package_root / path,
            project_root / path,
            workspace_root / path,
        ]
    )
    if path.parts and path.parts[0] == project_root.name:
        candidates.append(project_root.joinpath(*path.parts[1:]))

    for candidate in candidates:
        if candidate.exists():
            return candidate
    return path
