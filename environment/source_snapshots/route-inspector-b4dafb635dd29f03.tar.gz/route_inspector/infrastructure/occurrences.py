"""Read occurrence records from portable JSON, JSONL, and gzip containers."""

from __future__ import annotations

import gzip
import json
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

from route_inspector.infrastructure.paths import resolve_existing_path


def iter_occurrence_mappings(path: str | Path) -> Iterable[dict[str, Any]]:
    """Read exact occurrence mappings from JSON arrays/wrappers or JSONL."""

    source = resolve_existing_path(Path(path))
    logical_name = source.name[:-3] if source.name.endswith(".gz") else source.name
    opener = gzip.open if source.suffix == ".gz" else open
    if logical_name.endswith(".json"):
        with opener(source, "rt", encoding="utf-8") as stream:
            value = json.load(stream)
        if isinstance(value, list):
            records = value
        elif isinstance(value, Mapping):
            records = next(
                (
                    value[field]
                    for field in ("occurrences", "records")
                    if isinstance(value.get(field), list)
                ),
                None,
            )
            if records is None:
                raise ValueError(f"unrecognized occurrence JSON container: {source}")
        else:
            raise ValueError(f"occurrence JSON must contain records: {source}")
        for index, record in enumerate(records):
            if not isinstance(record, Mapping):
                raise ValueError(f"expected an occurrence object at {source}[{index}]")
            yield dict(record)
        return

    with opener(source, "rt", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            if not line.strip():
                continue
            record = json.loads(line)
            if not isinstance(record, Mapping):
                raise ValueError(f"expected an object at {source}:{line_number}")
            yield dict(record)
