from __future__ import annotations

import csv
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from route_inspector import __version__
from route_inspector.infrastructure.paths import (
    cli_command_text,
    relative_path,
    relativeize_paths,
)
from route_inspector.infrastructure.text import (
    increase_csv_field_limit,
    json_safe,
    write_tsv,
)

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = PACKAGE_ROOT.parent
WORKSPACE_ROOT = PROJECT_ROOT.parent

STAGE_DIRS = {
    "preprocess": "00_preprocess",
    "rrseq_cons": "10_rrseq_cons",
    "rrseq_gap": "11_rrseq_gap",
    "rrseq_gap_classification": "12_rrseq_gap_classification",
    "retro_bleu": "13_retro_bleu",
    "route_motifs": "14_route_motifs",
    "gapped_composite_rules": "21_gapped_composite_rules",
    "composite_rules": "20_composite_rules",
    "composite_classification": "30_composite_classification",
    "rxnclass_rrseqs": "31_rxnclass_rrseqs",
    "scoring": "40_scoring",
    "protection_analysis": "50_protection_analysis",
    "protection_interval_rxnclass": "51_protection_interval_rxnclass",
    "context_history": "60_context_history",
    "reference_index": "61_reference_index",
    "generated_route_inspection": "62_generated_route_inspection",
    "reference_library": "reference_libraries",
    "composite_library": "composite_libraries",
    "route_assessment": "64_route_assessment",
    "reference_route_assessment": "67_route_assessment",
    "counterfactual_reassembly": "counterfactual_reassembly",
}


increase_csv_field_limit()


def write_json(path: Path, data: Any) -> None:
    """Write JSON to disk.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    if Path(path).name == "summary.json":
        data = relativeize_paths(data)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(data, file, indent=2)


def dataset_prefix_from_path(path: str | Path) -> str:
    """Infer a compact dataset prefix from route or artifact paths."""
    path = Path(path)
    stem = path.stem
    for pattern in (
        r"[-_]?routes$",
        r"_classified_composite_rules$",
        r"_composite_rules$",
        r"_composite_reactions$",
        r"_composite_rule_collection_summary$",
        r"_composite_rule_collection_errors$",
        r"_composite_rule_classification_summary$",
        r"_rrseq_(?:cons|gap)_extraction_summary$",
        r"_rrseq_(?:cons|gap)_occurrences$",
        r"_rrseq_occurrences$",
        r"_rrseq_extraction_summary$",
        r"_routes_without_rrseq_(?:cons|gap)$",
        r"_routes_without_rrseqs$",
        r"_t\d+_rrseq_(?:cons|gap)$",
        r"_t\d+_rrseqs$",
        r"_t\d+_single_rules$",
        r"_protection_.+$",
    ):
        stem = re.sub(pattern, "", stem)
    return stem or path.stem or "dataset"


def stage_output_dir(output_root: Path, dataset: str, stage: str) -> Path:
    """Return the standard dataset-first, stage-second output directory."""
    stage_name = STAGE_DIRS.get(stage, stage)
    return Path(output_root).expanduser() / dataset / stage_name


def route_inspector_version() -> str:
    """Return the package version used by CLI and persisted manifests."""

    return __version__


def write_manifest(
    output_dir: Path,
    *,
    command_name: str,
    input_files: Iterable[str | Path] = (),
    output_files: Iterable[str | Path] | dict[str, str | Path] = (),
    config_path: str | Path | None = None,
    cli_args: Any | None = None,
    argv: list[str] | None = None,
    extra: dict[str, Any] | None = None,
) -> Path:
    """Write a standard manifest sidecar for a command output directory."""
    output_dir = Path(output_dir)
    if isinstance(output_files, dict):
        output_files_value = {
            key: relative_path(value) for key, value in sorted(output_files.items())
        }
    else:
        output_files_value = [relative_path(path) for path in output_files]
    manifest = {
        "command_name": command_name,
        "full_cli_command": cli_command_text(argv, base_dir=PROJECT_ROOT),
        "input_files": [relative_path(path) for path in input_files],
        "output_directory": relative_path(output_dir),
        "output_files": output_files_value,
        "config_path": relative_path(config_path) if config_path else None,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "route_inspector_version": route_inspector_version(),
        "cli_args": (
            relativeize_paths(
                json_safe(
                    {
                        key: value
                        for key, value in sorted(vars(cli_args).items())
                        if not callable(value)
                    }
                )
            )
            if cli_args is not None
            else None
        ),
        **(extra or {}),
    }
    manifest = relativeize_paths(manifest)
    path = output_dir / "manifest.json"
    write_json(path, manifest)
    return path


def write_errors_tsv(
    path: Path,
    errors: Iterable[dict[str, Any]],
    *,
    fieldnames: list[str] | None = None,
) -> Path:
    """Write generic tabular error sidecar, including an empty file header."""
    rows = list(errors)
    base_fields = fieldnames or ["route_id", "stage", "error_type", "message"]
    extra_fields = sorted(
        {key for row in rows for key in row if key not in base_fields}
    )
    all_fields = base_fields + extra_fields
    write_tsv(path, all_fields, rows)
    return path


def write_summary_sidecar(output_dir: Path, summary: dict[str, Any]) -> Path:
    """Write the sole summary.json sidecar for a command output directory."""
    path = Path(output_dir) / "summary.json"
    write_json(path, summary)
    return path


def write_standard_sidecars(
    output_dir: Path,
    *,
    command_name: str,
    summary: dict[str, Any],
    errors: Iterable[dict[str, Any]] = (),
    error_fieldnames: list[str] | None = None,
    input_files: Iterable[str | Path] = (),
    output_files: Iterable[str | Path] | dict[str, str | Path] = (),
    config_path: str | Path | None = None,
    cli_args: Any | None = None,
    argv: list[str] | None = None,
    extra_manifest: dict[str, Any] | None = None,
) -> dict[str, str]:
    """Write generic summary, errors, and manifest sidecars for a command."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    for stale_summary in output_dir.glob("*_summary.json"):
        if stale_summary.name != "summary.json":
            stale_summary.unlink()
    summary_path = write_summary_sidecar(output_dir, summary)
    errors_path = write_errors_tsv(
        output_dir / "errors.tsv",
        errors,
        fieldnames=error_fieldnames,
    )
    manifest_path = write_manifest(
        output_dir,
        command_name=command_name,
        input_files=input_files,
        output_files=output_files,
        config_path=config_path,
        cli_args=cli_args,
        argv=argv,
        extra=extra_manifest,
    )
    return {
        "summary": relative_path(summary_path),
        "errors": relative_path(errors_path),
        "manifest": relative_path(manifest_path),
    }


def resolve_file_or_dir_path(path: Path, default_filename: str) -> Path:
    """Resolve output path information for resolve file or dir path.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    if path.is_dir() or path.suffix == "":
        return path / default_filename
    return path


def split_cell(value: str | None) -> list[str]:
    """Split cell into normalized values.

    Keeping this helper in the IO layer avoids duplicating low-level file and table
    behavior in the chemistry-focused modules.
    """
    if not value:
        return []
    return [part.strip() for part in value.split(",") if part.strip()]


def reference_sort_key(value: Any) -> tuple[int, Any]:
    """Return a deterministic sort key for route references.

    Keeping this helper in the IO layer avoids duplicating low-level file and table
    behavior in the chemistry-focused modules.
    """
    if isinstance(value, int):
        return (0, value)
    if isinstance(value, str) and value.isdigit():
        return (0, int(value))
    return (1, str(value))


def rule_column(fieldnames: list[str], preferred: tuple[str, ...]) -> str:
    """Return rule column used for rule extraction or comparison.

    Keeping this helper in the IO layer avoids duplicating low-level file and table
    behavior in the chemistry-focused modules.
    """
    for candidate in preferred:
        if candidate in fieldnames:
            return candidate
    if fieldnames:
        return fieldnames[0]
    raise ValueError("TSV header is empty")


def read_rule_from_tsv(
    path: Path,
    row_index: int,
    *,
    columns: tuple[str, ...],
) -> str:
    """Read a selected rule string from a TSV row.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    with path.open(encoding="utf-8") as file:
        reader = csv.DictReader(file, delimiter="\t")
        fieldnames = reader.fieldnames or []
        column = None
        for candidate in columns:
            if candidate in fieldnames:
                column = candidate
                break
        if column is None:
            raise ValueError(f"{path} has none of these columns: {', '.join(columns)}")
        for index, row in enumerate(reader):
            if index == row_index:
                return row[column]
    raise IndexError(f"row index {row_index} not found in {path}")
