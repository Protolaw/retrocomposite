"""Low-level infrastructure with no scientific or dataset dependencies."""
