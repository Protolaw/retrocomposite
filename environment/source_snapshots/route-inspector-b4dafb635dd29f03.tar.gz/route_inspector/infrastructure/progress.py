"""Terminal progress formatting, independent of scientific workflows."""

import sys
import time


def render_progress(
    label: str,
    completed: int,
    total: int,
    started_at: float,
    *,
    workers: int,
) -> None:
    elapsed = max(time.monotonic() - started_at, 1e-9)
    fraction = completed / total if total else 1.0
    width = 28
    filled = min(width, int(width * fraction))
    bar = "#" * filled + "-" * (width - filled)
    rate = completed / elapsed
    ending = "\n" if completed >= total else ""
    print(
        f"\r[{label}] |{bar}| {completed:,}/{total:,} "
        f"({fraction:6.1%}) {rate:6.1f} routes/s "
        f"elapsed {elapsed:,.1f}s workers={workers}",
        end=ending,
        file=sys.stderr,
        flush=True,
    )
