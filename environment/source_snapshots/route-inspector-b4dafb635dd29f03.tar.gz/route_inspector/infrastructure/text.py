"""Plain/gzip text and TSV transport primitives; no scientific schemas."""

from __future__ import annotations

import csv
import gzip
import json
import sys
from pathlib import Path
from typing import Any, Iterable


def increase_csv_field_limit() -> None:
    """Raise the CSV parser field limit for large SMARTS and route fields.

    Keeping this helper in the IO layer avoids duplicating low-level file and table
    behavior in the chemistry-focused modules.
    """
    limit = sys.maxsize
    while True:
        try:
            csv.field_size_limit(limit)
            return
        except OverflowError:
            limit //= 10


def open_text(path: Path):
    """Open a plain-text or gzip-compressed file for reading.

    Keeping this helper in the IO layer avoids duplicating low-level file and table
    behavior in the chemistry-focused modules.
    """
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8")
    return path.open(encoding="utf-8")


def read_json(path: Path) -> Any:
    """Read JSON data from a plain or gzip-compressed file.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    with open_text(path) as file:
        return json.load(file)


def read_tsv_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    """Read a TSV header and row dictionaries from a tab-separated file.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    increase_csv_field_limit()
    with path.open(encoding="utf-8") as file:
        reader = csv.DictReader(file, delimiter="\t")
        return reader.fieldnames or [], list(reader)


def write_tsv(
    path: Path,
    fieldnames: list[str],
    rows: Iterable[dict[str, Any]],
) -> None:
    """Write TSV to disk.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def json_safe(value: Any) -> Any:
    """Return a JSON-serializable representation of common CLI values."""
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(item) for item in value]
    return str(value)
