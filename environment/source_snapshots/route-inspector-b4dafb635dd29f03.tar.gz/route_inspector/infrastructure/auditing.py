"""Audit-local reuse and progress, independent of GUI or publication formats."""

import hashlib
import pickle
import sqlite3
import tempfile
import time
import zlib
from collections import Counter, OrderedDict
from contextlib import contextmanager
from contextvars import ContextVar
from functools import lru_cache, wraps
from pathlib import Path

from route_inspector.infrastructure.build_workspace import retained_size

_current = ContextVar("library_audit", default=None)


class AuditContext:
    """Bounded hot cache; evicted results live only in private temporary storage.

    Pickles are produced and consumed by this process, never read from a library.
    Full keys are compared after digest lookup, including forced hash collisions.
    """

    def __init__(self, progress=None, max_bytes=64 * 1024 * 1024):
        self.progress = progress
        self.max_bytes = max_bytes
        self.hot = OrderedDict()
        self.bytes = 0
        self.metrics = Counter()
        self.scratch = self.db = None
        self.last_report = 0

    def report(self, phase, completed=None, total=None, *, force=False):
        now = time.monotonic()
        if self.progress and (force or now - self.last_report >= 0.25):
            self.last_report = now
            self.progress(dict(phase=phase, completed=completed, total=total))

    def _database(self):
        if self.db is None:
            self.scratch = tempfile.TemporaryDirectory(prefix="ri-audit-")
            self.db = sqlite3.connect(Path(self.scratch.name) / "reuse.sqlite")
            self.db.execute("PRAGMA cache_size=-4096")
            self.db.execute("CREATE TABLE reuse(digest TEXT,key BLOB,value BLOB)")
            self.db.execute("CREATE INDEX reuse_digest ON reuse(digest)")
        return self.db

    def remember(self, namespace, key, compute):
        encoded = pickle.dumps((namespace, key), protocol=5)
        if encoded in self.hot:
            value, size = self.hot.pop(encoded)
            self.hot[encoded] = value, size
            self.metrics["memory_hits"] += 1
            return value
        digest = hashlib.sha256(encoded).hexdigest()
        if self.db is not None:
            for old, packed in self.db.execute(
                "SELECT key,value FROM reuse WHERE digest=?", (digest,)
            ):
                if zlib.decompress(old) == encoded:
                    self.metrics["disk_hits"] += 1
                    return pickle.loads(zlib.decompress(packed))
        value = compute()  # Failed checks are never cached.
        self.metrics["computations"] += 1
        size = retained_size((encoded, value))
        while self.hot and self.bytes + size > self.max_bytes:
            old, (result, used) = self.hot.popitem(last=False)
            self.bytes -= used
            self._spill(old, result)
        if size <= self.max_bytes:
            self.hot[encoded] = value, size
            self.bytes += size
        else:
            self._spill(encoded, value)
        return value

    def _spill(self, key, value):
        self._database().execute(
            "INSERT INTO reuse VALUES(?,?,?)",
            (
                hashlib.sha256(key).hexdigest(),
                zlib.compress(key, 1),
                zlib.compress(pickle.dumps(value, protocol=5), 1),
            ),
        )

    def close(self):
        self.hot.clear()
        if self.db is not None:
            self.db.close()
            self.scratch.cleanup()


@contextmanager
def audit_context(progress=None, **kwargs):
    existing = _current.get()
    if existing is not None:
        yield existing
        return
    context = AuditContext(progress, **kwargs)
    token = _current.set(context)
    try:
        yield context
    finally:
        _current.reset(token)
        context.close()


def audit_scope(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        with audit_context():
            return function(*args, **kwargs)

    return wrapped


def audit_memo(function):
    """Reuse pure scientific calculations only within one immutable audit."""
    namespace = f"{function.__module__}.{function.__qualname__}"

    @wraps(function)
    def wrapped(*args, **kwargs):
        context = _current.get()
        if context is None:
            return function(*args, **kwargs)
        return context.remember(
            namespace, (args, kwargs), lambda: function(*args, **kwargs)
        )

    return wrapped


def audit_lru_cache(*, maxsize):
    """Keep existing interactive caching; use the bounded audit ledger in audits."""

    def decorate(function):
        cached = lru_cache(maxsize=maxsize)(function)
        audited = audit_memo(function)

        @wraps(function)
        def wrapped(*args, **kwargs):
            return (cached if _current.get() is None else audited)(*args, **kwargs)

        wrapped.cache_clear = cached.cache_clear
        wrapped.cache_info = cached.cache_info
        return wrapped

    return decorate


def audit_progress(phase, completed=None, total=None, *, force=False):
    context = _current.get()
    if context is not None:
        context.report(phase, completed, total, force=force)


def audit_remember(namespace, key, compute):
    context = _current.get()
    return compute() if context is None else context.remember(namespace, key, compute)


def audit_active():
    return _current.get() is not None
