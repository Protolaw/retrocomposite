"""Private worker result chunks: small queue messages, one decoded result at a time."""

from __future__ import annotations

import pickle
import tempfile
from collections import deque
from dataclasses import dataclass
from pathlib import Path

from route_inspector.infrastructure.build_workspace import BUFFER_BUDGET, retained_size
from route_inspector.infrastructure.hashing import sha256_file


@dataclass(frozen=True)
class Receipt:
    name: str
    sha256: str


def _run(task):
    function, item, root, budget = task
    token = BUFFER_BUDGET.set(budget)
    try:
        value = function(item)
    finally:
        BUFFER_BUDGET.reset(token)
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        prefix="result-", suffix=".pickle", dir=root, delete=False
    ) as stream:
        pickle.dump(value, stream, protocol=5)
        path = Path(stream.name)
    return Receipt(path.name, sha256_file(path))


def _load(receipt, root):
    path = Path(root) / receipt.name
    if (
        path.name != receipt.name
        or path.is_symlink()
        or sha256_file(path) != receipt.sha256
    ):
        raise ValueError("worker result chunk is damaged or outside its workspace")
    # Only this process pool writes these private chunks. This is deliberately
    # not a general-purpose loader for downloaded or user-supplied pickle files.
    with path.open("rb") as stream:
        result = pickle.load(stream)
    path.unlink()
    return result


def results(executor, function, items, root, *, workers):
    """Bound pending inputs by count and bytes; results stay on disk."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    pending = deque()
    used = 0
    budget = BUFFER_BUDGET.get() // 2
    for item in items:
        size = retained_size(item)
        while pending and (len(pending) >= 2 * workers or used + size > budget):
            future, weight = pending.popleft()
            used -= weight
            yield _load(future.result(), root)
        pending.append(
            (
                executor.submit(_run, (function, item, str(root), BUFFER_BUDGET.get())),
                size,
            )
        )
        used += size
    while pending:
        future, _ = pending.popleft()
        yield _load(future.result(), root)
