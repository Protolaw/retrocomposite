"""Byte-level file checksums, separate from scientific identity serialization."""

from __future__ import annotations

import hashlib
from pathlib import Path

from route_inspector.infrastructure.auditing import audit_progress


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    total, completed = path.stat().st_size, 0
    audit_progress(f"Checking file: {path.name}", 0, total, force=True)
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
            completed += len(block)
            audit_progress(f"Checking file: {path.name}", completed, total)
    return digest.hexdigest()


def file_record(path: Path) -> dict:
    return {"path": str(path), "sha256": sha256_file(path)}
