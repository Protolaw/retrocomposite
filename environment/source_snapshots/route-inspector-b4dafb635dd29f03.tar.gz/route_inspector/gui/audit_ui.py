"""Dataset preparation UI; audits never occupy the browsing executor."""

import asyncio

from nicegui import ui

from route_inspector.gui.audit_jobs import audit_jobs
from route_inspector.gui.verification import AuditRequired, rejected_snapshots


class AuditUI:
    def init_audits(self):
        self.audits = audit_jobs(self.workspace)
        self.audit_request = None
        self.audit_status = None
        self.audit_generation = 0
        self.audit_polling = False
        self.audit_lifecycle = asyncio.Lock()
        self.audit_activating = False
        self.audit_opened = None
        self.audit_opened_errors = {}
        self.verification_note = ""
        self.audit_return_screen = "modes"
        self.open_observations = ()
        self.snapshot_polling = False
        self.audit_timer = ui.timer(0.5, self.poll_dataset_audit)

    @ui.refreshable
    def audit_panel(self, dataset):
        """Initial loading belongs to its dataset card; rechecks stay silent."""
        status = self.audit_status
        if not status or status.get("dataset") != dataset or self.audit_opened:
            return
        with ui.column().classes("ri-dataset-loading w-full gap-1"):
            if status["state"] == "failed":
                ui.label(f"Could not prepare {dataset}").classes("text-negative")
                for reason in status.get("errors", {}).values():
                    ui.label(reason).classes("text-sm")
                ui.button(
                    "Retry loading", on_click=lambda: self.begin_dataset_audit(dataset)
                ).props("flat")
            elif status["state"] == "ready":
                ui.button(
                    "Open prepared dataset", on_click=self.activate_prepared_dataset
                )
            else:
                action = "Opening" if status["state"] == "opening" else "Preparing"
                ui.label(f"{action} {dataset}").classes("text-sm")
                ui.label(status.get("phase", "Checking saved verification")).classes(
                    "text-xs"
                )
                if status["state"] != "opening":
                    ui.button(
                        "Cancel loading", on_click=self.cancel_dataset_audit
                    ).props("flat")

    async def poll_open_snapshot(self):
        observations, info = self.open_observations, self.info
        if not observations or self.snapshot_polling or self.audit_activating:
            return
        self.snapshot_polling = True
        try:
            failures = await asyncio.to_thread(rejected_snapshots, observations)
            if not failures:
                return
            async with self.audit_lifecycle:
                if observations is not self.open_observations or info is not self.info:
                    return
                self.generation += 1
                self.proposal_generation += 1
                await self.call(self.service.close)
                self.open_observations = ()
                self.info = None
                self.view = {}
                self.screen = "datasets"
                self.verification_note = ""
                await self._cancel_dataset_audit(refresh=False)
                self.audit_status = dict(
                    state="failed", dataset=info["dataset_id"], errors=failures
                )
                self.error_label.set_text("; ".join(failures.values()))
                await self.body.refresh()
        finally:
            self.snapshot_polling = False

    async def begin_dataset_audit(self, dataset):
        await self.cancel_dataset_audit(refresh=False)
        self.audit_generation += 1
        generation = self.audit_generation
        self.loading_dataset = dataset
        self.error_label.set_text("")
        self.audit_status = dict(
            state="running", dataset=dataset, phase="Checking saved verification"
        )
        await self.audit_panel.refresh()
        try:
            token = await asyncio.to_thread(self.audits.request, dataset)
            if generation != self.audit_generation:
                await asyncio.to_thread(self.audits.release, token)
                return
            self.audit_request = token
            await self.poll_dataset_audit()
        except Exception as exc:
            if generation == self.audit_generation:
                self.error_label.set_text(str(exc))
                self.loading_dataset = None
                self.audit_status = dict(
                    state="failed", dataset=dataset, errors={"loading": str(exc)}
                )
                await self.audit_panel.refresh()

    async def poll_dataset_audit(self):
        await self.poll_open_snapshot()
        if self.audit_request is None or self.audit_polling or self.audit_activating:
            return
        token, generation = self.audit_request, self.audit_generation
        self.audit_polling = True
        try:
            status = await asyncio.to_thread(self.audits.poll, token)
            if generation != self.audit_generation or token != self.audit_request:
                return
            self.audit_status = status
            if self.audit_opened == token:
                failures = {
                    kind: reason
                    for kind, reason in status["errors"].items()
                    if self.audit_opened_errors.get(kind) != reason
                }
                if failures:
                    async with self.audit_lifecycle:
                        if (
                            generation != self.audit_generation
                            or token != self.audit_request
                        ):
                            return
                        await self.call(self.service.close)
                        self.info = None
                        self.open_observations = ()
                        self.generation += 1
                        self.screen = "datasets"
                        self.verification_note = ""
                        await self._cancel_dataset_audit(refresh=False)
                        self.audit_status = dict(
                            state="failed", dataset=status["dataset"], errors=failures
                        )
                        self.error_label.set_text("; ".join(failures.values()))
                        await self.body.refresh()
                        await self.audit_panel.refresh()
                    return
                if status["state"] == "ready":
                    async with self.audit_lifecycle:
                        if (
                            generation != self.audit_generation
                            or token != self.audit_request
                        ):
                            return
                        self.verification_note = (
                            "Original source verified · current library audits passed"
                        )
                        await self._cancel_dataset_audit(refresh=False)
                        await self.audit_panel.refresh()
                    return
            if status["state"] in {"ready", "failed"}:
                self.loading_dataset = None
            if status["state"] == "failed":
                self.error_label.set_text("; ".join(status["errors"].values()))
            await self.audit_panel.refresh()
            if (
                (status["state"] == "ready" or status.get("can_open"))
                and self.screen == "datasets"
                and self.audit_opened != token
            ):
                await self.activate_prepared_dataset()
        finally:
            self.audit_polling = False

    async def activate_prepared_dataset(self):
        async with self.audit_lifecycle:
            await self._activate_prepared_dataset()

    async def _activate_prepared_dataset(self):
        if (
            self.audit_activating
            or not self.audit_status
            or not (
                self.audit_status["state"] == "ready"
                or self.audit_status.get("can_open")
            )
            or self.audit_opened == self.audit_request
        ):
            return
        self.audit_activating = True
        token, generation = self.audit_request, self.audit_generation
        status = self.audit_status
        try:
            self.audit_status = {**status, "state": "opening"}
            await self.audit_panel.refresh()
            info = await self.call(
                self.service.open_dataset,
                status["dataset"],
                "ready" if status["state"] == "ready" else "snapshot",
                unavailable=status["errors"],
                expected_bindings=status["bindings"],
            )
            if generation != self.audit_generation or token != self.audit_request:
                return
            self.loading_dataset = None
            self.verification_note = (
                "Original source verified · current library audits passed"
                if status["state"] == "ready"
                else "Original source verified · unchanged previously audited libraries · "
                "updated validation pending"
            )
            await self.accept_dataset(info)
            self.open_observations = tuple(info.get("audit_observations", ()))
            # Render the destination before removing the loading panel. A failed
            # navigation must never leave an unexplained, idle dataset chooser.
            await self.body.refresh()
            if status["state"] == "ready":
                await self._cancel_dataset_audit(refresh=False)
            else:
                self.audit_opened = token
                self.audit_opened_errors = dict(status["errors"])
                self.audit_status = status
            await self.audit_panel.refresh()
        except AuditRequired as exc:
            # Do not silently fall back to a blocking audit after a snapshot race.
            await self._cancel_dataset_audit(refresh=False)
            self.audit_status = dict(
                state="failed",
                dataset=status["dataset"],
                errors={
                    "snapshot": f"Library verification changed: {exc}. Load the dataset again."
                },
            )
            await self.audit_panel.refresh()
        except Exception as exc:
            await self._cancel_dataset_audit(refresh=False)
            self.error_label.set_text(str(exc))
            self.audit_status = dict(
                state="failed", dataset=status["dataset"], errors={"loading": str(exc)}
            )
            await self.audit_panel.refresh()
        finally:
            self.audit_activating = False

    async def cancel_dataset_audit(self, *, refresh=True):
        async with self.audit_lifecycle:
            await self._cancel_dataset_audit(refresh=refresh)

    async def _cancel_dataset_audit(self, *, refresh=True):
        self.audit_generation += 1
        token, self.audit_request = self.audit_request, None
        self.loading_dataset = None
        self.audit_status = None
        self.audit_opened = None
        self.audit_opened_errors = {}
        if refresh:
            await self.audit_panel.refresh()
        if token is not None:
            await asyncio.to_thread(self.audits.release, token)
        if refresh:
            await self.body.refresh()

    async def return_to_loaded_dataset(self):
        if self.info:
            self.screen = self.audit_return_screen
            await self.body.refresh()
