"""Optional local browser UI. Importing this package does not import NiceGUI."""
