"""Conservative per-library validation dependencies, excluding build runners.

Mixed modules retain all definitions except reviewed construction-only helpers.
New validation modules in the listed directories are automatically fingerprinted.
"""

import ast
import hashlib
import sys
from importlib.metadata import PackageNotFoundError, version

SHARED = (
    "rules/*.py",
    "gui/verification.py",
    "gui/audit_dependencies.py",
    "gui/sources.py",
    "infrastructure/auditing.py",
    "infrastructure/hashing.py",
    "infrastructure/build_workspace.py",
    "routes/io.py",
    "routes/access.py",
    "reference_library/profile.py",
    "reference_library/models.py",
    "tactics/rrseq/gap_widths.py",
    "tactics/rrsubtree/models.py",
)
DEPENDENCIES = {
    "reference": (
        "reference_library/storage/*.py",
        "reference_library/identity/*.py",
        "reference_library/catalog.py",
        "reference_library/records.py",
        "reference_library/bigram_catalog.py",
        "reference_library/build/aggregation.py",
        "metrics/retro_bleu/bigrams.py",
    ),
    "pg": (
        "protection/strategies/*.py",
        "reference_library/identity/*.py",
    ),
    "composites": (
        "composite_rules/library.py",
        "composite_rules/identity.py",
        "composite_rules/families.py",
        "composite_rules/ring_breaking.py",
        "composite_rules/validation.py",
        "composite_rules/rrsubtree.py",
        "reference_library/storage/artifacts.py",
        "reference_library/storage/manifest.py",
    ),
}
EXCLUDED_FILES = {
    "reference_library/storage/writers.py",
    "reference_library/identity/audit.py",
    "protection/strategies/construction.py",
    "protection/strategies/reuse.py",
    "protection/strategies/staging.py",
    "protection/strategies/extraction.py",
}
# These modules also contain validation helpers. Do not exclude whole modules.
BUILD_DEFINITIONS = {
    "composite_rules/library.py": {
        "save",
        "build_composite_library",
        "_aggregate_results",
        "_release_unused_memory",
        "_construct_with_timeout",
        "_construct_library_item",
        "_init_composite_library_worker",
        "_process_composite_library_item",
        "_render_composite_progress",
        "_composite_extraction_profile",
        "_config_json_value",
    },
    "reference_library/catalog.py": {"from_occurrences"},
    "reference_library/storage/normalized.py": {
        "normalize_table",
        "normalize_publication",
    },
    "protection/strategies/relational.py": {"stage", "aggregate", "write_relational"},
    "protection/strategies/normalized_build.py": {
        "_stage",
        "_stage_route",
        "_entries",
        "_jsonl",
        "write_normalized",
    },
    "infrastructure/build_workspace.py": {"BuildWorkspace", "check_disk_headroom"},
}


def source_content(path, relative):
    raw = path.read_bytes()
    excluded = BUILD_DEFINITIONS.get(relative, set())
    if not excluded:
        return raw
    tree = ast.parse(raw)
    if not any(isinstance(n, (ast.FunctionDef, ast.ClassDef)) for n in tree.body):
        return raw

    class ValidationOnly(ast.NodeTransformer):
        def visit_FunctionDef(self, node):
            return None if node.name in excluded else self.generic_visit(node)

        def visit_ClassDef(self, node):
            return None if node.name in excluded else self.generic_visit(node)

    return ast.dump(ValidationOnly().visit(tree), include_attributes=False).encode()


def dependencies(package, kind="all"):
    if kind not in {*DEPENDENCIES, "all"}:
        raise ValueError(f"unknown audit kind: {kind}")
    patterns = list(SHARED)
    for name, group in DEPENDENCIES.items():
        if kind in {name, "all"}:
            patterns.extend(group)
    files = {p for pattern in patterns for p in package.glob(pattern)}
    result = {}
    for path in sorted(files):
        relative = path.relative_to(package).as_posix()
        if relative not in EXCLUDED_FILES:
            result[relative] = hashlib.sha256(
                source_content(path, relative)
            ).hexdigest()
    # The PG verifier regenerates diagnostics with this shared formatter only.
    formatter = package / "protection/strategies/construction.py"
    if kind in {"pg", "all"} and formatter.exists():
        tree = ast.parse(formatter.read_bytes())
        definitions = {
            n.name: n
            for n in tree.body
            if isinstance(n, (ast.FunctionDef, ast.ClassDef))
        }
        needed = {"_errors"}
        while True:
            referenced = {
                n.id
                for name in needed & definitions.keys()
                for n in ast.walk(definitions[name])
                if isinstance(n, ast.Name)
            }
            expanded = needed | (referenced & definitions.keys())
            if expanded == needed:
                break
            needed = expanded
        # Include imports/globals and any helpers actually used by the formatter.
        nodes = [
            n
            for n in tree.body
            if not isinstance(n, (ast.FunctionDef, ast.ClassDef)) or n.name in needed
        ]
        result["protection/strategies/construction.py:_errors"] = hashlib.sha256(
            ast.dump(
                ast.Module(body=nodes, type_ignores=[]), include_attributes=False
            ).encode()
        ).hexdigest()
    result["runtime:python"] = sys.version
    for name in ("chython-synplan", "chython", "SynPlanner", "networkx", "pydantic"):
        try:
            result[f"runtime:{name}"] = version(name)
        except PackageNotFoundError:
            result[f"runtime:{name}"] = "absent"
    return result
