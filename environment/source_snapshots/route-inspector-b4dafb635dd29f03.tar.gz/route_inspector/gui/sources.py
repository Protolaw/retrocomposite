"""Source-authoritative route loading; persistent route caches are never trusted."""

from __future__ import annotations

import hashlib
import json
import os
from collections import OrderedDict
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path

from route_inspector.reference_library.browsing import (
    BrowsePage,
    matches_route_search,
    sort_route_rows,
)
from route_inspector.routes.access import count_reaction_nodes
from route_inspector.routes.io import iter_route_json_stream

MAX_CACHED_ROUTES = 8
MAX_CACHE_BYTES = 16 * 1024 * 1024


def _json_number(value):
    if isinstance(value, Decimal):
        return float(value)
    raise TypeError(f"unsupported JSON value: {type(value).__name__}")


def _stat_signature(stat):
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns


def file_signature(path: Path) -> tuple[int, ...]:
    return _stat_signature(path.stat())


class _HashingReader:
    """Hash exactly the bytes consumed by the parser, restarting on its rewind."""

    def __init__(self, stream):
        self.stream = stream
        self.hasher = hashlib.sha256()

    def read(self, size=-1):
        data = self.stream.read(size)
        self.hasher.update(data)
        return data

    def readinto(self, buffer):
        count = self.stream.readinto(buffer)
        self.hasher.update(memoryview(buffer)[:count])
        return count

    def seek(self, offset, whence=0):
        if offset != 0 or whence != 0:
            raise ValueError("verified route reader only supports rewinding")
        position = self.stream.seek(0)
        self.hasher = hashlib.sha256()
        return position


@dataclass(frozen=True)
class _SourceScan:
    digest: str
    signature: tuple[int, ...]
    targets: dict[str, str]
    reaction_counts: dict[str, int]
    payload: bytes | None


def _scan_source(
    source, *, route_id=None, expected_digest=None, expected_signature=None
):
    """Fully consume one opened file before publishing its roster or route.

    No early return on finding a route: the complete parsed byte stream must
    match the expected source hash, and trailing syntax errors must be rejected.
    Only the compact roster and one requested payload are retained.
    """
    before = file_signature(source)
    if expected_signature is not None and before != expected_signature:
        raise ValueError("source file changed; attach it again")
    targets, reaction_counts, payload = {}, {}, None
    with source.open("rb") as stream:
        if _stat_signature(os.fstat(stream.fileno())) != before:
            raise ValueError("source file changed while being opened")
        reader = _HashingReader(stream)
        for original_id, route in iter_route_json_stream(reader):
            key = str(original_id)
            if key in targets:
                raise ValueError(f"duplicate route ID in source JSON: {key!r}")
            targets[key] = str(route.get("smiles", ""))
            reaction_counts[key] = count_reaction_nodes(route)
            if route_id == key:
                payload = json.dumps(route, default=_json_number).encode("utf-8")
        digest = reader.hasher.hexdigest()
        if before != _stat_signature(
            os.fstat(stream.fileno())
        ) or before != file_signature(source):
            raise ValueError("source file changed while being read; attach it again")
    if expected_digest is not None and digest != expected_digest:
        raise ValueError(
            "source SHA-256 mismatch: source changed or is not the requested snapshot"
        )
    return _SourceScan(digest, before, targets, reaction_counts, payload)


def load_verified_route(source: Path, route_id: str, *, expected_digest: str) -> dict:
    """Load a worker's route directly from the source, with no disk-cache fallback."""
    selected = str(route_id)
    scan = _scan_source(source, route_id=selected, expected_digest=expected_digest)
    if scan.payload is None:
        raise ValueError(f"route {selected!r} is missing from the source JSON")
    return json.loads(scan.payload)


class RouteSource:
    """Verified navigation metadata plus a bounded process-local payload LRU.

    Existing routes-v1-*.sqlite files are neither opened nor modified. A new
    source attachment builds its roster from JSON. Each uncached route read
    verifies the complete parsed stream against that attachment's source hash.
    """

    def __init__(
        self,
        source: Path,
        *,
        expected_digest=None,
        max_cached_routes=MAX_CACHED_ROUTES,
        max_cache_bytes=MAX_CACHE_BYTES,
    ):
        if max_cached_routes < 0 or max_cache_bytes < 0:
            raise ValueError("route cache limits must be nonnegative")
        self.source = source.resolve(strict=True)
        scan = _scan_source(self.source, expected_digest=expected_digest)
        self.digest, self.signature = scan.digest, scan.signature
        self._targets = scan.targets
        self._reaction_counts = scan.reaction_counts
        self._cache = OrderedDict()
        self._cache_bytes = 0
        self._max_cached_routes = max_cached_routes
        self._max_cache_bytes = max_cache_bytes

    def _clear_cache(self):
        self._cache.clear()
        self._cache_bytes = 0

    def check_unchanged(self):
        try:
            unchanged = self.signature == file_signature(self.source)
        except OSError:
            self._clear_cache()
            raise
        if not unchanged:
            self._clear_cache()
            raise ValueError(
                "source file changed; attach it again before inspecting routes"
            )

    @property
    def route_ids(self):
        self.check_unchanged()
        return tuple(self._targets)

    def route(self, route_id: str) -> dict:
        self.check_unchanged()
        key = str(route_id)
        if key not in self._targets:
            raise ValueError(f"route {key!r} is missing from the source JSON")
        payload = self._cache.get(key)
        if payload is None:
            try:
                scan = _scan_source(
                    self.source,
                    route_id=key,
                    expected_digest=self.digest,
                    expected_signature=self.signature,
                )
            except Exception:
                self._clear_cache()
                raise
            payload = scan.payload
            if payload is None:
                raise ValueError(f"route {key!r} is missing from the source JSON")
            if self._max_cached_routes and len(payload) <= self._max_cache_bytes:
                self._cache[key] = payload
                self._cache_bytes += len(payload)
                while (
                    len(self._cache) > self._max_cached_routes
                    or self._cache_bytes > self._max_cache_bytes
                ):
                    _, removed = self._cache.popitem(last=False)
                    self._cache_bytes -= len(removed)
        else:
            self._cache.move_to_end(key)
        # Immutable cached bytes prevent callers or renderers mutating later reads.
        return json.loads(payload)

    def targets(self, route_ids: list[str] | None = None) -> dict[str, str]:
        self.check_unchanged()
        if route_ids is None:
            return dict(self._targets)
        return {key: self._targets[key] for key in route_ids if key in self._targets}

    def reaction_counts(self) -> dict[str, int]:
        self.check_unchanged()
        return dict(self._reaction_counts)

    def page(
        self,
        search="",
        offset=0,
        limit=50,
        *,
        target_search_text=None,
        sort_by=None,
        descending=False,
    ) -> BrowsePage:
        self.check_unchanged()
        if offset < 0 or not 1 <= limit <= 200:
            raise ValueError("invalid page bounds")
        rows = [
            dict(
                id=key,
                route_id=key,
                target=target,
                reaction_count=self._reaction_counts[key],
            )
            for key, target in self._targets.items()
            if matches_route_search(key, target, search, target_search_text)
        ]
        rows = sort_route_rows(rows, sort_by, descending, target_search_text)
        return BrowsePage(
            tuple(rows[offset : offset + limit]), len(rows), offset, limit
        )
