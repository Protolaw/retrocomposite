"""Reuse successful local audits only for unchanged artifacts and verifier code."""

import hashlib
import json
import os
import tempfile
import threading
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path

from route_inspector.gui.sources import file_signature

_locks = {}
_guard = threading.Lock()
_observations = ContextVar("open_library_observations", default=None)


@contextmanager
def capture_snapshots():
    """Capture the snapshots already checked by loaders, without another scan."""
    observations = {}
    token = _observations.set(observations)
    try:
        yield observations
    finally:
        _observations.reset(token)


def rejected_snapshots(observations):
    """Read only failure receipts for the exact snapshots still open."""
    errors = {}
    for observation in observations:
        failure = Path(observation["receipt"]).with_suffix(".failed.json")
        try:
            rejected = json.loads(failure.read_text())
        except FileNotFoundError:
            continue
        except (OSError, ValueError):
            errors[observation["kind"]] = "Library rejection receipt is unreadable"
            continue
        if not isinstance(rejected, dict) or _same_snapshot(
            rejected, observation["snapshot"]
        ):
            errors[observation["kind"]] = (
                rejected.get("error", "Background audit rejected this library snapshot")
                if isinstance(rejected, dict)
                else "Invalid library rejection receipt"
            )
    return errors


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, prefix=".verification-")
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(value, stream, sort_keys=True)
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def verifier_identity(kind="all"):
    from route_inspector.gui.audit_dependencies import dependencies

    return hashlib.sha256(
        json.dumps(
            dependencies(Path(__file__).parents[1], kind), sort_keys=True
        ).encode()
    ).hexdigest()


def library_kind(loader):
    module = loader.__module__
    if "reference_library" in module:
        return "reference"
    if "protection" in module:
        return "pg"
    if "composite_rules" in module:
        return "composites"
    return "all"


class AuditRequired(RuntimeError):
    """The GUI must prepare a receipt outside its browsing worker."""


def _same_snapshot(left, right):
    return all(left.get(key) == right[key] for key in ("manifest_sha256", "files"))


def snapshot_verified(receipt, expected):
    """A previous successful audit still identifies the same immutable bytes.

    This does not certify those bytes under a newer verifier. The GUI reports
    that distinction and runs the newer audit separately. A recorded failure
    revokes earlier permission to browse this snapshot until an audit succeeds.
    """
    try:
        previous = json.loads(receipt.read_text())
        if (
            not isinstance(previous, dict)
            or previous.get("version") not in {1, 2}
            or not isinstance(previous.get("verifier"), str)
            or len(previous["verifier"]) != 64
            or not _same_snapshot(previous, expected)
        ):
            return False
        failure = receipt.with_suffix(".failed.json")
        if failure.exists():
            rejected = json.loads(failure.read_text())
            if not isinstance(rejected, dict) or _same_snapshot(rejected, expected):
                return False
    except (OSError, ValueError, TypeError):
        return False
    return True


def receipt_state(loader, directory, cache_root):
    from route_inspector.gui.audit_dependencies import dependencies

    directory = Path(directory).resolve()
    kind = library_kind(loader)
    sources = dependencies(Path(__file__).parents[1], kind)
    # Historical reference publications can embed a PG component.
    manifest = json.loads((directory / "manifest.json").read_text())
    if kind == "reference" and "pg_strategy" in manifest.get("components", {}):
        sources.update(dependencies(Path(__file__).parents[1], "pg"))
    identity = verifier_identity() if kind == "all" else verifier_identity(kind)
    expected = {
        "version": 2,
        "kind": kind,
        "verifier": identity,
        "dependencies": sources,
        **artifact_snapshot(directory),
    }
    receipt = Path(cache_root) / (
        hashlib.sha256(str(directory).encode()).hexdigest() + ".json"
    )
    try:
        previous = json.loads(receipt.read_text())
    except (OSError, ValueError):
        previous = None
    rejected = receipt.with_suffix(".failed.json").exists() and not snapshot_verified(
        receipt, expected
    )
    if rejected:
        reason = "A previous validation failure requires a successful recheck"
    elif previous == expected:
        reason = "Verified snapshot unchanged"
    elif not isinstance(previous, dict) or previous.get("version") != 2:
        reason = "No compatible successful audit receipt"
    elif (
        previous.get("files") != expected["files"]
        or previous.get("manifest_sha256") != expected["manifest_sha256"]
    ):
        reason = "Library artifacts changed"
    else:
        changed = sorted(
            k
            for k in set(sources) | set(previous.get("dependencies", {}))
            if sources.get(k) != previous.get("dependencies", {}).get(k)
        )
        reason = "Validation dependencies changed: " + ", ".join(changed[:5])
    return receipt, expected, previous == expected and not rejected, reason


def artifact_snapshot(directory):
    directory = Path(directory).resolve()
    manifest_path = directory / "manifest.json"
    before = file_signature(manifest_path)
    raw = manifest_path.read_bytes()
    manifest = json.loads(raw)
    files = {"manifest.json": list(before)}
    for descriptor in manifest["artifacts"].values():
        relative = descriptor["path"]
        path = (directory / relative).resolve()
        if not path.is_relative_to(directory):
            raise ValueError("library artifact escapes its directory")
        files[relative] = list(file_signature(path))
    if before != file_signature(manifest_path):
        raise ValueError("library manifest changed during verification")
    return {"manifest_sha256": hashlib.sha256(raw).hexdigest(), "files": files}


def load_verified(loader, directory, cache_root, verification="cached"):
    """Publish receipts only after successful audits of unchanged snapshots.

    ``ready`` requires the current verifier's receipt. ``snapshot`` also accepts
    a previous successful audit of identical artifacts, without promoting it to
    a current receipt. Both GUI policies refuse to start an audit here.
    Existing cached/full/fast API behavior is unchanged.
    """
    if verification not in {"cached", "full", "fast", "ready", "snapshot"}:
        raise ValueError("unknown verification policy")
    if verification == "fast":
        return loader(directory, verification="fast")
    directory = Path(directory).resolve()
    key = str(directory)
    with _guard:
        lock = _locks.setdefault(key, threading.Lock())
    with lock:
        receipt, expected, valid, reason = receipt_state(loader, directory, cache_root)
        if verification == "ready" and not valid:
            raise AuditRequired(reason)
        if verification == "snapshot" and not snapshot_verified(receipt, expected):
            raise AuditRequired(reason)
        mode = (
            "fast"
            if verification == "snapshot"
            or (verification in {"cached", "ready"} and valid)
            else "full"
        )
        try:
            library = loader(directory, verification=mode)
        except Exception as exc:
            atomic_json(
                receipt.with_suffix(".failed.json"),
                {**expected, "error": f"{type(exc).__name__}: {exc}"},
            )
            raise
        try:
            _, after, _, _ = receipt_state(loader, directory, cache_root)
            if after != expected:
                if (
                    after["files"] != expected["files"]
                    or after["manifest_sha256"] != expected["manifest_sha256"]
                ):
                    raise ValueError(
                        "library changed while being loaded; retry verification"
                    )
                raise ValueError(
                    "verifier changed during verification; retry with unchanged code"
                )
            if mode == "full":
                atomic_json(receipt, expected)
                receipt.with_suffix(".failed.json").unlink(missing_ok=True)
            elif verification == "snapshot" and not snapshot_verified(receipt, after):
                raise AuditRequired("Background audit rejected this library snapshot")
        except Exception:
            library.close()
            raise
        observations = _observations.get()
        if observations is not None:
            observations[str(directory)] = dict(
                receipt=str(receipt), kind=library_kind(loader), snapshot=expected
            )
        return library
