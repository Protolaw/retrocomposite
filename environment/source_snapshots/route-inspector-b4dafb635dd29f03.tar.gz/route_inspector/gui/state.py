"""Selection state is occurrence-aware and independent for each browsing mode."""

from dataclasses import dataclass, field

ROUTE_PAGE_SIZE = 20


@dataclass
class PGSelection:
    tactic_id: str | None = None
    tactic_length: int = 0
    tactic_minimum_events: int = 1
    tactic_offset: int = 0
    tactic_sort: str = "event_count"
    tactic_descending: bool = True
    protections_detected: bool = True
    origin: str = "All"
    terminus: str = "All"
    pg_type: str | None = None
    family: str | None = None
    route_id: str | None = None
    event_id: str | None = None
    step_id: str | None = None
    ngram_id: str | None = None
    ngram_length: int = 0
    search: str = ""
    route_offset: int = 0
    event_offset: int = 0
    gram_offset: int = 0
    family_offset: int = 0
    type_offset: int = 0
    sort_by: str = "route_id"
    descending: bool = False


@dataclass
class ExplorerState:
    analysis_domain: str = "Tactics"
    pg_mode: str = "Route-wise"
    pg_routes: PGSelection = field(default_factory=PGSelection)
    pg_types: PGSelection = field(default_factory=PGSelection)
    pg_tactics: PGSelection = field(default_factory=PGSelection)

    @property
    def pg(self):
        if self.pg_mode == "Tactic-wise":
            return self.pg_tactics
        return self.pg_routes if self.pg_mode == "Route-wise" else self.pg_types

    mode: str = "Route-wise"
    source: str = "Reference library"
    route: dict | None = None
    occurrence_id: str | None = None
    route_occurrence_table_open: bool = False
    entry_id: str | None = None
    tactic_route: dict | None = None
    tactic_occurrence_id: str | None = None
    tactic_workspace: str = "overview"
    composite_workspace: str = "overview"
    composite_lhs_offset: int = 0
    composite_lhs_selected: str | None = None
    composite_id: str | None = None
    composite_tactic_id: str | None = None
    composite_tactic_expanded: bool = True
    composite_route: dict | None = None
    composite_occurrence_id: str | None = None
    composite_kind: str | None = None
    composite_search: str = ""
    composite_minimum_support: int = 1
    composite_ring_breaking_only: bool = False
    composite_activator_filter: str = "all"
    composite_submode: str = "all"
    overlap_evidence_offset: int = 0
    overlap_step_id: str | None = None
    composite_offset: int = 0
    composite_source_offset: int = 0
    composite_occurrence_offset: int = 0
    kind: str = "rrseq_cons"
    route_search: str = ""
    route_rrseq_cons: str = "any"
    route_rrseq_gap: str = "any"
    tactic_search: str = ""
    minimum_size: int = 0
    minimum_support: int = 1
    activator_filter: str = "all"
    route_offset: int = 0
    route_sort_by: str | None = None
    route_sort_descending: bool = False
    entry_sort_by: str = "route_count"
    entry_sort_descending: bool = True
    composite_sort_by: str = "route_count"
    composite_sort_descending: bool = True
    related_direction: str = "extensions"
    related_offset: int = 0
    entry_offset: int = 0
    source_offset: int = 0
    occurrence_offset: int = 0
    tactic_occurrence_offset: int = 0
    query_path: str = ""
    config_path: str = "route_inspector/configs/rule_extraction_functional_groups.yaml"
    query_route_id: str | None = None
    assessment: dict | None = None
    query_occurrence_id: str | None = None
    skipped: bool = False
    aam: bool = True
    layered: bool = True
    route_rows: list = field(default_factory=list)

    def clear_route_selection(self):
        self.route = self.occurrence_id = None
        self.route_offset = self.occurrence_offset = 0

    def reset_route_filters(self):
        self.route_rrseq_cons = self.route_rrseq_gap = "any"
        self.route_search = ""
        self.clear_route_selection()

    def explore_tactic(self, entry_id, kind, route, occurrence_id):
        self.activator_filter = "all"
        self.mode = "Tactic-wise"
        self.tactic_workspace = "overview"
        self.related_direction, self.related_offset = "extensions", 0
        self.entry_id, self.kind = entry_id, kind
        self.tactic_route, self.tactic_occurrence_id = route, occurrence_id
        self.source_offset = self.tactic_occurrence_offset = 0

    def inspect_route(self):
        route, occurrence_id = (
            (self.composite_route, self.composite_occurrence_id)
            if self.mode == "Composite-wise"
            else (self.tactic_route, self.tactic_occurrence_id)
        )
        if route is None:
            raise ValueError("select a source route first")
        self.mode, self.source = "Route-wise", "Reference library"
        self.route, self.occurrence_id = route, occurrence_id
        self.occurrence_offset = 0

    def explore_composite(self, link):
        self.composite_activator_filter = "all"
        self.mode = "Composite-wise"
        self.composite_id = link["composite_id"]
        self.overlap_evidence_offset = 0
        self.overlap_step_id = None
        self.composite_tactic_id = link["tactic_entry_id"]
        self.composite_tactic_expanded = True
        self.composite_route = dict(link["route"])
        self.composite_occurrence_id = link["reference_occurrence_id"]
        if self.composite_kind not in (None, link["kind"]):
            self.composite_kind = link["kind"]
        self.composite_source_offset = self.composite_occurrence_offset = 0
