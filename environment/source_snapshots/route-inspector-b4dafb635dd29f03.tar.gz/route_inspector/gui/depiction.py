"""Shared depiction context used by GUI workers and standalone renderers."""

from route_inspector.visualization.depiction import (
    depiction_settings as depiction_settings,
)
