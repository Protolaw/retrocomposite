"""Workspace-scoped audit queue; browser sessions share work, never connections."""

import hashlib
import json
import subprocess
import sys
import threading
import time
from pathlib import Path
from uuid import uuid4

from route_inspector.datasets.bindings import dataset_bindings
from route_inspector.gui.verification import (
    atomic_json,
    receipt_state,
    snapshot_verified,
)

_managers = {}
_guard = threading.Lock()


def library_loader(kind):
    if kind == "reference":
        from route_inspector.reference_library import ReferenceTacticLibrary

        return ReferenceTacticLibrary.load
    if kind == "pg":
        from route_inspector.protection.strategies.catalog import (
            ReferencePGStrategyLibrary,
        )

        return ReferencePGStrategyLibrary.load
    if kind == "composites":
        from route_inspector.composite_rules.library import (
            CompositeDecompositionLibrary,
        )

        return CompositeDecompositionLibrary.load
    raise ValueError("unknown library kind")


def audit_jobs(workspace):
    workspace = Path(workspace).resolve()
    with _guard:
        return _managers.setdefault(workspace, AuditJobs(workspace))


class AuditJobs:
    def __init__(self, workspace):
        self.workspace = Path(workspace).resolve()
        self.root = self.workspace / "outputs/gui/audits"
        self.receipts = self.workspace / "outputs/gui/verification"
        self.jobs = {}
        self.requests = {}
        self.active = None
        self.process = self.log = None
        self.lock = threading.RLock()

    def request(self, dataset):
        with self.lock:
            bindings = dataset_bindings(self.workspace, dataset)
            token = uuid4().hex
            keys, errors = [], {}
            for kind in ("reference", "pg", "composites"):
                directory = bindings[kind]
                if not (directory / "manifest.json").is_file():
                    relative = directory.relative_to(self.workspace)
                    errors[kind] = (
                        f"No PG library found: {relative}"
                        if kind == "pg"
                        else "No composite companion found for this dataset"
                        if kind == "composites"
                        else f"No reference library found: {relative}"
                    )
                    continue
                try:
                    receipt, expected, valid, reason = receipt_state(
                        library_loader(kind), directory, self.receipts
                    )
                except (OSError, ValueError, KeyError) as exc:
                    errors[kind] = str(exc)
                    continue
                relative = str(directory.relative_to(self.workspace))
                key = hashlib.sha256(
                    json.dumps([relative, expected], sort_keys=True).encode()
                ).hexdigest()
                if (
                    key not in self.jobs
                    or self.jobs[key]["state"] in {"failed", "cancelled"}
                    or (self.jobs[key]["state"] == "completed" and not valid)
                ):
                    self.jobs[key] = dict(
                        kind=kind,
                        library=relative,
                        expected=expected,
                        reason=reason,
                        snapshot_verified=snapshot_verified(receipt, expected),
                        state="completed" if valid else "queued",
                        subscribers=set(),
                    )
                self.jobs[key]["subscribers"].add(token)
                keys.append(key)
            self.requests[token] = dict(
                dataset=dataset,
                keys=keys,
                errors=errors,
                started=time.monotonic(),
                bindings={
                    k: str(v.relative_to(self.workspace)) for k, v in bindings.items()
                },
            )
            self._tick()
            return token

    def _tick(self):
        if self.process is not None and self.process.poll() is not None:
            job = self.jobs[self.active]
            try:
                status = json.loads((job["directory"] / "status.json").read_text())
            except (OSError, ValueError):
                status = {}
            job["state"] = (
                "completed"
                if self.process.returncode == 0 and status.get("state") == "completed"
                else "failed"
            )
            job["message"] = status.get("message", "Audit worker exited unexpectedly")
            self.log.close()
            self.process = self.log = self.active = None
        if self.process is not None:
            return
        for key, job in self.jobs.items():
            if job["state"] != "queued" or not job["subscribers"]:
                continue
            directory = self.root / uuid4().hex
            directory.mkdir(parents=True)
            request = {k: job[k] for k in ("kind", "library", "expected", "reason")}
            atomic_json(directory / "request.json", request)
            atomic_json(
                directory / "status.json", dict(state="running", phase="Starting audit")
            )
            self.log = (directory / "worker.log").open("w")
            job["directory"] = directory
            try:
                self.process = subprocess.Popen(
                    [
                        sys.executable,
                        "-m",
                        "route_inspector.gui.audit_worker",
                        str(directory),
                    ],
                    cwd=self.workspace,
                    stdin=subprocess.DEVNULL,
                    stdout=self.log,
                    stderr=subprocess.STDOUT,
                )
            except OSError as exc:
                self.log.close()
                self.log = None
                job.update(state="failed", message=str(exc))
                continue
            self.active = key
            job["state"] = "running"
            break

    def poll(self, token):
        with self.lock:
            self._tick()
            request = self.requests.get(token)
            if request is None:
                return {"state": "cancelled"}
            errors = dict(request["errors"])
            pending = []
            for key in request["keys"]:
                job = self.jobs[key]
                if job["state"] in {"failed", "cancelled"}:
                    errors[job["kind"]] = job.get("message", "Audit cancelled")
                elif job["state"] != "completed":
                    pending.append(job)
            result = dict(
                dataset=request["dataset"],
                errors=errors,
                elapsed=time.monotonic() - request["started"],
                bindings=request["bindings"],
                can_open=all(j["snapshot_verified"] for j in pending)
                and not ({"reference", "pg"} <= errors.keys()),
                completed_libraries=sum(
                    self.jobs[k]["state"] == "completed" for k in request["keys"]
                ),
                total_libraries=len(request["keys"]),
            )
            if not pending:
                return {
                    **result,
                    "state": "failed"
                    if {"reference", "pg"} <= errors.keys()
                    else "ready",
                }
            job = next((j for j in pending if j["state"] == "running"), pending[0])
            status = {}
            if job.get("directory"):
                try:
                    status = json.loads((job["directory"] / "status.json").read_text())
                except (OSError, ValueError):
                    pass
            return {
                **result,
                **status,
                "state": "running",
                "kind": job["kind"],
                "reason": job["reason"],
                "phase": status.get("phase", "Waiting for audit worker"),
            }

    def release(self, token):
        with self.lock:
            request = self.requests.pop(token, None)
            if request is None:
                return
            cancelled = []
            for key in request["keys"]:
                job = self.jobs[key]
                job["subscribers"].discard(token)
                if job["subscribers"] or job["state"] == "completed":
                    continue
                job["state"] = "cancelled"
                cancelled.append(key)
            # Withdraw every queued job before finishing the active one. Calling
            # _tick inside the loop used to start audits solely to cancel them.
            if self.active in cancelled and self.process is not None:
                self.process.terminate()
                try:
                    self.process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait(timeout=3)
                self._tick()
            for key in cancelled:
                job = self.jobs[key]
                if job["state"] != "completed":
                    job["state"] = "cancelled"
                    if job.get("directory"):
                        atomic_json(
                            job["directory"] / "status.json",
                            dict(state="cancelled", message="Audit request released"),
                        )
            self._tick()

    def close(self):
        for token in list(self.requests):
            self.release(token)
