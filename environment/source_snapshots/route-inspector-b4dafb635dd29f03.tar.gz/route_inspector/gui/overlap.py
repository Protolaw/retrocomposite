"""Per-session background preparation and verified overlap-cache attachment."""

import os
import subprocess
from functools import wraps
from threading import RLock

from route_inspector.composite_rules.overlap import (
    DEFAULT_OVERLAP_CACHE_ROOT,
    InvalidOverlapCache,
    OverlapIndex,
    cache_identity,
    cache_key,
)
from route_inspector.gui.jobs import AnalysisJobs


def _synchronized(method):
    @wraps(method)
    def wrapped(self, *args, **kwargs):
        with self._lock:
            return method(self, *args, **kwargs)

    return wrapped


class OverlapPreparation:
    def __init__(self, workspace):
        self._lock = RLock()
        self._closed = False
        self.workspace = workspace
        self.jobs = AnalysisJobs(workspace / "outputs/gui/overlap_jobs")
        self.index = None
        self.identity = self.directory = None
        self.status = {
            "state": "idle",
            "message": "Single-step vocabulary has not been prepared",
        }

    @_synchronized
    def start(self, library, composites, source):
        if self._closed:
            return dict(self.status)
        if self.status["state"] != "idle":
            return self.poll(source)
        try:
            source.check_unchanged()
            self.identity = cache_identity(library, composites, source.digest)
            self.directory = (
                self.workspace / DEFAULT_OVERLAP_CACHE_ROOT / cache_key(self.identity)
            )
            if self.directory.exists():
                try:
                    self._attach()
                    return dict(self.status)
                except InvalidOverlapCache:
                    pass  # The worker revalidates, quarantines and rebuilds.
            request = {
                "operation": "single_step_overlap",
                "identity": self.identity,
                **{
                    name: os.path.relpath(path, self.workspace)
                    for name, path in {
                        "library": library.directory,
                        "composites": composites.directory,
                        "source": source.source,
                        "destination": self.directory,
                    }.items()
                },
            }
            self.jobs.start(request)
            self.status = {
                "state": "running",
                "message": "Preparing single-step vocabulary…",
            }
        except Exception as exc:
            self.status = {
                "state": "failed",
                "message": f"Single-step overlap unavailable: {exc}",
            }
        return dict(self.status)

    def _attach(self):
        self.index = OverlapIndex(self.directory, self.identity)
        self.status = {
            "state": "completed",
            "message": "Single-step vocabulary ready",
            "summary": self.index.summary,
        }

    @_synchronized
    def poll(self, source):
        if self._closed:
            return dict(self.status)
        try:
            source.check_unchanged()
            if self.status["state"] == "running":
                status = self.jobs.poll()
                if status["state"] == "completed":
                    self._attach()
                else:
                    self.status = status
        except Exception as exc:
            if self.index is not None:
                self.index.close()
                self.index = None
            self.status = {
                "state": "failed",
                "message": f"Single-step overlap unavailable: {exc}",
            }
        return dict(self.status)

    @_synchronized
    def retry(self, library, composites, source):
        if self._closed or self.status["state"] not in {"failed", "cancelled"}:
            return self.poll(source)
        try:
            source.check_unchanged()
            self.jobs.cancel()
            if self.jobs.process is not None:
                # The worker can publish a failed status just before exiting.
                self.jobs.process.wait(timeout=3)
            if self.index is not None:
                self.index.close()
                self.index = None
            self.status = {"state": "idle"}
            return self.start(library, composites, source)
        except subprocess.TimeoutExpired:
            self.status = {
                "state": "failed",
                "message": "Previous worker is still stopping; retry preparation shortly",
            }
        except Exception as exc:
            self.status = {
                "state": "failed",
                "message": f"Single-step overlap unavailable: {exc}",
            }
        return dict(self.status)

    @_synchronized
    def close(self):
        self._closed = True
        self.jobs.cancel()
        if self.index is not None:
            self.index.close()
            self.index = None
