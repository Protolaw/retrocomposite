"""Bounded molecule-only thumbnail cache; data URLs cannot execute scripts."""

from base64 import b64encode
from functools import lru_cache

from route_inspector.gui.depiction import depiction_settings


@lru_cache(maxsize=512)
def unmapped_smiles(smiles_text: str) -> str:
    """Chython's compact molecular string; never alter the mapped source record."""
    if not smiles_text:
        return ""
    from chython import MoleculeContainer, smiles

    try:
        molecule = smiles(smiles_text)
        return str(molecule) if isinstance(molecule, MoleculeContainer) else ""
    except (TypeError, ValueError):
        return ""


@lru_cache(maxsize=256)
def target_thumbnail(smiles_text: str) -> str:
    if not smiles_text:
        return ""
    from chython import smiles

    try:
        with depiction_settings(aam=False):
            svg = smiles(smiles_text).depict()
    except (TypeError, ValueError):
        return ""
    return "data:image/svg+xml;base64," + b64encode(svg.encode()).decode("ascii")
