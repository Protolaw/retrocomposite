// Only application-rendered, sanitized SVGs enter this viewer. No external assets.
window.riRouteViewer = function (id) {
  const host = document.getElementById('c' + id);
  if (!host) return;
  if (host.riAbort) host.riAbort.abort();
  host.riAbort = new AbortController();
  const signal = host.riAbort.signal;
  const svg = host.querySelector('svg');
  if (!svg) return;
  const original = svg.getAttribute('viewBox').split(/[ ,]+/).map(Number);
  svg.style.width = '100%'; svg.style.height = '100%';
  host.riBox = original.slice(); host.riOriginal = original;
  host.riTarget = original.slice();
  const draw = () => svg.setAttribute('viewBox', host.riBox.join(' '));
  const stop = () => {
    cancelAnimationFrame(host.riFrame);
    host.riFrame = null;
  };
  signal.addEventListener('abort', stop, {once: true});
  const animate = target => {
    stop();
    host.riTarget = target;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      host.riBox = target.slice(); draw(); return;
    }
    const start = host.riBox.slice(), time = performance.now();
    const frame = now => {
      if (!host.isConnected || signal.aborted) { stop(); return; }
      const progress = Math.min(1, (now - time) / 180);
      const ease = 1 - Math.pow(1 - progress, 3);
      host.riBox = start.map((value, i) => value + (target[i] - value) * ease);
      if (progress === 1) host.riBox = target.slice();
      draw();
      host.riFrame = progress < 1 ? requestAnimationFrame(frame) : null;
    };
    host.riFrame = requestAnimationFrame(frame);
  };
  host.riZoom = (factor, clientX, clientY) => {
    if (!Number.isFinite(factor) || factor <= 0) return;
    // Accumulate scale against the pending target, but place that scale around
    // the atom currently beneath the pointer. Mixing the pending origin with
    // the displayed anchor makes a moving pointer drift during animation.
    const [x,y,w,h] = host.riBox;
    factor = Math.max(original[2] / 40, Math.min(original[2] * 8, host.riTarget[2] * factor)) / w;
    let fx = 0.5, fy = 0.5;
    if (clientX !== undefined && clientY !== undefined) {
      const transform = svg.getScreenCTM();
      if (transform) {
        const point = new DOMPoint(clientX, clientY).matrixTransform(transform.inverse());
        fx = (point.x - host.riBox[0]) / host.riBox[2];
        fy = (point.y - host.riBox[1]) / host.riBox[3];
      }
    }
    animate([x + w * (1-factor) * fx, y + h * (1-factor) * fy, w * factor, h * factor]);
  };
  host.riFit = () => animate(original.slice());
  svg.addEventListener('wheel', e => {
    e.preventDefault();
    // Normalize trackpad pixels, mouse-wheel lines and page units; ignore
    // horizontal-only scroll and cap a single wheel event to a gentle step.
    const units = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? svg.clientHeight : 1;
    const delta = Math.max(-120, Math.min(120, e.deltaY * units));
    if (delta) host.riZoom(Math.exp(delta * 0.001), e.clientX, e.clientY);
  }, {passive: false, signal});
  let drag = null;
  svg.addEventListener('pointerdown', e => {
    if (e.button !== 0 || e.target.closest('.ri-route-reaction')) return;
    stop(); host.riTarget = host.riBox.slice();
    drag = [e.clientX, e.clientY, ...host.riBox]; svg.setPointerCapture(e.pointerId);
  }, {signal});
  svg.addEventListener('pointermove', e => {
    if (!drag) return;
    const rect = svg.getBoundingClientRect();
    const scale = Math.max(drag[4]/rect.width, drag[5]/rect.height);
    host.riBox = [drag[2]-(e.clientX-drag[0])*scale, drag[3]-(e.clientY-drag[1])*scale, drag[4], drag[5]];
    host.riTarget = host.riBox.slice(); draw();
  }, {signal});
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) svg.addEventListener(type, () => {drag=null;}, {signal});
  for (const node of svg.querySelectorAll('.ri-route-reaction')) {
    node.setAttribute('tabindex', '0'); node.setAttribute('role', 'button');
    node.setAttribute('aria-label', 'Inspect reaction ' + node.dataset.reactionPath);
    node.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {e.preventDefault(); node.dispatchEvent(new MouseEvent('click', {bubbles:true}));}
    }, {signal});
  }
};
window.riSelectReaction = function (id, path) {
  const host = document.getElementById('c' + id);
  if (host) for (const node of host.querySelectorAll('.ri-route-reaction')) node.classList.toggle('ri-selected', node.dataset.reactionPath === path);
};
