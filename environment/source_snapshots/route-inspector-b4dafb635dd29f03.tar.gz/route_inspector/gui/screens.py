"""Presentation-only screens; actions and background jobs live in app.py."""

import json
from xml.etree import ElementTree as ET

from nicegui import ui

from route_inspector.gui.activators import ActivatorScreens
from route_inspector.gui.composites import CompositeScreens
from route_inspector.gui.labels import TACTIC_LABELS
from route_inspector.gui.pg_screens import PGScreens
from route_inspector.gui.related import RelatedScreens
from route_inspector.gui.svg import inline_rule_glyphs
from route_inspector.gui.widgets import RouteViewer, copy_full_id, pager, table
from route_inspector.reference_library.browsing import KINDS, BrowsePage, route_token
from route_inspector.reference_library.models import ReferenceRouteKey

LABELS = {
    kind: kind.replace("rrseq", "RRSeq").replace("rrsubtree", "RRSubtree")
    for kind in KINDS
}
EMPTY = BrowsePage((), 0, 0, 50)


class ExplorerScreens(CompositeScreens, PGScreens, RelatedScreens, ActivatorScreens):
    @ui.refreshable
    def body(self):
        if self.screen == "datasets":
            self.dataset_screen()
            return
        if self.screen == "modes":
            self.mode_screen()
            return
        if self.info is None:
            return
        self.workspace_navigation()
        if self.state.analysis_domain == "PG strategies":
            self.pg_screen()
            return
        if self.state.mode == "Route-wise":
            ui.select(
                ["Reference library", "New prepared route"],
                value=self.state.source,
                label="Route source",
                on_change=lambda e: self.change("source", e.value),
            )
            if self.state.source == "New prepared route":
                self.query_controls()
        if self.state.mode == "Tactic-wise":
            self.tactic_workspace()
            return
        if self.state.mode == "Composite-wise":
            self.composite_workspace()
            return
        with ui.element("div").classes("ri-route-layout"):
            with ui.column().classes("ri-card ri-route-catalogue-pane"):
                self.navigation()
            with ui.column().classes("ri-card ri-route-column w-full"):
                if self.state.mode == "Composite-wise":
                    self.composite_panel()
                route = (
                    self.state.composite_route
                    if self.state.mode == "Composite-wise"
                    else self.state.tactic_route
                    if self.state.mode == "Tactic-wise"
                    else self.state.route
                )
                route_id = (
                    self.state.query_route_id
                    if self.state.mode == "Route-wise"
                    and self.state.source == "New prepared route"
                    else (route or {}).get("route_id")
                )
                ui.label(
                    f"Route {route_id}" if route_id is not None else "Route viewer"
                ).classes("text-h6")
                self.route_occurrence_selector(route_id)
                if (self.view.get("selected") or {}).get("kind", "").endswith("_gap"):
                    ui.checkbox(
                        "Highlight skipped steps",
                        value=self.state.skipped,
                        on_change=lambda e: self.change("skipped", e.value),
                    )
                self.viewer = RouteViewer(
                    self.view.get("preview", {}),
                    self.select_reaction,
                    aam=self.state.aam,
                    on_aam_change=lambda e: self.change("aam", e.value),
                    layered=self.state.layered,
                    on_layered_change=lambda e: self.change("layered", e.value),
                )
                if self.state.mode == "Route-wise":
                    self.rules_panel()
                self.reactions = self.view.get("preview", {}).get("reactions", [])
                with ui.expansion("Reaction details and tactic membership").classes(
                    "w-full"
                ):
                    self.inspector = ui.label(
                        "Select a reaction marker in the route."
                    ).classes("ri-inspector")
                if self.state.mode == "Route-wise":
                    if self.view.get("occurrences", EMPTY).total or (
                        self.state.source == "New prepared route"
                        and self.state.assessment
                    ):
                        with ui.expansion(
                            "Occurrence table and export",
                            value=self.state.route_occurrence_table_open,
                            on_value_change=lambda e: setattr(
                                self.state, "route_occurrence_table_open", e.value
                            ),
                        ).classes("w-full"):
                            self.occurrences_panel(show_selection=False)

    def route_occurrence_selector(self, route_id):
        """Keep tactic selection in place above the drawing and rule depiction."""
        if route_id is None:
            return
        page = self.view.get("occurrences", EMPTY)
        selected = self.view.get("selected")
        with ui.column().classes("ri-route-occurrence w-full gap-1"):
            if self.state.source == "New prepared route" and self.state.assessment:
                self.route_assessment_summary()
            ui.label(f"Tactic occurrences · {page.total}").classes("text-subtitle2")
            if not page.total:
                ui.label(
                    "Analyse this prepared route to find tactic occurrences."
                    if self.state.source == "New prepared route"
                    and not self.state.assessment
                    else "No stored tactic occurrences for this route. This does not imply absence of a synthetic tactic."
                ).classes("text-caption")
                return
            steps = {
                row["path"]: row.get("step") or row["path"]
                for row in self.view.get("preview", {}).get("reactions", ())
            }
            # Prefer the labels on the actual drawing: stored StepId metadata
            # can be absent or use a different numbering convention.
            try:
                drawing = ET.fromstring(self.view.get("preview", {}).get("svg", ""))
            except ET.ParseError:
                pass
            else:
                steps.update(
                    {
                        node.attrib["data-reaction-path"]: node.attrib[
                            "data-reaction-step"
                        ]
                        for node in drawing.iter()
                        if "data-reaction-path" in node.attrib
                        and "data-reaction-step" in node.attrib
                    }
                )
            rows = {row["id"]: row for row in page.rows}
            if selected:
                rows.setdefault(selected["id"], selected)
            options = {None: "Whole route · no tactic selected"}
            for index, row in enumerate(rows.values(), start=page.offset + 1):
                labels = ", ".join(
                    steps.get(path, path) for path in row["selected_paths"]
                )
                position = index if row in page.rows else "Selected"
                options[row["id"]] = (
                    f"{position}. {TACTIC_LABELS[row['kind']]} · {row['size']} rules · {labels}"
                )
            with ui.row().classes("w-full items-center gap-2"):
                ui.select(
                    options,
                    value=selected["id"] if selected else None,
                    label="Tactic occurrence",
                    on_change=lambda e: self.choose_route_occurrence(e.value),
                ).props("outlined dense options-dense").classes("ri-occurrence-select")
                ui.button("Explore this tactic", on_click=self.explore_tactic).props(
                    "outline dense no-caps"
                ).set_enabled(bool(selected and selected["entry_id"]))
            if page.total > page.limit:
                pager(page, lambda offset: self.change("occurrence_offset", offset))
            if selected:
                ui.label(f"Selected occurrence: {selected['id']}").classes(
                    "text-caption break-all"
                )

    def route_assessment_summary(self):
        assessment = self.state.assessment
        ui.label(f"Assessment: {assessment['status']}").classes("text-subtitle2")
        if assessment.get("limitation"):
            ui.label(assessment["limitation"])
        coverage = assessment["overall"]
        ui.label(
            f"Known occurrences: {coverage['known_occurrence_count']} / {coverage['occurrence_count']} · "
            f"Known unique tactics: {coverage['known_unique_identity_count']} / {coverage['unique_identity_count']}"
        )

    async def choose_route_occurrence(self, occurrence_id):
        field = (
            "query_occurrence_id"
            if self.state.source == "New prepared route"
            else "occurrence_id"
        )
        await self.change(field, occurrence_id)

    def workspace_navigation(self):
        pg = self.state.analysis_domain == "PG strategies"
        domain = "Protecting Group strategies" if pg else "Tactics"
        active = self.state.pg_mode if pg else self.state.mode
        dataset = self.info["dataset_id"]
        with (
            ui.row()
            .classes(
                "ri-workspace-nav w-full items-center "
                + ("ri-nav-pg" if pg else "ri-nav-tactics")
            )
            .props(f'role=navigation aria-label="{dataset} → {domain} → {active}"')
        ):
            with ui.row().classes("ri-workspace-location items-center"):
                ui.button(dataset, on_click=self.change_dataset).props(
                    'flat dense no-caps aria-label="Change dataset"'
                ).tooltip("Change dataset")
                ui.icon("chevron_right", size="18px")
                with (
                    ui.button(domain)
                    .props(
                        "flat dense no-caps icon-right=expand_more "
                        'aria-label="Switch analysis domain"'
                    )
                    .classes("ri-domain-button")
                ):
                    with ui.menu():
                        for name, label, key in (
                            ("Tactics", "Tactics", "tactics"),
                            ("PG strategies", "Protecting Group strategies", "pg"),
                        ):
                            status = self.info.get(key, {})
                            item = ui.menu_item(
                                label,
                                on_click=lambda name=name: self.choose_domain(name),
                            ).props("role=menuitem")
                            item.set_enabled(status.get("available", key == "tactics"))
                            if status.get("reason"):
                                item.tooltip(status["reason"])
                ui.icon("chevron_right", size="18px").classes("ri-mode-divider")
            with (
                ui.row()
                .classes("ri-workspace-modes items-center")
                .props(f'role=group aria-label="{domain} modes"')
            ):
                modes = (
                    ("Route-wise", "PG-wise", "Tactic-wise", "Propose-PG")
                    if pg
                    else ("Route-wise", "Tactic-wise", "Composite-wise")
                )
                for mode in modes:
                    selected = mode == active
                    button = ui.button(
                        mode,
                        on_click=lambda mode=mode: (
                            self.choose_pg_mode(mode) if pg else self.choose_mode(mode)
                        ),
                    ).props(
                        f'no-caps dense aria-label="{"PG " if pg else ""}{mode}" '
                        f'aria-pressed="{str(selected).lower()}" '
                        + ("unelevated" if selected else "flat")
                    )
                    status = self.info.get(
                        "pg"
                        if pg
                        else "composites"
                        if mode == "Composite-wise"
                        else "tactics",
                        {},
                    )
                    button.set_enabled(status.get("available", False))
                    if status.get("reason"):
                        button.tooltip(status["reason"])
            ui.space()
            with ui.row().classes("ri-workspace-actions items-center"):
                ui.button(icon="apps", on_click=self.choose_analysis).props(
                    'flat dense round aria-label="Choose analysis"'
                ).tooltip("Choose analysis")
                ui.button(icon="info_outline", on_click=self.show_library_info).props(
                    'flat dense round aria-label="Library information"'
                ).tooltip("Library information")

    async def choose_domain(self, domain):
        if domain == "PG strategies":
            await self.choose_pg_mode(self.state.pg_mode)
        elif domain == "Tactics":
            await self.choose_mode(self.state.mode)

    def show_library_info(self):
        with ui.dialog() as dialog, ui.card().classes("ri-library-dialog"):
            with ui.row().classes("w-full items-center"):
                ui.label(f"Library information · {self.info['dataset_id']}").classes(
                    "text-h6"
                )
                ui.space()
                ui.button("Close", on_click=dialog.close).props("flat no-caps")
            ui.label(
                "Available libraries and their source routes were verified when this dataset loaded."
            ).classes("text-caption")
            for label, key in (
                ("Tactics", "tactics"),
                ("Protecting Group strategies", "pg"),
                ("Composites", "composites"),
            ):
                status = self.info.get(key, {})
                available = status.get("available", False)
                ui.label(
                    f"{label} · {'Available' if available else 'Unavailable'}"
                ).classes("text-subtitle1")
                if not available:
                    ui.label(status.get("reason", "No library loaded")).classes(
                        "text-caption break-all"
                    )
                profile = (
                    self.info.get("profile")
                    if key == "tactics"
                    else status.get("profile")
                )
                if available and profile:
                    with ui.expansion(f"{label} extraction profile").classes("w-full"):
                        ui.label(json.dumps(profile, indent=2)).classes("ri-inspector")
        dialog.on("hide", dialog.delete)
        dialog.open()

    def tactic_workspace(self):
        with ui.element("div").classes("ri-tactic-layout"):
            with ui.column().classes("ri-card ri-tactic-catalogue"):
                ui.label("Find tactics").classes("text-h6")
                self.navigation()
            with ui.column().classes("ri-card ri-route-column ri-tactic-workspace"):
                with ui.column().classes("ri-tactic-heading w-full"):
                    with ui.row().classes("items-center w-full"):
                        ui.label("Selected tactic").classes("text-h6")
                        ui.space()
                        if self.related_history:
                            ui.button(
                                "Back to previous tactic", on_click=self.back_related
                            ).props("flat")
                    if self.state.entry_id:
                        copy_full_id(self.state.entry_id)
                        record = (self.view.get("entry") or {}).get("entry", {})
                        ui.label(
                            f"{TACTIC_LABELS[self.state.kind]} · "
                            f"{record.get('route_count', 0)} source routes · "
                            f"{record.get('occurrence_count', 0)} occurrences"
                        ).classes("text-caption")
                    else:
                        ui.label("Select a tactic from the catalogue.").classes(
                            "text-caption"
                        )
                with ui.tabs(
                    value=self.state.tactic_workspace,
                    on_change=lambda e: self.change_tactic_workspace(e.value),
                ).classes("ri-tactic-tabs w-full"):
                    ui.tab("overview", label="Overview")
                    ui.tab("related", label="Related tactics")
                    ui.tab("sources", label="Source routes")
                self.tactic_workspace_content()

    async def change_tactic_workspace(self, value):
        if value not in {"overview", "related", "sources"}:
            return
        if value == self.state.tactic_workspace:
            return
        self.state.tactic_workspace = value
        # Presentation only: keep loaded chemistry, selections and worker results.
        await self.tactic_workspace_content.refresh()

    @ui.refreshable
    def tactic_workspace_content(self):
        with ui.column().classes("ri-tactic-content w-full"):
            if not self.state.entry_id:
                ui.label(
                    "Choose a tactic to inspect its rules, compare related tactics, "
                    "or explore its source routes."
                ).classes("ri-placeholder")
            elif self.state.tactic_workspace == "overview":
                self.rules_panel(show_identity=False)
            elif self.state.tactic_workspace == "related":
                self.related_panel()
            else:
                route_id = (self.state.tactic_route or {}).get("route_id")
                ui.label(
                    f"Route {route_id}" if route_id is not None else "Route viewer"
                ).classes("text-h6 ri-tactic-route-title")
                if route_id is not None:
                    self.source_occurrence_controls("tactic")
                else:
                    ui.label("Choose a source route from the table below.").classes(
                        "text-caption"
                    )
                if (self.view.get("selected") or {}).get("kind", "").endswith("_gap"):
                    ui.checkbox(
                        "Highlight skipped steps",
                        value=self.state.skipped,
                        on_change=lambda e: self.change("skipped", e.value),
                    )
                self.viewer = RouteViewer(
                    self.view.get("preview", {}),
                    self.select_reaction,
                    aam=self.state.aam,
                    on_aam_change=lambda e: self.change("aam", e.value),
                    layered=self.state.layered,
                    on_layered_change=lambda e: self.change("layered", e.value),
                )
                self.reactions = self.view.get("preview", {}).get("reactions", [])
                with ui.expansion("Reaction details and tactic membership").classes(
                    "w-full"
                ):
                    self.inspector = ui.label(
                        "Select a reaction marker in the route."
                    ).classes("ri-inspector")
                with ui.column().classes("ri-source-routes w-full"):
                    ui.label("Source routes").classes("text-h6")
                    self.route_table()

    def rules_panel(self, *, show_identity=True):
        svg, error = self.view.get("rule_svg"), self.view.get("rule_error")
        if self.state.mode == "Tactic-wise" and not (svg or error):
            entry = self.view.get("entry") or {}
            svg, error = entry.get("svg"), entry.get("error")
        if svg or error:
            with ui.expansion("Selected tactic rules", value=True).classes(
                "ri-rules-panel w-full"
            ):
                identifier = (self.view.get("selected") or {}).get(
                    "entry_id"
                ) or self.state.entry_id
                if identifier and show_identity:
                    copy_full_id(identifier)
                entry_record = (self.view.get("entry") or {}).get("entry", {})
                widths = (
                    entry_record.get("identity", {})
                    .get("equivalence_payload", {})
                    .get("inter_selection_gap_widths")
                )
                if widths is not None:
                    ui.label(
                        "Skipped reactions between selected steps: "
                        + ", ".join(map(str, widths))
                    ).classes("text-caption")
                if svg:
                    ui.html(inline_rule_glyphs(svg), sanitize=True).classes(
                        "ri-rules-content w-full"
                    )
                if error:
                    ui.label(error).classes("text-warning")
                self.composite_shortcut()

    def show_target(self, row):
        """Enlarge the existing vector depiction without changing route selection."""
        with ui.dialog() as dialog, ui.card().classes("ri-target-dialog"):
            with ui.row().classes("w-full items-center"):
                ui.label(f"Target · Route {row['route_id']}").classes("text-h6")
                ui.space()
                ui.button("Close", on_click=dialog.close).props("flat")
            ui.image(row["target_image"]).props("fit=contain no-spinner").classes(
                "ri-target-large"
            )
            ui.label(row["target_unmapped"]).classes("ri-target-smiles")
        dialog.on("hide", dialog.delete)
        dialog.open()

    def dataset_screen(self):
        with ui.column().classes("ri-welcome"):
            ui.label("YOUR REFERENCE COLLECTION").classes("ri-eyebrow")
            ui.label("Explore the chemistry behind a synthesis.").classes("ri-hero")
            ui.label(
                "Start with a dataset. Then follow a route or explore its reaction tactics."
            ).classes("ri-intro")
            if self.scanning:
                with ui.row().classes("items-center"):
                    ui.spinner(size="24px")
                    ui.label("Finding local datasets…")
            with ui.row().classes("ri-choice-grid"):
                for row in self.dataset_rows:
                    dataset = row["id"]
                    with ui.column().classes("ri-choice-card"):
                        with ui.row().classes("w-full items-center"):
                            ui.label(dataset).classes("ri-dataset-title")
                            ui.space()
                            ui.label(
                                "READY" if row["available"] else "NOT AVAILABLE"
                            ).classes(
                                "ri-availability"
                                if row["available"]
                                else "ri-unavailable"
                            )
                        ui.label(
                            "ABSynth · private local corpus"
                            if dataset == "absynth"
                            else "PaRoutes · merged n1 + n5"
                            if dataset == "n1+n5"
                            else "PaRoutes reference corpus"
                        ).classes("ri-choice-subtitle")
                        ui.label(row["reason"]).classes("ri-choice-description")
                        ui.space()
                        button = (
                            ui.button(
                                f"Load {dataset}",
                                on_click=lambda dataset=dataset: self.load_dataset(
                                    dataset
                                ),
                            )
                            .props("unelevated no-caps icon-right=arrow_forward")
                            .classes("ri-primary w-full")
                        )
                        if not row["available"]:
                            button.disable()
                        if self.loading_dataset == dataset:
                            button.props("loading")
                        self.audit_panel(dataset)
            with ui.row().classes("items-center w-full"):
                refresh = ui.button(
                    "Refresh datasets", on_click=self.scan_datasets
                ).props("flat no-caps icon=refresh")
                if self.loading_dataset or self.scanning:
                    refresh.disable()
                if self.info:
                    ui.button(
                        f"Return to {self.info['dataset_id']}",
                        on_click=self.return_to_loaded_dataset,
                    ).props("flat no-caps")
            ui.label(
                "Routes and libraries are discovered on this workstation. No uploads, remapping or re-extraction."
            ).classes("ri-footnote")

    def mode_screen(self):
        with ui.column().classes("ri-welcome ri-mode-chooser"):
            ui.button("Change dataset", on_click=self.change_dataset).props(
                "flat no-caps icon=arrow_back"
            )
            ui.label(f"{self.info['dataset_id']} · READY TO EXPLORE").classes(
                "ri-eyebrow"
            )
            ui.label("How would you like to explore?").classes("ri-hero")
            stats = {
                **self.info["statistics"],
                "reference_route_count_processed": self.info["route_count"],
            }
            metrics = [
                ("routes", "reference_route_count_processed"),
                ("unique tactics", "entry_count"),
                ("tactic occurrences", "occurrence_count"),
            ]
            if self.info.get("pg", {}).get("available"):
                stats["pg_event_count"] = self.info["pg"]["statistics"].get(
                    "event_occurrence_count", 0
                )
                metrics.append(("PG-events", "pg_event_count"))
            with ui.row().classes("ri-metrics"):
                for label, key in metrics:
                    with ui.column().classes("ri-metric"):
                        ui.label(f"{stats.get(key, 0):,}").classes("ri-metric-value")
                        ui.label(label).classes("ri-metric-label")
            with ui.row().classes("ri-domain-choices"):
                with (
                    ui.column()
                    .classes("ri-analysis-group ri-tactics-group w-full")
                    .props('role=group aria-label="Tactics"')
                ):
                    ui.label("Tactics").classes("ri-group-title")
                    if not self.info.get("tactics", {}).get("available", True):
                        ui.label(self.info["tactics"]["reason"]).classes("text-caption")
                    with ui.row().classes("ri-choice-grid"):
                        for mode, icon, description, button_label in (
                            (
                                "Route-wise",
                                "route",
                                "Inspect a complete route and highlight every extracted tactic at its exact reaction steps.",
                                "Analyse route-wise",
                            ),
                            (
                                "Tactic-wise",
                                "hub",
                                "Browse four tactic types, compare their support and follow each occurrence back to its source route.",
                                "Analyse tactic-wise",
                            ),
                            (
                                "Composite-wise",
                                "merge_type",
                                "Explore certified composite rules, their original tactic decompositions and exact source occurrences.",
                                "Analyse composite-wise",
                            ),
                        ):
                            with ui.column().classes("ri-choice-card ri-mode-card"):
                                with ui.row().classes("ri-mode-card-heading"):
                                    with ui.row().classes("items-center gap-2"):
                                        ui.icon(icon, size="20px").classes(
                                            "ri-mode-icon"
                                        )
                                        ui.label(mode).classes("ri-choice-title")
                                    button = (
                                        ui.button(
                                            button_label,
                                            on_click=lambda mode=mode: self.choose_mode(
                                                mode
                                            ),
                                        )
                                        .props(
                                            "unelevated no-caps icon-right=arrow_forward"
                                        )
                                        .classes("ri-primary")
                                    )
                                ui.label(description).classes("ri-choice-description")
                                if not self.info.get("tactics", {}).get(
                                    "available", True
                                ):
                                    button.disable()
                                if mode == "Composite-wise" and not self.info.get(
                                    "composites", {}
                                ).get("available"):
                                    button.disable()
                                    ui.label(
                                        self.info.get("composites", {}).get(
                                            "reason", "No companion loaded"
                                        )
                                    ).classes("text-caption")
                self.pg_mode_cards()
            ui.label(
                "Read-only library browsing · original route source retained"
            ).classes("ri-footnote")

    def navigation(self):
        if self.state.mode == "Composite-wise":
            self.composite_navigation()
        elif self.state.mode == "Tactic-wise":
            ui.select(
                TACTIC_LABELS,
                value=self.state.kind,
                label="Tactic type",
                on_change=lambda e: self.change("kind", e.value),
            )
            with ui.row():
                ui.number(
                    "Minimum rule count",
                    value=self.state.minimum_size,
                    min=0,
                    precision=0,
                    on_change=lambda e: self.change("minimum_size", int(e.value or 0)),
                ).classes("w-40")
                ui.number(
                    "Minimum supporting routes",
                    value=self.state.minimum_support,
                    min=1,
                    precision=0,
                    on_change=lambda e: self.change(
                        "minimum_support", max(1, int(e.value or 1))
                    ),
                ).classes("w-48")
            self.activator_controls()
            search = ui.input("Entry ID contains", value=self.state.tactic_search)
            search.on(
                "keydown.enter", lambda: self.change("tactic_search", search.value)
            )
            ui.button(
                "Filter tactics",
                on_click=lambda: self.change("tactic_search", search.value),
            ).props("outline")
            page = self.view.get("entries", EMPTY)
            table(
                page.rows,
                [
                    ("entry_id", "Tactic entry"),
                    ("size", "Size"),
                    ("route_count", "Routes"),
                    ("occurrence_count", "Occurrences"),
                ],
                key="entry_id",
                on_select=self.select_entry,
                selected_id=self.state.entry_id,
                page=page,
                sort_by=self.state.entry_sort_by,
                descending=self.state.entry_sort_descending,
                on_sort=lambda column, descending: self.sort_table(
                    "entry", column, descending
                ),
            )
            pager(page, lambda offset: self.change("entry_offset", offset))
            entry = self.view.get("entry")
            if entry:
                record = entry["entry"]
                ui.label(
                    f"{record['route_count']} source routes · {record['occurrence_count']} occurrences"
                ).classes("text-subtitle2")
                self.activator_details()
        else:
            if self.state.source == "Reference library":
                with ui.column().classes("ri-route-filters w-full gap-2"):
                    for kind in ("rrseq_cons", "rrseq_gap"):
                        with ui.row().classes("items-center w-full"):
                            ui.label(LABELS[kind]).classes("w-28")
                            ui.toggle(
                                {
                                    "any": "Any",
                                    "present": "Present",
                                    "absent": "Absent",
                                },
                                value=getattr(self.state, f"route_{kind}"),
                                on_change=lambda e, kind=kind: self.change(
                                    f"route_{kind}", e.value
                                ),
                            ).props(
                                f'no-caps unelevated aria-label="{LABELS[kind]} presence"'
                            )
                    ui.label(
                        "Both filters apply. Presence means at least one occurrence."
                    ).classes("text-caption")
                    ui.button("Reset filters", on_click=self.reset_route_filters).props(
                        "flat no-caps icon=restart_alt"
                    )
            search = ui.input(
                "Find exact route ID or target SMILES", value=self.state.route_search
            ).classes("w-full")
            search.on(
                "keydown.enter", lambda: self.change("route_search", search.value)
            )
            ui.button(
                "Find routes",
                on_click=lambda: self.change("route_search", search.value),
            ).props("outline")
            if self.state.source == "Reference library":
                page = self.view.get("routes", EMPTY)
                ui.label(
                    f"Showing {page.total:,} / {self.info['route_count']:,} routes"
                ).classes("text-caption ri-route-count")
            self.route_table()

    def source_routes_panel(self):
        composite = self.state.mode == "Composite-wise"
        prefix = "composite" if composite else "tactic"
        with ui.column().classes("ri-source-routes w-full"):
            ui.label("Source routes").classes("text-h6")
            self.route_table()
            self.source_occurrence_controls(prefix)

    def source_occurrence_controls(self, prefix):
        labels = TACTIC_LABELS if prefix == "tactic" else LABELS
        with ui.column().classes("ri-source-occurrence w-full"):
            page = self.view.get("occurrences", EMPTY)
            selected = self.view.get("selected")
            if page.total > 1:
                options = {
                    row[
                        "id"
                    ]: f"{labels[row['kind']]} · {', '.join(row['selected_paths'])} · {row['id']}"
                    for row in page.rows
                }
                if selected:
                    options.setdefault(selected["id"], selected["id"])
                ui.select(
                    options,
                    value=selected["id"] if selected else None,
                    label="Matching occurrence",
                    on_change=lambda e: self.change(f"{prefix}_occurrence_id", e.value),
                ).classes("w-full")
                if page.total > page.limit:
                    pager(
                        page,
                        lambda offset: self.change(
                            f"{prefix}_occurrence_offset", offset
                        ),
                    )
            if selected:
                ui.label(f"Selected occurrence: {selected['id']}").classes(
                    "text-caption break-all"
                )
            ui.button("Inspect this route", on_click=self.inspect_route).set_enabled(
                getattr(self.state, f"{prefix}_route") is not None
            )

    def route_table(self):
        page = self.view.get("routes", EMPTY)
        fields = [
            ("route_id", "Route"),
            ("target_image", "Target"),
            ("target_unmapped", "SMILES"),
        ]
        if self.state.mode != "Route-wise":
            fields.insert(0, ("dataset_id", "Corpus"))
        if self.state.mode == "Composite-wise":
            fields += [
                ("matching_occurrence_count", "Certified occurrences"),
            ]
        elif (
            self.state.mode == "Tactic-wise" or self.state.source == "Reference library"
        ):
            fields += [
                ("occurrence_count", "Tactic occurrences"),
                ("unique_tactic_count", "Unique tactics"),
            ]
        if self.state.mode == "Tactic-wise":
            fields.append(("matching_occurrence_count", "Selected tactic occurrences"))
        if self.state.mode == "Route-wise":
            fields = [
                ("route_id", "Route"),
                ("target_image", "Target"),
                ("reaction_count", "Steps"),
            ]
            if self.state.source == "Reference library":
                fields.append(("occurrence_count", "Tactics"))
        route = (
            self.state.composite_route
            if self.state.mode == "Composite-wise"
            else self.state.tactic_route
            if self.state.mode == "Tactic-wise"
            else self.state.route
        )
        selected_id = route_token(ReferenceRouteKey.from_dict(route)) if route else None
        if (
            self.state.mode == "Route-wise"
            and self.state.source == "New prepared route"
        ):
            selected_id = self.state.query_route_id
        catalogue = table(
            page.rows,
            fields,
            on_select=self.select_route,
            selected_id=selected_id,
            on_target=self.show_target,
            page=page,
            sort_by=self.state.route_sort_by,
            descending=self.state.route_sort_descending,
            on_sort=(
                lambda column, descending: self.sort_table("route", column, descending)
            )
            if self.state.mode == "Route-wise"
            else None,
        )
        if self.state.mode == "Route-wise":
            catalogue.classes("ri-route-catalogue")
            catalogue.tooltip(
                "Steps = reaction steps; Tactics = tactic occurrences. Click a target to enlarge it and view its SMILES."
            )
            if selected_id is not None:
                # A route/occurrence redraw must not hide the selected row at
                # the bottom of this independently scrolling catalogue.
                ui.timer(
                    0.05,
                    lambda: ui.run_javascript(
                        f"""requestAnimationFrame(() => {{
                            const root = document.getElementById('c{catalogue.id}');
                            const middle = root?.querySelector('.q-table__middle');
                            const row = root?.querySelector('tbody [aria-checked="true"]')?.closest('tr');
                            if (!middle || !row) return;
                            const bounds = middle.getBoundingClientRect();
                            const selected = row.getBoundingClientRect();
                            if (selected.bottom > bounds.bottom)
                                middle.scrollTop += selected.bottom - bounds.bottom;
                        }});"""
                    ),
                    once=True,
                )
        pager(
            page,
            lambda offset: self.change(
                "composite_source_offset"
                if self.state.mode == "Composite-wise"
                else "source_offset"
                if self.state.mode == "Tactic-wise"
                else "route_offset",
                offset,
            ),
        )

    def occurrences_panel(self, *, show_selection=True):
        page = self.view.get("occurrences", EMPTY)
        if show_selection:
            ui.label(f"Tactic occurrences · {page.total}").classes("text-h6")
        if (
            self.state.assessment
            and self.state.mode == "Route-wise"
            and self.state.source == "New prepared route"
        ):
            assessment = self.state.assessment
            if show_selection:
                self.route_assessment_summary()
            with ui.expansion("Coverage and diagnostics"):
                ui.label(
                    json.dumps(
                        {
                            k: v
                            for k, v in assessment.items()
                            if k not in {"matches", "retro_bleu_bigrams"}
                        },
                        indent=2,
                    )
                ).classes("ri-inspector")
            ui.button(
                "Download assessment JSON",
                on_click=lambda: ui.download.content(
                    json.dumps(assessment, indent=2),
                    "assessment.json",
                    "application/json",
                ),
            ).props("flat")
        for kind in KINDS:
            rows = [r for r in page.rows if r["kind"] == kind]
            if rows:
                ui.label(LABELS[kind]).classes("text-subtitle2")
                table(
                    rows,
                    [
                        ("size", "Size"),
                        ("selected_paths", "Selected paths"),
                        ("skipped_paths", "Skipped paths"),
                        ("entry_id", "Tactic entry"),
                        ("route_count", "Route support"),
                        ("known", "Known"),
                    ],
                    on_select=self.select_occurrence,
                    selected_id=(self.view.get("selected") or {}).get("id"),
                )
        if page.total == 0:
            ui.label(
                "No stored tactic occurrences for this selection. This does not imply absence of a synthetic tactic."
            ).classes("text-caption")
        pager(
            page,
            lambda offset: self.change(
                "tactic_occurrence_offset"
                if self.state.mode == "Tactic-wise"
                else "occurrence_offset",
                offset,
            ),
        )
        selected = self.view.get("selected")
        if selected and show_selection:
            ui.label(f"Selected occurrence: {selected['id']}").classes(
                "text-caption break-all"
            )
        if self.state.mode == "Route-wise" and show_selection:
            ui.button("Explore this tactic", on_click=self.explore_tactic).set_enabled(
                bool(selected and selected["entry_id"])
            )
        elif self.state.mode != "Route-wise":
            ui.button("Inspect this route", on_click=self.inspect_route).set_enabled(
                self.state.tactic_route is not None
            )
        ui.button("Export occurrence table", on_click=self.export_occurrences).props(
            "flat"
        ).set_enabled(page.total > 0)

    def query_controls(self):
        with ui.row().classes("ri-card w-full items-center"):
            self.query_path = ui.input(
                "Prepared query JSON",
                value=self.state.query_path,
                on_change=lambda e: setattr(self.state, "query_path", e.value),
            ).classes("grow")
            ui.button("Open query routes", on_click=self.open_query)
            self.config_path = ui.input(
                "Matching extraction YAML",
                value=self.state.config_path,
                on_change=lambda e: setattr(self.state, "config_path", e.value),
            ).classes("grow")
            ui.button(
                "Analyse selected route", on_click=self.start_analysis
            ).set_enabled(self.state.query_route_id is not None)
            ui.button("Cancel analysis", on_click=self.cancel_analysis).props("outline")
            self.job_label = ui.label("Ready")
            completed = self.jobs.completed()
            ui.select(
                completed,
                label="Saved analyses",
                on_change=lambda e: self.load_result(e.value),
            ).classes("w-80")
