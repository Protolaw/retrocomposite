"""Optional same-LHS worker and isolated composite comparison workspace."""

from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import sqlite3
import threading
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from pathlib import Path
from xml.etree import ElementTree as ET

from nicegui import ui

from route_inspector.composite_rules.browsing import CompositeBrowser
from route_inspector.composite_rules.lhs import (
    INDEX_VERSION,
    CompositeLHSIndex,
    library_entries,
)
from route_inspector.composite_rules.library import CompositeDecompositionLibrary
from route_inspector.gui.composite_depictions import CompositeDepictions
from route_inspector.gui.inspection import render_composite
from route_inspector.gui.labels import TACTIC_LABELS
from route_inspector.gui.state import ExplorerState
from route_inspector.gui.svg import inline_rule_glyphs
from route_inspector.gui.verification import artifact_snapshot
from route_inspector.gui.widgets import copy_full_id, pager, table
from route_inspector.reference_library import ReferenceTacticLibrary
from route_inspector.rules.config import dependency_version

_LOCKS = {}
_GUARD = threading.Lock()


class CompositeLHSSession:
    """Own connections on the optional worker; reuse the GUI's verified snapshot."""

    def __init__(self, output):
        self.output = Path(output)
        self.reference = self.composites = self.index = self.browser = None
        self.context = None
        self.depictions = CompositeDepictions(output)

    def close(self):
        for resource in (self.index, self.composites, self.reference):
            if resource is not None:
                resource.close()
        self.reference = self.composites = self.index = self.browser = None
        self.context = None
        self.depictions.close()

    @staticmethod
    def check_snapshot(context):
        reference, composites, encoded = context
        observed = {
            "reference": artifact_snapshot(reference),
            "composites": artifact_snapshot(composites),
        }
        if observed != json.loads(encoded):
            raise ValueError(
                "Library changed since dataset verification; reload the dataset"
            )

    def prepare(self, context):
        self.check_snapshot(context)
        if self.context == context:
            return
        self.close()
        reference, composites, encoded = context
        identity = json.dumps(
            {
                "version": INDEX_VERSION,
                "snapshots": json.loads(encoded),
                "chython": dependency_version("chython-synplan"),
            },
            sort_keys=True,
        )
        path = (
            self.output
            / "composite_lhs"
            / (hashlib.sha256(identity.encode()).hexdigest() + ".sqlite")
        )
        try:
            # The owning GUI session verified these exact artifacts. Fast opens
            # give this worker independent handles without repeating that audit.
            self.reference = ReferenceTacticLibrary.load(reference, verification="fast")
            self.composites = CompositeDecompositionLibrary.load(
                composites, verification="fast"
            )
            self.browser = CompositeBrowser(self.composites, self.reference)
            if self.reference._connection is not None:
                self.reference._connection.execute("PRAGMA query_only = ON")
            with _GUARD:
                lock = _LOCKS.setdefault(str(path), threading.Lock())
            with lock:
                try:
                    self.index = CompositeLHSIndex(path)
                    if not self.index.valid(identity):
                        self.index.close()
                        self.index = None
                except (sqlite3.Error, OSError, TypeError, IndexError):
                    if self.index is not None:
                        self.index.close()
                    self.index = None
                if self.index is None:
                    CompositeLHSIndex.build(
                        path, library_entries(self.composites), identity
                    )
                    self.index = CompositeLHSIndex(path)
            self.check_snapshot(context)
            self.context = context
        except Exception:
            self.close()
            raise

    def query(self, context, composite_id, offset):
        self.prepare(context)
        try:
            result = self.browser.same_lhs(
                composite_id, index=self.index, offset=offset
            )
        except sqlite3.Error:
            # A cache may be damaged after it was opened. Recheck/rebuild once,
            # without treating corruption as an empty relationship result.
            self.close()
            self.prepare(context)
            result = self.browser.same_lhs(
                composite_id, index=self.index, offset=offset
            )
        # The page becomes selectable only when its cached drawings are ready.
        # A row click then only changes selection; it never launches rendering.
        previews, errors, rendered = {}, {}, {}
        for row in result["page"].rows:
            try:
                for rule in (row["selected_rule"], row["rule"]):
                    if rule not in rendered:
                        rendered[rule] = highlighted_svg(self.depictions.get(rule))
                previews[row["composite_id"]] = (
                    rendered[row["selected_rule"]],
                    rendered[row["rule"]],
                )
            except Exception as exc:
                errors[row["composite_id"]] = f"Stored rule drawing unavailable: {exc}"
        return {**result, "previews": previews, "preview_errors": errors}

    def preview(self, context, row):
        self.prepare(context)
        return tuple(
            highlighted_svg(self.depictions.get(rule))
            for rule in (row["selected_rule"], row["rule"])
        )


def highlighted_lhs(rule):
    """Highlight the LHS area without changing coordinates, maps or chemistry."""
    return highlighted_svg(render_composite(rule))


def highlighted_svg(svg):
    """Mark an existing drawing without running the rule renderer again."""
    root = ET.fromstring(inline_rule_glyphs(svg))
    arrow = next((child for child in root if child.get("marker-end")), None)
    if arrow is None:
        raise ValueError("Composite depiction lacks its reaction arrow")
    x, y, _, height = map(float, root.get("viewBox").split())
    width = float(arrow.get("x1")) - x - 0.15
    rectangle = ET.Element(
        "{http://www.w3.org/2000/svg}rect",
        {
            "x": str(x),
            "y": str(y),
            "width": str(max(0, width)),
            "height": str(height),
            "fill": "#DCFCE7",
            "rx": "0.12",
            "data-role": "same-lhs",
        },
    )
    ET.SubElement(
        rectangle, "{http://www.w3.org/2000/svg}title"
    ).text = "Equivalent complete LHS"
    root.insert(0, rectangle)
    return ET.tostring(root, encoding="unicode")


class CompositeLHSScreens:
    def init_composite_lhs(self):
        self.lhs_worker = CompositeLHSSession(self.service.output)
        self.lhs_executor = ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="composite-lhs"
        )
        self.lhs_request = 0
        self.lhs_key = None
        self.lhs_view = {}
        self.lhs_preview = None
        self.lhs_error = self.lhs_preview_error = None
        self.lhs_loading = False
        self.lhs_tasks = set()
        self.lhs_history = []
        self.lhs_pages = OrderedDict()

    def lhs_active(self):
        return (
            self.screen == "explorer"
            and self.state.analysis_domain == "Tactics"
            and self.state.mode == "Composite-wise"
            and self.state.composite_workspace == "same_lhs"
            and bool(self.state.composite_id)
        )

    def invalidate_lhs(self):
        self.lhs_request = getattr(self, "lhs_request", 0) + 1
        self.lhs_key = None

    def current_lhs_key(self):
        return (
            self.view.get("composite_lhs_context"),
            self.state.composite_id,
            self.state.composite_lhs_offset,
        )

    def schedule_lhs(self):
        if not self.lhs_active():
            self.invalidate_lhs()
            return
        key = self.current_lhs_key()
        if key == self.lhs_key:
            return
        self.invalidate_lhs()
        self.lhs_key = key
        cached = self.lhs_pages.get(key)
        if cached is not None:
            self.lhs_pages.move_to_end(key)
            self.lhs_view = cached
            self.lhs_loading = False
            self.lhs_error = None
            self.use_lhs_preview()
            return
        self.lhs_loading = True
        self.lhs_view = {}
        self.lhs_preview = self.lhs_error = self.lhs_preview_error = None
        task = asyncio.create_task(self.load_lhs(self.lhs_request, key))
        self.lhs_tasks.add(task)
        task.add_done_callback(self.lhs_tasks.discard)

    def lhs_current(self, request, key):
        return (
            self.lhs_active()
            and request == self.lhs_request
            and key == self.current_lhs_key()
        )

    async def load_lhs(self, request, key):
        try:
            result = await asyncio.get_running_loop().run_in_executor(
                self.lhs_executor, partial(self.lhs_worker.query, *key)
            )
            if not self.lhs_current(request, key):
                return
            self.lhs_view = result
            self.lhs_pages[key] = result
            while len(self.lhs_pages) > 4:
                self.lhs_pages.popitem(last=False)
        except Exception as exc:
            if not self.lhs_current(request, key):
                return
            self.lhs_error = f"Same-LHS search unavailable: {exc}"
        self.lhs_loading = False
        self.use_lhs_preview()
        await self.composite_lhs_panel.refresh()

    def lhs_selected_row(self):
        page = self.lhs_view.get("page")
        return (
            next(
                (
                    r
                    for r in page.rows
                    if r["composite_id"] == self.state.composite_lhs_selected
                ),
                None,
            )
            if page
            else None
        )

    async def change_lhs_page(self, offset):
        self.state.composite_lhs_offset = offset
        self.state.composite_lhs_selected = None
        self.schedule_lhs()
        await self.composite_lhs_panel.refresh()

    async def retry_lhs(self):
        self.lhs_pages.pop(self.current_lhs_key(), None)
        self.invalidate_lhs()
        self.schedule_lhs()
        await self.composite_lhs_panel.refresh()

    async def preview_lhs(self, row, *, key=None):
        page = self.lhs_view.get("page")
        if (
            not self.lhs_active()
            or page is None
            or (key is not None and key != self.current_lhs_key())
            or not any(r["composite_id"] == row["composite_id"] for r in page.rows)
        ):
            return
        self.state.composite_lhs_selected = row["composite_id"]
        self.use_lhs_preview()
        await self.composite_lhs_panel.refresh()

    def use_lhs_preview(self):
        cid = self.state.composite_lhs_selected
        self.lhs_preview = self.lhs_view.get("previews", {}).get(cid)
        self.lhs_preview_error = self.lhs_view.get("preview_errors", {}).get(cid)

    async def open_lhs_composite(self):
        row = self.lhs_selected_row()
        if row is None:
            return
        old = copy.deepcopy(self.state)
        request, key = self.lhs_request, self.current_lhs_key()
        try:
            link = await self.call(
                self.service.composite_same_lhs_destination,
                row["composite_id"],
                old.composite_route,
            )
        except Exception as exc:
            if self.lhs_current(request, key):
                self.fail(exc)
            return
        if not self.lhs_current(request, key) or self.lhs_selected_row() != row:
            return
        self.lhs_history.append(old)
        defaults = ExplorerState()
        for name in vars(defaults):
            if name.startswith("composite_") or name.startswith("overlap_"):
                setattr(self.state, name, copy.deepcopy(getattr(defaults, name)))
        self.state.explore_composite(link)
        self.invalidate_lhs()
        await self.refresh()

    async def back_lhs_composite(self):
        if not self.lhs_history:
            return
        previous = self.lhs_history.pop()
        for name in vars(previous):
            if (
                name.startswith("composite_")
                or name.startswith("overlap_")
                or name in {"aam", "layered", "skipped"}
            ):
                setattr(self.state, name, copy.deepcopy(getattr(previous, name)))
        self.invalidate_lhs()
        await self.refresh()

    @ui.refreshable
    def composite_lhs_preview(self):
        if self.lhs_preview_error:
            ui.label(f"Comparison unavailable: {self.lhs_preview_error}").classes(
                "text-warning"
            )
            ui.button(
                "Retry comparison",
                on_click=self.retry_lhs,
            ).props("flat")
        elif self.lhs_preview:
            row = self.lhs_selected_row()
            for label, svg, cid, vid in zip(
                ("Selected composite", "Related composite"),
                self.lhs_preview,
                (self.state.composite_id, row["composite_id"]),
                (row["selected_variant_id"], row["variant_id"]),
            ):
                with ui.column().classes("ri-lhs-rule w-full"):
                    with ui.row().classes("w-full items-center justify-between"):
                        ui.label(label).classes("text-subtitle1")
                        if label == "Related composite":
                            ui.button(
                                "Investigate this composite",
                                icon="arrow_forward",
                                on_click=self.open_lhs_composite,
                            ).props("no-caps").tooltip(
                                "Open its overview, decompositions and source routes. "
                                "Back to previous composite returns to this comparison."
                            )
                    copy_full_id(cid)
                    ui.html(svg, sanitize=True).classes("ri-rules-content w-full")
                    with ui.expansion("Matching certified variant").classes("w-full"):
                        copy_full_id(vid)
                        ui.label(
                            row["selected_rule"]
                            if label == "Selected composite"
                            else row["rule"]
                        ).classes("text-caption break-all")
        else:
            ui.label("Stored rule drawing unavailable.").classes("text-warning")

    @ui.refreshable
    def composite_lhs_panel(self):
        if not self.lhs_active():
            return
        with ui.column().classes("ri-composite-lhs w-full"):
            ui.label("Same LHS").classes("text-h6")
            ui.label(
                "Exact equality of the complete target-side query before >> in the stored "
                "retrosynthetic rule, ignoring atom-map numbering. Searches all composites "
                "in this dataset, independently of catalogue filters."
            ).classes("text-caption")
            current = self.view.get("composite", {})
            with ui.column().classes("ri-lhs-fragment w-full"):
                ui.label("Selected composite LHS").classes("text-subtitle1").tooltip(
                    "LHS of the Overview representative. Matching certified variants appear in the comparison below."
                )
                if current.get("lhs_svg"):
                    ui.html(current["lhs_svg"], sanitize=True).classes(
                        "ri-lhs-fragment-drawing"
                    )
                elif current.get("lhs_error"):
                    ui.label(current["lhs_error"]).classes("text-warning")
            if self.lhs_loading:
                ui.spinner(size="sm")
                ui.label("Reading related composites and saved drawings…")
                return
            if self.lhs_error:
                ui.label(self.lhs_error).classes("text-warning")
                ui.button("Retry same-LHS search", on_click=self.retry_lhs).props(
                    "flat"
                )
                return
            diagnostics = self.lhs_view.get("diagnostics", {})
            if diagnostics.get("unavailable_variants"):
                ui.label(
                    f"Partial results: {diagnostics['unavailable_variants']} variants in "
                    f"{diagnostics['unavailable_composites']} composites could not be compared; "
                    f"{len(diagnostics['selected'])} belong to the selected composite."
                ).classes("text-warning")
                with ui.expansion("Unavailable comparisons"):
                    ui.code(
                        json.dumps(diagnostics["details"], indent=2), language="json"
                    )
            page = self.lhs_view.get("page")
            if page is None:
                return
            ui.label(f"{page.total} related composites").classes("text-subtitle2")
            if not page.total:
                ui.label(
                    "No equivalent LHS found among successfully compared variants."
                )
                return
            if self.lhs_selected_row():
                ui.label(
                    "Green: equivalent complete LHS. Original atom numbers are retained; RHS fragments may differ."
                ).classes("ri-lhs-legend text-caption")
                ui.button("Open composite", on_click=self.open_lhs_composite)
                self.composite_lhs_preview()
            else:
                ui.label(
                    "Select a row below to compare rules without navigating."
                ).classes("text-caption")
            table(
                [
                    {**r, "kinds_label": [TACTIC_LABELS[k] for k in r["kinds"]]}
                    for r in page.rows
                ],
                [
                    ("composite_id", "Composite"),
                    ("product_count", "RHS fragments"),
                    ("tactic_sizes", "Tactic sizes"),
                    ("kinds_label", "Source tactic kinds"),
                    ("route_count", "Routes"),
                ],
                key="composite_id",
                on_select=partial(self.preview_lhs, key=self.current_lhs_key()),
                selected_id=self.state.composite_lhs_selected,
            )
            pager(page, self.change_lhs_page)
