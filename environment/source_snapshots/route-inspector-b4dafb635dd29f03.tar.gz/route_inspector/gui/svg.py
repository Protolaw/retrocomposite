"""Keep local SVG glyph references visible through the browser sanitizer."""

from copy import deepcopy
from xml.etree import ElementTree as ET

SVG = "http://www.w3.org/2000/svg"
XLINK = "http://www.w3.org/1999/xlink"
ET.register_namespace("", SVG)
ET.register_namespace("xlink", XLINK)


def inline_glyphs(svg: str) -> str:
    """Expand local ``use`` glyphs, which DOMPurify intentionally removes.

    Only our renderer output enters here. The result is still sanitized by
    NiceGUI; do not disable sanitization to retain chemical atom labels.
    """
    root = ET.fromstring(svg)
    by_id = {node.get("id"): node for node in root.iter() if node.get("id")}

    def expand(node, visiting=frozenset()):
        for child in list(node):
            if child.tag == f"{{{SVG}}}use":
                href = child.get(f"{{{XLINK}}}href", child.get("href", ""))
                if not href.startswith("#") or href[1:] not in by_id:
                    raise ValueError(
                        "SVG glyph must reference a local renderer-defined ID"
                    )
                target = href[1:]
                if target in visiting:
                    raise ValueError("cyclic SVG glyph reference")
                attributes = {
                    k: v
                    for k, v in child.attrib.items()
                    if k not in {"href", f"{{{XLINK}}}href"}
                }
                wrapper = ET.Element(f"{{{SVG}}}g", attributes)
                clone = deepcopy(by_id[target])
                for descendant in clone.iter():
                    descendant.attrib.pop("id", None)
                wrapper.append(clone)
                expand(wrapper, visiting | {target})
                index = list(node).index(child)
                node.remove(child)
                node.insert(index, wrapper)
            else:
                expand(child, visiting)

    expand(root)
    return ET.tostring(root, encoding="unicode")


def inline_rule_glyphs(html: str) -> str:
    """Rule panels are generated markup wrapping one or more SVG documents."""
    import re

    pieces, depth, cursor, start = [], 0, 0, 0
    for tag in re.finditer(r"<(/?)svg\b[^>]*>", html):
        if not tag.group(1):
            if depth == 0:
                start = tag.start()
            depth += 1
        else:
            depth -= 1
            if depth == 0:
                pieces.extend(
                    (html[cursor:start], inline_glyphs(html[start : tag.end()]))
                )
                cursor = tag.end()
    if depth:
        raise ValueError("unbalanced rule SVG")
    pieces.append(html[cursor:])
    return "".join(pieces)


def composite_lhs_fragment(svg: str) -> str:
    """Crop the already drawn query to its LHS; no chemistry or layout work.

    The clip also excludes RHS atoms from the visible drawing when embedded in
    HTML. Coordinates and atom labels on the LHS remain exactly as depicted.
    """
    root = ET.fromstring(inline_rule_glyphs(svg))
    arrow = next((child for child in root if child.get("marker-end")), None)
    if arrow is None:
        raise ValueError("Composite depiction lacks its reaction arrow")
    x, y, _, height = map(float, root.get("viewBox").split())
    width = float(arrow.get("x1")) - x - 0.15
    if width <= 0:
        raise ValueError("Composite depiction has an empty LHS area")
    root.set("viewBox", f"{x} {y} {width} {height}")
    root.set("width", f"{width}cm")
    root.set("height", f"{height}cm")
    root.set("overflow", "hidden")
    root.set("data-role", "lhs-fragment")
    root.remove(arrow)
    return ET.tostring(root, encoding="unicode")
