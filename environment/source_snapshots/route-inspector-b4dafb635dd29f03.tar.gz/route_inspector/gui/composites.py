"""Composite-mode presentation and read-only selection orchestration."""

import json

from nicegui import ui

from route_inspector.gui.composite_lhs import CompositeLHSScreens
from route_inspector.gui.labels import TACTIC_LABELS
from route_inspector.gui.state import ROUTE_PAGE_SIZE
from route_inspector.gui.svg import inline_rule_glyphs
from route_inspector.gui.widgets import RouteViewer, copy_full_id, pager, table
from route_inspector.reference_library.browsing import BrowsePage

KINDS = {None: "All", "rrseq_cons": "RRSeq_cons", "rrsubtree_cons": "RRSubtree_cons"}
OVERLAP_FILTERS = {"all": "all", "overlap": "matched", "novel": "unmatched"}


def fetch_composite(service, state, result):
    result["composite_lhs_context"] = service.composite_lhs_context
    result["overlap_status"] = service.overlap_status()
    overlap = OVERLAP_FILTERS[state.composite_submode]
    if overlap != "all" and result["overlap_status"]["state"] != "completed":
        result["entries"] = BrowsePage((), 0, 0, ROUTE_PAGE_SIZE)
        return None, None
    result["entries"] = service.composite_entries(
        kind=state.composite_kind,
        minimum_support=state.composite_minimum_support,
        search=state.composite_search,
        offset=state.composite_offset,
        sort_by=state.composite_sort_by,
        descending=state.composite_sort_descending,
        overlap=overlap,
        ring_breaking_only=state.composite_ring_breaking_only,
        activator_filter=state.composite_activator_filter,
    )
    key, selected = state.composite_route, state.composite_occurrence_id
    if not state.composite_id:
        return None, None
    candidates = service.composite_entries(
        search=state.composite_id,
        kind=state.composite_kind,
        minimum_support=state.composite_minimum_support,
        overlap=overlap,
        ring_breaking_only=state.composite_ring_breaking_only,
        activator_filter=state.composite_activator_filter,
    )
    if state.composite_search not in state.composite_id or not any(
        row["composite_id"] == state.composite_id for row in candidates.rows
    ):
        result["clear_composite_selection"] = True
        return None, None
    if state.composite_submode == "overlap":
        result["overlap_evidence"] = service.overlap_evidence(
            state.composite_id,
            offset=state.overlap_evidence_offset,
            selected=state.overlap_step_id,
            aam=state.aam,
        )
    result["composite"] = service.composite_entry(state.composite_id)
    groups = service.composite_tactics(state.composite_id, kind=state.composite_kind)
    result["composite_tactics"] = groups
    link = service.composite_link(selected) if selected else None
    tactic_id = state.composite_tactic_id or (
        link["tactic_entry_id"]
        if link
        else groups[0]["tactic_entry_id"]
        if groups
        else None
    )
    group = next(
        (group for group in groups if group["tactic_entry_id"] == tactic_id), None
    )
    if group is None:
        if tactic_id is not None or selected is not None:
            raise ValueError(
                "Selected occurrence or tactic does not belong to this composite"
            )
        return None, None
    result["active_composite_tactic_id"] = tactic_id
    result["composite_tactic"] = group
    result["routes"] = service.composite_routes(
        state.composite_id,
        kind=state.composite_kind,
        offset=state.composite_source_offset,
        limit=ROUTE_PAGE_SIZE,
        tactic_entry_id=tactic_id,
    )
    if key is None and result["routes"].rows:
        row = result["routes"].rows[0]
        key = {
            name: row[name] for name in ("dataset_id", "source_identity", "route_id")
        }
        result["active_composite_route"] = key
    if key is not None:
        result["occurrences"] = service.composite_occurrences(
            state.composite_id,
            kind=state.composite_kind,
            route=key,
            offset=state.composite_occurrence_offset,
            tactic_entry_id=tactic_id,
        )
        if result["occurrences"].total == 0:
            raise ValueError(
                "Selected route does not belong to this composite/tactic selection"
            )
        if selected is None and result["occurrences"].rows:
            selected = result["occurrences"].rows[0]["id"]
            result["active_composite_occurrence_id"] = selected
    if selected:
        link = service.composite_link(selected)
        if (
            link is None
            or link["composite_id"] != state.composite_id
            or (state.composite_kind and link["kind"] != state.composite_kind)
            or link["route"] != key
            or link["tactic_entry_id"] != tactic_id
        ):
            raise ValueError(
                "Selected occurrence does not belong to this composite/source selection"
            )
        result["composite_link"] = link
        result["certified_composite"] = service.composite_certified_depiction(
            link["certified_rule"]
        )
    return key, selected


class CompositeScreens(CompositeLHSScreens):
    def composite_workspace(self):
        with ui.element("div").classes("ri-composite-layout"):
            with ui.column().classes("ri-card ri-composite-catalogue-pane"):
                self.composite_navigation()
            with ui.column().classes("ri-card ri-route-column ri-composite-workspace"):
                if getattr(self, "lhs_history", ()):
                    ui.button(
                        "Back to previous composite",
                        icon="arrow_back",
                        on_click=self.back_lhs_composite,
                    ).props("flat no-caps")
                with ui.tabs(
                    value=self.state.composite_workspace,
                    on_change=lambda e: self.change_composite_workspace(e.value),
                ).classes("ri-composite-tabs w-full"):
                    ui.tab("overview", label="Overview")
                    ui.tab("decompositions", label="Decompositions")
                    ui.tab("sources", label="Source routes")
                    ui.tab("same_lhs", label="Same LHS")
                self.composite_workspace_content()

    async def change_composite_workspace(self, value):
        if value not in {"overview", "decompositions", "sources", "same_lhs"}:
            return
        if value == self.state.composite_workspace:
            return
        self.state.composite_workspace = value
        self.schedule_lhs()
        # Tab changes only rearrange already loaded evidence, without a fetch.
        await self.composite_workspace_content.refresh()

    @ui.refreshable
    def composite_workspace_content(self):
        with ui.column().classes("ri-composite-content w-full"):
            if (
                not self.view.get("composite")
                or self.state.composite_workspace == "overview"
            ):
                self.composite_panel()
            elif self.state.composite_workspace == "same_lhs":
                self.composite_lhs_panel()
            else:
                self.composite_tactic_selector()
                if self.state.composite_workspace == "decompositions":
                    self.composite_decompositions()
                else:
                    self.composite_sources()

    def composite_tactic_selector(self):
        groups = self.view.get("composite_tactics", ())
        ui.select(
            {
                g["tactic_entry_id"]: (
                    f"{TACTIC_LABELS[g['kind']]} · {g['tactic_entry_id'][:20]}… · "
                    f"{g['occurrence_count']} occurrences · {g['route_count']} routes"
                )
                for g in groups
            },
            value=self.state.composite_tactic_id,
            label="Source tactic",
            on_change=lambda e: self.select_composite_tactic(e.value),
        ).classes("w-full")
        ui.label(
            f"{len(groups)} tactics · ordered by certified occurrences in this composite"
        ).classes("text-caption")

    def composite_source_annotation(self):
        annotation = (self.view.get("composite_link") or {}).get("ring_breaking") or {}
        flag = annotation.get("value")
        label = "Yes" if flag is True else "No" if flag is False else "Unknown"
        ui.label(f"Selected source ring-breaking: {label}").classes("text-caption")
        if annotation.get("diagnostic"):
            ui.label(annotation["diagnostic"]).classes("text-warning text-caption")

    def composite_sources(self):
        route_id = (self.state.composite_route or {}).get("route_id")
        ui.label(
            f"Route {route_id}" if route_id is not None else "Route viewer"
        ).classes("text-h6")
        self.source_occurrence_controls("composite")
        self.composite_source_annotation()
        self.viewer = RouteViewer(
            self.view.get("preview", {}),
            self.select_reaction,
            aam=self.state.aam,
            on_aam_change=lambda e: self.change("aam", e.value),
            layered=self.state.layered,
            on_layered_change=lambda e: self.change("layered", e.value),
        )
        self.reactions = self.view.get("preview", {}).get("reactions", [])
        with ui.expansion("Reaction details and tactic membership").classes("w-full"):
            self.inspector = ui.label("Select a reaction marker in the route.").classes(
                "ri-inspector"
            )
        with ui.column().classes("ri-source-routes w-full"):
            ui.label("Source routes for selected tactic").classes("text-h6")
            self.route_table()

    @ui.refreshable
    def composite_overlap_status(self):
        status = self.view.get("overlap_status", {"state": "idle"})
        self.overlap_label = ui.label(status.get("message", "")).classes("text-caption")
        if status["state"] in {"failed", "cancelled"}:
            ui.button("Retry preparation", on_click=self.retry_overlap).props("no-caps")
        if status["state"] == "completed":
            summary = status["summary"]
            ui.label(
                f"{summary['successful_reactions']:,}/{summary['total_reactions']:,} reactions extracted · {summary['unique_rules']:,} single-step rules"
            ).classes("text-caption")
            ui.label(
                f"{summary['matched_composites']:,} composites matched · {summary['unmatched_composites']:,} without a verified match"
            ).classes("text-caption")
            if summary["failed_reactions"] or summary["skipped_reactions"]:
                ui.label(
                    f"{summary['failed_reactions']:,} failed · {summary['skipped_reactions']:,} skipped reactions. Matches cover successfully extracted rules."
                ).classes("text-warning text-caption")
            unavailable = summary["composite_identity_statuses"].get(
                "unavailable_live_query", 0
            )
            if unavailable:
                ui.label(
                    f"{unavailable:,} composite variants could not be compared from live query graphs; see overlap errors.tsv."
                ).classes("text-warning text-caption")
            failed_sources = summary["composite_identity_statuses"].get(
                "failed_source_attempts", 0
            )
            if failed_sources:
                ui.label(
                    f"{failed_sources:,} certified source reconstructions failed; additional matching families may be missing."
                ).classes("text-warning text-caption")
            if any(
                s.get(k, 0)
                for s in (
                    summary["step_identity_statuses"],
                    summary["composite_identity_statuses"],
                )
                for k in ("noncanonical_fallback", "exact_representation")
            ):
                ui.label(
                    "Some rules use conservative identity fallbacks; equivalent rules may remain unmatched."
                ).classes("text-warning text-caption")

    def composite_navigation(self):
        status = self.view.get("overlap_status", {"state": "idle"})
        ui.toggle(
            {
                "all": "All composites",
                "overlap": "Exact single-step overlap",
                "novel": "Novel",
            },
            value=self.state.composite_submode,
            on_change=lambda e: self.change("composite_submode", e.value),
        ).classes("ri-composite-submode w-full").props("no-caps")
        # Background status updates must not move the catalogue under a pointer
        # or dismiss a tooltip. Keep this container outside the refreshed area.
        with (
            ui.column()
            .classes("ri-composite-overlap-status w-full")
            .props('role="status" aria-label="Single-step overlap status"')
        ):
            self.composite_overlap_status()
        ui.label(
            "Novel = no exact single-step match in this dataset; this does not establish chemical novelty."
        ).classes("text-caption")
        ui.select(
            KINDS,
            value=self.state.composite_kind,
            label="Composite tactic kind",
            on_change=lambda e: self.change("composite_kind", e.value),
        ).classes("w-full")
        ui.number(
            "Minimum composite route support",
            min=1,
            precision=0,
            value=self.state.composite_minimum_support,
            on_change=lambda e: self.change(
                "composite_minimum_support", max(1, int(e.value or 1))
            ),
        ).classes("w-full")
        ring_filter = ui.checkbox(
            "Ring-breaking only",
            value=self.state.composite_ring_breaking_only,
            on_change=lambda e: self.change("composite_ring_breaking_only", e.value),
        ).tooltip(
            "Cuts a target ring bond in retrosynthesis (forms it in forward synthesis). At least one certified source must qualify."
        )
        if (
            not self.info["composites"]["statistics"]
            .get("ring_breaking", {})
            .get("annotated_occurrences", 0)
        ):
            ring_filter.disable()
            ui.label(
                "Ring-breaking classification unavailable: annotate or rebuild this composite library."
            ).classes("text-caption")
        self.activator_controls()
        search = ui.input(
            "Composite ID contains", value=self.state.composite_search
        ).classes("w-full")
        search.on(
            "keydown.enter", lambda: self.change("composite_search", search.value)
        )
        ui.button(
            "Filter composites",
            on_click=lambda: self.change("composite_search", search.value),
        ).props("outline")
        page = self.view["entries"]
        if self.state.composite_submode != "all" and not page.total:
            ui.label(
                (
                    "No composites without an exact single-step match satisfy the current filters."
                    if self.state.composite_submode == "novel"
                    else "No exact single-step matches satisfy the current filters."
                )
                if status["state"] == "completed"
                else status.get("message", "Preparing single-step vocabulary…")
            ).classes("ri-overlap-empty text-caption")
        catalogue = table(
            [
                {
                    **row,
                    **{
                        key: row[key] if row[key] is not None else "—"
                        for key in (
                            "product_count",
                            "reactant_atom_count",
                            "tactic_sizes",
                        )
                    },
                }
                for row in page.rows
            ],
            [
                ("composite_id", "Composite rule"),
                ("route_count", "Routes"),
                ("product_count", "Products"),
                ("reactant_atom_count", "Reactant atoms"),
                ("tactic_sizes", "Tactic sizes"),
                ("ring_breaking", "Ring-breaking"),
            ],
            key="composite_id",
            on_select=self.select_composite,
            selected_id=self.state.composite_id,
            page=page,
            sort_by=self.state.composite_sort_by,
            descending=self.state.composite_sort_descending,
            on_sort=lambda column, descending: self.sort_table(
                "composite", column, descending
            ),
        ).classes("ri-composite-catalogue")
        catalogue.add_slot(
            "body-cell-composite_id",
            '<q-td :props="props"><span :title="props.value">'
            '{{ props.value && props.value.startsWith("composite_i_") '
            '? props.value.slice(0, 20) + "…" : props.value }}'
            "</span></q-td>",
        )
        for display, source in zip(catalogue.rows, page.rows):
            counts = source["ring_breaking_counts"]
            display["ring_tooltip"] = (
                "Target ring bond cut in retrosynthesis; formed in forward synthesis. "
                f"{counts['yes']}/{sum(counts.values())} qualifying certified occurrences; "
                f"{counts['unknown']} unknown. Scoped to the selected tactic kind."
            )
        catalogue.add_slot(
            "body-cell-ring_breaking",
            '<q-td :props="props">{{ props.value === true ? "Yes" : props.value === false ? "No" : "Unknown" }}'
            "<q-tooltip>{{ props.row.ring_tooltip }}</q-tooltip></q-td>",
        )
        pager(page, lambda offset: self.change("composite_offset", offset))
        if any(row.get("metric_error") for row in page.rows):
            ui.label(
                "Some rule queries could not be parsed; their counts are shown as —."
            ).classes("text-warning text-caption")
        ui.label(
            "Stored retrosynthetic rule: Products = right-hand-side templates; "
            "Reactant atoms = explicit left-hand-side query atoms (implicit hydrogens excluded). "
            "Tactic sizes = distinct certified rule counts for the selected tactic kind."
        ).classes("text-caption")
        ui.label(
            "Consecutive tactics only. Gapped tactics are not certified executable composites."
        ).classes("text-caption")
        stats = self.info["composites"]["statistics"]
        ui.label(
            f"{stats.get('certified_link_count', 0):,} certified links · "
            f"{stats.get('error_count', 0):,} retained construction diagnostics"
        ).classes("text-caption")

    def composite_panel(self):
        value = self.view.get("composite")
        if value is None:
            ui.label(
                self.view["overlap_status"].get(
                    "message", "Preparing single-step vocabulary…"
                )
                if self.state.composite_submode != "all"
                and self.view.get("overlap_status", {}).get("state") != "completed"
                else "Select a composite rule to inspect its decompositions and source routes."
            )
            return
        entry = value["entry"]
        with ui.column().classes("ri-composite-panel w-full"):
            ui.label("Composite rule").classes("text-h6")
            self.activator_details()
            if value["svg"]:
                ui.html(inline_rule_glyphs(value["svg"]), sanitize=True).classes(
                    "ri-rules-content w-full"
                )
            if value["error"]:
                ui.label(value["error"]).classes("text-warning")
            kind = self.state.composite_kind
            routes = entry["route_counts"].get(kind or "all", 0)
            occurrences = (
                entry["occurrence_counts"].get(kind, 0)
                if kind
                else sum(entry["occurrence_counts"].values())
            )
            ui.label(
                f"{routes} source routes · {occurrences} certified occurrences"
            ).classes("text-subtitle2")
            ui.label(
                "The drawing is the family's catalog representative; the selected "
                "occurrence's exact certified rule is recorded in the details below."
            ).classes("text-caption")
            variants = entry.get("variants", [])
            if variants:
                ui.label(f"{len(variants)} exact executable variants").classes(
                    "text-caption"
                )
                statuses = {v["status"] for v in variants}
                if "noncanonical_fallback" in statuses:
                    ui.label(
                        "Symmetry limit reached: equivalent rules may remain in separate entries."
                    ).classes("text-warning")
                if "exact_representation" in statuses:
                    ui.label(
                        "Unsupported query constraints: retained under exact-representation identity."
                    ).classes("text-warning")
            with ui.expansion(
                "Composite SMARTS, certification and identifiers"
            ).classes("w-full"):
                ui.label(
                    json.dumps(
                        {
                            "composite_id": entry["composite_id"],
                            "catalog_representative_SMARTS": entry["composite_rule"],
                            "selected_certified_SMARTS": (
                                self.view.get("composite_link") or {}
                            ).get("certified_rule"),
                            "identity_version": entry["identity_version"],
                            "exact_variants": variants,
                            "selected_link": self.view.get("composite_link"),
                            "construction_profile": self.info["composites"][
                                "construction_profile"
                            ],
                        },
                        indent=2,
                    )
                ).classes("ri-inspector")
            self.single_step_evidence()
            ui.label(
                "Choose Decompositions to compare the individual rules with their exact certified composite, or Source routes to inspect the recorded chemistry."
            ).classes("text-caption")

    def single_step_evidence(self):
        evidence = self.view.get("overlap_evidence")
        if evidence is None:
            return
        with ui.column().classes("ri-overlap-evidence w-full"):
            ui.label("Matching single-step sources").classes("text-h6")
            page = evidence["page"]
            ui.label(
                f"{evidence['route_count']:,} source routes · {page.total:,} single-step occurrences"
            )
            if not page.total:
                ui.label(
                    "No exact match found in the successfully extracted single-step vocabulary."
                )
                return
            step = evidence["selected"]
            table(
                page.rows,
                [
                    ("route_id", "Route"),
                    ("step", "Step"),
                    ("reaction_node_path", "Node path"),
                ],
                selected_id=step["id"] if step else None,
                on_select=lambda row: self.change("overlap_step_id", row["id"]),
            )
            pager(page, lambda offset: self.change("overlap_evidence_offset", offset))
            if step:
                ui.label(f"Route {step['route_id']} · Step {step['step']}").classes(
                    "text-subtitle2"
                )
                if evidence.get("svg"):
                    ui.html(inline_rule_glyphs(evidence["svg"]), sanitize=True).classes(
                        "ri-rules-content w-full"
                    )
                if evidence.get("error"):
                    ui.label(evidence["error"]).classes("text-warning")
                ui.label("Recorded source reaction").classes("text-subtitle2")
                if evidence.get("reaction_svg"):
                    ui.html(
                        inline_rule_glyphs(evidence["reaction_svg"]), sanitize=True
                    ).classes("ri-source-reaction w-full")
                if evidence.get("reaction_error"):
                    ui.label(evidence["reaction_error"]).classes("text-warning")
                ui.label(step["reaction_smiles"]).classes("ri-inspector")
                ui.button("Inspect route", on_click=self.inspect_overlap_route).props(
                    "outline"
                )

    def composite_decompositions(self):
        selected = self.view.get("selected") or {}
        if not selected:
            ui.label("No certified source occurrence is available.").classes(
                "ri-placeholder"
            )
            return
        ui.label(f"{selected['size']} rules → 1 composite").classes(
            "text-h6 ri-compression-summary"
        )
        ui.label(
            f"Route {(self.state.composite_route or {}).get('route_id')} · "
            "comparison uses the selected occurrence's exact certified rule"
        ).classes("text-caption")
        self.source_occurrence_controls("composite")
        with ui.element("div").classes("ri-composite-comparison"):
            with ui.column().classes("ri-tactic-group ri-comparison-tactic"):
                ui.label("Constituent reaction rules").classes("text-subtitle1")
                ui.label(TACTIC_LABELS[selected["kind"]]).classes("text-caption")
                if self.view.get("rule_svg"):
                    ui.html(
                        inline_rule_glyphs(self.view["rule_svg"]), sanitize=True
                    ).classes("ri-rules-content w-full")
                if self.view.get("rule_error"):
                    ui.label(self.view["rule_error"]).classes("text-warning")
            with ui.column().classes("ri-comparison-composite"):
                ui.label("Resulting composite rule").classes("text-subtitle1")
                ui.label(
                    "Exact certified variant · stored executable direction"
                ).classes("text-caption")
                value = self.view.get("certified_composite", {})
                if value.get("svg"):
                    ui.html(inline_rule_glyphs(value["svg"]), sanitize=True).classes(
                        "ri-rules-content w-full"
                    )
                if value.get("error"):
                    ui.label(value["error"]).classes("text-warning")
                self.composite_source_annotation()
        ui.label(
            "Sequence order and subtree branching are retained. Atom labels belong to each stored rule; matching numbers across panels do not establish atom correspondence."
        ).classes("text-caption")
        copy_full_id(self.state.composite_tactic_id)
        with ui.row():
            ui.button("Explore this tactic", on_click=self.explore_tactic)
            ui.button(
                "View source routes", on_click=lambda: self.show_composite_sources()
            ).props("outline")

    async def show_composite_sources(self):
        self.state.composite_workspace = "sources"
        await self.body.refresh()

    def composite_shortcut(self):
        link = self.view.get("composite_link")
        if link:
            ui.button("Explore composite", on_click=self.explore_composite).props(
                "outline"
            )
        elif self.view.get("composite_error"):
            ui.label(self.view["composite_error"]).classes("text-warning")
        elif self.view.get("selected") and not (
            self.state.mode == "Route-wise"
            and self.state.source == "New prepared route"
        ):
            ui.label(
                "No certified composite is available for this occurrence."
            ).classes("text-caption")
