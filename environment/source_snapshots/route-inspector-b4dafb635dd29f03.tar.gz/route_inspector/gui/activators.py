"""Optional background activator indexing and local catalogue controls."""

from __future__ import annotations

import asyncio
import hashlib
import json
import sqlite3
import threading
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from pathlib import Path

from nicegui import ui

from route_inspector.composite_rules.library import CompositeDecompositionLibrary
from route_inspector.gui.verification import artifact_snapshot
from route_inspector.reference_library import ReferenceTacticLibrary
from route_inspector.rules.activators import MATCH_VERSION, catalogue_digest
from route_inspector.rules.activators.index import (
    INDEX_VERSION,
    TACTIC_POLICY_VERSION,
    ActivatorIndex,
    composite_records,
    tactic_records,
)
from route_inspector.rules.config import dependency_version

_LOCKS = {}
_GUARD = threading.Lock()


class ActivatorSession:
    """Independent read-only library connection; never launches a chemistry audit."""

    def __init__(self, output):
        self.output = Path(output)

    def prepare(self, context):
        scope, directory, encoded_snapshot = context
        snapshot = json.loads(encoded_snapshot)
        if artifact_snapshot(directory) != snapshot:
            raise ValueError("Library changed since verification; reload the dataset")
        identity = json.dumps(
            {
                "scope": scope,
                "snapshot": snapshot,
                "index": INDEX_VERSION,
                "matcher": MATCH_VERSION,
                "catalogue": catalogue_digest(),
                "chython": dependency_version("chython-synplan"),
                **(
                    {"tactic_policy": TACTIC_POLICY_VERSION}
                    if scope == "tactics"
                    else {}
                ),
            },
            sort_keys=True,
        )
        path = (
            self.output
            / "activators"
            / (hashlib.sha256(identity.encode()).hexdigest() + ".sqlite")
        )
        with _GUARD:
            lock = _LOCKS.setdefault(str(path), threading.Lock())
        with lock:
            valid = False
            index = None
            try:
                index = ActivatorIndex(path)
                valid = index.valid(identity)
            except (sqlite3.Error, OSError, TypeError, IndexError):
                pass
            finally:
                if index is not None:
                    index.close()
            if not valid:
                loader, records = (
                    (ReferenceTacticLibrary, tactic_records)
                    if scope == "tactics"
                    else (CompositeDecompositionLibrary, composite_records)
                )
                library = loader.load(directory, verification="fast")
                try:
                    if library._connection is not None:
                        library._connection.execute("PRAGMA query_only = ON")
                    ActivatorIndex.build(path, records(library), identity)
                finally:
                    library.close()
            if artifact_snapshot(directory) != snapshot:
                raise ValueError(
                    "Library changed during activator indexing; reload the dataset"
                )
        return str(path), identity


class ActivatorScreens:
    def init_activators(self):
        self.activator_worker = ActivatorSession(self.service.output)
        self.activator_executor = ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="activators"
        )
        self.activator_tasks = set()
        self.activator_request = 0
        self.activator_key = None
        self.activator_loading = False
        self.activator_error = None
        self.activator_view = {}

    def activator_active(self):
        return (
            self.screen == "explorer"
            and self.state.analysis_domain == "Tactics"
            and self.state.mode in {"Tactic-wise", "Composite-wise"}
        )

    def current_activator_key(self):
        return (
            self.view.get("activator_context"),
            self.state.composite_kind
            if self.state.mode == "Composite-wise"
            else self.state.kind,
            self.state.composite_id
            if self.state.mode == "Composite-wise"
            else self.state.entry_id,
        )

    def invalidate_activators(self):
        if hasattr(self, "activator_request"):
            self.activator_request += 1
            self.activator_key = None
            self.activator_view = {}

    def schedule_activators(self):
        if not hasattr(self, "activator_worker"):
            return
        if not self.activator_active():
            self.invalidate_activators()
            return
        key = self.current_activator_key()
        if key == self.activator_key or not key[0]:
            return
        self.activator_key = key
        self.activator_request += 1
        self.activator_error = None
        self.activator_view = self.view.get("activators", {})
        if self.activator_view.get("ready"):
            self.activator_loading = False
            return
        self.activator_loading = True
        task = asyncio.create_task(self.load_activators(self.activator_request, key))
        self.activator_tasks.add(task)
        task.add_done_callback(self.activator_tasks.discard)

    def activator_current(self, request, key):
        return (
            request == self.activator_request
            and self.activator_active()
            and key == self.current_activator_key()
        )

    async def load_activators(self, request, key):
        try:
            path, identity = await asyncio.get_running_loop().run_in_executor(
                self.activator_executor, partial(self.activator_worker.prepare, key[0])
            )
            if not self.activator_current(request, key):
                return
            attached = await self.call(
                self.service.attach_activator_index, key[0], path, identity
            )
            if not attached or not self.activator_current(request, key):
                return
            result = await self.call(
                self.service.activator_status, key[0][0], key[1], key[2]
            )
            if not self.activator_current(request, key):
                return
            self.activator_view = result
        except Exception as exc:
            if not self.activator_current(request, key):
                return
            self.activator_error = f"Activator filter unavailable: {exc}"
        self.activator_loading = False
        await self.activator_controls.refresh()
        await self.activator_details.refresh()

    async def retry_activators(self):
        self.activator_key = None
        self.schedule_activators()
        await self.activator_controls.refresh()

    @ui.refreshable
    def activator_controls(self):
        composite = self.state.mode == "Composite-wise"
        field = "composite_activator_filter" if composite else "activator_filter"
        with ui.column().classes("w-full gap-1 ri-activator-filter"):
            ui.label("Activator in rule").classes("text-subtitle2")
            ready = self.activator_view.get("ready", False)
            toggle = ui.toggle(
                {"all": "All", "present": "Present", "absent": "Absent"},
                value=getattr(self.state, field),
                on_change=lambda e: self.change(field, e.value),
            ).props('no-caps unelevated aria-label="Activator in rule"')
            toggle.set_enabled(ready)
            if not composite:
                ui.label("Step 1 (last in forward synthesis) is ignored.").classes(
                    "text-caption"
                )
            toggle.tooltip(
                "Complete precursor-side component compatible with the activator catalogue. "
                + (
                    "Checks certified net variants for this tactic kind."
                    if composite
                    else "Checks selected rules after step 1. Step 1 (last in forward synthesis) and skipped gap steps are excluded."
                )
                + " Stored patterns may omit or generalize reagents; this does not prove experimental use."
            )
            if self.activator_loading:
                ui.label(
                    "Preparing activator filter… All entries remain available."
                ).classes("text-caption")
            elif self.activator_error:
                ui.label(self.activator_error).classes("text-warning")
                ui.button(
                    "Retry activator filter", on_click=self.retry_activators
                ).props("flat dense")
            elif ready:
                counts = self.activator_view["counts"]
                ui.label(
                    f"{counts['present']:,} present · {counts['absent']:,} absent · {counts['unknown']:,} unknown"
                ).classes("text-caption")
                if counts["unknown"]:
                    ui.label(
                        "Unknown queries appear only under All; they are not classified as Absent."
                    ).classes("text-caption")

    @ui.refreshable
    def activator_details(self):
        detail = self.activator_view.get("detail")
        if not detail:
            return
        with ui.expansion(
            "Activator evidence · " + detail["status"].capitalize()
        ).classes("w-full"):
            if detail["evidence"]:
                ui.label(
                    "Matched catalogue names: "
                    + ", ".join(sorted({r["name"] for r in detail["evidence"]}))
                )
                for row in detail["evidence"]:
                    ui.label(
                        f"{row['name']} · {row['reference']} · precursor component {row['component']}"
                    ).classes("text-caption break-all")
            elif detail["status"] == "absent":
                ui.label(
                    "No complete precursor component matches the catalogue in the checked stored rules."
                )
            for message in detail["diagnostics"]:
                ui.label(message).classes("text-warning break-all")
