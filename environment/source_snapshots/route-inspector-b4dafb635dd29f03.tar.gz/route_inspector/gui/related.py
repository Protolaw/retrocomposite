"""Optional related-tactic worker, previews and isolated refreshable panel."""

from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import sqlite3
import threading
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from pathlib import Path
from xml.etree import ElementTree as ET

from nicegui import ui

from route_inspector.gui.inspection import render_tactic
from route_inspector.gui.labels import TACTIC_LABELS
from route_inspector.gui.svg import inline_rule_glyphs
from route_inspector.gui.verification import artifact_snapshot, load_verified
from route_inspector.gui.widgets import copy_full_id, pager, table
from route_inspector.reference_library import ReferenceTacticLibrary
from route_inspector.reference_library.browsing import LibraryBrowser
from route_inspector.reference_library.related import (
    INDEX_VERSION,
    RelatedIndex,
    compact_shape,
    containment,
    library_entries,
)
from route_inspector.rules.transformation import RuleFamilyIndex

_LOCKS = {}
_GUARD = threading.Lock()


class RelatedSession:
    """Used exclusively on the optional worker; no shared SQLite connections."""

    def __init__(self, output):
        self.output = Path(output)
        self.library = self.index = self.browser = None
        self.identity = None

    def close(self):
        if self.index is not None:
            self.index.close()
        if self.library is not None:
            self.library.close()
        self.index = self.library = self.browser = None
        self.identity = None

    def prepare(self, directory):
        directory = Path(directory)
        identity = json.dumps(
            {"version": INDEX_VERSION, "snapshot": artifact_snapshot(directory)},
            sort_keys=True,
        )
        if identity == self.identity:
            return
        self.close()
        library = load_verified(
            ReferenceTacticLibrary.load, directory, self.output / "verification"
        )
        path = (
            self.output
            / "related_tactics"
            / (hashlib.sha256(identity.encode()).hexdigest() + ".sqlite")
        )
        index = None
        try:
            with _GUARD:
                lock = _LOCKS.setdefault(str(path), threading.Lock())
            with lock:
                try:
                    index = RelatedIndex(path)
                    if not index.valid(identity):
                        index.close()
                        index = None
                except (sqlite3.Error, OSError, TypeError, IndexError):
                    if index is not None:
                        index.close()
                    index = None
                if index is None:
                    RelatedIndex.build(path, library_entries(library), identity)
                    index = RelatedIndex(path)
            if artifact_snapshot(directory) != json.loads(identity)["snapshot"]:
                raise ValueError(
                    "Reference library changed while preparing related tactics"
                )
        except Exception:
            if index is not None:
                index.close()
            library.close()
            raise
        self.library, self.index = library, index
        self.browser = LibraryBrowser(library)
        self.identity = identity

    def query(self, directory, entry_id, direction, offset):
        self.prepare(directory)
        counts = {
            name: len(self.index.relations(entry_id, name))
            for name in ("extensions", "cores")
        }
        return {
            "page": self.browser.related(
                entry_id, index=self.index, direction=direction, offset=offset
            ),
            "counts": counts,
        }

    def preview(self, directory, row):
        self.prepare(directory)
        # Draw the larger tactic for both directions, so removed rules remain visible.
        entry = self.library.get_entry(row["extension_entry_id"])
        occurrence = self.library.get_occurrence(entry.representative_occurrence_id)
        shared = {b for _, b in row["mapping"]}
        return highlighted_preview(
            entry,
            occurrence,
            shared,
            additional_label="Only in current"
            if row["extension_entry_id"] != row["entry_id"]
            else "Only in candidate",
        )


def highlighted_preview(entry, occurrence, shared, *, additional_label="Additional"):
    """Align unordered representative branches before colouring chemical nodes."""
    families = RuleFamilyIndex()
    expected = compact_shape(entry.kind, entry.identity.equivalence_payload, families)
    observed = compact_shape(
        entry.kind, occurrence.identity.equivalence_payload, families
    )
    alignment = containment(
        expected, observed, entry.kind.split("_")[0], allow_equal=True
    )
    if alignment is None:
        raise ValueError(
            "Representative tactic cannot be aligned with its exact identity"
        )
    shared = {alignment[i] for i in shared}
    if entry.kind.startswith("rrseq"):
        paths = occurrence.selected_reaction_node_paths
    else:
        native = occurrence.native_payload
        children = {}
        for edge in native["edges"]:
            children.setdefault(tuple(edge["parent_reaction_node_path"]), []).append(
                tuple(edge["child_reaction_node_path"])
            )
        paths = []

        def visit(path):
            paths.append(path)
            for child in children.get(path, []):
                visit(child)

        visit(tuple(native["root_reaction_node_path"]))
    marked = {"/".join(map(str, paths[i])) for i in shared}
    root = ET.fromstring(inline_rule_glyphs(render_tactic(occurrence)))
    count = 0
    for node in root.iter():
        if "data-reaction-path" not in node.attrib or "rule-node" not in node.get(
            "class", ""
        ):
            continue
        common = node.get("data-reaction-path") in marked
        node.set("data-related-role", "shared" if common else "additional")
        count += int(common)
        for child in node:
            if child.tag.endswith("}rect") or child.tag == "rect":
                child.set("fill", "#DCFCE7" if common else "#FEF3C7")
                child.set("stroke", "#15803D" if common else "#B45309")
            if child.tag.endswith("}text") or child.tag == "text":
                child.text = ("Shared · " if common else additional_label + " · ") + (
                    child.text or ""
                )
    if count != len(shared):
        raise ValueError("Rule preview lacks exact reaction-path annotations")
    return ET.tostring(root, encoding="unicode")


class RelatedScreens:
    def init_related(self):
        self.related_worker = RelatedSession(self.service.output)
        self.related_executor = ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="related-tactics"
        )
        self.related_request = 0
        self.related_key = None
        self.related_view = {}
        self.related_selected = None
        self.related_preview = None
        self.related_error = None
        self.related_loading = False
        self.related_tasks = set()
        self.related_history = []

    def related_active(self):
        return (
            self.screen == "explorer"
            and self.state.analysis_domain == "Tactics"
            and self.state.mode == "Tactic-wise"
            and bool(self.state.entry_id)
        )

    def invalidate_related(self):
        if hasattr(self, "invalidate_activators"):
            self.invalidate_activators()
        self.related_request += 1
        self.related_key = None
        if hasattr(self, "invalidate_lhs"):
            self.invalidate_lhs()

    def schedule_related(self):
        if not self.related_active():
            self.related_request += 1
            self.related_key = None
            return
        directory = self.view.get("related_directory")
        key = (
            directory,
            self.state.entry_id,
            self.state.related_direction,
            self.state.related_offset,
        )
        if key == self.related_key:
            return
        self.related_key = key
        self.related_request += 1
        request = self.related_request
        self.related_loading = True
        self.related_view = {}
        self.related_selected = self.related_preview = self.related_error = None
        task = asyncio.create_task(self.load_related(request, key))
        self.related_tasks.add(task)
        task.add_done_callback(self.related_tasks.discard)

    async def load_related(self, request, key):
        try:
            result = await asyncio.get_running_loop().run_in_executor(
                self.related_executor, partial(self.related_worker.query, *key)
            )
            if (
                request != self.related_request
                or not self.related_active()
                or key != self.current_related_key()
            ):
                return
            self.related_view = result
        except Exception as exc:
            if (
                request != self.related_request
                or key != self.current_related_key()
                or not self.related_active()
            ):
                return
            self.related_error = f"Related tactics unavailable: {exc}"
        else:
            self.related_error = None
        if request == self.related_request and self.related_active():
            self.related_loading = False
            await self.related_panel.refresh()

    def current_related_key(self):
        return (
            self.view.get("related_directory"),
            self.state.entry_id,
            self.state.related_direction,
            self.state.related_offset,
        )

    async def change_related(self, direction=None, offset=0):
        if direction is not None:
            self.state.related_direction = direction
        self.state.related_offset = offset
        self.schedule_related()
        await self.related_panel.refresh()

    async def retry_related(self):
        self.related_key = None
        self.schedule_related()
        await self.related_panel.refresh()

    async def preview_related(self, row):
        self.related_selected = row
        self.related_preview = None
        self.related_error = None
        request, key = self.related_request, self.current_related_key()
        await self.related_panel.refresh()
        try:
            svg = await asyncio.get_running_loop().run_in_executor(
                self.related_executor, partial(self.related_worker.preview, key[0], row)
            )
            if (
                request != self.related_request
                or key != self.current_related_key()
                or self.related_selected != row
                or not self.related_active()
            ):
                return
            self.related_preview = svg
        except Exception as exc:
            if (
                request != self.related_request
                or key != self.current_related_key()
                or self.related_selected != row
                or not self.related_active()
            ):
                return
            self.related_error = f"Rule preview unavailable: {exc}"
        # Keep navigation controls mounted while the worker completes. Replacing
        # Open tactic between pointer-down and pointer-up loses the user's click.
        await self.related_preview_panel.refresh()

    @ui.refreshable
    def related_preview_panel(self):
        if self.related_error:
            ui.label(self.related_error).classes("text-warning")
            ui.button(
                "Retry rule preview",
                on_click=partial(self.preview_related, self.related_selected),
            ).props("flat")
        elif self.related_preview:
            ui.html(self.related_preview, sanitize=True).classes(
                "ri-related-preview w-full"
            )
        else:
            ui.label("Loading rule preview…")

    async def open_related(self):
        row = self.related_selected
        if row is None:
            return
        old = copy.deepcopy(self.state)
        generation = self.generation
        route = await self.call(
            self.service.related_destination, row["entry_id"], old.tactic_route
        )
        if (
            generation != self.generation
            or not self.related_active()
            or self.related_selected != row
        ):
            return
        self.related_history.append(old)
        self.state.explore_tactic(row["entry_id"], row["kind"], route, None)
        await self.refresh()

    async def back_related(self):
        if self.related_history:
            previous = self.related_history.pop()
            # Do not rewind independent Route-wise or PG selections made since
            # the user visited this tactic.
            for name in (
                "entry_id",
                "tactic_workspace",
                "kind",
                "tactic_route",
                "tactic_occurrence_id",
                "minimum_size",
                "minimum_support",
                "activator_filter",
                "tactic_search",
                "entry_offset",
                "source_offset",
                "tactic_occurrence_offset",
                "entry_sort_by",
                "entry_sort_descending",
                "related_direction",
                "related_offset",
                "skipped",
                "aam",
                "layered",
            ):
                setattr(self.state, name, copy.deepcopy(getattr(previous, name)))
            await self.refresh()

    @ui.refreshable
    def related_panel(self):
        if not self.related_active():
            return
        with ui.column().classes("w-full ri-related-panel"):
            ui.label(
                "Exact shorter cores and longer extensions, including sequences along subtree branches. Independent of the tactic-list filters."
            ).classes("text-caption")
            counts = self.related_view.get("counts", {})
            with ui.tabs(
                value=self.state.related_direction,
                on_change=lambda e: self.change_related(direction=e.value),
            ).classes("w-full"):
                for name, label in (
                    ("extensions", "Longer extensions"),
                    ("cores", "Shorter cores"),
                ):
                    suffix = f" ({counts[name]})" if name in counts else ""
                    ui.tab(name, label=label + suffix)
            if self.related_loading:
                ui.spinner(size="sm")
                ui.label(
                    "Finding exact related tactics… First use prepares a reusable index."
                )
                return
            if self.related_error and not self.related_selected:
                ui.label(self.related_error).classes("text-warning")
                ui.button("Retry related tactics", on_click=self.retry_related).props(
                    "flat"
                )
            page = self.related_view.get("page")
            if page is None:
                return
            if not page.total:
                ui.label("No exact related tactics in this category.").classes(
                    "text-caption"
                )
                return
            if self.related_selected:
                row = self.related_selected
                extension = self.state.related_direction == "extensions"
                current_size = (
                    row["size"] - row["difference"]
                    if extension
                    else row["size"] + row["difference"]
                )
                with ui.row().classes("ri-related-comparison-heading w-full"):
                    with ui.column().classes("gap-1"):
                        ui.label(f"Current tactic · {current_size} rules").classes(
                            "text-subtitle1"
                        )
                        ui.label(
                            f"Candidate {'extension' if extension else 'core'} · "
                            f"{row['size']} rules · "
                            f"{row['difference']} {'added' if extension else 'removed'}"
                        ).classes("text-subtitle1")
                    ui.space()
                    ui.button("Open tactic", on_click=self.open_related)
                copy_full_id(row["entry_id"])
                with ui.row().classes("ri-related-legend w-full"):
                    ui.label("Shared rules").classes("ri-related-shared")
                    ui.label(
                        "Only in candidate" if extension else "Only in current"
                    ).classes("ri-related-additional")
                ui.label(
                    "Comparison overlays the two tactics on the larger structure. "
                    "Stored retrosynthetic order; dashed edges retain gaps. "
                    "Previewing does not change the open tactic."
                ).classes("text-caption")
                self.related_preview_panel()
            else:
                ui.label(
                    "Select a related tactic from the table below to compare its rules."
                ).classes("text-caption")
            table(
                [
                    {**row, "kind_label": TACTIC_LABELS[row["kind"]]}
                    for row in page.rows
                ],
                [
                    ("entry_id", "Tactic"),
                    ("kind_label", "Type"),
                    ("size", "Size"),
                    (
                        "difference",
                        "Added"
                        if self.state.related_direction == "extensions"
                        else "Removed",
                    ),
                    ("route_count", "Routes"),
                    ("occurrence_count", "Occurrences"),
                ],
                key="entry_id",
                on_select=self.preview_related,
                selected_id=(self.related_selected or {}).get("entry_id"),
            )
            pager(page, lambda offset: self.change_related(offset=offset))
