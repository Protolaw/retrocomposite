"""One cancellable analysis subprocess; persisted results are never overwritten."""

from __future__ import annotations

import json
import subprocess
import sys
import threading
from pathlib import Path
from uuid import uuid4

from route_inspector.infrastructure.artifacts import write_json
from route_inspector.reference_library.assessment.tactics import RouteTacticAssessment


class AnalysisJobs:
    def __init__(self, directory: Path):
        self.directory = directory
        self.process = None
        self.job_dir = None
        self._log = None
        self._lock = threading.RLock()

    def start(self, request: dict) -> str:
        with self._lock:
            self.poll()
            if self.process is not None and self.process.poll() is None:
                raise ValueError("an analysis is already running; wait or cancel it")
            self.job_dir = self.directory / uuid4().hex
            self.job_dir.mkdir(parents=True, exist_ok=False)
            write_json(self.job_dir / "request.json", request)
            write_json(
                self.job_dir / "status.json",
                {"state": "running", "message": "Starting analysis"},
            )
            self._log = (self.job_dir / "worker.log").open("w", encoding="utf-8")
            try:
                self.process = subprocess.Popen(
                    [
                        sys.executable,
                        "-m",
                        "route_inspector.gui.worker",
                        str(self.job_dir),
                    ],
                    cwd=self.directory.parents[2],
                    stdin=subprocess.DEVNULL,
                    stdout=self._log,
                    stderr=subprocess.STDOUT,
                )
            except Exception:
                self._log.close()
                write_json(
                    self.job_dir / "status.json",
                    {"state": "failed", "message": "Could not launch analysis worker"},
                )
                raise
            return self.job_dir.name

    def poll(self):
        with self._lock:
            if self.job_dir is None:
                return {"state": "idle"}
            try:
                status = json.loads((self.job_dir / "status.json").read_text())
            except (OSError, ValueError):
                status = {"state": "running", "message": "Working"}
            if self.process is not None and self.process.poll() is not None:
                if self._log and not self._log.closed:
                    self._log.close()
                if status["state"] == "running":
                    status = {
                        "state": "failed",
                        "message": "Worker exited unexpectedly; inspect worker.log",
                    }
                    write_json(self.job_dir / "status.json", status)
            return {**status, "job_id": self.job_dir.name}

    def cancel(self):
        with self._lock:
            state = self.poll()
            if (
                self.process is not None
                and self.process.poll() is None
                and state["state"] == "running"
            ):
                self.process.terminate()
                try:
                    self.process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait(timeout=3)
                # A completed publication racing cancellation stays complete.
                if (self.job_dir / "result" / "summary.json").exists():
                    status = {"state": "completed", "message": "Analysis completed"}
                else:
                    status = {
                        "state": "cancelled",
                        "message": "Analysis cancelled; partial files are not results",
                    }
                write_json(self.job_dir / "status.json", status)
            return self.poll()

    def completed(self):
        if not self.directory.exists():
            return []
        completed = []
        for path in self.directory.glob("*/status.json"):
            try:
                state = json.loads(path.read_text()).get("state")
            except (OSError, ValueError, AttributeError):
                continue  # Partial/corrupt job records are never successful results.
            if state == "completed":
                completed.append(path.parent.name)
        return sorted(completed)

    def result(self, job_id: str):
        if len(job_id) != 32 or any(c not in "0123456789abcdef" for c in job_id):
            raise ValueError("invalid job ID")
        root = self.directory / job_id
        status = json.loads((root / "status.json").read_text())
        if status["state"] != "completed":
            raise ValueError("analysis has not completed")
        request = json.loads((root / "request.json").read_text())
        summary = json.loads((root / "result" / "summary.json").read_text())
        if (
            summary["library_id"] != request["library_id"]
            or summary["query_input_sha256"] != request["source_sha256"]
            or summary["selected_route_ids"] != [str(request["route_id"])]
        ):
            raise ValueError("saved assessment provenance does not match its request")
        records = json.loads((root / "result" / "assessments.json").read_text())
        if len(records) != 1:
            raise ValueError("saved job must contain exactly one assessment")
        assessment = RouteTacticAssessment.from_dict(records[0])
        if (
            assessment.route.route_id != str(request["route_id"])
            or assessment.route.source_identity != f"sha256:{request['source_sha256']}"
        ):
            raise ValueError(
                "saved assessment route identity does not match its request"
            )
        return {"request": request, "assessment": assessment.to_dict()}
