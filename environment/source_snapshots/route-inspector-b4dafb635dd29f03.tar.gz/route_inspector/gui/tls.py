"""Loopback TLS for an SSH-forwarded GUI; never install trust or expose a host."""

from __future__ import annotations

import ipaddress
import os
import ssl
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from route_inspector.infrastructure.publication import publish_directory_no_replace


def _generate(directory: Path) -> None:
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "localhost")])
    now = datetime.now(timezone.utc)
    certificate = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(minutes=5))
        .not_valid_after(now + timedelta(days=365))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.SubjectAlternativeName(
                [
                    x509.DNSName("localhost"),
                    x509.IPAddress(ipaddress.ip_address("127.0.0.1")),
                    x509.IPAddress(ipaddress.ip_address("::1")),
                ]
            ),
            critical=False,
        )
        .add_extension(
            x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False
        )
        .sign(key, hashes.SHA256())
    )
    files = {
        "server.key": key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        ),
        "server.crt": certificate.public_bytes(serialization.Encoding.PEM),
    }
    for name, content in files.items():
        descriptor = os.open(
            directory / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600
        )
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(content)


def local_certificate(workspace: Path) -> tuple[Path, Path]:
    """Create a persistent private pair, without replacing any existing files."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes

    parent = workspace / "outputs" / "gui"
    parent.mkdir(parents=True, exist_ok=True)
    directory = parent / "tls"
    if not directory.exists() and not directory.is_symlink():
        stage = Path(tempfile.mkdtemp(prefix=".tls-", dir=parent))
        try:
            _generate(stage)
            try:
                publish_directory_no_replace(stage, directory)
            except FileExistsError:
                pass  # Another launcher won; validate its complete pair below.
        finally:
            if stage.exists():
                for name in ("server.crt", "server.key"):
                    (stage / name).unlink(missing_ok=True)
                stage.rmdir()
    certificate, key = directory / "server.crt", directory / "server.key"
    if directory.is_symlink() or certificate.is_symlink() or key.is_symlink():
        raise ValueError(
            "local TLS files must not be symlinks; supply an explicit certificate instead"
        )
    if not certificate.is_file() or not key.is_file():
        raise ValueError(
            "local TLS pair is incomplete; supply --ssl-certfile and --ssl-keyfile"
        )
    if os.name != "nt" and key.stat().st_mode & 0o077:
        raise ValueError("local TLS private key must be owner-only (chmod 600)")
    parsed = x509.load_pem_x509_certificate(certificate.read_bytes())
    now = datetime.now(timezone.utc)
    if not parsed.not_valid_before_utc <= now < parsed.not_valid_after_utc:
        raise ValueError(
            "local TLS certificate is expired or not yet valid; supply a renewed certificate"
        )
    names = parsed.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    if "localhost" not in names.get_values_for_type(
        x509.DNSName
    ) or ipaddress.ip_address("127.0.0.1") not in names.get_values_for_type(
        x509.IPAddress
    ):
        raise ValueError("local TLS certificate does not cover localhost and 127.0.0.1")
    print(
        "Local HTTPS certificate: outputs/gui/tls/server.crt\n"
        f"SHA-256 fingerprint: {parsed.fingerprint(hashes.SHA256()).hex(':')}\n"
        "This is a self-signed certificate. Verify its fingerprint before approving "
        "the browser warning; no system trust settings have been changed.",
        flush=True,
    )
    return certificate, key


def tls_options(workspace: Path, *, https=True, certificate=None, key=None) -> dict:
    if bool(certificate) != bool(key):
        raise ValueError("provide both --ssl-certfile and --ssl-keyfile")
    if not https:
        if certificate or key:
            raise ValueError("--http cannot be combined with TLS certificate options")
        return {}
    if certificate is None:
        certificate, key = local_certificate(workspace)
    else:
        certificate, key = (
            Path(certificate).resolve(strict=True),
            Path(key).resolve(strict=True),
        )
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certificate, key)
    return {"ssl_certfile": str(certificate), "ssl_keyfile": str(key)}
