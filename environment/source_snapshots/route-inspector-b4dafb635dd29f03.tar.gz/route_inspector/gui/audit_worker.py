"""Internal, cancellable library auditor; never passes SQLite handles to the UI."""

import fcntl
import json
import sys
import traceback
from pathlib import Path

from route_inspector.gui.audit_jobs import library_loader
from route_inspector.gui.verification import atomic_json, load_verified, receipt_state
from route_inspector.infrastructure.auditing import audit_context


def main(directory):
    workspace = Path.cwd()
    request = json.loads((directory / "request.json").read_text())

    def progress(value):
        atomic_json(directory / "status.json", {"state": "running", **value})

    try:
        progress(dict(phase="Waiting for workspace audit slot"))
        # Also serialize independent GUI server processes on the same workspace.
        with (directory.parent / ".audit.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            loader = library_loader(request["kind"])
            library = workspace / request["library"]
            receipts = workspace / "outputs/gui/verification"
            _, expected, _, _ = receipt_state(loader, library, receipts)
            if expected != request["expected"]:
                raise ValueError(
                    "Library or validation code changed before audit; load it again"
                )
            progress(dict(phase="Checking library snapshot"))
            with audit_context(progress=progress) as context:
                handle = load_verified(loader, library, receipts)
                handle.close()
                metrics = dict(context.metrics)
            atomic_json(
                directory / "status.json",
                dict(
                    state="completed",
                    phase="Audit complete",
                    message="Verified library ready",
                    metrics=metrics,
                ),
            )
        return 0
    except Exception as exc:
        traceback.print_exc()
        atomic_json(
            directory / "status.json",
            dict(state="failed", message=f"{type(exc).__name__}: {exc}"),
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main(Path(sys.argv[1])))
