"""Read-only route/occurrence presentation, independent of the browser framework."""

from __future__ import annotations

import json
from html import escape

from route_inspector.gui.depiction import depiction_settings
from route_inspector.reference_library.models import TacticOccurrence
from route_inspector.routes.access import reaction_nodes, reaction_smiles_from_node

# Shared GUI policy; the public visualization API retains forward layering.
GUI_LAYERED_FLOW = "snake"


def reaction_rows(route: dict, occurrences: list[TacticOccurrence]) -> list[dict]:
    result = []
    for path, node in reaction_nodes(route):
        metadata = node.get("metadata") or {}
        result.append(
            {
                "path": "/".join(map(str, path)),
                "step": str(metadata.get("step_id", metadata.get("StepId", ""))),
                "smiles": reaction_smiles_from_node(node),
                "metadata": metadata,
                "memberships": [
                    dict(
                        id=o.reference_occurrence_id,
                        kind=o.identity.kind,
                        role="selected"
                        if path in o.selected_reaction_node_paths
                        else "skipped",
                    )
                    for o in occurrences
                    if path
                    in (*o.selected_reaction_node_paths, *o.skipped_reaction_node_paths)
                ],
            }
        )
    return result


def render_route(
    route: dict,
    route_id: str,
    occurrence=None,
    skipped=False,
    *,
    aam=True,
    layered=True,
) -> str:
    from route_inspector.visualization import get_route_svg_from_json

    options = {}
    if occurrence is not None:
        key = (
            "rrseq_occurrence"
            if occurrence.identity.kind.startswith("rrseq")
            else "rrsubtree_occurrence"
        )
        options[key] = occurrence.native_payload
    with depiction_settings(aam=bool(aam)):
        return get_route_svg_from_json(
            {str(route_id): route},
            str(route_id),
            compact=True,
            layered=bool(layered),
            layered_flow=GUI_LAYERED_FLOW,
            box_solid=False,
            highlight_skipped_steps=bool(
                skipped and occurrence and occurrence.identity.kind.endswith("_gap")
            ),
            **options,
        )


@depiction_settings(aam=True)
def render_tactic(occurrence: TacticOccurrence) -> str:
    from route_inspector.visualization import get_rrseq_svg, get_rrsubtree_svg

    native = occurrence.native_payload
    if occurrence.identity.kind.startswith("rrsubtree"):
        return get_rrsubtree_svg(native)
    return get_rrseq_svg(native)


@depiction_settings(aam=True)
def render_composite(rule: str) -> str:
    """Draw the persisted net SMARTS in its stored executable direction."""
    from chython import smarts

    return smarts(rule).depict()


def render_reaction(reaction: str, *, aam=True) -> str:
    """Draw the recorded source reaction, retaining its direction and mapping."""
    from chython import smiles

    with depiction_settings(aam=bool(aam)):
        return smiles(reaction).depict()


def metadata_text(row: dict) -> str:
    """Plain text only; callers must not interpolate this as HTML."""
    return json.dumps(row, indent=2, ensure_ascii=False)


def placeholder(message: str) -> str:
    return f'<p class="ri-placeholder">{escape(message)}</p>'
