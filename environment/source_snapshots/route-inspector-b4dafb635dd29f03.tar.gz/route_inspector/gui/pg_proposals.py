"""Indexed PG recovery browsing and background proposal jobs."""

import json
import os
from pathlib import Path

from nicegui import ui

from route_inspector.gui.inspection import render_route
from route_inspector.gui.jobs import AnalysisJobs
from route_inspector.gui.pg_validation import ValidationInspector
from route_inspector.gui.svg import inline_glyphs
from route_inspector.gui.widgets import RouteViewer, table
from route_inspector.protection.recovery.artifacts import PGRecoveryBrowser
from route_inspector.protection.recovery.diagnostics import (
    NO_PROPOSAL_LABELS,
    REASON_LABELS,
    STEP_LABELS,
    VALIDATION_LABELS,
)
from route_inspector.routes.access import reaction_nodes

RECOVERY_LABELS = {
    "original_route_recovered": "Original recovered",
    "partial_strategy_recovery": "Strategy recovered",
    "different_valid_proposal": "Different proposal",
    "comparison_unresolved": "Unresolved",
    "no_proposal": "No proposal",
}
RECOVERY_HELP = {
    "original_route_recovered": "At least one proposal matches the complete original route.",
    "partial_strategy_recovery": "An original PG's type, attachment site and lifetime match, but the complete route is not recovered.",
    "different_valid_proposal": "A proposal was accepted under this run's policy, but no original route or PG strategy was confirmed recovered.",
    "comparison_unresolved": "Proposals exist, but comparison with the saved original could not be completed.",
    "no_proposal": "No proposal was accepted under this run's checks and search limits.",
}
MATCH_LABELS = {
    "stored_exact": "Stored · exact",
    "pg_normalized_exact": "PG-normalized · exact",
    "stored_reduced_context": "Stored · reduced context",
    "pg_normalized_reduced_context": "PG-normalized · reduced context",
    "stored_center_only": "Stored · reaction centre only · env 0",
    "pg_normalized_center_only": "PG-normalized · reaction centre only · env 0",
}
ROUTE_PAGE_SIZE = 20


def proposal_preview(tree, route_id, *, aam=False, layered=True, endpoint_paths=()):
    svg = render_route(tree, route_id, aam=aam, layered=layered)
    # Highlight recorded original paths or generated endpoint provenance in the
    # SVG only. The source tree and route exports remain unchanged.
    from xml.etree import ElementTree as ET

    root = ET.fromstring(svg)
    endpoints = {"/".join(map(str, p)) for p in endpoint_paths} | {
        "/".join(map(str, p))
        for p, n in reaction_nodes(tree)
        if n.get("metadata", {}).get("pg_proposal_endpoint")
    }
    for node in root.iter():
        if node.get("data-reaction-path") in endpoints:
            node.set(
                "style",
                (node.get("style", "") + ";filter:drop-shadow(0 0 5px #1976d2)"),
            )
    return {"svg": ET.tostring(root, encoding="unicode")}


class PGProposalScreens:
    def saved_proposal_runs(self):
        return {
            f"outputs/pg_recovery/{query}_to_{reference}/proposals": (
                f"{query} → {reference}"
                + (" (self-reference)" if query == reference else "")
            )
            for query, reference in (
                ("n5", "n1"),
                ("n1", "n5"),
                ("n1", "n1"),
                ("n5", "n5"),
            )
            if (
                self.workspace
                / f"outputs/pg_recovery/{query}_to_{reference}/proposals/catalog.sqlite"
            ).is_file()
        }

    async def select_saved_proposals(self, event):
        self.proposal_directory = event.value
        await self.load_pg_recovery()

    def proposal_inputs(self, browser):
        """Resolve relocated libraries by identity, without altering provenance."""
        manifest = browser.manifest
        library = self.proposal_library
        candidates = [
            browser.root.parent / "reference_library",
            self.workspace / library,
            *sorted((self.workspace / "outputs/pg_libraries").glob("*")),
        ]
        for candidate in candidates:
            try:
                recorded = json.loads((candidate / "manifest.json").read_text())
            except (OSError, ValueError):
                continue
            if (
                manifest.get("library_id")
                and recorded.get("library_id") == manifest["library_id"]
            ):
                library = os.path.relpath(candidate, self.workspace)
                break
        return (
            manifest.get("query_source", self.proposal_source),
            manifest.get("reference_source", self.proposal_reference),
            library,
        )

    def init_proposals(self):
        self.proposal_jobs = AnalysisJobs(
            self.workspace / "outputs/gui/pg_proposal_jobs"
        )
        self.proposal_browser = None
        self.proposal_view = {}
        self.proposal_generation = 0
        self.proposal_full_refresh_pending = False
        self.proposal_offset = 0
        self.proposal_recovery = "all"
        self.proposal_no_proposal_reason = "all"
        self.proposal_validation_reason = "all"
        self.proposal_failed_step = "all"
        self.proposal_diagnostic_flag = "all"
        self.proposal_check_offset = 0
        self.proposal_route = None
        self.proposal_selected = None
        self.proposal_variant = "Stripped"
        self.proposal_aam = False
        self.proposal_layered = True
        self.proposal_source = "data/clean/n5_pg_stripped.json"
        self.proposal_reference = "data/clean/n1_routes.json"
        self.proposal_library = "outputs/pg_libraries/n1"
        self.proposal_directory = next(
            (
                directory
                for directory in (
                    "outputs/pg_recovery/n5_to_n1/proposals",
                    "outputs/pg_recovery/n5_pg_stripped_selectivity_warnings/proposals",
                    "outputs/pg_recovery/n5_pg_stripped_removal_checked/proposals",
                    "outputs/pg_recovery/n5_pg_stripped_placement/proposals",
                    "outputs/pg_recovery/n5_pg_stripped_eligible/proposals_site_first",
                    "outputs/pg_recovery/n5_pg_stripped_eligible/proposals_endpoint_rules",
                    "outputs/pg_recovery/n5_pg_stripped_eligible/proposals",
                    "outputs/pg_recovery/n5_pg_stripped/proposals_center_only",
                    "outputs/pg_recovery/n5_pg_stripped/proposals_reduced_context",
                    "outputs/pg_recovery/n5_pg_stripped/proposals_lifetimes",
                    "outputs/pg_recovery/n5_pg_stripped/proposals_rule_sites",
                )
                if (self.workspace / directory / "manifest.json").is_file()
            ),
            "outputs/pg_recovery/n5_pg_stripped/proposals",
        )
        if self.proposal_directory in {
            "outputs/pg_recovery/n5_pg_stripped_eligible/proposals_site_first",
            "outputs/pg_recovery/n5_pg_stripped_eligible/proposals_endpoint_rules",
            "outputs/pg_recovery/n5_pg_stripped_eligible/proposals",
        }:
            self.proposal_source = "data/clean/n5_pg_stripped_eligible.json"
        elif self.proposal_directory in {
            "outputs/pg_recovery/n5_to_n1/proposals",
            "outputs/pg_recovery/n5_pg_stripped_selectivity_warnings/proposals",
            "outputs/pg_recovery/n5_pg_stripped_placement/proposals",
            "outputs/pg_recovery/n5_pg_stripped_removal_checked/proposals",
        }:
            self.proposal_source = "data/clean/n5_pg_stripped_placement.json"
        self.proposal_job = None
        self.proposal_job_state = None
        self.proposal_job_message = ""
        self.proposal_timer = ui.timer(0.8, self.poll_proposal_job)

    async def load_pg_recovery(self):
        self.proposal_generation += 1
        generation = self.proposal_generation
        try:
            directory = self.workspace / self.proposal_directory
            if (
                not (directory / "manifest.json").is_file()
                and (directory / "proposals/manifest.json").is_file()
            ):
                directory = directory / "proposals"
            self.require_proposal_catalog(directory)
            browser = await self.call(
                PGRecoveryBrowser,
                directory,
                diagnostic_cache=self.workspace / "outputs/gui/pg_recovery_diagnostics",
            )
            if generation != self.proposal_generation:
                return
            self.proposal_source, self.proposal_reference, self.proposal_library = (
                self.proposal_inputs(browser)
            )
            self.proposal_directory = os.path.relpath(directory, self.workspace)
            self.proposal_browser = browser
            self.proposal_validation_inspector = ValidationInspector(
                browser, self.workspace, self.proposal_library
            )
            self.proposal_offset = 0
            self.proposal_check_offset = 0
            self.proposal_route = self.proposal_selected = None
            await self.refresh_proposals()
        except Exception as exc:
            self.fail(exc)

    @staticmethod
    def require_proposal_catalog(directory):
        if not (directory / "catalog.sqlite").is_file():
            raise FileNotFoundError(
                "PG recovery database is missing. The saved run may have moved. "
                "Choose a current saved run under Run or load PG recovery, "
                "or enter its proposals directory and click Load PG recovery."
            )

    async def refresh_proposals(self, *, preview_only=False):
        # A display change must not supersede pending route/filter navigation
        # with a drawing-only update, leaving the rest of the panel stale.
        preview_only = preview_only and not getattr(
            self, "proposal_full_refresh_pending", False
        )
        if not preview_only:
            self.proposal_full_refresh_pending = True
        self.proposal_generation += 1
        generation = self.proposal_generation
        browser = self.proposal_browser
        if browser is None:
            self.proposal_full_refresh_pending = False
            await self.body.refresh()
            return
        if not (browser.root / "catalog.sqlite").is_file():
            self.proposal_full_refresh_pending = False
            self.proposal_browser = None
            self.proposal_view = {}
            await self.body.refresh()
            try:
                self.require_proposal_catalog(browser.root)
            except FileNotFoundError as exc:
                self.fail(exc)
            return
        offset, rid, selected = (
            self.proposal_offset,
            self.proposal_route,
            self.proposal_selected,
        )
        variant, aam, layered = (
            self.proposal_variant,
            self.proposal_aam,
            self.proposal_layered,
        )
        recovery = None if self.proposal_recovery == "all" else self.proposal_recovery
        filters = {
            key: None if (value := getattr(self, "proposal_" + key)) == "all" else value
            for key in (
                "no_proposal_reason",
                "validation_reason",
                "failed_step",
                "diagnostic_flag",
            )
        }
        check_offset = self.proposal_check_offset

        def load():
            rows = browser.routes(
                offset, limit=ROUTE_PAGE_SIZE, recovery=recovery, **filters
            )
            total = browser.route_count(recovery=recovery, **filters)
            route_id = (
                rid if rid is not None else (rows[0]["route_id"] if rows else None)
            )
            result = {
                "rows": rows,
                "route_id": route_id,
                "summary": browser.summary,
                "total": total,
                "diagnostic_counts": browser.diagnostic_counts(),
            }
            if route_id is None:
                result["preview"] = {"message": "No routes match this recovery status."}
                return result
            saved = browser.route(route_id)
            stripping = saved.get("metadata", {}).get("pg_stripping", {})
            original_endpoints = [
                row["event"][name]
                for row in stripping.get("events", [])
                for name in (
                    "protection_reaction_node_path",
                    "deprotection_reaction_node_path",
                )
                if row.get("event", {}).get(name)
            ]
            proposals = browser.proposals(route_id)
            chosen = next(
                (p for p in proposals if p["proposal_id"] == selected),
                proposals[0] if proposals else None,
            )
            tree = (
                stripping.get("original_tree")
                if variant == "Original"
                else chosen["tree"]
                if variant == "Proposed" and chosen
                else saved
                if variant == "Stripped"
                else None
            )
            result.update(
                proposals=proposals,
                chosen=chosen,
                tree=tree,
                preview=(
                    proposal_preview(
                        tree,
                        route_id,
                        aam=aam,
                        layered=layered,
                        endpoint_paths=original_endpoints
                        if variant == "Original"
                        else (),
                    )
                    if tree
                    else {"message": "No route available for this view."}
                ),
                stripping=stripping,
                diagnostics=browser.route_diagnostics(route_id),
                failed_checks=browser.validation_checks(
                    route_id, check_offset, stage=filters["failed_step"]
                ),
            )
            return result

        try:
            result = await self.call(load)
            if generation != self.proposal_generation:
                return
            self.proposal_view = result
            self.proposal_route = result["route_id"]
            self.proposal_selected = (
                result.get("chosen", {}).get("proposal_id")
                if result.get("chosen")
                else None
            )
            if self.state.pg_mode == "Propose-PG" and self.screen == "explorer":
                viewer = getattr(self, "proposal_viewer", None)
                if (
                    preview_only
                    and viewer
                    and viewer.canvas
                    and result["preview"].get("svg")
                ):
                    viewer.update_preview(result["preview"])
                else:
                    await self.body.refresh()
        except Exception as exc:
            self.fail(exc)
        finally:
            if generation == self.proposal_generation:
                self.proposal_full_refresh_pending = False

    async def change_proposal(self, field, value):
        setattr(self, "proposal_" + field, value)
        diagnostic_filters = {
            "no_proposal_reason",
            "validation_reason",
            "failed_step",
            "diagnostic_flag",
        }
        if field in diagnostic_filters:
            self.proposal_recovery = "no_proposal"
            self.proposal_route = self.proposal_selected = None
            self.proposal_offset = 0
            if field in {"validation_reason", "failed_step"} and value != "all":
                self.proposal_no_proposal_reason = "validation_rejected"
            if field == "no_proposal_reason" and value != "validation_rejected":
                self.proposal_validation_reason = self.proposal_failed_step = "all"
        if field == "recovery" and value != "no_proposal":
            for name in diagnostic_filters:
                setattr(self, "proposal_" + name, "all")
        if field in {"route", "offset", "recovery"} | diagnostic_filters:
            self.proposal_check_offset = 0
        if field in {"route", "offset", "recovery"}:
            self.proposal_selected = None
        if field in {"offset", "recovery"}:
            self.proposal_route = None
        if field == "recovery":
            self.proposal_offset = 0
        await self.refresh_proposals(preview_only=field in {"aam", "layered"})

    async def show_validation_check(self, check_id):
        browser, route_id = self.proposal_browser, self.proposal_route
        try:
            inspector = self.proposal_validation_inspector
            if inspector.library != self.proposal_library:
                inspector = ValidationInspector(
                    browser, self.workspace, self.proposal_library
                )
                self.proposal_validation_inspector = inspector
            result = await self.call(inspector.inspect, route_id, check_id)
            if browser is not self.proposal_browser or route_id != self.proposal_route:
                return
        except Exception as exc:
            self.fail(exc)
            return
        with ui.dialog() as dialog, ui.card().classes("ri-validation-dialog"):
            with ui.row().classes("w-full items-center"):
                ui.label(
                    f"Validation helper · Route {route_id} · {result['pg_type']}"
                ).classes("text-h6")
                ui.space()
                ui.button("Close", on_click=dialog.close).props("flat")
            ui.label(f"{result['stage']} · {result['reason']}").classes(
                "text-subtitle1"
            )
            ui.label(
                f"Proposed PG site atoms: {result['site_atom_maps']} · Query path: {result['query_path']} · Reference route: {result['reference_route_id']}"
            ).classes("text-caption")
            if result.get("evidence_reference") and result.get("endpoint_reference"):
                evidence, endpoint = (
                    result["evidence_reference"],
                    result["endpoint_reference"],
                )
                ui.label(
                    f"N-gram evidence: n1 route {evidence['route_id']} · "
                    f"Protection/deprotection pair: n1 route {endpoint['route_id']}"
                ).classes("text-caption")
            ui.label(
                "Expected is the fragment required by the proposed PG strategy. Replay outcomes are products actually generated by the validation rule."
            ).classes("text-caption")
            ui.label(
                "This is one rejected candidate. Other eligible sites and reference rules are tried separately within the search limits. Several sites used jointly by one reaction are not competing products."
            ).classes("text-caption")
            with ui.element("div").classes("ri-validation-comparison"):
                with ui.column().classes("ri-validation-expected"):
                    ui.label("Expected candidate fragment").classes("text-subtitle2")
                    self.validation_fragment(result["expected"])
                    if result.get("reconstructed"):
                        ui.label(
                            "Reconstructed from this run's query and verified reference provenance."
                        ).classes("text-caption")
                with ui.column().classes("ri-validation-outcomes"):
                    ui.label("Rule replay outcomes").classes("text-subtitle2")
                    if not result["outcomes"]:
                        ui.label(
                            "No valid product was recorded. The expected fragment is not a successful rule application."
                        )
                    for index, outcome in enumerate(result["outcomes"], 1):
                        ui.label(f"Recorded product {index}")
                        if outcome.get("attachment_site_atom_maps") is not None:
                            ui.label(
                                f"Replay attachment site atoms: {outcome['attachment_site_atom_maps']}"
                            ).classes("text-caption")
                        self.validation_fragment(outcome["preview"])
                        if not outcome["mapped"]:
                            ui.label(
                                "Historical product record: atom maps and stereochemistry were not retained; maps are hidden."
                            ).classes("text-caption")
            if result.get("query_context"):
                with ui.expansion("Recorded stripped-route step").classes("w-full"):
                    self.validation_fragment(result["query_context"])
            check = result["record"]["check"]
            ui.label(
                f"Raw applications: {check.get('raw_applications', '—')} · Invalid products: {check.get('invalid_products', '—')} · Search complete: {'Yes' if check.get('complete') else 'No'}"
            ).classes("text-caption")
            if "distinct_patch_applications" in check:
                ui.label(
                    f"Distinct mapped patches: {check['distinct_patch_applications']} · "
                    f"Duplicate patches skipped: {check.get('duplicate_patch_applications', 0)}"
                ).classes("text-caption")
            if "ineligible_site_applications" in check:
                ui.label(
                    f"Applications excluded by functional-group eligibility: {check['ineligible_site_applications'] + check.get('incompatible_reaction_site_applications', 0)}"
                ).classes("text-caption")
            if check.get("status") == "competing":
                ui.label(
                    "Replay stops after finding two distinct products; these are witnesses of competition, not an exhaustive product list."
                ).classes("text-caption")
            with ui.expansion("Rule and exact validation evidence").classes("w-full"):
                ui.label(json.dumps(result["record"], indent=2)).classes("ri-inspector")
            ui.button(
                "Export validation evidence",
                on_click=lambda: ui.download.content(
                    json.dumps(
                        {
                            k: v
                            for k, v in result.items()
                            if k not in {"expected", "outcomes", "query_context"}
                        },
                        indent=2,
                    ),
                    f"route_{route_id}_validation_{check_id}.json",
                    "application/json",
                ),
            )
        dialog.on("hide", dialog.delete)
        dialog.open()

    @staticmethod
    def validation_fragment(preview):
        if preview.get("svg"):
            ui.html(inline_glyphs(preview["svg"]), sanitize=True).classes(
                "ri-validation-fragment"
            )
            ui.button(
                "Download fragment SVG",
                on_click=lambda: ui.download.content(
                    preview["svg"], "validation_fragment.svg", "image/svg+xml"
                ),
            ).props("flat dense")
        else:
            ui.label(preview.get("message", "Fragment unavailable")).classes(
                "ri-placeholder"
            )

    async def run_pg_proposals(self):
        try:
            self.proposal_job = await self.call(
                self.proposal_jobs.start,
                {
                    "operation": "pg_proposal",
                    "routes_json": self.proposal_source,
                    "reference_routes_json": self.proposal_reference,
                    "library": self.proposal_library,
                },
            )
            self.proposal_job_state = None
            await self.poll_proposal_job()
        except Exception as exc:
            self.fail(exc)

    async def poll_proposal_job(self):
        if self.proposal_job is None:
            return
        status = await self.call(self.proposal_jobs.poll)
        if status.get("job_id") != self.proposal_job:
            return
        old = self.proposal_job_state
        self.proposal_job_state = status["state"]
        self.proposal_job_message = status.get("message", "")
        if hasattr(self, "proposal_status_label"):
            self.proposal_status_label.set_text(self.proposal_job_message)
        if old != status["state"] and status["state"] == "completed":
            # Completion never replaces a user's selected dataset or loaded run.
            self.proposal_completed_path = (
                f"outputs/gui/pg_proposal_jobs/{self.proposal_job}/result"
            )
            ui.notify(
                "PG proposals completed. Load the completed run to browse results."
            )
            if self.state.pg_mode == "Propose-PG" and self.screen == "explorer":
                await self.body.refresh()
        elif old != status["state"] and status["state"] == "failed":
            self.fail(RuntimeError(self.proposal_job_message))

    async def load_completed_proposals(self):
        self.proposal_directory = self.proposal_completed_path
        await self.load_pg_recovery()

    async def cancel_pg_proposals(self):
        await self.call(self.proposal_jobs.cancel)
        await self.poll_proposal_job()

    def proposal_screen(self):
        ui.label("Propose-PG").classes("text-h5")
        ui.label(
            "Match introduced, removed reference PG strategies to consecutive query rules. Original-route recovery is evaluated after proposal generation."
        ).classes("text-caption")
        with ui.expansion(
            "Run or load PG recovery", value=self.proposal_browser is None
        ).classes("w-full"):
            saved_runs = self.saved_proposal_runs()
            if saved_runs:
                ui.select(
                    saved_runs,
                    label="Saved PG recovery run (query → reference)",
                    value=self.proposal_directory
                    if self.proposal_directory in saved_runs
                    else None,
                    on_change=self.select_saved_proposals,
                ).classes("w-96")
            with ui.row().classes("w-full"):
                ui.input("Query corpus", value=self.proposal_source).bind_value(
                    self, "proposal_source"
                ).classes("w-96")
                ui.input(
                    "Reference clean corpus", value=self.proposal_reference
                ).bind_value(self, "proposal_reference").classes("w-96")
                ui.input(
                    "Reference PG library", value=self.proposal_library
                ).bind_value(self, "proposal_library").classes("w-96")
            with ui.row():
                ui.button("Run PG proposals", on_click=self.run_pg_proposals)
                ui.button("Cancel PG run", on_click=self.cancel_pg_proposals).props(
                    "outline"
                )
                if hasattr(self, "proposal_completed_path"):
                    ui.button(
                        "Load completed PG run", on_click=self.load_completed_proposals
                    )
            self.proposal_status_label = ui.label(self.proposal_job_message)
            with ui.row().classes("w-full"):
                ui.input(
                    "PG recovery results directory", value=self.proposal_directory
                ).bind_value(self, "proposal_directory").classes("w-96")
                ui.button("Load PG recovery", on_click=self.load_pg_recovery)
        view = self.proposal_view
        if not view:
            ui.label("Load PG recovery results to browse routes and proposals.")
            return
        summary = view["summary"]
        manifest = self.proposal_browser.manifest
        if manifest.get("identical_source_policy") == "allow_diagnostic":
            ui.label(
                "Self-reference diagnostic: identical original routes are allowed as reference evidence. Recovery here measures consistency, not generalization."
            ).classes("text-weight-bold text-orange-9")
        ui.label(
            "Replay checks required; reproduced intended products with competing outcomes are retained with selectivity warnings."
            if (manifest.get("selectivity_policy") or {}).get("acceptance")
            == "warn_competing"
            else "Attachment, mandatory deprotection and post-deprotection selectivity checked"
            if (manifest.get("selectivity_policy") or {}).get("deprotection")
            in {
                "required_pass_for_every_candidate",
                "required_intended_product_for_every_candidate",
            }
            else "Historical validation: removal replay was not required for every candidate."
            if manifest.get("selectivity_policy")
            else "This older run has not been checked for reaction-site selectivity."
        ).classes("text-caption")
        if (
            manifest.get("evidence_retrieval")
            == "exact_then_reduced_context_then_center_only"
        ):
            ui.label(
                "Exact evidence first, then reduced context, then reaction centre only (env 0) where neither stronger tier matches the same window and PG type."
            ).classes("text-caption")
        elif manifest.get("evidence_retrieval") == "exact_then_reduced_context":
            ui.label(
                "Exact evidence first, followed by matches with reduced reaction context."
            ).classes("text-caption")
        ui.label(
            f"Query: {Path(manifest.get('query_source', self.proposal_source)).name} · Reference: {Path(manifest.get('reference_source', self.proposal_reference)).name}"
        ).classes("text-caption")
        ui.label(
            f"{summary['query_routes']} query routes · {summary.get('routes_with_proposals', 0)} with proposals · {summary.get('routes_original_route_recovered', 0)} original routes recovered · {summary.get('truncated_routes', 0)} bounded searches"
        ).classes("text-subtitle2")
        with ui.row().classes("w-full items-start gap-6"):
            ui.select(
                {"all": "All", **RECOVERY_LABELS},
                value=self.proposal_recovery,
                label="Recovery status",
                on_change=lambda e: self.change_proposal("recovery", e.value),
            ).classes("w-64")
            with ui.column().classes("flex-1 min-w-64 gap-1 text-caption"):
                ui.label(
                    "All shows every route. Each route's status reflects its best proposal outcome."
                ).classes("text-weight-medium")
                for status, explanation in RECOVERY_HELP.items():
                    ui.label(f"{RECOVERY_LABELS[status]}: {explanation}")
        with ui.expansion(
            "Why no proposal?", value=self.proposal_recovery == "no_proposal"
        ).classes("w-full"):
            counts = view["diagnostic_counts"]
            with ui.row().classes("w-full items-start"):
                ui.select(
                    {
                        "all": "All reasons",
                        **{
                            k: f"{label} ({counts['reason'].get(k, 0)})"
                            for k, label in NO_PROPOSAL_LABELS.items()
                        },
                    },
                    value=self.proposal_no_proposal_reason,
                    label="No proposal reason",
                    on_change=lambda e: self.change_proposal(
                        "no_proposal_reason", e.value
                    ),
                ).classes("w-80")
                ui.select(
                    {
                        "all": "All validation reasons",
                        **{
                            k: f"{label} ({counts['validation_reason'].get(k, 0)})"
                            for k, label in VALIDATION_LABELS.items()
                        },
                    },
                    value=self.proposal_validation_reason,
                    label="Validation reason",
                    on_change=lambda e: self.change_proposal(
                        "validation_reason", e.value
                    ),
                ).classes("w-80")
                ui.select(
                    {"all": "All failed steps", **STEP_LABELS},
                    value=self.proposal_failed_step,
                    label="Failed step",
                    on_change=lambda e: self.change_proposal("failed_step", e.value),
                ).classes("w-64")
                ui.select(
                    {
                        "all": "All searches",
                        "search_incomplete": "Search incomplete",
                        "processing_error": "Processing error",
                    },
                    value=self.proposal_diagnostic_flag,
                    label="Diagnostic flag",
                    on_change=lambda e: self.change_proposal(
                        "diagnostic_flag", e.value
                    ),
                ).classes("w-56")
            ui.label(
                "Reasons describe the furthest stage reached by any candidate. Validation reasons combine failures across candidates. Counts cover all No proposal routes in this run."
            ).classes("text-caption")
            ui.label(
                "Select a failed check below the route to open the visual validation helper."
            ).classes("text-caption")
        total = view["total"]
        with ui.element("div").classes("ri-pg-proposal-layout"):
            with ui.column().classes("ri-card ri-pg-query-panel"):
                table(
                    [
                        {
                            **row,
                            "best_recovery": RECOVERY_LABELS[row["best_recovery"]],
                            "truncated": "Yes" if row["truncated"] else "",
                            "no_proposal_reason": NO_PROPOSAL_LABELS.get(
                                row.get("no_proposal_reason"), ""
                            ),
                        }
                        for row in view["rows"]
                    ],
                    [
                        ("route_id", "Route"),
                        ("proposal_count", "Proposals"),
                        ("best_recovery", "Recovery"),
                        ("no_proposal_reason", "No proposal reason"),
                        ("truncated", "Limited"),
                    ],
                    key="route_id",
                    selected_id=self.proposal_route,
                    on_select=lambda row: self.change_proposal(
                        "route", row["route_id"]
                    ),
                ).classes("ri-pg-query-table").props("dense")
                with ui.row():
                    ui.button(
                        "Previous",
                        on_click=lambda: self.change_proposal(
                            "offset", max(0, self.proposal_offset - ROUTE_PAGE_SIZE)
                        ),
                    ).set_enabled(self.proposal_offset > 0)
                    ui.label(
                        f"{self.proposal_offset + 1 if total else 0}–{min(self.proposal_offset + ROUTE_PAGE_SIZE, total)} / {total}"
                    )
                    ui.button(
                        "Next",
                        on_click=lambda: self.change_proposal(
                            "offset", self.proposal_offset + ROUTE_PAGE_SIZE
                        ),
                    ).set_enabled(self.proposal_offset + ROUTE_PAGE_SIZE < total)
            with ui.column().classes("ri-card ri-pg-preview-panel"):
                ui.toggle(
                    ["Original", "Stripped", "Proposed"],
                    value=self.proposal_variant,
                    on_change=lambda e: self.change_proposal("variant", e.value),
                )
                stripping = view.get("stripping", {})
                ui.label(
                    f"Original: {stripping.get('steps_before', '—')} steps → stripped: {stripping.get('steps_after', '—')} steps. Protection and deprotection steps are highlighted blue in Original and Proposed views."
                )
                self.proposal_viewer = RouteViewer(
                    view.get("preview", {}),
                    lambda _: None,
                    aam=self.proposal_aam,
                    on_aam_change=lambda e: self.change_proposal("aam", e.value),
                    layered=self.proposal_layered,
                    on_layered_change=lambda e: self.change_proposal(
                        "layered", e.value
                    ),
                )
                if view.get("tree"):
                    ui.button(
                        "Export displayed route JSON",
                        on_click=lambda: ui.download.content(
                            json.dumps(view["tree"], indent=2),
                            f"route_{self.proposal_route}_{self.proposal_variant.lower()}.json",
                            "application/json",
                        ),
                    )
                self.proposal_diagnostics(view)
                ui.label("Proposed PG strategies").classes("text-subtitle2")
                rows = [
                    {
                        "id": p["proposal_id"],
                        "rank": p["rank"],
                        "pg": p["strategy"]["pg_type"],
                        "mode": MATCH_LABELS[p["match"]["match_mode"]],
                        "n": len(p["match"]["paths"]),
                        "lifetime": len(p["strategy"]["query_interval_paths"]),
                        "support": len(p["match"]["support_route_ids"]),
                        "recovery": RECOVERY_LABELS[p["recovery"]["status"]],
                        "selectivity": "⚠ Competing products"
                        if p["validation"].get("selectivity_warnings")
                        else "No warning"
                        if manifest.get("selectivity_policy", {}).get("version", 0) >= 5
                        else "Historical policy",
                    }
                    for p in view.get("proposals", [])
                ]
                table(
                    rows,
                    [
                        ("rank", "#"),
                        ("pg", "PG"),
                        ("n", "Evidence n"),
                        ("lifetime", "PG lifetime"),
                        ("support", "Reference routes"),
                        ("mode", "Match"),
                        ("recovery", "Recovery"),
                        ("selectivity", "Selectivity"),
                    ],
                    selected_id=self.proposal_selected,
                    on_select=lambda row: self.change_proposal("selected", row["id"]),
                ).classes("ri-pg-proposal-table max-h-80 overflow-auto")
                chosen = view.get("chosen")
                if chosen:
                    warnings = chosen["validation"].get("selectivity_warnings", [])
                    if warnings:
                        ui.label(
                            "Selectivity warning: replay reproduced the intended product, but also found competing products. Recovery describes reconstruction, not selective synthesis."
                        ).classes("text-weight-bold text-orange-9")
                        with ui.expansion("Selectivity warning details").classes(
                            "w-full"
                        ):
                            for warning in warnings:
                                ui.label(
                                    STEP_LABELS.get(warning["stage"], warning["stage"])
                                )
                                ui.label(
                                    json.dumps(warning["check"], indent=2)
                                ).classes("ri-inspector")
                    endpoint = chosen.get("endpoint_reference")
                    if endpoint:
                        ui.label(
                            f"N-gram evidence: reference route {chosen['reference_window']['route_id']} · "
                            f"Protection/deprotection pair: reference route {endpoint['route_id']}"
                        ).classes("text-caption")
                    transfer = chosen["strategy"].get("evidence_transfer", "same_pg")
                    if transfer != "same_pg":
                        kind = (
                            "Cross-functional-group evidence"
                            if transfer == "cross_functional_group"
                            else "Family evidence"
                        )
                        ui.label(
                            f"{kind}: {chosen['strategy']['evidence_pg_type']} → "
                            f"{chosen['strategy']['pg_type']}. Weaker transferred evidence; see validation and selectivity warnings below."
                        ).classes("text-caption")
                    role = chosen["strategy"].get("evidence_role", "interval")
                    if role != "interval":
                        ui.label(
                            "Boundary evidence: the matched reaction occurs "
                            + (
                                "before protection installation."
                                if role == "before_installation"
                                else "after protection removal."
                            )
                            + " It is outside the protected lifetime."
                        ).classes("text-caption")
                    if endpoint and endpoint.get("rule_scope") == "functional_class":
                        ui.label(
                            "Endpoint substrate context generalized; functional-group restrictions retained."
                        ).classes("text-caption")
                    evidence_length = len(chosen["match"]["paths"])
                    lifetime = len(chosen["strategy"]["query_interval_paths"])
                    additional = sum(
                        path not in chosen["match"]["paths"]
                        for path in chosen["strategy"]["query_interval_paths"]
                    )
                    ui.label(
                        f"Matched evidence: {evidence_length} reactions · PG lifetime: {lifetime} reactions · Additional protected reactions: {additional}"
                    )
                    with ui.expansion(
                        "Matched rules, reference evidence and validation"
                    ).classes("w-full"):
                        ui.label(
                            json.dumps(
                                {k: v for k, v in chosen.items() if k != "tree"},
                                indent=2,
                            )
                        ).classes("ri-inspector")
                        ui.button(
                            "Export proposal and evidence",
                            on_click=lambda: ui.download.content(
                                json.dumps(chosen, indent=2),
                                "pg_proposal.json",
                                "application/json",
                            ),
                        )

    def proposal_diagnostics(self, view):
        diagnostics = view.get("diagnostics")
        if diagnostics is None:
            return
        ui.label(NO_PROPOSAL_LABELS[diagnostics["reason"]]).classes("text-subtitle2")
        if diagnostics["reason"] == "unavailable":
            ui.label(
                "This historical run lacks complete candidate/matching diagnostics. Its No proposal status is retained without guessing a cause."
            )
            return
        ui.label(
            f"Evidence windows: {diagnostics['matched_windows']} · Transferable: {diagnostics['transferable_windows']} · Candidate attempts: {diagnostics['attempted_candidates']} · Reached validation: {diagnostics['generated_candidates']}"
        ).classes("text-caption")
        if diagnostics["search_incomplete"]:
            ui.label("Search incomplete: a configured bound was reached.").classes(
                "text-warning"
            )
        if diagnostics["processing_error"]:
            ui.label(
                "Processing errors were retained; inspect the diagnostic details."
            ).classes("text-warning")
        with ui.expansion("Matched PG types and diagnostic details").classes("w-full"):
            ui.label("PG types: " + ", ".join(diagnostics["pg_types"]))
            ui.label("Evidence layers: " + ", ".join(diagnostics["evidence_tiers"]))
            ui.label(
                json.dumps(
                    {k: diagnostics[k] for k in ("messages", "reference_diagnostics")},
                    indent=2,
                )
            ).classes("ri-inspector")
        checks = view.get("failed_checks", {"rows": [], "total": 0})
        if not checks["total"]:
            return
        ui.label("Failed validation checks — select one for the visual helper").classes(
            "text-subtitle2"
        )
        checks_table = table(
            [
                {
                    **row,
                    "stage": STEP_LABELS.get(row["stage"], row["stage"]),
                    "reason": REASON_LABELS.get(row["reason"], row["reason"]),
                }
                for row in checks["rows"]
            ],
            [
                ("candidate_id", "Candidate"),
                ("pg_type", "PG"),
                ("site_atom_maps", "Site atoms"),
                ("stage", "Failed step"),
                ("reason", "Validation reason"),
                ("reference_route_id", "n1 route"),
                ("helper", "Inspect"),
            ],
            key="check_id",
            on_select=lambda row: self.show_validation_check(row["check_id"]),
        ).classes("ri-validation-checks")
        checks_table.add_slot(
            "body-cell-helper",
            '<q-td :props="props"><q-btn flat dense label="View fragments" '
            "@click.stop=\"$parent.$emit('inspect-validation', props.row.check_id)\" /></q-td>",
        )
        checks_table.on(
            "inspect-validation", lambda e: self.show_validation_check(e.args)
        )
        with ui.row():
            ui.button(
                "Previous checks",
                on_click=lambda: self.change_proposal(
                    "check_offset", max(0, self.proposal_check_offset - 25)
                ),
            ).set_enabled(self.proposal_check_offset > 0)
            ui.label(
                f"Checks {self.proposal_check_offset + 1}–{min(self.proposal_check_offset + 25, checks['total'])} / {checks['total']}"
            )
            ui.button(
                "Next checks",
                on_click=lambda: self.change_proposal(
                    "check_offset", self.proposal_check_offset + 25
                ),
            ).set_enabled(self.proposal_check_offset + 25 < checks["total"])
