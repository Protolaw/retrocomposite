"""Open embedded PG browse tables or an atomically published local legacy index."""

import hashlib
import json
import os
import sqlite3
import tempfile
from pathlib import Path

from route_inspector.gui.verification import atomic_json
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.protection.strategies.browsing import (
    BROWSE_TABLES,
    BROWSE_VERSION,
    build_browse_tables,
    has_browse_tables,
    sqlite_browse_entries,
)


def _read_only(path):
    return sqlite3.connect(f"{Path(path).resolve().as_uri()}?mode=ro", uri=True)


def _navigation(connection):
    if connection.execute("PRAGMA user_version").fetchone()[0] == 5:
        from route_inspector.protection.strategies.relational import register_browse

        register_browse(connection)
    for name in BROWSE_TABLES:
        connection.execute(f"CREATE TEMP VIEW {name} AS SELECT * FROM pg_browse_{name}")
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only = ON")
    return connection


def event_ngrams(connection, event, steps):
    """Hydrate format-5 window summaries from one already loaded step sequence."""
    raw_event = event.to_dict()
    rows = connection.execute(
        "SELECT m.occurrence_id,m.entry_id,m.start_index,m.length,m.occurrence_sha256,"
        "json_extract(e.entry_json,'$.route_count') AS route_count,"
        "json_extract(e.entry_json,'$.occurrence_count') AS occurrence_count "
        "FROM memberships m JOIN entries e ON e.entry_id=m.entry_id "
        "WHERE m.event_id=? AND m.kind='interval_ngram'",
        (event.occurrence_id,),
    )
    result = []
    for row in rows:
        start, length = row["start_index"], row["length"]
        selected = steps[start : start + length]
        result.append(
            {
                "occurrence_id": row["occurrence_id"],
                "entry_id": row["entry_id"],
                "occurrence_sha256": row["occurrence_sha256"],
                "route": dict(raw_event["route"]),
                "event_occurrence_id": event.occurrence_id,
                "focal_pg_type": raw_event["pg_type"],
                "active_pg_contexts": [list(s.active_pg_types) for s in selected],
                "step_occurrence_ids": [s.occurrence_id for s in selected],
                "reaction_node_paths": [list(s.reaction_node_path) for s in selected],
                "start_index": start,
                "length": length,
                "route_count": row["route_count"],
                "occurrence_count": row["occurrence_count"],
            }
        )
    return result


def open_pg_index(library, directory, cache_root):
    directory = Path(directory)
    descriptor = library.manifest.artifacts.get("catalog")
    source = _read_only(directory / descriptor["path"]) if descriptor else None
    if source is None and library.manifest.library_format_version == 5:
        # Portable normalized loading already verified and indexed a temporary
        # catalogue. Reuse it instead of expanding all entry support records.
        path = library._connection.execute("PRAGMA database_list").fetchone()[2]
        source = _read_only(path)
    try:
        if source is not None and has_browse_tables(source):
            result = _navigation(source)
            source = None  # ownership transfers to the browser
            return result
        identity = {
            "version": BROWSE_VERSION,
            "library_id": library.library_id,
            "artifacts": dict(library.manifest.artifacts),
        }
        key = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
        cache_root = Path(cache_root)
        cache_root.mkdir(parents=True, exist_ok=True)
        path = cache_root / f"{key}.sqlite"
        receipt = path.with_suffix(".json")
        try:
            valid = json.loads(receipt.read_text()) == {
                "sha256": sha256_file(path),
                "identity": identity,
            }
        except (OSError, ValueError):
            valid = False
        if valid:
            connection = _read_only(path)
            try:
                if has_browse_tables(connection):
                    return _navigation(connection)
            except sqlite3.DatabaseError:
                pass
            connection.close()
        fd, name = tempfile.mkstemp(
            dir=cache_root, prefix=".pg-index-", suffix=".sqlite"
        )
        os.close(fd)
        temporary = Path(name)
        try:
            connection = sqlite3.connect(temporary)
            try:
                entries = (
                    sqlite_browse_entries(source)
                    if source is not None
                    else (entry.to_dict() for entry in library.entries())
                )
                build_browse_tables(connection, entries)
            finally:
                connection.close()
            digest = sha256_file(temporary)
            os.replace(temporary, path)
            atomic_json(receipt, {"sha256": digest, "identity": identity})
        finally:
            temporary.unlink(missing_ok=True)
        return _navigation(_read_only(path))
    finally:
        if source is not None:
            source.close()
