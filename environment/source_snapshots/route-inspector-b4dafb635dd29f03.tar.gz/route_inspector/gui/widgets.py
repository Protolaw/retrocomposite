"""Small reusable browser widgets; scientific state lives outside NiceGUI."""

import json

from nicegui import ui

from route_inspector.gui.svg import inline_glyphs


def table(
    rows,
    fields,
    *,
    key="id",
    on_select=None,
    selected_id=None,
    on_target=None,
    page=None,
    sort_by=None,
    descending=False,
    on_sort=None,
):
    columns = [
        dict(
            name=name,
            label=label,
            field=name,
            align="left",
            sortable=on_sort is not None and name != "target_image",
        )
        for name, label in fields
    ]
    originals = {row[key]: row for row in rows}
    display_rows = [
        {
            name: ", ".join(map(str, row[name]))
            if isinstance(row.get(name), (list, tuple))
            else row.get(name)
            for name in dict.fromkeys([key, *(name for name, _ in fields)])
        }
        for row in rows
    ]
    widget = ui.table(
        columns=columns,
        rows=display_rows,
        row_key=key,
        pagination={
            "sortBy": sort_by,
            "descending": descending,
            "rowsNumber": page.total,
            "rowsPerPage": page.limit,
            "page": page.offset // page.limit + 1,
        }
        if on_sort is not None
        else None,
        selection="single" if on_select else None,
        on_select=(
            lambda e: on_select(originals[e.selection[0][key]]) if e.selection else None
        )
        if on_select
        else None,
    ).classes("ri-table")
    if on_sort is not None:
        # rowsNumber enables server-side sorting: never reorder just this page.
        widget.props("hide-pagination binary-state-sort")
        sortable = {column["name"] for column in columns if column["sortable"]}

        def request_sort(event):
            pagination = event.args["pagination"]
            column = pagination.get("sortBy")
            if column in sortable:
                return on_sort(column, bool(pagination.get("descending", False)))

        widget.on("request", request_sort, ["pagination"])
    widget.selected = [row for row in display_rows if row[key] == selected_id]
    if any(name == "reaction_count" for name, _ in fields):
        widget.add_slot(
            "body-cell-reaction_count",
            '<q-td :props="props">{{ props.value == null ? "—" : props.value }}</q-td>',
        )
    if any(name == "entry_id" for name, _ in fields):
        # Keep full IDs in row keys, selection events and sorting; abbreviate text only.
        widget.add_slot(
            "body-cell-entry_id",
            '<q-td :props="props"><span :title="props.value">'
            '{{ props.value && props.value.startsWith("tactic_i_") && props.value.length > 17 '
            '? props.value.slice(0, 17) + "..." : props.value }}'
            '</span><q-btn v-if="props.value" flat dense size="sm" icon="content_copy" '
            'aria-label="Copy full ID" title="Copy full ID" '
            "@click.stop=\"$parent.$emit('copy-id', props.value)\" /></q-td>",
        )
        widget.on("copy-id", lambda e: ui.clipboard.write(e.args))
    if any(name == "composite_id" for name, _ in fields):
        widget.add_slot(
            "body-cell-composite_id",
            '<q-td :props="props"><span :title="props.value">'
            '{{ props.value ? props.value.slice(0, 20) + "…" : "" }}'
            '</span><q-btn v-if="props.value" flat dense size="sm" icon="content_copy" '
            'aria-label="Copy full ID" title="Copy full ID" '
            "@click.stop=\"$parent.$emit('copy-composite-id', props.value)\" /></q-td>",
        )
        widget.on("copy-composite-id", lambda e: ui.clipboard.write(e.args))
    if any(name == "target_image" for name, _ in fields):
        image = (
            '<img :src="props.value" alt="Target structure" '
            'style="width:100px;height:65px;object-fit:contain" />'
        )
        if on_target:
            widget.add_slot(
                "body-cell-target_image",
                '<q-td :props="props"><button v-if="props.value" type="button" '
                'class="ri-target-preview" '
                ":aria-label=\"'Enlarge target for route ' + props.row.route_id\" "
                f"@click.stop=\"$parent.$emit('target', props.row['{key}'])\">"
                + image
                + "</button></q-td>",
            )
            widget.on("target", lambda e: on_target(originals[e.args]))
        else:
            widget.add_slot(
                "body-cell-target_image",
                '<q-td :props="props"><span v-if="props.value">'
                + image
                + "</span></q-td>",
            )
    return widget


def copy_full_id(identifier):
    """A selectable complete identifier with a clipboard action."""
    with ui.row().classes("items-center"):
        ui.label(identifier).classes("text-caption select-text break-all").tooltip(
            identifier
        )
        button = ui.button(
            "Copy full ID",
            icon="content_copy",
            on_click=lambda: ui.clipboard.write(identifier),
        ).props("flat dense")
        button.on("click", js_handler="event => event.stopPropagation()")
    return button


def pager(page, callback):
    last_offset = max(0, (page.total - 1) // page.limit * page.limit)
    with ui.row().classes("items-center"):
        ui.button("First", on_click=lambda: callback(0)).props("flat").set_enabled(
            page.offset > 0
        )
        ui.button(
            "Previous", on_click=lambda: callback(max(0, page.offset - page.limit))
        ).props("flat").set_enabled(page.offset > 0)
        ui.label(
            f"{page.offset + 1 if page.total else 0}–{min(page.offset + page.limit, page.total)} of {page.total}"
        ).classes("text-caption")
        ui.button("Next", on_click=lambda: callback(page.offset + page.limit)).props(
            "flat"
        ).set_enabled(page.offset + page.limit < page.total)
        ui.button("Last", on_click=lambda: callback(last_offset)).props(
            "flat"
        ).set_enabled(page.total > 0 and page.offset != last_offset)


class RouteViewer:
    def __init__(
        self, preview, on_reaction, *, aam, on_aam_change, layered, on_layered_change
    ):
        self.svg = preview.get("svg", "")
        if preview.get("source_labels"):
            ui.label("Original routes: " + ", ".join(preview["source_labels"])).classes(
                "text-caption select-all"
            )
        with ui.row().classes("items-center"):
            ui.checkbox("AAM", value=aam, on_change=on_aam_change).tooltip(
                "Show atom mapping labels"
            )
            ui.checkbox("Layered", value=layered, on_change=on_layered_change).tooltip(
                "Arrange the route in connected layers with alternating left-to-right and right-to-left flow"
            )
            ui.button("Zoom in", on_click=lambda: self.action("riZoom(1/1.1)")).props(
                "flat dense"
            )
            ui.button("Zoom out", on_click=lambda: self.action("riZoom(1.1)")).props(
                "flat dense"
            )
            ui.button("Fit", on_click=lambda: self.action("riFit()")).props(
                "flat dense"
            )
            ui.button(
                "Fullscreen", on_click=lambda: self.action("requestFullscreen()")
            ).props("flat dense")
            ui.button(
                "Download SVG",
                on_click=lambda: ui.download.content(
                    self.svg, "route.svg", "image/svg+xml"
                ),
            ).props("flat dense").set_enabled(bool(self.svg))
        if not self.svg:
            ui.label(preview.get("message") or "Select a route to begin.").classes(
                "ri-placeholder"
            )
            self.canvas = None
            return
        self.canvas = ui.html(inline_glyphs(self.svg), sanitize=True).classes(
            "ri-canvas"
        )
        self.canvas.on(
            "click",
            lambda e: on_reaction(e.args),
            js_handler="(e) => { const n=e.target.closest('.ri-route-reaction'); if(n) emit(n.dataset.reactionPath); }",
        )
        ui.timer(
            0.05,
            lambda: ui.run_javascript(f"window.riRouteViewer({self.canvas.id})"),
            once=True,
        )

    def action(self, method):
        if self.canvas:
            ui.run_javascript(f"document.getElementById('c{self.canvas.id}')?.{method}")

    def update_preview(self, preview):
        """Replace the drawing while retaining live toolbar event handlers."""
        self.svg = preview["svg"]
        self.canvas.set_content(inline_glyphs(self.svg))
        self.canvas.client.run_javascript(
            f"requestAnimationFrame(() => window.riRouteViewer({self.canvas.id}))"
        )

    def select(self, path):
        if self.canvas:
            # Navigation may have deleted the event's original slot during refresh.
            self.canvas.client.run_javascript(
                f"window.riSelectReaction({self.canvas.id}, {json.dumps(path)})"
            )
