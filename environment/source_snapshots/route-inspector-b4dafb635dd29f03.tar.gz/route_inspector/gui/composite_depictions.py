"""Persist drawings of stored queries; never execute or re-extract rules."""

import hashlib
import json
import sqlite3
from collections import OrderedDict
from pathlib import Path
from uuid import uuid4

from route_inspector.gui.inspection import render_composite
from route_inspector.rules.config import dependency_version

DEPICTION_VERSION = 1


class CompositeDepictions:
    """Lazy, thread-owned SQLite drawing cache shared across GUI sessions."""

    def __init__(self, output):
        identity = json.dumps(
            {
                "version": DEPICTION_VERSION,
                "chython": dependency_version("chython-synplan"),
                "aam": True,
            },
            sort_keys=True,
        )
        self.path = (
            Path(output)
            / "composite_depictions"
            / (hashlib.sha256(identity.encode()).hexdigest() + ".sqlite")
        )
        self.connection = None
        self.memory = OrderedDict()

    def close(self):
        if self.connection is not None:
            self.connection.close()
        self.connection = None
        self.memory.clear()

    def _open(self):
        if self.connection is not None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path, timeout=30)
        self.connection.execute(
            "CREATE TABLE IF NOT EXISTS drawings (rule TEXT PRIMARY KEY, svg TEXT NOT NULL, digest TEXT NOT NULL)"
        )
        self.connection.commit()

    def _read(self, rule):
        try:
            self._open()
            return self.connection.execute(
                "SELECT svg, digest FROM drawings WHERE rule=?", (rule,)
            ).fetchone()
        except sqlite3.DatabaseError as exc:
            self.close()
            if getattr(exc, "sqlite_errorcode", 0) & 0xFF not in {
                sqlite3.SQLITE_CORRUPT,
                sqlite3.SQLITE_NOTADB,
                sqlite3.SQLITE_ERROR,
            }:
                # Lock contention or a read-only directory is not corruption.
                raise
            # Only a disposable drawing cache is quarantined. Libraries and
            # completed relationship indexes are never touched.
            self.path.replace(self.path.with_suffix(f".damaged-{uuid4().hex}"))
            self._open()
            return None

    def get(self, rule):
        if rule in self.memory:
            self.memory.move_to_end(rule)
            return self.memory[rule]
        row = self._read(rule)
        if (
            row is not None
            and isinstance(row[0], str)
            and hashlib.sha256(row[0].encode()).hexdigest() == row[1]
        ):
            svg = row[0]
        else:
            svg = render_composite(rule)
            digest = hashlib.sha256(svg.encode()).hexdigest()
            with self.connection:
                self.connection.execute(
                    "INSERT OR REPLACE INTO drawings VALUES (?, ?, ?)",
                    (rule, svg, digest),
                )
        self.memory[rule] = svg
        while len(self.memory) > 128:
            self.memory.popitem(last=False)
        return svg
