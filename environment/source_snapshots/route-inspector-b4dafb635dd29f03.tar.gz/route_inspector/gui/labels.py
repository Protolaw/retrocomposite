"""Human-readable tactic labels; persisted kind codes remain unchanged."""

TACTIC_LABELS = {
    "rrseq_cons": "Sequence · Consecutive",
    "rrseq_gap": "Sequence · Gapped",
    "rrsubtree_cons": "Subtree · Consecutive",
    "rrsubtree_gap": "Subtree · Gapped",
}
