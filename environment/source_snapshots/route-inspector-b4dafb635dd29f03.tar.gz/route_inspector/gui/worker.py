"""Subprocess entrypoint for a single GUI assessment (no web imports)."""

import json
import sys
import traceback
from pathlib import Path

from route_inspector.gui.sources import load_verified_route
from route_inspector.infrastructure.artifacts import write_json
from route_inspector.reference_library import ReferenceTacticLibrary
from route_inspector.workflows.interactive import assess_prepared_route


def main(directory: Path):
    def status(state, message):
        temporary = directory / "status.next.json"
        write_json(temporary, {"state": state, "message": message})
        temporary.replace(directory / "status.json")

    try:
        request = json.loads((directory / "request.json").read_text())
        if request.get("operation") == "pg_proposal":
            from route_inspector.workflows.pg_recovery import propose_pg_strategies
            from route_inspector.workflows.requests import ProposePgStrategiesRequest

            propose_pg_strategies(
                ProposePgStrategiesRequest(
                    routes_json=Path(request["routes_json"]),
                    reference_routes_json=Path(request["reference_routes_json"]),
                    library=Path(request["library"]),
                    output_dir=directory / "result",
                ),
                progress=lambda stage, message: status("running", message),
            )
            status(
                "completed",
                "PG proposals completed; recovery and diagnostics are available",
            )
            return 0
        if request.get("operation") == "single_step_overlap":
            from route_inspector.composite_rules.library import (
                CompositeDecompositionLibrary,
            )
            from route_inspector.workflows.overlap import (
                OverlapRequest,
                prepare_overlap,
            )

            status("running", "Verifying single-step vocabulary sources and profile")
            with (
                ReferenceTacticLibrary.load(request["library"]) as library,
                CompositeDecompositionLibrary.load(request["composites"]) as composites,
            ):
                prepare_overlap(
                    OverlapRequest(
                        source=Path(request["source"]),
                        destination=Path(request["destination"]),
                        expected_identity=request["identity"],
                    ),
                    library,
                    composites,
                    progress=status,
                )
            status("completed", "Single-step vocabulary ready")
            return 0
        status("running", "Verifying library and source")
        route = load_verified_route(
            Path(request["source"]),
            request["route_id"],
            expected_digest=request["source_sha256"],
        )
        with ReferenceTacticLibrary.load(
            request["library"], verification=request["verification"]
        ) as library:
            if library.library_id != request["library_id"]:
                raise ValueError("selected library identity changed")
            status("running", "Validating profile, extracting and matching tactics")
            assess_prepared_route(
                library,
                route,
                route_id=request["route_id"],
                source_sha256=request["source_sha256"],
                config=request["config"],
                output_dir=directory / "result",
                verification=request["verification"],
            )
        status(
            "completed",
            "Analysis completed; inspect the assessment status for extraction limitations",
        )
    except Exception as exc:
        traceback.print_exc()
        status("failed", f"{type(exc).__name__}: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(Path(sys.argv[1])))
