"""Local-only, read-only route/tactic explorer built on the scientific APIs."""

from __future__ import annotations

import asyncio
import copy
import csv
import io
import json
import os
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from pathlib import Path

from nicegui import app, ui

from route_inspector.gui.audit_ui import AuditUI
from route_inspector.gui.composites import OVERLAP_FILTERS, fetch_composite
from route_inspector.gui.inspection import metadata_text, render_tactic
from route_inspector.gui.jobs import AnalysisJobs
from route_inspector.gui.pg import fetch_pg
from route_inspector.gui.screens import ExplorerScreens
from route_inspector.gui.service import ExplorerService
from route_inspector.gui.state import ROUTE_PAGE_SIZE, ExplorerState
from route_inspector.reference_library.browsing import (
    KINDS,
    BrowsePage,
    occurrence_summary,
)
from route_inspector.reference_library.models import TacticOccurrence

LABELS = {
    kind: kind.replace("rrseq", "RRSeq").replace("rrsubtree", "RRSubtree")
    for kind in KINDS
}
EMPTY = BrowsePage((), 0, 0, 50)


class Explorer(AuditUI, ExplorerScreens):
    def __init__(self, workspace, jobs):
        self.workspace, self.jobs = workspace, jobs
        self.service = ExplorerService(workspace)
        self.executor = ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="route-explorer"
        )
        self.state = ExplorerState()
        self.info = None
        self.view = {}
        self.error = ""
        self.generation = 0
        self.job_id = None
        self.seen_job_state = None
        self.reactions = []
        self.screen = "datasets"
        self.dataset_rows = []
        self.loading_dataset = None
        self.verification_note = ""
        self.scanning = True
        self.init_proposals()
        self.init_related()
        self.init_composite_lhs()
        self.init_activators()
        with ui.header().classes("ri-header items-center"):
            ui.icon("account_tree", size="26px").classes("ri-brand-icon")
            ui.label("Route Inspector").classes("ri-brand")
            ui.space()
            audit_label = (
                ui.label()
                .classes("text-xs")
                .bind_text_from(
                    self,
                    "verification_note",
                    backward=lambda note: (
                        "Snapshot verified · recheck pending"
                        if "pending" in note
                        else "Libraries verified"
                        if note
                        else ""
                    ),
                )
            )
            audit_label.bind_visibility_from(
                self,
                "verification_note",
                backward=lambda note: bool(note) and "pending" not in note,
            )
            with audit_label:
                ui.tooltip().bind_text_from(self, "verification_note")
            ui.label("SYNTHESIS EXPLORER").classes("ri-header-note")
        with ui.column().classes("ri-shell"):
            self.banner = ui.label("").classes("ri-status")
            self.error_label = ui.label("").classes("text-negative w-full")
            self.init_audits()
            self.body()
        self.timer = ui.timer(0.6, self.poll_job)
        self.overlap_timer = ui.timer(1.0, self.poll_overlap)
        self.discovery_timer = ui.timer(0.01, self.scan_datasets, once=True)
        self.client = ui.context.client
        self.client.on_delete(self.close)

    async def call(self, function, *args, **kwargs):
        return await asyncio.get_running_loop().run_in_executor(
            self.executor, partial(function, *args, **kwargs)
        )

    def fail(self, exc):
        self.error = f"{type(exc).__name__}: {exc}"
        self.error_label.set_text(self.error)
        ui.notify(self.error, type="negative", close_button=True)

    async def scan_datasets(self):
        if self.loading_dataset:
            return
        self.scanning = True
        try:
            self.dataset_rows = await self.call(self.service.datasets)
        except Exception as exc:
            self.fail(exc)
        finally:
            self.scanning = False
            await self.body.refresh()

    async def load_dataset(self, dataset):
        await self.begin_dataset_audit(dataset)

    async def accept_dataset(self, info):
        self.generation += 1
        self.invalidate_related()
        self.invalidate_lhs()
        self.info, self.state, self.view = info, ExplorerState(), {}
        self.related_history.clear()
        self.lhs_history.clear()
        self.lhs_pages.clear()
        self.related_key = None
        self.screen = "modes"
        await self.call(self.service.save_settings, {"dataset": info["dataset_id"]})
        self.banner.set_text("")

    async def choose_pg_mode(self, mode):
        if not self.info.get("pg", {}).get("available"):
            return
        self.invalidate_related()
        self.state.analysis_domain = "PG strategies"
        self.state.pg_mode = mode
        self.screen = "explorer"
        if mode == "Propose-PG":
            self.generation += 1
            if (
                self.proposal_browser is None
                and (
                    self.workspace / self.proposal_directory / "manifest.json"
                ).exists()
            ):
                await self.load_pg_recovery()
            else:
                await self.refresh_proposals()
            return
        await self.refresh()

    async def change_pg(self, name, value):
        selection = self.state.pg
        setattr(selection, name, value or "" if name == "search" else value)
        if self.state.pg_mode == "Tactic-wise" and name in {
            "tactic_id",
            "tactic_length",
            "tactic_minimum_events",
            "terminus",
        }:
            if name == "terminus":
                selection.tactic_length = 0
            if name != "tactic_id":
                selection.tactic_id = None
                selection.tactic_offset = 0
            selection.pg_type = selection.family = selection.route_id = None
            selection.event_id = selection.step_id = selection.ngram_id = None
            selection.type_offset = selection.family_offset = selection.route_offset = 0
            selection.event_offset = selection.gram_offset = 0
            selection.ngram_length = 0
        if name in {
            "protections_detected",
            "origin",
            "terminus",
            "pg_type",
            "family",
            "search",
        }:
            selection.route_offset = 0
            selection.route_id = None
        if name in {"origin", "terminus", "pg_type"}:
            selection.family = None
            selection.family_offset = 0
        if name in {"origin", "terminus"}:
            selection.pg_type = None
            selection.type_offset = 0
        if name in {
            "protections_detected",
            "origin",
            "terminus",
            "pg_type",
            "family",
            "search",
            "route_id",
        }:
            selection.event_id = None
            selection.event_offset = 0
        if name in {
            "protections_detected",
            "origin",
            "terminus",
            "pg_type",
            "family",
            "search",
            "route_id",
            "event_id",
        }:
            selection.step_id = selection.ngram_id = None
            selection.gram_offset = 0
            selection.ngram_length = 0
        if name == "ngram_length":
            selection.gram_offset = 0
            selection.ngram_id = None
        if name == "ngram_id":
            selection.step_id = None
        if name == "step_id":
            selection.ngram_id = None
        await self.refresh()

    async def sort_pg_tactics(self, column, descending):
        selection = self.state.pg
        selection.tactic_descending = descending
        selection.tactic_sort = column
        selection.tactic_offset = 0
        await self.refresh()

    async def switch_pg_context(self):
        if not self.view.get("event"):
            return
        selection = copy.deepcopy(self.state.pg)
        selection.route_offset = selection.family_offset = selection.type_offset = 0
        selection.search = ""
        if self.state.pg_mode == "Route-wise":
            selection.pg_type = self.view["event"]["pg_type"]
            selection.family = self.view["event_family"]
            self.state.pg_types = selection
            await self.choose_pg_mode("PG-wise")
        else:
            selection.pg_type = selection.family = None
            self.state.pg_routes = selection
            await self.choose_pg_mode("Route-wise")

    async def sort_pg(self, column, descending):
        self.state.pg.sort_by, self.state.pg.descending = column, descending
        self.state.pg.route_offset = 0
        await self.refresh()

    async def choose_mode(self, mode):
        if not self.info.get("tactics", {}).get("available", True):
            return
        self.state.analysis_domain = "Tactics"
        if mode == "Composite-wise" and not self.info.get("composites", {}).get(
            "available"
        ):
            return
        self.screen = "explorer"
        self.state.mode = mode
        await self.refresh()

    async def choose_analysis(self):
        self.invalidate_related()
        self.screen = "modes"
        await self.body.refresh()

    async def change_dataset(self):
        self.invalidate_activators()
        if self.screen != "datasets":
            self.audit_return_screen = self.screen
        self.invalidate_related()
        self.generation += 1
        self.screen = "datasets"
        self.error_label.set_text("")
        self.banner.set_text("")
        if self.loading_dataset:
            await self.body.refresh()
        else:
            await self.scan_datasets()

    def fetch(self, state):
        if state.analysis_domain == "PG strategies":
            return fetch_pg(self.service, state)
        result = {
            "preview": {},
            "occurrences": EMPTY,
            "routes": BrowsePage((), 0, 0, ROUTE_PAGE_SIZE),
            "entries": EMPTY,
            "rule_svg": "",
            "rule_error": None,
            "selected": None,
        }
        if state.mode in {"Tactic-wise", "Composite-wise"}:
            composite = state.mode == "Composite-wise"
            scope = "composites" if composite else "tactics"
            result["activator_context"] = self.service.activator_contexts.get(scope)
            result["activators"] = self.service.activator_status(
                scope,
                state.composite_kind if composite else state.kind,
                state.composite_id if composite else state.entry_id,
            )
        if state.mode == "Composite-wise":
            key, selected = fetch_composite(self.service, state, result)
        elif state.mode == "Tactic-wise":
            result["related_directory"] = str(self.service.library.directory)
            result["entries"] = self.service.entries(
                kind=state.kind,
                minimum_size=state.minimum_size,
                minimum_support=state.minimum_support,
                search=state.tactic_search,
                offset=state.entry_offset,
                sort_by=state.entry_sort_by,
                descending=state.entry_sort_descending,
                activator_filter=state.activator_filter,
            )
            if state.entry_id:
                if (
                    state.activator_filter != "all"
                    and not self.service.entries(
                        kind=state.kind,
                        search=state.entry_id,
                        activator_filter=state.activator_filter,
                    ).total
                ):
                    result["clear_tactic_selection"] = True
                    result["activators"]["detail"] = None
                    return result
                result["entry"] = self.service.entry(state.entry_id)
                result["routes"] = self.service.routes(
                    entry_id=state.entry_id,
                    offset=state.source_offset,
                    limit=ROUTE_PAGE_SIZE,
                )
            key, selected = state.tactic_route, state.tactic_occurrence_id
            if key:
                result["occurrences"] = self.service.occurrences(
                    route=key,
                    entry_id=state.entry_id,
                    offset=state.tactic_occurrence_offset,
                )
                if selected is None and state.entry_id and result["occurrences"].rows:
                    selected = result["occurrences"].rows[0]["id"]
                    result["active_tactic_occurrence_id"] = selected
        elif state.source == "New prepared route":
            result["routes"] = (
                self.service.query_routes(
                    limit=ROUTE_PAGE_SIZE,
                    search=state.route_search,
                    offset=state.route_offset,
                    sort_by=state.route_sort_by,
                    descending=state.route_sort_descending,
                )
                if self.service.query
                else BrowsePage((), 0, 0, ROUTE_PAGE_SIZE)
            )
            matches = (state.assessment or {}).get("matches", [])
            rows = []
            for match in matches:
                occurrence = TacticOccurrence.from_dict(match["occurrence"])
                row = occurrence_summary(occurrence)
                entry = match["reference_entry"]
                row.update(
                    entry_id=entry["entry_id"] if entry else None,
                    route_count=entry["route_count"] if entry else 0,
                    known=match["known"],
                )
                rows.append(row)
                if row["id"] == state.query_occurrence_id:
                    result["selected"] = row
            rows.sort(key=lambda r: (r["kind"], r["id"]))
            result["occurrences"] = BrowsePage(
                tuple(rows[state.occurrence_offset : state.occurrence_offset + 50]),
                len(rows),
                state.occurrence_offset,
                50,
            )
            if state.query_route_id:
                try:
                    result["preview"] = self.service.inspect_query(
                        state.query_route_id,
                        [m["occurrence"] for m in matches],
                        state.query_occurrence_id,
                        state.skipped,
                        aam=state.aam,
                        layered=state.layered,
                    )
                except Exception as exc:
                    result["preview"] = {"message": f"Route drawing unavailable: {exc}"}
                selected_occ = next(
                    (
                        m["occurrence"]
                        for m in matches
                        if m["occurrence"]["reference_occurrence_id"]
                        == state.query_occurrence_id
                    ),
                    None,
                )
                if selected_occ:
                    self.rule(result, TacticOccurrence.from_dict(selected_occ))
            return result
        else:
            result["routes"] = self.service.routes(
                limit=ROUTE_PAGE_SIZE,
                search=state.route_search,
                offset=state.route_offset,
                rrseq_cons=state.route_rrseq_cons,
                rrseq_gap=state.route_rrseq_gap,
                sort_by=state.route_sort_by,
                descending=state.route_sort_descending,
            )
            key, selected = state.route, state.occurrence_id
            if key:
                result["occurrences"] = self.service.occurrences(
                    route=key, offset=state.occurrence_offset
                )
        if key:
            try:
                result["preview"] = self.service.inspect(
                    key, selected, state.skipped, aam=state.aam, layered=state.layered
                )
            except Exception as exc:
                result["preview"] = {"message": f"Route drawing unavailable: {exc}"}
        if selected:
            occurrence = self.service.library.get_occurrence(selected)
            entry = self.service.library.get_entry(
                self.service.library.entry_id_for_occurrence(selected)
            )
            result["selected"] = occurrence_summary(occurrence, entry)
            self.rule(result, occurrence)
            if state.mode != "Composite-wise":
                try:
                    result["composite_link"] = self.service.composite_link(selected)
                except Exception as exc:
                    result["composite_error"] = f"Composite link unavailable: {exc}"
        return result

    @staticmethod
    def rule(result, occurrence):
        try:
            result["rule_svg"] = render_tactic(occurrence)
        except Exception as exc:
            result["rule_error"] = f"Rule depiction unavailable: {exc}"

    async def refresh(self, *, preview_only=False):
        if self.info is None:
            return
        if (
            self.state.analysis_domain == "PG strategies"
            and self.state.pg_mode == "Propose-PG"
            and self.screen == "explorer"
        ):
            await self.refresh_proposals()
            return
        if self.screen != "explorer":
            await self.body.refresh()
            return
        preview_only = preview_only and not getattr(self, "full_refresh_pending", False)
        if not preview_only:
            self.full_refresh_pending = True
        self.generation += 1
        generation = self.generation
        viewer = getattr(self, "viewer", None)
        try:
            if (
                self.state.analysis_domain == "Tactics"
                and self.state.mode == "Composite-wise"
            ):
                await self.call(self.service.prepare_overlap)
            view = await self.call(self.fetch, copy.deepcopy(self.state))
            if generation != self.generation or self.screen != "explorer":
                return
            self.view = view
            if "active_event" in view:
                self.state.pg.event_id = view["active_event"]
            if "active_ngram" in view:
                self.state.pg.ngram_id = view["active_ngram"]
            if view.get("clear_composite_selection"):
                self.clear_composite_selection()
                view.get("activators", {})["detail"] = None
            if view.get("clear_tactic_selection"):
                self.state.entry_id = self.state.tactic_route = (
                    self.state.tactic_occurrence_id
                ) = None
                self.state.source_offset = self.state.tactic_occurrence_offset = 0
            if "active_tactic_occurrence_id" in view:
                self.state.tactic_occurrence_id = view["active_tactic_occurrence_id"]
            for field in (
                "composite_tactic_id",
                "composite_route",
                "composite_occurrence_id",
                "composite_submode",
            ):
                if f"active_{field}" in view:
                    setattr(self.state, field, view[f"active_{field}"])
            if (
                preview_only
                and viewer
                and viewer is getattr(self, "viewer", None)
                and viewer.canvas
                and view.get("preview", {}).get("svg")
            ):
                viewer.update_preview(view["preview"])
                self.reactions = view["preview"].get("reactions", [])
            else:
                self.schedule_related()
                self.schedule_lhs()
                self.schedule_activators()
                await self.body.refresh()
        except Exception as exc:
            self.fail(exc)
        finally:
            if generation == self.generation:
                self.full_refresh_pending = False

    async def change(self, name, value):
        if (
            name == "mode"
            and value == "Composite-wise"
            and not self.info.get("composites", {}).get("available")
        ):
            return
        if (
            name == "composite_source_offset"
            and value != self.state.composite_source_offset
        ):
            # The next fetch selects the first route/occurrence on the new page.
            # Do not retain an off-page route in the viewer or decomposition.
            self.state.composite_route = self.state.composite_occurrence_id = None
            self.state.composite_occurrence_offset = 0
        setattr(self.state, name, value)
        if (
            name == "source"
            and value == "New prepared route"
            and self.state.route_sort_by in {"occurrence_count", "unique_tactic_count"}
        ):
            self.state.route_sort_by = None
            self.state.route_sort_descending = False
        if name in {
            "composite_kind",
            "composite_search",
            "composite_minimum_support",
            "composite_ring_breaking_only",
            "composite_submode",
            "composite_activator_filter",
        }:
            self.state.composite_offset = 0
        if name == "overlap_evidence_offset":
            self.state.overlap_step_id = None
        if name == "composite_kind":
            self.state.composite_tactic_id = None
            self.state.composite_tactic_expanded = True
            self.state.composite_id = self.state.composite_route = (
                self.state.composite_occurrence_id
            ) = None
            self.state.composite_source_offset = (
                self.state.composite_occurrence_offset
            ) = 0
        if name in {
            "kind",
            "tactic_search",
            "minimum_size",
            "minimum_support",
            "activator_filter",
        }:
            self.state.entry_offset = 0
        if name == "kind":
            self.state.entry_id = self.state.tactic_route = (
                self.state.tactic_occurrence_id
            ) = None
            self.state.source_offset = self.state.tactic_occurrence_offset = 0
        if name == "route_search":
            self.state.route_offset = 0
        if name in {"route_rrseq_cons", "route_rrseq_gap"}:
            self.state.clear_route_selection()
        if name in {"aam", "layered"}:
            await self.refresh(preview_only=True)
        else:
            await self.refresh()

    async def reset_route_filters(self):
        self.state.reset_route_filters()
        await self.refresh()

    async def sort_table(self, scope, sort_by, descending):
        if scope not in {"route", "entry", "composite"}:
            raise ValueError("unknown navigation table")
        if (
            getattr(self.state, f"{scope}_sort_by"),
            getattr(self.state, f"{scope}_sort_descending"),
        ) == (sort_by, descending):
            return
        setattr(self.state, f"{scope}_sort_by", sort_by)
        setattr(self.state, f"{scope}_sort_descending", bool(descending))
        setattr(self.state, f"{scope}_offset", 0)
        await self.refresh()

    async def select_route(self, row):
        if self.state.mode == "Composite-wise":
            self.state.composite_route = {
                k: row[k] for k in ("dataset_id", "source_identity", "route_id")
            }
            self.state.composite_occurrence_id = None
            self.state.composite_occurrence_offset = 0
        elif self.state.mode == "Tactic-wise":
            self.state.tactic_route = {
                k: row[k] for k in ("dataset_id", "source_identity", "route_id")
            }
            self.state.tactic_occurrence_id, self.state.tactic_occurrence_offset = (
                None,
                0,
            )
        elif self.state.source == "New prepared route":
            self.state.query_route_id = row["route_id"]
            self.state.assessment = self.state.query_occurrence_id = None
            self.state.occurrence_offset = 0
        else:
            self.state.route = {
                k: row[k] for k in ("dataset_id", "source_identity", "route_id")
            }
            self.state.occurrence_id, self.state.occurrence_offset = None, 0
        await self.refresh()

    async def select_entry(self, row):
        self.state.related_direction, self.state.related_offset = "extensions", 0
        self.state.entry_id = row["entry_id"]
        self.state.tactic_route = self.state.tactic_occurrence_id = None
        self.state.source_offset = self.state.tactic_occurrence_offset = 0
        await self.refresh()

    async def select_composite(self, row):
        self.state.composite_lhs_offset = 0
        self.state.composite_lhs_selected = None
        self.state.overlap_evidence_offset = 0
        self.state.overlap_step_id = None
        self.state.composite_id = row["composite_id"]
        self.state.composite_tactic_id = None
        self.state.composite_tactic_expanded = True
        self.state.composite_route = self.state.composite_occurrence_id = None
        self.state.composite_source_offset = self.state.composite_occurrence_offset = 0
        await self.refresh()

    async def select_composite_tactic(self, tactic_id, expanded=True):
        if not expanded:
            if tactic_id == self.state.composite_tactic_id:
                self.state.composite_tactic_expanded = False
            return
        self.state.composite_tactic_expanded = True
        if tactic_id == self.state.composite_tactic_id:
            return
        self.state.composite_tactic_id = tactic_id
        self.state.composite_route = self.state.composite_occurrence_id = None
        self.state.composite_source_offset = self.state.composite_occurrence_offset = 0
        await self.refresh()

    async def explore_composite(self):
        link = self.view.get("composite_link")
        if link:
            self.state.explore_composite(link)
            if self.state.composite_submode != "all":

                def visible():
                    if self.service.overlap_status()["state"] != "completed":
                        return False
                    return any(
                        row["composite_id"] == link["composite_id"]
                        for row in self.service.composite_entries(
                            search=link["composite_id"],
                            overlap=OVERLAP_FILTERS[self.state.composite_submode],
                        ).rows
                    )

                if not await self.call(visible):
                    self.state.composite_submode = "all"
            await self.refresh()

    def clear_composite_selection(self):
        self.state.composite_id = self.state.composite_tactic_id = None
        self.state.composite_route = self.state.composite_occurrence_id = None
        self.state.composite_source_offset = self.state.composite_occurrence_offset = 0
        self.state.overlap_evidence_offset = 0
        self.state.overlap_step_id = None

    async def inspect_overlap_route(self):
        step = (self.view.get("overlap_evidence") or {}).get("selected")
        if step:
            self.state.reset_route_filters()
            self.state.mode, self.state.source = "Route-wise", "Reference library"
            self.state.route = {
                key: step[key] for key in ("dataset_id", "source_identity", "route_id")
            }
            self.state.occurrence_id = None
            self.state.occurrence_offset = 0
            await self.refresh()
            self.select_reaction("/".join(map(str, step["reaction_node_path"])))

    async def retry_overlap(self):
        generation = self.generation
        preparation = self.service.overlap
        # Bind the current preparation before queuing: a dataset switch must
        # never launch a retry against the new dataset on an old button click.
        library, composites = self.service.library, self.service.composites
        source = next(iter(self.service.sources.values()))
        await self.call(preparation.retry, library, composites, source)
        if generation == self.generation and self.state.mode == "Composite-wise":
            await self.refresh()

    async def poll_overlap(self):
        if (
            self.screen != "explorer"
            or self.state.analysis_domain != "Tactics"
            or self.state.mode != "Composite-wise"
        ):
            return
        generation = self.generation
        status = await self.call(self.service.overlap_status)
        if (
            generation != self.generation
            or self.state.analysis_domain != "Tactics"
            or self.state.mode != "Composite-wise"
            or self.screen != "explorer"
        ):
            return
        previous = self.view.get("overlap_status")
        if previous is None:
            return  # Initial navigation is still preparing the composite view.
        if status.get("state") != previous.get("state"):
            if self.state.composite_submode == "all":
                # All-composite results do not depend on overlap readiness.
                # Keep live pagination/selection handlers during job transitions.
                self.view["overlap_status"] = status
                await self.composite_overlap_status.refresh()
            else:
                # Filtered results must be loaded/cleared when readiness changes.
                await self.refresh()
        elif hasattr(self, "overlap_label"):
            self.overlap_label.set_text(status.get("message", ""))

    async def select_occurrence(self, row):
        field = (
            "tactic_occurrence_id"
            if self.state.mode == "Tactic-wise"
            else (
                "query_occurrence_id"
                if self.state.source == "New prepared route"
                else "occurrence_id"
            )
        )
        await self.change(field, row["id"])

    async def explore_tactic(self):
        row = self.view.get("selected")
        if not row or not row["entry_id"]:
            return
        route, occurrence_id = row["route"], row["id"]
        if (
            self.state.mode == "Route-wise"
            and self.state.source == "New prepared route"
        ):

            def representative():
                entry = self.service.library.get_entry(row["entry_id"])
                occurrence = self.service.library.get_occurrence(
                    entry.representative_occurrence_id
                )
                return occurrence.route.to_dict(), occurrence.reference_occurrence_id

            route, occurrence_id = await self.call(representative)
        self.state.explore_tactic(row["entry_id"], row["kind"], route, occurrence_id)
        await self.refresh()

    async def inspect_route(self):
        self.state.inspect_route()
        await self.refresh()

    def select_reaction(self, path):
        row = next((r for r in self.reactions if r["path"] == path), None)
        if row is not None:
            self.inspector.set_text(metadata_text(row))
            self.viewer.select(path)

    async def open_query(self):
        try:
            await self.call(self.service.open_query, self.query_path.value)
            self.state.query_route_id = self.state.assessment = (
                self.state.query_occurrence_id
            ) = None
            self.state.route_offset = self.state.occurrence_offset = 0
            await self.refresh()
        except Exception as exc:
            self.fail(exc)

    async def start_analysis(self):
        try:
            config_value = self.config_path.value
            selected_route_id = self.state.query_route_id

            def request():
                self.service.query.check_unchanged()
                return {
                    "library": os.path.relpath(
                        self.service.library.directory, self.workspace
                    ),
                    "library_id": self.service.library.library_id,
                    "verification": self.service.verification,
                    "source": os.path.relpath(
                        self.service.query.source, self.workspace
                    ),
                    "source_sha256": self.service.query.digest,
                    "route_id": selected_route_id,
                    "config": os.path.relpath(
                        self.service.config_path(config_value), self.workspace
                    ),
                }

            values = await self.call(request)
            self.job_id = await self.call(self.jobs.start, values)
            self.seen_job_state = None
        except Exception as exc:
            self.fail(exc)

    async def poll_job(self):
        if self.job_id is None:
            return
        status = await self.call(self.jobs.poll)
        if status.get("job_id") != self.job_id:
            return
        if (
            self.state.source == "New prepared route"
            and self.state.mode == "Route-wise"
            and hasattr(self, "job_label")
        ):
            self.job_label.set_text(status.get("message", ""))
        state = status["state"]
        if state != self.seen_job_state:
            self.seen_job_state = state
            if state == "completed":
                ui.notify("Analysis completed. Open it from Saved analyses.")
                # Do not replace a route/library the user selected meanwhile.
                await self.refresh()
            elif state == "failed":
                self.fail(RuntimeError(status.get("message")))

    async def cancel_analysis(self):
        await self.call(self.jobs.cancel)

    async def load_result(self, job_id):
        if not job_id:
            return
        try:
            result = await self.call(self.jobs.result, job_id)
            request = result["request"]
            if request["library_id"] != self.info["library_id"]:
                raise ValueError("saved assessment belongs to a different library")
            await self.call(
                self.service.open_query, request["source"], request["source_sha256"]
            )
            if self.service.query.digest != request["source_sha256"]:
                raise ValueError("saved assessment source JSON has changed")
            self.state.query_path = request["source"]
            self.state.config_path = request["config"]
            self.state.query_route_id = request["route_id"]
            self.state.assessment = result["assessment"]
            self.state.query_occurrence_id = None
            self.state.occurrence_offset = 0
            await self.refresh()
        except Exception as exc:
            self.fail(exc)

    async def export_occurrences(self):
        try:
            state = copy.deepcopy(self.state)

            def rows():
                if state.mode == "Route-wise" and state.source == "New prepared route":
                    return [
                        occurrence_summary(
                            TacticOccurrence.from_dict(m["occurrence"]), None
                        )
                        | {
                            "entry_id": m["reference_entry"]["entry_id"]
                            if m["reference_entry"]
                            else None,
                            "known": m["known"],
                        }
                        for m in (state.assessment or {}).get("matches", [])
                    ]
                result, offset = [], 0
                while True:
                    page = self.service.occurrences(
                        route=state.tactic_route
                        if state.mode == "Tactic-wise"
                        else state.route,
                        entry_id=state.entry_id
                        if state.mode == "Tactic-wise"
                        else None,
                        offset=offset,
                        limit=200,
                    )
                    result.extend(page.rows)
                    offset += 200
                    if offset >= page.total:
                        return result

            records = await self.call(rows)
            stream = io.StringIO()
            if records:
                writer = csv.DictWriter(
                    stream, fieldnames=list(records[0]), delimiter="\t"
                )
                writer.writeheader()
                writer.writerows(
                    {
                        k: json.dumps(v) if isinstance(v, (dict, list)) else v
                        for k, v in r.items()
                    }
                    for r in records
                )
            ui.download.content(
                stream.getvalue(), "tactic_occurrences.tsv", "text/tab-separated-values"
            )
        except Exception as exc:
            self.fail(exc)

    async def close(self):
        self.invalidate_activators()
        for task in self.activator_tasks:
            task.cancel()
        self.activator_executor.shutdown(wait=False, cancel_futures=True)
        self.audit_timer.cancel()
        self.open_observations = ()
        await self.cancel_dataset_audit(refresh=False)
        self.invalidate_lhs()
        for task in self.lhs_tasks:
            task.cancel()
        await asyncio.get_running_loop().run_in_executor(
            self.lhs_executor, self.lhs_worker.close
        )
        self.lhs_executor.shutdown(wait=False)
        self.related_request += 1
        for task in self.related_tasks:
            task.cancel()
        await asyncio.get_running_loop().run_in_executor(
            self.related_executor, self.related_worker.close
        )
        self.related_executor.shutdown(wait=False)
        self.proposal_generation += 1
        self.proposal_timer.cancel()
        self.timer.cancel()
        self.overlap_timer.cancel()
        self.discovery_timer.cancel()
        await self.call(self.service.close)
        self.executor.shutdown(wait=False)


def launch(
    workspace: Path,
    port=8080,
    *,
    host="127.0.0.1",
    https=True,
    ssl_certfile=None,
    ssl_keyfile=None,
):
    if not workspace.is_dir():
        raise ValueError("workspace must be an existing directory")
    from route_inspector.gui.tls import tls_options

    tls = tls_options(workspace, https=https, certificate=ssl_certfile, key=ssl_keyfile)
    protocol = "https" if tls else "http"
    print(
        f"GUI listening on {host}:{port}. Open {protocol}://localhost:{port} "
        "using the local, Docker-published, or SSH-forwarded port.",
        flush=True,
    )
    assets = Path(__file__).parent
    jobs = AnalysisJobs(workspace / "outputs" / "gui" / "jobs")

    @ui.page("/")
    def index():
        ui.colors(primary="#22776d", secondary="#183b3c", accent="#22776d")
        ui.add_css((assets / "style.css").read_text())
        ui.add_body_html("<script>" + (assets / "viewer.js").read_text() + "</script>")
        Explorer(workspace, jobs)

    async def shutdown():
        from route_inspector.gui.audit_jobs import audit_jobs

        await asyncio.to_thread(audit_jobs(workspace).close)
        await asyncio.to_thread(jobs.cancel)

    app.on_shutdown(shutdown)
    ui.run(
        host=host,
        port=port,
        title="Route Inspector",
        reload=False,
        show=False,
        favicon="🧪",
        on_air=False,
        **tls,
    )
