"""PG route and type browsing, using the same canvas and tables as tactics."""

import json

from nicegui import ui

from route_inspector.gui.pg import PGBrowser
from route_inspector.gui.pg_proposals import PGProposalScreens
from route_inspector.gui.svg import inline_rule_glyphs
from route_inspector.gui.widgets import RouteViewer, copy_full_id, pager, table


class PGScreens(PGProposalScreens):
    def pg_mode_cards(self):
        with (
            ui.column()
            .classes("ri-analysis-group ri-pg-group w-full")
            .props('role=group aria-label="Protecting Group strategies"')
        ):
            ui.label("Protecting Group strategies").classes("ri-group-title")
            status = self.info.get("pg", {})
            if not status.get("available"):
                ui.label(status.get("reason", "PG library unavailable")).classes(
                    "text-caption"
                )
            with ui.row().classes("ri-choice-grid"):
                for mode, subtitle, label in (
                    (
                        "Route-wise",
                        "Browse routes with or without detected protecting-group events.",
                        "Explore PG routes",
                    ),
                    (
                        "PG-wise",
                        "Choose a protecting group, then explore its strategy families and source events.",
                        "Explore PG types",
                    ),
                    (
                        "Tactic-wise",
                        "Explore reaction-rule n-grams within introduced PG-event lifespans and compare protecting-group usage.",
                        "Explore n-grams within PG",
                    ),
                    (
                        "Propose-PG",
                        "Propose PG strategies from n1 n-gram evidence and compare with the original route.",
                        "Explore PG proposals",
                    ),
                ):
                    classes = "ri-choice-card ri-mode-card"
                    if mode == "Propose-PG":
                        classes += " ri-proposal-choice"
                    with ui.column().classes(classes):
                        with ui.row().classes("ri-mode-card-heading"):
                            ui.label(mode).classes("ri-choice-title")
                            ui.button(
                                label,
                                on_click=lambda mode=mode: self.choose_pg_mode(mode),
                                color="#2865a6",
                            ).props("unelevated no-caps text-color=white").set_enabled(
                                status.get("available", False)
                            )
                        ui.label(subtitle).classes("ri-choice-description")

    def pg_table_page(
        self, rows, fields, *, offset_name, selected=None, callback=None, key="id"
    ):
        page = PGBrowser.page(rows, getattr(self.state.pg, offset_name))
        table(page.rows, fields, key=key, selected_id=selected, on_select=callback)
        pager(page, lambda offset: self.change_pg(offset_name, offset))

    def pg_screen(self):
        if self.state.pg_mode == "Propose-PG":
            self.proposal_screen()
            return
        selection = self.state.pg
        no_protections = (
            self.state.pg_mode == "Route-wise" and not selection.protections_detected
        )
        with ui.row().classes("w-full items-start no-wrap max-md:flex-wrap"):
            with ui.column().classes("ri-card w-full md:w-2/5"):
                ui.label(f"Protecting Group strategies · {self.state.pg_mode}").classes(
                    "text-h6"
                )
                if self.state.pg_mode == "Route-wise":
                    ui.switch(
                        "Protections detected",
                        value=selection.protections_detected,
                        on_change=lambda e: self.change_pg(
                            "protections_detected", e.value
                        ),
                    )
                    ui.label(
                        "OFF · Routes with no recorded PG events"
                        if no_protections
                        else "ON · Routes with detected PG events"
                    ).classes("text-caption")
                if self.state.pg_mode == "Tactic-wise":
                    ui.label("Introduced PG events only").classes("text-subtitle2")
                else:
                    ui.select(
                        ["All", "In-stock", "Introduced"],
                        label="PG origin",
                        value=selection.origin,
                        on_change=lambda e: self.change_pg("origin", e.value),
                    ).classes("w-48").set_enabled(not no_protections)
                ui.select(
                    [
                        "All",
                        "Preserved in target",
                        "Not preserved in target",
                        "Unavailable",
                    ],
                    label="PG terminus",
                    value=selection.terminus,
                    on_change=lambda e: self.change_pg("terminus", e.value),
                ).classes("w-60").set_enabled(not no_protections)
                if self.state.pg_mode == "Tactic-wise":
                    self.pg_tactics_table()
                elif self.state.pg_mode == "PG-wise":
                    ui.label("Protecting groups").classes("text-subtitle1")
                    self.pg_table_page(
                        self.view.get("types", []),
                        [
                            ("id", "PG type"),
                            ("route_count", "Routes"),
                            ("occurrence_count", "Events"),
                            ("family_count", "Families"),
                        ],
                        offset_name="type_offset",
                        selected=selection.pg_type,
                        callback=lambda row: self.change_pg("pg_type", row["id"]),
                    )
                else:
                    self.pg_source_routes()
            with ui.column().classes("ri-card ri-route-column w-full md:w-3/5"):
                if self.state.pg_mode == "Tactic-wise" and selection.tactic_id:
                    self.pg_tactic_popularity()
                if (
                    self.state.pg_mode in {"PG-wise", "Tactic-wise"}
                    and selection.pg_type
                ):
                    self.pg_family_selector()
                    if selection.family:
                        self.pg_source_routes()
                ui.label(
                    f"Route {selection.route_id}"
                    if selection.route_id
                    else "PG route viewer"
                ).classes("text-h6")
                self.viewer = RouteViewer(
                    self.view.get("preview", {}),
                    self.select_reaction,
                    aam=self.state.aam,
                    on_aam_change=lambda e: self.change("aam", e.value),
                    layered=self.state.layered,
                    on_layered_change=lambda e: self.change("layered", e.value),
                )
                self.reactions = self.view.get("preview", {}).get("reactions", [])
                with ui.expansion("Reaction details").classes("w-full"):
                    self.inspector = ui.label(
                        "Select a reaction marker in the route."
                    ).classes("ri-inspector")
                if selection.route_id:
                    ui.label(
                        "No PG events recorded for this route."
                        if no_protections
                        else "PG events in this route"
                    ).classes("text-subtitle1")
                if selection.route_id and not no_protections:
                    self.pg_table_page(
                        [
                            {
                                **row,
                                "terminus_label": {
                                    "preserved": "Preserved in target",
                                    "not_preserved": "Not preserved in target",
                                }.get(row.get("terminus"), "Unavailable"),
                            }
                            for row in self.view.get("events", [])
                        ],
                        [
                            ("pg", "PG"),
                            ("origin", "Origin"),
                            ("terminus_label", "PG terminus"),
                            ("functional_group", "Protected group"),
                        ],
                        offset_name="event_offset",
                        selected=selection.event_id,
                        callback=lambda row: self.change_pg("event_id", row["id"]),
                    )
                if self.view.get("event"):
                    self.pg_event_details()

    def pg_tactics_table(self):
        selection = self.state.pg
        ui.select(
            {
                0: "All lengths",
                **{n: str(n) for n in self.view.get("tactic_lengths", [])},
            },
            label="Tactic length",
            value=selection.tactic_length,
            on_change=lambda e: self.change_pg("tactic_length", e.value),
        ).classes("w-48")
        ui.number(
            "Minimum PG events",
            value=selection.tactic_minimum_events,
            min=1,
            step=1,
            on_change=lambda e: self.change_pg(
                "tactic_minimum_events", max(1, int(e.value or 1))
            ),
        ).props("debounce=350").classes("w-48")
        rows = self.view.get("tactics", [])
        page = self.view.get("tactic_page") or PGBrowser.page(
            rows, selection.tactic_offset
        )
        widget = table(
            page.rows,
            [
                ("id", "N-gram ID"),
                ("length", "Length"),
                ("pg_type_count", "PG types"),
                ("event_count", "PG events"),
                ("route_count", "Routes"),
                ("window_count", "Occurrences"),
            ],
            key="id",
            selected_id=selection.tactic_id,
            on_select=lambda r: self.change_pg("tactic_id", r["id"]),
            page=page,
            sort_by=selection.tactic_sort,
            descending=selection.tactic_descending,
            on_sort=self.sort_pg_tactics,
        )
        widget.add_slot(
            "body-cell-id",
            '<q-td :props="props"><span :title="props.value">{{ props.value.slice(0, 22) }}…</span></q-td>',
        )
        pager(page, lambda offset: self.change_pg("tactic_offset", offset))
        if not rows:
            ui.label(
                "No introduced PG events have lifespan n-grams matching these filters."
            )
        if not self.view.get("multistep_ngrams_available", True):
            ui.label(
                "Multi-step n-gram evidence unavailable in this historical library; single-step rules are shown."
            )

    def pg_tactic_popularity(self):
        ui.label("Selected lifespan tactic").classes("text-h6")
        copy_full_id(self.state.pg.tactic_id)
        self.pg_rules(self.view.get("tactic_rules", []))
        ui.label("Protecting-group popularity").classes("text-subtitle1")
        ui.label(
            "Distinct introduced PG events; repeated windows count once per event. "
            "Share is relative to all matching events under the PG-terminus filter."
        ).classes("text-caption")
        self.pg_table_page(
            self.view.get("tactic_types", []),
            [
                ("id", "PG type"),
                ("event_count", "PG events"),
                ("event_share", "Event share"),
                ("route_count", "Routes"),
                ("window_count", "Occurrences"),
            ],
            offset_name="type_offset",
            selected=self.state.pg.pg_type,
            callback=lambda r: self.change_pg("pg_type", r["id"]),
        )

    def pg_family_selector(self):
        selection = self.state.pg
        ui.label(f"{selection.pg_type} strategy families").classes("text-subtitle1")
        self.pg_table_page(
            [
                {**row, "label": row["id"][:22] + "…"}
                for row in self.view.get("families", [])
            ],
            [
                ("label", "Family ID"),
                ("origins", "Origin"),
                ("functional_groups", "Protected group"),
                ("route_count", "Routes"),
                ("occurrence_count", "Events"),
            ],
            offset_name="family_offset",
            selected=selection.family,
            callback=lambda row: self.change_pg("family", row["id"]),
        )
        if selection.family:
            copy_full_id(selection.family)

    def pg_source_routes(self):
        selection = self.state.pg
        ui.label("Source routes").classes("text-subtitle1")
        ui.input(
            "Search PG routes",
            value=selection.search,
            on_change=lambda e: self.change_pg("search", e.value),
        ).props("debounce=350 clearable")
        page = self.view["routes"]
        table(
            page.rows,
            [
                ("route_id", "Route"),
                ("target_image", "Target"),
                ("reaction_count", "Reactions"),
                ("occurrence_count", "PG events"),
            ],
            selected_id=selection.route_id,
            on_select=lambda row: self.change_pg("route_id", row["route_id"]),
            page=page,
            sort_by=selection.sort_by,
            descending=selection.descending,
            on_sort=self.sort_pg,
            on_target=self.show_target,
        )
        pager(page, lambda offset: self.change_pg("route_offset", offset))
        if not page.total:
            ui.label("No routes match these filters.").classes("ri-placeholder")

    @staticmethod
    def pg_rules(rows):
        for row in rows:
            ui.label(row["label"]).classes("text-subtitle2")
            if row.get("svg"):
                ui.html(inline_rule_glyphs(row["svg"]), sanitize=True).classes(
                    "ri-rules-content w-full"
                )
            if row.get("error"):
                ui.label(row["error"]).classes("text-warning")

    def pg_event_details(self):
        event, selection = self.view["event"], self.state.pg
        ui.label(
            f"{event['pg_type']} · {event['source_type']} · {event['lifetime_steps']} interval reactions"
        ).classes("text-subtitle1")
        terminus = event.get("pg_terminus", "unavailable")
        labels = {
            "preserved": "Preserved in target",
            "not_preserved": "Not preserved in target",
            "unavailable": "Terminus unavailable — rebuild library",
        }
        ui.label(labels[terminus]).classes("text-subtitle2")
        evidence = event.get("annotations", {})
        if terminus == "preserved":
            ui.label(
                "Observed installation"
                if evidence.get("evidence_status") == "observed_installation"
                else "Structural candidate — protective intent not established"
            ).classes("text-caption")
            if evidence.get("trace_status") == "unresolved":
                ui.label("Unresolved lineage; lifespan evidence unavailable").classes(
                    "text-warning"
                )
            if evidence.get("precursor_types"):
                ui.label(
                    "Precursor types: " + ", ".join(evidence["precursor_types"])
                ).classes("text-caption")
        ui.button(
            "Explore this PG"
            if self.state.pg_mode == "Route-wise"
            else "Inspect PG route",
            on_click=self.switch_pg_context,
        ).props("flat no-caps")
        ui.label(
            "Blue: protection · Cyan: incorporation · Amber: interval · Purple: deprotection · Green: stock · Pink: target PG"
        ).classes("text-caption")
        with ui.expansion("Event provenance and endpoint rules").classes("w-full"):
            copy_full_id(event["occurrence_id"])
            ui.label(json.dumps(event, indent=2)).classes("ri-inspector")
            self.pg_rules(self.view.get("endpoints", []))
        ui.label("Lifespan reactions").classes("text-subtitle1")
        ui.label(
            (
                "Synthetic order; installation excluded, protected steps through the target included. "
                if terminus == "preserved"
                else "Synthetic order; source and deprotection endpoints excluded. "
            )
            + "Single-step reaction rules are included as length-1 n-grams."
        ).classes("text-caption")
        steps = [{**s, "position": i + 1} for i, s in enumerate(self.view["steps"])]
        if self.state.pg_mode == "Tactic-wise":
            matching_steps = {
                key for g in self.view["grams"] for key in g["step_occurrence_ids"]
            }
            steps = [s for s in steps if s["occurrence_id"] in matching_steps]
        table(
            steps,
            [
                ("position", "Position"),
                ("reaction_node_path", "Node path"),
                ("active_pg_types", "Active PGs"),
            ],
            key="occurrence_id",
            selected_id=selection.step_id,
            on_select=lambda row: self.change_pg("step_id", row["occurrence_id"]),
        )
        if not steps:
            ui.label("No reactions strictly inside this lifespan.")
        ui.label("Lifespan n-grams").classes("text-subtitle1")
        grams = self.view["grams"]
        ui.select(
            {
                0: "All lengths",
                **{n: str(n) for n in sorted({g["length"] for g in grams})},
            },
            label="N-gram length",
            value=selection.ngram_length,
            on_change=lambda e: self.change_pg("ngram_length", e.value),
        ).classes("w-48")
        filtered = [
            {**g, "span": f"{g['start_index'] + 1}–{g['start_index'] + g['length']}"}
            for g in grams
            if not selection.ngram_length or g["length"] == selection.ngram_length
        ]
        self.pg_table_page(
            filtered,
            [
                ("length", "Length"),
                ("span", "Interval span"),
                (
                    "route_count",
                    "Matching routes"
                    if self.state.pg_mode == "Tactic-wise"
                    else "Library routes",
                ),
                (
                    "occurrence_count",
                    "Matching occurrences"
                    if self.state.pg_mode == "Tactic-wise"
                    else "Library occurrences",
                ),
            ],
            offset_name="gram_offset",
            selected=selection.ngram_id,
            key="occurrence_id",
            callback=lambda row: self.change_pg("ngram_id", row["occurrence_id"]),
        )
        if not grams:
            ui.label("No n-grams: no reactions strictly inside this lifespan.")
        if len(steps) >= 2 and not self.view.get("multistep_ngrams_available", True):
            ui.label(
                "Multi-step n-gram evidence unavailable in this historical library; single-step rules are shown."
            )
        if self.view.get("span"):
            ui.label(self.view["span"]).classes("text-subtitle1")
        self.pg_rules(self.view.get("selected_rules", []))
