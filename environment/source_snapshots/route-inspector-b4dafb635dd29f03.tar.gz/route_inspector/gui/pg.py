"""Read-only PG navigation over verified event provenance and lifespan evidence."""

import json
from collections import OrderedDict

from route_inspector.gui.depiction import depiction_settings
from route_inspector.gui.inspection import (
    GUI_LAYERED_FLOW,
    reaction_rows,
    render_composite,
)
from route_inspector.gui.pg_index import open_pg_index
from route_inspector.gui.sources import RouteSource
from route_inspector.gui.verification import load_verified
from route_inspector.infrastructure.build_workspace import ByteMemo
from route_inspector.protection.strategies.catalog import ReferencePGStrategyLibrary
from route_inspector.reference_library.browsing import (
    BrowsePage,
    matches_route_search,
    sort_route_rows,
)
from route_inspector.visualization import get_route_svg_from_json


class PGBrowser:
    """Read-only queries over persistent PG navigation tables."""

    def __init__(
        self,
        directory,
        source_path,
        dataset,
        verification="full",
        *,
        cache_root=None,
        source=None,
    ):
        from pathlib import Path

        cache_root = (
            Path(cache_root)
            if cache_root is not None
            else Path(directory).parent / ".gui-cache"
        )
        self.library = load_verified(
            ReferencePGStrategyLibrary.load,
            directory,
            cache_root / "verification",
            verification,
        )
        self.db = None
        self.cache = OrderedDict()
        self._tactic_pages = ByteMemo(self._tactic_page, max_bytes=2 * 1024 * 1024)
        try:
            corpora = self.library.manifest.reference_corpora
            from route_inspector.gui.datasets import corpus_ids

            if len(corpora) != 1 or corpora[0]["dataset_id"] not in corpus_ids(dataset):
                raise ValueError(f"PG library is not the selected {dataset} corpus")
            corpus = corpora[0]
            self.source = source if source is not None else RouteSource(source_path)
            # Source identity is stable across append/replace revisions so that
            # unchanged occurrence provenance survives; input_sha256 binds bytes.
            expected_digest = corpus.get("input_sha256")
            if expected_digest is None:
                expected_digest = str(corpus["source_identity"]).removeprefix("sha256:")
            if expected_digest != self.source.digest:
                raise ValueError("PG library and source SHA-256 do not match")
            if not set(map(str, corpus.get("route_ids", ()))) <= set(
                self.source.route_ids
            ):
                raise ValueError("PG source does not contain all recorded route IDs")
            self.corpus = corpus
            self.db = open_pg_index(self.library, directory, cache_root / "pg_indexes")
            event_route_ids = {
                row[0]
                for row in self.db.execute("SELECT DISTINCT route_id FROM events")
            }
            self.no_pg_route_ids = (
                frozenset(map(str, corpus.get("route_ids", ()))) - event_route_ids
            )
            self.targets = self.source.targets()
            self.reaction_counts = self.source.reaction_counts()
        except Exception:
            self.close()
            raise

    def close(self):
        self.library.close()
        if self.db is not None:
            self.db.close()
        self.cache.clear()
        self._tactic_pages.cache_clear()

    @staticmethod
    def where(
        origin="All", pg=None, family=None, route_id=None, terminus="All", tactic=None
    ):
        clauses, args = [], []
        if tactic is not None:
            clauses.append(
                "EXISTS (SELECT 1 FROM tactic_windows w WHERE w.event = events.id AND w.entry = ?)"
            )
            args.append(tactic)
        if origin == "In-stock":
            clauses.append("origin IN ('stock', 'protected_synthon')")
        elif origin == "Introduced":
            clauses.append("origin = 'introduced'")
        elif origin != "All":
            raise ValueError("unknown PG origin filter")
        termini = {
            "Preserved in target": "preserved",
            "Not preserved in target": "not_preserved",
            "Unavailable": "unavailable",
        }
        if terminus != "All":
            if terminus not in termini:
                raise ValueError("unknown PG terminus filter")
            clauses.append("terminus = ?")
            args.append(termini[terminus])
        for column, value in (("pg", pg), ("family", family), ("route_id", route_id)):
            if value is not None:
                clauses.append(f"{column} = ?")
                args.append(value)
        return (" WHERE " + " AND ".join(clauses) if clauses else ""), args

    def ensure_tactics(self):
        """Tactic windows are prepared with the persistent browsing index."""

    def tactic_lengths(self, *, terminus="All"):
        where, args = self.where(origin="Introduced", terminus=terminus)
        return [
            r[0]
            for r in self.db.execute(
                "SELECT DISTINCT w.length FROM tactic_windows w JOIN events ON events.id=w.event"
                + where
                + " ORDER BY w.length",
                args,
            )
        ]

    def tactics(
        self,
        *,
        terminus="All",
        length=0,
        minimum_events=1,
        sort_by="event_count",
        descending=True,
        tactic=None,
        offset=None,
        limit=20,
    ):
        self.ensure_tactics()
        if sort_by not in {
            "id",
            "length",
            "pg_type_count",
            "event_count",
            "route_count",
            "window_count",
        }:
            raise ValueError("invalid PG tactic sort")
        where, args = self.where(origin="Introduced", terminus=terminus)
        if length:
            where += " AND w.length = ?"
            args.append(length)
        if tactic is not None:
            where += " AND w.entry = ?"
            args.append(tactic)
        # The origin/terminus index narrows events before fetching their windows.
        # Entry-specific queries retain SQLite's choice of the entry index.
        joins = (
            "FROM events CROSS JOIN tactic_windows w ON events.id = w.event"
            if tactic is None
            else "FROM tactic_windows w JOIN events ON events.id = w.event"
        )
        sql = (
            "SELECT w.entry AS id, w.length AS length, COUNT(DISTINCT events.pg) AS pg_type_count, "
            "COUNT(DISTINCT events.id) AS event_count, COUNT(DISTINCT events.route_id) AS route_count, "
            "COUNT(*) AS window_count "
            + joins
            + where
            + " GROUP BY w.entry, w.length HAVING COUNT(DISTINCT events.id) >= ?"
        )
        args.append(max(1, int(minimum_events)))
        order = f" ORDER BY {sort_by} {'DESC' if descending else 'ASC'}, id ASC"
        if offset is None:
            return [dict(r) for r in self.db.execute(sql + order, args)]
        if offset < 0 or not 1 <= limit <= 200:
            raise ValueError("invalid PG page bounds")
        page = self._tactic_pages(sql, tuple(args), order, offset, limit)
        # Callers may decorate rows; keep the cached scalar page detached.
        return BrowsePage(
            tuple(dict(row) for row in page.rows), page.total, offset, limit
        )

    def _tactic_page(self, sql, args, order, offset, limit):
        rows = [
            dict(r)
            for r in self.db.execute(
                "SELECT grouped.*,COUNT(*) OVER() AS page_total FROM ("
                + sql
                + ") grouped"
                + order
                + " LIMIT ? OFFSET ?",
                (*args, limit, offset),
            )
        ]
        total = (
            rows[0]["page_total"]
            if rows
            else (
                self.db.execute("SELECT COUNT(*) FROM (" + sql + ")", args).fetchone()[
                    0
                ]
                if offset
                else 0
            )
        )
        for row in rows:
            del row["page_total"]
        return BrowsePage(tuple(rows), total, offset, limit)

    def tactic_types(self, tactic, *, terminus="All"):
        self.ensure_tactics()
        where, args = self.where(origin="Introduced", terminus=terminus)
        rows = [
            dict(r)
            for r in self.db.execute(
                "SELECT events.pg AS id, COUNT(DISTINCT events.id) AS event_count, "
                "COUNT(DISTINCT events.route_id) AS route_count, COUNT(*) AS window_count "
                "FROM tactic_windows w JOIN events ON events.id = w.event"
                + where
                + " AND w.entry = ? GROUP BY events.pg ORDER BY event_count DESC, events.pg",
                [*args, tactic],
            )
        ]
        total = sum(r["event_count"] for r in rows)
        return [
            {**r, "event_share": f"{100 * r['event_count'] / total:.1f}%"} for r in rows
        ]

    def tactic_rules(self, tactic, *, terminus="All"):
        where, args = self.where(origin="Introduced", terminus=terminus)
        row = self.db.execute(
            "SELECT w.payload FROM tactic_windows w JOIN events ON events.id = w.event"
            + where
            + " AND w.entry = ? ORDER BY w.id LIMIT 1",
            [*args, tactic],
        ).fetchone()
        if row is None:
            return []
        return rule_depictions(
            [
                (f"Rule {i + 1}", self.library.get_interval_step(key).rule_smarts)
                for i, key in enumerate(json.loads(row[0])["step_occurrence_ids"])
            ]
        )

    def grouped(self, column, **filters):
        if column not in {"pg", "family", "route_id"}:
            raise ValueError("invalid PG grouping")
        where, args = self.where(**filters)
        return [
            dict(r)
            for r in self.db.execute(
                f"SELECT {column} AS id, COUNT(*) AS occurrence_count, "
                "COUNT(DISTINCT route_id) AS route_count, COUNT(DISTINCT family) AS family_count, "
                "GROUP_CONCAT(DISTINCT origin) AS origins, "
                "GROUP_CONCAT(DISTINCT functional_group) AS functional_groups "
                f"FROM events{where} GROUP BY {column} ORDER BY route_count DESC, id",
                args,
            )
        ]

    @staticmethod
    def page(rows, offset=0, limit=20):
        if offset < 0 or not 1 <= limit <= 200:
            raise ValueError("invalid PG page bounds")
        return BrowsePage(
            tuple(rows[offset : offset + limit]), len(rows), offset, limit
        )

    def routes(
        self,
        *,
        search="",
        offset=0,
        sort_by="route_id",
        descending=False,
        protections_detected=True,
        **filters,
    ):
        rows = []
        # Absence is relative to every recorded event, never to an origin or
        # terminus filter. Only the library's recorded corpus roster is eligible.
        grouped = (
            self.grouped("route_id", **filters)
            if protections_detected
            else (
                {"id": rid, "occurrence_count": 0, "family_count": 0}
                for rid in self.no_pg_route_ids
            )
        )
        for row in grouped:
            rid = row["id"]
            target = self.targets[rid]
            if not matches_route_search(rid, target, search):
                continue
            rows.append(
                {
                    **row,
                    "route_id": rid,
                    "target": target,
                    "dataset_id": self.corpus["dataset_id"],
                    "source_identity": self.corpus["source_identity"],
                    "reaction_count": self.reaction_counts[rid],
                }
            )
        return self.page(sort_route_rows(rows, sort_by, descending), offset)

    def events(self, **filters):
        where, args = self.where(**filters)
        return [
            dict(r)
            for r in self.db.execute(
                f"SELECT * FROM events{where} ORDER BY pg, origin, id", args
            )
        ]

    def inspect(self, event_id, *, aam=True, layered=True):
        event = self.library.get_event_occurrence(event_id)
        return self.inspect_route(
            event.route.route_id, event=event, aam=aam, layered=layered
        )

    def inspect_route(self, route_id, *, event=None, aam=True, layered=True):
        root = self.source.route(route_id)
        key = (
            route_id,
            event.occurrence_id if event else None,
            aam,
            layered,
            GUI_LAYERED_FLOW,
        )
        preview = self.cache.get(key)
        if preview is None:
            with depiction_settings(aam=aam):
                svg = get_route_svg_from_json(
                    {route_id: root},
                    route_id,
                    pg_strategy_occurrence=event.to_dict() if event else None,
                    compact=True,
                    layered=layered,
                    layered_flow=GUI_LAYERED_FLOW,
                    box_solid=False,
                )
            preview = {"svg": svg, "reactions": reaction_rows(root, [])}
            labels = (root.get("metadata") or {}).get("route_merge", {}).get("labels")
            if labels:
                preview["source_labels"] = labels
            self.cache[key] = preview
            while len(self.cache) > 16:
                self.cache.popitem(last=False)
        self.cache.move_to_end(key)
        return preview

    def evidence(self, event_id):
        event = self.library.get_event_occurrence(event_id)
        steps = [
            self.library.get_interval_step(key)
            for key in event.interval_step_occurrence_ids
        ]
        if self.library.manifest.library_format_version == 5:
            from route_inspector.gui.pg_index import event_ngrams

            grams = event_ngrams(self.db, event, steps)
        else:
            grams = [
                json.loads(row[0])
                for row in self.db.execute(
                    # Sorting by the global occurrence ID makes SQLite prefer the
                    # kind index and scan every window. The final sort below also
                    # includes unigrams and supplies the required stable order.
                    "SELECT payload FROM grams WHERE event = ?",
                    (event_id,),
                )
            ]
        # Unigrams already have exact identities and event-qualified provenance
        # in the interval-step catalog; reuse these rather than extracting rules.
        for step in steps:
            entry = self.library.entry_summary_for_occurrence(step.occurrence_id)
            grams.append(
                {
                    "occurrence_id": step.occurrence_id,
                    "entry_id": entry["entry_id"],
                    "event_occurrence_id": step.event_occurrence_id,
                    "route": step.route.to_dict(),
                    "focal_pg_type": step.focal_pg_type,
                    "active_pg_contexts": [list(step.active_pg_types)],
                    "step_occurrence_ids": [step.occurrence_id],
                    "reaction_node_paths": [list(step.reaction_node_path)],
                    "start_index": step.step_index,
                    "length": 1,
                    "route_count": entry["route_count"],
                    "occurrence_count": entry["occurrence_count"],
                }
            )
        grams.sort(key=lambda r: (r["length"], r["start_index"], r["occurrence_id"]))
        return event, steps, grams


def rule_depictions(rules):
    result = []
    for label, rule in rules:
        if rule:
            try:
                result.append({"label": label, "svg": render_composite(rule)})
            except Exception as exc:
                result.append(
                    {"label": label, "error": f"Rule depiction unavailable: {exc}"}
                )
    return result


def fetch_pg(service, state):
    browser, selection = service.pg, state.pg
    protections_detected = (
        state.pg_mode != "Route-wise" or selection.protections_detected
    )
    filters = {"origin": selection.origin, "terminus": selection.terminus}
    result = {
        "preview": {},
        "types": [],
        "families": [],
        "events": [],
        "steps": [],
        "grams": [],
    }
    if state.pg_mode == "Tactic-wise":
        filters["origin"] = "Introduced"
        result["tactic_lengths"] = browser.tactic_lengths(terminus=selection.terminus)
        result["tactic_page"] = browser.tactics(
            terminus=selection.terminus,
            length=selection.tactic_length,
            minimum_events=selection.tactic_minimum_events,
            sort_by=selection.tactic_sort,
            descending=selection.tactic_descending,
            offset=selection.tactic_offset,
        )
        result["tactics"] = list(result["tactic_page"].rows)
        selected_tactics = (
            browser.tactics(
                terminus=selection.terminus,
                length=selection.tactic_length,
                minimum_events=selection.tactic_minimum_events,
                tactic=selection.tactic_id,
            )
            if selection.tactic_id is not None
            else []
        )
        result["multistep_ngrams_available"] = (
            browser.library.manifest.library_format_version >= 2
        )
        if not selected_tactics:
            result["routes"] = browser.page([])
            return result
        filters["tactic"] = selection.tactic_id
        result["tactic_types"] = browser.tactic_types(
            selection.tactic_id, terminus=selection.terminus
        )
        result["tactic_rules"] = browser.tactic_rules(
            selection.tactic_id, terminus=selection.terminus
        )
        if selection.pg_type:
            filters["pg"] = selection.pg_type
            result["families"] = browser.grouped("family", **filters)
        if selection.family:
            filters["family"] = selection.family
    if state.pg_mode == "PG-wise":
        result["types"] = browser.grouped("pg", **filters)
        if selection.pg_type:
            filters["pg"] = selection.pg_type
            result["families"] = browser.grouped("family", **filters)
        if selection.family:
            filters["family"] = selection.family
    result["routes"] = (
        service._route_targets(
            browser.routes(
                **filters,
                protections_detected=protections_detected,
                search=selection.search,
                offset=selection.route_offset,
                sort_by=selection.sort_by,
                descending=selection.descending,
            )
        )
        if state.pg_mode == "Route-wise" or selection.family
        else browser.page([])
    )
    if not protections_detected:
        if selection.route_id in browser.no_pg_route_ids:
            try:
                result["preview"] = browser.inspect_route(
                    selection.route_id, aam=state.aam, layered=state.layered
                )
            except Exception as exc:
                result["preview"] = {"message": f"Route drawing unavailable: {exc}"}
        return result
    if selection.route_id:
        result["events"] = browser.events(**filters, route_id=selection.route_id)
        valid = {r["id"] for r in result["events"]}
        selected = (
            selection.event_id
            if selection.event_id in valid
            else next(iter(result["events"]), {}).get("id")
        )
        result["active_event"] = selected
        if selected:
            event, steps, grams = browser.evidence(selected)
            if state.pg_mode == "Tactic-wise":
                grams = [g for g in grams if g["entry_id"] == selection.tactic_id]
                support = selected_tactics[0]
                grams = [
                    {
                        **g,
                        "route_count": support["route_count"],
                        "occurrence_count": support["window_count"],
                    }
                    for g in grams
                ]
                allowed_steps = {key for g in grams for key in g["step_occurrence_ids"]}
                if selection.step_id not in allowed_steps:
                    selection.step_id = None
                if not selection.step_id and selection.ngram_id not in {
                    g["occurrence_id"] for g in grams
                }:
                    selection.ngram_id = grams[0]["occurrence_id"] if grams else None
                result["active_ngram"] = selection.ngram_id
            result["event_family"] = browser.library.event_entry_id_for_occurrence(
                selected
            )
            result.update(
                event=event.to_dict(),
                steps=[s.to_dict() for s in steps],
                grams=grams,
                multistep_ngrams_available=browser.library.manifest.library_format_version
                >= 2,
            )
            result["endpoints"] = rule_depictions(
                [
                    (
                        "Incorporation"
                        if event.source_type == "protected_synthon"
                        else "Protection",
                        event.protection_rule_smarts,
                    ),
                    ("Deprotection", event.deprotection_rule_smarts),
                ]
            )
            try:
                result["preview"] = browser.inspect(
                    selected, aam=state.aam, layered=state.layered
                )
            except Exception as exc:
                result["preview"] = {"message": f"Route drawing unavailable: {exc}"}
            rules = []
            if selection.step_id:
                rules = [
                    (f"Interval step {i + 1}", s.rule_smarts)
                    for i, s in enumerate(steps)
                    if s.occurrence_id == selection.step_id
                ]
            if selection.ngram_id:
                gram = next(
                    (g for g in grams if g["occurrence_id"] == selection.ngram_id), None
                )
                if gram:
                    rules = [
                        (f"Interval step {i + 1}", s.rule_smarts)
                        for i, s in enumerate(steps)
                        if s.occurrence_id in gram["step_occurrence_ids"]
                    ]
                    result["span"] = (
                        f"Selected n-gram: interval steps {gram['start_index'] + 1}–{gram['start_index'] + gram['length']}"
                    )
            result["selected_rules"] = rule_depictions(rules)
    return result
