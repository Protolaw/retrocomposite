"""One-thread-owned read-only library session and bounded rendering cache."""

from __future__ import annotations

import json
from collections import OrderedDict
from pathlib import Path
from xml.etree import ElementTree as ET

from route_inspector.composite_rules.browsing import CompositeBrowser
from route_inspector.composite_rules.library import CompositeDecompositionLibrary
from route_inspector.gui.datasets import (
    corpus_ids,
    dataset_bindings,
    dataset_paths,
    discover_datasets,
)
from route_inspector.gui.inspection import (
    GUI_LAYERED_FLOW,
    reaction_rows,
    render_composite,
    render_reaction,
    render_route,
    render_tactic,
)
from route_inspector.gui.overlap import OverlapPreparation
from route_inspector.gui.pg import PGBrowser
from route_inspector.gui.sources import RouteSource
from route_inspector.gui.svg import composite_lhs_fragment
from route_inspector.gui.thumbnails import target_thumbnail, unmapped_smiles
from route_inspector.gui.verification import (
    AuditRequired,
    artifact_snapshot,
    capture_snapshots,
    load_verified,
)
from route_inspector.reference_library import ReferenceTacticLibrary
from route_inspector.reference_library.browsing import BrowsePage, LibraryBrowser
from route_inspector.reference_library.models import ReferenceRouteKey


class ExplorerService:
    def __init__(self, workspace: Path):
        self.workspace = workspace
        self.output = workspace / "outputs" / "gui"
        self.library = None
        self.pg = None
        self.browser = None
        self.sources = {}
        self.query = None
        self.composites = None
        self.composite_browser = None
        self.composite_lhs_context = None
        self.activator_contexts = {}
        self.activator_indexes = {}
        self.composite_status = {"available": False, "reason": "No companion loaded"}
        self._svg_cache = OrderedDict()
        self._composite_svg_cache = OrderedDict()
        self._target_labels = {}
        self.overlap = OverlapPreparation(workspace)

    def path(self, value: str) -> Path:
        path = Path(value).expanduser()
        return (path if path.is_absolute() else self.workspace / path).resolve(
            strict=True
        )

    def open_library(self, value: str, verification: str):
        # Do not destroy a working session if a replacement fails to load.
        library = load_verified(
            ReferenceTacticLibrary.load,
            self.path(value),
            self.output / "verification",
            verification,
        )
        self.close()
        self.library = library
        self.browser = LibraryBrowser(library)
        self.activator_contexts["tactics"] = (
            "tactics",
            str(library.directory),
            json.dumps(artifact_snapshot(library.directory), sort_keys=True),
        )
        self.sources = {}
        self._svg_cache.clear()
        self._target_labels.clear()
        self.verification = (
            "full" if verification in {"cached", "ready", "snapshot"} else verification
        )
        return {
            "library_id": library.library_id,
            "statistics": dict(library.manifest.statistics),
            "profile": library.processing_profile.to_dict(),
            "corpora": [dict(c) for c in library.manifest.reference_corpora],
        }

    def close(self):
        for index in self.activator_indexes.values():
            index.close()
        self.activator_indexes.clear()
        self.activator_contexts.clear()
        if self.pg is not None:
            self.pg.close()
            self.pg = None
        self.overlap.close()
        self.overlap = OverlapPreparation(self.workspace)
        if self.composites is not None:
            self.composites.close()
            self.composites = None
        self.composite_browser = None
        self.composite_lhs_context = None
        self.composite_status = {"available": False, "reason": "No companion loaded"}
        self._composite_svg_cache.clear()
        if self.library is not None:
            self.library.close()
            self.library = None
        self.sources.clear()
        self.query = None
        self._svg_cache.clear()
        self._target_labels.clear()

    def datasets(self):
        return discover_datasets(self.workspace)

    def open_dataset(
        self,
        dataset: str,
        verification="cached",
        *,
        unavailable=None,
        expected_bindings=None,
    ):
        with capture_snapshots() as snapshots:
            info = self._open_dataset(
                dataset,
                verification,
                unavailable=unavailable,
                expected_bindings=expected_bindings,
            )
        info["audit_observations"] = [
            snapshots[str(library.directory.resolve())]
            for library in (
                self.library,
                self.pg.library if self.pg else None,
                self.composites,
            )
            if library is not None and str(library.directory.resolve()) in snapshots
        ]
        return info

    def _open_dataset(self, dataset, verification, *, unavailable, expected_bindings):
        """Swap sessions only after the corpus and original source both verify."""
        accepted_corpora = corpus_ids(dataset)
        bindings = dataset_bindings(self.workspace, dataset)
        unavailable = unavailable or {}
        if expected_bindings is not None and expected_bindings != {
            k: str(v.relative_to(self.workspace)) for k, v in bindings.items()
        }:
            raise AuditRequired("Dataset bindings changed; load it again")
        source = bindings["source"]
        candidate = ExplorerService(self.workspace)
        info = {
            "profile": {},
            "statistics": {},
            "corpora": [],
            "dataset_id": dataset,
            "source_path": str(source.relative_to(self.workspace)),
        }
        try:
            try:
                if "reference" in unavailable:
                    raise ValueError(unavailable["reference"])
                library, _ = dataset_paths(self.workspace, dataset)
                info.update(candidate.open_library(str(library), verification))
                corpora = info["corpora"]
                if (
                    len(corpora) != 1
                    or corpora[0]["dataset_id"] not in accepted_corpora
                ):
                    raise ValueError(
                        f"Reference library is not the selected {dataset} corpus"
                    )
                matched = candidate.attach_source(str(source))
                if matched != [corpora[0]["dataset_id"]]:
                    raise ValueError("Reference library and source corpus do not match")
                info.update(
                    corpus_id=corpora[0]["dataset_id"],
                    route_count=(
                        len(corpora[0]["route_ids"])
                        if "route_ids" in corpora[0]
                        else candidate.browser.routes(limit=1).total
                    ),
                    library_path=str(library.relative_to(self.workspace)),
                )
                info["tactics"] = {"available": True}
            except AuditRequired:
                raise
            except Exception as exc:
                candidate.close()
                candidate.browser = None
                info.update(profile={}, statistics={}, corpora=[])
                info["tactics"] = {"available": False, "reason": str(exc)}
            pg_directory = bindings["pg"]
            try:
                if "pg" in unavailable:
                    raise ValueError(unavailable["pg"])
                if not (pg_directory / "manifest.json").is_file():
                    raise ValueError(
                        f"No PG library found: {pg_directory.relative_to(self.workspace)}"
                    )
                candidate.pg = PGBrowser(
                    pg_directory,
                    source,
                    dataset,
                    verification,
                    cache_root=self.output,
                    source=next(iter(candidate.sources.values()), None),
                )
                pg = candidate.pg
                info["pg"] = {
                    "available": True,
                    "library_id": pg.library.library_id,
                    "statistics": dict(pg.library.manifest.statistics),
                    "profile": dict(pg.library.manifest.processing_profile),
                }
                candidate.sources[
                    (pg.corpus["dataset_id"], pg.corpus["source_identity"])
                ] = pg.source
                if not info["tactics"]["available"]:
                    info.update(
                        corpus_id=pg.corpus["dataset_id"],
                        route_count=len(pg.source.route_ids),
                    )
            except AuditRequired:
                raise
            except Exception as exc:
                info["pg"] = {"available": False, "reason": str(exc)}
            if not info["tactics"]["available"] and not info["pg"]["available"]:
                raise ValueError(
                    info["tactics"]["reason"] + "; " + info["pg"]["reason"]
                )
            companion = bindings["composites"]
            info["composites"] = (
                {"available": False, "reason": unavailable["composites"]}
                if "composites" in unavailable
                else (
                    candidate.open_composites(companion, verification=verification)
                    if info["tactics"]["available"]
                    else candidate.composite_status
                )
            )
        except Exception:
            candidate.close()
            raise
        self.close()
        self.library, self.browser, self.pg = (
            candidate.library,
            candidate.browser,
            candidate.pg,
        )
        self.sources, self.verification = (
            candidate.sources,
            candidate.verification
            if candidate.library
            else (
                "full"
                if verification in {"cached", "ready", "snapshot"}
                else verification
            ),
        )
        self.composites = candidate.composites
        self.composite_browser = candidate.composite_browser
        self.composite_status = candidate.composite_status
        self.composite_lhs_context = candidate.composite_lhs_context
        self.activator_contexts = candidate.activator_contexts
        return info

    def open_composites(self, directory, verification="cached"):
        """An optional companion must not make the Reference library unusable."""
        previous = self.activator_indexes.pop("composites", None)
        if previous is not None:
            previous.close()
        self.activator_contexts.pop("composites", None)
        self.overlap.close()
        self.overlap = OverlapPreparation(self.workspace)
        candidate = None
        if self.composites is not None:
            self.composites.close()
        self.composites = self.composite_browser = None
        self.composite_lhs_context = None
        self._composite_svg_cache.clear()
        try:
            if not (directory / "manifest.json").is_file():
                raise ValueError("No composite companion found for this dataset")
            candidate = load_verified(
                CompositeDecompositionLibrary.load,
                directory,
                self.output / "verification",
                verification,
            )
            candidate.assert_reference_library(self.library)
            if candidate.manifest.source_routes_sha256 not in {
                source.digest for source in self.sources.values()
            }:
                raise ValueError(
                    "Composite source-route digest does not match the verified source"
                )
            browser = CompositeBrowser(candidate, self.library)
        except AuditRequired:
            if candidate is not None:
                candidate.close()
            raise
        except Exception as exc:
            if candidate is not None:
                candidate.close()
            self.composite_status = {"available": False, "reason": str(exc)}
        else:
            self.composites, self.composite_browser = candidate, browser
            self.activator_contexts["composites"] = (
                "composites",
                str(candidate.directory),
                json.dumps(artifact_snapshot(candidate.directory), sort_keys=True),
            )
            self.composite_lhs_context = (
                str(self.library.directory),
                str(candidate.directory),
                json.dumps(
                    {
                        "reference": artifact_snapshot(self.library.directory),
                        "composites": artifact_snapshot(candidate.directory),
                    },
                    sort_keys=True,
                ),
            )
            self.composite_status = {
                "available": True,
                "reason": "Certified companion and source verified",
                "library_id": candidate.library_id,
                "statistics": dict(candidate.manifest.statistics),
                "construction_profile": dict(candidate.manifest.construction_profile),
            }
        return dict(self.composite_status)

    def _require_composites(self):
        if self.composite_browser is None:
            raise ValueError(self.composite_status["reason"])
        return self.composite_browser

    def composite_entries(self, **kwargs):
        kwargs.setdefault("activator_index", self.activator_indexes.get("composites"))
        if kwargs.get("overlap", "all") != "all":
            if self.overlap_status()["state"] != "completed":
                raise ValueError("Single-step overlap is not ready")
            kwargs["matched_ids"] = self.overlap.index.matched_ids
        return self._require_composites().entries(**kwargs)

    def prepare_overlap(self):
        self._require_composites()
        return self.overlap.start(
            self.library, self.composites, next(iter(self.sources.values()))
        )

    def retry_overlap(self):
        self._require_composites()
        return self.overlap.retry(
            self.library, self.composites, next(iter(self.sources.values()))
        )

    def overlap_status(self):
        if not self.sources:
            return dict(self.overlap.status)
        return self.overlap.poll(next(iter(self.sources.values())))

    def overlap_evidence(self, composite_id, *, offset=0, selected=None, aam=True):
        if self.overlap_status()["state"] != "completed":
            return None
        page, route_count = self.overlap.index.evidence(composite_id, offset=offset)
        step = (
            self.overlap.index.step(composite_id, selected)
            if selected
            else (page.rows[0] if page.rows else None)
        )
        result = {"page": page, "route_count": route_count, "selected": step}
        if step:
            try:
                result["svg"] = render_composite(step["rule_smarts"])
            except Exception as exc:
                result["error"] = f"Single-step depiction unavailable: {exc}"
            try:
                result["reaction_svg"] = render_reaction(
                    step["reaction_smiles"], aam=aam
                )
            except Exception as exc:
                result["reaction_error"] = (
                    f"Source reaction depiction unavailable: {exc}"
                )
        return result

    def composite_entry(self, composite_id):
        self._require_composites()
        entry = self.composites.get_entry(composite_id)
        cached = self._composite_svg_cache.get(composite_id)
        if cached is None:
            try:
                cached = {"svg": render_composite(entry.composite_rule), "error": None}
            except Exception as exc:
                cached = {"svg": "", "error": f"Composite depiction unavailable: {exc}"}
            self._composite_svg_cache[composite_id] = cached
            while len(self._composite_svg_cache) > 16:
                self._composite_svg_cache.popitem(last=False)
        else:
            self._composite_svg_cache.move_to_end(composite_id)
        if "lhs_svg" not in cached:
            try:
                cached["lhs_svg"] = (
                    composite_lhs_fragment(cached["svg"]) if cached["svg"] else ""
                )
                cached["lhs_error"] = cached["error"]
            except (ValueError, TypeError, ET.ParseError) as exc:
                cached["lhs_svg"] = ""
                cached["lhs_error"] = f"LHS fragment unavailable: {exc}"
        return {"entry": entry.to_dict(), **cached}

    def composite_same_lhs(self, composite_id, *, index, offset=0, limit=20):
        return self._require_composites().same_lhs(
            composite_id, index=index, offset=offset, limit=limit
        )

    def composite_same_lhs_destination(self, composite_id, route=None):
        link = self._require_composites().same_lhs_destination(composite_id, route)
        return self.composite_link(link["reference_occurrence_id"])

    def composite_certified_depiction(self, rule):
        """Cache the exact occurrence rule separately from family representatives."""
        key = ("certified", rule)
        cached = self._composite_svg_cache.get(key)
        if cached is None:
            try:
                cached = {"svg": render_composite(rule), "error": None}
            except Exception as exc:
                cached = {"svg": "", "error": f"Composite depiction unavailable: {exc}"}
            self._composite_svg_cache[key] = cached
            while len(self._composite_svg_cache) > 16:
                self._composite_svg_cache.popitem(last=False)
        else:
            self._composite_svg_cache.move_to_end(key)
        return cached

    def composite_routes(self, composite_id, **kwargs):
        page = self._require_composites().routes(composite_id, **kwargs)
        return self._route_targets(page)

    def composite_tactics(self, composite_id, **kwargs):
        return self._require_composites().tactics(composite_id, **kwargs)

    def composite_occurrences(self, composite_id, *, route=None, **kwargs):
        from route_inspector.reference_library.browsing import occurrence_summary

        browser = self._require_composites()
        page = browser.links(
            composite_id,
            route=ReferenceRouteKey.from_dict(route) if route else None,
            **kwargs,
        )
        rows = []
        for link in page.rows:
            occurrence = browser.verified_occurrence(link, self.library)
            entry = self.library.get_entry(link["tactic_entry_id"])
            rows.append(
                {**occurrence_summary(occurrence, entry), "composite_link": link}
            )
        return BrowsePage(tuple(rows), page.total, page.offset, page.limit)

    def composite_link(self, occurrence_id):
        if self.composites is None:
            return None
        link = self.composites.link_for_occurrence(occurrence_id)
        if link is not None:
            self.composite_browser.verified_occurrence(link, self.library)
            return {
                **link.to_dict(),
                "certified_rule": self.composites.certified_rule(link),
            }
        return None

    def attach_source(self, value: str):
        if self.library is None:
            raise ValueError("open a library first")
        source = RouteSource(self.path(value))
        matched = [
            c
            for c in self.library.manifest.reference_corpora
            if c.get("input_sha256", str(c["source_identity"]).removeprefix("sha256:"))
            == source.digest
        ]
        if not matched:
            raise ValueError(
                "source SHA-256 does not match any corpus recorded by this library"
            )
        for corpus in matched:
            # Check roster completeness without loading route payloads.
            expected = {str(r) for r in corpus.get("route_ids", ())}
            actual = set(source.route_ids)
            if expected - actual:
                raise ValueError(
                    "verified source does not contain all recorded route IDs"
                )
            self.sources[(corpus["dataset_id"], corpus["source_identity"])] = source
            targets = source.targets()
            self.browser.set_route_targets(
                corpus["dataset_id"],
                corpus["source_identity"],
                targets,
                reaction_counts=source.reaction_counts(),
            )
        return [c["dataset_id"] for c in matched]

    def open_query(self, value: str, expected_digest=None):
        candidate = RouteSource(self.path(value), expected_digest=expected_digest)
        self.query = candidate
        self._target_labels.clear()
        return self.query.page()

    def config_path(self, value: str):
        from route_inspector.infrastructure.paths import resolve_existing_path

        candidate = Path(value).expanduser()
        candidate = candidate if candidate.is_absolute() else self.workspace / candidate
        return (
            candidate.resolve() if candidate.is_file() else resolve_existing_path(value)
        )

    def routes(self, **kwargs):
        page = self.browser.routes(target_search_text=self._target_label, **kwargs)
        return self._route_targets(page)

    def _target_label(self, target):
        # Compact navigation metadata, not route payloads or scientific identity.
        # Keep labels for this session so searching large rosters does not parse
        # every molecule again on each keystroke/page. Cleared on dataset/query load.
        if target not in self._target_labels:
            self._target_labels[target] = unmapped_smiles(target)
        return self._target_labels[target]

    def _route_targets(self, page):
        rows = [dict(row) for row in page.rows]
        for key, source in self.sources.items():
            selected = [
                r for r in rows if (r["dataset_id"], r["source_identity"]) == key
            ]
            targets = source.targets([r["route_id"] for r in selected])
            for row in selected:
                row["target"] = targets.get(row["route_id"], row.get("target", ""))
        for row in rows:
            row["target_unmapped"] = self._target_label(row.get("target", ""))
            row["target_image"] = target_thumbnail(row["target_unmapped"])
        return BrowsePage(tuple(rows), page.total, page.offset, page.limit)

    def query_routes(self, **kwargs):
        if self.query is None:
            raise ValueError("open a prepared route JSON first")
        page = self.query.page(target_search_text=self._target_label, **kwargs)
        rows = [
            {
                **row,
                "target_unmapped": self._target_label(row["target"]),
                "target_image": target_thumbnail(self._target_label(row["target"])),
            }
            for row in page.rows
        ]
        return BrowsePage(tuple(rows), page.total, page.offset, page.limit)

    def related(self, entry_id, *, index, **kwargs):
        """Expose bounded exact relationships to non-UI service callers."""
        return self.browser.related(entry_id, index=index, **kwargs)

    def related_destination(self, entry_id, preferred_route=None):
        if (
            preferred_route
            and self.occurrences(route=preferred_route, entry_id=entry_id, limit=1).rows
        ):
            return preferred_route
        rows = self.routes(entry_id=entry_id, limit=1).rows
        return (
            {k: rows[0][k] for k in ("dataset_id", "source_identity", "route_id")}
            if rows
            else None
        )

    def entries(self, **kwargs):
        kwargs.setdefault("activator_index", self.activator_indexes.get("tactics"))
        return self.browser.entries(**kwargs)

    def attach_activator_index(self, context, path, identity):
        """Open an independent read-only handle on the browsing thread."""
        from route_inspector.rules.activators.index import ActivatorIndex

        scope = context[0]
        if self.activator_contexts.get(scope) != context:
            return False
        index = ActivatorIndex(path)
        try:
            if not index.valid(identity):
                raise ValueError(
                    "Activator cache no longer matches its completed build"
                )
        except Exception:
            index.close()
            raise
        previous = self.activator_indexes.get(scope)
        self.activator_indexes[scope] = index
        if previous is not None:
            previous.close()
        return True

    def activator_status(self, scope, kind=None, entry_id=None):
        index = self.activator_indexes.get(scope)
        return {
            "ready": index is not None,
            "counts": index.counts(kind) if index else {},
            "detail": index.detail(entry_id, kind) if index and entry_id else None,
        }

    def occurrences(self, route=None, **kwargs):
        key = ReferenceRouteKey.from_dict(route) if route else None
        return self.browser.occurrences(route=key, **kwargs)

    def entry(self, entry_id):
        entry = self.library.get_entry(entry_id)
        occurrence = self.library.get_occurrence(entry.representative_occurrence_id)
        try:
            svg = render_tactic(occurrence)
            error = None
        except Exception as exc:
            svg, error = "", f"Rule depiction unavailable: {exc}"
        return {"entry": entry.to_dict(), "svg": svg, "error": error}

    def inspect(
        self, route: dict, occurrence_id=None, skipped=False, *, aam=True, layered=True
    ):
        key = ReferenceRouteKey.from_dict(route)
        source = self.sources.get((key.dataset_id, key.source_identity))
        if source is None:
            return {
                "svg": "",
                "reactions": [],
                "message": "Attach the hash-matched source JSON to draw this route.",
            }
        root = source.route(key.route_id)
        occurrences = list(self.library.iter_occurrences(**key.to_dict()))
        occurrence = None
        if occurrence_id:
            occurrence = self.library.get_occurrence(occurrence_id)
            if occurrence.route != key:
                raise ValueError(
                    "selected occurrence belongs to a different source route"
                )
        cache_key = (
            self.library.library_id,
            source.digest,
            key,
            occurrence_id,
            bool(skipped),
            bool(aam),
            bool(layered),
            GUI_LAYERED_FLOW,
        )
        svg = self._svg_cache.get(cache_key)
        if svg is None:
            svg = render_route(
                root, key.route_id, occurrence, skipped, aam=aam, layered=layered
            )
            self._svg_cache[cache_key] = svg
            while len(self._svg_cache) > 16:
                self._svg_cache.popitem(last=False)
        else:
            self._svg_cache.move_to_end(cache_key)
        return {
            "svg": svg,
            "reactions": reaction_rows(root, occurrences),
            "message": None,
            **(
                {"source_labels": root["metadata"]["route_merge"]["labels"]}
                if (root.get("metadata") or {}).get("route_merge", {}).get("labels")
                else {}
            ),
        }

    def inspect_query(
        self,
        route_id,
        occurrences=(),
        selected=None,
        skipped=False,
        *,
        aam=True,
        layered=True,
    ):
        from route_inspector.reference_library.models import TacticOccurrence

        root = self.query.route(route_id)
        parsed = [TacticOccurrence.from_dict(o) for o in occurrences]
        occurrence = next(
            (o for o in parsed if o.reference_occurrence_id == selected), None
        )
        if any(
            o.route.route_id != str(route_id)
            or o.route.source_identity != f"sha256:{self.query.digest}"
            for o in parsed
        ):
            raise ValueError("query occurrence source identity mismatch")
        return {
            "svg": render_route(
                root, route_id, occurrence, skipped, aam=aam, layered=layered
            ),
            "reactions": reaction_rows(root, parsed),
            "message": None,
        }

    def save_settings(self, values):
        from route_inspector.infrastructure.artifacts import write_json

        self.output.mkdir(parents=True, exist_ok=True)
        write_json(self.output / "settings.json", values)

    def settings(self):
        path = self.output / "settings.json"
        if not path.exists():
            return {}
        try:
            return json.loads(path.read_text())
        except (ValueError, OSError):
            return {}
