"""Workspace-local discovery of prepared route corpora."""

from pathlib import Path

from route_inspector.datasets.bindings import (
    DATASETS as DATASETS,
)
from route_inspector.datasets.bindings import (
    activate_library_revision as activate_library_revision,
)
from route_inspector.datasets.bindings import (
    corpus_ids as corpus_ids,
)
from route_inspector.datasets.bindings import (
    dataset_bindings as dataset_bindings,
)


def dataset_paths(workspace: Path, dataset: str) -> tuple[Path, Path]:
    paths = dataset_bindings(workspace, dataset)
    source, library = paths["source"], paths["reference"]
    if not source.is_file():
        raise ValueError(f"Missing prepared routes: {source.relative_to(workspace)}")
    if not (library / "manifest.json").is_file():
        raise ValueError(
            f"Missing Reference library: {library.relative_to(workspace)}. "
            "Build or copy the complete library here, then refresh datasets."
        )
    return library, source


def discover_datasets(workspace: Path) -> list[dict]:
    """Locate files only; load-time verification establishes scientific identity.

    Defaults use exact folder names; alternate publications require explicit
    local bindings. Discovery never guesses a different extraction profile.
    """
    rows = []
    for dataset in DATASETS:
        try:
            try:
                dataset_paths(workspace, dataset)
            except ValueError:
                paths = dataset_bindings(workspace, dataset)
                source = paths["source"]
                pg = paths["pg"] / "manifest.json"
                if not source.is_file() or not pg.is_file():
                    raise
        except (ValueError, OSError) as exc:
            rows.append(dict(id=dataset, available=False, reason=str(exc)))
        else:
            rows.append(
                dict(id=dataset, available=True, reason="Library and routes found")
            )
    return rows
