"""Lazy, provenance-checked pictures of rejected PG candidate reactions."""

import json
from xml.etree import ElementTree as ET

from route_inspector.gui.inspection import render_route
from route_inspector.protection.recovery.diagnostics import REASON_LABELS, STEP_LABELS
from route_inspector.protection.recovery.trees import at, primary

ET.register_namespace("", "http://www.w3.org/2000/svg")


def reaction_fragment(reaction):
    """A one-step route with every recorded input; no remapping or chemistry."""
    left, _, right = reaction.split(">")
    return {
        "type": "mol",
        "smiles": right,
        "in_stock": False,
        "children": [
            {
                "type": "reaction",
                "smiles": reaction,
                "children": [
                    {"type": "mol", "smiles": text, "in_stock": False, "children": []}
                    for text in left.split(".")
                    if text
                ],
            }
        ]
        if left
        else [],
    }


def preview(reaction, *, aam=True):
    try:
        root = ET.fromstring(
            render_route(reaction_fragment(reaction), "validation", aam=aam)
        )
        # Cropped inputs need not be purchasable, and this product need not be
        # the route target. Replace renderer endpoint captions for this view.
        for node in root.iter():
            if node.text and node.text.strip() in {
                "IN STOCK",
                "NOT IN STOCK",
                "TARGET",
            }:
                node.text = "PRODUCT" if node.text.strip() == "TARGET" else "INPUT"
        return {"svg": ET.tostring(root, encoding="unicode")}
    except Exception as exc:
        return {"message": f"Fragment drawing unavailable: {exc}"}


class ValidationInspector:
    def __init__(self, browser, workspace, library):
        self.browser, self.workspace, self.library = browser, workspace, library
        self.references = None
        self.reconstructed = {}

    def _load_references(self):
        from route_inspector.protection.recovery.evidence import library_input

        source = self.workspace / self.browser.manifest["reference_source"]
        routes, events, _, provenance = library_input(
            self.workspace / self.library, source
        )
        if provenance["library_id"] != self.browser.manifest["library_id"]:
            raise ValueError("Reference PG library does not match this proposal run")
        if provenance["source_sha256"] != self.browser.manifest["source_sha256"]:
            raise ValueError("Reference corpus does not match this proposal run")
        if (
            provenance["processing_profile"]
            != self.browser.manifest["processing_profile"]
        ):
            raise ValueError(
                "Reference processing profile differs from this proposal run"
            )
        self.references = {rid: routes[rid] for rid in events}
        self.events = {
            event["occurrence_id"]: event for rows in events.values() for event in rows
        }

    def reconstruct(self, route_id, candidate):
        """Rebuild intended reactions only; never re-extract or rerun validation."""
        from route_inspector.protection.recovery.generation import (
            construct_candidate,
            sites,
        )

        strategy = candidate["strategy"]
        key = (str(route_id), json.dumps(strategy, sort_keys=True))
        if key in self.reconstructed:
            return self.reconstructed[key]
        if self.references is None:
            self._load_references()
        query = primary(self.browser.route(route_id))
        endpoint = candidate.get("endpoint_reference", {})
        reference = self.references[
            endpoint.get("route_id", candidate["reference_route_id"])
        ]
        event = self.events[endpoint.get("event_id", strategy["reference_event_id"])]
        if endpoint.get("rule_scope") == "functional_class":
            event = {
                **event,
                "protection_rule_smarts": endpoint["protection_rule"],
                "deprotection_rule_smarts": endpoint["deprotection_rule"],
                "endpoint_context_policy": "functional_class",
            }
        paths = tuple(tuple(p) for p in strategy["query_interval_paths"])
        matches, _ = sites(
            query,
            paths,
            reference,
            event,
            limit=self.browser.manifest.get("limits", {}).get("max_site_matches", 256),
            generalized=strategy.get("site_discovery") != "reference_context",
            reverse_rule=self.browser.manifest.get("processing_profile", {})
            .get("rule_extraction_config", {})
            .get("reverse_rule", True),
            site_policy=self.browser.manifest.get("site_matching_policy", "legacy"),
        )
        for site in matches:
            if list(site[0]) != strategy["installation_input_path"]:
                continue
            if (
                sorted(site[1][n] for n in event["protected_atom_ids"])
                != strategy["site_atom_maps"]
            ):
                continue
            _, actual, reactions = construct_candidate(
                query,
                paths,
                site,
                reference,
                {"event": event, "transferable": True},
                evidence_paths=tuple(
                    tuple(p) for p in strategy["matched_window_paths"]
                ),
            )
            # Exact transfer provenance must agree; do not show an approximate
            # reconstruction as the historical intended candidate.
            for field in (
                "reference_atom_transfer",
                "free_input_atom_remapping",
                "query_interval_paths",
            ):
                if json.loads(json.dumps(actual[field])) != strategy[field]:
                    raise ValueError(
                        "Candidate reconstruction differs from recorded atom transfer"
                    )
            self.reconstructed[key] = reactions
            return reactions
        raise ValueError("Recorded candidate site cannot be reconstructed")

    def inspect(self, route_id, check_id):
        record = self.browser.validation_check(route_id, check_id)
        check, stage, candidate = record["check"], record["stage"], record["candidate"]
        strategy = candidate["strategy"]
        result = {
            "route_id": str(route_id),
            "pg_type": strategy["pg_type"],
            "stage": STEP_LABELS.get(stage, STEP_LABELS.get("protected_interval")),
            "reason": REASON_LABELS.get(
                check.get("reason"), check.get("reason", "Unverified")
            ),
            "site_atom_maps": strategy.get("site_atom_maps", []),
            "reference_route_id": candidate.get("reference_route_id"),
            "reference_event_id": strategy.get("reference_event_id"),
            "evidence_reference": candidate.get("reference_window"),
            "endpoint_reference": candidate.get("endpoint_reference"),
            "query_path": check.get(
                "query_reaction_path",
                check.get("query_input_path", check.get("query_output_path", [])),
            ),
            "record": record,
            "outcomes": [],
        }
        reaction = check.get("reaction_smiles")
        try:
            query = primary(self.browser.route(route_id))
            if not reaction:
                if stage == "post_deprotection":
                    reaction = at(query, check["query_reaction_path"])["smiles"]
                else:
                    reactions = self.reconstruct(route_id, candidate)
                    reaction = (
                        reactions["protected_steps"][
                            tuple(check["query_reaction_path"])
                        ]
                        if stage in {"protected_interval", "protected_extension"}
                        else reactions[stage]
                    )
                result["reconstructed"] = True
            result["reaction_smiles"] = reaction
            result["expected"] = preview(reaction)
        except Exception as exc:
            result["expected"] = {"message": f"Expected fragment unavailable: {exc}"}
        if stage in {"protected_interval", "protected_extension", "post_deprotection"}:
            try:
                recorded = at(
                    primary(self.browser.route(route_id)), check["query_reaction_path"]
                )["smiles"]
                result["query_context"] = preview(recorded)
            except (KeyError, IndexError, TypeError):
                result["query_context"] = {
                    "message": "Recorded query context is unavailable at this path."
                }
        for outcome in check.get("outcomes", []):
            mapped_product = outcome.get("mapped_product_smiles")
            product = mapped_product or ".".join(outcome["product_smiles"])
            if reaction:
                replayed = reaction.split(">")[0] + ">>" + product
                drawing = preview(replayed, aam=bool(mapped_product))
            else:
                drawing = preview(">>" + product, aam=bool(mapped_product))
            result["outcomes"].append(
                {
                    "preview": drawing,
                    "mapped": bool(mapped_product),
                    "product_smiles": product,
                    "attachment_site_atom_maps": outcome.get(
                        "attachment_site_atom_maps"
                    ),
                    "reactant_pattern_molecule_indices": outcome.get(
                        "reactant_pattern_molecule_indices"
                    ),
                }
            )
        return result
