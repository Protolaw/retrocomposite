"""Lossless offline identity regrouping of already-certified companions.

No extractor, reactor, mapper or certification engine is invoked here. An exact
variant is still the unit of certification; the structural family is an index.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import replace
from pathlib import Path

from route_inspector.composite_rules.browsing import CompositeBrowser
from route_inspector.composite_rules.families import IDENTITY_POLICY, key_for_version
from route_inspector.composite_rules.identity import (
    normalize_rule,
)
from route_inspector.composite_rules.library import (
    CompositeDecompositionLibrary,
    CompositeDecompositionLink,
    CompositeLibraryEntry,
    _AcceptedConstruction,
    _aggregate_results,
    _library_id,
    identity_statistics,
)
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.reference_library import ReferenceTacticLibrary
from route_inspector.reference_library.storage.artifacts import (
    _publish_directory_no_replace,
)


def _portable(library, name):
    path = library.directory / library.manifest.artifacts[name]["path"]
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def validate_composite_library(library, reference=None):
    """Audit keys, variants, support, source identities and SQLite/JSONL agreement.

    Call after ``load(..., verification='full')``. This deliberately explicit
    offline audit does not change trusted-fast loading or GUI latency.
    """
    if library.directory is None:
        raise ValueError("validation requires a published companion")
    entries_raw = _portable(library, "entries")
    links_raw = _portable(library, "links")
    entries = [CompositeLibraryEntry.from_dict(v) for v in entries_raw]
    links = [CompositeDecompositionLink.from_dict(v) for v in links_raw]
    if len({e.composite_id for e in entries}) != len(entries):
        raise ValueError("duplicate composite entries")
    if len({link.reference_occurrence_id for link in links}) != len(links):
        raise ValueError("duplicate certified occurrences")
    if any(
        e.identity_version != library.manifest.library_format_version for e in entries
    ):
        raise ValueError("entry/manifest identity versions disagree")
    if any(
        link.schema_version != library.manifest.library_format_version for link in links
    ):
        raise ValueError("link/manifest schema versions disagree")
    if reference is not None:
        library.assert_reference_library(reference)
        if library.manifest.source_routes_sha256 not in {
            c["input_sha256"] for c in reference.manifest.reference_corpora
        }:
            raise ValueError("composite source digest disagrees with Reference corpus")
    browser = CompositeBrowser(library)
    members = {}
    for link in links:
        members.setdefault(link.composite_id, []).append(link)
        library.certified_rule(link)
        if link.certificate.get("validation_status") not in {
            "validated_unique",
            "validated_ambiguous",
        }:
            raise ValueError("uncertified decomposition link")
        for field in (
            "source_chemistry_equivalent",
            "source_mapping_consistent",
            "composite_chemistry_equivalent",
            "composite_mapping_consistent",
        ):
            if link.certificate.get(field) is not True:
                raise ValueError(f"certificate lacks successful {field}")
        if reference is not None:
            browser.verified_occurrence(link, reference)
    all_variants = set()
    for entry in entries:
        local = members.get(entry.composite_id, [])
        from route_inspector.composite_rules.ring_breaking import (
            aggregate_ring_breaking,
        )

        if entry.ring_breaking_counts != aggregate_ring_breaking(local):
            raise ValueError(
                "ring-breaking aggregates disagree with source annotations"
            )
        if tuple(sorted(link.link_id for link in local)) != entry.link_ids:
            raise ValueError("entry link membership disagrees with provenance")
        for kind in ("rrseq_cons", "rrsubtree_cons", "all"):
            subset = [link for link in local if kind == "all" or link.kind == kind]
            routes = {
                (link.dataset_id, link.source_identity, link.route_id)
                for link in subset
            }
            if len(routes) != entry.route_counts.get(kind, 0):
                raise ValueError("distinct-route support disagrees with links")
            if kind != "all" and len(subset) != entry.occurrence_counts.get(kind, 0):
                raise ValueError("occurrence support disagrees with links")
        if entry.identity_version >= 2:
            recorded = {normalize_rule(link.composite_rule) for link in local}
            if recorded != {v["normalized_rule"] for v in entry.variants}:
                raise ValueError("exact variants disagree with certified links")
            for variant in entry.variants:
                rule = variant["normalized_rule"]
                if rule in all_variants:
                    raise ValueError("exact variant belongs to multiple families")
                all_variants.add(rule)
                key = key_for_version(rule, entry.identity_version)
                if key.encoding != entry.identity_key or any(
                    variant[k] != v for k, v in key.audit().items()
                ):
                    raise ValueError(
                        "stored composite identity disagrees with its graph"
                    )
    connection = library._connection
    if connection is not None:
        if (
            connection.execute("PRAGMA integrity_check").fetchone()[0] != "ok"
            or connection.execute("PRAGMA foreign_key_check").fetchall()
        ):
            raise ValueError("composite SQLite integrity failure")
        for table, column, rows, id_column in (
            ("entries", "entry_json", entries_raw, "composite_id"),
            ("links", "link_json", links_raw, "link_id"),
        ):
            sql_rows = [
                json.loads(row[0])
                for row in connection.execute(
                    f"SELECT {column} FROM {table} ORDER BY {id_column}"
                )
            ]
            if sql_rows != sorted(rows, key=lambda value: value[id_column]):
                raise ValueError(f"SQLite/JSONL disagreement: {table}")
        expected_entries = sorted((e.composite_id, e.normalized_rule) for e in entries)
        actual_entries = [
            tuple(row)
            for row in connection.execute(
                "SELECT composite_id, normalized_rule FROM entries ORDER BY composite_id"
            )
        ]
        expected_links = sorted(
            (
                link.link_id,
                link.composite_id,
                link.kind,
                link.reference_occurrence_id,
                link.tactic_entry_id,
                link.dataset_id,
                link.source_identity,
                link.route_id,
            )
            for link in links
        )
        actual_links = [
            tuple(row)
            for row in connection.execute(
                "SELECT link_id, composite_id, kind, reference_occurrence_id, tactic_entry_id, "
                "dataset_id, source_identity, route_id FROM links ORDER BY link_id"
            )
        ]
        if expected_entries != actual_entries or expected_links != actual_links:
            raise ValueError("SQLite indexed columns disagree with JSONL")
        if library.manifest.catalog_schema_version >= 2:
            expected = sorted(
                (v["normalized_rule"], v["variant_id"], e.composite_id)
                for e in entries
                for v in e.variants
            )
            actual = [
                tuple(row)
                for row in connection.execute(
                    "SELECT normalized_rule, variant_id, composite_id FROM variants ORDER BY normalized_rule"
                )
            ]
            if expected != actual:
                raise ValueError("SQLite variant index disagrees with JSONL")
            from route_inspector.composite_rules.identity import identity_base_id

            expected = sorted(
                (e.composite_id, identity_base_id(e.identity_key), e.identity_key)
                for e in entries
            )
            actual = [
                tuple(row)
                for row in connection.execute(
                    "SELECT composite_id, base_id, encoding FROM identity_keys ORDER BY composite_id"
                )
            ]
            if expected != actual:
                raise ValueError("SQLite identity index disagrees with JSONL")
    stats = library.manifest.statistics
    if "ring_breaking" in stats:
        from route_inspector.composite_rules.ring_breaking import summary_counts

        for key, value in summary_counts(links).items():
            if stats["ring_breaking"].get(key) != value:
                raise ValueError(
                    "ring-breaking statistics disagree with source annotations"
                )
    expected_stats = {
        "composite_entry_count": len(entries),
        "certified_link_count": len(links),
        "error_count": len(library.errors),
    }
    for kind in ("rrseq_cons", "rrsubtree_cons"):
        subset = [link for link in links if link.kind == kind]
        expected_stats[f"{kind}_certified_link_count"] = len(subset)
        expected_stats[f"{kind}_route_count"] = len(
            {(link.dataset_id, link.source_identity, link.route_id) for link in subset}
        )
    if library.manifest.library_format_version >= 2:
        expected_stats.update(
            identity_statistics(
                entries,
                identity_version=library.manifest.library_format_version,
            )
        )
    for name, count in expected_stats.items():
        if name in stats and stats[name] != count:
            raise ValueError(f"composite statistics disagree: {name}")
    if "constructions_seen" in stats and stats["constructions_seen"] != len(
        links
    ) + len(library.errors):
        raise ValueError("construction-count accounting disagrees")
    calculated_id = _library_id(
        library.manifest.source_reference_library_id,
        library.manifest.source_routes_sha256,
        library.manifest.construction_profile,
        entries,
        links,
        format_version=library.manifest.library_format_version,
    )
    if library.library_id != calculated_id:
        raise ValueError("composite library identity disagrees with portable records")
    summary = json.loads(
        (library.directory / library.manifest.artifacts["summary"]["path"]).read_text()
    )
    if summary != stats:
        raise ValueError("summary and manifest statistics disagree")
    return expected_stats


def reindex_composite_library(source, reference):
    """Return a version-3 companion and deterministic old-to-new provenance."""
    before = validate_composite_library(source, reference)
    old_entries = source.entries()
    old_links = [
        link
        for entry in old_entries
        for link in source.links_for_entry(entry.composite_id)
    ]
    accepted = [
        _AcceptedConstruction(
            composite_rule=source.certified_rule(link),
            kind=link.kind,
            reference_occurrence_id=link.reference_occurrence_id,
            tactic_entry_id=link.tactic_entry_id,
            dataset_id=link.dataset_id,
            source_identity=link.source_identity,
            route_id=link.route_id,
            certificate=link.certificate,
            ring_breaking=link.ring_breaking,
        )
        for link in old_links
    ]
    entries, links = _aggregate_results(accepted)
    new_by_occurrence = {link.reference_occurrence_id: link for link in links}
    link_changes = []
    entry_changes = {}
    for old in sorted(old_links, key=lambda link: link.link_id):
        new = new_by_occurrence[old.reference_occurrence_id]
        if (
            new.certificate != old.certificate
            or new.composite_rule != source.certified_rule(old)
            or new.ring_breaking != old.ring_breaking
            or any(
                getattr(new, field) != getattr(old, field)
                for field in (
                    "kind",
                    "reference_occurrence_id",
                    "tactic_entry_id",
                    "dataset_id",
                    "source_identity",
                    "route_id",
                )
            )
        ):
            raise ValueError("regrouping changed certified evidence or provenance")
        entry_changes.setdefault(old.composite_id, set()).add(new.composite_id)
        link_changes.append(
            {
                "old_link_id": old.link_id,
                "new_link_id": new.link_id,
                "reference_occurrence_id": old.reference_occurrence_id,
                "variant_id": new.variant_id,
            }
        )
    stats = {
        **source.manifest.statistics,
        "composite_entry_count": len(entries),
        **identity_statistics(entries),
    }
    audit = {
        "operation": "identity_reindex_only",
        "policy": dict(IDENTITY_POLICY),
        "source_manifest": source.manifest.to_dict(),
        "source_manifest_sha256": sha256_file(source.directory / "manifest.json"),
        "before": before,
        "after": stats,
        "entries": [
            {"old_composite_id": old, "new_composite_ids": sorted(new)}
            for old, new in sorted(entry_changes.items())
        ],
        "links": link_changes,
    }
    previous_audit = source.reindex_audit
    if previous_audit is None and "reindex_audit" in source.manifest.artifacts:
        previous_audit = json.loads(
            (
                source.directory / source.manifest.artifacts["reindex_audit"]["path"]
            ).read_text()
        )
    if previous_audit is not None:
        audit["previous_reindex_audit"] = previous_audit
    profile = {
        **source.manifest.construction_profile,
        "composite_identity": dict(IDENTITY_POLICY),
    }
    manifest = replace(
        source.manifest,
        library_format_version=3,
        catalog_schema_version=3,
        library_id=_library_id(
            source.manifest.source_reference_library_id,
            source.manifest.source_routes_sha256,
            profile,
            entries,
            links,
        ),
        construction_profile=profile,
        statistics=stats,
        artifacts={},
    )
    return CompositeDecompositionLibrary(
        manifest=manifest,
        entries=entries,
        links=links,
        errors=source.errors,
        reindex_audit=audit,
    )


def publish_reindexed_library(staging, destination, backup):
    """Promote verified staging with no-replace backup and rollback on failure."""
    staging, destination, backup = map(Path, (staging, destination, backup))
    paths = [p.resolve() for p in (staging, destination, backup)]
    if any(
        a == b or a in b.parents or b in a.parents
        for i, a in enumerate(paths)
        for b in paths[i + 1 :]
    ):
        raise ValueError("publication directories must be distinct and non-nested")
    if backup.exists():
        raise FileExistsError(backup)
    with CompositeDecompositionLibrary.load(staging, verification="full") as candidate:
        validate_composite_library(candidate)
        audit_path = staging / candidate.manifest.artifacts["reindex_audit"]["path"]
        audit = json.loads(audit_path.read_text())
        if (
            sha256_file(destination / "manifest.json")
            != audit["source_manifest_sha256"]
        ):
            raise ValueError("publication source changed since reindexing")
    with CompositeDecompositionLibrary.load(destination, verification="full"):
        pass
    backup.parent.mkdir(parents=True, exist_ok=True)
    _publish_directory_no_replace(destination, backup)
    try:
        _publish_directory_no_replace(staging, destination)
    except BaseException:
        _publish_directory_no_replace(backup, destination)
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--reference-library", type=Path, required=True)
    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--reference-verification",
        choices=("full", "fast"),
        default="full",
        help="Use fast only for an unchanged, previously verified Reference library; composite artifacts are always hashed.",
    )
    parser.add_argument(
        "--overlap-cache-dir",
        type=Path,
        default=Path("outputs/gui/single_step_overlap"),
        help="Reuse existing single-step evidence without extraction when available.",
    )
    args = parser.parse_args(argv)
    if args.output_dir.exists():
        raise FileExistsError(args.output_dir)
    with (
        CompositeDecompositionLibrary.load(args.library, verification="full") as source,
        ReferenceTacticLibrary.load(
            args.reference_library, verification=args.reference_verification
        ) as reference,
    ):
        if sha256_file(args.routes_json) != source.manifest.source_routes_sha256:
            raise ValueError("source routes do not match the certified snapshot")
        result = reindex_composite_library(source, reference)
        result.save(args.output_dir)
        with CompositeDecompositionLibrary.load(
            args.output_dir, verification="full"
        ) as check:
            stats = validate_composite_library(check, reference)
            from route_inspector.composite_rules.reindex_overlap import (
                regroup_overlap_cache,
            )

            regroup_overlap_cache(source, check, reference, args.overlap_cache_dir)
    print(json.dumps(stats, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
