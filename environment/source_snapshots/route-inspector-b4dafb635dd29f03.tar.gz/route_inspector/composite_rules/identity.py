"""Versioned side-aware composite identity, without pairwise isomorphism.

Like SynPlanner's canonical QueryCGR key, this uses colour refinement followed
by bounded within-colour permutations. Unlike a bare QueryCGR, the input rule
retains whether an atom exists on each side. The fallback is a complete graph
encoding, but is deliberately *not* claimed to be numbering invariant.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from functools import lru_cache
from itertools import permutations, product
from math import factorial

from route_inspector.rules.graph import (
    _reaction_atom_side_labels,
    _unsupported_query_constraints,
    canonical_json,
    serialize_query_cgr,
)

IDENTITY_VERSION = 2
MAX_PERMUTATIONS = 5000
IDENTITY_POLICY = {
    "version": IDENTITY_VERSION,
    "method": "side_aware_query_cgr",
    "max_permutations": MAX_PERMUTATIONS,
    "limit_policy": "noncanonical_fallback",
    "unsupported_policy": "exact_representation",
    "pairwise_isomorphism": False,
}


class UnsupportedCompositeQuery(ValueError):
    """A rule contains constraints that the structural encoding cannot retain."""


@dataclass(frozen=True)
class CompositeRuleKey:
    encoding: str
    status: str
    permutation_count: int
    reason: str = ""

    @property
    def base_id(self) -> str:
        return identity_base_id(self.encoding)

    def audit(self) -> dict:
        return {
            "status": self.status,
            "permutation_count": self.permutation_count,
            "reason": self.reason,
        }


def identity_base_id(encoding: str) -> str:
    """Hash bucket only: callers must still compare complete encodings."""
    return "composite_i_" + hashlib.sha256(encoding.encode("utf-8")).hexdigest()


def normalize_rule(rule: str) -> str:
    value = "".join(str(rule).split())
    if not value or ">>" not in value:
        raise ValueError("composite rule must be non-empty reaction SMARTS")
    return value


def variant_id(rule: str) -> str:
    return (
        "composite_variant_i_"
        + hashlib.sha256(normalize_rule(rule).encode("utf-8")).hexdigest()
    )


def _compress(labels):
    palette = {label: i for i, label in enumerate(sorted(set(labels.values())))}
    return {n: palette[label] for n, label in labels.items()}


def composite_query_cgr_key(rule, *, max_permutations=MAX_PERMUTATIONS):
    """Encode an original reaction query; reject unsupported query semantics.

    Map identities align both sides *jointly*. No independent canonicalization
    of the two sides, atom-count signature, or SMARTS textual equality is used.
    Unsupported rules raise; :func:`key_from_smarts` retains them exactly.
    """
    if max_permutations < 1:
        raise ValueError("max_permutations must be positive")
    if not hasattr(rule, "reactants") or not hasattr(rule, "products"):
        raise TypeError("the original reaction query is required, not a QueryCGR")
    if rule.reagents:
        raise UnsupportedCompositeQuery("reaction-agent queries are unsupported")
    unsupported = _unsupported_query_constraints(rule)
    if unsupported:
        raise UnsupportedCompositeQuery(", ".join(unsupported))
    graph = serialize_query_cgr(
        ~rule, atom_side_labels=_reaction_atom_side_labels(rule)
    )
    labels = {atom["node"]: canonical_json(atom["label"]) for atom in graph["atoms"]}
    adjacency = {n: {} for n in labels}
    for bond in graph["bonds"]:
        a, b = bond["nodes"]
        adjacency[a][b] = adjacency[b][a] = canonical_json(bond["label"])
    colors = _compress(labels)
    for _ in labels:
        refined = _compress(
            {
                n: (
                    colors[n],
                    tuple(sorted((bond, colors[m]) for m, bond in edges.items())),
                )
                for n, edges in adjacency.items()
            }
        )
        if refined == colors:
            break
        colors = refined
    groups = [
        tuple(n for n in labels if colors[n] == c) for c in sorted(set(colors.values()))
    ]
    count = 1
    for group in groups:
        count *= factorial(len(group))

    def encode(order):
        positions = {n: i for i, n in enumerate(order)}
        return (
            tuple(labels[n] for n in order),
            tuple(
                sorted(
                    (positions[n], positions[m], bond)
                    for n in order
                    for m, bond in adjacency[n].items()
                    if positions[n] < positions[m]
                )
            ),
        )

    if count <= max_permutations:
        encoding = min(
            encode(tuple(n for group in orders for n in group))
            for orders in product(*(permutations(group) for group in groups))
        )
        status = "canonical"
    else:
        # Positional tie-breaks retain every label and edge. They can miss merges
        # after renumbering, but equal encodings still imply equal labelled graphs.
        encoding = encode(
            tuple(
                n
                for group in groups
                for n in sorted(group, key=lambda n: (labels[n], len(adjacency[n]), n))
            )
        )
        status = "noncanonical_fallback"
    return CompositeRuleKey(
        canonical_json(
            {
                "version": IDENTITY_VERSION,
                "method": "side_aware_query_cgr",
                "graph": encoding,
            }
        ),
        status,
        count,
    )


@lru_cache(maxsize=32768)
def key_from_smarts(rule: str) -> CompositeRuleKey:
    """Parse stored queries; fail closed to exact identity, never a lossy key."""
    from chython import smarts

    normalized = normalize_rule(rule)
    try:
        return composite_query_cgr_key(smarts(normalized))
    except (
        ValueError,
        TypeError,
        AttributeError,
        KeyError,
        NotImplementedError,
    ) as exc:
        return CompositeRuleKey(
            canonical_json(
                {
                    "version": IDENTITY_VERSION,
                    "method": "exact_representation",
                    "rule": normalized,
                }
            ),
            "exact_representation",
            0,
            f"{type(exc).__name__}: {exc}",
        )
