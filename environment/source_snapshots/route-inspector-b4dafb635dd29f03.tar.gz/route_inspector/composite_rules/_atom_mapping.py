"""Assign introduced atoms identities scoped to a complete replayed route."""

from collections import Counter
from copy import deepcopy
from typing import Any, Iterable, Mapping


def _molecule(node):
    from chython import smiles

    return smiles(node.get("mapped_smiles") or node["smiles"])


def _identity(molecule):
    """Mapped graph identity, independent of serialization/component ordering."""
    return (
        str(molecule),
        tuple(
            sorted(
                (n, a.atomic_number, a.isotope, a.charge, a.is_radical)
                for n, a in molecule.atoms()
            )
        ),
        tuple(sorted((min(n, m), max(n, m), int(b)) for n, m, b in molecule.bonds())),
    )


def route_atom_ids(root: Mapping[str, Any]) -> set[int]:
    """Reserve maps from every original molecule and reaction, including agents."""
    from chython import smiles

    result = set()

    def visit(node):
        if node.get("type") == "mol":
            result.update(_molecule(node))
        elif node.get("type") == "reaction":
            reaction = smiles(node["smiles"])
            for molecule in (
                *reaction.reactants,
                *reaction.products,
                *reaction.reagents,
            ):
                result.update(molecule)
        for child in node.get("children", ()) or ():
            visit(child)

    visit(root)
    return result


def normalize_route_atom_mapping(
    root: Mapping[str, Any],
    *,
    reserved_atom_ids: Iterable[int] = (),
    forward: bool = False,
    repair_recorded_collisions: bool = False,
):
    """Return a copy with unique introduced IDs and per-reaction local maps.

    Only RRSubtree reactions introduce renumberable atoms. Recorded reactions
    retain their IDs unless ``repair_recorded_collisions`` is requested for
    source-route preparation. Then only conflicting new occurrences receive
    fresh IDs; target atoms remain pinned. Each child inherits only the identities of its own input
    molecule: a local reactor ID reused in a sibling is a different atom, even
    when both atoms have the same element. The allocator is shared by all arms.
    No global old-ID/new-ID substitution can implement this distinction.

    Native RRSubtree reaction SMILES are retrospective; ``forward=True`` writes
    those steps in SynPlanner's precursor-to-product convention. The caller must
    reserve all original route IDs when inserting into an existing route.
    """
    from chython import smiles
    from chython.containers import ReactionContainer

    result = deepcopy(dict(root))
    target = _molecule(result)
    reserved = set(reserved_atom_ids) | set(target)
    next_id = max(reserved, default=0) + 1
    introduced = set(target)
    reaction_maps = {}

    def visit(node, inherited, path):
        nonlocal next_id
        local = _molecule(node)
        if set(local) != set(inherited):
            raise ValueError(f"Inconsistent atom lineage at molecule path {path}")
        local.remap(inherited)
        node["smiles"] = format(local, "m")
        if "mapped_smiles" in node:
            node["mapped_smiles"] = node["smiles"]
        reactions = node.get("children", ()) or ()
        if not reactions:
            return
        if len(reactions) != 1 or reactions[0].get("type") != "reaction":
            raise ValueError(f"Expected one reaction at molecule path {path}")
        step = reactions[0]
        step_path = path + (0,)
        reaction = smiles(step["smiles"])
        generated = step.get("rule_source") == "RRSubtree"
        active = reaction.reactants if generated else reaction.products
        precursors = reaction.products if generated else reaction.reactants
        # Compare in the local coordinate system before remapping the reaction.
        input_local = local.copy()
        input_local.remap({new: old for old, new in inherited.items()})
        if not any(_identity(mol) == _identity(input_local) for mol in active):
            raise ValueError(f"Reaction product disagrees with molecule at {path}")
        children = step.get("children", ()) or ()
        child_molecules = [_molecule(child) for child in children]
        if Counter(map(_identity, child_molecules)) != Counter(
            map(_identity, precursors)
        ):
            raise ValueError(f"Reaction precursors disagree with branches at {path}")
        child_ids = [n for mol in child_molecules for n in mol]
        if len(child_ids) != len(set(child_ids)):
            raise ValueError(f"Distinct precursor atoms share a mapping at {path}")
        mapping = dict(inherited)
        all_molecules = (*reaction.reactants, *reaction.products, *reaction.reagents)
        all_ids = {n for mol in all_molecules for n in mol}
        for old in sorted(all_ids - mapping.keys()):
            if generated:
                new = next_id
                next_id += 1
            else:
                new = old
                if new not in reserved:
                    raise ValueError(f"Original atom {new} was not reserved")
                if new in introduced and repair_recorded_collisions:
                    new = next_id
                    next_id += 1
            if new in introduced:
                raise ValueError(
                    f"Atom map {new} introduced in distinct branches at reaction "
                    f"path {step_path} (tree node {step.get('tree_node_id')})"
                )
            introduced.add(new)
            mapping[old] = new
        for mol in all_molecules:
            mol.remap({n: mapping[n] for n in mol})
        if generated and forward:
            reaction = ReactionContainer(
                reactants=reaction.products,
                products=reaction.reactants,
                reagents=reaction.reagents,
                meta=deepcopy(reaction.meta),
            )
        else:
            reaction.flush_cache()
        step["smiles"] = format(reaction, "m")
        if "mapped_smiles" in step:
            step["mapped_smiles"] = step["smiles"]
        reaction_maps[step_path] = mapping
        for index, (child, mol) in enumerate(zip(children, child_molecules)):
            visit(child, {n: mapping[n] for n in mol}, step_path + (index,))

    visit(result, {n: n for n in target}, ())
    return result, reaction_maps


def normalize_recorded_route_atom_mapping(root: Mapping[str, Any]):
    """Reconcile local maps before exact replay, retaining a reversible audit.

    Original target IDs and nonconflicting introduced IDs are unchanged. Only
    later births of an already used local ID are renamed, above every recorded
    ID. Their descendants inherit that identity within their branch. Numeric
    equality across unrelated branches is never treated as shared atom identity.
    """
    normalized, mappings = normalize_route_atom_mapping(
        root,
        reserved_atom_ids=route_atom_ids(root),
        repair_recorded_collisions=True,
    )
    changes = []
    for path, mapping in mappings.items():
        renamed = [[old, new] for old, new in sorted(mapping.items()) if old != new]
        if not renamed:
            continue
        reaction = root
        for index in path:
            reaction = reaction["children"][index]
        changes.append(
            {
                "reaction_path": list(path),
                "tree_node_id": reaction.get("tree_node_id"),
                "atom_maps": renamed,
            }
        )
    if changes:
        normalized.setdefault("metadata", {})["recorded_atom_mapping"] = {
            "policy": "preserve_target_and_nonconflicting_original_ids",
            "remapped_steps": changes,
        }
    return normalized
