"""Disk-staged certified constructions, with unchanged portable composite records."""

from __future__ import annotations

import fcntl
import json
import sqlite3
import zlib
from dataclasses import asdict
from pathlib import Path

from route_inspector.composite_rules.families import key_for_version
from route_inspector.composite_rules.identity import (
    normalize_rule,
    variant_id,
)
from route_inspector.rules.graph import canonical_json


class RecordSequence:
    """Re-iterable ordered SQLite records; explicit slicing remains supported."""

    def __init__(self, db, table, column, factory, order):
        self.db, self.table, self.column, self.factory, self.order = (
            db,
            table,
            column,
            factory,
            order,
        )

    def __len__(self):
        return self.db.execute(f"SELECT COUNT(*) FROM {self.table}").fetchone()[0]

    def __iter__(self):
        for (raw,) in self.db.execute(
            f"SELECT {self.column} FROM {self.table} ORDER BY {self.order}"
        ):
            yield self.factory(json.loads(raw))

    def __getitem__(self, index):
        if isinstance(index, slice):
            from itertools import islice

            return tuple(
                islice(iter(self), index.start or 0, index.stop, index.step or 1)
            )
        if index < 0:
            index += len(self)
        if index < 0:
            raise IndexError(index)
        row = self.db.execute(
            f"SELECT {self.column} FROM {self.table} ORDER BY {self.order} LIMIT 1 OFFSET ?",
            (index,),
        ).fetchone()
        if row is None:
            raise IndexError(index)
        return self.factory(json.loads(row[0]))


class AcceptedRecords:
    def __init__(self, stage):
        self.stage = stage

    def append(self, value):
        from route_inspector.composite_rules.library import COMPOSITE_IDENTITY_VERSION

        key = key_for_version(
            normalize_rule(value.composite_rule), COMPOSITE_IDENTITY_VERSION
        )
        self.stage.db.execute(
            "INSERT INTO accepted VALUES(?,?,?,?,?)",
            (
                value.reference_occurrence_id,
                key.base_id,
                key.encoding,
                normalize_rule(value.composite_rule),
                zlib.compress(canonical_json(asdict(value)).encode(), 3),
            ),
        )

    def __len__(self):
        return self.stage.db.execute("SELECT COUNT(*) FROM accepted").fetchone()[0]


class ErrorRecords(RecordSequence):
    def __init__(self, db):
        super().__init__(db, "build_errors", "error_json", lambda v: v, "ordinal")

    def append(self, value):
        self.db.execute(
            "INSERT INTO build_errors(oid,error_json) VALUES(?,?)",
            (value["reference_occurrence_id"], canonical_json(value)),
        )


class CompositeStage:
    def __init__(self, root, *, fingerprint=None, resume=False):
        from route_inspector.composite_rules.library import (
            _SCHEMA_SQL,
            _VARIANT_SCHEMA_SQL,
        )

        root = Path(root)
        root.mkdir(parents=True, exist_ok=True)
        self.lock = (root / "constructions.lock").open("a+")
        try:
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BaseException:
            self.lock.close()
            raise
        path = root / "constructions.sqlite"
        exists = path.exists()
        if exists and not resume:
            self.lock.close()
            raise FileExistsError("composite staging exists; use resume=True")
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=TRUNCATE")
        self.db.execute("PRAGMA cache_size=-16384")
        self.db.execute("PRAGMA temp_store=FILE")
        if not exists:
            self.db.executescript(
                _SCHEMA_SQL
                + _VARIANT_SCHEMA_SQL
                + """
                CREATE TABLE build_metadata(fingerprint TEXT);
                CREATE TABLE accepted(oid TEXT PRIMARY KEY,base_id TEXT,encoding TEXT,normalized TEXT,payload BLOB);
                CREATE INDEX accepted_groups ON accepted(base_id,encoding,oid);
                CREATE TABLE build_errors(ordinal INTEGER PRIMARY KEY,oid TEXT UNIQUE,error_json TEXT);
            """
            )
        encoded = canonical_json(fingerprint or {})
        if not exists:
            self.db.execute("INSERT INTO build_metadata VALUES(?)", (encoded,))
            self.db.commit()
        elif (
            self.db.execute("SELECT fingerprint FROM build_metadata").fetchone()[0]
            != encoded
        ):
            self.close()
            raise ValueError("composite resume fingerprint mismatch")
        self.accepted = AcceptedRecords(self)
        self.errors = ErrorRecords(self.db)

    def close(self):
        self.db.close()
        self.lock.close()

    def contains(self, oid):
        return (
            self.db.execute(
                "SELECT 1 FROM accepted WHERE oid=? UNION ALL SELECT 1 FROM build_errors WHERE oid=?",
                (oid, oid),
            ).fetchone()
            is not None
        )

    def aggregate(self):
        from route_inspector.composite_rules.library import (
            _EXECUTABLE_KINDS,
            COMPOSITE_IDENTITY_VERSION,
            CompositeDecompositionLink,
            CompositeLibraryEntry,
            _link_id,
        )
        from route_inspector.composite_rules.ring_breaking import (
            aggregate_ring_breaking,
        )

        version = COMPOSITE_IDENTITY_VERSION
        previous = None
        ordinal = 0
        for base, encoding in self.db.execute(
            "SELECT DISTINCT base_id,encoding FROM accepted ORDER BY base_id,encoding"
        ):
            ordinal = ordinal + 1 if base == previous else 0
            previous = base
            cid = f"{base}~{ordinal:04d}"
            if self.db.execute(
                "SELECT 1 FROM entries WHERE composite_id=?", (cid,)
            ).fetchone():
                continue
            variants = tuple(
                {
                    "variant_id": variant_id(rule),
                    "normalized_rule": rule,
                    **key_for_version(rule, version).audit(),
                }
                for (rule,) in self.db.execute(
                    "SELECT DISTINCT normalized FROM accepted WHERE base_id=? AND encoding=? ORDER BY normalized",
                    (base, encoding),
                )
            )
            for (payload,) in self.db.execute(
                "SELECT payload FROM accepted WHERE base_id=? AND encoding=? ORDER BY oid",
                (base, encoding),
            ):
                value = json.loads(zlib.decompress(payload))
                link = CompositeDecompositionLink(
                    schema_version=version,
                    link_id=_link_id(
                        cid, value["reference_occurrence_id"], schema_version=version
                    ),
                    composite_id=cid,
                    variant_id=variant_id(value["composite_rule"]),
                    **value,
                )
                self.db.execute(
                    "INSERT INTO links VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        link.link_id,
                        cid,
                        link.kind,
                        link.reference_occurrence_id,
                        link.tactic_entry_id,
                        link.dataset_id,
                        link.source_identity,
                        link.route_id,
                        canonical_json(link.to_dict()),
                    ),
                )
            occurrence_counts = {
                kind: self.db.execute(
                    "SELECT COUNT(*) FROM links WHERE composite_id=? AND kind=?",
                    (cid, kind),
                ).fetchone()[0]
                for kind in _EXECUTABLE_KINDS
            }
            routes = {
                kind: self.db.execute(
                    "SELECT COUNT(*) FROM (SELECT DISTINCT dataset_id,source_identity,route_id FROM links WHERE composite_id=?"
                    + (" AND kind=?" if kind != "all" else "")
                    + ")",
                    (cid, kind) if kind != "all" else (cid,),
                ).fetchone()[0]
                for kind in (*_EXECUTABLE_KINDS, "all")
            }
            links = (
                CompositeDecompositionLink.from_dict(json.loads(r[0]))
                for r in self.db.execute(
                    "SELECT link_json FROM links WHERE composite_id=? ORDER BY link_id",
                    (cid,),
                )
            )
            entry = CompositeLibraryEntry(
                identity_version=version,
                composite_id=cid,
                composite_rule=variants[0]["normalized_rule"],
                normalized_rule=variants[0]["normalized_rule"],
                identity_key=encoding,
                variants=variants,
                link_ids=tuple(
                    r[0]
                    for r in self.db.execute(
                        "SELECT link_id FROM links WHERE composite_id=? ORDER BY link_id",
                        (cid,),
                    )
                ),
                ring_breaking_counts=aggregate_ring_breaking(links),
                occurrence_counts=occurrence_counts,
                route_counts=routes,
            )
            self.db.execute(
                "INSERT INTO entries VALUES(?,?,?)",
                (cid, entry.normalized_rule, canonical_json(entry.to_dict())),
            )
            self.db.executemany(
                "INSERT INTO variants VALUES(?,?,?)",
                ((v["normalized_rule"], v["variant_id"], cid) for v in variants),
            )
            self.db.execute(
                "INSERT INTO identity_keys VALUES(?,?,?)", (cid, base, encoding)
            )
            self.db.commit()
        return (
            RecordSequence(
                self.db,
                "entries",
                "entry_json",
                CompositeLibraryEntry.from_dict,
                "composite_id",
            ),
            RecordSequence(
                self.db,
                "links",
                "link_json",
                CompositeDecompositionLink.from_dict,
                "link_id",
            ),
        )

    def library(self, manifest, entries, links):
        from route_inspector.composite_rules.library import (
            CompositeDecompositionLibrary,
        )

        stage = self

        class StagedLibrary(CompositeDecompositionLibrary):
            def close(self):
                super().close()
                stage.lock.close()

            def save(self, directory, *, include_sqlite=True):
                self._entries, self._links = entries, links
                try:
                    super().save(directory, include_sqlite=include_sqlite)
                finally:
                    self._entries = self._links = None

        library = StagedLibrary(
            manifest=manifest, entries=None, links=None, connection=self.db
        )
        library._errors = self.errors
        return library
