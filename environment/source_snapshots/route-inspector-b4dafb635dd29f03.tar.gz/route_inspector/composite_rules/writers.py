"""Composite artifact paths, columns, and serialization."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Iterable

from route_inspector.infrastructure.artifacts import (
    reference_sort_key,
    resolve_file_or_dir_path,
)
from route_inspector.infrastructure.text import write_tsv
from route_inspector.tactics.rrseq.writers import reaction_output_reactants_num


def output_base(output: Path, suffix: str) -> Path:
    """Build the normalized output stem shared by related artifacts.

    The returned path follows the project naming conventions so downstream commands can
    discover related summaries and error files automatically.
    """
    prefix = output.with_suffix("")
    base_name = re.sub(r"_classified_composite_rules$", "", prefix.name)
    base_name = re.sub(r"_composite_rules$", "", base_name)
    return prefix.with_name(f"{base_name}_{suffix}")


def default_smi_path(output: Path) -> Path:
    """Resolve output path information for default SMI path.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    return output_base(output, "composite_reactions").with_suffix(".smi")


def default_composite_summary_path(output: Path) -> Path:
    """Resolve output path information for default composite summary path.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    return (output if is_directory_path(output) else output.parent) / "summary.json"


def default_composite_error_path(output: Path) -> Path:
    """Resolve output path information for default composite error path.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    return output_base(output, "composite_rule_collection_errors").with_suffix(".tsv")


def default_classification_output_path(composite_rules_tsv: Path) -> Path:
    """Resolve output path information for default classification output path.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    return output_base(composite_rules_tsv, "classified_composite_rules").with_suffix(
        ".tsv"
    )


def default_classification_summary_path(output: Path) -> Path:
    """Resolve output path information for default classification summary path.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    return (output if is_directory_path(output) else output.parent) / "summary.json"


def resolve_classification_output_paths(
    composite_rules_tsv: Path,
    output: Path,
    summary: Path,
) -> tuple[Path, Path]:
    """Resolve output path information for resolve classification output paths.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    base_name = re.sub(r"_composite_rules$", "", composite_rules_tsv.stem)
    output_path = resolve_file_or_dir_path(
        output,
        f"{base_name}_classified_composite_rules.tsv",
    )
    summary_path = output_path.parent / "summary.json"
    return output_path, summary_path


def is_directory_path(path: Path) -> bool:
    """Resolve output path information for is directory path.

    The returned path follows the project naming conventions so downstream commands can
    discover related summaries and error files automatically.
    """
    return path.is_dir() or path.suffix == ""


def rrseq_output_stem(rrseq_tsvs: Iterable[Path]) -> str:
    """Infer the shared output stem from rrseq TSV paths.

    The returned path follows the project naming conventions so downstream commands can
    discover related summaries and error files automatically.
    """
    stems = []
    for path in rrseq_tsvs:
        match = re.match(r"(.+)_t\d+_(?:rrseq_cons|rrseqs)$", path.stem)
        if match:
            stems.append(match.group(1))

    unique_stems = sorted(set(stems))
    if len(unique_stems) == 1:
        return unique_stems[0]
    if unique_stems:
        return "merged"
    return "composite"


def resolve_optional_sidecar_path(
    path: Path | None,
    output_dir: Path,
    filename: str,
) -> Path:
    """Resolve output path information for resolve optional sidecar path.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    if path is None:
        return output_dir / filename
    if is_directory_path(path):
        return path / filename
    return path


def resolve_composite_output_paths(
    output: Path,
    rrseq_tsvs: list[Path],
    *,
    output_smi: Path | None = None,
    summary: Path | None = None,
    errors: Path | None = None,
) -> tuple[Path, Path, Path, Path]:
    """Resolve output path information for resolve composite output paths.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    if is_directory_path(output):
        stem = rrseq_output_stem(rrseq_tsvs)
        output_dir = output
        return (
            output_dir / f"{stem}_composite_rules.tsv",
            resolve_optional_sidecar_path(
                output_smi,
                output_dir,
                f"{stem}_composite_reactions.smi",
            ),
            output_dir / "summary.json",
            resolve_optional_sidecar_path(
                errors,
                output_dir,
                f"{stem}_composite_rule_collection_errors.tsv",
            ),
        )

    rules_path = output
    smi_path = output_smi or default_smi_path(rules_path)
    summary_path = rules_path.parent / "summary.json"
    error_path = errors or default_composite_error_path(rules_path)
    return rules_path, smi_path, summary_path, error_path


def sorted_aggregates(aggregates: dict[str, Any]) -> list[Any]:
    """Return aggregate records sorted by popularity and rule text.

    Keeping this helper in the IO layer avoids duplicating low-level file and table
    behavior in the chemistry-focused modules.
    """
    return sorted(
        aggregates.values(),
        key=lambda aggregate: (
            -len(getattr(aggregate, "qualified_route_ids", ()) or aggregate.route_ids),
            -len(aggregate.pseudo_reaction_ids),
            aggregate.rule_smarts,
        ),
    )


def composite_rule_ids(aggregates: dict[str, Any]) -> dict[str, str]:
    """Return deterministic public IDs shared by all composite artifacts."""

    return {
        aggregate.cgr_key: f"a{index}"
        for index, aggregate in enumerate(sorted_aggregates(aggregates))
    }


def write_composite_rules_tsv(
    output: Path,
    aggregates: dict[str, Any],
    *,
    composite_ids: dict[str, str] | None = None,
) -> dict[str, int]:
    """Write composite rules TSV to disk.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    fieldnames = [
        "Composite_rule",
        "output_reactants_num",
        "popularity",
        "route_ids_size",
        "Reference",
        "Target_molecules",
        "rrseq_cons_variants",
        "RRseq_cons_sizes",
        "RRseq_cons",
        "Source_rrseq_cons_rows",
        "pseudo_reactions_size",
        "Pseudo_reaction_ids",
        "Composite_id",
        "occurrence_count",
        "validated_occurrence_count",
        "ambiguous_occurrence_count",
        "failed_occurrence_count",
        "validation_rate",
        "validation_status",
        "qualified_popularity",
        "qualified_route_ids_size",
        "Qualified_references_json",
    ]
    composite_ids = composite_ids or composite_rule_ids(aggregates)
    rows = []
    for aggregate in sorted_aggregates(aggregates):
        route_ids = sorted(aggregate.route_ids, key=reference_sort_key)
        qualified_route_ids = sorted(
            getattr(aggregate, "qualified_route_ids", ())
            or {(None, route_id) for route_id in route_ids},
            key=lambda item: (
                item[0] or "",
                reference_sort_key(item[1]),
            ),
        )
        occurrence_count = len(getattr(aggregate, "occurrence_ids", ()))
        validated_count = len(getattr(aggregate, "validated_occurrence_ids", ()))
        ambiguous_count = len(getattr(aggregate, "ambiguous_occurrence_ids", ()))
        failed_count = len(getattr(aggregate, "failed_occurrence_ids", ()))
        if occurrence_count == 0:
            validation_status = "unvalidated_legacy"
        elif failed_count:
            validation_status = "partially_validated" if validated_count else "rejected"
        elif ambiguous_count:
            validation_status = "validated_with_ambiguity"
        else:
            validation_status = "validated_unique"
        rows.append(
            {
                "Composite_rule": aggregate.rule_smarts,
                "output_reactants_num": reaction_output_reactants_num(
                    aggregate.rule_smarts
                ),
                "popularity": len(route_ids),
                "route_ids_size": len(route_ids),
                "Reference": ",".join(route_ids),
                "Target_molecules": ",".join(sorted(aggregate.target_molecules)),
                "rrseq_cons_variants": len(aggregate.rrseqs),
                "RRseq_cons_sizes": ",".join(map(str, sorted(aggregate.rrseq_sizes))),
                "RRseq_cons": " || ".join(sorted(aggregate.rrseqs)),
                "Source_rrseq_cons_rows": ",".join(sorted(aggregate.source_rows)),
                "pseudo_reactions_size": len(aggregate.pseudo_reaction_ids),
                "Pseudo_reaction_ids": ",".join(aggregate.pseudo_reaction_ids),
                "Composite_id": composite_ids[aggregate.cgr_key],
                "occurrence_count": occurrence_count,
                "validated_occurrence_count": validated_count,
                "ambiguous_occurrence_count": ambiguous_count,
                "failed_occurrence_count": failed_count,
                "validation_rate": (
                    f"{validated_count / occurrence_count:.6f}"
                    if occurrence_count
                    else ""
                ),
                "validation_status": validation_status,
                "qualified_popularity": len(qualified_route_ids),
                "qualified_route_ids_size": len(qualified_route_ids),
                "Qualified_references_json": json.dumps(
                    [list(item) for item in qualified_route_ids],
                    separators=(",", ":"),
                ),
            }
        )
    write_tsv(output, fieldnames, rows)
    return {"composite_rules": len(aggregates)}


def write_pseudo_reactions_smi(
    output: Path,
    pseudo_reactions: list[Any],
    aggregates: dict[str, Any],
    *,
    composite_ids: dict[str, str] | None = None,
) -> None:
    """Write pseudo reactions SMI to disk.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    output.parent.mkdir(parents=True, exist_ok=True)
    composite_ids = composite_ids or composite_rule_ids(aggregates)
    with output.open("w", encoding="utf-8") as file:
        for record in pseudo_reactions:
            file.write(
                "\t".join(
                    [
                        record.reaction_smiles,
                        record.pseudo_reaction_id,
                        composite_ids[record.composite_cgr],
                        ",".join(record.route_ids),
                        record.target_smiles,
                        str(record.rrseq_cons_size),
                        f"{Path(record.source_tsv).name}:{record.source_row}",
                    ]
                )
                + "\n"
            )


def resolve_composite_validation_output_paths(
    rules_path: Path,
    *,
    validation: Path | None = None,
    validation_errors: Path | None = None,
    certified: Path | None = None,
) -> tuple[Path, Path, Path]:
    """Resolve additive occurrence-validation and certified-rule artifacts."""

    stem = re.sub(r"_composite_rules$", "", rules_path.stem)
    output_dir = rules_path.parent
    return (
        validation or output_dir / f"{stem}_composite_validation.json",
        validation_errors or output_dir / f"{stem}_composite_validation_failures.tsv",
        certified or output_dir / f"{stem}_validated_composite_rules.tsv",
    )


def write_composite_validation_records(
    path: Path,
    records: Iterable[dict[str, Any]],
    *,
    composite_ids: dict[str, str],
) -> None:
    """Write deterministic JSON-array occurrence and match provenance."""

    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write("[")
        first = True
        for record in records:
            output_record = dict(record)
            aggregate_key = output_record.get("composite_aggregate_key")
            output_record["composite_id"] = composite_ids.get(aggregate_key)
            if not first:
                stream.write(",")
            json.dump(
                output_record,
                stream,
                sort_keys=True,
                separators=(",", ":"),
            )
            first = False
        stream.write("]\n")


def write_composite_validation_failures(
    path: Path,
    records: Iterable[dict[str, Any]],
) -> None:
    """Write compact scientific rejections separately from execution errors."""

    failures = [record for record in records if not record.get("accepted")]
    if not failures:
        if path.exists():
            path.unlink()
        return
    rows = []
    for record in failures:
        representative = record.get("representative_validation") or {}
        candidate = record.get("candidate_validation") or {}
        error = record.get("error") or {}
        validation_error = representative or candidate
        rows.append(
            {
                "occurrence_id": record.get("occurrence_id", ""),
                "route_id": record.get("route_id", ""),
                "target_smiles": record.get("target_smiles", ""),
                "root_index": record.get("root_index", ""),
                "branch_index": record.get("branch_index", ""),
                "RRseq_cons": record.get("RRseq_cons", record.get("RRseq", "")),
                "status": record.get("status", ""),
                "first_outcome_match": representative.get(
                    "first_outcome_match",
                    "",
                ),
                "any_outcome_match": representative.get(
                    "any_outcome_match",
                    "",
                ),
                "total_unique_outcomes": representative.get(
                    "total_unique_outcomes",
                    "",
                ),
                "matching_outcome_count": representative.get(
                    "matching_outcome_count",
                    "",
                ),
                "truncated": representative.get("truncated", ""),
                "error_type": error.get("error_type")
                or validation_error.get("error_type", ""),
                "message": error.get("message")
                or validation_error.get("error_message", ""),
            }
        )
    write_tsv(
        path,
        [
            "occurrence_id",
            "route_id",
            "target_smiles",
            "root_index",
            "branch_index",
            "RRseq_cons",
            "status",
            "first_outcome_match",
            "any_outcome_match",
            "total_unique_outcomes",
            "matching_outcome_count",
            "truncated",
            "error_type",
            "message",
        ],
        rows,
    )


def write_composite_errors(path: Path, errors: list[dict[str, Any]]) -> None:
    """Write composite errors to disk.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    if not errors:
        if path.exists():
            path.unlink()
        return
    fieldnames = [
        "dataset",
        "route_id",
        "reaction_steps",
        "row_index",
        "Target_smiles",
        "RRseq_cons",
        "source_tsv",
        "RRseq_cons_size",
        "Route_ids",
        "stage",
        "error_type",
        "message",
    ]
    write_tsv(
        path,
        fieldnames,
        (composite_error_row_for_output(row) for row in errors),
    )


def source_tsv_prefix(path: str | Path) -> str:
    """Return the compact dataset and rule-size prefix for a source TSV.

    Keeping this helper in the IO layer avoids duplicating low-level file and table
    behavior in the chemistry-focused modules.
    """
    stem = Path(path).stem
    return re.sub(r"_(?:rrseq_cons|rrseqs)$", "", stem)


def composite_error_row_for_output(row: dict[str, Any]) -> dict[str, Any]:
    """Normalize an composite extraction error row for TSV output.

    The returned path follows the project naming conventions so downstream commands can
    discover related summaries and error files automatically.
    """
    return {
        "dataset": row.get("dataset", ""),
        "route_id": row.get("route_id", ""),
        "reaction_steps": row.get("reaction_steps", ""),
        "row_index": row.get("row_index", ""),
        "Target_smiles": row.get("Target_smiles")
        or row.get("target_smiles")
        or row.get("Target_molecules", ""),
        "RRseq_cons": row.get("RRseq_cons", row.get("RRseq", "")),
        "source_tsv": source_tsv_prefix(row.get("source_tsv", "")),
        "RRseq_cons_size": row.get("RRseq_cons_size")
        or row.get("RRseq_size")
        or row.get("rrseq_size", ""),
        "Route_ids": row.get("Route_ids") or row.get("route_ids", ""),
        "stage": row.get("stage", ""),
        "error_type": row.get("error_type", ""),
        "message": row.get("message", ""),
    }
