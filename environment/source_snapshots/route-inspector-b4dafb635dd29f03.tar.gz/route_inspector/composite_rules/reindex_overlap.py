"""Remap existing overlap evidence after a lossless composite-family regroup."""

import json
import shutil
import sqlite3
import tempfile
from dataclasses import replace
from pathlib import Path

from route_inspector.composite_rules.overlap import (
    CACHE_ARTIFACTS,
    OverlapIndex,
    cache_identity,
    cache_key,
)
from route_inspector.composite_rules.overlap_cache import cache_lock
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.infrastructure.publication import publish_directory_no_replace


def regroup_overlap_cache(source, upgraded, reference, cache_root):
    """Union old family matches; retain exact rules, steps and failure evidence."""
    old_identity = cache_identity(
        reference, source, source.manifest.source_routes_sha256
    )
    new_identity = cache_identity(
        reference, upgraded, upgraded.manifest.source_routes_sha256
    )
    if {k: v for k, v in old_identity.items() if k != "composite_library_id"} != {
        k: v for k, v in new_identity.items() if k != "composite_library_id"
    }:
        raise ValueError("Regrouping changed the overlap source or comparison policy")
    cache_root = Path(cache_root)
    old, new = (cache_root / cache_key(i) for i in (old_identity, new_identity))
    if not old.exists():
        return None
    entries, links = {}, {}
    for entry in source.entries():
        destinations = set()
        for link in source.links_for_entry(entry.composite_id):
            candidate = upgraded.link_for_occurrence(link.reference_occurrence_id)
            expected = replace(
                link,
                schema_version=candidate.schema_version,
                link_id=candidate.link_id,
                composite_id=candidate.composite_id,
                composite_rule=source.certified_rule(link),
                variant_id=candidate.variant_id,
            )
            if expected != candidate:
                raise ValueError("Regrouping changed certified overlap source evidence")
            destinations.add(candidate.composite_id)
            links[link.link_id] = candidate.link_id
        if len(destinations) != 1:
            raise ValueError(
                "Overlap reuse requires whole-family merges without splits"
            )
        entries[entry.composite_id] = destinations.pop()
    if len(links) != upgraded.manifest.statistics["certified_link_count"] or set(
        entries.values()
    ) != {e.composite_id for e in upgraded.entries()}:
        raise ValueError("Regrouping changed the source occurrence population")
    with OverlapIndex(old, old_identity) as index:
        summary = dict(index.summary)
    with cache_lock(new):
        if new.exists():
            with OverlapIndex(new, new_identity):
                return new
        temporary = Path(tempfile.mkdtemp(prefix=".regroup-overlap-", dir=cache_root))
        try:
            shutil.copytree(old, temporary, dirs_exist_ok=True)
            with sqlite3.connect(temporary / "catalog.sqlite") as con:
                con.execute(
                    "CREATE TEMP TABLE regroup (old TEXT PRIMARY KEY, new TEXT NOT NULL)"
                )
                con.executemany(
                    "INSERT INTO regroup VALUES (?, ?)", sorted(entries.items())
                )
                if con.execute(
                    "SELECT count(*) FROM matches LEFT JOIN regroup ON composite_id=old WHERE old IS NULL"
                ).fetchone()[0]:
                    raise ValueError(
                        "Overlap cache references an unknown old composite"
                    )
                con.execute(
                    "CREATE TEMP TABLE merged AS SELECT DISTINCT new AS composite_id, rule_id FROM matches JOIN regroup ON composite_id=old"
                )
                con.execute("DELETE FROM matches")
                con.execute("INSERT INTO matches SELECT * FROM merged")
                matched = con.execute(
                    "SELECT count(DISTINCT composite_id) FROM matches"
                ).fetchone()[0]
            audit_path = temporary / "composite_sources.jsonl"
            attempts = []
            for line in audit_path.read_text().splitlines():
                row = json.loads(line)
                row["composite_id"] = entries[row["composite_id"]]
                row["link_id"] = links[row["link_id"]]
                attempts.append(json.dumps(row, sort_keys=True))
            audit_path.write_text("".join(row + "\n" for row in attempts))
            summary.update(
                composite_count=len(set(entries.values())),
                matched_composites=matched,
                unmatched_composites=len(set(entries.values())) - matched,
            )
            (temporary / "summary.json").write_text(
                json.dumps(summary, indent=2) + "\n"
            )
            manifest_path = temporary / "manifest.json"
            manifest = json.loads(manifest_path.read_text())
            manifest["identity"] = new_identity
            manifest["artifacts"] = {
                name: sha256_file(temporary / name) for name in CACHE_ARTIFACTS
            }
            manifest["regrouped_from_composite_library_id"] = source.library_id
            manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
            with OverlapIndex(temporary, new_identity):
                pass
            publish_directory_no_replace(temporary, new)
        finally:
            if temporary.exists():
                shutil.rmtree(temporary)
    return new
