"""Source-scoped, full-rule overlap with all extracted single reaction steps.

This is supplementary evidence, never an execution certificate. Catalogs are
immutable and published after every declared corpus reaction is accounted for.
"""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import sqlite3
import tempfile
from collections import Counter
from pathlib import Path

from route_inspector.composite_rules.identity import IDENTITY_POLICY, key_from_smarts
from route_inspector.composite_rules.overlap_cache import (
    InvalidOverlapCache,
    cache_lock,
    quarantine_cache,
)
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.infrastructure.publication import publish_directory_no_replace
from route_inspector.reference_library.browsing import BrowsePage
from route_inspector.reference_library.profile import canonical_json
from route_inspector.routes.access import reaction_nodes, reaction_smiles_from_node
from route_inspector.routes.io import iter_route_json_stream
from route_inspector.rules.evidence import EvidenceCacheError

OVERLAP_VERSION = 4
DEFAULT_OVERLAP_CACHE_ROOT = Path("outputs/gui/single_step_overlap")
CACHE_ARTIFACTS = (
    "catalog.sqlite",
    "summary.json",
    "errors.tsv",
    "composite_sources.jsonl",
)


def runtime_versions():
    from route_inspector.routes.synplanner import route_cgr_compatibility_policy
    from route_inspector.rules.config import dependency_version

    versions = {
        "synplanner": dependency_version("SynPlanner"),
        "chython": dependency_version("chython-synplan"),
    }
    policy = route_cgr_compatibility_policy()
    if policy != "native":
        versions["route_cgr_compatibility"] = policy
    return versions


def cache_identity(library, composites, source_digest):
    from route_inspector.rules.transformation import POLICY

    return {
        "version": OVERLAP_VERSION,
        "identity_policy": POLICY
        if library.tactic_identity_version >= 3
        else IDENTITY_POLICY,
        "source_sha256": source_digest,
        "reference_library_id": library.library_id,
        "composite_library_id": composites.library_id,
        "processing_profile": library.processing_profile.to_dict(),
        "runtime_versions": runtime_versions(),
    }


def cache_key(identity):
    return hashlib.sha256(canonical_json(identity).encode()).hexdigest()


def prepare_overlap_cache(
    source,
    library,
    composites,
    *,
    cache_root=DEFAULT_OVERLAP_CACHE_ROOT,
    progress=None,
    extractor=None,
    evidence_cache=None,
):
    """Prepare or reuse the identity-keyed cache consumed by GUI browsing.

    Accepts both in-memory and persisted composite libraries. All source
    reactions in the declared Reference roster are scanned, independently of the selected composite kinds or
    occurrence limit. Fatal errors propagate; per-reaction failures remain in
    the returned summary and the cache diagnostics.
    """
    identity = cache_identity(library, composites, sha256_file(Path(source)))
    destination = Path(cache_root) / cache_key(identity)
    summary = build_overlap(
        source,
        library,
        composites,
        destination,
        progress=progress,
        extractor=extractor,
        evidence_cache=evidence_cache,
    )
    with OverlapIndex(destination, identity) as index:
        assert index.summary == summary
    return destination, summary


def extractor_from_profile(profile):
    """Restore resolved settings, rejecting silent defaults or runtime drift."""
    try:
        from synplan.chem.reaction.rules.config import RuleExtractionConfig
    except ImportError:
        from synplan.utils.config import RuleExtractionConfig

    from route_inspector.rules.config import resolved_config_mapping
    from route_inspector.rules.extraction import SynPlannerRuleExtractor

    if profile.input_state != "preprocessed":
        raise ValueError("Single-step overlap requires a prepared source dataset")
    recorded = dict(profile.rule_extraction_config)
    versions = recorded.pop("implementation_versions", None)
    if versions != runtime_versions():
        raise ValueError(
            "Recorded extraction runtime differs from the installed runtime"
        )
    payload = dict(recorded)
    payload["func_groups_list"] = [
        value["query_smarts"] if isinstance(value, dict) else value
        for value in payload.get("func_groups_list", [])
    ]
    config = RuleExtractionConfig(**payload)
    if resolved_config_mapping(config) != recorded:
        raise ValueError(
            "Restored extraction configuration differs from the library profile"
        )
    return SynPlannerRuleExtractor(config)


SCHEMA = """
CREATE TABLE rules (id INTEGER PRIMARY KEY, encoding TEXT NOT NULL UNIQUE,
                    status TEXT NOT NULL, smarts TEXT NOT NULL);
CREATE TABLE steps (id TEXT PRIMARY KEY, rule_id INTEGER NOT NULL,
                    route_token TEXT NOT NULL, payload TEXT NOT NULL);
CREATE INDEX steps_rule ON steps(rule_id, id);
CREATE TABLE matches (composite_id TEXT NOT NULL, rule_id INTEGER NOT NULL,
                      PRIMARY KEY(composite_id, rule_id));
"""


def build_overlap(
    source,
    library,
    composites,
    destination,
    *,
    progress=None,
    extractor=None,
    evidence_cache=None,
):
    """Scan the Reference corpus's reactions; audit source routes outside it."""
    source, destination = Path(source), Path(destination)
    digest = sha256_file(source)
    identity = cache_identity(library, composites, digest)
    composites.assert_reference_library(library)
    if composites.manifest.source_routes_sha256 != digest:
        raise ValueError("Composite source-route digest does not match overlap source")
    corpora = library.manifest.reference_corpora
    if len(corpora) != 1 or corpora[0]["input_sha256"] != digest:
        raise ValueError(
            "Overlap requires the current dataset's verified source corpus"
        )
    corpus = corpora[0]
    expected_routes = (
        set(map(str, corpus["route_ids"])) if "route_ids" in corpus else None
    )
    custom_extractor = extractor is not None
    extractor = (
        extractor
        if extractor is not None
        else extractor_from_profile(library.processing_profile)
    )
    with cache_lock(destination):
        cached = _reuse_or_quarantine(destination, identity)
        if cached is not None:
            return cached
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=".overlap-", dir=destination.parent))
    connection = sqlite3.connect(temporary / "catalog.sqlite")
    connection.execute("PRAGMA temp_store=FILE")
    connection.execute("PRAGMA cache_size=-16384")
    counts = Counter(
        total_reactions=0,
        successful_reactions=0,
        skipped_reactions=0,
        failed_reactions=0,
        routes=0,
    )
    statuses = Counter()
    composite_statuses = Counter()
    family_vocabulary = library.tactic_identity_version >= 3
    evidence = None
    if family_vocabulary and not custom_extractor and evidence_cache is not False:
        from route_inspector.rules.config import resolved_config_mapping
        from route_inspector.rules.evidence import RuleEvidenceStore, evidence_path

        evidence = RuleEvidenceStore(
            evidence_path(library.directory or destination)
            if evidence_cache is None
            else evidence_cache,
            resolved_config_mapping(extractor.config),
        )
    try:
        if evidence is not None:
            evidence.db  # Fail before scanning if the reusable store cannot open.
        if family_vocabulary:
            from route_inspector.composite_rules.browsing import CompositeBrowser
            from route_inspector.composite_rules.disk_overlap import (
                DiskSources,
                DiskVocabulary,
            )
            from route_inspector.composite_rules.transformation_overlap import (
                checked_composite_extractor,
                live_composite,
            )

            composite_browser = CompositeBrowser(composites)
            vocabulary = DiskVocabulary(connection, evidence=evidence)
            composite_extractor = checked_composite_extractor(
                library.processing_profile, composites
            )
            sources = DiskSources(connection, composites)
        connection.executescript(SCHEMA)
        with (
            (temporary / "errors.tsv").open("w") as errors,
            (temporary / "composite_sources.jsonl").open("w") as source_audit,
            source.open("rb") as stream,
        ):
            writer = csv.DictWriter(
                errors,
                fieldnames=["route_id", "reaction_node_path", "status", "message"],
                delimiter="\t",
            )
            writer.writeheader()
            route_ids, source_route_ids, excluded_route_ids = set(), set(), set()
            for route_id, route in iter_route_json_stream(stream):
                route_id = str(route_id)
                if route_id in source_route_ids:
                    raise ValueError("Duplicate source route ID")
                source_route_ids.add(route_id)
                if expected_routes is not None and route_id not in expected_routes:
                    excluded_route_ids.add(route_id)
                    writer.writerow(
                        dict(
                            route_id=route_id,
                            reaction_node_path="",
                            status="outside_reference_corpus",
                            message="Route is outside the Reference library's declared route roster",
                        )
                    )
                    continue
                route_ids.add(route_id)
                counts["routes"] += 1
                route_key = {
                    "dataset_id": corpus["dataset_id"],
                    "source_identity": corpus["source_identity"],
                    "route_id": route_id,
                }
                token = canonical_json(route_key)
                if family_vocabulary:
                    for variant, link in sources.get(route_id, ()):
                        attempt = dict(
                            **route_key,
                            composite_id=link.composite_id,
                            mapped_rule=variant[1],
                            link_id=link.link_id,
                            reference_occurrence_id=link.reference_occurrence_id,
                            variant_id=link.variant_id,
                        )
                        composite_statuses["source_attempts"] += 1
                        try:
                            occurrence = composite_browser.verified_occurrence(
                                link, library
                            )
                            attempt["selected_reaction_node_paths"] = [
                                list(path)
                                for path in occurrence.selected_reaction_node_paths
                            ]
                            composite_step = live_composite(
                                link,
                                route,
                                library,
                                composite_extractor,
                                **(
                                    {"evidence": evidence, "occurrence": occurrence}
                                    if evidence is not None
                                    else {}
                                ),
                            )
                            family = vocabulary.rule(composite_step.transformation)
                            vocabulary.add_composite(link.composite_id, family)
                            if sources.reconstructed(variant):
                                composite_statuses["live_query_sides"] += 1
                            composite_statuses["successful_source_reconstructions"] += 1
                            attempt.update(status="reconstructed", rule_family=family)
                        except EvidenceCacheError:
                            raise
                        except Exception as exc:
                            composite_statuses["failed_source_attempts"] += 1
                            attempt.update(
                                status="failed", message=f"{type(exc).__name__}: {exc}"
                            )
                            writer.writerow(
                                dict(
                                    route_id=route_id,
                                    reaction_node_path="",
                                    status="composite_comparison_failed",
                                    message=f"{link.composite_id} / {link.link_id} / {link.reference_occurrence_id}: {type(exc).__name__}: {exc}",
                                )
                            )
                        source_audit.write(canonical_json(attempt) + "\n")
                for path, node in reaction_nodes(route):
                    counts["total_reactions"] += 1
                    try:
                        reaction = reaction_smiles_from_node(node)
                        if evidence is not None:
                            step = evidence.extract("single", reaction, extractor)
                        else:
                            step, _ = extractor.extract(reaction)
                        if step is None:
                            counts["skipped_reactions"] += 1
                            writer.writerow(
                                dict(
                                    route_id=route_id,
                                    reaction_node_path=list(path),
                                    status="skipped",
                                    message="No rule returned by the recorded extraction configuration",
                                )
                            )
                            continue
                        if family_vocabulary:
                            if not step.transformation:
                                raise ValueError(
                                    "Missing live single-step query graphs"
                                )
                            family = vocabulary.rule(step.transformation)
                            from types import SimpleNamespace

                            rule = SimpleNamespace(
                                encoding=canonical_json(step.transformation),
                                status="exact_representation"
                                if "exact_representation" in step.transformation
                                else "live_query_sides",
                            )
                        else:
                            rule = key_from_smarts(step.rule_smarts)
                    except EvidenceCacheError:
                        raise
                    except Exception as exc:
                        counts["failed_reactions"] += 1
                        writer.writerow(
                            dict(
                                route_id=route_id,
                                reaction_node_path=list(path),
                                status="failed",
                                message=f"{type(exc).__name__}: {exc}",
                            )
                        )
                        continue
                    counts["successful_reactions"] += 1
                    statuses[rule.status] += 1
                    if family_vocabulary:
                        connection.execute(
                            "INSERT OR IGNORE INTO rules(id,encoding,status,smarts) VALUES (?,?,?,?)",
                            (family, rule.encoding, rule.status, step.rule_smarts),
                        )
                        rule_id = family
                    else:
                        connection.execute(
                            "INSERT OR IGNORE INTO rules(encoding,status,smarts) VALUES (?,?,?)",
                            (rule.encoding, rule.status, step.rule_smarts),
                        )
                        rule_id = connection.execute(
                            "SELECT id FROM rules WHERE encoding=?", (rule.encoding,)
                        ).fetchone()[0]
                    occurrence_id = hashlib.sha256(
                        canonical_json([route_key, path]).encode()
                    ).hexdigest()
                    metadata = node.get("metadata") or {}
                    row = dict(
                        id=occurrence_id,
                        **route_key,
                        reaction_node_path=list(path),
                        step=str(
                            metadata.get(
                                "step_id",
                                metadata.get("StepId", "/".join(map(str, path))),
                            )
                        ),
                        rule_smarts=step.rule_smarts,
                        reaction_smiles=reaction,
                        identity_status=rule.status,
                    )
                    connection.execute(
                        "INSERT INTO steps VALUES (?,?,?,?)",
                        (occurrence_id, rule_id, token, canonical_json(row)),
                    )
                if progress and counts["routes"] % 100 == 0:
                    progress(
                        "running",
                        f"Preparing overlap evidence: {counts['routes']:,} routes processed",
                    )
            if len(route_ids) != int(corpus["route_count"]):
                raise ValueError("Source route count differs from the library corpus")
            if expected_routes is not None and route_ids != expected_routes:
                raise ValueError("Source route roster differs from the library corpus")
        if sha256_file(source) != digest:
            raise ValueError("Source changed during single-step extraction")
        entry_count = int(composites.manifest.statistics["composite_entry_count"])
        entries = () if family_vocabulary else composites.entries()
        if family_vocabulary:
            composite_statuses["unavailable_live_query"] = sources.missing_count()
            vocabulary.write_matches()
        for entry in () if family_vocabulary else entries:
            rules = [
                entry.composite_rule,
                *(v["normalized_rule"] for v in entry.variants),
            ]
            for smarts in dict.fromkeys(rules):
                rule = key_from_smarts(smarts)
                composite_statuses[rule.status] += 1
                connection.execute(
                    "INSERT OR IGNORE INTO matches SELECT ?, id FROM rules WHERE encoding=?",
                    (entry.composite_id, rule.encoding),
                )
        connection.commit()
        matched = connection.execute(
            "SELECT count(DISTINCT composite_id) FROM matches"
        ).fetchone()[0]
        summary = dict(
            counts,
            source_routes=len(source_route_ids),
            excluded_routes=len(excluded_route_ids),
            excluded_route_ids=sorted(excluded_route_ids),
            unique_rules=connection.execute("SELECT count(*) FROM rules").fetchone()[0],
            composite_count=entry_count,
            matched_composites=matched,
            unmatched_composites=entry_count - matched,
            step_identity_statuses=dict(statuses),
            composite_identity_statuses=dict(composite_statuses),
            **(
                {
                    "matching_metrics": dict(vocabulary.metrics),
                    "comparison_limitations": "All certified sources are attempted; failed reconstructions may hide additional live query families, even for otherwise reconstructed variants. See composite_sources.jsonl and errors.tsv.",
                }
                if family_vocabulary
                else {}
            ),
        )
        if evidence is not None:
            summary["evidence_reuse"] = dict(evidence.metrics)
        assert counts["total_reactions"] == sum(
            counts[k]
            for k in ("successful_reactions", "skipped_reactions", "failed_reactions")
        )
        assert (
            counts["successful_reactions"]
            == connection.execute("SELECT count(*) FROM steps").fetchone()[0]
        )
        connection.close()
        (temporary / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
        manifest = {
            "identity": identity,
            "artifacts": {
                name: sha256_file(temporary / name) for name in CACHE_ARTIFACTS
            },
        }
        (temporary / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
        with OverlapIndex(temporary, identity):
            pass  # Validate the staged result before exposing it to readers.
        with cache_lock(destination):
            cached = _reuse_or_quarantine(destination, identity)
            if cached is not None:
                return cached  # Return the verified winner's summary, not ours.
            publish_directory_no_replace(temporary, destination)
        return summary
    finally:
        if evidence is not None:
            evidence.close()
        connection.close()
        if temporary.exists():
            shutil.rmtree(temporary)


def _reuse_or_quarantine(directory, identity):
    """Called only under cache_lock, after source/profile compatibility checks."""
    if not directory.exists():
        return None
    try:
        with OverlapIndex(directory, identity) as index:
            return index.summary
    except InvalidOverlapCache as exc:
        quarantine_cache(directory, exc)
    return None


class OverlapIndex:
    def __init__(self, directory, identity):
        self.connection = None
        try:
            self._load(Path(directory), identity)
        except BaseException as exc:
            if self.connection is not None:
                self.connection.close()
            if isinstance(
                exc,
                (
                    FileNotFoundError,
                    NotADirectoryError,
                    json.JSONDecodeError,
                    UnicodeDecodeError,
                    KeyError,
                    TypeError,
                ),
            ):
                raise InvalidOverlapCache(
                    f"Invalid single-step overlap cache: {exc}"
                ) from exc
            if isinstance(exc, sqlite3.DatabaseError) and getattr(
                exc, "sqlite_errorcode", None
            ) in {
                sqlite3.SQLITE_CORRUPT,
                sqlite3.SQLITE_NOTADB,
                sqlite3.SQLITE_ERROR,
            }:
                raise InvalidOverlapCache(
                    f"Invalid single-step overlap catalog: {exc}"
                ) from exc
            raise

    def _load(self, directory, identity):
        manifest = json.loads((directory / "manifest.json").read_text())
        if manifest["identity"] != identity:
            raise InvalidOverlapCache("Single-step overlap cache identity mismatch")
        for name in CACHE_ARTIFACTS:
            if sha256_file(directory / name) != manifest["artifacts"][name]:
                raise InvalidOverlapCache("Single-step overlap cache artifact mismatch")
        self.summary = json.loads((directory / "summary.json").read_text())
        for name in (
            "total_reactions",
            "successful_reactions",
            "skipped_reactions",
            "failed_reactions",
            "routes",
            "unique_rules",
            "composite_count",
            "matched_composites",
            "unmatched_composites",
        ):
            value = self.summary[name]
            if type(value) is not int or value < 0:
                raise InvalidOverlapCache(f"Invalid overlap summary count: {name}")
        for name in ("step_identity_statuses", "composite_identity_statuses"):
            if not isinstance(self.summary[name], dict):
                raise InvalidOverlapCache(f"Invalid overlap summary: {name}")
        self.connection = sqlite3.connect(
            (directory / "catalog.sqlite").resolve().as_uri() + "?mode=ro", uri=True
        )
        if self.connection.execute("PRAGMA quick_check").fetchone() != ("ok",):
            raise InvalidOverlapCache("Invalid single-step overlap catalog integrity")
        # Probe every required column, including those only used in evidence views.
        self.connection.execute(
            "SELECT id, encoding, status, smarts FROM rules LIMIT 0"
        )
        self.connection.execute(
            "SELECT id, rule_id, route_token, payload FROM steps LIMIT 0"
        )
        self.connection.execute("SELECT composite_id, rule_id FROM matches LIMIT 0")
        self.matched_ids = frozenset(
            row[0]
            for row in self.connection.execute(
                "SELECT DISTINCT composite_id FROM matches"
            )
        )
        summary = self.summary
        if (
            summary["total_reactions"]
            != sum(
                summary[k]
                for k in (
                    "successful_reactions",
                    "skipped_reactions",
                    "failed_reactions",
                )
            )
            or summary["composite_count"]
            != summary["matched_composites"] + summary["unmatched_composites"]
            or summary["matched_composites"] != len(self.matched_ids)
            or summary["unique_rules"]
            != self.connection.execute("SELECT count(*) FROM rules").fetchone()[0]
            or summary["successful_reactions"]
            != self.connection.execute("SELECT count(*) FROM steps").fetchone()[0]
        ):
            raise InvalidOverlapCache("Single-step overlap summary does not reconcile")

    def close(self):
        self.connection.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def evidence(self, composite_id, *, offset=0, limit=20):
        if offset < 0 or not 1 <= limit <= 200:
            raise ValueError("Invalid evidence page bounds")
        join = (
            "FROM steps s JOIN matches m ON s.rule_id=m.rule_id WHERE m.composite_id=?"
        )
        total, routes = self.connection.execute(
            "SELECT count(*),count(DISTINCT route_token) " + join, (composite_id,)
        ).fetchone()
        rows = tuple(
            json.loads(row[0])
            for row in self.connection.execute(
                "SELECT payload "
                + join
                + " ORDER BY route_token,s.id LIMIT ? OFFSET ?",
                (composite_id, limit, offset),
            )
        )
        return BrowsePage(rows, total, offset, limit), routes

    def step(self, composite_id, step_id):
        row = self.connection.execute(
            "SELECT payload FROM steps s JOIN matches m ON s.rule_id=m.rule_id WHERE m.composite_id=? AND s.id=?",
            (composite_id, step_id),
        ).fetchone()
        if row is None:
            raise ValueError("Single-step evidence does not belong to this composite")
        return json.loads(row[0])
