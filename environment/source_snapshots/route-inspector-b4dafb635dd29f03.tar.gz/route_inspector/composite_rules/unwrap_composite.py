from __future__ import annotations

import copy
import json
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import asdict, dataclass
from itertools import product
from typing import Any

import route_inspector.routes.access as route_access
from route_inspector import chemistry
from route_inspector.composite_rules.validation import (
    CompositeValidationStatus,
    compare_precursor_multisets,
    validate_composite_rule,
)
from route_inspector.tactics.rrseq.unwrap import (
    ChythonOneShotTraceAdapter,
    split_rrseq,
    unwrap_rule_sequence,
)


@dataclass(frozen=True)
class CompositeOccurrenceMatch:
    """One structurally certified composite occurrence in a source route."""

    source_route_id: Any
    reaction_step: str
    reaction_node_path: tuple[int, ...]
    composite_rule: str
    detection_method: str
    application_count: int
    original_tree_node_id: Any | None = None

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["reaction_node_path"] = list(self.reaction_node_path)
        return value


@dataclass(frozen=True)
class CompositeUnwrapDiagnostic:
    """A non-fatal or fatal alternative-level expansion diagnostic."""

    source_route_id: Any
    reaction_step: str
    reaction_node_path: tuple[int, ...]
    composite_rule: str
    rrseq_alternative_index: int | None
    rrseq: str | None
    stage: str
    error_type: str
    message: str

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["reaction_node_path"] = list(self.reaction_node_path)
        return value


@dataclass(frozen=True)
class CompositeOccurrenceUnwrapResult:
    """Expanded routes and auditable occurrence-level provenance."""

    routes_json: dict[str, dict[str, Any]]
    occurrences_by_route: dict[str, tuple[CompositeOccurrenceMatch, ...]]
    variant_counts_by_source_route: dict[str, int]
    diagnostics: tuple[CompositeUnwrapDiagnostic, ...]

    @property
    def matching_route_ids(self) -> tuple[str, ...]:
        return tuple(self.occurrences_by_route)

    @property
    def matched_occurrences(self) -> tuple[CompositeOccurrenceMatch, ...]:
        """Return all certified occurrences in deterministic source-route order."""

        return tuple(
            occurrence
            for occurrences in self.occurrences_by_route.values()
            for occurrence in occurrences
        )

    @property
    def total_occurrences(self) -> int:
        return len(self.matched_occurrences)

    @property
    def total_variants(self) -> int:
        return len(self.routes_json)


def _compact_rule(value: Any) -> str:
    return "".join(str(value).split())


def _validated_unwrappers(
    unwrappers: Mapping[str, Sequence[str]],
) -> dict[str, tuple[str, ...]]:
    if not isinstance(unwrappers, Mapping) or not unwrappers:
        raise ValueError("unwrappers must be a nonempty mapping")

    from chython import smarts

    validated: dict[str, tuple[str, ...]] = {}
    normalized_composites: dict[str, str] = {}
    for raw_composite, raw_alternatives in unwrappers.items():
        composite = str(raw_composite).strip()
        if not composite:
            raise ValueError("composite rule keys cannot be empty")
        if ">>" not in composite:
            raise ValueError(f"composite rule is not a reaction SMARTS: {composite!r}")
        try:
            composite_query = smarts(composite)
        except Exception as exc:
            raise ValueError(f"invalid composite rule {composite!r}: {exc}") from exc
        if _changed_dynamic_bond_count(composite_query) < 1:
            raise ValueError(
                f"bond-change-free composite rule is unsupported: {composite!r}"
            )
        compact = _compact_rule(composite)
        previous = normalized_composites.get(compact)
        if previous is not None:
            raise ValueError(
                "duplicate composite rules after whitespace normalization: "
                f"{previous!r} and {composite!r}"
            )
        normalized_composites[compact] = composite

        if isinstance(raw_alternatives, (str, bytes)) or not isinstance(
            raw_alternatives, Sequence
        ):
            raise TypeError(
                f"RRSeq alternatives for {composite!r} must be a sequence of strings"
            )
        alternatives: list[str] = []
        seen: set[str] = set()
        for raw_rrseq in raw_alternatives:
            rrseq = str(raw_rrseq).strip()
            rules = split_rrseq(rrseq)
            for rule in rules:
                if ">>" not in rule:
                    raise ValueError(
                        f"RRSeq alternative for {composite!r} contains a non-reaction rule"
                    )
                try:
                    smarts(rule)
                except Exception as exc:
                    raise ValueError(
                        f"invalid RRSeq rule in alternative {rrseq!r}: {exc}"
                    ) from exc
            normalized_rrseq = "$".join(rules)
            duplicate_key = "$".join(_compact_rule(rule) for rule in rules)
            if duplicate_key in seen:
                raise ValueError(
                    f"duplicate RRSeq alternative for composite {composite!r}: "
                    f"{normalized_rrseq!r}"
                )
            seen.add(duplicate_key)
            alternatives.append(normalized_rrseq)
        if not alternatives:
            raise ValueError(f"composite rule {composite!r} has no RRSeq alternatives")
        validated[composite] = tuple(alternatives)
    return validated


def _json_key(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def _deduplicate_routes(values: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: dict[str, dict[str, Any]] = {}
    for value in values:
        unique.setdefault(_json_key(value), value)
    return list(unique.values())


def _molecule_smiles(node: Mapping[str, Any]) -> str:
    value = route_access.molecule_node_mapped_smiles(
        dict(node)
    ) or route_access.molecule_node_smiles(dict(node))
    if not value:
        raise ValueError("molecule node has no SMILES")
    return value


def _iter_route_reactions(
    root: dict[str, Any],
) -> Iterable[tuple[int, str, tuple[int, ...], dict[str, Any], dict[str, Any]]]:
    step = 0

    def visit(
        molecule: dict[str, Any], molecule_path: tuple[int, ...]
    ) -> Iterable[tuple[int, str, tuple[int, ...], dict[str, Any], dict[str, Any]]]:
        nonlocal step
        reaction_children = [
            (index, child)
            for index, child in enumerate(molecule.get("children", ()) or ())
            if isinstance(child, dict) and child.get("type") == "reaction"
        ]
        if len(reaction_children) > 1:
            raise ValueError(
                f"molecule path {list(molecule_path)} has more than one reaction child"
            )
        for reaction_index, reaction in reaction_children:
            step += 1
            current = step
            reaction_path = molecule_path + (reaction_index,)
            yield current, f"r{current}", reaction_path, molecule, reaction
            for child_index, child in enumerate(reaction.get("children", ()) or ()):
                if isinstance(child, dict) and child.get("type") == "mol":
                    yield from visit(child, reaction_path + (child_index,))

    yield from visit(root, ())


def _changed_dynamic_bond_count(value: Any) -> int:
    cgr = ~value
    return sum(
        getattr(bond, "order", None) != getattr(bond, "p_order", None)
        for _atom_1, _atom_2, bond in cgr.bonds()
    )


def _changed_dynamic_bond_endpoints(value: Any) -> frozenset[frozenset[int]]:
    cgr = ~value
    return frozenset(
        frozenset((int(atom_1), int(atom_2)))
        for atom_1, atom_2, bond in cgr.bonds()
        if getattr(bond, "order", None) != getattr(bond, "p_order", None)
    )


def _application_count(reaction_smiles: str, composite_rule: str) -> int:
    from chython import smarts

    occurrence_count = _changed_dynamic_bond_count(
        chemistry.parse_reaction(reaction_smiles)
    )
    one_application_count = _changed_dynamic_bond_count(smarts(composite_rule))
    if one_application_count < 1:
        raise ValueError(
            "bond-change-free composites cannot be used for repeated-application "
            "inference"
        )
    quotient, remainder = divmod(occurrence_count, one_application_count)
    if quotient < 1 or remainder:
        raise ValueError(
            "recorded occurrence has a non-integral composite application count: "
            f"{occurrence_count} changed bonds versus {one_application_count} per "
            "composite application"
        )
    return quotient


def _direct_composite_metadata(reaction: Mapping[str, Any]) -> tuple[str, ...]:
    metadata = reaction.get("metadata") or {}
    values = []
    for container in (reaction, metadata):
        for field in ("composite_rule", "rule_smarts"):
            value = container.get(field)
            if value is not None and str(value).strip():
                values.append(str(value).strip())
    return tuple(dict.fromkeys(values))


def _expected_precursors(reaction: Mapping[str, Any]) -> tuple[str, ...]:
    return tuple(
        _molecule_smiles(child)
        for child in reaction.get("children", ()) or ()
        if isinstance(child, dict) and child.get("type") == "mol"
    )


def _canonical_precursor_multiset(molecules: Sequence[Any]) -> tuple[str, ...]:
    values = []
    for molecule in molecules:
        try:
            values.append(chemistry.canonical_molecule_string(molecule))
        except Exception:
            values.append(format(molecule, "m"))
    return tuple(sorted(values))


def _validate_repeated_composite_replay(
    target_smiles: str,
    composite_rule: str,
    expected_precursors: Sequence[str],
    application_count: int,
    *,
    max_outcomes: int,
    adapter: ChythonOneShotTraceAdapter,
) -> tuple[bool, bool]:
    """Return ``(certified, truncated)`` for repeated composite replay."""

    from chython.reactor import Reactor

    reactor = Reactor.from_smarts(
        composite_rule,
        delete_atoms=True,
        one_shot=True,
        automorphism_filter=False,
    )
    initial = (chemistry.parse_molecule(target_smiles),)
    final_outcomes: dict[tuple[str, ...], tuple[Any, ...]] = {}
    truncated = False

    def expand(frontier: tuple[Any, ...], remaining: int) -> None:
        nonlocal truncated
        if truncated:
            return
        if remaining == 0:
            key = _canonical_precursor_multiset(frontier)
            if key not in final_outcomes:
                if len(final_outcomes) >= max_outcomes:
                    truncated = True
                    return
                final_outcomes[key] = frontier
            return
        for molecule_index, molecule in enumerate(frontier):
            enumeration = adapter.enumerate(
                reactor,
                molecule,
                max_unique_outcomes=max_outcomes + 1,
            )
            if enumeration.truncated:
                truncated = True
                return
            for outcome in enumeration.outcomes:
                expand(
                    frontier[:molecule_index]
                    + outcome.products
                    + frontier[molecule_index + 1 :],
                    remaining - 1,
                )
                if truncated:
                    return

    expand(initial, application_count)
    certified = any(
        compare_precursor_multisets(expected_precursors, outcome).chemistry_equivalent
        for outcome in final_outcomes.values()
    )
    return certified, truncated


def _detect_json_occurrences(
    root: dict[str, Any],
    source_route_id: Any,
    unwrappers: Mapping[str, tuple[str, ...]],
    *,
    max_composite_outcomes: int,
) -> tuple[CompositeOccurrenceMatch, ...]:
    compact_to_composite = {
        _compact_rule(composite): composite for composite in unwrappers
    }
    matches: list[CompositeOccurrenceMatch] = []
    for _index, reaction_step, path, target_node, reaction in _iter_route_reactions(
        root
    ):
        if (
            reaction.get("rrseq_step") is not None
            or reaction.get("rule_source") == "RRseq"
        ):
            continue
        direct_values = _direct_composite_metadata(reaction)
        selected = tuple(
            dict.fromkeys(
                compact_to_composite[_compact_rule(value)]
                for value in direct_values
                if _compact_rule(value) in compact_to_composite
            )
        )
        candidates = selected or tuple(unwrappers)
        expected = _expected_precursors(reaction)
        reaction_smiles = route_access.reaction_smiles_from_node(dict(reaction))
        certified: list[str] = []
        for composite in candidates:
            try:
                application_count = _application_count(reaction_smiles, composite)
            except ValueError:
                # A different changed-bond multiplicity is evidence that this
                # configured composite is not the recorded occurrence.
                continue
            if application_count == 1:
                validation = validate_composite_rule(
                    _molecule_smiles(target_node),
                    composite,
                    expected,
                    max_outcomes=max_composite_outcomes,
                )
                candidate_certified = validation.certified
                truncated = (
                    validation.status == CompositeValidationStatus.OUTCOME_LIMIT_REACHED
                )
            else:
                candidate_certified, truncated = _validate_repeated_composite_replay(
                    _molecule_smiles(target_node),
                    composite,
                    expected,
                    application_count,
                    max_outcomes=max_composite_outcomes,
                    adapter=ChythonOneShotTraceAdapter(),
                )
            if truncated:
                raise ValueError(
                    f"route {source_route_id}, {reaction_step}: composite replay "
                    f"reached the {max_composite_outcomes}-outcome limit"
                )
            if candidate_certified:
                certified.append(composite)
        if selected and not certified:
            raise ValueError(
                f"route {source_route_id}, {reaction_step}: metadata-selected "
                "composite does not replay to the recorded precursors"
            )
        if len(certified) > 1:
            raise ValueError(
                f"route {source_route_id}, {reaction_step}: multiple configured "
                f"composites match the recorded occurrence: {certified}"
            )
        if not certified:
            continue
        composite = certified[0]
        matches.append(
            CompositeOccurrenceMatch(
                source_route_id=source_route_id,
                reaction_step=reaction_step,
                reaction_node_path=path,
                composite_rule=composite,
                detection_method="metadata" if selected else "replay",
                application_count=_application_count(reaction_smiles, composite),
                original_tree_node_id=reaction.get(
                    "tree_node_id", reaction.get("node_id")
                ),
            )
        )
    return tuple(matches)


def _tree_rule_locations(
    tree: Any, unwrappers: Mapping[str, tuple[str, ...]]
) -> dict[tuple[Any, int], str]:
    requested = {_compact_rule(rule): rule for rule in unwrappers}
    locations: dict[tuple[Any, int], str] = {}
    found: dict[str, list[tuple[Any, int]]] = {rule: [] for rule in unwrappers}
    for source, rules_by_source in tree.priority_rules.items():
        for rule_id, rule in enumerate(rules_by_source):
            composite = requested.get(_compact_rule(rule))
            if composite is not None:
                found[composite].append((source, rule_id))
    for composite, composite_locations in found.items():
        if not composite_locations:
            raise ValueError(
                f"composite rule {composite!r} is absent from tree.priority_rules"
            )
        if len(composite_locations) > 1:
            raise ValueError(
                f"composite rule {composite!r} is ambiguous in tree.priority_rules: "
                f"{composite_locations}"
            )
        if composite_locations:
            locations[composite_locations[0]] = composite
    return locations


def _export_tree_route(tree: Any, route_id: Any) -> dict[str, Any]:
    """Export one exact SynPlanner route while preserving duplicate branches."""

    from synplan.chem.reaction.routes.representation import extract_reactions

    from route_inspector.routes.synplanner import tree_route_node_ids

    path_ids = tree_route_node_ids(tree, route_id)
    extracted = extract_reactions(tree, route_id=route_id)
    if not extracted or route_id not in extracted:
        raise ValueError(f"SynPlanner could not extract route {route_id}")
    reactions_by_step = extracted[route_id]
    expected_steps = len(path_ids) - 1
    if len(reactions_by_step) != expected_steps:
        raise ValueError(
            f"route {route_id} has {expected_steps} tree steps but "
            f"{len(reactions_by_step)} extracted reactions"
        )

    root_precursor = tree.nodes[path_ids[0]].curr_precursor
    root = {
        "type": "mol",
        "smiles": format(root_precursor.molecule, "m"),
        "in_stock": False,
        "_precursor_object_id": id(root_precursor),
    }
    open_leaves = {id(root_precursor): root}
    for route_step, (parent_id, child_id) in enumerate(
        zip(path_ids, path_ids[1:]), start=1
    ):
        parent_node = tree.nodes[parent_id]
        child_node = tree.nodes[child_id]
        target_node = open_leaves.pop(id(parent_node.curr_precursor), None)
        if target_node is None:
            raise ValueError(
                f"route {route_id}: precursor for tree node {child_id} is not an open leaf"
            )
        reaction = reactions_by_step[expected_steps - route_step]
        unmatched = list(child_node.new_precursors)
        reaction_children: list[dict[str, Any]] = []
        for reactant in reaction.reactants:
            # Several chemically identical precursors may coexist in one tree
            # state. Pair them by the least-changing state-preserving mapped
            # alignment rather than accepting the first graph isomorphism. This
            # retains the persistent lineage and the reaction's branch order.
            ranked_matches: list[tuple[tuple[Any, ...], int]] = []
            for index, precursor in enumerate(unmatched):
                mapping = chemistry.state_preserving_molecule_mapping(
                    reactant, precursor.molecule
                )
                if mapping is not None:
                    ranked_matches.append(
                        (
                            (
                                0,
                                sum(source != target for source, target in mapping),
                                tuple(target for _source, target in mapping),
                                index,
                            ),
                            index,
                        )
                    )
                elif chemistry.mapped_molecules_correspond(
                    reactant, precursor.molecule
                ):
                    # Reaction extraction can lose an aromatic [nH] state. Keep
                    # the stored MCTS molecule in that exceptional case, after
                    # every exact-state candidate has been preferred.
                    ranked_matches.append(((1, index), index))
            matched_index = (
                min(ranked_matches, key=lambda value: value[0])[1]
                if ranked_matches
                else None
            )
            molecule_child: dict[str, Any] = {
                "type": "mol",
                "smiles": format(reactant, "m"),
                "in_stock": True,
            }
            if matched_index is not None:
                precursor = unmatched.pop(matched_index)
                # Preserve the reaction's mapped lineage whenever its atom state
                # already matches the stored MCTS precursor. Replace it only when
                # extraction changed atom state (notably an invalid [n] emitted
                # for a stored [nH] precursor).
                if (
                    chemistry.state_preserving_molecule_mapping(
                        reactant, precursor.molecule
                    )
                    is None
                ):
                    molecule_child["smiles"] = format(precursor.molecule, "m")
                molecule_child["_precursor_object_id"] = id(precursor)
                open_leaves[id(precursor)] = molecule_child
            reaction_children.append(molecule_child)
        if unmatched:
            raise ValueError(
                f"route {route_id}, tree node {child_id}: could not map "
                f"{len(unmatched)} stored precursor(s) into the reaction"
            )
        target_node["in_stock"] = False
        target_node["children"] = [
            {
                "type": "reaction",
                "smiles": format(reaction, "m"),
                "children": reaction_children,
                "node_id": child_id,
                "tree_node_id": child_id,
                "rule_source": child_node.rule_source,
                "rule_id": child_node.rule_id,
                "rule_key": child_node.rule_key,
                "policy_rank": child_node.policy_rank,
            }
        ]

    stack = [root]
    while stack:
        node = stack.pop()
        node.pop("_precursor_object_id", None)
        stack.extend(
            child for child in node.get("children", ()) or () if isinstance(child, dict)
        )
    return root


def _detect_tree_occurrences(
    root: dict[str, Any],
    source_route_id: Any,
    locations: Mapping[tuple[Any, int], str],
) -> tuple[CompositeOccurrenceMatch, ...]:
    matches = []
    for _index, reaction_step, path, _target_node, reaction in _iter_route_reactions(
        root
    ):
        key = (reaction.get("rule_source"), reaction.get("rule_id"))
        composite = locations.get(key)
        if composite is None:
            continue
        reaction_smiles = route_access.reaction_smiles_from_node(reaction)
        matches.append(
            CompositeOccurrenceMatch(
                source_route_id=source_route_id,
                reaction_step=reaction_step,
                reaction_node_path=path,
                composite_rule=composite,
                detection_method="tree_priority_rule",
                application_count=_application_count(reaction_smiles, composite),
                original_tree_node_id=reaction.get(
                    "tree_node_id", reaction.get("node_id")
                ),
            )
        )
    return tuple(matches)


def _leaf_paths(root: dict[str, Any]) -> tuple[tuple[int, ...], ...]:
    found: list[tuple[int, ...]] = []

    def visit(node: dict[str, Any], path: tuple[int, ...]) -> None:
        children = node.get("children", ()) or ()
        if node.get("type") == "mol" and not children:
            found.append(path)
            return
        for index, child in enumerate(children):
            if isinstance(child, dict):
                visit(child, path + (index,))

    visit(root, ())
    return tuple(found)


def _node_at_path(root: dict[str, Any], path: tuple[int, ...]) -> dict[str, Any]:
    node = root
    for index in path:
        node = node["children"][index]
    return node


def _replace_at_path(
    root: dict[str, Any], path: tuple[int, ...], replacement: dict[str, Any]
) -> None:
    parent = _node_at_path(root, path[:-1])
    parent["children"][path[-1]] = replacement


def _enumerate_rrseq_roots(
    target_smiles: str,
    rrseq: str,
    *,
    adapter: ChythonOneShotTraceAdapter,
) -> tuple[dict[str, Any], ...]:
    from chython.reactor import Reactor

    rule_smarts = split_rrseq(rrseq)
    reactors = tuple(
        Reactor.from_smarts(
            rule,
            delete_atoms=False,
            one_shot=True,
            automorphism_filter=False,
        )
        for rule in rule_smarts
    )

    def expand(step_index: int, active_molecule: Any) -> Iterable[dict[str, Any]]:
        enumeration = adapter.enumerate(
            reactors[step_index],
            active_molecule,
        )
        for outcome in enumeration.outcomes:
            products_now = outcome.products
            if not products_now:
                continue
            if step_index == len(reactors) - 1:
                child_sets: Iterable[list[dict[str, Any]]] = (
                    [
                        {
                            "type": "mol",
                            "smiles": format(product_molecule, "m"),
                            "in_stock": False,
                        }
                        for product_molecule in products_now
                    ],
                )
            else:
                continued: list[list[dict[str, Any]]] = []
                for active_index, product_molecule in enumerate(products_now):
                    for continuation in expand(step_index + 1, product_molecule):
                        children = [
                            {
                                "type": "mol",
                                "smiles": format(sibling, "m"),
                                "in_stock": False,
                            }
                            for sibling in products_now
                        ]
                        children[active_index] = continuation
                        continued.append(children)
                child_sets = continued
            for children in child_sets:
                yield {
                    "type": "mol",
                    "smiles": format(active_molecule, "m"),
                    "in_stock": False,
                    "children": [
                        {
                            "type": "reaction",
                            "smiles": outcome.reaction_smiles,
                            "children": children,
                        }
                    ],
                }

    return tuple(
        _deduplicate_routes(expand(0, chemistry.parse_molecule(target_smiles)))
    )


def _enumerate_repeated_rrseq_roots(
    target_smiles: str,
    rrseq: str,
    application_count: int,
    *,
    adapter: ChythonOneShotTraceAdapter,
) -> tuple[dict[str, Any], ...]:
    if application_count < 1:
        raise ValueError("application_count must be positive")
    first = _enumerate_rrseq_roots(target_smiles, rrseq, adapter=adapter)
    if application_count == 1:
        return first
    repeated: list[dict[str, Any]] = []
    for first_application in first:
        for leaf_path in _leaf_paths(first_application):
            leaf_smiles = _molecule_smiles(_node_at_path(first_application, leaf_path))
            for continuation in _enumerate_repeated_rrseq_roots(
                leaf_smiles,
                rrseq,
                application_count - 1,
                adapter=adapter,
            ):
                candidate = copy.deepcopy(first_application)
                _replace_at_path(candidate, leaf_path, copy.deepcopy(continuation))
                repeated.append(candidate)
    return tuple(_deduplicate_routes(repeated))


def _reattach_original_children(
    generated_root: dict[str, Any], original_children: Sequence[dict[str, Any]]
) -> list[dict[str, Any]]:
    # Reattach every recorded precursor, including terminal duplicates. Besides
    # retaining node metadata and stock state, this preserves distinct symmetric
    # assignments when equivalent precursor branches carry different mapped
    # lineages. Extra leaves introduced by the RRSeq remain generated stock nodes.
    original_branches = [
        child
        for child in original_children
        if isinstance(child, dict) and child.get("type") == "mol"
    ]
    paths = _leaf_paths(generated_root)
    leaf_molecules = [
        chemistry.parse_molecule(_molecule_smiles(_node_at_path(generated_root, path)))
        for path in paths
    ]
    original_molecules = [
        chemistry.parse_molecule(_molecule_smiles(child)) for child in original_branches
    ]
    candidates: list[list[int]] = []
    candidate_evidence: list[dict[int, dict[str, Any]]] = []
    for original in original_molecules:
        original_atom_ids = {int(atom_id) for atom_id in original}
        evidence_by_leaf: dict[int, dict[str, Any]] = {}
        overlap_evidence: list[tuple[int, int, list[int]]] = []
        for leaf_index, generated in enumerate(leaf_molecules):
            if chemistry.mapped_molecules_correspond(original, generated):
                evidence_by_leaf[leaf_index] = {"mode": "exact_graph"}
                continue
            generated_atom_ids = {int(atom_id) for atom_id in generated}
            shared = {
                atom_id
                for atom_id in original_atom_ids & generated_atom_ids
                if (
                    original.atom(atom_id).atomic_number,
                    original.atom(atom_id).isotope,
                )
                == (
                    generated.atom(atom_id).atomic_number,
                    generated.atom(atom_id).isotope,
                )
            }
            missing = original_atom_ids - shared
            overlap_evidence.append((leaf_index, len(shared), sorted(missing)))
            if not missing:
                evidence_by_leaf[leaf_index] = {
                    "mode": "mapped_lineage_projection",
                    "shared_atom_map_count": len(shared),
                    "missing_downstream_atom_maps": [],
                }
            elif len(shared) >= max(1, len(original_atom_ids) - 1):
                # SynPlanner tree molecules can disagree with the recorded
                # reaction on one locally introduced atom map (for example O40
                # versus O41). Preserve the otherwise complete mapped lineage,
                # and make the exception explicit in the output route.
                evidence_by_leaf[leaf_index] = {
                    "mode": "mapped_lineage_projection_with_local_map_mismatch",
                    "shared_atom_map_count": len(shared),
                    "missing_downstream_atom_maps": sorted(missing),
                }
        if not evidence_by_leaf and overlap_evidence:
            best_overlap = max(value[1] for value in overlap_evidence)
            if best_overlap:
                # Historical SynPlanner composite routes can place the next
                # priority-rule target across a boundary that the declared
                # elementary RRSeq has already split. There is then no complete
                # graph or map-set witness. Preserve one deterministic maximum-
                # lineage handoff and expose its incomplete coverage explicitly.
                leaf_index, shared_count, missing = next(
                    value for value in overlap_evidence if value[1] == best_overlap
                )
                evidence_by_leaf[leaf_index] = {
                    "mode": "mapped_lineage_maximum_overlap_projection",
                    "shared_atom_map_count": shared_count,
                    "downstream_atom_map_count": len(original_atom_ids),
                    "missing_downstream_atom_maps": missing,
                }
        candidates.append(list(evidence_by_leaf))
        candidate_evidence.append(evidence_by_leaf)
    if any(not values for values in candidates):
        return []

    assignments: list[tuple[int, ...]] = []

    def assign(index: int, used: set[int], chosen: list[int]) -> None:
        if index == len(original_branches):
            assignments.append(tuple(chosen))
            return
        for leaf_index in candidates[index]:
            if leaf_index in used:
                continue
            used.add(leaf_index)
            chosen.append(leaf_index)
            assign(index + 1, used, chosen)
            chosen.pop()
            used.remove(leaf_index)

    assign(0, set(), [])
    attached = []
    for assignment in assignments:
        candidate = copy.deepcopy(generated_root)
        for original_index, leaf_index in enumerate(assignment):
            replacement = copy.deepcopy(original_branches[original_index])
            reattachment = dict(candidate_evidence[original_index][leaf_index])
            mode = reattachment["mode"]
            if mode != "exact_graph":
                metadata = replacement.setdefault("metadata", {})
                reattachment.update(
                    {
                        "generated_leaf_smiles": _molecule_smiles(
                            _node_at_path(candidate, paths[leaf_index])
                        ),
                        "downstream_branch_smiles": _molecule_smiles(replacement),
                    }
                )
                metadata["composite_unwrap_branch_reattachment"] = reattachment
            _replace_at_path(
                candidate,
                paths[leaf_index],
                replacement,
            )
        assigned = set(assignment)
        for leaf_index, path in enumerate(paths):
            if leaf_index not in assigned:
                _node_at_path(candidate, path)["in_stock"] = True
        attached.append(candidate)
    return _deduplicate_routes(attached)


def _generated_reactions(root: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        reaction
        for _index, _step, _path, _target, reaction in _iter_route_reactions(root)
        if reaction.get("rule_source") is None
    ]


def _generated_route_covers_occurrence_changes(
    generated_root: dict[str, Any], original_reaction: Mapping[str, Any]
) -> bool:
    source_reaction = chemistry.parse_reaction(
        route_access.reaction_smiles_from_node(dict(original_reaction))
    )
    source_changes = _changed_dynamic_bond_endpoints(source_reaction)
    target = chemistry.parse_molecule(_molecule_smiles(generated_root))
    _product_index, source_product = chemistry.find_matching_molecule(
        source_reaction.products,
        target,
    )
    if source_product is not None:
        mapping = chemistry.state_preserving_molecule_mapping(
            source_product,
            target,
        )
        if mapping is None:
            best_mapping = None
            best_key = None
            try:
                graph_mappings = source_product.get_mapping(
                    target,
                    automorphism_filter=False,
                )
                for mapping_index, raw_mapping in enumerate(graph_mappings, start=1):
                    if mapping_index > 10_000:
                        break
                    candidate = tuple(
                        sorted(
                            (int(source), int(destination))
                            for source, destination in raw_mapping.items()
                        )
                    )
                    key = (
                        sum(source != destination for source, destination in candidate),
                        tuple(destination for _source, destination in candidate),
                    )
                    if best_key is None or key < best_key:
                        best_mapping = candidate
                        best_key = key
            except Exception:
                best_mapping = None
            mapping = best_mapping
        if mapping is not None:
            translated = dict(mapping)
            source_changes = frozenset(
                frozenset(
                    (translated.get(atom_1, atom_1), translated.get(atom_2, atom_2))
                )
                for atom_1, atom_2 in (tuple(pair) for pair in source_changes)
            )
    generated_changes: set[frozenset[int]] = set()
    for reaction in _generated_reactions(generated_root):
        generated_changes.update(
            _changed_dynamic_bond_endpoints(
                chemistry.parse_reaction(
                    route_access.reaction_smiles_from_node(reaction)
                )
            )
        )
    return source_changes.issubset(generated_changes)


def _annotate_generated_reactions(
    root: dict[str, Any],
    original_reaction: Mapping[str, Any],
    match: CompositeOccurrenceMatch,
    rrseq: str,
    alternative_index: int,
    alternative_count: int,
) -> None:
    rules_in_rrseq = split_rrseq(rrseq)
    generated = _generated_reactions(root)
    expected_count = len(rules_in_rrseq) * match.application_count
    if len(generated) != expected_count:
        raise ValueError(
            f"generated {len(generated)} reactions but expected {expected_count} "
            "from the RRSeq length and repeated-application count"
        )
    original_id = original_reaction.get(
        "tree_node_id", original_reaction.get("node_id", match.reaction_step)
    )
    for sequence_index, reaction in enumerate(generated, start=1):
        rule_index = (sequence_index - 1) % len(rules_in_rrseq)
        application_index = (sequence_index - 1) // len(rules_in_rrseq) + 1
        expanded_id = f"{original_id}.{alternative_index}.{sequence_index}"
        reaction.update(
            {
                "node_id": expanded_id,
                "tree_node_id": expanded_id,
                "source_route_id": match.source_route_id,
                "original_reaction_path": list(match.reaction_node_path),
                "original_tree_node_id": match.original_tree_node_id,
                "rule_source": "RRseq",
                "rule_id": rule_index,
                "rule_key": f"RRseq:{sequence_index}",
                "rrseq": rrseq,
                "rrseq_step": rule_index + 1,
                "rrseq_sequence_step": sequence_index,
                "rrseq_application": application_index,
                "rrseq_rule": rules_in_rrseq[rule_index],
                "rrseq_alternative_index": alternative_index,
                "rrseq_alternative_count": alternative_count,
                "composite_rule": match.composite_rule,
                "original_composite_rule": match.composite_rule,
            }
        )


def _expand_route_molecule(
    molecule_node: dict[str, Any],
    molecule_path: tuple[int, ...],
    matches_by_path: Mapping[tuple[int, ...], CompositeOccurrenceMatch],
    unwrappers: Mapping[str, tuple[str, ...]],
    diagnostics: list[CompositeUnwrapDiagnostic],
    *,
    adapter: ChythonOneShotTraceAdapter,
) -> list[dict[str, Any]]:
    reaction_children = [
        (index, child)
        for index, child in enumerate(molecule_node.get("children", ()) or ())
        if isinstance(child, dict) and child.get("type") == "reaction"
    ]
    if not reaction_children:
        return [copy.deepcopy(molecule_node)]
    if len(reaction_children) != 1:
        raise ValueError(
            f"molecule path {list(molecule_path)} has more than one reaction child"
        )

    reaction_index, original_reaction = reaction_children[0]
    reaction_path = molecule_path + (reaction_index,)
    child_options: list[list[dict[str, Any]]] = []
    for child_index, child in enumerate(original_reaction.get("children", ()) or ()):
        if isinstance(child, dict) and child.get("type") == "mol":
            child_options.append(
                _expand_route_molecule(
                    child,
                    reaction_path + (child_index,),
                    matches_by_path,
                    unwrappers,
                    diagnostics,
                    adapter=adapter,
                )
            )
        else:
            child_options.append([copy.deepcopy(child)])

    variants: list[dict[str, Any]] = []
    match = matches_by_path.get(reaction_path)
    for children in product(*child_options):
        expanded_children = tuple(copy.deepcopy(child) for child in children)
        if match is None:
            reaction = copy.deepcopy(original_reaction)
            reaction["children"] = list(expanded_children)
            parent = copy.deepcopy(molecule_node)
            parent["children"] = [reaction]
            variants.append(parent)
            continue

        alternatives = unwrappers[match.composite_rule]
        successful_for_children = 0
        for alternative_index, rrseq in enumerate(alternatives, start=1):
            try:
                generated_roots = _enumerate_repeated_rrseq_roots(
                    _molecule_smiles(molecule_node),
                    rrseq,
                    match.application_count,
                    adapter=adapter,
                )
                site_matched_roots = tuple(
                    generated_root
                    for generated_root in generated_roots
                    if _generated_route_covers_occurrence_changes(
                        generated_root, original_reaction
                    )
                )
                if site_matched_roots:
                    generated_roots = site_matched_roots
                    change_coverage = "mapped_dynamic_bonds_covered"
                else:
                    # Some archived priority-rule applications have a mapped
                    # reaction center that no declared RRSeq reactor outcome can
                    # reproduce. Keep the declared outcomes, but preserve that
                    # failure explicitly instead of claiming site certification.
                    change_coverage = (
                        "unresolved_no_outcome_covers_mapped_dynamic_bonds"
                    )
                for generated_root in generated_roots:
                    for generated_reaction in _generated_reactions(generated_root):
                        generated_reaction["composite_occurrence_change_coverage"] = (
                            change_coverage
                        )
                    _annotate_generated_reactions(
                        generated_root,
                        original_reaction,
                        match,
                        rrseq,
                        alternative_index,
                        len(alternatives),
                    )
                attached_variants = [
                    attached
                    for generated_root in generated_roots
                    for attached in _reattach_original_children(
                        generated_root, expanded_children
                    )
                ]
                attached_variants = _deduplicate_routes(attached_variants)
                if not attached_variants:
                    raise ValueError(
                        "RRSeq generated no branch assignment matching the recorded "
                        "precursors"
                    )
                for attached in attached_variants:
                    parent = copy.deepcopy(molecule_node)
                    parent["children"] = attached.get("children", [])
                    variants.append(parent)
                successful_for_children += len(attached_variants)
            except Exception as exc:
                diagnostics.append(
                    CompositeUnwrapDiagnostic(
                        source_route_id=match.source_route_id,
                        reaction_step=match.reaction_step,
                        reaction_node_path=match.reaction_node_path,
                        composite_rule=match.composite_rule,
                        rrseq_alternative_index=alternative_index,
                        rrseq=rrseq,
                        stage="rrseq_expansion",
                        error_type=type(exc).__name__,
                        message=str(exc),
                    )
                )
        if successful_for_children == 0:
            diagnostics.append(
                CompositeUnwrapDiagnostic(
                    source_route_id=match.source_route_id,
                    reaction_step=match.reaction_step,
                    reaction_node_path=match.reaction_node_path,
                    composite_rule=match.composite_rule,
                    rrseq_alternative_index=None,
                    rrseq=None,
                    stage="composite_occurrence",
                    error_type="NoValidAlternative",
                    message=(
                        f"none of {len(alternatives)} RRSeq alternatives could "
                        "reproduce this branch combination"
                    ),
                )
            )
    if not variants and match is not None:
        raise ValueError(
            f"route {match.source_route_id}, {match.reaction_step}: none of "
            f"{len(unwrappers[match.composite_rule])} RRSeq alternatives could "
            "reproduce the occurrence"
        )
    return _deduplicate_routes(variants)


def _root_assignments(root: dict[str, Any]) -> list[dict[str, Any]]:
    selected: dict[tuple[Any, str, int, str], dict[str, Any]] = {}
    for _index, _step, _path, _target, reaction in _iter_route_reactions(root):
        if reaction.get("rule_source") != "RRseq":
            continue
        key = (
            reaction.get("original_tree_node_id"),
            _json_key(reaction.get("original_reaction_path")),
            int(reaction["rrseq_alternative_index"]),
            str(reaction["rrseq"]),
        )
        selected.setdefault(
            key,
            {
                "original_tree_node_id": reaction.get("original_tree_node_id"),
                "original_reaction_path": reaction.get("original_reaction_path"),
                "composite_rule": reaction.get("composite_rule"),
                "rrseq": reaction.get("rrseq"),
                "rrseq_alternative_index": reaction.get("rrseq_alternative_index"),
                "rrseq_alternative_count": reaction.get("rrseq_alternative_count"),
            },
        )
    return sorted(
        selected.values(),
        key=lambda value: (
            tuple(value.get("original_reaction_path") or ()),
            int(value["rrseq_alternative_index"]),
            str(value["rrseq"]),
        ),
    )


def _contains_expanded_rrseq_reaction(root: dict[str, Any]) -> bool:
    return any(
        reaction.get("rrseq_step") is not None or reaction.get("rule_source") == "RRseq"
        for _index, _step, _path, _target, reaction in _iter_route_reactions(root)
    )


def unwrap_composite_occurrences(
    *,
    unwrappers: Mapping[str, Sequence[str]],
    tree: Any | None = None,
    routes_json: route_access.RouteCollection | None = None,
    route_ids: Iterable[Any] | None = None,
    max_composite_outcomes: int = 256,
) -> CompositeOccurrenceUnwrapResult:
    """Expand configured composite occurrences into every valid RRSeq variant.

    Exactly one source must be provided. Plain route JSON is matched by certified
    composite replay; SynPlanner trees are matched through their priority-rule IDs.
    Neither input is mutated.
    """

    if (tree is None) == (routes_json is None):
        raise ValueError("supply exactly one of tree or routes_json")
    if max_composite_outcomes < 1:
        raise ValueError("max_composite_outcomes must be at least 1")
    if isinstance(route_ids, (str, bytes)):
        raise TypeError("route_ids must be an iterable of route IDs, not a string")
    configured = _validated_unwrappers(unwrappers)
    adapter = ChythonOneShotTraceAdapter()
    diagnostics: list[CompositeUnwrapDiagnostic] = []

    source_routes: list[
        tuple[Any, dict[str, Any], tuple[CompositeOccurrenceMatch, ...]]
    ] = []
    passthrough_routes: list[tuple[Any, dict[str, Any]]] = []
    if tree is not None:
        from route_inspector.routes.synplanner import tree_route_node_ids

        locations = _tree_rule_locations(tree, configured)
        selected_route_ids = (
            list(route_ids) if route_ids is not None else list(tree.winning_nodes)
        )
        for source_route_id in selected_route_ids:
            # Resolve the route early so invalid filters fail clearly.
            path_ids = tree_route_node_ids(tree, source_route_id)
            if not any(
                (
                    tree.nodes[node_id].rule_source,
                    tree.nodes[node_id].rule_id,
                )
                in locations
                for node_id in path_ids[1:]
            ):
                continue
            root = _export_tree_route(tree, source_route_id)
            occurrences = _detect_tree_occurrences(root, source_route_id, locations)
            if occurrences:
                source_routes.append((source_route_id, root, occurrences))
    else:
        assert routes_json is not None
        if route_ids is None:
            selected_items = list(route_access.route_items(routes_json))
        else:
            selected_items = [
                (route_id, route_access.route_by_id(routes_json, route_id))
                for route_id in route_ids
            ]
        for source_route_id, source_root in selected_items:
            root = copy.deepcopy(source_root)
            occurrences = _detect_json_occurrences(
                root,
                source_route_id,
                configured,
                max_composite_outcomes=max_composite_outcomes,
            )
            if occurrences:
                source_routes.append((source_route_id, root, occurrences))
            elif _contains_expanded_rrseq_reaction(root):
                # A second call on this function's output must not expand the
                # generated RRSeq steps again or renumber the variants.
                passthrough_routes.append((source_route_id, root))

    expanded_routes: dict[str, dict[str, Any]] = {
        str(route_id): copy.deepcopy(root) for route_id, root in passthrough_routes
    }
    occurrences_by_route: dict[str, tuple[CompositeOccurrenceMatch, ...]] = {}
    variant_counts: dict[str, int] = {}
    for _route_id, passthrough in passthrough_routes:
        source_key = str(passthrough.get("source_route_id", _route_id))
        variant_counts[source_key] = variant_counts.get(source_key, 0) + 1
    for source_route_id, root, occurrences in source_routes:
        source_key = str(source_route_id)
        matches_by_path = {match.reaction_node_path: match for match in occurrences}
        variants = _expand_route_molecule(
            root,
            (),
            matches_by_path,
            configured,
            diagnostics,
            adapter=adapter,
        )
        if not variants:
            raise RuntimeError(
                f"route {source_route_id} produced no valid RRSeq expansion"
            )
        variants.sort(key=_json_key)
        occurrences_by_route[source_key] = occurrences
        variant_counts[source_key] = len(variants)
        for variant_index, variant in enumerate(variants, start=1):
            expanded_route_id = f"{source_route_id}.{variant_index}"
            variant["node_id"] = expanded_route_id
            variant["source_route_id"] = source_route_id
            if tree is not None:
                variant["source_node_id"] = source_route_id
            variant["variant_index"] = variant_index
            variant["composite_occurrences"] = [
                match.to_dict() for match in occurrences
            ]
            variant["composite_unwrap_assignments"] = _root_assignments(variant)
            expanded_routes[expanded_route_id] = variant

    unique_diagnostics = {
        _json_key(diagnostic.to_dict()): diagnostic for diagnostic in diagnostics
    }
    return CompositeOccurrenceUnwrapResult(
        routes_json=expanded_routes,
        occurrences_by_route=occurrences_by_route,
        variant_counts_by_source_route=variant_counts,
        diagnostics=tuple(unique_diagnostics.values()),
    )


def unwrap_composite_rule(
    target_smiles: str,
    composite_rule: str,
    *,
    route_id: int = 0,
    mark_leaves_in_stock: bool = True,
) -> dict[int, dict[str, Any]]:
    """Unwrap composite rule into a retrosynthetic route.

    The composite rule is treated as a one-step retrosynthetic template so the
    generated route matches the reactants produced during extraction.
    """
    return unwrap_rule_sequence(
        target_smiles,
        [composite_rule],
        route_id=route_id,
        rule_key_prefix="composite",
        mark_leaves_in_stock=mark_leaves_in_stock,
    ).routes_json


__all__ = [
    "CompositeOccurrenceMatch",
    "CompositeOccurrenceUnwrapResult",
    "CompositeUnwrapDiagnostic",
    "unwrap_composite_occurrences",
    "unwrap_composite_rule",
]
