"""Overlap-cache recovery primitives; readers never mutate cached evidence."""

import json
import os
import uuid
from contextlib import contextmanager


class InvalidOverlapCache(ValueError):
    """Persisted overlap evidence is incomplete, corrupt, or incompatible."""


@contextmanager
def cache_lock(directory):
    """Serialize inspection, quarantine and publication across worker processes.

    Keep the lock file: unlinking it would let different processes lock different
    inodes. Extraction happens outside this short critical section.
    """
    directory.parent.mkdir(parents=True, exist_ok=True)
    with (directory.parent / f".{directory.name}.lock").open("a+b") as lock:
        if os.name == "nt":
            import msvcrt

            if lock.tell() == 0:
                lock.write(b"\0")
                lock.flush()
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl

            fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            yield
        finally:
            if os.name == "nt":
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock, fcntl.LOCK_UN)


def quarantine_cache(directory, reason):
    """Preserve damaged evidence and its reason under a unique sibling name.

    The caller must hold cache_lock and revalidate immediately before moving.
    Permission and other filesystem failures propagate; they are not corruption.
    """
    quarantine = directory.parent / f".{directory.name}.invalid-{uuid.uuid4().hex}"
    directory.rename(quarantine)
    (quarantine.parent / f"{quarantine.name}.json").write_text(
        json.dumps({"cache": directory.name, "reason": str(reason)}, indent=2) + "\n"
    )
    return quarantine
