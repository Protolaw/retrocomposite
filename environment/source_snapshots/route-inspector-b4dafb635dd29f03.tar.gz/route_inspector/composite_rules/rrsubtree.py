"""Certified composite construction and expansion for ``RRSubtree_cons``.

Native RRSubtree occurrences remain analysis-oriented motifs.  This module adds
an executable, occurrence-level derivative only after the selected rule tree,
its recorded route boundary, and the extracted net composite all agree under
exact constitutional and target-lineage comparison.
"""

from __future__ import annotations

import copy
import hashlib
import json
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import asdict, dataclass, field, replace
from itertools import product
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Literal

import route_inspector.routes.access as route_access
from route_inspector import chemistry
from route_inspector.composite_rules._atom_mapping import normalize_route_atom_mapping
from route_inspector.composite_rules.composite import (
    CompositeRuleExtractor,
    build_composite_candidate,
    normalize_pseudo_reaction_mapping,
)
from route_inspector.composite_rules.validation import (
    ABSTRACTION_BOUNDARY_POLICY,
    CompositeValidationStatus,
    PrecursorComparison,
    abstract_precursor_boundary,
    compare_precursor_multisets,
    validate_abstract_composite_rule,
    validate_composite_rule,
)
from route_inspector.reference_library.models import TacticOccurrence
from route_inspector.tactics.rrseq.occurrences import RRseqConsOccurrence
from route_inspector.tactics.rrseq.unwrap import (
    ChythonOneShotTraceAdapter,
    RuleApplicationError,
)
from route_inspector.tactics.rrsubtree.models import (
    NodePath,
    RRSubtreeNode,
    RRSubtreeOccurrence,
)

CompositeSourceKind = Literal["rrseq_cons", "rrsubtree_cons"]


class RRSubtreeCompositeError(ValueError):
    """Base error for invalid or chemically unsupported subtree composites."""


class RRSubtreeCompositeOutcomeLimitError(RRSubtreeCompositeError):
    """Raised when bounded enumeration cannot complete a source certificate."""


@dataclass(frozen=True)
class RRSubtreeReplayTrace:
    """Compact selected-outcome evidence for one logical subtree node."""

    reaction_node_path: NodePath
    rule_smarts: str
    input_smiles: str
    selected_outcome_index: int
    reaction_smiles: str
    child_product_assignments: tuple[tuple[NodePath, int], ...]
    query_to_target_mappings: tuple[tuple[tuple[int, int], ...], ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "reaction_node_path": list(self.reaction_node_path),
            "rule_smarts": self.rule_smarts,
            "input_smiles": self.input_smiles,
            "selected_outcome_index": self.selected_outcome_index,
            "reaction_smiles": self.reaction_smiles,
            "child_product_assignments": [
                {"child_reaction_node_path": list(path), "product_index": index}
                for path, index in self.child_product_assignments
            ],
            "query_to_target_mappings": [
                [list(pair) for pair in mapping]
                for mapping in self.query_to_target_mappings
            ],
        }


@dataclass(frozen=True)
class RRSubtreeSourceReplay:
    """Bounded replay result compared with one recorded route boundary."""

    status: str
    accepted_variant_count: int
    generated_variant_count: int
    truncated: bool
    comparison: PrecursorComparison | None
    traces: tuple[RRSubtreeReplayTrace, ...]
    error_type: str | None = None
    error_message: str | None = None

    @property
    def certified(self) -> bool:
        return (
            self.status in {"validated_unique", "validated_ambiguous"}
            and self.comparison is not None
            and self.comparison.chemistry_equivalent
            and self.comparison.mapping_consistent
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "accepted_variant_count": self.accepted_variant_count,
            "generated_variant_count": self.generated_variant_count,
            "truncated": self.truncated,
            "certified": self.certified,
            "comparison": (
                None if self.comparison is None else self.comparison.to_dict()
            ),
            "traces": [trace.to_dict() for trace in self.traces],
            "error_type": self.error_type,
            "error_message": self.error_message,
        }


@dataclass(frozen=True)
class RRSubtreeCompositeDecomposition:
    """One source-certified RRSubtree decomposition of an exact composite."""

    composite_rule: str
    reference_occurrence_id: str
    occurrence: RRSubtreeOccurrence = field(repr=False, compare=False)
    tactic_entry_id: str | None = None
    certificate_status: str = "validated_unique"
    boundary_policy: str = "full_recorded_boundary"

    def __post_init__(self) -> None:
        if self.boundary_policy not in {
            "full_recorded_boundary",
            ABSTRACTION_BOUNDARY_POLICY,
        }:
            raise ValueError("unsupported composite boundary policy")
        if self.occurrence.kind != "cons":
            raise ValueError("composite decompositions require RRSubtree_cons")
        if not self.composite_rule.strip():
            raise ValueError("composite_rule must not be empty")
        if not self.reference_occurrence_id:
            raise ValueError("reference_occurrence_id must not be empty")
        if self.certificate_status not in {
            "validated_unique",
            "validated_ambiguous",
        }:
            raise ValueError("RRSubtree decomposition is not replay-certified")


@dataclass(frozen=True)
class CompositeConstructionResult:
    """One library occurrence's composite construction and replay certificate."""

    kind: CompositeSourceKind
    reference_occurrence_id: str
    native_occurrence_id: str
    route_id: str
    composite_rule: str | None
    pseudo_reaction_smiles: str | None
    accepted: bool
    validation_status: str
    source_replay: Mapping[str, Any]
    composite_validation: Mapping[str, Any] | None
    boundary_precursor_node_paths: tuple[NodePath, ...] = ()
    all_edges_rrseq_connected: bool | None = None
    diagnostics: tuple[Mapping[str, Any], ...] = ()
    decomposition: RRSubtreeCompositeDecomposition | None = field(
        default=None,
        repr=False,
        compare=False,
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "reference_occurrence_id": self.reference_occurrence_id,
            "native_occurrence_id": self.native_occurrence_id,
            "route_id": self.route_id,
            "composite_rule": self.composite_rule,
            "pseudo_reaction_smiles": self.pseudo_reaction_smiles,
            "accepted": self.accepted,
            "validation_status": self.validation_status,
            "source_replay": dict(self.source_replay),
            "composite_validation": (
                None
                if self.composite_validation is None
                else dict(self.composite_validation)
            ),
            "boundary_precursor_node_paths": [
                list(path) for path in self.boundary_precursor_node_paths
            ],
            "all_edges_rrseq_connected": self.all_edges_rrseq_connected,
            "diagnostics": [dict(value) for value in self.diagnostics],
        }


@dataclass(frozen=True)
class RRSubtreeCompositeDiagnostic:
    """One bounded alternative-level expansion diagnostic."""

    reference_occurrence_id: str
    stage: str
    error_type: str
    message: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RRSubtreeCompositeVariant:
    """One target-specific certified RRSubtree expansion."""

    variant_id: str
    reference_occurrence_id: str
    tactic_entry_id: str | None
    composite_outcome_index: int
    route: Mapping[str, Any]
    traces: tuple[RRSubtreeReplayTrace, ...]
    precursor_comparison: PrecursorComparison

    def to_dict(self) -> dict[str, Any]:
        return {
            "variant_id": self.variant_id,
            "reference_occurrence_id": self.reference_occurrence_id,
            "tactic_entry_id": self.tactic_entry_id,
            "composite_outcome_index": self.composite_outcome_index,
            "route": copy.deepcopy(dict(self.route)),
            "traces": [trace.to_dict() for trace in self.traces],
            "precursor_comparison": self.precursor_comparison.to_dict(),
        }


@dataclass(frozen=True)
class RRSubtreeCompositeUnwrapResult:
    """All bounded, chemically certified subtree expansions."""

    routes_json: Mapping[str, Mapping[str, Any]]
    variants: tuple[RRSubtreeCompositeVariant, ...]
    diagnostics: tuple[RRSubtreeCompositeDiagnostic, ...]
    complete: bool

    @property
    def variant_count(self) -> int:
        return len(self.variants)


@dataclass
class _GeneratedTree:
    root: dict[str, Any]
    leaves: tuple[Any, ...]
    traces: tuple[RRSubtreeReplayTrace, ...]


@dataclass
class _ExpansionBudget:
    max_variants: int
    truncated: bool = False

    def retain(self, values: list[_GeneratedTree]) -> list[_GeneratedTree]:
        if len(values) > self.max_variants:
            self.truncated = True
            del values[self.max_variants :]
        return values


def _compact_rule(value: str) -> str:
    return "".join(str(value).split())


def composite_rule_identity(rule_smarts: str) -> tuple[str, str]:
    """Return collision-bucket key and exact normalized executable SMARTS."""

    normalized = _compact_rule(rule_smarts)
    if not normalized or ">>" not in normalized:
        raise ValueError("composite rule must be non-empty reaction SMARTS")
    digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
    return f"composite_i_{digest}", normalized


def _node_at_path(root: Mapping[str, Any], path: Sequence[int]) -> Mapping[str, Any]:
    node: Mapping[str, Any] = root
    for index in path:
        children = node.get("children", ()) or ()
        try:
            child = children[int(index)]
        except (IndexError, TypeError) as exc:
            raise ValueError(f"route has no node at path {list(path)}") from exc
        if not isinstance(child, Mapping):
            raise ValueError(f"route path {list(path)} does not identify an object")
        node = child
    return node


def _molecule_smiles(node: Mapping[str, Any]) -> str:
    value = route_access.molecule_node_mapped_smiles(
        dict(node)
    ) or route_access.molecule_node_smiles(dict(node))
    if not value:
        raise ValueError("molecule node has no SMILES")
    return value


def _mapped_molecule(node: Mapping[str, Any]) -> Any:
    return chemistry.parse_molecule(_molecule_smiles(node))


def _as_rrsubtree_occurrence(
    occurrence: TacticOccurrence | RRSubtreeOccurrence,
) -> tuple[RRSubtreeOccurrence, str]:
    if isinstance(occurrence, RRSubtreeOccurrence):
        return occurrence, occurrence.occurrence_id
    if not isinstance(occurrence, TacticOccurrence):
        raise TypeError("occurrence must be TacticOccurrence or RRSubtreeOccurrence")
    if occurrence.identity.kind not in {"rrsubtree_cons", "rrsubtree_gap"}:
        raise ValueError("occurrence is not an RRSubtree tactic")
    return (
        RRSubtreeOccurrence.from_dict(occurrence.native_payload),
        occurrence.reference_occurrence_id,
    )


def _default_extractor() -> CompositeRuleExtractor:
    return CompositeRuleExtractor.from_args(
        SimpleNamespace(
            config="route_inspector/configs/rule_extraction_small.yaml",
        )
    )


def _topology(
    occurrence: RRSubtreeOccurrence,
) -> tuple[dict[NodePath, RRSubtreeNode], dict[NodePath, tuple[NodePath, ...]]]:
    nodes = {node.reaction_node_path: node for node in occurrence.nodes}
    children: dict[NodePath, list[NodePath]] = {path: [] for path in nodes}
    for edge in occurrence.edges:
        children[edge.parent_reaction_node_path].append(edge.child_reaction_node_path)
    return nodes, {path: tuple(sorted(values)) for path, values in children.items()}


def _molecule_node(molecule: Any) -> dict[str, Any]:
    return {"type": "mol", "smiles": format(molecule, "m"), "in_stock": False}


def _json_key(value: Mapping[str, Any]) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def _deduplicate_generated(values: Iterable[_GeneratedTree]) -> list[_GeneratedTree]:
    unique: dict[str, _GeneratedTree] = {}
    for value in values:
        unique.setdefault(_json_key(value.root), value)
    return [unique[key] for key in sorted(unique)]


def _normalize_generated_atom_maps(tree: _GeneratedTree) -> _GeneratedTree:
    """Keep replay evidence synchronized with branch-scoped new-atom IDs."""
    root, mappings = normalize_route_atom_mapping(tree.root)
    traces_by_source = {}
    for path, mapping in mappings.items():
        reaction = _node_at_path(root, path)
        source_path = tuple(reaction["rrsubtree_source_reaction_node_path"])
        traces_by_source[source_path] = (path, mapping, reaction)
    traces = []
    for trace in tree.traces:
        path, mapping, reaction = traces_by_source[trace.reaction_node_path]
        traces.append(
            replace(
                trace,
                input_smiles=_molecule_smiles(_node_at_path(root, path[:-1])),
                reaction_smiles=reaction["smiles"],
                query_to_target_mappings=tuple(
                    tuple((query, mapping[target]) for query, target in match)
                    for match in trace.query_to_target_mappings
                ),
            )
        )
    return _GeneratedTree(
        root=root,
        leaves=tuple(
            _mapped_molecule(_node_at_path(root, path)) for path in _leaf_paths(root)
        ),
        traces=tuple(traces),
    )


def _source_products_for_children(
    occurrence: RRSubtreeOccurrence,
    parent_path: NodePath,
    outcome: Any,
    source_reaction: Any,
    *,
    parent_lineage_atom_ids: set[int],
) -> tuple[tuple[tuple[NodePath, int, Any], ...], ...]:
    edges = sorted(
        (
            edge
            for edge in occurrence.edges
            if edge.parent_reaction_node_path == parent_path
        ),
        key=lambda edge: edge.child_reaction_node_path,
    )
    candidates: list[tuple[NodePath, tuple[tuple[int, Any], ...]]] = []
    for edge in edges:
        expected = source_reaction.reactants[edge.parent_reactant_index]
        matching_values: list[tuple[int, Any]] = []
        for index, product_molecule in enumerate(outcome.products):
            comparison = compare_precursor_multisets(
                (expected,),
                (product_molecule,),
                lineage_atom_ids=parent_lineage_atom_ids,
            )
            if not (
                comparison.chemistry_equivalent
                and comparison.mapping_consistent
                and comparison.atom_mappings
            ):
                continue
            expected_to_replay = dict(comparison.atom_mappings[0])
            replay_to_expected = {
                replay: expected_atom
                for expected_atom, replay in expected_to_replay.items()
            }
            remapped_product = product_molecule.copy()
            remapped_product.remap(replay_to_expected)
            matching_values.append((index, remapped_product))
        matching = tuple(matching_values)
        if not matching:
            raise RuleApplicationError(
                "source replay could not assign child reaction path "
                f"{list(edge.child_reaction_node_path)} to a generated precursor"
            )
        candidates.append((edge.child_reaction_node_path, matching))

    assignments: list[tuple[tuple[NodePath, int, Any], ...]] = []

    def visit(
        position: int,
        used: set[int],
        selected: list[tuple[NodePath, int, Any]],
    ) -> None:
        if position == len(candidates):
            assignments.append(tuple(selected))
            return
        child_path, product_values = candidates[position]
        for product_index, remapped_product in product_values:
            if product_index in used:
                continue
            used.add(product_index)
            selected.append((child_path, product_index, remapped_product))
            visit(position + 1, used, selected)
            selected.pop()
            used.remove(product_index)

    visit(0, set(), [])
    if not assignments:
        raise RuleApplicationError(
            "recorded RRSubtree child branches have no exact source product assignment"
        )
    return tuple(assignments)


def _source_replay_node(
    occurrence: RRSubtreeOccurrence,
    node_by_path: Mapping[NodePath, RRSubtreeNode],
    children_by_path: Mapping[NodePath, tuple[NodePath, ...]],
    node_path: NodePath,
    active_molecule: Any,
    *,
    adapter: ChythonOneShotTraceAdapter,
    max_outcomes: int,
    budget: _ExpansionBudget,
) -> list[_GeneratedTree]:
    from chython.reactor import Reactor

    node = node_by_path[node_path]
    source_reaction = chemistry.parse_reaction(node.reaction_smiles)
    source_target = chemistry.parse_molecule(node.target_smiles)
    target_comparison = compare_precursor_multisets(
        (source_target,),
        (active_molecule,),
        lineage_atom_ids={int(atom_number) for atom_number in source_target},
    )
    if not (
        target_comparison.chemistry_equivalent and target_comparison.mapping_consistent
    ):
        raise RuleApplicationError(
            f"active molecule disagrees with source target at {list(node_path)}"
        )

    enumeration = adapter.enumerate(
        Reactor.from_smarts(node.rule_smarts, delete_atoms=True, one_shot=True),
        active_molecule,
        max_unique_outcomes=max_outcomes,
    )
    if enumeration.truncated:
        budget.truncated = True
    accepted: list[_GeneratedTree] = []
    for outcome in enumeration.outcomes:
        source_comparison = compare_precursor_multisets(
            source_reaction.reactants,
            outcome.products,
            lineage_atom_ids={int(atom_number) for atom_number in active_molecule},
        )
        if not (
            source_comparison.chemistry_equivalent
            and source_comparison.mapping_consistent
        ):
            continue
        assignment_options = _source_products_for_children(
            occurrence,
            node_path,
            outcome,
            source_reaction,
            parent_lineage_atom_ids={
                int(atom_number) for atom_number in active_molecule
            },
        )
        for source_assignments in assignment_options:
            remapped_products = list(outcome.products)
            assignments = []
            for child_path, product_index, remapped_product in source_assignments:
                remapped_products[product_index] = remapped_product
                assignments.append((child_path, product_index))
            guided_outcome = replace(
                outcome,
                products=tuple(remapped_products),
                product_smiles=tuple(
                    format(product_molecule, "m")
                    for product_molecule in remapped_products
                ),
            )
            generated = _combine_child_expansions(
                occurrence,
                node_by_path,
                children_by_path,
                node_path,
                active_molecule,
                guided_outcome,
                tuple(assignments),
                adapter=adapter,
                max_outcomes=max_outcomes,
                budget=budget,
                source_guided=True,
            )
            accepted.extend(generated)
            budget.retain(accepted)
    return _deduplicate_generated(accepted)


def _candidate_child_assignments(
    child_paths: tuple[NodePath, ...],
    product_count: int,
) -> Iterable[tuple[tuple[NodePath, int], ...]]:
    if not child_paths:
        yield ()
        return
    if len(child_paths) > product_count:
        return

    def visit(
        position: int, used: set[int], selected: list[tuple[NodePath, int]]
    ) -> Any:
        if position == len(child_paths):
            yield tuple(selected)
            return
        child_path = child_paths[position]
        for product_index in range(product_count):
            if product_index in used:
                continue
            used.add(product_index)
            selected.append((child_path, product_index))
            yield from visit(position + 1, used, selected)
            selected.pop()
            used.remove(product_index)

    yield from visit(0, set(), [])


def _combine_child_expansions(
    occurrence: RRSubtreeOccurrence,
    node_by_path: Mapping[NodePath, RRSubtreeNode],
    children_by_path: Mapping[NodePath, tuple[NodePath, ...]],
    node_path: NodePath,
    active_molecule: Any,
    outcome: Any,
    assignments: tuple[tuple[NodePath, int], ...],
    *,
    adapter: ChythonOneShotTraceAdapter,
    max_outcomes: int,
    budget: _ExpansionBudget,
    source_guided: bool,
) -> list[_GeneratedTree]:
    options: list[list[_GeneratedTree]] = []
    for child_path, product_index in assignments:
        child_product = outcome.products[product_index]
        try:
            child_values = (
                _source_replay_node(
                    occurrence,
                    node_by_path,
                    children_by_path,
                    child_path,
                    child_product,
                    adapter=adapter,
                    max_outcomes=max_outcomes,
                    budget=budget,
                )
                if source_guided
                else _enumerate_node(
                    occurrence,
                    node_by_path,
                    children_by_path,
                    child_path,
                    child_product,
                    adapter=adapter,
                    max_outcomes=max_outcomes,
                    budget=budget,
                )
            )
        except RuleApplicationError:
            child_values = []
        if not child_values:
            return []
        options.append(child_values)

    combined: list[_GeneratedTree] = []
    combinations = product(*options) if options else ((),)
    for child_combination in combinations:
        children = [_molecule_node(value) for value in outcome.products]
        leaves: list[Any] = []
        traces: list[RRSubtreeReplayTrace] = []
        assigned_indices: set[int] = set()
        for (child_path, product_index), child_tree in zip(
            assignments,
            child_combination,
        ):
            assigned_indices.add(product_index)
            children[product_index] = child_tree.root
            leaves.extend(child_tree.leaves)
            traces.extend(child_tree.traces)
        for product_index, product_molecule in enumerate(outcome.products):
            if product_index not in assigned_indices:
                leaves.append(product_molecule)
        reaction_path_text = ".".join(str(index) for index in node_path)
        reaction_node = {
            "type": "reaction",
            "smiles": outcome.reaction_smiles,
            "rule_source": "RRSubtree",
            "rule_key": f"RRSubtree:{reaction_path_text}",
            "rrsubtree_source_reaction_node_path": list(node_path),
            "rrsubtree_rule": node_by_path[node_path].rule_smarts,
            "children": children,
        }
        root = _molecule_node(active_molecule)
        root["children"] = [reaction_node]
        trace = RRSubtreeReplayTrace(
            reaction_node_path=node_path,
            rule_smarts=node_by_path[node_path].rule_smarts,
            input_smiles=format(active_molecule, "m"),
            selected_outcome_index=outcome.outcome_index,
            reaction_smiles=outcome.reaction_smiles,
            child_product_assignments=tuple(assignments),
            query_to_target_mappings=outcome.query_to_target_mappings,
        )
        combined.append(
            _GeneratedTree(
                root=root,
                leaves=tuple(leaves),
                traces=(trace, *traces),
            )
        )
        budget.retain(combined)
        if budget.truncated and len(combined) >= budget.max_variants:
            break
    return _deduplicate_generated(combined)


def _expand_connected_children(
    initial: _GeneratedTree,
    child_paths: tuple[NodePath, ...],
    occurrence: RRSubtreeOccurrence,
    node_by_path: Mapping[NodePath, RRSubtreeNode],
    children_by_path: Mapping[NodePath, tuple[NodePath, ...]],
    *,
    adapter: ChythonOneShotTraceAdapter,
    max_outcomes: int,
    budget: _ExpansionBudget,
) -> list[_GeneratedTree]:
    """Replay source siblings sequentially after a ring opens into one molecule.

    Each source subtree is consumed exactly once. Enumerate both execution order
    and the live precursor on which the next subtree acts, retaining coproducts.
    The caller still validates the final boundary against the net composite.
    Source certification itself continues to require its recorded topology.
    """
    completed: list[_GeneratedTree] = []

    def visit(current: _GeneratedTree, pending: tuple[NodePath, ...]) -> None:
        if not pending:
            completed.append(current)
            budget.retain(completed)
            return
        for position, child_path in enumerate(pending):
            remaining = pending[:position] + pending[position + 1 :]
            for leaf_path in _leaf_paths(current.root):
                molecule = _mapped_molecule(_node_at_path(current.root, leaf_path))
                try:
                    options = _enumerate_node(
                        occurrence,
                        node_by_path,
                        children_by_path,
                        child_path,
                        molecule,
                        adapter=adapter,
                        max_outcomes=max_outcomes,
                        budget=budget,
                    )
                except RuleApplicationError:
                    continue
                for option in options:
                    root = copy.deepcopy(current.root)
                    _replace_at_path(root, leaf_path, copy.deepcopy(option.root))
                    visit(
                        _GeneratedTree(
                            root=root,
                            leaves=tuple(
                                _mapped_molecule(_node_at_path(root, path))
                                for path in _leaf_paths(root)
                            ),
                            traces=(*current.traces, *option.traces),
                        ),
                        remaining,
                    )
                    if budget.truncated and len(completed) >= budget.max_variants:
                        return

    visit(initial, child_paths)
    return _deduplicate_generated(completed)


def _enumerate_node(
    occurrence: RRSubtreeOccurrence,
    node_by_path: Mapping[NodePath, RRSubtreeNode],
    children_by_path: Mapping[NodePath, tuple[NodePath, ...]],
    node_path: NodePath,
    active_molecule: Any,
    *,
    adapter: ChythonOneShotTraceAdapter,
    max_outcomes: int,
    budget: _ExpansionBudget,
) -> list[_GeneratedTree]:
    from chython.reactor import Reactor

    node = node_by_path[node_path]
    enumeration = adapter.enumerate(
        Reactor.from_smarts(node.rule_smarts, delete_atoms=True, one_shot=True),
        active_molecule,
        max_unique_outcomes=max_outcomes,
    )
    if enumeration.truncated:
        budget.truncated = True
    values: list[_GeneratedTree] = []
    child_paths = children_by_path[node_path]
    for outcome in enumeration.outcomes:
        if len(outcome.products) == 1 and len(child_paths) > 1:
            initial = _combine_child_expansions(
                occurrence,
                node_by_path,
                children_by_path,
                node_path,
                active_molecule,
                outcome,
                (),
                adapter=adapter,
                max_outcomes=max_outcomes,
                budget=budget,
                source_guided=False,
            )[0]
            # Logical source children share the initial product; the route and
            # child traces record their actual sequential inputs.
            initial.traces = (
                replace(
                    initial.traces[0],
                    child_product_assignments=tuple((path, 0) for path in child_paths),
                ),
            )
            values.extend(
                _expand_connected_children(
                    initial,
                    child_paths,
                    occurrence,
                    node_by_path,
                    children_by_path,
                    adapter=adapter,
                    max_outcomes=max_outcomes,
                    budget=budget,
                )
            )
            budget.retain(values)
            if budget.truncated and len(values) >= budget.max_variants:
                break
            continue
        for assignments in _candidate_child_assignments(
            child_paths,
            len(outcome.products),
        ):
            values.extend(
                _combine_child_expansions(
                    occurrence,
                    node_by_path,
                    children_by_path,
                    node_path,
                    active_molecule,
                    outcome,
                    assignments,
                    adapter=adapter,
                    max_outcomes=max_outcomes,
                    budget=budget,
                    source_guided=False,
                )
            )
            budget.retain(values)
            if budget.truncated and len(values) >= budget.max_variants:
                break
    return _deduplicate_generated(values)


def _source_boundary(
    occurrence: RRSubtreeOccurrence,
    source_route: Mapping[str, Any],
) -> tuple[Any, tuple[Any, ...]]:
    root_target_path = occurrence.root_reaction_node_path[:-1]
    target = _mapped_molecule(_node_at_path(source_route, root_target_path))
    boundaries = tuple(
        _mapped_molecule(_node_at_path(source_route, path))
        for path in occurrence.boundary_precursor_node_paths
    )
    return target, boundaries


def replay_rrsubtree_source(
    occurrence: TacticOccurrence | RRSubtreeOccurrence,
    source_route: Mapping[str, Any],
    *,
    max_outcomes: int = 256,
    max_variants: int = 256,
    adapter: ChythonOneShotTraceAdapter | None = None,
) -> RRSubtreeSourceReplay:
    """Replay one RRSubtree_cons and compare it with its recorded boundary."""

    native, _reference_id = _as_rrsubtree_occurrence(occurrence)
    if native.kind != "cons":
        raise ValueError("only RRSubtree_cons can be replay-certified")
    if max_outcomes < 1 or max_variants < 1:
        raise ValueError("outcome and variant limits must be positive")
    try:
        target, expected_boundary = _source_boundary(native, source_route)
        node_by_path, children_by_path = _topology(native)
        budget = _ExpansionBudget(max_variants=max_variants)
        generated = _source_replay_node(
            native,
            node_by_path,
            children_by_path,
            native.root_reaction_node_path,
            target,
            adapter=adapter or ChythonOneShotTraceAdapter(),
            max_outcomes=max_outcomes,
            budget=budget,
        )
        comparisons = tuple(
            compare_precursor_multisets(
                expected_boundary,
                value.leaves,
                lineage_atom_ids={int(atom_number) for atom_number in target},
            )
            for value in generated
        )
        accepted = tuple(
            (value, comparison)
            for value, comparison in zip(generated, comparisons)
            if comparison.chemistry_equivalent and comparison.mapping_consistent
        )
        if budget.truncated:
            status = "outcome_limit_reached"
        elif not generated:
            status = "subtree_no_application"
        elif not accepted:
            status = "subtree_boundary_mismatch"
        elif len(accepted) == 1:
            status = "validated_unique"
        else:
            status = "validated_ambiguous"
        representative = accepted[0] if accepted else None
        return RRSubtreeSourceReplay(
            status=status,
            accepted_variant_count=len(accepted),
            generated_variant_count=len(generated),
            truncated=budget.truncated,
            comparison=None if representative is None else representative[1],
            traces=() if representative is None else representative[0].traces,
        )
    except Exception as exc:
        return RRSubtreeSourceReplay(
            status="replay_error",
            accepted_variant_count=0,
            generated_variant_count=0,
            truncated=False,
            comparison=None,
            traces=(),
            error_type=type(exc).__name__,
            error_message=str(exc),
        )


def _pseudo_reaction(
    target: Any,
    boundary: Sequence[Any],
) -> tuple[str, str, tuple[str, ...]]:
    from chython.containers.reaction import ReactionContainer

    reactants, product_molecule = normalize_pseudo_reaction_mapping(boundary, target)
    reaction = ReactionContainer(
        reactants=tuple(reactants),
        products=(product_molecule,),
    )
    return (
        format(reaction, "m"),
        format(product_molecule, "m"),
        tuple(format(reactant, "m") for reactant in reactants),
    )


def construct_rrsubtree_composite_rule(
    occurrence: TacticOccurrence | RRSubtreeOccurrence,
    source_route: Mapping[str, Any],
    *,
    extractor: CompositeRuleExtractor | None = None,
    max_replay_outcomes: int = 256,
    max_variants: int = 256,
    allow_ambiguous: bool = True,
) -> CompositeConstructionResult:
    """Construct and certify a net composite from one exact RRSubtree_cons."""

    native, reference_occurrence_id = _as_rrsubtree_occurrence(occurrence)
    if native.kind != "cons":
        raise ValueError("only RRSubtree_cons can construct executable composites")
    source_replay = replay_rrsubtree_source(
        native,
        source_route,
        max_outcomes=max_replay_outcomes,
        max_variants=max_variants,
    )
    target, boundaries = _source_boundary(native, source_route)
    pseudo_smiles, target_smiles, boundary_smiles = _pseudo_reaction(
        target,
        boundaries,
    )
    diagnostics: list[Mapping[str, Any]] = []
    if not source_replay.certified:
        diagnostics.append(
            {
                "stage": "rrsubtree_source_replay",
                "status": source_replay.status,
                "message": source_replay.error_message or "source replay not certified",
            }
        )
        return CompositeConstructionResult(
            kind="rrsubtree_cons",
            reference_occurrence_id=reference_occurrence_id,
            native_occurrence_id=native.occurrence_id,
            route_id=native.route_id,
            composite_rule=None,
            pseudo_reaction_smiles=pseudo_smiles,
            accepted=False,
            validation_status=source_replay.status,
            source_replay=source_replay.to_dict(),
            composite_validation=None,
            boundary_precursor_node_paths=native.boundary_precursor_node_paths,
            all_edges_rrseq_connected=native.all_edges_rrseq_connected,
            diagnostics=tuple(diagnostics),
        )

    extracted = (extractor or _default_extractor()).extract(pseudo_smiles)
    if extracted is None:
        diagnostics.append(
            {
                "stage": "composite_rule_extraction",
                "status": "rule_not_extracted",
                "message": "SynPlanner did not extract one composite rule",
            }
        )
        return CompositeConstructionResult(
            kind="rrsubtree_cons",
            reference_occurrence_id=reference_occurrence_id,
            native_occurrence_id=native.occurrence_id,
            route_id=native.route_id,
            composite_rule=None,
            pseudo_reaction_smiles=pseudo_smiles,
            accepted=False,
            validation_status="rule_not_extracted",
            source_replay=source_replay.to_dict(),
            composite_validation=None,
            boundary_precursor_node_paths=native.boundary_precursor_node_paths,
            all_edges_rrseq_connected=native.all_edges_rrseq_connected,
            diagnostics=tuple(diagnostics),
        )
    validation = validate_abstract_composite_rule(
        target_smiles,
        extracted.rule_smarts,
        boundary_smiles,
        max_outcomes=max_replay_outcomes,
    )
    replay_ambiguous = source_replay.status == "validated_ambiguous"
    composite_ambiguous = (
        validation.status == CompositeValidationStatus.VALIDATED_AMBIGUOUS
    )
    accepted = (
        source_replay.certified
        and validation.lineage_certified
        and validation.status
        in {
            CompositeValidationStatus.VALIDATED_UNIQUE,
            CompositeValidationStatus.VALIDATED_AMBIGUOUS,
        }
        and (allow_ambiguous or not (replay_ambiguous or composite_ambiguous))
    )
    if not accepted:
        diagnostics.append(
            {
                "stage": "composite_replay",
                "status": validation.status.value,
                "message": (
                    "ambiguous replay is retained but uncertified"
                    if replay_ambiguous or composite_ambiguous
                    else "composite replay did not preserve source boundary and lineage"
                ),
            }
        )
    decomposition = (
        RRSubtreeCompositeDecomposition(
            composite_rule=extracted.rule_smarts,
            reference_occurrence_id=reference_occurrence_id,
            occurrence=native,
            certificate_status=validation.status.value,
            boundary_policy=ABSTRACTION_BOUNDARY_POLICY,
        )
        if accepted
        else None
    )
    return CompositeConstructionResult(
        kind="rrsubtree_cons",
        reference_occurrence_id=reference_occurrence_id,
        native_occurrence_id=native.occurrence_id,
        route_id=native.route_id,
        composite_rule=extracted.rule_smarts,
        pseudo_reaction_smiles=pseudo_smiles,
        accepted=accepted,
        validation_status=validation.status.value,
        source_replay=source_replay.to_dict(),
        composite_validation=validation.to_dict(),
        boundary_precursor_node_paths=native.boundary_precursor_node_paths,
        all_edges_rrseq_connected=native.all_edges_rrseq_connected,
        diagnostics=tuple(diagnostics),
        decomposition=decomposition,
    )


def _construct_rrseq_composite_rule(
    occurrence: TacticOccurrence,
    *,
    extractor: CompositeRuleExtractor | None,
    max_replay_outcomes: int,
    allow_ambiguous: bool,
) -> CompositeConstructionResult:
    if occurrence.identity.kind != "rrseq_cons":
        raise ValueError("occurrence is not RRseq_cons")
    native = RRseqConsOccurrence.from_dict(occurrence.native_payload)
    application = SimpleNamespace(
        source_tsv=Path("reference_library"),
        row_index=0,
        rrseq=native.rrseq_cons,
        rrseq_cons=native.rrseq_cons,
        rrseq_size=native.rrseq_cons_size,
        rrseq_cons_size=native.rrseq_cons_size,
        route_ids=(native.route_id,),
        target_smiles=native.segment_target_smiles,
        occurrence_id=native.occurrence_id,
        route_id=native.route_id,
        route_target_smiles=native.route_target_smiles,
        source_matches=tuple(match.to_dict() for match in native.source_matches),
        source_route_leaves=tuple(
            leaf.mapped_smiles for leaf in native.source_route_leaves
        ),
        source_identity=native.source_identity,
    )
    candidate = build_composite_candidate(
        application,
        extractor or _default_extractor(),
        max_replay_outcomes=max_replay_outcomes,
    )
    validation = candidate.candidate_validation
    accepted = bool(
        candidate.status == "ok"
        and validation is not None
        and validation.lineage_certified
        and (
            allow_ambiguous
            or validation.status == CompositeValidationStatus.VALIDATED_UNIQUE
        )
        and candidate.witness is not None
        and (
            candidate.witness.source_comparison is None
            or (
                candidate.witness.source_comparison.chemistry_equivalent
                and candidate.witness.source_comparison.mapping_consistent
            )
        )
    )
    return CompositeConstructionResult(
        kind="rrseq_cons",
        reference_occurrence_id=occurrence.reference_occurrence_id,
        native_occurrence_id=native.occurrence_id,
        route_id=native.route_id,
        composite_rule=candidate.rule_smarts,
        pseudo_reaction_smiles=(
            None
            if candidate.witness is None
            else candidate.witness.pseudo_reaction_smiles
        ),
        accepted=accepted,
        validation_status=(
            candidate.status if validation is None else validation.status.value
        ),
        source_replay=(
            {}
            if candidate.witness is None
            else {
                "source_comparison": (
                    None
                    if candidate.witness.source_comparison is None
                    else candidate.witness.source_comparison.to_dict()
                ),
                "rrseq_step_traces": list(candidate.witness.rrseq_step_traces),
            }
        ),
        composite_validation=None if validation is None else validation.to_dict(),
        diagnostics=(() if candidate.error is None else (candidate.error,)),
    )


def construct_composite_rule(
    occurrence: TacticOccurrence,
    *,
    source_route: Mapping[str, Any] | None = None,
    extractor: CompositeRuleExtractor | None = None,
    max_replay_outcomes: int = 256,
    max_variants: int = 256,
    allow_ambiguous: bool = True,
) -> CompositeConstructionResult:
    """Construct a certified composite from a library executable occurrence."""

    if not isinstance(occurrence, TacticOccurrence):
        raise TypeError("construct_composite_rule requires a TacticOccurrence")
    if occurrence.identity.kind == "rrseq_cons":
        return _construct_rrseq_composite_rule(
            occurrence,
            extractor=extractor,
            max_replay_outcomes=max_replay_outcomes,
            allow_ambiguous=allow_ambiguous,
        )
    if occurrence.identity.kind == "rrsubtree_cons":
        if source_route is None:
            raise ValueError("RRSubtree_cons construction requires source_route")
        return construct_rrsubtree_composite_rule(
            occurrence,
            source_route,
            extractor=extractor,
            max_replay_outcomes=max_replay_outcomes,
            max_variants=max_variants,
            allow_ambiguous=allow_ambiguous,
        )
    raise ValueError(
        "only rrseq_cons and rrsubtree_cons can construct executable composites"
    )


def _composite_outcomes(
    target_smiles: str,
    composite_rule: str,
    *,
    adapter: ChythonOneShotTraceAdapter,
    max_outcomes: int,
) -> tuple[Any, tuple[Any, ...], bool]:
    from chython import smiles
    from chython.reactor import Reactor

    target = smiles(target_smiles)
    enumeration = adapter.enumerate(
        Reactor.from_smarts(composite_rule, delete_atoms=True, one_shot=True),
        target,
        max_unique_outcomes=max_outcomes,
    )
    return target, enumeration.outcomes, enumeration.truncated


def _mark_leaves_in_stock(node: dict[str, Any]) -> None:
    children = node.get("children", ()) or ()
    if node.get("type") == "mol" and not children:
        node["in_stock"] = True
        return
    for child in children:
        if isinstance(child, dict):
            _mark_leaves_in_stock(child)


def _coerce_decompositions(
    values: Sequence[RRSubtreeCompositeDecomposition | CompositeConstructionResult],
) -> tuple[RRSubtreeCompositeDecomposition, ...]:
    resolved: list[RRSubtreeCompositeDecomposition] = []
    for value in values:
        if isinstance(value, RRSubtreeCompositeDecomposition):
            resolved.append(value)
        elif isinstance(value, CompositeConstructionResult):
            if value.decomposition is None or not value.accepted:
                raise ValueError("construction result is not a certified decomposition")
            resolved.append(value.decomposition)
        else:
            raise TypeError("decompositions must be certified construction results")
    if not resolved:
        raise ValueError("at least one certified RRSubtree decomposition is required")
    return tuple(
        sorted(
            resolved,
            key=lambda value: (
                value.reference_occurrence_id,
                value.tactic_entry_id or "",
            ),
        )
    )


def unwrap_rrsubtree_composite(
    target_smiles: str,
    composite_rule: str,
    decompositions: Sequence[
        RRSubtreeCompositeDecomposition | CompositeConstructionResult
    ],
    *,
    max_outcomes: int = 256,
    max_variants: int = 256,
    mark_leaves_in_stock: bool = True,
) -> RRSubtreeCompositeUnwrapResult:
    """Return every bounded RRSubtree expansion matching the composite outcome."""

    if max_outcomes < 1 or max_variants < 1:
        raise ValueError("outcome and variant limits must be positive")
    normalized_rule = _compact_rule(composite_rule)
    resolved = _coerce_decompositions(decompositions)
    for decomposition in resolved:
        if _compact_rule(decomposition.composite_rule) != normalized_rule:
            raise ValueError(
                "decomposition is certified for a different composite rule"
            )

    adapter = ChythonOneShotTraceAdapter(preserve_atom_mapping=True)
    target, composite_outcomes, composite_truncated = _composite_outcomes(
        target_smiles,
        composite_rule,
        adapter=adapter,
        max_outcomes=max_outcomes,
    )
    diagnostics: list[RRSubtreeCompositeDiagnostic] = []
    variants: list[RRSubtreeCompositeVariant] = []
    complete = not composite_truncated
    if composite_truncated:
        diagnostics.append(
            RRSubtreeCompositeDiagnostic(
                reference_occurrence_id="",
                stage="composite_application",
                error_type="OutcomeLimitReached",
                message=f"composite outcomes reached the cap of {max_outcomes}",
            )
        )
    if not composite_outcomes:
        diagnostics.append(
            RRSubtreeCompositeDiagnostic(
                reference_occurrence_id="",
                stage="composite_application",
                error_type="RuleApplicationError",
                message="composite rule did not apply to target",
            )
        )

    for decomposition in resolved:
        occurrence = decomposition.occurrence
        node_by_path, children_by_path = _topology(occurrence)
        budget = _ExpansionBudget(max_variants=max_variants)
        try:
            generated = _enumerate_node(
                occurrence,
                node_by_path,
                children_by_path,
                occurrence.root_reaction_node_path,
                target,
                adapter=adapter,
                max_outcomes=max_outcomes,
                budget=budget,
            )
        except Exception as exc:
            diagnostics.append(
                RRSubtreeCompositeDiagnostic(
                    reference_occurrence_id=decomposition.reference_occurrence_id,
                    stage="rrsubtree_application",
                    error_type=type(exc).__name__,
                    message=str(exc),
                )
            )
            complete = False
            continue
        complete = complete and not budget.truncated
        if budget.truncated:
            diagnostics.append(
                RRSubtreeCompositeDiagnostic(
                    reference_occurrence_id=(decomposition.reference_occurrence_id),
                    stage="rrsubtree_application",
                    error_type="OutcomeLimitReached",
                    message=f"RRSubtree variants exceeded the cap of {max_variants}",
                )
            )
        matched_for_decomposition = 0
        for generated_tree in generated:
            generated_tree = _normalize_generated_atom_maps(generated_tree)
            comparison_leaves = generated_tree.leaves
            boundary_audit = None
            if decomposition.boundary_policy == ABSTRACTION_BOUNDARY_POLICY:
                try:
                    comparison_leaves, boundary_audit = abstract_precursor_boundary(
                        target, comparison_leaves
                    )
                except Exception as exc:
                    diagnostics.append(
                        RRSubtreeCompositeDiagnostic(
                            reference_occurrence_id=decomposition.reference_occurrence_id,
                            stage="abstraction_boundary",
                            error_type=type(exc).__name__,
                            message=str(exc),
                        )
                    )
                    complete = False
                    continue
            for composite_outcome in composite_outcomes:
                comparison = compare_precursor_multisets(
                    composite_outcome.products,
                    comparison_leaves,
                    lineage_atom_ids={int(atom_number) for atom_number in target},
                )
                if not (
                    comparison.chemistry_equivalent and comparison.mapping_consistent
                ):
                    continue
                route = copy.deepcopy(generated_tree.root)
                route.setdefault("metadata", {})[
                    "rrsubtree_composite_decomposition"
                ] = {
                    "reference_occurrence_id": (decomposition.reference_occurrence_id),
                    "tactic_entry_id": decomposition.tactic_entry_id,
                    "composite_rule": composite_rule,
                    "composite_outcome_index": composite_outcome.outcome_index,
                    **(
                        {"abstraction_boundary": boundary_audit}
                        if boundary_audit is not None
                        else {}
                    ),
                }
                if mark_leaves_in_stock:
                    _mark_leaves_in_stock(route)
                variants.append(
                    RRSubtreeCompositeVariant(
                        variant_id="",
                        reference_occurrence_id=(decomposition.reference_occurrence_id),
                        tactic_entry_id=decomposition.tactic_entry_id,
                        composite_outcome_index=composite_outcome.outcome_index,
                        route=route,
                        traces=generated_tree.traces,
                        precursor_comparison=comparison,
                    )
                )
                matched_for_decomposition += 1
                if len(variants) >= max_variants:
                    complete = False
                    break
            if len(variants) >= max_variants:
                break
        if not matched_for_decomposition:
            diagnostics.append(
                RRSubtreeCompositeDiagnostic(
                    reference_occurrence_id=decomposition.reference_occurrence_id,
                    stage="precursor_comparison",
                    error_type="NoMatchingOutcome",
                    message=(
                        "RRSubtree expansion produced no precursor multiset matching "
                        "a direct composite-rule outcome"
                    ),
                )
            )
        if len(variants) >= max_variants:
            diagnostics.append(
                RRSubtreeCompositeDiagnostic(
                    reference_occurrence_id=(decomposition.reference_occurrence_id),
                    stage="variant_collection",
                    error_type="OutcomeLimitReached",
                    message=f"final variants reached the cap of {max_variants}",
                )
            )
            break

    unique: dict[str, RRSubtreeCompositeVariant] = {}
    for variant in variants:
        key = _json_key(variant.route)
        unique.setdefault(key, variant)
    ordered = [unique[key] for key in sorted(unique)]
    if len(ordered) > max_variants:
        ordered = ordered[:max_variants]
        complete = False
    finalized = tuple(
        RRSubtreeCompositeVariant(
            variant_id=f"0.{index}",
            reference_occurrence_id=value.reference_occurrence_id,
            tactic_entry_id=value.tactic_entry_id,
            composite_outcome_index=value.composite_outcome_index,
            route=value.route,
            traces=value.traces,
            precursor_comparison=value.precursor_comparison,
        )
        for index, value in enumerate(ordered, start=1)
    )
    return RRSubtreeCompositeUnwrapResult(
        routes_json={value.variant_id: value.route for value in finalized},
        variants=finalized,
        diagnostics=tuple(diagnostics),
        complete=complete,
    )


def _leaf_paths(root: Mapping[str, Any]) -> tuple[NodePath, ...]:
    found: list[NodePath] = []

    def visit(node: Mapping[str, Any], path: NodePath) -> None:
        children = node.get("children", ()) or ()
        if node.get("type") == "mol" and not children:
            found.append(path)
            return
        for index, child in enumerate(children):
            if isinstance(child, Mapping):
                visit(child, path + (index,))

    visit(root, ())
    return tuple(found)


def _replace_at_path(
    root: dict[str, Any], path: NodePath, value: dict[str, Any]
) -> dict[str, Any]:
    if not path:
        return value
    parent = root
    for index in path[:-1]:
        parent = parent["children"][index]
    parent["children"][path[-1]] = value
    return root


def _reattach_exact_branches(
    generated_root: Mapping[str, Any],
    original_precursors: Sequence[Mapping[str, Any]],
    *,
    max_variants: int,
) -> tuple[list[dict[str, Any]], bool]:
    paths = _leaf_paths(generated_root)
    leaves = [_mapped_molecule(_node_at_path(generated_root, path)) for path in paths]
    originals = [_mapped_molecule(value) for value in original_precursors]
    candidates: list[tuple[int, ...]] = []
    for original in originals:
        lineage = {int(atom_number) for atom_number in original}
        matching = tuple(
            index
            for index, leaf in enumerate(leaves)
            if (
                (
                    comparison := compare_precursor_multisets(
                        (original,),
                        (leaf,),
                        lineage_atom_ids=lineage,
                    )
                ).chemistry_equivalent
                and comparison.mapping_consistent
            )
        )
        if not matching:
            return [], False
        candidates.append(matching)

    assignments: list[tuple[int, ...]] = []

    def visit(position: int, used: set[int], selected: list[int]) -> None:
        if len(assignments) >= max_variants:
            return
        if position == len(candidates):
            assignments.append(tuple(selected))
            return
        for leaf_index in candidates[position]:
            if leaf_index in used:
                continue
            used.add(leaf_index)
            selected.append(leaf_index)
            visit(position + 1, used, selected)
            selected.pop()
            used.remove(leaf_index)

    visit(0, set(), [])
    values: list[dict[str, Any]] = []
    for assignment in assignments:
        candidate = copy.deepcopy(dict(generated_root))
        for original_index, leaf_index in enumerate(assignment):
            candidate = _replace_at_path(
                candidate,
                paths[leaf_index],
                copy.deepcopy(dict(original_precursors[original_index])),
            )
        values.append(candidate)
    truncated = len(assignments) >= max_variants
    return values, truncated


def unwrap_rrsubtree_composite_in_route(
    route: Mapping[str, Any],
    molecule_node_path: Sequence[int],
    composite_rule: str,
    decompositions: Sequence[
        RRSubtreeCompositeDecomposition | CompositeConstructionResult
    ],
    *,
    max_outcomes: int = 256,
    max_variants: int = 256,
) -> RRSubtreeCompositeUnwrapResult:
    """Insert or replace a composite occurrence at one molecule-node path."""

    source_root = copy.deepcopy(dict(route))
    path = tuple(int(index) for index in molecule_node_path)
    target_node = _node_at_path(source_root, path)
    if target_node.get("type") != "mol":
        raise ValueError("molecule_node_path must identify a molecule node")
    reaction_children = [
        child
        for child in target_node.get("children", ()) or ()
        if isinstance(child, Mapping) and child.get("type") == "reaction"
    ]
    if len(reaction_children) > 1:
        raise ValueError("target molecule has more than one reaction child")
    original_precursors: tuple[Mapping[str, Any], ...] = ()
    if reaction_children:
        original_reaction = reaction_children[0]
        recorded_rule = original_reaction.get(
            "composite_rule"
        ) or original_reaction.get("rule_smarts")
        if recorded_rule is not None and _compact_rule(
            str(recorded_rule)
        ) != _compact_rule(composite_rule):
            raise ValueError("existing reaction records a different composite rule")
        original_precursors = tuple(
            child
            for child in original_reaction.get("children", ()) or ()
            if isinstance(child, Mapping) and child.get("type") == "mol"
        )
        expected = tuple(_mapped_molecule(value) for value in original_precursors)
        validation = validate_composite_rule(
            _molecule_smiles(target_node),
            composite_rule,
            expected,
            max_outcomes=max_outcomes,
        )
        if not validation.lineage_certified:
            raise ValueError(
                "existing reaction precursors do not exactly match the composite rule"
            )

    unwrapped = unwrap_rrsubtree_composite(
        _molecule_smiles(target_node),
        composite_rule,
        decompositions,
        max_outcomes=max_outcomes,
        max_variants=max_variants,
        mark_leaves_in_stock=not original_precursors,
    )
    diagnostics = list(unwrapped.diagnostics)
    inserted: list[tuple[RRSubtreeCompositeVariant, dict[str, Any]]] = []
    complete = unwrapped.complete
    for variant in unwrapped.variants:
        generated_roots = [copy.deepcopy(dict(variant.route))]
        if original_precursors:
            generated_roots, truncated = _reattach_exact_branches(
                variant.route,
                original_precursors,
                max_variants=max_variants - len(inserted),
            )
            complete = complete and not truncated
            if truncated:
                diagnostics.append(
                    RRSubtreeCompositeDiagnostic(
                        reference_occurrence_id=variant.reference_occurrence_id,
                        stage="route_reattachment",
                        error_type="OutcomeLimitReached",
                        message=(
                            f"exact branch reattachments reached the cap of {max_variants}"
                        ),
                    )
                )
        for generated_root in generated_roots:
            merged_root = copy.deepcopy(generated_root)
            for key, value in target_node.items():
                if key == "children":
                    continue
                if key == "metadata" and isinstance(value, Mapping):
                    generated_metadata = merged_root.get("metadata")
                    if not isinstance(generated_metadata, Mapping):
                        generated_metadata = {}
                    merged_root["metadata"] = {
                        **copy.deepcopy(dict(generated_metadata)),
                        **copy.deepcopy(dict(value)),
                    }
                    continue
                merged_root.setdefault(key, copy.deepcopy(value))
            candidate_route = copy.deepcopy(source_root)
            candidate_route = _replace_at_path(candidate_route, path, merged_root)
            inserted.append((variant, candidate_route))
            if len(inserted) >= max_variants:
                complete = False
                break
        if len(inserted) >= max_variants:
            break

    source_id = str(source_root.get("node_id", source_root.get("route_id", "0")))
    final_variants = tuple(
        RRSubtreeCompositeVariant(
            variant_id=f"{source_id}.{index}",
            reference_occurrence_id=source_variant.reference_occurrence_id,
            tactic_entry_id=source_variant.tactic_entry_id,
            composite_outcome_index=source_variant.composite_outcome_index,
            route=candidate_route,
            traces=source_variant.traces,
            precursor_comparison=source_variant.precursor_comparison,
        )
        for index, (source_variant, candidate_route) in enumerate(inserted, start=1)
    )
    return RRSubtreeCompositeUnwrapResult(
        routes_json={value.variant_id: value.route for value in final_variants},
        variants=final_variants,
        diagnostics=tuple(diagnostics),
        complete=complete,
    )


__all__ = [
    "CompositeConstructionResult",
    "CompositeSourceKind",
    "RRSubtreeCompositeDecomposition",
    "RRSubtreeCompositeDiagnostic",
    "RRSubtreeCompositeError",
    "RRSubtreeCompositeOutcomeLimitError",
    "RRSubtreeCompositeUnwrapResult",
    "RRSubtreeCompositeVariant",
    "RRSubtreeReplayTrace",
    "RRSubtreeSourceReplay",
    "composite_rule_identity",
    "construct_composite_rule",
    "construct_rrsubtree_composite_rule",
    "replay_rrsubtree_source",
    "unwrap_rrsubtree_composite",
    "unwrap_rrsubtree_composite_in_route",
]
