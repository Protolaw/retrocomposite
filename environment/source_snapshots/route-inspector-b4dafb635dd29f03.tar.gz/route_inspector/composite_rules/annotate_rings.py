"""Annotate a certified companion without extraction, replay or recertification.

Usage: python -m route_inspector.composite_rules.annotate_rings --help
"""

import argparse
import json
import shutil
import sys
import tempfile
import time
from collections import defaultdict
from dataclasses import replace
from pathlib import Path

from route_inspector import chemistry
from route_inspector.composite_rules.browsing import CompositeBrowser
from route_inspector.composite_rules.library import (
    CompositeDecompositionLibrary,
    _library_id,
)
from route_inspector.composite_rules.reindex import validate_composite_library
from route_inspector.composite_rules.ring_breaking import (
    POLICY,
    aggregate_ring_breaking,
    classify_ring_breaking,
    summary_counts,
    unknown_annotation,
)
from route_inspector.composite_rules.rrsubtree import _pseudo_reaction, _source_boundary
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.reference_library import ReferenceTacticLibrary
from route_inspector.reference_library.storage.artifacts import (
    _publish_directory_no_replace,
)
from route_inspector.routes.io import iter_route_json_file
from route_inspector.tactics.rrseq.occurrences import RRseqConsOccurrence
from route_inspector.tactics.rrsubtree.models import RRSubtreeOccurrence


def source_annotation(occurrence, route):
    """Use the full recorded boundary certified by the existing source replay."""
    origin = "certified_source_boundary"
    try:
        if occurrence.identity.kind == "rrseq_cons":
            native = RRseqConsOccurrence.from_dict(occurrence.native_payload)
            target = chemistry.parse_molecule(native.segment_target_smiles)
            boundary = tuple(
                chemistry.parse_molecule(leaf.mapped_smiles)
                for leaf in native.source_route_leaves
            )
            if not boundary:
                raise ValueError("certified source boundary is unavailable")
        else:
            native = RRSubtreeOccurrence.from_dict(occurrence.native_payload)
            target, boundary = _source_boundary(native, route)
        pseudo, _, _ = _pseudo_reaction(target, boundary)
        return classify_ring_breaking(pseudo, origin=origin)
    except Exception as exc:
        return unknown_annotation(exc, origin=origin)


def annotate_library(source, reference, routes_json, *, progress=None):
    started = time.perf_counter()
    digest = sha256_file(routes_json)
    if digest != source.manifest.source_routes_sha256:
        raise ValueError("source routes do not match the certified snapshot")
    if progress:
        progress("Verifying certified source library")
    validate_composite_library(source, reference)
    entries = source.entries()
    grouped = defaultdict(list)
    for entry in entries:
        for link in source.links_for_entry(entry.composite_id):
            grouped[link.route_id].append(link)
    if progress:
        progress("Classifying certified source boundaries")
    browser = CompositeBrowser(source, reference)
    links = []
    for route_id, route in iter_route_json_file(routes_json):
        for link in grouped.pop(str(route_id), ()):
            occurrence = browser.verified_occurrence(link, reference)
            links.append(
                replace(link, ring_breaking=source_annotation(occurrence, route))
            )
            if progress and len(links) % 1000 == 0:
                progress(f"Annotated {len(links):,} certified occurrences")
    if grouped:
        raise ValueError("certified routes absent from source snapshot")
    # Detect changes during streaming, before publishing any new evidence.
    if sha256_file(routes_json) != digest:
        raise ValueError("source routes changed during annotation")
    by_entry = defaultdict(list)
    for link in links:
        by_entry[link.composite_id].append(link)
    entries = tuple(
        replace(
            e, ring_breaking_counts=aggregate_ring_breaking(by_entry[e.composite_id])
        )
        for e in entries
    )
    links = tuple(sorted(links, key=lambda link: link.link_id))
    stats = {
        **source.manifest.statistics,
        "ring_breaking": {
            **summary_counts(links),
            "annotation_seconds": time.perf_counter() - started,
        },
    }
    profile = {
        **source.manifest.construction_profile,
        "ring_breaking": dict(POLICY),
        "ring_breaking_upgrade": {
            "source_library_id": source.library_id,
            "source_manifest_sha256": sha256_file(source.directory / "manifest.json"),
        },
    }
    manifest = replace(
        source.manifest,
        library_id=_library_id(
            source.manifest.source_reference_library_id,
            digest,
            profile,
            entries,
            links,
            format_version=source.manifest.library_format_version,
        ),
        construction_profile=profile,
        statistics=stats,
        artifacts={},
    )
    return CompositeDecompositionLibrary(
        manifest=manifest,
        entries=entries,
        links=links,
        errors=source.errors,
        reindex_audit=source.reindex_audit,
    )


def preserve_overlap_cache(source, upgraded, reference, cache_root):
    """Copy verified overlap evidence when only supplementary annotations changed.

    The library ID changes, but all exact executable variants and memberships
    must remain byte-for-byte equal. No new chemical equivalence is asserted.
    """
    from route_inspector.composite_rules.overlap import (
        OverlapIndex,
        cache_identity,
        cache_key,
    )

    old_identity = cache_identity(
        reference, source, source.manifest.source_routes_sha256
    )
    new_identity = cache_identity(
        reference, upgraded, upgraded.manifest.source_routes_sha256
    )
    if {k: v for k, v in old_identity.items() if k != "composite_library_id"} != {
        k: v for k, v in new_identity.items() if k != "composite_library_id"
    }:
        raise ValueError("annotation upgrade changed overlap source identity")
    if len(source.entries()) != len(upgraded.entries()):
        raise ValueError("annotation upgrade changed composite membership")
    old = Path(cache_root) / cache_key(old_identity)
    new = Path(cache_root) / cache_key(new_identity)
    if not old.exists():
        return None
    for entry in source.entries():
        other = upgraded.get_entry(entry.composite_id)
        if replace(other, ring_breaking_counts=entry.ring_breaking_counts) != entry:
            raise ValueError(
                "annotation upgrade changed composite chemistry or membership"
            )
        for link in source.links_for_entry(entry.composite_id):
            candidate = upgraded.link_for_occurrence(link.reference_occurrence_id)
            if replace(candidate, ring_breaking=link.ring_breaking) != link:
                raise ValueError("annotation upgrade changed certified source evidence")
    with OverlapIndex(old, old_identity):
        pass
    if new.exists():
        with OverlapIndex(new, new_identity):
            pass
        return new
    temporary = Path(tempfile.mkdtemp(prefix=".ring-overlap-", dir=cache_root))
    try:
        shutil.copytree(old, temporary, dirs_exist_ok=True)
        manifest_path = temporary / "manifest.json"
        manifest = json.loads(manifest_path.read_text())
        manifest["identity"] = new_identity
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
        with OverlapIndex(temporary, new_identity):
            pass
        _publish_directory_no_replace(temporary, new)
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)
    return new


def main(argv=None):
    started = time.perf_counter()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--reference-library", type=Path, required=True)
    parser.add_argument("--routes-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--overlap-cache-dir",
        type=Path,
        default=Path("outputs/gui/single_step_overlap"),
    )
    args = parser.parse_args(argv)
    if args.output_dir.exists():
        raise FileExistsError(args.output_dir)
    args.output_dir.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(
        tempfile.mkdtemp(prefix=".ring-annotation-", dir=args.output_dir.parent)
    )
    try:
        with (
            CompositeDecompositionLibrary.load(
                args.library, verification="full"
            ) as source,
            ReferenceTacticLibrary.load(
                args.reference_library, verification="full"
            ) as reference,
        ):
            result = annotate_library(
                source,
                reference,
                args.routes_json,
                progress=lambda message: print(message, file=sys.stderr, flush=True),
            )
            print("Auditing staged publication", file=sys.stderr, flush=True)
            result.save(temporary / "library")
            with CompositeDecompositionLibrary.load(
                temporary / "library", verification="full"
            ) as check:
                validate_composite_library(check, reference)
                preserve_overlap_cache(source, check, reference, args.overlap_cache_dir)
            _publish_directory_no_replace(temporary / "library", args.output_dir)
            print(json.dumps(result.manifest.statistics, indent=2, sort_keys=True))
            print(
                f"Upgrade wall time: {time.perf_counter() - started:.3f} s",
                file=sys.stderr,
                flush=True,
            )
    finally:
        shutil.rmtree(temporary)


if __name__ == "__main__":
    main()
