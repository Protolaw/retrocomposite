from __future__ import annotations

from pathlib import Path

from route_inspector.infrastructure.artifacts import read_rule_from_tsv


def is_gapped_composite_rule_artifact(path: Path) -> bool:
    """Return whether a TSV is an analysis-only gapped-composite artifact."""

    return path.name.endswith(
        ("_gapped_composite_rules.tsv", "_separated_composite_rules.tsv")
    )


def reject_gapped_composite_rule_artifact(path: Path) -> None:
    """Reject non-executable gapped composites in template application."""

    if is_gapped_composite_rule_artifact(path):
        raise ValueError(
            f"{path} contains analysis-only gapped composite rules and cannot be used here"
        )


def read_composite_rule_from_tsv(path: Path, row_index: int) -> str:
    """Read a selected composite rule string from a TSV row.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    reject_gapped_composite_rule_artifact(path)
    return read_rule_from_tsv(
        path,
        row_index,
        columns=("Composite_rule", "Composite_rules"),
    )
