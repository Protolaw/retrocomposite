"""Bounded read-only browsing of certified companions, without reconstruction.

SQLite queries run on the library's owning thread. Portable catalogs are already
memory-backed; compact indexes are built once rather than on every UI action.
"""

from __future__ import annotations

import json
from collections import defaultdict

from route_inspector.composite_rules.library import CompositeDecompositionLink
from route_inspector.composite_rules.ring_breaking import classification
from route_inspector.reference_library.browsing import BrowsePage, route_token
from route_inspector.reference_library.models import ReferenceRouteKey

KINDS = ("rrseq_cons", "rrsubtree_cons")
METRIC_COLUMNS = {
    "product_count",
    "reactant_atom_count",
    "tactic_sizes",
}


def _bounds(kind, offset, limit):
    if kind not in (None, *KINDS):
        raise ValueError("only consecutive tactics have certified composites")
    if offset < 0 or not 1 <= limit <= 200:
        raise ValueError("offset must be nonnegative; limit must be between 1 and 200")


class CompositeBrowser:
    """Page entries, exact source identities and certified decomposition links."""

    def __init__(self, library, reference=None):
        self.library = library
        self.reference = reference
        if reference is not None:
            library.assert_reference_library(reference)
        self._rule_metrics = {}
        self._size_cache = {}
        self._tactic_sizes = {}
        self._summaries = {}
        self._portable_links = defaultdict(list)
        if library._connection is not None:
            # The GUI must never mutate even a catalog opened by the core loader.
            library._connection.execute("PRAGMA query_only = ON")
        else:
            for link in library._links or ():
                self._portable_links[link.composite_id].append(link)
            for links in self._portable_links.values():
                links.sort(key=lambda link: link.reference_occurrence_id)

    def entries(
        self,
        *,
        kind=None,
        minimum_support=1,
        search="",
        offset=0,
        limit=50,
        sort_by="route_count",
        descending=True,
        overlap="all",
        matched_ids=None,
        ring_breaking_only=False,
        activator_filter="all",
        activator_index=None,
    ):
        _bounds(kind, offset, limit)
        from route_inspector.rules.activators import filter_ids

        allowed = filter_ids(activator_filter, activator_index, kind)
        if minimum_support < 1:
            raise ValueError("minimum support must be positive")
        if overlap not in {"all", "matched", "unmatched"}:
            raise ValueError("invalid single-step overlap filter")
        if overlap != "all" and matched_ids is None:
            raise ValueError("single-step overlap is not ready")
        if sort_by not in {
            "composite_id",
            "route_count",
            "occurrence_count",
            "ring_breaking",
            *METRIC_COLUMNS,
        }:
            raise ValueError("invalid composite sort column")
        metric_sort = sort_by in METRIC_COLUMNS
        if kind not in self._summaries:
            connection = self.library._connection
            if connection is not None:
                # Project immutable catalogue metadata once per kind. Repeated
                # COUNT/SELECT queries otherwise parse every entry JSON again,
                # even when only the selected source occurrence has changed.
                route_count = f"coalesce(json_extract(entry_json, '$.route_counts.{kind or 'all'}'), 0)"
                occurrence_count = (
                    f"coalesce(json_extract(entry_json, '$.occurrence_counts.{kind}'), 0)"
                    if kind
                    else "(coalesce(json_extract(entry_json, '$.occurrence_counts.rrseq_cons'), 0) + "
                    "coalesce(json_extract(entry_json, '$.occurrence_counts.rrsubtree_cons'), 0))"
                )
                summaries = [
                    dict(row)
                    for row in connection.execute(
                        f"SELECT composite_id, {route_count} AS route_count, "
                        f"{occurrence_count} AS occurrence_count, normalized_rule, "
                        f"json_extract(entry_json, '$.ring_breaking_counts.{kind or 'all'}') AS ring_counts "
                        "FROM entries"
                    )
                ]
                for row in summaries:
                    if row["ring_counts"] is not None:
                        row["ring_counts"] = json.loads(row["ring_counts"])
            else:
                summaries = [
                    dict(
                        composite_id=entry.composite_id,
                        normalized_rule=entry.normalized_rule,
                        ring_counts=(entry.ring_breaking_counts or {}).get(
                            kind or "all"
                        ),
                        route_count=entry.route_counts.get(kind or "all", 0),
                        occurrence_count=entry.occurrence_counts.get(kind, 0)
                        if kind
                        else entry.occurrence_count,
                    )
                    for entry in self.library.entries()
                ]
            self._summaries[kind] = tuple(
                sorted(summaries, key=lambda row: row["composite_id"])
            )
        matching = [
            row
            for row in self._summaries[kind]
            if row["route_count"] >= minimum_support
            and search in row["composite_id"]
            and (allowed is None or row["composite_id"] in allowed)
            and (
                not ring_breaking_only
                or (row.get("ring_counts") or {}).get("yes", 0) > 0
            )
            and (
                overlap == "all"
                or (row["composite_id"] in matched_ids) == (overlap == "matched")
            )
        ]
        if sort_by == "ring_breaking":
            matching.sort(
                key=lambda row: bool(classification(row.get("ring_counts") or {})),
                reverse=descending,
            )
            matching.sort(
                key=lambda row: classification(row.get("ring_counts") or {}) is None
            )
        elif not metric_sort:
            matching.sort(key=lambda row: row[sort_by], reverse=descending)
        total = len(matching)
        rows = matching if metric_sort else matching[offset : offset + limit]
        rows = [self._with_metrics(row, kind) for row in rows]
        if metric_sort:
            # Sort the complete filtered result before paging; unknowns stay last.
            rows.sort(key=lambda row: row["composite_id"])
            known = [row for row in rows if row[sort_by] is not None]
            unknown = [row for row in rows if row[sort_by] is None]
            rows = (
                sorted(known, key=lambda row: row[sort_by], reverse=descending)
                + unknown
            )
            rows = rows[offset : offset + limit]
        return BrowsePage(tuple(dict(row) for row in rows), total, offset, limit)

    def _with_metrics(self, row, kind):
        row = dict(row)
        counts = row.pop("ring_counts", None)
        if isinstance(counts, str):
            counts = json.loads(counts)
        counts = counts or {
            "yes": 0,
            "no": 0,
            "unknown": row.get("occurrence_count", 0),
        }
        row["ring_breaking"] = classification(counts)
        row["ring_breaking_counts"] = dict(counts)
        rule = row.pop("normalized_rule")
        if rule not in self._rule_metrics:
            from chython import smarts

            try:
                query = smarts(rule)
                metrics = {
                    "product_count": len(query.products),
                    "reactant_atom_count": sum(len(m) for m in query.reactants),
                    "metric_error": None,
                }
            except (
                ValueError,
                TypeError,
                AttributeError,
                KeyError,
                NotImplementedError,
            ) as exc:
                metrics = {
                    "product_count": None,
                    "reactant_atom_count": None,
                    "metric_error": f"Rule metrics unavailable: {exc}",
                }
            self._rule_metrics[rule] = metrics
        row.update(self._rule_metrics[rule])
        row["tactic_sizes"] = self._sizes(row["composite_id"], kind)
        return row

    def _sizes(self, composite_id, kind):
        if self.reference is None:
            return None
        key = composite_id, kind
        if key not in self._size_cache:
            connection = self.library._connection
            if connection is not None:
                ids = [
                    row[0]
                    for row in connection.execute(
                        "SELECT DISTINCT tactic_entry_id FROM links WHERE composite_id = ?"
                        + (" AND kind = ?" if kind else ""),
                        (composite_id, kind) if kind else (composite_id,),
                    )
                ]
            else:
                ids = {link.tactic_entry_id for link in self._links(composite_id, kind)}
            missing = set(ids) - self._tactic_sizes.keys()
            if missing:
                connection = self.reference._connection
                if connection is not None:
                    # Read only scalar sizes for this composite's linked tactics.
                    # Do not scan or materialize detailed reference occurrences.
                    self._tactic_sizes.update(
                        connection.execute(
                            "SELECT e.entry_id, json_array_length(o.occurrence_json, "
                            "'$.selected_reaction_node_paths') FROM entries e JOIN occurrences o "
                            "ON o.reference_occurrence_id = e.representative_occurrence_id "
                            "WHERE e.entry_id IN (SELECT value FROM json_each(?))",
                            (json.dumps(sorted(missing)),),
                        )
                    )
                else:
                    for entry_id in missing:
                        entry = self.reference.get_entry(entry_id)
                        self._tactic_sizes[entry_id] = len(
                            self.reference.get_occurrence(
                                entry.representative_occurrence_id
                            ).selected_reaction_node_paths
                        )
            self._size_cache[key] = tuple(sorted({self._tactic_sizes[i] for i in ids}))
        return self._size_cache[key]

    def tactics(self, composite_id, *, kind=None):
        """Group one composite's certified links by exact tactic, most frequent first."""
        _bounds(kind, 0, 1)
        where, params = self._where(composite_id, kind)
        connection = self.library._connection
        if connection is not None:
            rows = [
                dict(row)
                for row in connection.execute(
                    "SELECT kind, tactic_entry_id, sum(n) AS occurrence_count, "
                    "count(*) AS route_count FROM ("
                    "SELECT kind, tactic_entry_id, dataset_id, source_identity, route_id, count(*) AS n "
                    f"FROM links WHERE {where} "
                    "GROUP BY kind, tactic_entry_id, dataset_id, source_identity, route_id) "
                    "GROUP BY kind, tactic_entry_id",
                    params,
                )
            ]
        else:
            groups = defaultdict(list)
            for link in self._links(composite_id, kind):
                groups[(link.kind, link.tactic_entry_id)].append(link)
            rows = [
                dict(
                    kind=key[0],
                    tactic_entry_id=key[1],
                    occurrence_count=len(links),
                    route_count=len({self.route_key(link) for link in links}),
                )
                for key, links in groups.items()
            ]
        return tuple(
            sorted(
                rows,
                key=lambda row: (
                    -row["occurrence_count"],
                    -row["route_count"],
                    row["kind"],
                    row["tactic_entry_id"],
                ),
            )
        )

    def same_lhs(self, composite_id, *, index, offset=0, limit=20):
        """Related stored queries across all kinds, independent of list filters."""
        page = index.page(composite_id, offset=offset, limit=limit)
        rows = tuple(
            {**row, "tactic_sizes": self._sizes(row["composite_id"], None)}
            for row in page.rows
        )
        return {
            "page": BrowsePage(rows, page.total, offset, limit),
            "diagnostics": index.diagnostics(composite_id),
        }

    def same_lhs_destination(self, composite_id, route=None):
        """Preserve a source route when possible, otherwise use catalogue order."""
        if route is not None:
            key = ReferenceRouteKey.from_dict(route)
            links = self.links(composite_id, route=key, limit=1)
            if links.rows:
                return links.rows[0]
        routes = self.routes(composite_id, limit=1)
        if not routes.rows:
            raise ValueError("Composite has no certified source occurrences")
        key = ReferenceRouteKey.from_dict(routes.rows[0])
        return self.links(composite_id, route=key, limit=1).rows[0]

    def _where(self, composite_id, kind, route=None, tactic_entry_id=None):
        self.library.get_entry(composite_id)
        predicates, params = ["composite_id = ?"], [composite_id]
        if kind:
            predicates.append("kind = ?")
            params.append(kind)
        if tactic_entry_id is not None:
            predicates.append("tactic_entry_id = ?")
            params.append(tactic_entry_id)
        if route is not None:
            for name, value in route.to_dict().items():
                predicates.append(f"{name} = ?")
                params.append(value)
        return " AND ".join(predicates), params

    def _links(self, composite_id, kind, route=None, tactic_entry_id=None):
        return [
            link
            for link in self._portable_links[composite_id]
            if (kind is None or link.kind == kind)
            and (route is None or self.route_key(link) == route)
            and (tactic_entry_id is None or link.tactic_entry_id == tactic_entry_id)
        ]

    @staticmethod
    def route_key(link):
        return ReferenceRouteKey(link.dataset_id, link.source_identity, link.route_id)

    def routes(
        self, composite_id, *, kind=None, offset=0, limit=50, tactic_entry_id=None
    ):
        _bounds(kind, offset, limit)
        where, params = self._where(composite_id, kind, tactic_entry_id=tactic_entry_id)
        connection = self.library._connection
        if connection is not None:
            grouped = (
                "SELECT dataset_id, source_identity, route_id, "
                "count(*) AS matching_occurrence_count, "
                "count(DISTINCT tactic_entry_id) AS unique_tactic_count "
                f"FROM links WHERE {where} GROUP BY dataset_id, source_identity, route_id"
            )
            total = connection.execute(
                f"SELECT count(*) FROM ({grouped})", params
            ).fetchone()[0]
            rows = [
                dict(row)
                for row in connection.execute(
                    grouped
                    + " ORDER BY dataset_id, source_identity, route_id LIMIT ? OFFSET ?",
                    (*params, limit, offset),
                )
            ]
        else:
            groups = defaultdict(list)
            for link in self._links(
                composite_id, kind, tactic_entry_id=tactic_entry_id
            ):
                groups[(link.dataset_id, link.source_identity, link.route_id)].append(
                    link
                )
            rows = [
                dict(
                    dataset_id=key[0],
                    source_identity=key[1],
                    route_id=key[2],
                    matching_occurrence_count=len(links),
                    unique_tactic_count=len({link.tactic_entry_id for link in links}),
                )
                for key, links in sorted(groups.items())
            ]
            total, rows = len(rows), rows[offset : offset + limit]
        for row in rows:
            row["id"] = route_token(ReferenceRouteKey.from_dict(row))
        return BrowsePage(tuple(rows), total, offset, limit)

    def links(
        self,
        composite_id,
        *,
        kind=None,
        route=None,
        offset=0,
        limit=50,
        tactic_entry_id=None,
    ):
        _bounds(kind, offset, limit)
        where, params = self._where(composite_id, kind, route, tactic_entry_id)
        connection = self.library._connection
        if connection is not None:
            total = connection.execute(
                f"SELECT count(*) FROM links WHERE {where}", params
            ).fetchone()[0]
            rows = [
                json.loads(row[0])
                for row in connection.execute(
                    f"SELECT link_json FROM links WHERE {where} ORDER BY reference_occurrence_id LIMIT ? OFFSET ?",
                    (*params, limit, offset),
                )
            ]
        else:
            links = self._links(composite_id, kind, route, tactic_entry_id)
            total, rows = (
                len(links),
                [link.to_dict() for link in links[offset : offset + limit]],
            )
        return BrowsePage(tuple(rows), total, offset, limit)

    def verified_occurrence(self, link, reference):
        """Reject stale/contradictory provenance before any route is highlighted."""
        if isinstance(link, dict):
            link = CompositeDecompositionLink.from_dict(link)
        occurrence = reference.get_occurrence(link.reference_occurrence_id)
        entry = self.library.get_entry(link.composite_id)
        self.library.certified_rule(link)
        status = link.certificate.get("validation_status")
        if status not in {"validated_unique", "validated_ambiguous"}:
            raise ValueError("composite link is not certified")
        if (
            occurrence.route != self.route_key(link)
            or occurrence.identity.kind != link.kind
            or reference.entry_id_for_occurrence(link.reference_occurrence_id)
            != link.tactic_entry_id
            or link.link_id not in entry.link_ids
        ):
            raise ValueError(
                "composite link disagrees with Reference occurrence identity"
            )
        return occurrence
