"""Immutable companion library for certified composite decompositions."""

from __future__ import annotations

import csv
import ctypes
import gc
import hashlib
import json
import shutil
import signal
import sqlite3
import sys
import tempfile
import time
from collections import defaultdict, deque
from collections.abc import Iterable, Mapping, Sequence
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from itertools import chain
from pathlib import Path
from typing import Any, Literal

import route_inspector.routes.access as route_access
from route_inspector import __version__
from route_inspector.composite_rules.composite import CompositeRuleExtractor
from route_inspector.composite_rules.families import (
    IDENTITY_POLICY,
    key_for_version,
)
from route_inspector.composite_rules.identity import (
    identity_base_id,
    normalize_rule,
    variant_id,
)
from route_inspector.composite_rules.ring_breaking import (
    POLICY as RING_BREAKING_POLICY,
)
from route_inspector.composite_rules.ring_breaking import (
    aggregate_ring_breaking,
    classify_ring_breaking,
    summary_counts,
    validate_annotation,
)
from route_inspector.composite_rules.rrsubtree import (
    CompositeConstructionResult,
    RRSubtreeCompositeDecomposition,
    composite_rule_identity,
    construct_composite_rule,
)
from route_inspector.composite_rules.validation import ABSTRACTION_BOUNDARY_POLICY
from route_inspector.infrastructure.auditing import audit_scope
from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.infrastructure.runtime import (
    git_commit_hash,
    normalize_n_cpu,
    setup_runtime_cache_dirs,
)
from route_inspector.reference_library import ReferenceTacticLibrary
from route_inspector.reference_library.profile import canonical_json
from route_inspector.reference_library.storage.artifacts import (
    _publish_directory_no_replace,
)
from route_inspector.rules.config import RuleExtractionSettings
from route_inspector.tactics.rrsubtree.models import RRSubtreeOccurrence

COMPOSITE_LIBRARY_FORMAT_VERSION = 3
COMPOSITE_LIBRARY_SCHEMA_VERSION = 3
COMPOSITE_IDENTITY_VERSION = 3
COMPOSITE_LINK_SCHEMA_VERSION = 3

_EXECUTABLE_KINDS = ("rrseq_cons", "rrsubtree_cons")
_ARTIFACT_PATHS = {
    "entries": "composites/entries.jsonl",
    "links": "provenance/decomposition_links.jsonl",
    "rrseq_report": "reports/rrseq_cons.tsv",
    "rrsubtree_report": "reports/rrsubtree_cons.tsv",
    "errors": "reports/errors.jsonl",
    "summary": "summary.json",
    "catalog": "catalog.sqlite",
    "reindex_audit": "provenance/reindex.json",
}
_REQUIRED_ARTIFACTS = frozenset(
    {
        "entries",
        "links",
        "rrseq_report",
        "rrsubtree_report",
        "errors",
        "summary",
    }
)
_ALLOWED_ARTIFACTS = _REQUIRED_ARTIFACTS | {"catalog", "reindex_audit"}

_SCHEMA_SQL = """
CREATE TABLE metadata (
    key TEXT PRIMARY KEY,
    value_json TEXT NOT NULL
) WITHOUT ROWID;

CREATE TABLE entries (
    composite_id TEXT PRIMARY KEY,
    normalized_rule TEXT NOT NULL UNIQUE,
    entry_json TEXT NOT NULL
) WITHOUT ROWID;

CREATE TABLE links (
    link_id TEXT PRIMARY KEY,
    composite_id TEXT NOT NULL REFERENCES entries(composite_id),
    kind TEXT NOT NULL CHECK (kind IN ('rrseq_cons', 'rrsubtree_cons')),
    reference_occurrence_id TEXT NOT NULL,
    tactic_entry_id TEXT NOT NULL,
    dataset_id TEXT NOT NULL,
    source_identity TEXT NOT NULL,
    route_id TEXT NOT NULL,
    link_json TEXT NOT NULL,
    UNIQUE(composite_id, reference_occurrence_id)
) WITHOUT ROWID;

CREATE INDEX idx_links_composite_kind
    ON links(composite_id, kind, reference_occurrence_id);
CREATE INDEX idx_links_reference_occurrence
    ON links(reference_occurrence_id);
CREATE INDEX idx_links_route
    ON links(dataset_id, source_identity, route_id, kind);
"""


_VARIANT_SCHEMA_SQL = """
CREATE TABLE variants (
    normalized_rule TEXT PRIMARY KEY,
    variant_id TEXT NOT NULL,
    composite_id TEXT NOT NULL REFERENCES entries(composite_id)
) WITHOUT ROWID;
CREATE INDEX idx_variants_composite ON variants(composite_id);
CREATE TABLE identity_keys (
    composite_id TEXT PRIMARY KEY REFERENCES entries(composite_id),
    base_id TEXT NOT NULL,
    encoding TEXT NOT NULL UNIQUE
) WITHOUT ROWID;
CREATE INDEX idx_identity_base ON identity_keys(base_id);
"""


def _artifact(path: Path, root: Path) -> dict[str, Any]:
    return {
        "path": path.relative_to(root).as_posix(),
        "sha256": _sha256_file(path),
        "size_bytes": path.stat().st_size,
    }


def _canonical_jsonl(path: Path, values: Iterable[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        for value in values:
            stream.write(canonical_json(value))
            stream.write("\n")


def _read_jsonl(path: Path, *, label: str) -> tuple[Mapping[str, Any], ...]:
    values: list[Mapping[str, Any]] = []
    with path.open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"{label} line {line_number} is not valid JSON"
                ) from exc
            if not isinstance(value, Mapping):
                raise ValueError(f"{label} line {line_number} must be an object")
            values.append(value)
    return tuple(values)


def _link_id(
    composite_id: str,
    reference_occurrence_id: str,
    *,
    schema_version: int = COMPOSITE_LINK_SCHEMA_VERSION,
) -> str:
    digest = hashlib.sha256(
        canonical_json(
            {
                "schema_version": schema_version,
                "composite_id": composite_id,
                "reference_occurrence_id": reference_occurrence_id,
            }
        ).encode("utf-8")
    ).hexdigest()
    return f"composite_link_i_{digest}"


def _compact_certificate(result: CompositeConstructionResult) -> dict[str, Any]:
    source_replay = dict(result.source_replay)
    source_comparison = source_replay.get("comparison") or source_replay.get(
        "source_comparison"
    )
    composite_validation = dict(result.composite_validation or {})
    return {
        "source_occurrence_certified": result.accepted,
        "application_unique": (
            composite_validation.get("total_unique_outcomes") == 1
            and not composite_validation.get("truncated", True)
        ),
        "abstraction_boundary": composite_validation.get("abstraction_boundary"),
        "validation_status": result.validation_status,
        "source_replay_status": source_replay.get("status"),
        "source_chemistry_equivalent": (
            source_comparison.get("chemistry_equivalent")
            if isinstance(source_comparison, Mapping)
            else None
        ),
        "source_mapping_consistent": (
            source_comparison.get("mapping_consistent")
            if isinstance(source_comparison, Mapping)
            else None
        ),
        "composite_chemistry_equivalent": composite_validation.get(
            "chemistry_equivalent"
        ),
        "composite_mapping_consistent": composite_validation.get("mapping_consistent"),
        "composite_error_type": composite_validation.get("error_type"),
        "composite_error_message": composite_validation.get("error_message"),
        "all_edges_rrseq_connected": result.all_edges_rrseq_connected,
        "boundary_precursor_node_paths": [
            list(path) for path in result.boundary_precursor_node_paths
        ],
    }


@dataclass(frozen=True)
class CompositeDecompositionLink:
    """Compact certified link to one Reference-library occurrence."""

    link_id: str
    composite_id: str
    kind: str
    reference_occurrence_id: str
    tactic_entry_id: str
    dataset_id: str
    source_identity: str
    route_id: str
    certificate: Mapping[str, Any]
    schema_version: int = COMPOSITE_LINK_SCHEMA_VERSION
    variant_id: str | None = None
    composite_rule: str | None = None
    ring_breaking: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        validate_annotation(self.ring_breaking)
        if self.schema_version not in {1, 2, 3}:
            raise ValueError("unsupported composite decomposition-link schema")
        if self.kind not in _EXECUTABLE_KINDS:
            raise ValueError(f"unsupported executable tactic kind: {self.kind!r}")
        for field_name in (
            "composite_id",
            "reference_occurrence_id",
            "tactic_entry_id",
            "dataset_id",
            "source_identity",
            "route_id",
        ):
            if not str(getattr(self, field_name)):
                raise ValueError(f"{field_name} must not be empty")
        if self.link_id != _link_id(
            self.composite_id,
            self.reference_occurrence_id,
            schema_version=self.schema_version,
        ):
            raise ValueError("composite decomposition link ID is inconsistent")
        if self.schema_version >= 2:
            if not self.composite_rule or self.variant_id != variant_id(
                self.composite_rule
            ):
                raise ValueError(
                    "composite link must identify its exact certified variant"
                )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "link_id": self.link_id,
            "composite_id": self.composite_id,
            "kind": self.kind,
            "reference_occurrence_id": self.reference_occurrence_id,
            "tactic_entry_id": self.tactic_entry_id,
            "route": {
                "dataset_id": self.dataset_id,
                "source_identity": self.source_identity,
                "route_id": self.route_id,
            },
            "certificate": json.loads(canonical_json(self.certificate)),
            **(
                {"ring_breaking": dict(self.ring_breaking)}
                if self.ring_breaking is not None
                else {}
            ),
            **(
                {"variant_id": self.variant_id, "composite_rule": self.composite_rule}
                if self.schema_version >= 2
                else {}
            ),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "CompositeDecompositionLink":
        route = value["route"]
        if not isinstance(route, Mapping):
            raise ValueError("composite decomposition link route must be an object")
        return cls(
            schema_version=int(value["schema_version"]),
            link_id=str(value["link_id"]),
            composite_id=str(value["composite_id"]),
            kind=str(value["kind"]),
            reference_occurrence_id=str(value["reference_occurrence_id"]),
            tactic_entry_id=str(value["tactic_entry_id"]),
            dataset_id=str(route["dataset_id"]),
            source_identity=str(route["source_identity"]),
            route_id=str(route["route_id"]),
            certificate=dict(value.get("certificate") or {}),
            ring_breaking=value.get("ring_breaking"),
            variant_id=value.get("variant_id"),
            composite_rule=value.get("composite_rule"),
        )


@dataclass(frozen=True)
class CompositeLibraryEntry:
    """One structural family, retaining exact certified executable variants."""

    composite_id: str
    composite_rule: str
    normalized_rule: str
    link_ids: tuple[str, ...]
    occurrence_counts: Mapping[str, int]
    route_counts: Mapping[str, int]
    identity_version: int = COMPOSITE_IDENTITY_VERSION
    identity_key: str | None = None
    variants: tuple[Mapping[str, Any], ...] = ()
    ring_breaking_counts: Mapping[str, Mapping[str, int]] | None = None

    def __post_init__(self) -> None:
        if self.identity_version not in {1, 2, 3}:
            raise ValueError("unsupported composite identity version")
        base_id, normalized = composite_rule_identity(self.composite_rule)
        if self.normalized_rule != normalized:
            raise ValueError("normalized composite rule is inconsistent")
        if self.identity_version >= 2:
            if not self.identity_key or not self.variants:
                raise ValueError(
                    "structural identity requires its encoding and variants"
                )
            if json.loads(self.identity_key).get("version") != self.identity_version:
                raise ValueError("composite key and entry identity versions disagree")
            base_id = identity_base_id(self.identity_key)
            normalized_variants = tuple(v["normalized_rule"] for v in self.variants)
            if normalized_variants != tuple(sorted(set(normalized_variants))):
                raise ValueError("composite variants must be sorted and unique")
            if normalized != normalized_variants[0]:
                raise ValueError(
                    "representative must be the smallest normalized variant"
                )
            for value in self.variants:
                if value["variant_id"] != variant_id(value["normalized_rule"]):
                    raise ValueError("composite variant identity is inconsistent")
                if value["status"] not in {
                    "canonical",
                    "noncanonical_fallback",
                    "exact_representation",
                }:
                    raise ValueError("unsupported composite key status")
        if not self.composite_id.startswith(f"{base_id}~"):
            raise ValueError("composite ID is inconsistent with its versioned identity")
        if tuple(sorted(set(self.link_ids))) != self.link_ids:
            raise ValueError("composite link IDs must be sorted and unique")

    @property
    def occurrence_count(self) -> int:
        return sum(int(value) for value in self.occurrence_counts.values())

    @property
    def route_count(self) -> int:
        return int(self.route_counts.get("all", 0))

    def to_dict(self) -> dict[str, Any]:
        return {
            "identity_version": self.identity_version,
            "composite_id": self.composite_id,
            "composite_rule": self.composite_rule,
            "normalized_rule": self.normalized_rule,
            "link_ids": list(self.link_ids),
            "occurrence_counts": dict(self.occurrence_counts),
            "route_counts": dict(self.route_counts),
            **(
                {"ring_breaking_counts": self.ring_breaking_counts}
                if self.ring_breaking_counts is not None
                else {}
            ),
            **(
                {
                    "identity_key": self.identity_key,
                    "variants": [dict(v) for v in self.variants],
                }
                if self.identity_version >= 2
                else {}
            ),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "CompositeLibraryEntry":
        return cls(
            identity_version=int(value["identity_version"]),
            composite_id=str(value["composite_id"]),
            composite_rule=str(value["composite_rule"]),
            normalized_rule=str(value["normalized_rule"]),
            identity_key=value.get("identity_key"),
            variants=tuple(dict(v) for v in value.get("variants", ())),
            ring_breaking_counts=value.get("ring_breaking_counts"),
            link_ids=tuple(str(item) for item in value["link_ids"]),
            occurrence_counts={
                str(key): int(count)
                for key, count in dict(value["occurrence_counts"]).items()
            },
            route_counts={
                str(key): int(count)
                for key, count in dict(value["route_counts"]).items()
            },
        )


@dataclass(frozen=True)
class CompositeLibraryManifest:
    """Provenance and integrity contract for one companion library."""

    library_id: str
    source_reference_library_id: str
    source_processing_profile_fingerprint: str
    source_routes_sha256: str
    construction_profile: Mapping[str, Any]
    statistics: Mapping[str, Any]
    artifacts: Mapping[str, Mapping[str, Any]]
    route_inspector_version: str = __version__
    route_inspector_commit: str = ""
    library_format_version: int = COMPOSITE_LIBRARY_FORMAT_VERSION
    catalog_schema_version: int = COMPOSITE_LIBRARY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.library_format_version not in {1, 2, 3}:
            raise ValueError("unsupported composite library format")
        if self.catalog_schema_version != self.library_format_version:
            raise ValueError("unsupported composite library catalog schema")
        if len(self.source_routes_sha256) != 64 or any(
            character not in "0123456789abcdef"
            for character in self.source_routes_sha256.lower()
        ):
            raise ValueError("source route digest is invalid")
        for field_name in (
            "library_id",
            "source_reference_library_id",
            "source_processing_profile_fingerprint",
        ):
            if not str(getattr(self, field_name)):
                raise ValueError(f"{field_name} must not be empty")

    def to_dict(self) -> dict[str, Any]:
        return {
            "library_format_version": self.library_format_version,
            "catalog_schema_version": self.catalog_schema_version,
            "library_id": self.library_id,
            "source_reference_library_id": self.source_reference_library_id,
            "source_processing_profile_fingerprint": (
                self.source_processing_profile_fingerprint
            ),
            "source_routes_sha256": self.source_routes_sha256,
            "construction_profile": json.loads(
                canonical_json(self.construction_profile)
            ),
            "statistics": json.loads(canonical_json(self.statistics)),
            "artifacts": json.loads(canonical_json(self.artifacts)),
            "route_inspector_version": self.route_inspector_version,
            "route_inspector_commit": self.route_inspector_commit,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "CompositeLibraryManifest":
        return cls(
            library_format_version=int(value["library_format_version"]),
            catalog_schema_version=int(value["catalog_schema_version"]),
            library_id=str(value["library_id"]),
            source_reference_library_id=str(value["source_reference_library_id"]),
            source_processing_profile_fingerprint=str(
                value["source_processing_profile_fingerprint"]
            ),
            source_routes_sha256=str(value["source_routes_sha256"]),
            construction_profile=dict(value["construction_profile"]),
            statistics=dict(value["statistics"]),
            artifacts=dict(value["artifacts"]),
            route_inspector_version=str(value.get("route_inspector_version") or ""),
            route_inspector_commit=str(value.get("route_inspector_commit") or ""),
        )


def _library_id(
    source_library_id: str,
    routes_digest: str,
    construction_profile: Mapping[str, Any],
    entries: Sequence[CompositeLibraryEntry],
    links: Sequence[CompositeDecompositionLink],
    *,
    format_version: int = COMPOSITE_LIBRARY_FORMAT_VERSION,
) -> str:
    # Stream canonical JSON in the same key order as the historical identity.
    digest = hashlib.sha256()
    values = {
        "format_version": format_version,
        "source_reference_library_id": source_library_id,
        "source_routes_sha256": routes_digest,
        "construction_profile": construction_profile,
        "entries": entries,
        "links": links,
    }
    digest.update(b"{")
    for index, key in enumerate(sorted(values)):
        if index:
            digest.update(b",")
        digest.update((canonical_json(key) + ":").encode())
        if key in {"entries", "links"}:
            digest.update(b"[")
            for ordinal, value in enumerate(values[key]):
                if ordinal:
                    digest.update(b",")
                digest.update(canonical_json(value.to_dict()).encode())
            digest.update(b"]")
        else:
            digest.update(canonical_json(values[key]).encode())
    digest.update(b"}")
    return f"composite_library_{digest.hexdigest()}"


@dataclass(frozen=True)
class _AcceptedConstruction:
    """Compact state; complete native payloads stay in the source library."""

    composite_rule: str
    kind: str
    reference_occurrence_id: str
    tactic_entry_id: str
    dataset_id: str
    source_identity: str
    route_id: str
    certificate: Mapping[str, Any]
    ring_breaking: Mapping[str, Any] | None = None


def _aggregate_results(
    accepted: Sequence[_AcceptedConstruction],
    *,
    identity_version: int = COMPOSITE_IDENTITY_VERSION,
) -> tuple[tuple[CompositeLibraryEntry, ...], tuple[CompositeDecompositionLink, ...]]:
    grouped: dict[str, list[_AcceptedConstruction]] = defaultdict(list)
    seen_occurrences: set[str] = set()
    for result in accepted:
        if result.reference_occurrence_id in seen_occurrences:
            raise ValueError("duplicate certified Reference occurrence")
        seen_occurrences.add(result.reference_occurrence_id)
        key = key_for_version(normalize_rule(result.composite_rule), identity_version)
        grouped[key.encoding].append(result)

    entries: list[CompositeLibraryEntry] = []
    links: list[CompositeDecompositionLink] = []
    buckets: dict[str, list[str]] = defaultdict(list)
    for encoding in grouped:
        buckets[identity_base_id(encoding)].append(encoding)

    composite_ids = {
        normalized: f"{base_id}~{ordinal:04d}"
        for base_id, rules in sorted(buckets.items())
        for ordinal, normalized in enumerate(sorted(rules))
    }
    for encoding in sorted(grouped):
        members = sorted(
            grouped[encoding],
            key=lambda item: item.reference_occurrence_id,
        )
        composite_id = composite_ids[encoding]
        variants = tuple(
            {
                "variant_id": variant_id(rule),
                "normalized_rule": rule,
                **key_for_version(rule, identity_version).audit(),
            }
            for rule in sorted({normalize_rule(m.composite_rule) for m in members})
        )
        normalized = variants[0]["normalized_rule"]
        member_links: list[CompositeDecompositionLink] = []
        for result in members:
            member_links.append(
                CompositeDecompositionLink(
                    schema_version=identity_version,
                    link_id=_link_id(
                        composite_id,
                        result.reference_occurrence_id,
                        schema_version=identity_version,
                    ),
                    composite_id=composite_id,
                    kind=result.kind,
                    reference_occurrence_id=result.reference_occurrence_id,
                    tactic_entry_id=result.tactic_entry_id,
                    dataset_id=result.dataset_id,
                    source_identity=result.source_identity,
                    route_id=result.route_id,
                    certificate=result.certificate,
                    ring_breaking=result.ring_breaking,
                    variant_id=variant_id(result.composite_rule),
                    composite_rule=result.composite_rule,
                )
            )
        links.extend(member_links)
        occurrence_counts = {
            kind: sum(link.kind == kind for link in member_links)
            for kind in _EXECUTABLE_KINDS
        }
        route_sets = {
            kind: {
                (link.dataset_id, link.source_identity, link.route_id)
                for link in member_links
                if link.kind == kind
            }
            for kind in _EXECUTABLE_KINDS
        }
        all_routes = set().union(*route_sets.values())
        entries.append(
            CompositeLibraryEntry(
                identity_version=identity_version,
                composite_id=composite_id,
                composite_rule=normalized,
                normalized_rule=normalized,
                identity_key=encoding,
                variants=variants,
                link_ids=tuple(sorted(link.link_id for link in member_links)),
                ring_breaking_counts=aggregate_ring_breaking(member_links),
                occurrence_counts=occurrence_counts,
                route_counts={
                    **{kind: len(values) for kind, values in route_sets.items()},
                    "all": len(all_routes),
                },
            )
        )
    return tuple(sorted(entries, key=lambda value: value.composite_id)), tuple(
        sorted(links, key=lambda value: value.link_id)
    )


def identity_statistics(entries, *, identity_version=None):
    from collections import Counter

    counts = Counter()
    version = identity_version
    for entry in entries:
        version = version or entry.identity_version
        if entry.identity_version != version:
            raise ValueError("mixed composite identity versions")
        counts.update(v["status"] for v in entry.variants)
    return {
        "identity_version": version or COMPOSITE_IDENTITY_VERSION,
        "exact_variant_count": sum(counts.values()),
        **{
            f"identity_{status}_variant_count": counts[status]
            for status in ("canonical", "noncanonical_fallback", "exact_representation")
        },
    }


class CompositeDecompositionLibrary:
    """Exact composite catalog with lazy SQLite-backed decomposition links."""

    def __init__(
        self,
        *,
        manifest: CompositeLibraryManifest,
        entries: Sequence[CompositeLibraryEntry] | None,
        links: Sequence[CompositeDecompositionLink] | None,
        errors: Sequence[Mapping[str, Any]] = (),
        directory: Path | None = None,
        connection: sqlite3.Connection | None = None,
        reindex_audit: Mapping[str, Any] | None = None,
    ) -> None:
        self.manifest = manifest
        self._entries = None if entries is None else tuple(entries)
        self._links = None if links is None else tuple(links)
        self._errors = tuple(json.loads(canonical_json(value)) for value in errors)
        self.directory = directory
        self._connection = connection
        self.reindex_audit = reindex_audit
        self._entry_cache = {entry.composite_id: entry for entry in self._entries or ()}
        from route_inspector.infrastructure.build_workspace import ByteMemo

        self._disk_entry = ByteMemo(self._read_entry)

    def __enter__(self) -> "CompositeDecompositionLibrary":
        return self

    def __exit__(self, *_args: Any) -> None:
        self.close()

    def close(self) -> None:
        if self._connection is not None:
            self._connection.close()
            self._connection = None

    @property
    def library_id(self) -> str:
        return self.manifest.library_id

    @property
    def errors(self) -> tuple[Mapping[str, Any], ...]:
        return self._errors

    def assert_reference_library(self, library: ReferenceTacticLibrary) -> None:
        if library.library_id != self.manifest.source_reference_library_id:
            raise ValueError(
                "composite library was built from a different Reference library"
            )
        fingerprint = library.processing_profile.fingerprint
        if fingerprint != self.manifest.source_processing_profile_fingerprint:
            raise ValueError(
                "Reference processing-profile fingerprint does not match "
                "the composite library"
            )

    def entries(self, kind: str | None = None) -> tuple[CompositeLibraryEntry, ...]:
        if kind is not None and kind not in _EXECUTABLE_KINDS:
            raise ValueError(f"unsupported executable kind: {kind!r}")
        if self._entries is not None:
            values = self._entries
        else:
            if self._connection is None:
                raise RuntimeError("composite library is closed")
            values = tuple(
                CompositeLibraryEntry.from_dict(json.loads(row[0]))
                for row in self._connection.execute(
                    "SELECT entry_json FROM entries ORDER BY composite_id"
                )
            )
        if kind is None:
            return tuple(values)
        return tuple(
            entry for entry in values if int(entry.occurrence_counts.get(kind, 0)) > 0
        )

    def get_entry(self, composite_id: str) -> CompositeLibraryEntry:
        normalized = str(composite_id)
        cached = self._entry_cache.get(normalized)
        if cached is not None:
            return cached
        return self._disk_entry(normalized)

    def _read_entry(self, normalized: str) -> CompositeLibraryEntry:
        if self._connection is None:
            raise KeyError(f"unknown composite entry: {normalized}")
        row = self._connection.execute(
            "SELECT entry_json FROM entries WHERE composite_id = ?",
            (normalized,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown composite entry: {normalized}")
        entry = CompositeLibraryEntry.from_dict(json.loads(row[0]))
        return entry

    def lookup_rule(self, composite_rule: str) -> CompositeLibraryEntry | None:
        normalized = normalize_rule(composite_rule)
        if self._entries is not None:
            matches = [
                entry
                for entry in self._entries
                if entry.normalized_rule == normalized
                or any(v["normalized_rule"] == normalized for v in entry.variants)
            ]
        else:
            if self._connection is None:
                raise RuntimeError("composite library is closed")
            sql = (
                "SELECT entry_json FROM variants JOIN entries USING (composite_id) WHERE variants.normalized_rule = ?"
                if self.manifest.catalog_schema_version >= 2
                else "SELECT entry_json FROM entries WHERE normalized_rule = ?"
            )
            row = self._connection.execute(
                sql,
                (normalized,),
            ).fetchone()
            matches = (
                []
                if row is None
                else [CompositeLibraryEntry.from_dict(json.loads(row[0]))]
            )
        if not matches and self.manifest.library_format_version >= 2:
            key = key_for_version(normalized, self.manifest.library_format_version)
            if self._entries is not None:
                matches = [e for e in self._entries if e.identity_key == key.encoding]
            else:
                matches = [
                    CompositeLibraryEntry.from_dict(json.loads(row[0]))
                    for row in self._connection.execute(
                        "SELECT entry_json FROM identity_keys JOIN entries USING (composite_id) "
                        "WHERE base_id = ? AND encoding = ?",
                        (key.base_id, key.encoding),
                    )
                ]
        if len(matches) > 1:
            raise RuntimeError("exact composite rule matched multiple entries")
        return matches[0] if matches else None

    def certified_rule(self, link: CompositeDecompositionLink) -> str:
        """Resolve the recorded executable variant, never a family substitute."""
        if self.link_for_occurrence(link.reference_occurrence_id) != link:
            raise ValueError(
                "link differs from its recorded certified variant or provenance"
            )
        entry = self.get_entry(link.composite_id)
        if link.link_id not in entry.link_ids:
            raise ValueError("composite link is not a member of its entry")
        if entry.identity_version == 1:
            if link.schema_version != 1:
                raise ValueError("composite link/entry identity versions disagree")
            return entry.composite_rule
        if link.schema_version != entry.identity_version or not any(
            v["variant_id"] == link.variant_id
            and v["normalized_rule"] == normalize_rule(link.composite_rule)
            for v in entry.variants
        ):
            raise ValueError("composite link disagrees with its certified variant")
        return link.composite_rule

    def links_for_entry(
        self,
        composite_id: str,
        *,
        kind: str | None = None,
    ) -> tuple[CompositeDecompositionLink, ...]:
        self.get_entry(composite_id)
        if kind is not None and kind not in _EXECUTABLE_KINDS:
            raise ValueError(f"unsupported executable kind: {kind!r}")
        if self._links is not None:
            values = tuple(
                link
                for link in self._links
                if link.composite_id == composite_id
                and (kind is None or link.kind == kind)
            )
        else:
            if self._connection is None:
                raise RuntimeError("composite library is closed")
            sql = "SELECT link_json FROM links WHERE composite_id = ?"
            parameters: list[Any] = [composite_id]
            if kind is not None:
                sql += " AND kind = ?"
                parameters.append(kind)
            sql += " ORDER BY reference_occurrence_id"
            values = tuple(
                CompositeDecompositionLink.from_dict(json.loads(row[0]))
                for row in self._connection.execute(sql, tuple(parameters))
            )
        return tuple(sorted(values, key=lambda value: value.reference_occurrence_id))

    def link_for_occurrence(
        self,
        reference_occurrence_id: str,
    ) -> CompositeDecompositionLink | None:
        """Return one certified link through the persisted occurrence index."""

        normalized = str(reference_occurrence_id)
        if self._links is not None:
            matches = tuple(
                link
                for link in self._links
                if link.reference_occurrence_id == normalized
            )
        else:
            if self._connection is None:
                raise RuntimeError("composite library is closed")
            rows = self._connection.execute(
                "SELECT link_json FROM links WHERE reference_occurrence_id = ?",
                (normalized,),
            ).fetchall()
            matches = tuple(
                CompositeDecompositionLink.from_dict(json.loads(row[0])) for row in rows
            )
        if len(matches) > 1:
            raise RuntimeError(
                "one Reference occurrence is linked to multiple composites"
            )
        return matches[0] if matches else None

    def decompositions_for_rule(
        self,
        composite_rule: str,
        reference_library: ReferenceTacticLibrary,
        *,
        kind: str = "rrsubtree_cons",
        limit: int | None = None,
    ) -> tuple[RRSubtreeCompositeDecomposition, ...]:
        """Resolve certified RRSubtree definitions through indexed occurrence IDs."""

        if kind != "rrsubtree_cons":
            raise ValueError(
                "RRSubtree decomposition resolution requires kind='rrsubtree_cons'"
            )
        self.assert_reference_library(reference_library)
        entry = self.lookup_rule(composite_rule)
        if entry is None:
            return ()
        links = self.links_for_entry(entry.composite_id, kind=kind)
        # Family membership does not transfer a replay certificate to a different
        # executable mapping or component order.
        links = tuple(
            link
            for link in links
            if normalize_rule(self.certified_rule(link))
            == normalize_rule(composite_rule)
        )
        if limit is not None:
            if limit < 0:
                raise ValueError("limit must be non-negative")
            links = links[:limit]
        values: list[RRSubtreeCompositeDecomposition] = []
        for link in links:
            occurrence = reference_library.get_occurrence(link.reference_occurrence_id)
            if occurrence.identity.kind != "rrsubtree_cons":
                raise ValueError(
                    "composite link resolved to a non-RRSubtree occurrence"
                )
            values.append(
                RRSubtreeCompositeDecomposition(
                    composite_rule=self.certified_rule(link),
                    reference_occurrence_id=link.reference_occurrence_id,
                    tactic_entry_id=link.tactic_entry_id,
                    occurrence=RRSubtreeOccurrence.from_dict(occurrence.native_payload),
                    certificate_status=str(
                        link.certificate.get("validation_status") or ""
                    ),
                    boundary_policy=(
                        link.certificate.get("abstraction_boundary") or {}
                    ).get("policy", "full_recorded_boundary"),
                )
            )
        return tuple(values)

    def save(self, directory: str | Path, *, include_sqlite: bool = True) -> None:
        if self._entries is None or self._links is None:
            raise RuntimeError("only an in-memory composite library can be saved")
        destination = Path(directory).expanduser()
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            raise FileExistsError(destination)
        if (
            self.reindex_audit is None
            and self.directory is not None
            and "reindex_audit" in self.manifest.artifacts
        ):
            self.reindex_audit = json.loads(
                (
                    self.directory / self.manifest.artifacts["reindex_audit"]["path"]
                ).read_text(encoding="utf-8")
            )
        temporary = Path(
            tempfile.mkdtemp(
                prefix=f".{destination.name}.",
                dir=destination.parent,
            )
        )
        try:
            entries_path = temporary / _ARTIFACT_PATHS["entries"]
            links_path = temporary / _ARTIFACT_PATHS["links"]
            _canonical_jsonl(
                entries_path,
                (entry.to_dict() for entry in self._entries),
            )
            _canonical_jsonl(
                links_path,
                (link.to_dict() for link in self._links),
            )
            errors_path = temporary / _ARTIFACT_PATHS["errors"]
            _canonical_jsonl(errors_path, self._errors)
            if self.reindex_audit is not None:
                (temporary / _ARTIFACT_PATHS["reindex_audit"]).write_text(
                    canonical_json(self.reindex_audit) + "\n", encoding="utf-8"
                )
            for kind, artifact_name in (
                ("rrseq_cons", "rrseq_report"),
                ("rrsubtree_cons", "rrsubtree_report"),
            ):
                report_path = temporary / _ARTIFACT_PATHS[artifact_name]
                report_path.parent.mkdir(parents=True, exist_ok=True)
                with report_path.open("w", encoding="utf-8", newline="") as stream:
                    writer = csv.DictWriter(
                        stream,
                        fieldnames=(
                            "composite_id",
                            "popularity",
                            "occurrence_count",
                            "Composite_rule",
                        ),
                        delimiter="\t",
                    )
                    writer.writeheader()
                    for entry in self._entries:
                        count = int(entry.occurrence_counts.get(kind, 0))
                        if not count:
                            continue
                        writer.writerow(
                            {
                                "composite_id": entry.composite_id,
                                "popularity": entry.route_counts.get(kind, 0),
                                "occurrence_count": count,
                                "Composite_rule": entry.composite_rule,
                            }
                        )
            summary_path = temporary / _ARTIFACT_PATHS["summary"]
            summary_path.write_text(
                json.dumps(self.manifest.statistics, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            if include_sqlite:
                catalog_path = temporary / _ARTIFACT_PATHS["catalog"]
                connection = sqlite3.connect(catalog_path)
                try:
                    connection.executescript(_SCHEMA_SQL)
                    if self.manifest.catalog_schema_version >= 2:
                        connection.executescript(_VARIANT_SCHEMA_SQL)
                    metadata = {
                        "library_id": self.library_id,
                        "source_reference_library_id": (
                            self.manifest.source_reference_library_id
                        ),
                        "entry_count": len(self._entries),
                        "link_count": len(self._links),
                    }
                    connection.executemany(
                        "INSERT INTO metadata VALUES (?, ?)",
                        (
                            (key, canonical_json(value))
                            for key, value in metadata.items()
                        ),
                    )
                    connection.executemany(
                        "INSERT INTO entries VALUES (?, ?, ?)",
                        (
                            (
                                entry.composite_id,
                                entry.normalized_rule,
                                canonical_json(entry.to_dict()),
                            )
                            for entry in self._entries
                        ),
                    )
                    connection.executemany(
                        "INSERT INTO links VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (
                            (
                                link.link_id,
                                link.composite_id,
                                link.kind,
                                link.reference_occurrence_id,
                                link.tactic_entry_id,
                                link.dataset_id,
                                link.source_identity,
                                link.route_id,
                                canonical_json(link.to_dict()),
                            )
                            for link in self._links
                        ),
                    )
                    if self.manifest.catalog_schema_version >= 2:
                        connection.executemany(
                            "INSERT INTO variants VALUES (?, ?, ?)",
                            (
                                (v["normalized_rule"], v["variant_id"], e.composite_id)
                                for e in self._entries
                                for v in e.variants
                            ),
                        )
                        connection.executemany(
                            "INSERT INTO identity_keys VALUES (?, ?, ?)",
                            (
                                (
                                    e.composite_id,
                                    identity_base_id(e.identity_key),
                                    e.identity_key,
                                )
                                for e in self._entries
                            ),
                        )
                    for kind in (*_EXECUTABLE_KINDS, "all"):
                        connection.execute(
                            f"CREATE INDEX idx_entries_ring_breaking_{kind} ON entries "
                            f"(json_extract(entry_json, '$.ring_breaking_counts.{kind}.yes'))"
                        )
                    connection.commit()
                finally:
                    connection.close()

            artifact_names = [
                "entries",
                "links",
                "rrseq_report",
                "rrsubtree_report",
                "errors",
                "summary",
            ]
            if include_sqlite:
                artifact_names.append("catalog")
            if self.reindex_audit is not None:
                artifact_names.append("reindex_audit")
            artifacts = {
                name: _artifact(temporary / _ARTIFACT_PATHS[name], temporary)
                for name in artifact_names
            }
            manifest = CompositeLibraryManifest(
                library_format_version=self.manifest.library_format_version,
                catalog_schema_version=self.manifest.catalog_schema_version,
                library_id=self.manifest.library_id,
                source_reference_library_id=(self.manifest.source_reference_library_id),
                source_processing_profile_fingerprint=(
                    self.manifest.source_processing_profile_fingerprint
                ),
                source_routes_sha256=self.manifest.source_routes_sha256,
                construction_profile=self.manifest.construction_profile,
                statistics=self.manifest.statistics,
                artifacts=artifacts,
                route_inspector_version=self.manifest.route_inspector_version,
                route_inspector_commit=self.manifest.route_inspector_commit,
            )
            (temporary / "manifest.json").write_text(
                json.dumps(manifest.to_dict(), indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            if destination.exists():
                raise FileExistsError(
                    "composite-library destination appeared during build: "
                    f"{destination}"
                )
            _publish_directory_no_replace(temporary, destination)
        except Exception:
            shutil.rmtree(temporary, ignore_errors=True)
            raise
        self.manifest = manifest

    @classmethod
    @audit_scope
    def load(
        cls,
        directory: str | Path,
        *,
        verification: Literal["fast", "full"] = "fast",
    ) -> "CompositeDecompositionLibrary":
        """Open a previously verified, unchanged companion in ``fast`` mode.

        The default trusts the caller to keep the library immutable; size and
        metadata checks do not detect every later modification. ``full`` hashes
        every declared artifact before use and is appropriate after building,
        importing, copying or updating the companion. Keep its source Reference
        library under the same trust policy. Matching semantics are unchanged.
        """
        if verification not in {"fast", "full"}:
            raise ValueError("verification must be 'fast' or 'full'")
        root = Path(directory).expanduser()
        raw_manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
        if not isinstance(raw_manifest, Mapping):
            raise ValueError("composite manifest must contain an object")
        manifest = CompositeLibraryManifest.from_dict(raw_manifest)
        artifact_names = set(manifest.artifacts)
        if not _REQUIRED_ARTIFACTS.issubset(
            artifact_names
        ) or not artifact_names.issubset(_ALLOWED_ARTIFACTS):
            raise ValueError(
                "composite manifest artifact set is incomplete or unknown: "
                f"{sorted(artifact_names)}"
            )
        for name, descriptor in manifest.artifacts.items():
            if descriptor.get("path") != _ARTIFACT_PATHS[name]:
                raise ValueError(
                    f"composite artifact {name!r} must use canonical path "
                    f"{_ARTIFACT_PATHS[name]!r}"
                )
            path = root / str(descriptor["path"])
            if not path.is_file():
                raise FileNotFoundError(path)
            if path.stat().st_size != int(descriptor["size_bytes"]):
                raise ValueError(f"composite artifact size mismatch: {path}")
            if verification == "full":
                if _sha256_file(path) != descriptor["sha256"]:
                    raise ValueError(f"composite artifact hash mismatch: {path}")

        catalog_descriptor = manifest.artifacts.get("catalog")
        if catalog_descriptor is not None:
            connection = sqlite3.connect(
                (root / str(catalog_descriptor["path"])).resolve().as_uri()
                + "?mode=ro",
                uri=True,
            )
            connection.row_factory = sqlite3.Row
            metadata = {
                str(row["key"]): json.loads(row["value_json"])
                for row in connection.execute("SELECT * FROM metadata")
            }
            if metadata.get("library_id") != manifest.library_id:
                connection.close()
                raise ValueError("composite SQLite catalog disagrees with manifest")
            if int(metadata.get("entry_count", -1)) != int(
                manifest.statistics.get("composite_entry_count", -2)
            ) or int(metadata.get("link_count", -1)) != int(
                manifest.statistics.get("certified_link_count", -2)
            ):
                connection.close()
                raise ValueError("composite SQLite counts disagree with manifest")
            errors = tuple(
                _read_jsonl(
                    root / str(manifest.artifacts["errors"]["path"]),
                    label="composite errors",
                )
            )
            return cls(
                manifest=manifest,
                entries=None,
                links=None,
                errors=errors,
                directory=root,
                connection=connection,
            )
        entries = tuple(
            CompositeLibraryEntry.from_dict(value)
            for value in _read_jsonl(
                root / str(manifest.artifacts["entries"]["path"]),
                label="composite entries",
            )
        )
        links = tuple(
            CompositeDecompositionLink.from_dict(value)
            for value in _read_jsonl(
                root / str(manifest.artifacts["links"]["path"]),
                label="composite links",
            )
        )
        errors = tuple(
            _read_jsonl(
                root / str(manifest.artifacts["errors"]["path"]),
                label="composite errors",
            )
        )
        return cls(
            manifest=manifest,
            entries=entries,
            links=links,
            errors=errors,
            directory=root,
        )


@dataclass(frozen=True)
class CompositeLibraryBuildResult:
    """Built companion library plus retained occurrence-level diagnostics."""

    library: CompositeDecompositionLibrary
    constructions_seen: int
    certified_links: int
    errors: tuple[Mapping[str, Any], ...]


class _OccurrenceTimeout(BaseException):
    """Escape chemistry helpers that turn ordinary exceptions into diagnostics."""

    pass


def _release_unused_memory() -> None:
    """Collect chemistry object cycles and return free glibc pages when available."""

    gc.collect()
    try:
        malloc_trim = ctypes.CDLL(None).malloc_trim
    except (AttributeError, OSError):
        return
    malloc_trim.argtypes = (ctypes.c_size_t,)
    malloc_trim.restype = ctypes.c_int
    malloc_trim(0)


def _construct_with_timeout(
    occurrence: Any,
    *,
    source_route: Mapping[str, Any] | None,
    extractor: CompositeRuleExtractor,
    max_replay_outcomes: int,
    max_variants: int,
    allow_ambiguous: bool,
    timeout_seconds: float | None,
) -> CompositeConstructionResult:
    if timeout_seconds is None:
        return construct_composite_rule(
            occurrence,
            source_route=source_route,
            extractor=extractor,
            max_replay_outcomes=max_replay_outcomes,
            max_variants=max_variants,
            allow_ambiguous=allow_ambiguous,
        )
    if timeout_seconds <= 0:
        raise ValueError("application timeout must be positive")
    if not hasattr(signal, "SIGALRM"):
        raise RuntimeError("per-occurrence timeout requires POSIX SIGALRM")
    previous = signal.getsignal(signal.SIGALRM)

    def timeout(_signum: int, _frame: Any) -> None:
        raise _OccurrenceTimeout(
            f"composite construction exceeded {timeout_seconds:g} seconds"
        )

    signal.signal(signal.SIGALRM, timeout)
    signal.setitimer(signal.ITIMER_REAL, timeout_seconds)
    try:
        return construct_composite_rule(
            occurrence,
            source_route=source_route,
            extractor=extractor,
            max_replay_outcomes=max_replay_outcomes,
            max_variants=max_variants,
            allow_ambiguous=allow_ambiguous,
        )
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous)


@dataclass(frozen=True)
class _CompositeLibraryWorkItem:
    kind: str
    occurrence: Any
    source_route: Mapping[str, Any] | None
    tactic_entry_id: str


@dataclass(frozen=True)
class _CompositeLibraryWorkOutcome:
    accepted: _AcceptedConstruction | None = None
    error: Mapping[str, Any] | None = None
    fatal: bool = False


_COMPOSITE_LIBRARY_WORKER_EXTRACTOR: CompositeRuleExtractor | None = None
_COMPOSITE_LIBRARY_WORKER_OPTIONS: Mapping[str, Any] = {}


def _construct_library_item(
    item: _CompositeLibraryWorkItem,
    extractor: CompositeRuleExtractor,
    options: Mapping[str, Any],
) -> _CompositeLibraryWorkOutcome:
    occurrence = item.occurrence
    kind = item.kind
    from route_inspector.rules.evidence import EvidenceCacheError

    try:
        result = _construct_with_timeout(
            occurrence,
            source_route=item.source_route,
            extractor=extractor,
            max_replay_outcomes=int(options["max_replay_outcomes"]),
            max_variants=int(options["max_variants"]),
            allow_ambiguous=bool(options["allow_ambiguous"]),
            timeout_seconds=options["application_timeout_seconds"],
        )
    except EvidenceCacheError:
        raise
    except (_OccurrenceTimeout, Exception) as exc:
        return _CompositeLibraryWorkOutcome(
            error={
                "kind": kind,
                "reference_occurrence_id": occurrence.reference_occurrence_id,
                "route_id": occurrence.route.route_id,
                "error_type": type(exc).__name__,
                "message": str(exc),
            },
            fatal=True,
        )
    if not result.accepted:
        return _CompositeLibraryWorkOutcome(
            error={
                "kind": kind,
                "reference_occurrence_id": occurrence.reference_occurrence_id,
                "route_id": occurrence.route.route_id,
                "error_type": "UncertifiedComposite",
                "message": result.validation_status,
                "certificate": _compact_certificate(result),
                "diagnostics": [dict(item) for item in result.diagnostics],
            }
        )
    if result.composite_rule is None:
        return _CompositeLibraryWorkOutcome(
            error={
                "kind": kind,
                "reference_occurrence_id": occurrence.reference_occurrence_id,
                "route_id": occurrence.route.route_id,
                "error_type": "InvalidAcceptedComposite",
                "message": "accepted composite construction has no executable rule",
            },
            fatal=True,
        )
    return _CompositeLibraryWorkOutcome(
        accepted=_AcceptedConstruction(
            composite_rule=result.composite_rule,
            kind=result.kind,
            reference_occurrence_id=result.reference_occurrence_id,
            tactic_entry_id=item.tactic_entry_id,
            dataset_id=occurrence.route.dataset_id,
            source_identity=occurrence.route.source_identity,
            route_id=occurrence.route.route_id,
            certificate=_compact_certificate(result),
            ring_breaking=classify_ring_breaking(result.pseudo_reaction_smiles),
        )
    )


def _init_composite_library_worker(
    extractor_args: Mapping[str, Any],
    extractor_cache_size: int | None,
    options: Mapping[str, Any],
    evidence_file=None,
) -> None:
    global _COMPOSITE_LIBRARY_WORKER_EXTRACTOR
    global _COMPOSITE_LIBRARY_WORKER_OPTIONS
    setup_runtime_cache_dirs()
    _COMPOSITE_LIBRARY_WORKER_EXTRACTOR = CompositeRuleExtractor.from_args(
        RuleExtractionSettings(**dict(extractor_args)),
        retain_query_cgr=False,
        max_cache_size=extractor_cache_size,
    )
    _COMPOSITE_LIBRARY_WORKER_OPTIONS = dict(options)
    if evidence_file is not None:
        from route_inspector.rules.evidence import configure_evidence

        configure_evidence(_COMPOSITE_LIBRARY_WORKER_EXTRACTOR, evidence_file)


def _process_composite_library_item(
    item: _CompositeLibraryWorkItem,
) -> _CompositeLibraryWorkOutcome:
    if _COMPOSITE_LIBRARY_WORKER_EXTRACTOR is None:
        raise RuntimeError("composite-library worker is not initialized")
    return _construct_library_item(
        item,
        _COMPOSITE_LIBRARY_WORKER_EXTRACTOR,
        _COMPOSITE_LIBRARY_WORKER_OPTIONS,
    )


def _render_composite_progress(
    completed: int,
    total: int,
    started_at: float,
    *,
    workers: int,
) -> None:
    elapsed = max(time.monotonic() - started_at, 1e-9)
    fraction = completed / total if total else 1.0
    width = 28
    filled = min(width, int(width * fraction))
    bar = "#" * filled + "-" * (width - filled)
    ending = "\n" if completed >= total else ""
    print(
        f"\r[composite-library] |{bar}| {completed:,}/{total:,} "
        f"({fraction:6.1%}) {completed / elapsed:6.1f} occurrences/s "
        f"elapsed {elapsed:,.1f}s workers={workers}",
        end=ending,
        file=sys.stderr,
        flush=True,
    )


def _config_json_value(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _config_json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_config_json_value(item) for item in value]
    return str(value)


def _composite_extraction_profile(
    extractor: CompositeRuleExtractor,
) -> Mapping[str, Any]:
    config = getattr(extractor, "config", None)
    if hasattr(config, "model_dump"):
        resolved = config.model_dump()
    elif hasattr(config, "dict"):
        resolved = config.dict()
    else:
        resolved = {"object_type": type(config).__qualname__}
    config_path = getattr(extractor, "config_path", None)
    source = None
    source_sha256 = None
    if config_path is not None:
        path = Path(config_path)
        source = f"route_inspector/configs/{path.name}"
        if path.is_file():
            source_sha256 = _sha256_file(path)
    return {
        "source": source,
        "source_sha256": source_sha256,
        "resolved": _config_json_value(resolved),
    }


def build_composite_library(
    reference_library: ReferenceTacticLibrary,
    routes_json: route_access.RouteCollection,
    *,
    source_routes_sha256: str,
    extractor: CompositeRuleExtractor | None = None,
    kinds: Sequence[str] = _EXECUTABLE_KINDS,
    max_replay_outcomes: int = 256,
    max_variants: int = 256,
    application_timeout_seconds: float | None = 300.0,
    allow_ambiguous: bool = True,
    ignore_errors: bool = False,
    limit_occurrences: int | None = None,
    n_cpu: int = 1,
    extractor_args: Mapping[str, Any] | None = None,
    extractor_cache_size: int | None = 16,
    progress_interval: int = 0,
    work_dir: str | Path | None = None,
    resume: bool = False,
    memory_budget_mb: int = 512,
    reuse_library=None,
    reuse_route_ids=(),
) -> CompositeLibraryBuildResult:
    """Build a compact companion from indexed Reference-library occurrences."""

    normalized_kinds = tuple(dict.fromkeys(str(kind) for kind in kinds))
    if any(kind not in _EXECUTABLE_KINDS for kind in normalized_kinds):
        raise ValueError(
            "composite library supports rrseq_cons and rrsubtree_cons only"
        )
    if limit_occurrences is not None and limit_occurrences < 0:
        raise ValueError("limit_occurrences must be non-negative")
    resolved_extractor = extractor or CompositeRuleExtractor.from_args(
        type(
            "Args",
            (),
            {
                "config": "route_inspector/configs/rule_extraction_small.yaml",
            },
        )()
    )
    workers = normalize_n_cpu(n_cpu)
    from route_inspector.rules.evidence import configure_evidence, evidence_path

    evidence_file = (
        evidence_path(reference_library.directory)
        if getattr(reference_library, "directory", None) is not None
        else None
    )
    evidence = (
        configure_evidence(resolved_extractor, evidence_file)
        if evidence_file is not None
        else None
    )
    options = {
        "max_replay_outcomes": max_replay_outcomes,
        "max_variants": max_variants,
        "application_timeout_seconds": application_timeout_seconds,
        "allow_ambiguous": allow_ambiguous,
    }
    stage = None
    if work_dir is not None:
        from route_inspector.composite_rules.disk_build import CompositeStage
        from route_inspector.infrastructure.build_workspace import runtime_versions

        stage = CompositeStage(
            work_dir,
            resume=resume,
            fingerprint=dict(
                builder="composites-bounded-v1",
                runtime=runtime_versions(),
                reference=reference_library.library_id,
                source=source_routes_sha256,
                kinds=list(normalized_kinds),
                options=options,
                ignore_errors=ignore_errors,
                limit=limit_occurrences,
                extraction=_composite_extraction_profile(resolved_extractor),
                **(
                    {
                        "reuse_library_id": reuse_library.library_id,
                        "reuse_route_ids": sorted(reuse_route_ids),
                    }
                    if reuse_library
                    else {}
                ),
            ),
        )
    from route_inspector.infrastructure.build_workspace import BUFFER_BUDGET

    if memory_budget_mb < 32:
        if stage is not None:
            stage.close()
        raise ValueError("memory budget must be at least 32 MiB")
    token = BUFFER_BUDGET.set(memory_budget_mb * 1024 * 1024)
    try:
        reused_routes = set(map(str, reuse_route_ids))
        previous_errors = (
            {e["reference_occurrence_id"]: e for e in reuse_library.errors}
            if reuse_library is not None
            else {}
        )
        seen = 0
        manifest = getattr(reference_library, "manifest", None)
        counts = getattr(manifest, "statistics", {}).get("occurrences_by_kind", {})
        expected_seen = (
            sum(counts.get(kind, 0) for kind in normalized_kinds) if counts else None
        )
        if expected_seen is not None and limit_occurrences is not None:
            expected_seen = min(expected_seen, limit_occurrences)

        def work_items():
            nonlocal seen
            for kind in normalized_kinds:
                if limit_occurrences is not None and seen >= limit_occurrences:
                    return
                for occurrence in reference_library.iter_occurrences(kind=kind):
                    if limit_occurrences is not None and seen >= limit_occurrences:
                        return
                    seen += 1
                    if stage is not None and stage.contains(
                        occurrence.reference_occurrence_id
                    ):
                        continue
                    if (
                        reuse_library is not None
                        and occurrence.route.route_id in reused_routes
                    ):
                        link = reuse_library.link_for_occurrence(
                            occurrence.reference_occurrence_id
                        )
                        if link is not None:
                            if (
                                link.dataset_id,
                                link.source_identity,
                                link.route_id,
                            ) != (
                                occurrence.route.dataset_id,
                                occurrence.route.source_identity,
                                occurrence.route.route_id,
                            ):
                                raise ValueError(
                                    "reused composite has different source provenance"
                                )
                            accepted.append(
                                _AcceptedConstruction(
                                    composite_rule=reuse_library.certified_rule(link),
                                    kind=link.kind,
                                    reference_occurrence_id=link.reference_occurrence_id,
                                    tactic_entry_id=reference_library.entry_id_for_occurrence(
                                        link.reference_occurrence_id
                                    ),
                                    dataset_id=link.dataset_id,
                                    source_identity=link.source_identity,
                                    route_id=link.route_id,
                                    certificate=link.certificate,
                                    ring_breaking=link.ring_breaking,
                                )
                            )
                        elif occurrence.reference_occurrence_id in previous_errors:
                            errors.append(
                                previous_errors[occurrence.reference_occurrence_id]
                            )
                        else:
                            raise ValueError(
                                "unchanged occurrence lacks a prior composite result; use a complete baseline"
                            )
                        if stage is not None:
                            stage.db.commit()
                        continue
                    yield _CompositeLibraryWorkItem(
                        kind=kind,
                        occurrence=occurrence,
                        source_route=(
                            route_access.route_by_id(
                                routes_json, occurrence.route.route_id
                            )
                            if kind == "rrsubtree_cons"
                            else None
                        ),
                        tactic_entry_id=reference_library.entry_id_for_occurrence(
                            occurrence.reference_occurrence_id
                        ),
                    )

        accepted = [] if stage is None else stage.accepted
        errors = [] if stage is None else stage.errors
        started_at = time.monotonic()

        def consume(index: int, outcome: _CompositeLibraryWorkOutcome) -> None:
            if outcome.accepted is not None:
                accepted.append(outcome.accepted)
            if outcome.error is not None:
                errors.append(outcome.error)
                if outcome.fatal and not ignore_errors:
                    raise RuntimeError(
                        f"{outcome.error['error_type']}: {outcome.error['message']}"
                    )
            if stage is not None:
                stage.db.commit()
                if index % 25 == 0:
                    from route_inspector.infrastructure.build_workspace import (
                        check_disk_headroom,
                    )

                    check_disk_headroom(Path(work_dir))
            if progress_interval and (
                index % progress_interval == 0 or index == expected_seen
            ):
                _render_composite_progress(
                    index, expected_seen or seen, started_at, workers=workers
                )

        items = iter(work_items())
        first = next(items, None)
        items = chain((first,), items) if first is not None else iter(())
        if workers > 1 and first is not None:
            if extractor_args is None:
                raise ValueError("extractor_args is required when n_cpu > 1")
            with ProcessPoolExecutor(
                max_workers=workers,
                initializer=_init_composite_library_worker,
                initargs=(extractor_args, extractor_cache_size, options, evidence_file),
            ) as executor:
                # Executor.map eagerly retains the complete iterable on supported
                # Python versions. Bound submitted payloads and retain source order.
                if stage is not None:
                    from route_inspector.infrastructure.worker_spool import results

                    for index, outcome in enumerate(
                        results(
                            executor,
                            _process_composite_library_item,
                            items,
                            Path(work_dir) / "worker-results",
                            workers=workers,
                        ),
                        1,
                    ):
                        consume(index, outcome)
                else:
                    pending = deque()
                    index = 0
                    for item in items:
                        pending.append(
                            executor.submit(_process_composite_library_item, item)
                        )
                        if len(pending) >= 2 * workers:
                            index += 1
                            consume(index, pending.popleft().result())
                    while pending:
                        index += 1
                        consume(index, pending.popleft().result())

        else:
            for index, item in enumerate(items, start=1):
                consume(
                    index, _construct_library_item(item, resolved_extractor, options)
                )
        _release_unused_memory()
        entries, links = (
            _aggregate_results(accepted) if stage is None else stage.aggregate()
        )
        route_sets = {
            kind: {
                (link.dataset_id, link.source_identity, link.route_id)
                for link in links
                if link.kind == kind
            }
            for kind in _EXECUTABLE_KINDS
        }
        statistics = {
            "ring_breaking": summary_counts(links),
            "constructions_seen": seen,
            "certified_link_count": len(links),
            "composite_entry_count": len(entries),
            "error_count": len(errors),
            **{
                f"{kind}_certified_link_count": sum(link.kind == kind for link in links)
                for kind in _EXECUTABLE_KINDS
            },
            **{
                f"{kind}_route_count": len(route_sets[kind])
                for kind in _EXECUTABLE_KINDS
            },
            **identity_statistics(entries),
        }
        construction_profile = {
            "ring_breaking": dict(RING_BREAKING_POLICY),
            "schema_version": COMPOSITE_LIBRARY_SCHEMA_VERSION,
            "kinds": list(normalized_kinds),
            "max_replay_outcomes": max_replay_outcomes,
            "max_variants": max_variants,
            "application_timeout_seconds": application_timeout_seconds,
            "allow_ambiguous": allow_ambiguous,
            "stereochemistry_policy": "ignored",
            "chemical_equivalence_policy": "exact_constitutional_graph",
            "atom_lineage_policy": "target_atoms_strict",
            "certification_policy": {
                "version": 2,
                "source_replay": "full_recorded_boundary",
                "composite_replay": ABSTRACTION_BOUNDARY_POLICY,
                "application_uniqueness": "reported_separately",
            },
            "rule_extraction": _composite_extraction_profile(resolved_extractor),
            "composite_identity": dict(IDENTITY_POLICY),
        }
        manifest = CompositeLibraryManifest(
            library_id=_library_id(
                reference_library.library_id,
                source_routes_sha256,
                construction_profile,
                entries,
                links,
            ),
            source_reference_library_id=reference_library.library_id,
            source_processing_profile_fingerprint=(
                reference_library.processing_profile.fingerprint
            ),
            source_routes_sha256=source_routes_sha256,
            construction_profile=construction_profile,
            statistics=statistics,
            artifacts={},
            route_inspector_commit=git_commit_hash(),
        )
        if stage is None:
            library = CompositeDecompositionLibrary(
                manifest=manifest,
                entries=entries,
                links=links,
                errors=errors,
            )
        else:
            library = stage.library(manifest, entries, links)

        return CompositeLibraryBuildResult(
            library=library,
            constructions_seen=seen,
            certified_links=len(links),
            errors=tuple(errors) if stage is None else errors,
        )
    except BaseException:
        if stage is not None:
            stage.close()
        raise
    finally:
        BUFFER_BUDGET.reset(token)
        if evidence is not None:
            evidence.close()


__all__ = [
    "COMPOSITE_IDENTITY_VERSION",
    "COMPOSITE_LIBRARY_FORMAT_VERSION",
    "COMPOSITE_LIBRARY_SCHEMA_VERSION",
    "COMPOSITE_LINK_SCHEMA_VERSION",
    "CompositeDecompositionLibrary",
    "CompositeDecompositionLink",
    "CompositeLibraryBuildResult",
    "CompositeLibraryEntry",
    "CompositeLibraryManifest",
    "build_composite_library",
]
