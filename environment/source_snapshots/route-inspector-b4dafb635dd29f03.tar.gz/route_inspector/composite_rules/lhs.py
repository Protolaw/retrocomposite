"""Disposable index of exact, map-independent stored composite query LHSs.

This relates stored executable queries, not re-extracted source chemistry. A
signature is only a candidate bucket; membership requires graph isomorphism.
"""

from __future__ import annotations

import json
import os
import sqlite3
import tempfile
from collections import defaultdict
from pathlib import Path

from route_inspector.reference_library.browsing import BrowsePage
from route_inspector.rules.graph import canonical_json, labelled_graphs_are_isomorphic
from route_inspector.rules.transformation import _graph_signature, _side

INDEX_VERSION = 1


def lhs_graph(rule):
    """Retain all supported LHS predicates, ignoring maps and component order.

    Read the stored query, never a molecular SMILES or the joint QueryCGR key.
    The predicate serializer rejects unsupported semantics (including stereo).
    """
    from chython import smarts

    if str(rule).count(">>") != 1:
        raise ValueError("Expected stored reaction SMARTS with one >> separator")
    lhs = rule.split(">>")[0]
    if not lhs.strip():
        raise ValueError("Empty composite LHS")
    return _side(smarts(lhs + ">>" + lhs).reactants)


def library_entries(library):
    """Read immutable catalogue metadata without loading occurrence payloads."""
    if library._connection is not None:
        for row in library._connection.execute(
            "SELECT entry_json FROM entries ORDER BY composite_id"
        ):
            yield json.loads(row[0])
    else:
        for entry in library.entries():
            yield entry.to_dict()


class CompositeLHSIndex:
    """Thread-owned read-only index. Completed files are published atomically."""

    def __init__(self, path):
        self.connection = sqlite3.connect(
            Path(path).resolve().as_uri() + "?mode=ro", uri=True
        )
        self.connection.row_factory = sqlite3.Row

    def close(self):
        self.connection.close()

    @staticmethod
    def build(path, entries, identity):
        from chython import smarts

        from route_inspector.composite_rules.identity import variant_id

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(
            dir=path.parent, prefix=".lhs-", suffix=".sqlite"
        )
        os.close(fd)
        connection = sqlite3.connect(temporary)
        try:
            connection.executescript("""
                CREATE TABLE metadata (identity TEXT NOT NULL);
                CREATE TABLE entries (composite_id TEXT PRIMARY KEY,
                    route_count INTEGER NOT NULL, summary TEXT NOT NULL);
                CREATE TABLE variants (composite_id TEXT NOT NULL REFERENCES entries,
                    variant_id TEXT NOT NULL, family INTEGER, rule TEXT NOT NULL,
                    product_count INTEGER, diagnostic TEXT,
                    PRIMARY KEY (composite_id, variant_id));
                CREATE INDEX by_family ON variants(family, composite_id);
            """)
            buckets, exact = defaultdict(list), {}
            families = 0
            for entry in entries:
                cid = entry["composite_id"]
                connection.execute(
                    "INSERT INTO entries VALUES (?, ?, ?)",
                    (
                        cid,
                        entry["route_counts"]["all"],
                        canonical_json(
                            {
                                "kinds": sorted(
                                    k
                                    for k, n in entry["occurrence_counts"].items()
                                    if n
                                ),
                            }
                        ),
                    ),
                )
                variants = entry.get("variants") or [
                    {
                        "variant_id": variant_id(entry["normalized_rule"]),
                        "normalized_rule": entry["normalized_rule"],
                    }
                ]
                for variant in variants:
                    rule = variant["normalized_rule"]
                    family = product_count = diagnostic = None
                    try:
                        graph = lhs_graph(rule)
                        encoded = canonical_json(graph)
                        product_count = len(smarts(rule).products)
                        if encoded in exact:
                            family = exact[encoded]
                        else:
                            signature = canonical_json(_graph_signature(graph))
                            for representative, candidate in buckets[signature]:
                                if labelled_graphs_are_isomorphic(
                                    graph, representative
                                ):
                                    family = candidate
                                    break
                            if family is None:
                                family = families
                                families += 1
                                buckets[signature].append((graph, family))
                            exact[encoded] = family
                    except (
                        ValueError,
                        TypeError,
                        AttributeError,
                        KeyError,
                        NotImplementedError,
                    ) as exc:
                        diagnostic = f"{type(exc).__name__}: {exc}"
                    connection.execute(
                        "INSERT INTO variants VALUES (?, ?, ?, ?, ?, ?)",
                        (
                            cid,
                            variant["variant_id"],
                            family,
                            rule,
                            product_count,
                            diagnostic,
                        ),
                    )
            connection.execute("INSERT INTO metadata VALUES (?)", (identity,))
            connection.commit()
            if connection.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("Same-LHS index failed integrity check")
            connection.close()
            os.replace(temporary, path)
        finally:
            connection.close()
            Path(temporary).unlink(missing_ok=True)

    def valid(self, identity):
        return (
            self.connection.execute("PRAGMA quick_check").fetchone()[0] == "ok"
            and self.connection.execute("SELECT identity FROM metadata").fetchone()[0]
            == identity
            and self.connection.execute(
                "SELECT count(summary) FROM entries"
            ).fetchone()[0]
            >= 0
            and self.connection.execute(
                "SELECT count(family), count(diagnostic) FROM variants"
            ).fetchone()[0]
            >= 0
        )

    def diagnostics(self, composite_id):
        rows = [
            dict(row)
            for row in self.connection.execute(
                "SELECT composite_id, variant_id, diagnostic FROM variants "
                "WHERE diagnostic IS NOT NULL ORDER BY composite_id, variant_id"
            )
        ]
        return {
            "unavailable_variants": len(rows),
            "unavailable_composites": len({r["composite_id"] for r in rows}),
            "selected": [r for r in rows if r["composite_id"] == composite_id],
            "details": rows,
        }

    def page(self, composite_id, *, offset=0, limit=20):
        if offset < 0 or not 1 <= limit <= 200:
            raise ValueError("Invalid same-LHS pagination bounds")
        if (
            self.connection.execute(
                "SELECT 1 FROM entries WHERE composite_id=?", (composite_id,)
            ).fetchone()
            is None
        ):
            raise KeyError(composite_id)
        # Rank witnesses before pagination: multiple matching variants never
        # inflate counts or duplicate composite rows.
        query = """
            WITH matches AS (
                SELECT other.composite_id, selected.variant_id AS selected_variant_id,
                    other.variant_id, selected.rule AS selected_rule, other.rule,
                    other.product_count,
                    row_number() OVER (PARTITION BY other.composite_id
                        ORDER BY selected.variant_id, other.variant_id) AS witness
                FROM variants selected JOIN variants other USING (family)
                WHERE selected.composite_id=? AND other.composite_id != selected.composite_id
            )
            SELECT matches.*, entries.route_count, entries.summary FROM matches
            JOIN entries USING (composite_id) WHERE witness=1
        """
        total = self.connection.execute(
            "SELECT count(*) FROM (" + query + ")", (composite_id,)
        ).fetchone()[0]
        rows = []
        for item in self.connection.execute(
            query + " ORDER BY route_count DESC, composite_id LIMIT ? OFFSET ?",
            (composite_id, limit, offset),
        ):
            row = dict(item)
            row.pop("witness")
            row.update(json.loads(row.pop("summary")))
            rows.append(row)
        return BrowsePage(tuple(rows), total, offset, limit)
