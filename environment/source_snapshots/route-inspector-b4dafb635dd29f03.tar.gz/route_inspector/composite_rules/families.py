"""Exact composite families from independent complete query sides.

Mapped SMARTS remain executable variants. This identity only groups them; it
does not transfer atom correspondence or certificates between variants.
"""

from functools import lru_cache

from route_inspector.composite_rules.identity import (
    CompositeRuleKey,
    key_from_smarts,
    normalize_rule,
)
from route_inspector.rules.canonical import _canonical_graph_certificate
from route_inspector.rules.graph import canonical_json
from route_inspector.rules.transformation import _side

IDENTITY_VERSION = 3
IDENTITY_POLICY = {
    "version": IDENTITY_VERSION,
    "method": "independent_complete_query_sides",
    "canonicalization": "exact_individualization_refinement",
    "cross_side_atom_correspondence": False,
    "unsupported_policy": "exact_representation",
}


@lru_cache(maxsize=32768)
def family_key_from_smarts(rule: str) -> CompositeRuleKey:
    """Canonicalize full labelled sides, including disconnected multiplicity."""
    from chython import smarts

    normalized = normalize_rule(rule)
    try:
        query = smarts(normalized)
        if query.reagents:
            raise ValueError("Reaction-agent queries are unsupported")
        sides = {
            name: _canonical_graph_certificate(_side(molecules))
            for name, molecules in (
                ("reactants", query.reactants),
                ("products", query.products),
            )
        }
        return CompositeRuleKey(
            canonical_json(
                {"version": 3, "method": IDENTITY_POLICY["method"], **sides}
            ),
            "canonical",
            0,
        )
    except (
        ValueError,
        TypeError,
        AttributeError,
        KeyError,
        NotImplementedError,
    ) as exc:
        return CompositeRuleKey(
            canonical_json(
                {"version": 3, "method": "exact_representation", "rule": normalized}
            ),
            "exact_representation",
            0,
            f"{type(exc).__name__}: {exc}",
        )


def key_for_version(rule, version):
    """Keep legacy mapped-family lookup and validation scientifically stable."""
    if version == 2:
        return key_from_smarts(rule)
    if version == 3:
        return family_key_from_smarts(rule)
    raise ValueError(f"Unsupported composite family identity version: {version}")
