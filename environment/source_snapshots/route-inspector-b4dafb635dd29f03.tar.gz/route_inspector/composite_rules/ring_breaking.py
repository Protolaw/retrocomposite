"""Retrosynthetic ring-bond disconnection on complete mapped pseudo-reactions.

No rule extraction, neural mapping, or RDKit is involved. The forward product
is the retrosynthetic target. SSSR edges cover all cyclic bonds, including
those outside a particular choice of smallest-ring basis.
"""

from collections import Counter

POLICY = {
    "version": 1,
    "direction": "retrosynthetic",
    "algorithm": "chython_sssr_target_bonds_absent_in_precursors",
    "aggregation": "any_certified_occurrence",
}
KINDS = ("rrseq_cons", "rrsubtree_cons", "all")


def unknown_annotation(error, *, origin):
    return {
        "version": POLICY["version"],
        "value": None,
        "bonds": [],
        "origin": origin,
        "diagnostic": f"{type(error).__name__}: {error}",
    }


def classify_ring_breaking(reaction, *, origin="construction_pseudo_reaction"):
    """Return a tri-state annotation; chemical negatives are strictly Boolean.

    Missing or duplicate mapping is unknown, never silently repaired. For text
    input every atom must carry an explicit positive map. Container callers
    supply already route-mapped molecules, with unique identities on each side.
    """
    try:
        from chython import smiles
        from chython.containers import ReactionContainer

        if isinstance(reaction, str):
            from chython.files.daylight.tokenize import smiles_tokenize

            # Tokenization also distinguishes atoms from ring/branch syntax.
            for side in reaction.split(">"):
                for kind, token in smiles_tokenize(side):
                    if kind in (0, 8):
                        # Chython's atom tokens carry a parsed mapping field.
                        if not isinstance(token, dict) or not token.get(
                            "parsed_mapping"
                        ):
                            raise ValueError(
                                "pseudo-reaction contains an unmapped atom"
                            )
            reaction = smiles(reaction, ignore=False)
        if not isinstance(reaction, ReactionContainer):
            raise ValueError("expected a mapped pseudo-reaction")
        if not reaction.reactants or not reaction.products:
            raise ValueError("pseudo-reaction requires both sides")

        def atoms(molecules):
            result = {}
            for molecule in molecules:
                for number, atom in molecule.atoms():
                    if number <= 0 or number in result:
                        raise ValueError("duplicate or nonpositive atom mapping")
                    result[number] = (atom.atomic_number, atom.isotope)
            return result

        before_atoms = atoms(reaction.reactants)
        after_atoms = atoms(reaction.products)
        if any(before_atoms.get(n) != atom for n, atom in after_atoms.items()):
            raise ValueError("target atom lacks a compatible precursor identity")
        before_bonds = {
            tuple(sorted((a, b)))
            for molecule in reaction.reactants
            for a, b, bond in molecule.bonds()
            if int(bond) != 8
        }
        ring_bonds = {
            tuple(sorted((a, b)))
            for molecule in reaction.products
            for ring in molecule.sssr
            for a, b in zip(ring, ring[1:] + ring[:1])
        }
        formed = sorted(ring_bonds - before_bonds)
        return {
            "version": POLICY["version"],
            "value": bool(formed),
            "bonds": [list(pair) for pair in formed],
            "origin": origin,
            "diagnostic": None,
        }
    except Exception as exc:
        # Annotation failure must not discard an independently certified source.
        return unknown_annotation(exc, origin=origin)


def _stream_counts(links):
    counts = {kind: Counter() for kind in KINDS}
    annotated = 0
    for link in links:
        annotated += link.ring_breaking is not None
        value = (link.ring_breaking or {}).get("value")
        status = "yes" if value is True else "no" if value is False else "unknown"
        if getattr(link, "kind", None) in counts:
            counts[link.kind][status] += 1
        counts["all"][status] += 1
    return annotated, (
        {
            kind: {key: values[key] for key in ("yes", "no", "unknown")}
            for kind, values in counts.items()
        }
        if annotated
        else None
    )


def aggregate_ring_breaking(links):
    return _stream_counts(links)[1]


def classification(counts):
    if counts.get("yes", 0):
        return True
    if counts.get("unknown", 0) or not counts.get("no", 0):
        return None
    return False


def summary_counts(links):
    annotated, counts = _stream_counts(links)
    return {"annotated_occurrences": annotated, "counts": counts}


def validate_annotation(annotation):
    """Reject malformed supplementary evidence at the portable-model boundary."""
    if annotation is None:
        return
    if annotation.get("version") != POLICY["version"]:
        raise ValueError("unsupported ring-breaking annotation version")
    value = annotation.get("value")
    if value is not None and type(value) is not bool:
        raise ValueError("ring-breaking value must be Boolean or null")
    bonds = annotation.get("bonds")
    if not isinstance(bonds, list) or any(
        not isinstance(pair, list)
        or len(pair) != 2
        or any(type(n) is not int or n <= 0 for n in pair)
        or pair[0] >= pair[1]
        for pair in bonds
    ):
        raise ValueError("invalid ring-breaking bond evidence")
    if bonds != [list(pair) for pair in sorted({tuple(pair) for pair in bonds})]:
        raise ValueError("ring-breaking bonds must be sorted and unique")
    if bool(bonds) != (value is True):
        raise ValueError("ring-breaking value disagrees with bond evidence")
    if not annotation.get("origin"):
        raise ValueError("ring-breaking evidence origin is required")
    if (value is None) != bool(annotation.get("diagnostic")):
        raise ValueError("unknown ring-breaking classification requires a diagnostic")
