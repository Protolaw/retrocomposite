"""Live query-side evidence reconstructed from certified source boundaries."""

from collections import defaultdict
from functools import lru_cache

from route_inspector.rules.transformation import (
    RuleFamilyIndex,
    capture_rule,
    rules_equivalent,
)


@lru_cache(maxsize=4096)
def _persisted_query(rule):
    from chython import smarts

    # This is only a certificate guard, not a vocabulary key. Avoid a second
    # joint-graph canonicalization: exact side isomorphism is authoritative.
    return capture_rule(smarts(rule), f"persisted:{rule}")


def same_persisted_transformation(left, right):
    """Check the persisted certificate's sides, excluding cross-side lineage.

    Parsing here validates the existing serialized certificate only. Vocabulary
    identity still comes exclusively from the live, unconverted extraction.
    """
    return rules_equivalent(_persisted_query(left), _persisted_query(right))


def composite_sources(composites):
    """All certified alternatives, in stable order within each source route."""
    by_route = defaultdict(list)
    for entry in composites.entries():
        for link in sorted(
            composites.links_for_entry(entry.composite_id),
            key=lambda link: link.link_id,
        ):
            rule = composites.certified_rule(link)
            by_route[str(link.route_id)].append(((entry.composite_id, rule), link))
    return by_route


def live_composite(
    link, route, reference, extractor, *, evidence=None, occurrence=None
):
    from chython import smiles

    from route_inspector.composite_rules.rrsubtree import (
        _molecule_smiles,
        _node_at_path,
        _pseudo_reaction,
        _source_boundary,
    )
    from route_inspector.tactics.rrsubtree.models import RRSubtreeOccurrence

    occurrence = occurrence or reference.get_occurrence(link.reference_occurrence_id)
    native = occurrence.native_payload
    source_key = None
    if evidence is not None:
        # Only the exact boundary chemistry enters reuse keys, never dataset IDs.
        # The caller still verifies every current certificate and occurrence link.
        if link.kind == "rrseq_cons":
            boundary = [
                native["segment_target_smiles"],
                [leaf["mapped_smiles"] for leaf in native["source_route_leaves"]],
            ]
        else:
            subtree = RRSubtreeOccurrence.from_dict(native)
            boundary = [
                _molecule_smiles(
                    _node_at_path(route, subtree.root_reaction_node_path[:-1])
                ),
                [
                    _molecule_smiles(_node_at_path(route, path))
                    for path in subtree.boundary_precursor_node_paths
                ],
            ]
        source_key = [link.kind, boundary, link.composite_rule]
        found, result = evidence.get("boundary", source_key)
        if found:
            from types import SimpleNamespace

            return SimpleNamespace(**result)
    if link.kind == "rrseq_cons":
        target = smiles(native["segment_target_smiles"])
        boundaries = tuple(
            smiles(leaf["mapped_smiles"]) for leaf in native["source_route_leaves"]
        )
    else:
        target, boundaries = _source_boundary(
            RRSubtreeOccurrence.from_dict(native), route
        )
    pseudo, _, _ = _pseudo_reaction(target, boundaries)
    step = (
        evidence.extract("composite", pseudo, extractor)
        if evidence is not None
        else extractor.extract(pseudo)
    )
    if step is None or not step.transformation:
        raise ValueError("No live composite query returned")
    if not same_persisted_transformation(step.rule_smarts, link.composite_rule):
        raise ValueError(
            "Reconstructed query differs from the certified composite variant"
        )
    if evidence is not None:
        evidence.put(
            "boundary",
            source_key,
            {"rule_smarts": step.rule_smarts, "transformation": step.transformation},
        )
    return step


def checked_composite_extractor(profile, composites):
    from synplan.chem.reaction.rules.config import RuleExtractionConfig

    from route_inspector.composite_rules.composite import CompositeRuleExtractor
    from route_inspector.composite_rules.overlap import extractor_from_profile
    from route_inspector.rules.config import resolved_config_mapping

    source = extractor_from_profile(profile)
    recorded = composites.manifest.construction_profile["rule_extraction"]["resolved"]
    config = RuleExtractionConfig(**recorded)
    if resolved_config_mapping(config) != resolved_config_mapping(source.config):
        raise ValueError("Composite and single-step extraction configurations differ")
    return CompositeRuleExtractor(config, retain_query_cgr=False, max_cache_size=1000)


class TransformationVocabulary:
    def __init__(self):
        self.index = RuleFamilyIndex()
        self.composites = set()

    def rule(self, graph):
        return self.index.family(graph) + 1
