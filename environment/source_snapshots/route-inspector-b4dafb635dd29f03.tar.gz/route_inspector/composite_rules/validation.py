"""End-to-end validation for executable ordinary composite rules."""

from __future__ import annotations

from collections import Counter
from collections.abc import Collection, Sequence
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any

from route_inspector.chemistry import strict_atom_mapping
from route_inspector.tactics.rrseq.unwrap import (
    AtomMapping,
    ChythonOneShotTraceAdapter,
)

CHEMICAL_EQUIVALENCE_POLICY = "exact_constitutional_graph"
STEREOCHEMISTRY_POLICY = "ignored"
ATOM_LINEAGE_POLICY = "target_atoms_strict"
ABSTRACTION_BOUNDARY_POLICY = "synplanner_net_reactants_v1"


def abstract_precursor_boundary(
    target: str | Any, expected_leaves: Sequence[Any]
) -> tuple[tuple[Any, ...], dict[str, Any]]:
    """Apply extraction's reagent policy before looking at any rule outcomes.

    Preserve whole molecules and multiplicity. Refuse to abstract away any
    component containing target atoms, even if the standardizer calls it inert.
    The complete boundary remains authoritative for original-tactic replay.
    """
    from chython.containers import ReactionContainer
    from synplan.chem.reaction.curation.standardizing import RemoveReagentsStandardizer

    product = _molecule(target)
    original = _flatten(expected_leaves)
    reaction = ReactionContainer(
        reactants=tuple(m.copy() for m in original), products=(product.copy(),)
    )
    # Match the existing constitutional-only certification/extraction policy,
    # without changing the original molecules retained in the audit or replay.
    reaction.clean_stereo()
    standardized = RemoveReagentsStandardizer()(reaction)
    counts = Counter(format(m, "m") for m in standardized.reactants)
    retained, included, omitted = [], [], []
    target_maps = set(product)
    for index, (molecule, constitutional) in enumerate(
        zip(original, reaction.reactants)
    ):
        mapped = format(molecule, "m")
        signature = format(constitutional, "m")
        record = {
            "component_index": index,
            "mapped_smiles": mapped,
            "atom_maps": sorted(molecule),
        }
        if counts[signature]:
            counts[signature] -= 1
            retained.append(molecule)
            included.append(record)
        else:
            if target_maps.intersection(molecule):
                raise ValueError(
                    "abstraction would omit a target-contributing component"
                )
            omitted.append({**record, "reason": "net_reagent_without_target_atoms"})
    if any(counts.values()):
        raise ValueError("reagent standardization changed retained component identity")
    return tuple(retained), {
        "policy": ABSTRACTION_BOUNDARY_POLICY,
        "original_component_count": len(original),
        "retained_components": included,
        "omitted_components": omitted,
    }


def validate_abstract_composite_rule(
    target: str | Any,
    rule: str,
    expected_leaves: Sequence[Any],
    *,
    max_outcomes: int = 256,
    adapter: ChythonOneShotTraceAdapter | None = None,
) -> CompositeValidationResult:
    """Strictly validate the declared net boundary and retain its full audit."""
    try:
        retained, audit = abstract_precursor_boundary(target, expected_leaves)
    except Exception as exc:
        return _validation_error(exc)
    result = validate_composite_rule(
        target, rule, retained, max_outcomes=max_outcomes, adapter=adapter
    )
    return replace(result, abstraction_boundary=audit)


@dataclass(frozen=True)
class PrecursorComparison:
    """Strict chemical and atom-lineage comparison of two precursor multisets."""

    chemistry_equivalent: bool
    mapping_consistent: bool
    expected_precursor_smiles: tuple[str, ...]
    actual_precursor_smiles: tuple[str, ...]
    component_pairs: tuple[tuple[int, int], ...] = ()
    atom_mappings: tuple[AtomMapping, ...] = ()
    chemistry_mismatch_reason: str | None = None
    mapping_mismatch_reason: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "chemistry_equivalent": self.chemistry_equivalent,
            "mapping_consistent": self.mapping_consistent,
            "expected_precursor_smiles": list(self.expected_precursor_smiles),
            "actual_precursor_smiles": list(self.actual_precursor_smiles),
            "component_pairs": [list(pair) for pair in self.component_pairs],
            "atom_mappings": [
                [list(pair) for pair in mapping] for mapping in self.atom_mappings
            ],
            "chemistry_mismatch_reason": self.chemistry_mismatch_reason,
            "mapping_mismatch_reason": self.mapping_mismatch_reason,
        }


def _molecule(value: Any) -> Any:
    if isinstance(value, str):
        from chython import smiles

        return smiles(value)
    return value


def _flatten(values: Sequence[Any]) -> list[Any]:
    flattened: list[Any] = []
    for value in values:
        molecule = _molecule(value)
        components = tuple(molecule.connected_components)
        if len(components) > 1:
            flattened.extend(molecule.split())
        else:
            flattened.append(molecule)
    return flattened


def _pair_mappings(
    left: Any,
    right: Any,
    lineage_atom_ids: set[int],
) -> tuple[AtomMapping | None, AtomMapping | None]:
    if left.atoms_count != right.atoms_count or left.bonds_count != right.bonds_count:
        return None, None

    chemical: AtomMapping | None = None
    lineage: AtomMapping | None = None
    for raw_mapping in left.get_mapping(
        right,
        automorphism_filter=False,
        match_stereo=False,
    ):
        mapping = {int(source): int(target) for source, target in raw_mapping.items()}
        if not strict_atom_mapping(left, right, mapping):
            continue
        frozen: AtomMapping = tuple(sorted(mapping.items()))
        if chemical is None:
            chemical = frozen
        if all(
            mapping[atom_number] == atom_number
            for atom_number in lineage_atom_ids
            if atom_number in mapping
        ):
            lineage = frozen
            break
    return chemical, lineage


def _find_assignment(
    candidates: list[list[tuple[int, AtomMapping, AtomMapping | None]]],
    *,
    require_lineage: bool,
) -> tuple[tuple[tuple[int, int], ...], tuple[AtomMapping, ...]] | None:
    order = sorted(range(len(candidates)), key=lambda index: len(candidates[index]))
    selected: dict[int, tuple[int, AtomMapping]] = {}
    used: set[int] = set()

    def visit(position: int) -> bool:
        if position == len(order):
            return True
        expected_index = order[position]
        for actual_index, chemical, lineage in candidates[expected_index]:
            mapping = lineage if require_lineage else chemical
            if actual_index in used or mapping is None:
                continue
            used.add(actual_index)
            selected[expected_index] = (actual_index, mapping)
            if visit(position + 1):
                return True
            selected.pop(expected_index)
            used.remove(actual_index)
        return False

    if not visit(0):
        return None
    pairs = tuple(
        (expected_index, selected[expected_index][0])
        for expected_index in range(len(candidates))
    )
    mappings = tuple(
        selected[expected_index][1] for expected_index in range(len(candidates))
    )
    return pairs, mappings


def compare_precursor_multisets(
    expected: Sequence[Any],
    actual: Sequence[Any],
    *,
    lineage_atom_ids: Collection[int] | None = None,
) -> PrecursorComparison:
    """Compare exact constitutional graphs and target-atom lineage.

    Component order and atom-map labels outside the requested lineage IDs are
    ignored. Atom and bond state remain exact, but tetrahedral and double-bond
    stereo are deliberately excluded because extracted RRseq and composite
    templates are stereo-agnostic.
    """

    expected_molecules = _flatten(expected)
    actual_molecules = _flatten(actual)
    expected_text = tuple(format(molecule, "m") for molecule in expected_molecules)
    actual_text = tuple(format(molecule, "m") for molecule in actual_molecules)
    if len(expected_molecules) != len(actual_molecules):
        return PrecursorComparison(
            False,
            False,
            expected_text,
            actual_text,
            chemistry_mismatch_reason="precursor_count_mismatch",
            mapping_mismatch_reason="chemistry_not_equivalent",
        )

    lineage_ids = (
        {int(atom_number) for atom_number in lineage_atom_ids}
        if lineage_atom_ids is not None
        else {
            int(atom_number)
            for molecule in expected_molecules
            for atom_number in molecule
        }
    )
    expected_lineage_ids = {
        int(atom_number)
        for molecule in expected_molecules
        for atom_number in molecule
        if int(atom_number) in lineage_ids
    }
    actual_lineage_ids = {
        int(atom_number)
        for molecule in actual_molecules
        for atom_number in molecule
        if int(atom_number) in lineage_ids
    }
    candidates: list[list[tuple[int, AtomMapping, AtomMapping | None]]] = []
    for expected_molecule in expected_molecules:
        row = []
        for actual_index, actual_molecule in enumerate(actual_molecules):
            chemical, lineage = _pair_mappings(
                expected_molecule,
                actual_molecule,
                lineage_ids,
            )
            if chemical is not None:
                row.append((actual_index, chemical, lineage))
        candidates.append(row)

    chemistry = _find_assignment(candidates, require_lineage=False)
    if chemistry is None:
        return PrecursorComparison(
            False,
            False,
            expected_text,
            actual_text,
            chemistry_mismatch_reason="chemical_structure_mismatch",
            mapping_mismatch_reason="chemistry_not_equivalent",
        )
    lineage = (
        _find_assignment(candidates, require_lineage=True)
        if expected_lineage_ids == actual_lineage_ids
        else None
    )
    if lineage is None:
        return PrecursorComparison(
            True,
            False,
            expected_text,
            actual_text,
            component_pairs=chemistry[0],
            atom_mappings=chemistry[1],
            mapping_mismatch_reason="atom_lineage_mismatch",
        )
    return PrecursorComparison(
        True,
        True,
        expected_text,
        actual_text,
        component_pairs=lineage[0],
        atom_mappings=lineage[1],
    )


class CompositeValidationStatus(str, Enum):
    """Scientific outcomes of bounded composite reapplication."""

    VALIDATED_UNIQUE = "validated_unique"
    VALIDATED_AMBIGUOUS = "validated_ambiguous"
    NO_APPLICATION = "composite_no_application"
    NO_MATCHING_OUTCOME = "composite_no_matching_outcome"
    OUTCOME_LIMIT_REACHED = "outcome_limit_reached"
    VALIDATION_ERROR = "validation_error"


@dataclass(frozen=True)
class CompositeOutcomeValidation:
    """Comparison of one generated composite outcome with expected leaves."""

    outcome_index: int
    reaction_smiles: str
    precursor_smiles: tuple[str, ...]
    query_to_target_mappings: tuple[AtomMapping, ...]
    comparison: PrecursorComparison

    def to_dict(self) -> dict[str, Any]:
        return {
            "outcome_index": self.outcome_index,
            "reaction_smiles": self.reaction_smiles,
            "precursor_smiles": list(self.precursor_smiles),
            "query_to_target_mappings": [
                [list(pair) for pair in mapping]
                for mapping in self.query_to_target_mappings
            ],
            "comparison": self.comparison.to_dict(),
        }


@dataclass(frozen=True)
class CompositeValidationResult:
    """Complete bounded validation result for one composite occurrence."""

    status: CompositeValidationStatus
    chemistry_equivalent: bool
    mapping_consistent: bool
    first_outcome_match: bool
    any_outcome_match: bool
    total_unique_outcomes: int
    matching_outcome_count: int
    truncated: bool
    outcomes: tuple[CompositeOutcomeValidation, ...] = ()
    error_type: str | None = None
    error_message: str | None = None
    abstraction_boundary: dict[str, Any] | None = None

    @property
    def certified(self) -> bool:
        return (
            self.status
            in {
                CompositeValidationStatus.VALIDATED_UNIQUE,
                CompositeValidationStatus.VALIDATED_AMBIGUOUS,
            }
            and self.chemistry_equivalent
        )

    @property
    def lineage_certified(self) -> bool:
        return self.certified and self.mapping_consistent

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "chemistry_equivalent": self.chemistry_equivalent,
            "mapping_consistent": self.mapping_consistent,
            "certified": self.certified,
            "lineage_certified": self.lineage_certified,
            "first_outcome_match": self.first_outcome_match,
            "any_outcome_match": self.any_outcome_match,
            "total_unique_outcomes": self.total_unique_outcomes,
            "matching_outcome_count": self.matching_outcome_count,
            "truncated": self.truncated,
            "outcomes": [outcome.to_dict() for outcome in self.outcomes],
            "error_type": self.error_type,
            "error_message": self.error_message,
            **(
                {"abstraction_boundary": self.abstraction_boundary}
                if self.abstraction_boundary is not None
                else {}
            ),
        }


def _validation_error(exc: Exception) -> CompositeValidationResult:
    return CompositeValidationResult(
        status=CompositeValidationStatus.VALIDATION_ERROR,
        chemistry_equivalent=False,
        mapping_consistent=False,
        first_outcome_match=False,
        any_outcome_match=False,
        total_unique_outcomes=0,
        matching_outcome_count=0,
        truncated=False,
        error_type=type(exc).__name__,
        error_message=str(exc),
    )


def validate_composite_rule(
    target: str | Any,
    composite_rule_smarts: str,
    expected_leaves: Sequence[Any],
    *,
    max_outcomes: int = 256,
    adapter: ChythonOneShotTraceAdapter | None = None,
) -> CompositeValidationResult:
    """Reapply a composite and compare every bounded outcome with RRseq leaves."""

    try:
        from chython import smiles
        from chython.reactor import Reactor

        target_molecule = smiles(target) if isinstance(target, str) else target
        reactor = Reactor.from_smarts(
            composite_rule_smarts,
            delete_atoms=True,
            one_shot=True,
        )
        enumeration = (adapter or ChythonOneShotTraceAdapter()).enumerate(
            reactor,
            target_molecule,
            max_unique_outcomes=max_outcomes,
        )
        lineage_ids = {int(atom_number) for atom_number in target_molecule}
        checked = tuple(
            CompositeOutcomeValidation(
                outcome_index=outcome.outcome_index,
                reaction_smiles=outcome.reaction_smiles,
                precursor_smiles=outcome.product_smiles,
                query_to_target_mappings=outcome.query_to_target_mappings,
                comparison=compare_precursor_multisets(
                    expected_leaves,
                    outcome.products,
                    lineage_atom_ids=lineage_ids,
                ),
            )
            for outcome in enumeration.outcomes
        )
        matching = tuple(
            outcome for outcome in checked if outcome.comparison.chemistry_equivalent
        )
        any_match = bool(matching)
        first_match = bool(checked and checked[0].comparison.chemistry_equivalent)
        mapping_consistent = any(
            outcome.comparison.mapping_consistent for outcome in matching
        )
        if enumeration.truncated:
            status = CompositeValidationStatus.OUTCOME_LIMIT_REACHED
        elif not checked:
            status = CompositeValidationStatus.NO_APPLICATION
        elif not matching:
            status = CompositeValidationStatus.NO_MATCHING_OUTCOME
        elif len(checked) == 1:
            status = CompositeValidationStatus.VALIDATED_UNIQUE
        else:
            status = CompositeValidationStatus.VALIDATED_AMBIGUOUS
        return CompositeValidationResult(
            status=status,
            chemistry_equivalent=any_match,
            mapping_consistent=mapping_consistent,
            first_outcome_match=first_match,
            any_outcome_match=any_match,
            total_unique_outcomes=len(checked),
            matching_outcome_count=len(matching),
            truncated=enumeration.truncated,
            outcomes=checked,
        )
    except Exception as exc:
        return _validation_error(exc)


__all__ = [
    "ABSTRACTION_BOUNDARY_POLICY",
    "ATOM_LINEAGE_POLICY",
    "CHEMICAL_EQUIVALENCE_POLICY",
    "CompositeOutcomeValidation",
    "CompositeValidationResult",
    "CompositeValidationStatus",
    "PrecursorComparison",
    "abstract_precursor_boundary",
    "validate_abstract_composite_rule",
    "STEREOCHEMISTRY_POLICY",
    "compare_precursor_multisets",
    "validate_composite_rule",
]
