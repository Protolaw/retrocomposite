from __future__ import annotations

import csv
import json
import signal
import time
import traceback
from collections import OrderedDict, defaultdict, deque
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
from typing import Any, Iterable

from route_inspector import chemistry
from route_inspector.composite_rules.validation import (
    CompositeValidationResult,
    CompositeValidationStatus,
    PrecursorComparison,
    compare_precursor_multisets,
    validate_abstract_composite_rule,
)
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.runtime import (
    normalize_n_cpu,
    setup_runtime_cache_dirs,
)
from route_inspector.infrastructure.text import write_tsv
from route_inspector.rules.config import RuleExtractionSettings
from route_inspector.rules.evidence import EvidenceCacheError
from route_inspector.tactics.rrseq import gapped_classification
from route_inspector.tactics.rrseq.artifacts import (
    iter_rrseq_applications,
    iter_rrseq_occurrence_applications,
)
from route_inspector.tactics.rrseq.unwrap import (
    RuleApplicationError,
    RuleApplicationOutcomeLimitError,
    RuleStepTrace,
    split_rrseq,
    unwrap_rule_sequence,
    unwrap_rule_sequence_traced,
)

DEFAULT_COMPOSITE_RULE_CONFIG = Path(
    "route_inspector/configs/rule_extraction_small.yaml"
)


class CompositeApplicationTimeoutError(TimeoutError):
    """Raised when one occurrence exceeds its configured wall-clock budget."""


_COMPOSITE_WORKER_EXTRACTOR: CompositeRuleExtractor | None = None
_GAPPED_COMPOSITE_WORKER_EXTRACTOR: Any | None = None


@dataclass(frozen=True)
class ExtractedCompositeRule:
    rule_smarts: str
    cgr_key: str
    query_cgr: Any | None
    transformation: dict[str, Any] = field(default_factory=dict)


@dataclass
class PseudoReactionRecord:
    pseudo_reaction_id: str
    composite_cgr: str
    reaction_smiles: str
    source_tsv: str
    source_row: int
    route_ids: tuple[str, ...]
    target_smiles: str
    rrseq_size: int
    rrseq: str
    occurrence_id: str | None = None
    validation_status: str = "unvalidated_legacy"

    @property
    def rrseq_cons(self) -> str:
        """Canonical name for the executable sequence provenance."""

        return self.rrseq

    @property
    def rrseq_cons_size(self) -> int:
        """Number of rules in :attr:`rrseq_cons`."""

        return self.rrseq_size


@dataclass
class CompositeRuleAggregate:
    rule_smarts: str
    cgr_key: str
    query_cgr: Any | None = None
    route_ids: set[str] = field(default_factory=set)
    target_molecules: set[str] = field(default_factory=set)
    rrseqs: set[str] = field(default_factory=set)
    rrseq_sizes: set[int] = field(default_factory=set)
    source_rows: set[str] = field(default_factory=set)
    pseudo_reaction_ids: list[str] = field(default_factory=list)
    occurrence_ids: set[str] = field(default_factory=set)
    validated_occurrence_ids: set[str] = field(default_factory=set)
    ambiguous_occurrence_ids: set[str] = field(default_factory=set)
    failed_occurrence_ids: set[str] = field(default_factory=set)
    qualified_route_ids: set[tuple[str | None, str]] = field(default_factory=set)


@dataclass
class CompositeCollectionStats:
    rrseq_rows_seen: int = 0
    applications_seen: int = 0
    pseudo_reactions_built: int = 0
    composite_rules_extracted: int = 0
    skipped_unwrap_applications: int = 0
    skipped_rule_extractions: int = 0
    skipped_rule_extraction_errors: int = 0
    errors: int = 0
    application_timeouts: int = 0
    exact_occurrences_seen: int = 0
    rrseq_source_matches: int = 0
    rrseq_source_mismatches: int = 0
    rrseq_source_mapping_mismatches: int = 0
    validated_unique: int = 0
    validated_ambiguous: int = 0
    validation_rejected: int = 0
    validation_inconclusive: int = 0
    legacy_unvalidated: int = 0


@dataclass(frozen=True)
class CompositeWitness:
    """Pseudo-reaction inputs plus the exact RRseq replay evidence."""

    pseudo_reaction_smiles: str
    target_smiles: str
    rrseq_leaf_smiles: tuple[str, ...]
    source_route_leaf_smiles: tuple[str, ...]
    source_comparison: PrecursorComparison | None
    rrseq_step_traces: tuple[dict[str, Any], ...]


@dataclass
class CompositeCandidate:
    """One occurrence-level extraction result before structural aggregation."""

    application: Any
    witness: CompositeWitness | None = None
    rule_smarts: str | None = None
    candidate_validation: CompositeValidationResult | None = None
    status: str = "pending"
    error: dict[str, Any] | None = None


@dataclass
class ValidatedCompositeCollection:
    """Occurrence-aware primary and certified composite collections."""

    aggregates: dict[str, CompositeRuleAggregate]
    certified_aggregates: dict[str, CompositeRuleAggregate]
    pseudo_reactions: list[PseudoReactionRecord]
    stats: CompositeCollectionStats
    errors: list[dict[str, Any]]
    validation_records: list[dict[str, Any]]
    occurrence_paths: list[Path]
    input_occurrence_schema_versions: tuple[int, ...]
    processed_occurrence_schema_versions: tuple[int, ...]


def is_standardization_error(exc: Exception) -> bool:
    """Return whether standardization error matches the expected condition.

    This step supports composite rule extraction from rrseq applications and
    keeps duplicate rules merged by structural identity.
    """
    return type(exc).__name__ == "StandardizationError"


def compose_pseudo_reaction_smiles(
    target_smiles: str,
    rrseq: str,
) -> str:
    """Compose pseudo reaction SMILES from normalized inputs.

    The pseudo-reaction collapses an unwrapped route into target-to-stock reactants
    before SynPlanner rule extraction is run again.
    """
    from chython.containers.reaction import ReactionContainer

    unwrapped = unwrap_rule_sequence(
        target_smiles,
        split_rrseq(rrseq),
        route_id=0,
        rule_key_prefix="rrseq",
        mark_leaves_in_stock=True,
    )
    reactants, product = normalize_pseudo_reaction_mapping(
        unwrapped.leaf_molecules,
        unwrapped.target_molecule,
    )
    pseudo_reaction = ReactionContainer(
        reactants=tuple(reactants),
        products=(product,),
    )
    return format(pseudo_reaction, "m")


def serialize_rule_step_trace(trace: RuleStepTrace) -> dict[str, Any]:
    """Return a JSON-safe RRseq application witness."""

    return {
        "step_index": trace.step_index,
        "rule_smarts": trace.rule_smarts,
        "input_smiles": trace.input_smiles,
        "selected_outcome_index": trace.selected_outcome_index,
        "selected_continuation_index": trace.selected_continuation_index,
        "truncated": trace.truncated,
        "outcomes": [
            {
                "outcome_index": outcome.outcome_index,
                "reaction_smiles": outcome.reaction_smiles,
                "product_smiles": list(outcome.product_smiles),
                "query_to_target_mappings": [
                    [list(pair) for pair in mapping]
                    for mapping in outcome.query_to_target_mappings
                ],
                "continuation_product_indices": list(
                    outcome.continuation_product_indices
                ),
            }
            for outcome in trace.outcomes
        ],
    }


def compose_pseudo_reaction_witness(
    target_smiles: str,
    rrseq: str,
    *,
    source_route_leaves: Iterable[str] | None = None,
    source_matches: Iterable[dict[str, Any]] | None = None,
    max_replay_outcomes: int | None = None,
) -> CompositeWitness:
    """Compose a pseudo-reaction without discarding its RRseq application trace."""

    from chython.containers.reaction import ReactionContainer

    unwrapped = unwrap_rule_sequence_traced(
        target_smiles,
        split_rrseq(rrseq),
        route_id=0,
        rule_key_prefix="rrseq",
        mark_leaves_in_stock=True,
        source_matches=(tuple(source_matches) if source_matches is not None else None),
        max_outcomes_per_step=max_replay_outcomes,
    )
    source_leaf_smiles = tuple(source_route_leaves or ())
    source_comparison = None
    if source_route_leaves is not None:
        source_comparison = compare_precursor_multisets(
            source_leaf_smiles,
            unwrapped.leaf_molecules,
            lineage_atom_ids={
                int(atom_number) for atom_number in unwrapped.target_molecule
            },
        )
    reactants, product = normalize_pseudo_reaction_mapping(
        unwrapped.leaf_molecules,
        unwrapped.target_molecule,
    )
    pseudo_reaction = ReactionContainer(
        reactants=tuple(reactants),
        products=(product,),
    )
    return CompositeWitness(
        pseudo_reaction_smiles=format(pseudo_reaction, "m"),
        target_smiles=format(product, "m"),
        rrseq_leaf_smiles=tuple(format(reactant, "m") for reactant in reactants),
        source_route_leaf_smiles=source_leaf_smiles,
        source_comparison=source_comparison,
        rrseq_step_traces=tuple(
            serialize_rule_step_trace(trace) for trace in unwrapped.step_traces
        ),
    )


def normalize_pseudo_reaction_mapping(
    reactants: Iterable[Any],
    product: Any,
) -> tuple[list[Any], Any]:
    """Normalize pseudo reaction mapping for route-inspector processing.

    The pseudo-reaction collapses an unwrapped route into target-to-stock reactants
    before SynPlanner rule extraction is run again.
    """
    product = product.copy()
    product_atoms = {
        atom_number: atom.atomic_number for atom_number, atom in product.atoms()
    }
    used_reactant_numbers: set[int] = set()
    next_atom_number = max(product_atoms, default=0) + 1
    normalized_reactants = []

    for reactant in reactants:
        reactant = reactant.copy()
        remapping: dict[int, int] = {}
        for atom_number, atom in reactant.atoms():
            product_atomic_number = product_atoms.get(atom_number)
            can_keep_number = atom_number not in used_reactant_numbers and (
                product_atomic_number is None
                or product_atomic_number == atom.atomic_number
            )
            if can_keep_number:
                used_reactant_numbers.add(atom_number)
                continue

            while (
                next_atom_number in product_atoms
                or next_atom_number in used_reactant_numbers
            ):
                next_atom_number += 1
            remapping[atom_number] = next_atom_number
            used_reactant_numbers.add(next_atom_number)
            next_atom_number += 1

        if remapping:
            reactant.remap(remapping)
        normalized_reactants.append(reactant)

    return normalized_reactants, product


def rule_query_cgr(rule_smarts: str) -> Any:
    """Return rule query CGR used for rule extraction or comparison.

    The comparison uses composed QueryCGR structure rather than raw SMARTS strings,
    which avoids treating equivalent atom-map numbering as different.
    """
    from chython import smarts
    from chython.containers.reaction import ReactionContainer
    from chython.reactor import Reactor

    try:
        return smarts(rule_smarts).compose()
    except Exception:
        reactor = Reactor.from_smarts(rule_smarts, delete_atoms=False)
        reaction = ReactionContainer(
            reactor.__dict__["_patterns"],
            reactor.__dict__["_products"],
        )
        return reaction.compose()


def rule_cgr_key(rule_smarts: str) -> str:
    """Return rule CGR key used for rule extraction or comparison.

    The comparison uses composed QueryCGR structure rather than raw SMARTS strings,
    which avoids treating equivalent atom-map numbering as different.
    """
    return json.dumps(
        query_cgr_coarse_signature(rule_query_cgr(rule_smarts)),
        sort_keys=True,
        default=repr,
    )


def freeze_query_value(value: Any) -> Any:
    """Convert query value into a hashable representation.

    The comparison uses composed QueryCGR structure rather than raw SMARTS strings,
    which avoids treating equivalent atom-map numbering as different.
    """
    if isinstance(value, (tuple, list)):
        return tuple(freeze_query_value(item) for item in value)
    if isinstance(value, set):
        return tuple(sorted(freeze_query_value(item) for item in value))
    if isinstance(value, (int, float, str, bool, type(None))):
        return value
    return repr(value)


def query_atom_signature(atom: Any) -> tuple[Any, ...]:
    """Return query atom signature used for structural rule comparison.

    The comparison uses composed QueryCGR structure rather than raw SMARTS strings,
    which avoids treating equivalent atom-map numbering as different.
    """
    return (
        atom.atomic_number,
        repr(freeze_query_value(atom.charge)),
        repr(freeze_query_value(atom.p_charge)),
        repr(freeze_query_value(atom.is_radical)),
        repr(freeze_query_value(atom.p_is_radical)),
        repr(freeze_query_value(atom.neighbors)),
        repr(freeze_query_value(atom.p_neighbors)),
        repr(freeze_query_value(atom.hybridization)),
        repr(freeze_query_value(atom.p_hybridization)),
        repr(freeze_query_value(atom.isotope)),
    )


def query_bond_signature(bond: Any) -> tuple[Any, ...]:
    """Return query bond signature used for structural rule comparison.

    The comparison uses composed QueryCGR structure rather than raw SMARTS strings,
    which avoids treating equivalent atom-map numbering as different.
    """
    return (
        repr(freeze_query_value(bond.order)),
        repr(freeze_query_value(bond.p_order)),
    )


def query_cgr_adjacency(query_cgr: Any) -> dict[int, dict[int, tuple[Any, ...]]]:
    """Return query CGR adjacency used for structural rule comparison.

    The comparison uses composed QueryCGR structure rather than raw SMARTS strings,
    which avoids treating equivalent atom-map numbering as different.
    """
    adjacency = {atom_number: {} for atom_number, _atom in query_cgr.atoms()}
    for atom_1, atom_2, bond in query_cgr.bonds():
        signature = query_bond_signature(bond)
        adjacency[atom_1][atom_2] = signature
        adjacency[atom_2][atom_1] = signature
    return adjacency


def query_cgr_coarse_signature(query_cgr: Any) -> tuple[Any, ...]:
    """Return query CGR coarse signature used for structural rule comparison.

    The comparison uses composed QueryCGR structure rather than raw SMARTS strings,
    which avoids treating equivalent atom-map numbering as different.
    """
    atom_signatures = {
        atom_number: query_atom_signature(atom)
        for atom_number, atom in query_cgr.atoms()
    }
    bond_signatures = []
    for atom_1, atom_2, bond in query_cgr.bonds():
        endpoints = sorted((atom_signatures[atom_1], atom_signatures[atom_2]))
        bond_signatures.append((tuple(endpoints), query_bond_signature(bond)))
    return (
        tuple(sorted(atom_signatures.values())),
        tuple(sorted(bond_signatures)),
    )


def query_cgr_isomorphic(left: Any, right: Any) -> bool:
    """Return query CGR isomorphic used for structural rule comparison.

    The comparison uses composed QueryCGR structure rather than raw SMARTS strings,
    which avoids treating equivalent atom-map numbering as different.
    """
    if left.atoms_count != right.atoms_count:
        return False
    if left.bonds_count != right.bonds_count:
        return False

    left_atoms = {
        atom_number: query_atom_signature(atom) for atom_number, atom in left.atoms()
    }
    right_atoms = {
        atom_number: query_atom_signature(atom) for atom_number, atom in right.atoms()
    }
    left_adjacency = query_cgr_adjacency(left)
    right_adjacency = query_cgr_adjacency(right)

    candidates = {
        left_atom: [
            right_atom
            for right_atom, right_signature in right_atoms.items()
            if right_signature == left_signature
            and len(right_adjacency[right_atom]) == len(left_adjacency[left_atom])
        ]
        for left_atom, left_signature in left_atoms.items()
    }
    if any(not atom_candidates for atom_candidates in candidates.values()):
        return False

    order = sorted(
        left_atoms,
        key=lambda atom_number: (
            len(candidates[atom_number]),
            -len(left_adjacency[atom_number]),
        ),
    )
    mapping: dict[int, int] = {}
    used_right_atoms: set[int] = set()

    def mapping_is_consistent(left_atom: int, right_atom: int) -> bool:
        """Return whether a candidate atom mapping is consistent with prior matches.

        This step supports composite rule extraction from rrseq applications
        and keeps duplicate rules merged by structural identity.
        """
        for mapped_left_atom, mapped_right_atom in mapping.items():
            left_bond = left_adjacency[left_atom].get(mapped_left_atom)
            right_bond = right_adjacency[right_atom].get(mapped_right_atom)
            if (left_bond is None) != (right_bond is None):
                return False
            if left_bond is not None and left_bond != right_bond:
                return False
        return True

    def search(index: int) -> bool:
        """Search candidate atom mappings recursively.

        This step supports composite rule extraction from rrseq applications
        and keeps duplicate rules merged by structural identity.
        """
        if index == len(order):
            return True
        left_atom = order[index]
        for right_atom in candidates[left_atom]:
            if right_atom in used_right_atoms:
                continue
            if not mapping_is_consistent(left_atom, right_atom):
                continue
            mapping[left_atom] = right_atom
            used_right_atoms.add(right_atom)
            if search(index + 1):
                return True
            used_right_atoms.remove(right_atom)
            del mapping[left_atom]
        return False

    return search(0)


def matching_aggregate(
    aggregate_buckets: dict[tuple[Any, ...], list[CompositeRuleAggregate]],
    query_cgr: Any,
) -> CompositeRuleAggregate | None:
    """Find an existing composite aggregate with an isomorphic QueryCGR.

    The aggregation links each composite rule back to the rrseqs, targets, and
    route IDs that produced it.
    """
    for aggregate in aggregate_buckets.get(query_cgr_coarse_signature(query_cgr), []):
        if aggregate.query_cgr is not None and query_cgr_isomorphic(
            aggregate.query_cgr,
            query_cgr,
        ):
            return aggregate
    return None


def collection_error_row(
    application: Any,
    *,
    stage: str,
    exc: Exception,
    composite_rule: str = "",
) -> dict[str, Any]:
    """Build a TSV row describing a failed composite-rule application.

    This step supports composite rule extraction from rrseq applications and
    keeps duplicate rules merged by structural identity.
    """
    row = {
        "source_tsv": str(application.source_tsv),
        "row_index": application.row_index,
        "Target_smiles": application.target_smiles,
        "RRseq_cons": application.rrseq_cons,
        "RRseq_cons_size": application.rrseq_cons_size,
        "Route_ids": ",".join(application.route_ids),
    }
    if getattr(application, "route_id", None) is not None:
        source_name = Path(application.source_tsv).name
        row.update(
            {
                "dataset": source_name.split("_t", 1)[0],
                "route_id": str(application.route_id),
                "reaction_steps": ",".join(
                    str(match["path_position"])
                    for match in getattr(application, "source_matches", ())
                    if isinstance(match, dict)
                    and match.get("path_position") is not None
                ),
                "stage": stage,
                "error_type": type(exc).__qualname__,
                "message": str(exc),
                "composite_rule": composite_rule,
            }
        )
    return row


class CompositeRuleExtractor:
    def __init__(
        self,
        config: Any,
        *,
        retain_query_cgr: bool = True,
        max_cache_size: int | None = None,
        config_path: str | Path | None = None,
    ):
        """Initialize this object with its resolved configuration.

        This step supports composite rule extraction from rrseq applications
        and keeps duplicate rules merged by structural identity.
        """
        self.config = config
        self.config_path = None if config_path is None else Path(config_path)
        self.retain_query_cgr = bool(retain_query_cgr)
        if max_cache_size is not None and max_cache_size < 1:
            raise ValueError("max_cache_size must be positive or None")
        self.max_cache_size = max_cache_size
        self.cache: OrderedDict[
            str,
            ExtractedCompositeRule | None,
        ] = OrderedDict()

    @classmethod
    def from_args(
        cls,
        args: RuleExtractionSettings,
        *,
        retain_query_cgr: bool = True,
        max_cache_size: int | None = None,
    ) -> "CompositeRuleExtractor":
        """Build an extractor instance from parsed CLI arguments.

        This step supports composite rule extraction from rrseq applications
        and keeps duplicate rules merged by structural identity.
        """
        try:
            from synplan.chem.reaction.rules.config import RuleExtractionConfig
        except ImportError:  # SynPlanner 1.6 compatibility
            from synplan.utils.config import RuleExtractionConfig

        config_path = resolve_existing_path(
            getattr(args, "config", None) or DEFAULT_COMPOSITE_RULE_CONFIG
        )
        if not config_path.is_file():
            raise FileNotFoundError(f"rule extraction config not found: {config_path}")
        config = RuleExtractionConfig.from_yaml(str(config_path))
        return cls(
            config,
            retain_query_cgr=retain_query_cgr,
            max_cache_size=max_cache_size,
            config_path=config_path,
        )

    def extract(self, reaction_smiles: str) -> ExtractedCompositeRule | None:
        """Extract one rule from a mapped reaction SMILES string.

        This step supports composite rule extraction from rrseq applications
        and keeps duplicate rules merged by structural identity.
        """
        if reaction_smiles in self.cache:
            cached = self.cache[reaction_smiles]
            self.cache.move_to_end(reaction_smiles)
            return cached

        from chython import smiles as parse_smiles
        from synplan.chem.reaction.rules.extraction import (
            _rule_to_reactor_smarts,
            extract_rules,
        )

        reaction = parse_smiles(reaction_smiles)
        rules, skipped = extract_rules(self.config, reaction)
        if skipped or not rules:
            self._remember(reaction_smiles, None)
            return None
        if len(rules) != 1:
            raise ValueError(f"expected one composite rule, got {len(rules)}")

        rule = rules[0]
        from synplan.chem.utils import canonical_query_cgr_key

        from route_inspector.rules.transformation import capture_rule

        transformation = capture_rule(rule, canonical_query_cgr_key(~rule))
        rule_smarts = _rule_to_reactor_smarts(rule)
        extracted = ExtractedCompositeRule(
            rule_smarts=rule_smarts,
            cgr_key=rule_cgr_key(rule_smarts),
            query_cgr=(rule_query_cgr(rule_smarts) if self.retain_query_cgr else None),
            transformation=transformation,
        )
        self._remember(reaction_smiles, extracted)
        return extracted

    def _remember(
        self,
        reaction_smiles: str,
        extracted: ExtractedCompositeRule | None,
    ) -> None:
        self.cache[reaction_smiles] = extracted
        if getattr(self, "evidence", None) is not None:
            self.evidence.record("composite", reaction_smiles, extracted)
        self.cache.move_to_end(reaction_smiles)
        if self.max_cache_size is not None:
            while len(self.cache) > self.max_cache_size:
                self.cache.popitem(last=False)


def composite_extractor_args_dict(args: RuleExtractionSettings) -> dict[str, Any]:
    """Serialize composite extractor settings for worker initialization.

    This step supports composite rule extraction from rrseq applications and
    keeps duplicate rules merged by structural identity.
    """
    return {
        "config": str(
            resolve_existing_path(
                getattr(args, "config", None) or DEFAULT_COMPOSITE_RULE_CONFIG
            )
        ),
        "environment_atom_count": getattr(args, "environment_atom_count", 1),
        "include_rings": getattr(args, "include_rings", False),
        "keep_leaving_groups": getattr(args, "keep_leaving_groups", True),
        "keep_incoming_groups": getattr(args, "keep_incoming_groups", False),
        "reactor_validation": getattr(args, "reactor_validation", False),
    }


def _init_composite_worker(extractor_args: dict[str, Any]) -> None:
    """Run the worker entry point for init composite.

    This step supports composite rule extraction from rrseq applications and
    keeps duplicate rules merged by structural identity.
    """
    global _COMPOSITE_WORKER_EXTRACTOR
    setup_runtime_cache_dirs()
    _COMPOSITE_WORKER_EXTRACTOR = CompositeRuleExtractor.from_args(
        RuleExtractionSettings(**extractor_args)
    )


def _composite_application_worker(item: tuple[int, Any]) -> dict[str, Any]:
    """Run the worker entry point for composite application.

    This step supports composite rule extraction from rrseq applications and
    keeps duplicate rules merged by structural identity.
    """
    _application_index, application = item
    try:
        if _COMPOSITE_WORKER_EXTRACTOR is None:
            raise RuntimeError("composite worker was not initialized")
        pseudo_reaction_smiles = compose_pseudo_reaction_smiles(
            application.target_smiles,
            application.rrseq_cons,
        )
        extracted = _COMPOSITE_WORKER_EXTRACTOR.extract(pseudo_reaction_smiles)
        if extracted is None:
            return {
                "status": "skipped_rule_extraction",
                "application": application,
                "pseudo_reaction_smiles": pseudo_reaction_smiles,
            }
        return {
            "status": "ok",
            "application": application,
            "pseudo_reaction_smiles": pseudo_reaction_smiles,
            "rule_smarts": extracted.rule_smarts,
        }
    except Exception as exc:
        if isinstance(exc, RuleApplicationError):
            return {
                "status": "skipped_unwrap",
                "application": application,
                "error": collection_error_row(
                    application,
                    stage="skipped_unwrap",
                    exc=exc,
                ),
            }
        if is_standardization_error(exc):
            return {
                "status": "skipped_rule_extraction_error",
                "application": application,
            }
        return {
            "status": "error",
            "application": application,
            "error": {
                **collection_error_row(application, stage="error", exc=exc),
                "error_type": type(exc).__qualname__,
                "message": str(exc) or traceback.format_exc(limit=1).strip(),
            },
        }


def build_composite_candidate(
    application: Any,
    extractor: CompositeRuleExtractor,
    *,
    max_replay_outcomes: int,
) -> CompositeCandidate:
    """Extract and immediately reapply one occurrence-level composite candidate."""

    witness: CompositeWitness | None = None
    try:
        witness = compose_pseudo_reaction_witness(
            application.target_smiles,
            application.rrseq_cons,
            source_route_leaves=application.source_route_leaves,
            source_matches=application.source_matches,
            max_replay_outcomes=max_replay_outcomes,
        )
        extracted = extractor.extract(witness.pseudo_reaction_smiles)
        if extracted is None:
            return CompositeCandidate(
                application=application,
                witness=witness,
                status="skipped_rule_extraction",
            )
        validation = validate_abstract_composite_rule(
            witness.target_smiles,
            extracted.rule_smarts,
            witness.source_route_leaf_smiles or witness.rrseq_leaf_smiles,
            max_outcomes=max_replay_outcomes,
        )
        return CompositeCandidate(
            application=application,
            witness=witness,
            rule_smarts=extracted.rule_smarts,
            candidate_validation=validation,
            status="ok",
        )
    except EvidenceCacheError:
        # Infrastructure failures must abort construction, never reject chemistry.
        raise
    except Exception as exc:
        if isinstance(exc, CompositeApplicationTimeoutError):
            status = "application_timeout"
        elif isinstance(exc, RuleApplicationOutcomeLimitError):
            status = "rrseq_outcome_limit_reached"
        elif isinstance(exc, RuleApplicationError):
            status = "skipped_unwrap"
        elif is_standardization_error(exc):
            status = "skipped_rule_extraction_error"
        else:
            status = "error"
        return CompositeCandidate(
            application=application,
            witness=witness,
            status=status,
            error={
                **collection_error_row(application, stage=status, exc=exc),
                "error_type": type(exc).__qualname__,
                "message": str(exc) or traceback.format_exc(limit=1).strip(),
                "occurrence_id": application.occurrence_id or "",
            },
        )


def build_composite_candidate_with_timeout(
    application: Any,
    extractor: CompositeRuleExtractor,
    *,
    max_replay_outcomes: int,
    application_timeout_seconds: float | None,
) -> CompositeCandidate:
    """Build one candidate under a process-local wall-clock deadline."""

    if application_timeout_seconds is None:
        return build_composite_candidate(
            application,
            extractor,
            max_replay_outcomes=max_replay_outcomes,
        )
    if application_timeout_seconds <= 0:
        raise ValueError("--application-timeout-seconds must be greater than zero")
    if not hasattr(signal, "SIGALRM") or not hasattr(signal, "setitimer"):
        raise RuntimeError(
            "per-occurrence composite timeout requires POSIX SIGALRM support"
        )

    previous_handler = signal.getsignal(signal.SIGALRM)

    def raise_timeout(_signum: int, _frame: Any) -> None:
        raise CompositeApplicationTimeoutError(
            "composite occurrence processing exceeded "
            f"{application_timeout_seconds:g} seconds"
        )

    signal.signal(signal.SIGALRM, raise_timeout)
    signal.setitimer(signal.ITIMER_REAL, application_timeout_seconds)
    try:
        return build_composite_candidate(
            application,
            extractor,
            max_replay_outcomes=max_replay_outcomes,
        )
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)


def _validated_composite_candidate_worker(
    item: tuple[int, Any, int, float | None],
) -> CompositeCandidate:
    """Worker-safe occurrence candidate extraction and reapplication."""

    (
        _application_index,
        application,
        max_replay_outcomes,
        application_timeout_seconds,
    ) = item
    if _COMPOSITE_WORKER_EXTRACTOR is None:
        raise RuntimeError("composite worker was not initialized")
    return build_composite_candidate_with_timeout(
        application,
        _COMPOSITE_WORKER_EXTRACTOR,
        max_replay_outcomes=max_replay_outcomes,
        application_timeout_seconds=application_timeout_seconds,
    )


def application_timeout_candidate(
    application: Any,
    application_timeout_seconds: float,
) -> CompositeCandidate:
    """Represent a parent-enforced hard timeout as an inconclusive candidate."""

    exc = CompositeApplicationTimeoutError(
        "composite occurrence processing exceeded "
        f"{application_timeout_seconds:g} seconds"
    )
    return CompositeCandidate(
        application=application,
        witness=None,
        status="application_timeout",
        error={
            **collection_error_row(
                application,
                stage="application_timeout",
                exc=exc,
            ),
            "error_type": type(exc).__qualname__,
            "message": str(exc),
            "occurrence_id": application.occurrence_id or "",
        },
    )


def terminate_process_pool(executor: ProcessPoolExecutor) -> None:
    """Terminate workers, then join the executor's management threads.

    Waiting for the executor before killing a worker can hang when native graph
    matching does not return. Marking the pool broken before terminating workers
    wakes the executor manager and lets that thread close its own queues; manually
    closing them from the caller races the manager and can deadlock the parent.
    """

    manager = getattr(executor, "_executor_manager_thread", None)
    wakeup = getattr(executor, "_executor_manager_thread_wakeup", None)
    shutdown_lock = getattr(executor, "_shutdown_lock", None)
    processes = list(getattr(executor, "_processes", {}).values())

    def stop_workers() -> None:
        executor._broken = "composite watchdog terminated an overdue worker"
        executor._shutdown_thread = True
        for process in processes:
            if process.is_alive():
                process.terminate()
        for process in processes:
            process.join(timeout=1)
        for process in processes:
            if process.is_alive():
                process.kill()
        for process in processes:
            process.join(timeout=1)
        if wakeup is not None:
            wakeup.wakeup()

    if shutdown_lock is None:
        stop_workers()
    else:
        with shutdown_lock:
            stop_workers()
    if manager is not None:
        manager.join()
    executor.shutdown(wait=True, cancel_futures=True)


def build_composite_candidates_parallel(
    applications: list[Any],
    *,
    n_cpu: int,
    extractor_args: RuleExtractionSettings,
    max_replay_outcomes: int,
    application_timeout_seconds: float | None,
) -> list[CompositeCandidate]:
    """Build candidates with at most one in-flight occurrence per worker.

    The bounded queue makes submission time a conservative approximation of
    task start time. If compiled graph matching ignores Python signals, the
    parent terminates the worker generation and records every killed in-flight
    occurrence as inconclusive. Pending work that had not yet entered the killed
    pool is then submitted to a fresh generation with a fresh deadline.
    """

    pending = deque(
        (index, application, None) for index, application in enumerate(applications)
    )
    candidates: list[CompositeCandidate | None] = [None] * len(applications)
    extractor_config = composite_extractor_args_dict(extractor_args)

    while pending:
        executor = ProcessPoolExecutor(
            max_workers=n_cpu,
            initializer=_init_composite_worker,
            initargs=(extractor_config,),
        )
        active: dict[Any, tuple[int, Any, float]] = {}

        def submit_available() -> None:
            while pending and len(active) < n_cpu:
                index, application, original_started_at = pending.popleft()
                started_at = original_started_at or time.monotonic()
                future = executor.submit(
                    _validated_composite_candidate_worker,
                    (
                        index,
                        application,
                        max_replay_outcomes,
                        application_timeout_seconds,
                    ),
                )
                active[future] = (index, application, started_at)

        submit_available()
        generation_terminated = False
        while active:
            ready = {future for future in active if future.done()}
            if ready:
                for future in ready:
                    index, _application, _started_at = active.pop(future)
                    candidates[index] = future.result()
                submit_available()
                # Harvest newly submitted work that finishes immediately before
                # deciding whether an older task requires pool termination.
                continue
            if not active:
                break

            now = time.monotonic()
            overdue = {
                future
                for future, (_, _, started_at) in active.items()
                if (
                    application_timeout_seconds is not None
                    and not future.done()
                    and now - started_at >= application_timeout_seconds
                )
            }
            if overdue:
                # Terminating a ProcessPoolExecutor kills all of its workers,
                # not only the process running the first overdue future. Do not
                # resubmit collateral tasks with nearly expired original clocks:
                # that can kill a replacement pool during its initialization and
                # strand its management thread. Every unfinished task in this
                # generation is therefore accounted as inconclusive.
                for future, (index, application, _started_at) in active.items():
                    candidates[index] = application_timeout_candidate(
                        application,
                        application_timeout_seconds,
                    )
                terminate_process_pool(executor)
                active.clear()
                generation_terminated = True
                break

            wait_seconds = None
            if application_timeout_seconds is not None:
                next_deadline = min(
                    started_at + application_timeout_seconds
                    for _, _, started_at in active.values()
                )
                wait_seconds = max(0.0, next_deadline - time.monotonic())
            done, _ = wait(
                active,
                timeout=wait_seconds,
                return_when=FIRST_COMPLETED,
            )
            if done:
                for future in done:
                    index, _application, _started_at = active.pop(future)
                    candidates[index] = future.result()
                submit_available()

        if not generation_terminated:
            executor.shutdown(wait=True)

    if any(candidate is None for candidate in candidates):
        raise RuntimeError("parallel composite candidate accounting is incomplete")
    return [candidate for candidate in candidates if candidate is not None]


def select_rrseq_applications(
    rrseq_tsvs: list[Path],
    *,
    limit_rows: int | None = None,
    limit_applications: int | None = None,
) -> tuple[list[Any], int]:
    """Select rrseq rule applications for the next processing step.

    The aggregation links each composite rule back to the rrseqs, targets, and
    route IDs that produced it.
    """
    applications = []
    rows_seen: set[tuple[Path, int]] = set()
    rrseq_rows_seen = 0
    for application in iter_rrseq_applications(rrseq_tsvs):
        if limit_applications is not None and len(applications) >= limit_applications:
            break
        row_key = (application.source_tsv, application.row_index)
        if row_key not in rows_seen:
            if limit_rows is not None and rrseq_rows_seen >= limit_rows:
                break
            rows_seen.add(row_key)
            rrseq_rows_seen += 1
        applications.append(application)
    return applications, rrseq_rows_seen


def select_occurrence_applications(
    rrseq_tsvs: list[Path],
    occurrence_paths: list[Path],
    *,
    limit_rows: int | None = None,
    limit_applications: int | None = None,
) -> tuple[list[Any], int, tuple[int, ...], tuple[int, ...]]:
    """Return applications, row count, all-input schemas, and processed schemas."""

    selected_rows: list[tuple[Path, int]] = []
    for tsv_path in rrseq_tsvs:
        with tsv_path.open(encoding="utf-8") as file:
            reader = csv.DictReader(file, delimiter="\t")
            fieldnames = set(reader.fieldnames or ())
            rrseq_column = "RRseq_cons" if "RRseq_cons" in fieldnames else "RRseq"
            required = {rrseq_column, "Reference", "Target_molecules"}
            missing = sorted(required - fieldnames)
            if missing:
                raise ValueError(
                    f"{tsv_path} lacks exact-provenance columns: " + ", ".join(missing)
                )
            selected_rows.extend(
                (tsv_path, row_index)
                for row_index, row in enumerate(reader)
                if (row.get(rrseq_column) or "").strip()
            )
    selected_rows.sort(key=lambda item: (str(item[0]), item[1]))
    if limit_rows is not None:
        selected_rows = selected_rows[:limit_rows]
    selected_row_set = set(selected_rows)

    input_occurrence_schema_versions: set[int] = set()
    applications = sorted(
        iter_rrseq_occurrence_applications(
            rrseq_tsvs,
            occurrence_paths,
            occurrence_schema_versions=input_occurrence_schema_versions,
        ),
        key=lambda application: (
            application.occurrence_id or "",
            str(application.source_tsv),
            application.row_index,
        ),
    )
    applications = [
        application
        for application in applications
        if (application.source_tsv, application.row_index) in selected_row_set
    ]
    matched_rows = {
        (application.source_tsv, application.row_index) for application in applications
    }
    missing_rows = [row for row in selected_rows if row not in matched_rows]
    if missing_rows:
        preview = ", ".join(
            f"{path}:{row_index + 2}" for path, row_index in missing_rows[:10]
        )
        suffix = "" if len(missing_rows) <= 10 else ", ..."
        raise ValueError(
            "ordinary RRseq occurrence coverage is incomplete; no exact "
            f"occurrence matched {len(missing_rows)} selected row(s): "
            f"{preview}{suffix}"
        )
    if limit_applications is not None:
        applications = applications[:limit_applications]
        retained_rows = {
            (application.source_tsv, application.row_index)
            for application in applications
        }
        selected_rows = [row for row in selected_rows if row in retained_rows]
    return (
        applications,
        len(selected_rows),
        tuple(sorted(input_occurrence_schema_versions)),
        tuple(
            sorted(
                {
                    int(application.occurrence_schema_version)
                    for application in applications
                    if application.occurrence_schema_version is not None
                }
            )
        ),
    )


def merge_composite_success(
    *,
    application: Any,
    pseudo_reaction_smiles: str,
    rule_smarts: str,
    aggregates: dict[str, CompositeRuleAggregate],
    aggregate_buckets: dict[tuple[Any, ...], list[CompositeRuleAggregate]],
    pseudo_reactions: list[PseudoReactionRecord],
) -> None:
    """Merge composite success into aggregate results.

    The aggregation links each composite rule back to the rrseqs, targets, and
    route IDs that produced it.
    """
    query_cgr = rule_query_cgr(rule_smarts)
    cgr_key = rule_cgr_key(rule_smarts)
    aggregate = matching_aggregate(aggregate_buckets, query_cgr)
    if aggregate is None:
        aggregate = CompositeRuleAggregate(
            rule_smarts=rule_smarts,
            cgr_key=cgr_key,
            query_cgr=query_cgr,
        )
        aggregates[aggregate.cgr_key] = aggregate
        aggregate_buckets.setdefault(
            query_cgr_coarse_signature(query_cgr),
            [],
        ).append(aggregate)

    pseudo_reaction_id = f"p{len(pseudo_reactions)}"
    pseudo_reactions.append(
        PseudoReactionRecord(
            pseudo_reaction_id=pseudo_reaction_id,
            composite_cgr=aggregate.cgr_key,
            reaction_smiles=pseudo_reaction_smiles,
            source_tsv=str(application.source_tsv),
            source_row=application.row_index,
            route_ids=application.route_ids,
            target_smiles=application.target_smiles,
            rrseq_size=application.rrseq_cons_size,
            rrseq=application.rrseq_cons,
        )
    )

    aggregate.route_ids.update(application.route_ids)
    for route_id in application.route_ids:
        aggregate.qualified_route_ids.add(
            (getattr(application, "source_identity", None), route_id)
        )
    aggregate.target_molecules.add(application.target_smiles)
    aggregate.rrseqs.add(application.rrseq_cons)
    aggregate.rrseq_sizes.add(application.rrseq_cons_size)
    aggregate.source_rows.add(f"{application.source_tsv.name}:{application.row_index}")
    aggregate.pseudo_reaction_ids.append(pseudo_reaction_id)


def collect_composite_rules(
    rrseq_tsvs: list[Path],
    extractor: CompositeRuleExtractor,
    *,
    limit_rows: int | None = None,
    limit_applications: int | None = None,
    ignore_errors: bool = False,
    progress_interval: int = 250,
    n_cpu: int = 1,
    extractor_args: RuleExtractionSettings | None = None,
) -> tuple[
    dict[str, CompositeRuleAggregate],
    list[PseudoReactionRecord],
    CompositeCollectionStats,
    list[dict[str, Any]],
]:
    """Collect composite rules from route-analysis input data.

    The aggregation links each composite rule back to the rrseqs, targets, and
    route IDs that produced it.
    """
    aggregates: dict[str, CompositeRuleAggregate] = {}
    aggregate_buckets: dict[tuple[Any, ...], list[CompositeRuleAggregate]] = {}
    pseudo_reactions: list[PseudoReactionRecord] = []
    errors: list[dict[str, Any]] = []
    stats = CompositeCollectionStats()
    applications, stats.rrseq_rows_seen = select_rrseq_applications(
        rrseq_tsvs,
        limit_rows=limit_rows,
        limit_applications=limit_applications,
    )
    n_cpu = normalize_n_cpu(n_cpu)

    def consume_result(result: dict[str, Any]) -> None:
        """Merge one worker result into the aggregate state.

        This step supports composite rule extraction from rrseq applications
        and keeps duplicate rules merged by structural identity.
        """
        application = result["application"]
        stats.applications_seen += 1
        status = result["status"]

        if status == "ok":
            stats.pseudo_reactions_built += 1
            stats.composite_rules_extracted += 1
            merge_composite_success(
                application=application,
                pseudo_reaction_smiles=result["pseudo_reaction_smiles"],
                rule_smarts=result["rule_smarts"],
                aggregates=aggregates,
                aggregate_buckets=aggregate_buckets,
                pseudo_reactions=pseudo_reactions,
            )
        elif status == "skipped_rule_extraction":
            stats.pseudo_reactions_built += 1
            stats.skipped_rule_extractions += 1
        elif status == "skipped_rule_extraction_error":
            stats.skipped_rule_extraction_errors += 1
        elif status == "skipped_unwrap":
            stats.skipped_unwrap_applications += 1
            errors.append(result["error"])
        else:
            stats.errors += 1
            errors.append(result["error"])
            if not ignore_errors:
                raise RuntimeError(
                    "composite rule extraction failed for "
                    f"{application.source_tsv}:{application.row_index}: "
                    f"{result['error'].get('error_type', 'Error')}: "
                    f"{result['error'].get('message', '')}"
                )

        if progress_interval and stats.applications_seen % progress_interval == 0:
            print(
                "processed applications="
                f"{stats.applications_seen} composite_rules={len(aggregates)} "
                f"skipped_unwrap={stats.skipped_unwrap_applications} "
                f"errors={stats.errors}",
                flush=True,
            )

    if n_cpu > 1 and applications:
        if extractor_args is None:
            raise ValueError("extractor_args is required when n_cpu > 1")
        with ProcessPoolExecutor(
            max_workers=n_cpu,
            initializer=_init_composite_worker,
            initargs=(composite_extractor_args_dict(extractor_args),),
        ) as executor:
            for result in executor.map(
                _composite_application_worker,
                enumerate(applications),
            ):
                consume_result(result)
    else:
        for application_index, application in enumerate(applications):
            try:
                pseudo_reaction_smiles = compose_pseudo_reaction_smiles(
                    application.target_smiles,
                    application.rrseq_cons,
                )
                extracted = extractor.extract(pseudo_reaction_smiles)
                if extracted is None:
                    result = {
                        "status": "skipped_rule_extraction",
                        "application": application,
                        "pseudo_reaction_smiles": pseudo_reaction_smiles,
                    }
                else:
                    result = {
                        "status": "ok",
                        "application": application,
                        "pseudo_reaction_smiles": pseudo_reaction_smiles,
                        "rule_smarts": extracted.rule_smarts,
                    }
            except Exception as exc:
                if isinstance(exc, RuleApplicationError):
                    result = {
                        "status": "skipped_unwrap",
                        "application": application,
                        "error": collection_error_row(
                            application,
                            stage="skipped_unwrap",
                            exc=exc,
                        ),
                    }
                elif is_standardization_error(exc):
                    result = {
                        "status": "skipped_rule_extraction_error",
                        "application": application,
                    }
                else:
                    result = {
                        "status": "error",
                        "application": application,
                        "error": {
                            **collection_error_row(
                                application,
                                stage="error",
                                exc=exc,
                            ),
                            "error_type": type(exc).__qualname__,
                            "message": str(exc)
                            or traceback.format_exc(limit=1).strip(),
                        },
                    }
            consume_result(result)

    if progress_interval and stats.applications_seen % progress_interval:
        print(
            "processed applications="
            f"{stats.applications_seen} composite_rules={len(aggregates)} "
            f"skipped_unwrap={stats.skipped_unwrap_applications} "
            f"errors={stats.errors}",
            flush=True,
        )

    return aggregates, pseudo_reactions, stats, errors


def _group_composite_candidates(
    candidates: Iterable[CompositeCandidate],
) -> list[dict[str, Any]]:
    """Group only byte-identical SMARTS, preserving every query predicate.

    Composed QueryCGRs omit some executable SMARTS constraints, including
    hydrogen-count and ring-membership predicates. They are therefore unsafe
    as a publication equivalence relation.
    """

    groups_by_rule: dict[str, dict[str, Any]] = {}
    ordered = sorted(
        (candidate for candidate in candidates if candidate.rule_smarts),
        key=lambda candidate: (
            candidate.rule_smarts or "",
            candidate.application.occurrence_id or "",
        ),
    )
    for candidate in ordered:
        rule_smarts = candidate.rule_smarts or ""
        group = groups_by_rule.get(rule_smarts)
        if group is None:
            group = {
                "query_cgr": rule_query_cgr(rule_smarts),
                "candidates": [],
            }
            groups_by_rule[rule_smarts] = group
        group["candidates"].append(candidate)
    return [groups_by_rule[rule] for rule in sorted(groups_by_rule)]


def _unique_composite_key(
    rule_smarts: str,
    aggregates: dict[str, CompositeRuleAggregate],
) -> str:
    """Return a collision-safe internal aggregate key."""

    base_key = rule_cgr_key(rule_smarts)
    if base_key not in aggregates:
        return base_key
    suffix = 2
    while f"{base_key}#{suffix}" in aggregates:
        suffix += 1
    return f"{base_key}#{suffix}"


def _update_occurrence_aggregate(
    aggregate: CompositeRuleAggregate,
    candidate: CompositeCandidate,
    *,
    pseudo_reaction_id: str,
    validation_status: str,
    accepted: bool,
) -> None:
    """Merge one exact occurrence without flattening its route/target link."""

    application = candidate.application
    aggregate.route_ids.update(application.route_ids)
    for route_id in application.route_ids:
        aggregate.qualified_route_ids.add(
            (getattr(application, "source_identity", None), route_id)
        )
    aggregate.target_molecules.add(application.target_smiles)
    aggregate.rrseqs.add(application.rrseq_cons)
    aggregate.rrseq_sizes.add(application.rrseq_cons_size)
    aggregate.source_rows.add(f"{application.source_tsv.name}:{application.row_index}")
    aggregate.pseudo_reaction_ids.append(pseudo_reaction_id)
    if application.occurrence_id:
        aggregate.occurrence_ids.add(application.occurrence_id)
        if accepted:
            aggregate.validated_occurrence_ids.add(application.occurrence_id)
            if validation_status == CompositeValidationStatus.VALIDATED_AMBIGUOUS.value:
                aggregate.ambiguous_occurrence_ids.add(application.occurrence_id)
        else:
            aggregate.failed_occurrence_ids.add(application.occurrence_id)


def _validation_status(
    source_comparison: PrecursorComparison | None,
    representative_validation: CompositeValidationResult,
    *,
    allow_ambiguous: bool,
) -> tuple[str, bool]:
    """Return the occurrence status and strict publication decision."""

    if source_comparison is None:
        return "unvalidated_legacy", False
    if not source_comparison.chemistry_equivalent:
        return "rrseq_source_mismatch", False
    if not source_comparison.mapping_consistent:
        return "rrseq_source_mapping_mismatch", False
    if (
        representative_validation.status
        == CompositeValidationStatus.OUTCOME_LIMIT_REACHED
    ):
        return representative_validation.status.value, False
    if not representative_validation.certified:
        return representative_validation.status.value, False
    if not representative_validation.mapping_consistent:
        return "mapping_mismatch", False
    if (
        representative_validation.status
        == CompositeValidationStatus.VALIDATED_AMBIGUOUS
        and not allow_ambiguous
    ):
        return "validated_ambiguous_disallowed", False
    return representative_validation.status.value, True


def _failed_candidate_validation_record(
    candidate: CompositeCandidate,
) -> dict[str, Any]:
    application = candidate.application
    witness = candidate.witness
    return {
        "schema_version": 1,
        "occurrence_id": application.occurrence_id,
        "occurrence_schema_version": application.occurrence_schema_version,
        "route_id": application.route_id,
        "route_target_smiles": application.route_target_smiles,
        "target_smiles": application.target_smiles,
        "root_index": application.root_index,
        "branch_index": application.branch_index,
        "branch_indices": list(application.branch_indices),
        "reaction_node_paths": [list(path) for path in application.reaction_node_paths],
        "start_position": application.start_position,
        "end_position": application.end_position,
        "RRseq_cons": application.rrseq_cons,
        "RRseq_cons_size": application.rrseq_cons_size,
        "provenance_quality": application.provenance_quality,
        "source_identity": getattr(application, "source_identity", None),
        "source_tsv": str(application.source_tsv),
        "source_row": application.row_index,
        "source_occurrence_path": (
            str(application.source_occurrence_path)
            if application.source_occurrence_path
            else None
        ),
        "status": candidate.status,
        "accepted": False,
        "error": candidate.error,
        "expected_rrseq_leaves": (
            list(witness.rrseq_leaf_smiles) if witness is not None else []
        ),
        "source_route_leaves": (
            list(witness.source_route_leaf_smiles)
            if witness is not None
            else list(application.source_route_leaves)
        ),
        "source_comparison": (
            witness.source_comparison.to_dict()
            if witness is not None and witness.source_comparison is not None
            else None
        ),
        "matches": {
            "source_route": list(application.source_matches),
            "rrseq_replay": (
                list(witness.rrseq_step_traces) if witness is not None else []
            ),
            "composite_replay": [],
        },
    }


def collect_validated_composite_rules(
    rrseq_tsvs: list[Path],
    occurrence_paths: list[Path],
    extractor: CompositeRuleExtractor,
    *,
    limit_rows: int | None = None,
    limit_applications: int | None = None,
    ignore_errors: bool = False,
    progress_interval: int = 250,
    n_cpu: int = 1,
    extractor_args: RuleExtractionSettings | None = None,
    max_replay_outcomes: int = 256,
    allow_ambiguous: bool = True,
    application_timeout_seconds: float | None = 300.0,
) -> ValidatedCompositeCollection:
    """Extract, reapply, and certify every exact ordinary RRseq occurrence."""

    if max_replay_outcomes < 1:
        raise ValueError("--max-replay-outcomes must be at least 1")
    (
        applications,
        rrseq_rows_seen,
        input_occurrence_schema_versions,
        processed_occurrence_schema_versions,
    ) = select_occurrence_applications(
        rrseq_tsvs,
        occurrence_paths,
        limit_rows=limit_rows,
        limit_applications=limit_applications,
    )
    missing_schema_versions = [
        application.occurrence_id
        for application in applications
        if application.occurrence_schema_version is None
    ]
    if missing_schema_versions:
        raise ValueError(
            "exact RRseq_cons applications lack occurrence schema provenance: "
            + ", ".join(str(value) for value in missing_schema_versions[:10])
        )
    if application_timeout_seconds is not None and application_timeout_seconds <= 0:
        raise ValueError("--application-timeout-seconds must be greater than zero")
    stats = CompositeCollectionStats(
        rrseq_rows_seen=rrseq_rows_seen,
        applications_seen=len(applications),
        exact_occurrences_seen=len(applications),
    )
    n_cpu = normalize_n_cpu(n_cpu)
    if n_cpu > 1 and applications:
        if extractor_args is None:
            raise ValueError("extractor_args is required when n_cpu > 1")
        candidates = build_composite_candidates_parallel(
            applications,
            n_cpu=n_cpu,
            extractor_args=extractor_args,
            max_replay_outcomes=max_replay_outcomes,
            application_timeout_seconds=application_timeout_seconds,
        )
    else:
        candidates = [
            build_composite_candidate_with_timeout(
                application,
                extractor,
                max_replay_outcomes=max_replay_outcomes,
                application_timeout_seconds=application_timeout_seconds,
            )
            for application in applications
        ]

    errors: list[dict[str, Any]] = []
    validation_records: list[dict[str, Any]] = []
    successful_candidates: list[CompositeCandidate] = []
    for index, candidate in enumerate(candidates, start=1):
        if candidate.witness is not None:
            stats.pseudo_reactions_built += 1
            source_comparison = candidate.witness.source_comparison
            if (
                source_comparison is not None
                and source_comparison.chemistry_equivalent
                and source_comparison.mapping_consistent
            ):
                stats.rrseq_source_matches += 1
            elif (
                source_comparison is not None and source_comparison.chemistry_equivalent
            ):
                stats.rrseq_source_mapping_mismatches += 1
            else:
                stats.rrseq_source_mismatches += 1
        if candidate.rule_smarts is not None:
            stats.composite_rules_extracted += 1
            successful_candidates.append(candidate)
        elif candidate.status == "skipped_rule_extraction":
            stats.skipped_rule_extractions += 1
            stats.validation_rejected += 1
            validation_records.append(_failed_candidate_validation_record(candidate))
        elif candidate.status == "skipped_rule_extraction_error":
            stats.skipped_rule_extraction_errors += 1
            stats.validation_rejected += 1
            validation_records.append(_failed_candidate_validation_record(candidate))
        elif candidate.status == "skipped_unwrap":
            stats.skipped_unwrap_applications += 1
            stats.validation_rejected += 1
            if candidate.error:
                errors.append(candidate.error)
            validation_records.append(_failed_candidate_validation_record(candidate))
        elif candidate.status == "rrseq_outcome_limit_reached":
            stats.skipped_unwrap_applications += 1
            stats.validation_inconclusive += 1
            validation_records.append(_failed_candidate_validation_record(candidate))
        elif candidate.status == "application_timeout":
            stats.application_timeouts += 1
            stats.skipped_unwrap_applications += 1
            stats.validation_inconclusive += 1
            if candidate.error:
                errors.append(candidate.error)
            validation_records.append(_failed_candidate_validation_record(candidate))
        else:
            stats.errors += 1
            stats.validation_rejected += 1
            if candidate.error:
                errors.append(candidate.error)
            validation_records.append(_failed_candidate_validation_record(candidate))
            if not ignore_errors:
                error = candidate.error or {}
                raise RuntimeError(
                    "composite rule extraction failed for occurrence "
                    f"{candidate.application.occurrence_id}: "
                    f"{error.get('error_type', 'Error')}: "
                    f"{error.get('message', '')}"
                )
        if progress_interval and index % progress_interval == 0:
            print(
                f"processed occurrences={index} "
                f"candidate_rules={len(successful_candidates)} "
                f"timeouts={stats.application_timeouts} errors={stats.errors}",
                flush=True,
            )

    aggregates: dict[str, CompositeRuleAggregate] = {}
    certified_aggregates: dict[str, CompositeRuleAggregate] = {}
    pseudo_reactions: list[PseudoReactionRecord] = []
    for group in _group_composite_candidates(successful_candidates):
        members: list[CompositeCandidate] = sorted(
            group["candidates"],
            key=lambda candidate: candidate.application.occurrence_id or "",
        )
        representative_rule = min(candidate.rule_smarts or "" for candidate in members)
        aggregate_key = _unique_composite_key(
            representative_rule,
            aggregates,
        )
        aggregate = CompositeRuleAggregate(
            rule_smarts=representative_rule,
            cgr_key=aggregate_key,
            query_cgr=group["query_cgr"],
        )
        aggregates[aggregate_key] = aggregate

        certified_aggregate: CompositeRuleAggregate | None = None
        for candidate in members:
            application = candidate.application
            witness = candidate.witness
            if witness is None:
                continue
            # Groups are deliberately byte-identical SMARTS groups, so the rule
            # validated while building this candidate is the representative rule.
            # Reusing that result avoids an identical second graph-replay pass for
            # every occurrence.
            representative_validation = candidate.candidate_validation
            if representative_validation is None:
                representative_validation = validate_abstract_composite_rule(
                    witness.target_smiles,
                    representative_rule,
                    witness.source_route_leaf_smiles or witness.rrseq_leaf_smiles,
                    max_outcomes=max_replay_outcomes,
                )
            status, accepted = _validation_status(
                witness.source_comparison,
                representative_validation,
                allow_ambiguous=allow_ambiguous,
            )
            if accepted:
                if (
                    representative_validation.status
                    == CompositeValidationStatus.VALIDATED_UNIQUE
                ):
                    stats.validated_unique += 1
                else:
                    stats.validated_ambiguous += 1
            elif status == CompositeValidationStatus.OUTCOME_LIMIT_REACHED.value:
                stats.validation_inconclusive += 1
            else:
                stats.validation_rejected += 1

            pseudo_reaction_id = f"p{len(pseudo_reactions)}"
            pseudo_reactions.append(
                PseudoReactionRecord(
                    pseudo_reaction_id=pseudo_reaction_id,
                    composite_cgr=aggregate_key,
                    reaction_smiles=witness.pseudo_reaction_smiles,
                    source_tsv=str(application.source_tsv),
                    source_row=application.row_index,
                    route_ids=application.route_ids,
                    target_smiles=application.target_smiles,
                    rrseq_size=application.rrseq_cons_size,
                    rrseq=application.rrseq_cons,
                    occurrence_id=application.occurrence_id,
                    validation_status=status,
                )
            )
            _update_occurrence_aggregate(
                aggregate,
                candidate,
                pseudo_reaction_id=pseudo_reaction_id,
                validation_status=status,
                accepted=accepted,
            )
            if accepted:
                if certified_aggregate is None:
                    certified_aggregate = CompositeRuleAggregate(
                        rule_smarts=representative_rule,
                        cgr_key=aggregate_key,
                        query_cgr=group["query_cgr"],
                    )
                    certified_aggregates[aggregate_key] = certified_aggregate
                _update_occurrence_aggregate(
                    certified_aggregate,
                    candidate,
                    pseudo_reaction_id=pseudo_reaction_id,
                    validation_status=status,
                    accepted=True,
                )

            validation_records.append(
                {
                    "schema_version": 1,
                    "occurrence_id": application.occurrence_id,
                    "occurrence_schema_version": (
                        application.occurrence_schema_version
                    ),
                    "route_id": application.route_id,
                    "source_identity": getattr(
                        application,
                        "source_identity",
                        None,
                    ),
                    "route_target_smiles": application.route_target_smiles,
                    "target_smiles": application.target_smiles,
                    "root_index": application.root_index,
                    "branch_index": application.branch_index,
                    "branch_indices": list(application.branch_indices),
                    "reaction_node_paths": [
                        list(path) for path in application.reaction_node_paths
                    ],
                    "start_position": application.start_position,
                    "end_position": application.end_position,
                    "RRseq_cons": application.rrseq_cons,
                    "RRseq_cons_size": application.rrseq_cons_size,
                    "source_tsv": str(application.source_tsv),
                    "source_row": application.row_index,
                    "source_occurrence_path": (
                        str(application.source_occurrence_path)
                        if application.source_occurrence_path
                        else None
                    ),
                    "provenance_quality": application.provenance_quality,
                    "pseudo_reaction_id": pseudo_reaction_id,
                    "composite_aggregate_key": aggregate_key,
                    "candidate_rule": candidate.rule_smarts,
                    "representative_rule": representative_rule,
                    "status": status,
                    "accepted": accepted,
                    "expected_rrseq_leaves": list(witness.rrseq_leaf_smiles),
                    "source_route_leaves": list(witness.source_route_leaf_smiles),
                    "composite_expected_leaves": list(
                        witness.source_route_leaf_smiles or witness.rrseq_leaf_smiles
                    ),
                    "source_comparison": (
                        witness.source_comparison.to_dict()
                        if witness.source_comparison is not None
                        else None
                    ),
                    "candidate_validation": (
                        candidate.candidate_validation.to_dict()
                        if candidate.candidate_validation is not None
                        else None
                    ),
                    "representative_validation": (representative_validation.to_dict()),
                    "matches": {
                        "source_route": list(application.source_matches),
                        "rrseq_replay": list(witness.rrseq_step_traces),
                        "composite_replay": [
                            outcome.to_dict()
                            for outcome in representative_validation.outcomes
                        ],
                    },
                }
            )

    validation_records.sort(
        key=lambda record: (
            str(record.get("occurrence_id") or ""),
            str(record.get("status") or ""),
        )
    )
    classified = (
        stats.validated_unique
        + stats.validated_ambiguous
        + stats.validation_rejected
        + stats.validation_inconclusive
    )
    if classified != stats.applications_seen:
        raise RuntimeError(
            "validation accounting invariant failed: "
            f"applications={stats.applications_seen}, classified={classified}"
        )
    return ValidatedCompositeCollection(
        aggregates=aggregates,
        certified_aggregates=certified_aggregates,
        pseudo_reactions=pseudo_reactions,
        stats=stats,
        errors=errors,
        validation_records=validation_records,
        occurrence_paths=occurrence_paths,
        input_occurrence_schema_versions=input_occurrence_schema_versions,
        processed_occurrence_schema_versions=processed_occurrence_schema_versions,
    )


class GappedCompositeConstructionError(ValueError):
    """Raised when a selected RouteCGR violates a construction invariant."""


class NoNetSelectedChange(GappedCompositeConstructionError):
    """Raised for a valid history whose selected reactions have no net effect."""


class SkippedConnectorOverlap(GappedCompositeConstructionError):
    """Raised when a skipped reaction changes a selected-history connector map."""


def validate_gapped_occurrence_integrity(occurrence: dict[str, Any]) -> None:
    """Reject legacy or malformed sidecars before composing gapped reactions."""

    required_fields = ("connector_maps", "skipped_center_maps")
    missing = [field for field in required_fields if field not in occurrence]
    if missing:
        raise GappedCompositeConstructionError(
            "occurrence lacks required gapped provenance: " + ", ".join(missing)
        )
    try:
        connector_maps = {int(atom_map) for atom_map in occurrence["connector_maps"]}
        skipped_center_maps = {
            int(atom_map) for atom_map in occurrence["skipped_center_maps"]
        }
    except (TypeError, ValueError) as exc:
        raise GappedCompositeConstructionError(
            "occurrence has non-integer connector provenance"
        ) from exc
    overlap = connector_maps & skipped_center_maps
    if overlap:
        raise SkippedConnectorOverlap(
            "skipped reaction changes selected-history connector maps: "
            + ",".join(str(atom_map) for atom_map in sorted(overlap))
        )


@dataclass(frozen=True)
class GappedCompositeRuleResult:
    rule_smarts: str
    cgr_key: str
    contributing_step_numbers: tuple[int, ...]
    contributing_positions: tuple[int, ...]
    net_center_maps: tuple[int, ...]
    lhs_target_maps: tuple[int, ...]


class GappedCompositeRuleExtractor:
    """Build one target-relevant, analysis-only rule from selected reactions."""

    def __init__(self, config: Any):
        self.config = self._analysis_config(config)

    @staticmethod
    def _config_with(config: Any, **updates: Any) -> Any:
        if hasattr(config, "model_copy"):
            return config.model_copy(update=updates)
        if hasattr(config, "copy"):
            return config.copy(update=updates)
        values = dict(getattr(config, "__dict__", {}))
        values.update(updates)
        return type(config)(**values)

    @classmethod
    def _analysis_config(cls, config: Any) -> Any:
        # The history/provenance algorithm decides which centers belong together.
        # Leaving/incoming expansion is disabled so dropping non-LHS pseudo-products
        # cannot reintroduce skipped-state atoms. Radius-two context supplies the
        # chemically useful environment around every selected net center.
        return cls._config_with(
            config,
            environment_atom_count=2,
            multicenter_rules=True,
            reverse_rule=True,
            single_product_only=True,
            keep_leaving_groups=False,
            keep_incoming_groups=False,
            keep_reagents=False,
            reactor_validation=False,
            atom_info_retention={
                "reaction_center": {
                    "neighbors": False,
                    "implicit_hydrogens": False,
                    "ring_sizes": False,
                },
                "environment": {
                    "neighbors": False,
                    "implicit_hydrogens": False,
                    "ring_sizes": False,
                },
            },
        )

    @classmethod
    def from_args(cls, args: RuleExtractionSettings) -> "GappedCompositeRuleExtractor":
        from synplan.utils.config import RuleExtractionConfig

        config_path = getattr(args, "config", None)
        if config_path is not None:
            config = RuleExtractionConfig.from_yaml(
                str(resolve_existing_path(Path(config_path)))
            )
            return cls(config)

        default_config = resources.files("route_inspector").joinpath(
            "configs", "rule_extraction_functional_groups.yaml"
        )
        with resources.as_file(default_config) as resolved_config:
            return cls(RuleExtractionConfig.from_yaml(str(resolved_config)))

    @classmethod
    def default(cls) -> "GappedCompositeRuleExtractor":
        return cls.from_args(RuleExtractionSettings(config=None, include_rings=False))

    def extract(self, occurrence: dict[str, Any]) -> GappedCompositeRuleResult:
        return build_gapped_composite_rule_result(occurrence, self.config)


def _gapped_occurrence_paths(paths: Iterable[Path]) -> list[Path]:
    resolved: list[Path] = []
    seen: set[Path] = set()
    for raw_path in paths:
        path = resolve_existing_path(raw_path)
        candidates = (
            sorted(
                {
                    *path.glob("*_rrseq_gap_occurrences.json"),
                    *path.glob("*_separated_rrseq_occurrences.json"),
                }
            )
            if path.is_dir()
            else [path]
        )
        if not candidates:
            raise ValueError(f"{path} contains no RRseq_gap occurrence sidecars")
        for candidate in candidates:
            if not candidate.name.endswith(
                ("_rrseq_gap_occurrences.json", "_separated_rrseq_occurrences.json")
            ):
                raise ValueError(f"{candidate} is not an RRseq_gap occurrence sidecar")
            key = candidate.resolve()
            if key not in seen:
                seen.add(key)
                resolved.append(candidate)
    return resolved


def _valid_single_lhs_smarts(rule_smarts: str) -> bool:
    if rule_smarts.count(">>") != 1:
        return False
    lhs, _rhs = rule_smarts.split(">>", 1)
    if not lhs or "." in lhs:
        return False
    try:
        from chython import smarts

        smarts(rule_smarts)
    except Exception:
        return False
    return True


def _connected_product_center_context(
    product: Any,
    center_atoms: set[int],
) -> set[int]:
    """Add the minimum product paths needed to keep one LHS query object."""

    if len(center_atoms) < 2:
        return set(center_atoms)
    adjacency: dict[int, set[int]] = {int(atom): set() for atom in product}
    for atom_1, atom_2, _bond in product.bonds():
        adjacency[int(atom_1)].add(int(atom_2))
        adjacency[int(atom_2)].add(int(atom_1))

    ordered = sorted(center_atoms)
    connected = {ordered[0]}
    for target in ordered[1:]:
        if target in connected:
            continue
        queue = [target]

        parent: dict[int, int | None] = {target: None}
        meeting: int | None = None
        for atom in queue:
            if atom in connected:
                meeting = atom
                break
            for neighbor in sorted(adjacency.get(atom, ())):
                if neighbor not in parent:
                    parent[neighbor] = atom
                    queue.append(neighbor)
        if meeting is None:
            continue
        atom: int | None = meeting
        while atom is not None:
            connected.add(atom)
            atom = parent[atom]
    return connected


def _selected_reaction_smiles(occurrence: dict[str, Any]) -> tuple[str, ...]:
    selected_steps = occurrence.get("selected_steps") or []
    if not selected_steps:
        raise GappedCompositeConstructionError("occurrence has no selected steps")
    values = tuple(str(step.get("reaction_smiles", "")) for step in selected_steps)
    if any(not value for value in values):
        raise GappedCompositeConstructionError(
            "selected step has no normalized reaction_smiles"
        )
    return values


def _selected_step_center_maps(step: dict[str, Any]) -> frozenset[int]:
    """Read serialized centers, deriving them only for compact test occurrences."""

    serialized = step.get("center_atoms", ())
    if serialized:
        return frozenset(int(atom_map) for atom_map in serialized)
    reaction_smiles = str(step.get("reaction_smiles", ""))
    if not reaction_smiles:
        return frozenset()
    from chython import smiles

    return frozenset(
        int(atom_map) for atom_map in (~smiles(reaction_smiles)).center_atoms
    )


def _selected_step_reactant_projections(
    step: dict[str, Any],
) -> list[tuple[Any, frozenset[int]]]:
    """Return center-bearing reactant components for one selected route step."""

    projections = step.get("reactant_center_molecules") or []
    if projections:
        return [
            (
                chemistry.parse_molecule(str(molecule_smiles)).copy(),
                frozenset(int(atom_map) for atom_map in center_maps),
            )
            for molecule_smiles, center_maps in projections
        ]

    from chython import smiles

    reaction_smiles = str(step.get("reaction_smiles", ""))
    if not reaction_smiles:
        raise GappedCompositeConstructionError(
            "selected step has no normalized reaction_smiles"
        )
    reaction = smiles(reaction_smiles)
    center_maps = _selected_step_center_maps(step)
    return [
        (
            molecule.copy(),
            frozenset(int(atom_map) for atom_map in molecule) & center_maps,
        )
        for molecule in reaction.reactants
        if set(molecule) & center_maps
    ]


def _splice_selected_step_reaction(
    occurrence: dict[str, Any],
) -> tuple[Any, frozenset[int], frozenset[int]]:
    """Compose selected route changes without treating skipped steps as reactions.

    Each newly selected step replaces only the prior frontier component that carries
    its shared history maps. This retains selected transformations while avoiding the
    false consecutive-state assumption made by ``compose_route_cgr``.
    """

    from chython.containers import ReactionContainer

    target_smiles = str(occurrence.get("target_molecule", ""))
    if not target_smiles:
        raise GappedCompositeConstructionError("occurrence has no target molecule")
    selected_steps = occurrence.get("selected_steps") or []
    if len(selected_steps) < 2:
        raise GappedCompositeConstructionError(
            "a gapped composite requires at least two selected steps"
        )

    frontier: list[tuple[Any, frozenset[int]]] = []
    history_maps: set[int] = set()
    selected_center_maps: set[int] = set()
    for index, step in enumerate(selected_steps):
        step_center_maps = _selected_step_center_maps(step)
        if not step_center_maps:
            raise GappedCompositeConstructionError(
                "selected step has no mapped reaction-center atoms"
            )
        if index:
            connector_maps = history_maps & step_center_maps
            if not connector_maps:
                raise GappedCompositeConstructionError(
                    "selected steps are not connected through mapped center history"
                )
            frontier = [
                (molecule, component_maps)
                for molecule, component_maps in frontier
                if not (component_maps & connector_maps)
            ]
        frontier.extend(_selected_step_reactant_projections(step))
        history_maps.update(step_center_maps)
        selected_center_maps.update(step_center_maps)

    if not frontier:
        raise NoNetSelectedChange("selected steps leave no center-bearing reactants")
    product_projections = selected_steps[0].get("product_center_molecules") or []
    if product_projections:
        target_smiles, _target_center_maps = max(
            product_projections,
            key=lambda projection: (
                len(
                    set(chemistry.parse_molecule(str(projection[0])))
                    & selected_center_maps
                ),
                len(projection[1]),
                str(projection[0]),
            ),
        )
    target = chemistry.parse_molecule(str(target_smiles)).copy()
    return (
        ReactionContainer(
            reactants=tuple(molecule for molecule, _maps in frontier),
            products=(target,),
            reagents=(),
        ),
        frozenset(selected_center_maps),
        frozenset(int(atom_map) for atom_map in target),
    )


def build_gapped_composite_rule_result(
    occurrence: dict[str, Any],
    config: Any,
) -> GappedCompositeRuleResult:
    """Build one selected-history SMARTS by splicing selected route steps."""

    from synplan.chem.reaction.rules.extraction import (
        _rule_to_reactor_smarts,
        create_rule,
    )

    reaction, selected_center_maps, target_maps = _splice_selected_step_reaction(
        occurrence
    )
    lhs_centers = selected_center_maps & target_maps
    if not lhs_centers:
        raise GappedCompositeConstructionError(
            "selected history has no mapped centers on its target molecule"
        )
    target = reaction.products[0]
    product_context = _connected_product_center_context(target, set(lhs_centers))
    # A selected history can also contain changes on a fragment that is no longer
    # connected to the root target. Including those centers makes SynPlanner emit
    # a second LHS query object, which is not a target-relevant reaction SMARTS.
    # Prefer the full history, then project it onto the root target if needed.
    candidate_atom_sets = (
        set(selected_center_maps) | product_context,
        set(lhs_centers) | product_context,
    )
    rule_smarts: str | None = None
    empty_template_error: ValueError | None = None
    for rule_atoms in candidate_atom_sets:
        try:
            candidate_smarts = _rule_to_reactor_smarts(
                create_rule(
                    config,
                    reaction,
                    _restrict_center_atoms=rule_atoms,
                    _skip_full_reaction_validation=True,
                )
            )
        except ValueError as exc:
            if "empty template" in str(exc):
                empty_template_error = exc
                continue
            raise
        if _valid_single_lhs_smarts(candidate_smarts):
            rule_smarts = candidate_smarts
            break
    if rule_smarts is None:
        if empty_template_error is not None:
            raise NoNetSelectedChange(
                "selected reactions have no attributable net change"
            ) from empty_template_error
        raise GappedCompositeConstructionError(
            "selected-history splice did not produce a valid single-LHS SMARTS"
        )

    selected_positions = tuple(
        int(position) for position in occurrence.get("selected_positions", ())
    )
    return GappedCompositeRuleResult(
        rule_smarts=rule_smarts,
        cgr_key=rule_cgr_key(rule_smarts),
        contributing_step_numbers=tuple(range(1, len(selected_positions) + 1)),
        contributing_positions=selected_positions,
        net_center_maps=tuple(sorted(selected_center_maps)),
        lhs_target_maps=tuple(sorted(lhs_centers)),
    )


def build_gapped_composite_rule(occurrence: dict[str, Any]) -> tuple[str, str]:
    """Compatibility helper returning SMARTS and QueryCGR identity."""

    result = GappedCompositeRuleExtractor.default().extract(occurrence)
    return result.rule_smarts, result.cgr_key


@dataclass
class GappedCompositeOccurrenceAggregate:
    rule_smarts: str
    cgr_key: str
    query_cgr: Any | None = None
    route_ids: set[str] = field(default_factory=set)
    qualified_route_ids: set[tuple[str, str]] = field(default_factory=set)
    target_molecules: set[str] = field(default_factory=set)
    rrseqs: set[str] = field(default_factory=set)
    selected_positions: set[str] = field(default_factory=set)
    skipped_positions: set[str] = field(default_factory=set)
    contributing_positions: set[str] = field(default_factory=set)
    net_center_maps: set[str] = field(default_factory=set)
    occurrence_ids: set[str] = field(default_factory=set)


def _gapped_extractor_args_dict(args: RuleExtractionSettings) -> dict[str, Any]:
    return {
        "config": str(args.config) if getattr(args, "config", None) else None,
        "include_rings": bool(getattr(args, "include_rings", False)),
    }


def _init_gapped_composite_worker(extractor_args: dict[str, Any]) -> None:
    global _GAPPED_COMPOSITE_WORKER_EXTRACTOR
    setup_runtime_cache_dirs()
    _GAPPED_COMPOSITE_WORKER_EXTRACTOR = GappedCompositeRuleExtractor.from_args(
        RuleExtractionSettings(**extractor_args)
    )


def _gapped_occurrence_worker(occurrence: dict[str, Any]) -> dict[str, Any]:
    try:
        if _GAPPED_COMPOSITE_WORKER_EXTRACTOR is None:
            raise RuntimeError("gapped composite worker was not initialized")
        validate_gapped_occurrence_integrity(occurrence)
        result = _GAPPED_COMPOSITE_WORKER_EXTRACTOR.extract(occurrence)
        return {"status": "ok", "occurrence": occurrence, "result": result}
    except NoNetSelectedChange:
        return {"status": "no_net_selected_change", "occurrence": occurrence}
    except Exception as exc:
        return {
            "status": "error",
            "occurrence": occurrence,
            "error_type": type(exc).__qualname__,
            "message": str(exc) or traceback.format_exc(limit=1).strip(),
        }


def _read_gapped_occurrences(
    sidecars: list[Path],
    limit_occurrences: int | None,
) -> list[dict[str, Any]]:
    selected, _source_paths = gapped_classification.load_gapped_occurrences(sidecars)
    return selected[:limit_occurrences] if limit_occurrences is not None else selected


def collect_gapped_composite_rules_from_occurrences(
    sidecars: list[Path],
    *,
    limit_occurrences: int | None = None,
    extractor: GappedCompositeRuleExtractor | None = None,
    n_cpu: int = 1,
    extractor_args: RuleExtractionSettings | None = None,
    context_radius: int = 2,
    max_replay_outcomes: int = 256,
    require_unique_replay: bool = False,
    detect_complementary: bool = False,
    protection_index: Any = None,
    classification_sink: list[dict[str, Any]] | None = None,
) -> tuple[
    dict[str, GappedCompositeOccurrenceAggregate],
    list[dict[str, str]],
    int,
    int,
]:
    """Collect RouteCGR-derived gapped rules and unexpected diagnostics."""

    occurrences = _read_gapped_occurrences(sidecars, limit_occurrences)
    classified_records: list[dict[str, Any]] = []
    factorable_occurrences: list[dict[str, Any]] = []
    for occurrence in occurrences:
        classification = gapped_classification.classify_gapped_occurrence(
            occurrence,
            context_radius=context_radius,
            max_replay_outcomes=max_replay_outcomes,
            protection_index=protection_index,
            require_unique_replay=require_unique_replay,
            detect_complementary=detect_complementary,
        )
        record = {**occurrence, **classification.to_dict()}
        classified_records.append(record)
        if classification.classification == "factorable":
            factorable_occurrences.append(occurrence)
    if classification_sink is not None:
        classification_sink.extend(classified_records)

    workers = normalize_n_cpu(n_cpu)
    if workers > 1:
        if extractor_args is None:
            extractor_args = RuleExtractionSettings(config=None, include_rings=False)
        with ProcessPoolExecutor(
            max_workers=workers,
            initializer=_init_gapped_composite_worker,
            initargs=(_gapped_extractor_args_dict(extractor_args),),
        ) as executor:
            results = list(
                executor.map(
                    _gapped_occurrence_worker,
                    factorable_occurrences,
                    chunksize=8,
                )
            )
    else:
        active_extractor = extractor or GappedCompositeRuleExtractor.default()
        results = []
        for occurrence in factorable_occurrences:
            try:
                validate_gapped_occurrence_integrity(occurrence)
                result = active_extractor.extract(occurrence)
                results.append(
                    {"status": "ok", "occurrence": occurrence, "result": result}
                )
            except NoNetSelectedChange:
                results.append(
                    {"status": "no_net_selected_change", "occurrence": occurrence}
                )
            except Exception as exc:
                results.append(
                    {
                        "status": "error",
                        "occurrence": occurrence,
                        "error_type": type(exc).__qualname__,
                        "message": str(exc) or traceback.format_exc(limit=1).strip(),
                    }
                )

    aggregates: dict[str, GappedCompositeOccurrenceAggregate] = {}
    aggregate_buckets: dict[
        tuple[Any, ...], list[GappedCompositeOccurrenceAggregate]
    ] = defaultdict(list)
    errors: list[dict[str, str]] = []
    no_net_selected_change = sum(
        not bool(record.get("has_persistent_net_change"))
        for record in classified_records
    )
    for item in results:
        occurrence = item["occurrence"]
        if item["status"] == "no_net_selected_change":
            no_net_selected_change += 1
            continue
        if item["status"] == "error":
            errors.append(
                {
                    "occurrence_id": str(occurrence.get("occurrence_id", "")),
                    "route_id": str(occurrence.get("route_id", "")),
                    "RRseq_gap": str(
                        occurrence.get("RRseq_gap", occurrence.get("RRseq", ""))
                    ),
                    "stage": "construct_route_cgr_template",
                    "error_type": str(item["error_type"]),
                    "message": str(item["message"]),
                }
            )
            continue

        result: GappedCompositeRuleResult = item["result"]
        query_cgr = rule_query_cgr(result.rule_smarts)
        signature = query_cgr_coarse_signature(query_cgr)
        aggregate = next(
            (
                candidate
                for candidate in aggregate_buckets.get(signature, ())
                if candidate.query_cgr is not None
                and query_cgr_isomorphic(candidate.query_cgr, query_cgr)
            ),
            None,
        )
        if aggregate is None:
            aggregate = GappedCompositeOccurrenceAggregate(
                result.rule_smarts,
                result.cgr_key,
                query_cgr,
            )
            internal_key = result.cgr_key
            collision_index = 1
            while internal_key in aggregates:
                collision_index += 1
                internal_key = f"{result.cgr_key}#{collision_index}"
            aggregates[internal_key] = aggregate
            aggregate_buckets[signature].append(aggregate)
        aggregate.route_ids.add(str(occurrence.get("route_id", "")))
        aggregate.qualified_route_ids.add(
            (
                str(occurrence.get("source_identity", "")),
                str(occurrence.get("route_id", "")),
            )
        )
        aggregate.target_molecules.add(str(occurrence.get("target_molecule", "")))
        aggregate.rrseqs.add(
            str(occurrence.get("RRseq_gap", occurrence.get("RRseq", "")))
        )
        aggregate.selected_positions.add(
            ",".join(
                str(position) for position in occurrence.get("selected_positions", [])
            )
        )
        aggregate.skipped_positions.add(
            ",".join(
                str(position) for position in occurrence.get("skipped_positions", [])
            )
        )
        aggregate.contributing_positions.add(
            ",".join(str(position) for position in result.contributing_positions)
        )
        aggregate.net_center_maps.add(
            ",".join(str(atom_map) for atom_map in result.net_center_maps)
        )
        aggregate.occurrence_ids.add(str(occurrence.get("occurrence_id", "")))
    return aggregates, errors, len(occurrences), no_net_selected_change


def gapped_composite_occurrence_output_paths(
    output: Path, sidecars: list[Path], summary: Path | None = None
) -> tuple[Path, Path, Path]:
    if output.suffix:
        rules_path = output
    else:
        stems = [
            path.name.removesuffix("_rrseq_gap_occurrences.json").removesuffix(
                "_separated_rrseq_occurrences.json"
            )
            for path in sidecars
        ]
        prefix = stems[0] if len(set(stems)) == 1 else "merged"
        rules_path = output / f"{prefix}_gapped_composite_rules.tsv"
    return (
        rules_path,
        rules_path.parent / "summary.json",
        rules_path.with_name(f"{rules_path.stem}_collection_errors.tsv"),
    )


def write_selected_center_gapped_composite_rules(
    output: Path, aggregates: dict[str, GappedCompositeOccurrenceAggregate]
) -> dict[str, int]:
    rows = []
    for aggregate in sorted(
        aggregates.values(), key=lambda item: (-len(item.route_ids), item.rule_smarts)
    ):
        rrseq_sizes = sorted(
            {len(split_rrseq(rrseq)) for rrseq in aggregate.rrseqs if rrseq}
        )
        rrseq_provenance = "||".join(sorted(aggregate.rrseqs))
        rows.append(
            {
                "Gapped_composite_rule": aggregate.rule_smarts,
                "popularity": len(
                    aggregate.qualified_route_ids
                    or {("", route_id) for route_id in aggregate.route_ids}
                ),
                "Reference": ",".join(
                    sorted(route_id for route_id in aggregate.route_ids if route_id)
                ),
                "Qualified_references_json": json.dumps(
                    sorted(aggregate.qualified_route_ids),
                    separators=(",", ":"),
                ),
                "RRseq_gap": rrseq_provenance,
                "RRseq_gap_sizes": ",".join(str(size) for size in rrseq_sizes),
                "Target_molecules": ",".join(
                    sorted(target for target in aggregate.target_molecules if target)
                ),
                "Source_occurrence_ids": ";".join(
                    sorted(
                        occurrence_id
                        for occurrence_id in aggregate.occurrence_ids
                        if occurrence_id
                    )
                ),
                "Selected_positions": ";".join(sorted(aggregate.selected_positions)),
                "Skipped_positions": ";".join(sorted(aggregate.skipped_positions)),
                "Contributing_positions": ";".join(
                    sorted(aggregate.contributing_positions)
                ),
                "Net_center_maps": ";".join(sorted(aggregate.net_center_maps)),
                "analysis_only": "true",
                "source_rrseq_type": "gapped",
                "factorability": "factorable",
            }
        )
    write_tsv(
        output,
        [
            "Gapped_composite_rule",
            "popularity",
            "Reference",
            "RRseq_gap",
            "RRseq_gap_sizes",
            "Qualified_references_json",
            "Target_molecules",
            "Source_occurrence_ids",
            "Selected_positions",
            "Skipped_positions",
            "Contributing_positions",
            "Net_center_maps",
            "analysis_only",
            "source_rrseq_type",
            "factorability",
        ],
        rows,
    )
    return {"gapped_composite_rules": len(aggregates)}
