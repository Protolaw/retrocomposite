"""Disposable disk-backed evidence for complete single-step overlap scans."""

import json
from collections import Counter

from route_inspector.composite_rules.library import CompositeDecompositionLink
from route_inspector.rules.graph import canonical_json
from route_inspector.rules.transformation import _equivalent_candidates, _signature


class DiskVocabulary:
    """Same encounter-order families and exact comparisons as RuleFamilyIndex."""

    def __init__(self, db, evidence=None):
        self.db = db
        self.evidence = evidence
        self.metrics = Counter()
        self.representations = 0
        db.executescript("""
            CREATE TEMP TABLE overlap_representations(encoding TEXT PRIMARY KEY,family INTEGER);
            CREATE TEMP TABLE overlap_families(signature TEXT,family INTEGER PRIMARY KEY,encoding TEXT);
            CREATE INDEX temp.overlap_family_bucket ON overlap_families(signature,family);
            CREATE TEMP TABLE overlap_composites(composite_id TEXT,family INTEGER,PRIMARY KEY(composite_id,family));
        """)

    def rule(self, graph):
        encoded = canonical_json(graph)
        row = self.db.execute(
            "SELECT family FROM overlap_representations WHERE encoding=?", (encoded,)
        ).fetchone()
        if row is not None:
            self.metrics["fast_hits"] += 1
            return row[0]
        # Avoid the process-wide string LRU: graphs are retained on disk here.
        signature = _signature.__wrapped__(encoded)
        self.metrics["representations"] += 1
        family = None
        bucket_size = 0
        for candidate, other in self.db.execute(
            "SELECT family,encoding FROM overlap_families WHERE signature=? ORDER BY family",
            (signature,),
        ):
            bucket_size += 1
            self.metrics["candidate_comparisons"] += 1
            equivalent = (
                self.evidence.equivalent
                if self.evidence is not None
                else _equivalent_candidates
            )
            if equivalent(graph, json.loads(other)):
                family = candidate
                break
        if family is None:
            family = self.representations + 1
            self.db.execute(
                "INSERT INTO overlap_families VALUES(?,?,?)",
                (signature, family, encoded),
            )
            self.metrics["families"] += 1
            self.metrics["largest_bucket"] = max(
                self.metrics["largest_bucket"], bucket_size + 1
            )
        self.db.execute(
            "INSERT INTO overlap_representations VALUES(?,?)", (encoded, family)
        )
        self.representations += 1
        return family

    def add_composite(self, composite_id, family):
        self.db.execute(
            "INSERT OR IGNORE INTO overlap_composites VALUES(?,?)",
            (composite_id, family),
        )

    def write_matches(self):
        self.db.execute(
            "INSERT OR IGNORE INTO matches SELECT c.composite_id,r.id "
            "FROM overlap_composites c JOIN rules r ON r.id=c.family"
        )


class DiskSources:
    """All certified sources, streamed one link at a time in the original order."""

    def __init__(self, db, composites):
        self.db = db
        db.executescript("""
            CREATE TEMP TABLE overlap_sources(route_id TEXT,composite_id TEXT,link_id TEXT,mapped_rule TEXT,payload TEXT);
            CREATE INDEX temp.overlap_source_route ON overlap_sources(route_id,composite_id,link_id);
            CREATE TEMP TABLE overlap_missing(composite_id TEXT,mapped_rule TEXT,PRIMARY KEY(composite_id,mapped_rule));
        """)
        if composites._connection is not None:
            links = (
                CompositeDecompositionLink.from_dict(json.loads(row[0]))
                for row in composites._connection.execute(
                    "SELECT link_json FROM links ORDER BY composite_id,link_id"
                )
            )
        else:
            links = iter(composites._links or ())
        for link in links:
            rule = composites.certified_rule(link)
            db.execute(
                "INSERT INTO overlap_sources VALUES(?,?,?,?,?)",
                (
                    str(link.route_id),
                    link.composite_id,
                    link.link_id,
                    rule,
                    canonical_json(link.to_dict()),
                ),
            )
            db.execute(
                "INSERT OR IGNORE INTO overlap_missing VALUES(?,?)",
                (link.composite_id, rule),
            )

    def get(self, route_id, default=()):
        for cid, rule, payload in self.db.execute(
            "SELECT composite_id,mapped_rule,payload FROM overlap_sources "
            "WHERE route_id=? ORDER BY composite_id,link_id",
            (route_id,),
        ):
            yield (cid, rule), CompositeDecompositionLink.from_dict(json.loads(payload))

    def reconstructed(self, variant):
        return bool(
            self.db.execute(
                "DELETE FROM overlap_missing WHERE composite_id=? AND mapped_rule=?",
                variant,
            ).rowcount
        )

    def missing_count(self):
        return self.db.execute("SELECT COUNT(*) FROM overlap_missing").fetchone()[0]
