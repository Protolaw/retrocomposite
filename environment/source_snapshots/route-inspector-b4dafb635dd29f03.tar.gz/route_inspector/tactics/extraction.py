"""One-pass per-route extraction of RRSeqs and RRSubtree motifs.

The combined API shares only mechanical route preparation. RRSeq extraction is
still delegated to the established consecutive and gapped implementations.
RRSubtree occurrences retain their own topology and gap policies. Executability
of a consecutive RRSubtree composite requires its occurrence-level certificate;
gapped tactics remain analysis-only.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from route_inspector.datasets.paroutes.source_ids import PAROUTES_SOURCE_ID_ADAPTER
from route_inspector.metrics.retro_bleu.bigrams import (
    RetroBleuBigramOccurrence,
    extract_prepared_retro_bleu_bigrams,
)
from route_inspector.rules.models import PreparedRouteRuleData, RouteProcessingStats
from route_inspector.rules.preparation import (
    prepare_root_reaction_paths,
    prepare_route_rule_data,
)
from route_inspector.tactics.rrseq.naming import RRSEQ_CONS_KIND, RRSEQ_GAP_KIND
from route_inspector.tactics.rrseq.route_extraction import extract_route_rule_sequences
from route_inspector.tactics.rrsubtree.extract import (
    RRSubtreeCandidateLimitError,
    RRSubtreeLimits,
    extract_prepared_rrsubtrees,
    rrseq_witnesses_from_occurrences,
)
from route_inspector.tactics.rrsubtree.models import (
    RRSubtreeOccurrence,
    RRSubtreeRRSeqWitness,
)

RuleSequence = tuple[str, ...]
SequenceTargets = dict[RuleSequence, set[str]]
SequenceQueryCGRKeys = dict[RuleSequence, tuple[str, ...]]


@dataclass(frozen=True)
class RouteMotifPreparationStats:
    """Route-rule preparation and gapped-history counts for one route."""

    reactions_seen: int
    reaction_rule_cache_hits: int
    reaction_rule_cache_misses: int
    skipped_reactions: int
    no_net_selected_change: int

    @classmethod
    def from_processing_stats(
        cls,
        stats: RouteProcessingStats,
    ) -> "RouteMotifPreparationStats":
        """Take an immutable snapshot of the applicable processing counters."""

        return cls(
            reactions_seen=stats.reactions_seen,
            reaction_rule_cache_hits=stats.reaction_rule_cache_hits,
            reaction_rule_cache_misses=stats.reaction_rule_cache_misses,
            skipped_reactions=stats.skipped_reactions,
            no_net_selected_change=stats.no_net_selected_change,
        )


@dataclass(frozen=True)
class RouteMotifRRSubtreeError:
    """A rejected RRSubtree domain; no partial motifs are returned."""

    error_type: str
    message: str
    limit: int | None
    candidate_count: int | None
    cons_candidate_count: int | None
    gap_candidate_count: int | None


@dataclass(frozen=True)
class RouteMotifStrictPathError:
    """A strict path-witness failure affecting cons and RRSubtree domains."""

    error_type: str
    message: str
    affected_domains: tuple[str, ...] = (
        "rrseq_cons",
        "rrsubtree_cons",
        "rrsubtree_gap",
    )


@dataclass(frozen=True)
class RouteMotifRetroBleuBigramError:
    """A supplementary bigram extraction failure."""

    error_type: str
    message: str


@dataclass(frozen=True)
class RouteMotifExtractionResult:
    """All supported rule motifs extracted from one shared route preparation."""

    rrseq_cons_sequences: SequenceTargets
    single_rules: SequenceTargets
    rrseq_cons_occurrences: tuple[dict[str, Any], ...]
    rrseq_gap_sequences: SequenceTargets
    rrseq_gap_occurrences: tuple[dict[str, Any], ...]
    rrseq_cons_query_cgr_keys: SequenceQueryCGRKeys
    rrseq_gap_query_cgr_keys: SequenceQueryCGRKeys
    single_rule_query_cgr_keys: SequenceQueryCGRKeys
    rrseq_cons_base_query_cgr_keys: SequenceQueryCGRKeys
    rrseq_gap_base_query_cgr_keys: SequenceQueryCGRKeys
    single_rule_base_query_cgr_keys: SequenceQueryCGRKeys
    single_rule_occurrences: tuple[dict[str, Any], ...]
    rrsubtree_cons_occurrences: tuple[RRSubtreeOccurrence, ...]
    rrsubtree_gap_occurrences: tuple[RRSubtreeOccurrence, ...]
    rrsubtree_cons_eligibility_witness: RRSubtreeRRSeqWitness | None
    rrsubtree_gap_eligibility_witness: RRSubtreeRRSeqWitness | None
    rrsubtree_candidate_count: int
    rrsubtree_cons_candidate_count: int
    rrsubtree_gap_candidate_count: int
    retro_bleu_bigram_occurrences: tuple[RetroBleuBigramOccurrence, ...]
    preparation_stats: RouteMotifPreparationStats
    rrsubtree_error: RouteMotifRRSubtreeError | None
    strict_path_error: RouteMotifStrictPathError | None
    retro_bleu_bigram_error: RouteMotifRetroBleuBigramError | None
    prepared_route: PreparedRouteRuleData


def extract_route_motifs(
    route_id: Any,
    route: dict[str, Any],
    rule_extractor: Any,
    *,
    source_identity: str = "",
    dataset_id: str = "",
    source_id_adapter: str = PAROUTES_SOURCE_ID_ADAPTER,
    rrseq_min_length: int = 2,
    rrseq_max_length: int | None = 20,
    rrsubtree_min_size: int = 3,
    rrsubtree_max_size: int = 12,
    rrsubtree_max_candidates_per_route: int = 100_000,
    include_retro_bleu_bigrams: bool = False,
    prepared_route: PreparedRouteRuleData | None = None,
) -> RouteMotifExtractionResult:
    """Extract two RRSeq and two RRSubtree kinds in one route pass.

    Route normalization, reaction-rule extraction, and exact path-witness
    preparation happen once. The prepared objects are then passed to the
    existing RRSeq implementations unchanged and to the separate conservative
    RRSubtree extractor.
    """

    if rrseq_min_length < 2:
        raise ValueError("rrseq_min_length must be at least 2")
    if rrseq_max_length is not None and rrseq_max_length < rrseq_min_length:
        raise ValueError(
            "rrseq_max_length must be greater than or equal to rrseq_min_length"
        )

    rrsubtree_limits = RRSubtreeLimits(
        min_size=rrsubtree_min_size,
        max_size=rrsubtree_max_size,
        max_candidates_per_route=rrsubtree_max_candidates_per_route,
    )
    stats = RouteProcessingStats()
    if prepared_route is None:
        prepared_route = prepare_route_rule_data(
            route,
            rule_extractor,
            stats=stats,
            route_id=route_id,
            source_identity=source_identity,
            dataset_id=dataset_id,
            source_id_adapter=source_id_adapter,
            include_single_rule_occurrences=True,
        )
    elif prepared_route.source_id_adapter != source_id_adapter:
        raise ValueError("prepared route source-ID adapter differs from the request")
    retro_bleu_bigram_error: RouteMotifRetroBleuBigramError | None = None
    if include_retro_bleu_bigrams:
        try:
            retro_bleu_bigram_occurrences = extract_prepared_retro_bleu_bigrams(
                prepared_route,
                route_id=route_id,
                dataset_id=dataset_id,
                source_identity=source_identity,
            )
        except Exception as exc:
            retro_bleu_bigram_occurrences = ()
            retro_bleu_bigram_error = RouteMotifRetroBleuBigramError(
                error_type=type(exc).__qualname__,
                message=str(exc) or type(exc).__qualname__,
            )
    else:
        retro_bleu_bigram_occurrences = ()
    strict_path_error: RouteMotifStrictPathError | None = None
    try:
        prepared_root_paths = prepare_root_reaction_paths(prepared_route)
    except ValueError as exc:
        strict_path_error = RouteMotifStrictPathError(
            error_type=type(exc).__qualname__,
            message=str(exc),
        )

        gap_query_cgr_keys: SequenceQueryCGRKeys = {}
        gap_base_query_cgr_keys: SequenceQueryCGRKeys = {}
        gap_single_rule_query_cgr_keys: SequenceQueryCGRKeys = {}
        gap_single_rule_base_query_cgr_keys: SequenceQueryCGRKeys = {}
        (
            rrseq_gap_sequences,
            gap_single_rules,
            rrseq_gap_occurrences,
        ) = extract_route_rule_sequences(
            route,
            rule_extractor,
            min_length=rrseq_min_length,
            max_length=rrseq_max_length,
            stats=stats,
            sequence_mode=RRSEQ_GAP_KIND,
            route_id=route_id,
            source_identity=source_identity,
            dataset_id=dataset_id,
            source_id_adapter=source_id_adapter,
            sequence_query_cgr_keys=gap_query_cgr_keys,
            sequence_base_query_cgr_keys=gap_base_query_cgr_keys,
            single_rule_query_cgr_keys=gap_single_rule_query_cgr_keys,
            single_rule_base_query_cgr_keys=gap_single_rule_base_query_cgr_keys,
            prepared_route=prepared_route,
            prepared_root_paths=None,
        )
        return RouteMotifExtractionResult(
            rrseq_cons_sequences={},
            single_rules=gap_single_rules,
            rrseq_cons_occurrences=(),
            rrseq_gap_sequences=rrseq_gap_sequences,
            rrseq_gap_occurrences=tuple(rrseq_gap_occurrences),
            rrseq_cons_query_cgr_keys={},
            rrseq_gap_query_cgr_keys=gap_query_cgr_keys,
            single_rule_query_cgr_keys=gap_single_rule_query_cgr_keys,
            rrseq_cons_base_query_cgr_keys={},
            rrseq_gap_base_query_cgr_keys=gap_base_query_cgr_keys,
            single_rule_base_query_cgr_keys=gap_single_rule_base_query_cgr_keys,
            single_rule_occurrences=tuple(
                getattr(prepared_route, "single_rule_occurrences", ())
            ),
            rrsubtree_cons_occurrences=(),
            rrsubtree_gap_occurrences=(),
            rrsubtree_cons_eligibility_witness=None,
            rrsubtree_gap_eligibility_witness=None,
            rrsubtree_candidate_count=0,
            rrsubtree_cons_candidate_count=0,
            rrsubtree_gap_candidate_count=0,
            retro_bleu_bigram_occurrences=retro_bleu_bigram_occurrences,
            preparation_stats=RouteMotifPreparationStats.from_processing_stats(stats),
            rrsubtree_error=None,
            strict_path_error=strict_path_error,
            retro_bleu_bigram_error=retro_bleu_bigram_error,
            prepared_route=prepared_route,
        )

    cons_query_cgr_keys: SequenceQueryCGRKeys = {}
    gap_query_cgr_keys: SequenceQueryCGRKeys = {}
    cons_base_query_cgr_keys: SequenceQueryCGRKeys = {}
    gap_base_query_cgr_keys: SequenceQueryCGRKeys = {}
    single_rule_query_cgr_keys: SequenceQueryCGRKeys = {}
    single_rule_base_query_cgr_keys: SequenceQueryCGRKeys = {}
    (
        rrseq_cons_sequences,
        single_rules,
        rrseq_cons_occurrences,
    ) = extract_route_rule_sequences(
        route,
        rule_extractor,
        min_length=rrseq_min_length,
        max_length=rrseq_max_length,
        stats=stats,
        sequence_mode=RRSEQ_CONS_KIND,
        route_id=route_id,
        source_identity=source_identity,
        dataset_id=dataset_id,
        source_id_adapter=source_id_adapter,
        sequence_query_cgr_keys=cons_query_cgr_keys,
        sequence_base_query_cgr_keys=cons_base_query_cgr_keys,
        single_rule_query_cgr_keys=single_rule_query_cgr_keys,
        single_rule_base_query_cgr_keys=single_rule_base_query_cgr_keys,
        prepared_route=prepared_route,
        prepared_root_paths=prepared_root_paths,
    )
    (
        rrseq_gap_sequences,
        _gap_single_rules,
        rrseq_gap_occurrences,
    ) = extract_route_rule_sequences(
        route,
        rule_extractor,
        min_length=rrseq_min_length,
        max_length=rrseq_max_length,
        stats=stats,
        sequence_mode=RRSEQ_GAP_KIND,
        route_id=route_id,
        source_identity=source_identity,
        dataset_id=dataset_id,
        source_id_adapter=source_id_adapter,
        sequence_query_cgr_keys=gap_query_cgr_keys,
        sequence_base_query_cgr_keys=gap_base_query_cgr_keys,
        single_rule_query_cgr_keys=single_rule_query_cgr_keys,
        single_rule_base_query_cgr_keys=single_rule_base_query_cgr_keys,
        prepared_route=prepared_route,
        prepared_root_paths=prepared_root_paths,
    )

    eligibility_occurrences = {
        "cons": tuple(rrseq_cons_occurrences),
        "gap": tuple(rrseq_gap_occurrences),
    }
    if rrseq_min_length > 2:
        eligibility_stats = RouteProcessingStats()
        for kind, sequence_mode in (
            ("cons", RRSEQ_CONS_KIND),
            ("gap", RRSEQ_GAP_KIND),
        ):
            _sequences, _single_rules, occurrences = extract_route_rule_sequences(
                route,
                rule_extractor,
                min_length=2,
                max_length=2,
                stats=eligibility_stats,
                sequence_mode=sequence_mode,
                route_id=route_id,
                source_identity=source_identity,
                sequence_query_cgr_keys={},
                single_rule_query_cgr_keys={},
                prepared_route=prepared_route,
                prepared_root_paths=prepared_root_paths,
            )
            eligibility_occurrences[kind] = tuple(occurrences)
    witnesses_by_kind = {
        kind: rrseq_witnesses_from_occurrences(kind, occurrences)
        for kind, occurrences in eligibility_occurrences.items()
    }

    rrsubtree_error: RouteMotifRRSubtreeError | None = None
    if not any(witnesses_by_kind.values()):
        rrsubtree_cons_occurrences = ()
        rrsubtree_gap_occurrences = ()
        rrsubtree_candidate_count = 0
        rrsubtree_cons_candidate_count = 0
        rrsubtree_gap_candidate_count = 0
    else:
        try:
            rrsubtree_result = extract_prepared_rrsubtrees(
                prepared_route,
                prepared_root_paths,
                route_id=route_id,
                source_identity=source_identity,
                dataset_id=dataset_id,
                limits=rrsubtree_limits,
                rrseq_cons_witnesses=witnesses_by_kind["cons"],
                rrseq_gap_witnesses=witnesses_by_kind["gap"],
            )
        except RRSubtreeCandidateLimitError as exc:
            rrsubtree_cons_occurrences = ()
            rrsubtree_gap_occurrences = ()
            rrsubtree_candidate_count = exc.candidate_count
            rrsubtree_cons_candidate_count = exc.cons_candidate_count
            rrsubtree_gap_candidate_count = exc.gap_candidate_count
            rrsubtree_error = RouteMotifRRSubtreeError(
                error_type=type(exc).__qualname__,
                message=str(exc),
                limit=exc.limit,
                candidate_count=exc.candidate_count,
                cons_candidate_count=exc.cons_candidate_count,
                gap_candidate_count=exc.gap_candidate_count,
            )
        except Exception as exc:
            rrsubtree_cons_occurrences = ()
            rrsubtree_gap_occurrences = ()
            rrsubtree_candidate_count = 0
            rrsubtree_cons_candidate_count = 0
            rrsubtree_gap_candidate_count = 0
            rrsubtree_error = RouteMotifRRSubtreeError(
                error_type=type(exc).__qualname__,
                message=str(exc) or type(exc).__qualname__,
                limit=None,
                candidate_count=None,
                cons_candidate_count=None,
                gap_candidate_count=None,
            )
        else:
            rrsubtree_cons_occurrences = rrsubtree_result.cons_occurrences
            rrsubtree_gap_occurrences = rrsubtree_result.gap_occurrences
            rrsubtree_candidate_count = rrsubtree_result.candidate_count
            rrsubtree_cons_candidate_count = rrsubtree_result.cons_candidate_count
            rrsubtree_gap_candidate_count = rrsubtree_result.gap_candidate_count
    return RouteMotifExtractionResult(
        rrseq_cons_sequences=rrseq_cons_sequences,
        single_rules=single_rules,
        rrseq_cons_occurrences=tuple(rrseq_cons_occurrences),
        rrseq_gap_sequences=rrseq_gap_sequences,
        rrseq_gap_occurrences=tuple(rrseq_gap_occurrences),
        rrseq_cons_query_cgr_keys=cons_query_cgr_keys,
        rrseq_gap_query_cgr_keys=gap_query_cgr_keys,
        single_rule_query_cgr_keys=single_rule_query_cgr_keys,
        rrseq_cons_base_query_cgr_keys=cons_base_query_cgr_keys,
        rrseq_gap_base_query_cgr_keys=gap_base_query_cgr_keys,
        single_rule_base_query_cgr_keys=single_rule_base_query_cgr_keys,
        single_rule_occurrences=tuple(
            getattr(prepared_route, "single_rule_occurrences", ())
        ),
        rrsubtree_cons_occurrences=rrsubtree_cons_occurrences,
        rrsubtree_gap_occurrences=rrsubtree_gap_occurrences,
        rrsubtree_cons_eligibility_witness=(
            witnesses_by_kind["cons"][0] if witnesses_by_kind["cons"] else None
        ),
        rrsubtree_gap_eligibility_witness=(
            witnesses_by_kind["gap"][0] if witnesses_by_kind["gap"] else None
        ),
        rrsubtree_candidate_count=rrsubtree_candidate_count,
        rrsubtree_cons_candidate_count=rrsubtree_cons_candidate_count,
        rrsubtree_gap_candidate_count=rrsubtree_gap_candidate_count,
        retro_bleu_bigram_occurrences=retro_bleu_bigram_occurrences,
        rrsubtree_error=rrsubtree_error,
        strict_path_error=strict_path_error,
        retro_bleu_bigram_error=retro_bleu_bigram_error,
        preparation_stats=RouteMotifPreparationStats.from_processing_stats(stats),
        prepared_route=prepared_route,
    )


__all__ = [
    "RouteMotifExtractionResult",
    "RouteMotifStrictPathError",
    "RouteMotifRRSubtreeError",
    "RouteMotifPreparationStats",
    "RouteMotifRetroBleuBigramError",
    "extract_route_motifs",
]
