"""Plot selected-reaction counts from an assembled Reference tactic library.

Run from the project root::

    python -m route_inspector.tactics.rrsubtree.distribution

Writes PNG, SVG, PDF, a TSV of counts, and provenance JSON into a fresh directory.
Requires matplotlib (included in the notebooks extra). No extraction is run.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import tempfile
from collections import defaultdict
from pathlib import Path

from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.infrastructure.publication import publish_directory_no_replace
from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
from route_inspector.reference_library import ReferenceTacticLibrary

KINDS = ("rrsubtree_cons", "rrsubtree_gap")
LABELS = {"rrsubtree_cons": "Consecutive", "rrsubtree_gap": "Gapped"}
DEFINITION = (
    "Size counts selected reaction nodes across the entire subtree, including "
    "the root and all arms; skipped reactions are excluded. Families are stored "
    "reference-library entries under the library's recorded identity semantics. "
    "Occurrences are distinct reference occurrence IDs. Route counts use unions "
    "of (dataset, source identity, route ID); a route can appear in multiple bins."
)


def collect_distribution(library):
    buckets = defaultdict(lambda: {"families": 0, "occurrences": 0, "routes": set()})
    seen = set()
    totals = {}
    for kind in KINDS:
        entries = library.entries(kind=kind)
        occurrence_total = 0
        all_routes = set()
        for entry in entries:
            sizes, entry_routes = set(), set()
            occurrences = list(library.iter_occurrences(entry.entry_id))
            if not occurrences or len(occurrences) != entry.occurrence_count:
                raise ValueError(f"Occurrence support mismatch: {entry.entry_id}")
            for occurrence in occurrences:
                identifier = occurrence.reference_occurrence_id
                if identifier in seen:
                    raise ValueError(f"Repeated occurrence ownership: {identifier}")
                seen.add(identifier)
                paths = occurrence.selected_reaction_node_paths
                size = len(paths)
                if size < 3 or len(set(paths)) != size:
                    raise ValueError(
                        f"Invalid RRSubtree selected-node paths: {identifier}"
                    )
                annotated = occurrence.annotations.get("subtree_size")
                if annotated is not None and (
                    type(annotated) is not int or annotated != size
                ):
                    raise ValueError(f"Contradictory subtree_size: {identifier}")
                if occurrence.identity.kind != kind:
                    raise ValueError(f"Tactic-kind mismatch: {identifier}")
                sizes.add(size)
                entry_routes.add(occurrence.route)
            if (
                len(sizes) != 1
                or len(entry_routes) != entry.route_count
                or entry_routes != set(entry.reference_routes)
            ):
                raise ValueError(
                    f"Family size/route support mismatch: {entry.entry_id}"
                )
            size = sizes.pop()
            bucket = buckets[kind, size]
            bucket["families"] += 1
            bucket["occurrences"] += len(occurrences)
            bucket["routes"].update(entry_routes)
            occurrence_total += len(occurrences)
            all_routes.update(entry_routes)
        statistics = library.manifest.statistics
        if len(entries) != statistics["entries_by_kind"].get(kind, 0):
            raise ValueError(f"Manifest family count mismatch: {kind}")
        if occurrence_total != statistics["occurrences_by_kind"].get(kind, 0):
            raise ValueError(f"Manifest occurrence count mismatch: {kind}")
        totals[kind] = dict(
            families=len(entries), occurrences=occurrence_total, routes=len(all_routes)
        )
    profile = library.processing_profile.to_dict()
    sizes = set(range(profile["rrsubtree_min_size"], profile["rrsubtree_max_size"] + 1))
    sizes.update(size for _, size in buckets)
    rows = []
    for size in sorted(sizes):
        for kind in KINDS:
            bucket = buckets[kind, size]
            rows.append(
                dict(
                    kind=kind,
                    size=size,
                    families=bucket["families"],
                    occurrences=bucket["occurrences"],
                    routes=len(bucket["routes"]),
                )
            )
    return rows, totals


def plot_distribution(rows, destination):
    setup_runtime_cache_dirs()
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import MaxNLocator

    sizes = sorted({row["size"] for row in rows})
    data = {(row["kind"], row["size"]): row for row in rows}
    with plt.rc_context({"font.size": 11, "svg.fonttype": "none", "pdf.fonttype": 42}):
        fig, axes = plt.subplots(1, 2, figsize=(10, 4.6))
        for ax, metric, title in zip(
            axes,
            ("families", "occurrences"),
            ("Unique tactic families", "Tactic occurrences"),
        ):
            for index, (kind, color) in enumerate(zip(KINDS, ("#2274A5", "#D17A22"))):
                heights = [data[kind, size][metric] for size in sizes]
                positions = [x + (index - 0.5) * 0.36 for x in range(len(sizes))]
                bars = ax.bar(
                    positions, heights, width=0.34, color=color, label=LABELS[kind]
                )
                ax.bar_label(
                    bars,
                    labels=[str(n) if n else "" for n in heights],
                    padding=3,
                    fontsize=10,
                )
            ax.set_xticks(range(len(sizes)), sizes)
            ax.set_xlabel("Selected reaction steps per subtree")
            ax.set_ylabel("Count")
            ax.set_title(title)
            ax.yaxis.set_major_locator(MaxNLocator(integer=True))
            ax.set_ylim(bottom=0, top=max(1, max(row[metric] for row in rows)) * 1.2)
            ax.spines[["top", "right"]].set_visible(False)
            ax.set_axisbelow(True)
            ax.grid(axis="y", alpha=0.2)
        axes[0].legend(frameon=False)
        fig.suptitle("RRSubtree size distribution", fontsize=15)
        fig.text(
            0.5,
            0.02,
            "Root + all selected arm steps; skipped reactions excluded. Gapped tactics are analysis-only.",
            ha="center",
            fontsize=9,
            color="#555555",
        )
        fig.tight_layout(rect=(0, 0.055, 1, 0.96))
        try:
            for suffix in ("png", "svg", "pdf"):
                fig.savefig(
                    destination / f"rrsubtree_size_distribution.{suffix}",
                    dpi=200,
                    facecolor="white",
                )
        finally:
            plt.close(fig)


def run(library_path, output_dir, *, verification="full", backend="auto"):
    library_path, output_dir = Path(library_path), Path(output_dir)
    if output_dir.exists():
        raise FileExistsError(
            f"Refusing to overwrite {output_dir}; choose a fresh output directory"
        )
    manifest_digest = sha256_file(library_path / "manifest.json")
    with ReferenceTacticLibrary.load(
        library_path, verification=verification, backend=backend
    ) as library:
        rows, totals = collect_distribution(library)
        provenance = {
            "schema_version": 1,
            "status": "complete",
            "library": os.path.relpath(library_path),
            "library_id": library.library_id,
            "manifest_sha256": manifest_digest,
            "verification": verification,
            "backend": backend,
            "definition": DEFINITION,
            "processing_profile": library.processing_profile.to_dict(),
            "identity_configuration": dict(library.manifest.identity_configuration),
            "source_corpora": [
                {k: c[k] for k in ("dataset_id", "source_identity", "input_sha256")}
                for c in library.manifest.reference_corpora
            ],
        }
    if sha256_file(library_path / "manifest.json") != manifest_digest:
        raise ValueError("Library changed during analysis")
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        prefix=".rrsubtree-size-", dir=output_dir.parent
    ) as tmp:
        staging = Path(tmp) / "report"
        staging.mkdir()
        plot_distribution(rows, staging)
        with (staging / "distribution.tsv").open("w", newline="") as stream:
            writer = csv.DictWriter(
                stream,
                fieldnames=["kind", "size", "families", "occurrences", "routes"],
                delimiter="\t",
            )
            writer.writeheader()
            writer.writerows(rows)
        (staging / "summary.json").write_text(json.dumps(totals, indent=2) + "\n")
        provenance["artifacts"] = {
            path.name: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
            for path in sorted(staging.iterdir())
        }
        (staging / "manifest.json").write_text(json.dumps(provenance, indent=2) + "\n")
        publish_directory_no_replace(staging, output_dir)
    return rows, totals


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--library", type=Path, default=Path("outputs/reference_libraries/n1")
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("outputs/n1/rrsubtree_size_distribution"),
    )
    parser.add_argument(
        "--verification",
        choices=("fast", "full"),
        default="full",
        help="fast is only for a previously verified unchanged library",
    )
    parser.add_argument(
        "--backend", choices=("auto", "sqlite", "jsonl"), default="auto"
    )
    args = parser.parse_args()
    _, totals = run(
        args.library,
        args.output_dir,
        verification=args.verification,
        backend=args.backend,
    )
    print(json.dumps(totals, indent=2))
    print(f"Plots and counts: {args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
