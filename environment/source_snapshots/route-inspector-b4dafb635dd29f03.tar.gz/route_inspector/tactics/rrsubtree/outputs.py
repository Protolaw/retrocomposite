"""Deterministic artifacts for convergent reaction-subtree motifs.

Occurrence JSON preserves exact source-route provenance. Canonical family JSON
preserves the complete canonical topology and occurrence statistics, while
compact TSV tables retain route-popularity statistics for plotting.
"""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

from route_inspector.infrastructure.artifacts import (
    reference_sort_key,
    write_json,
    write_standard_sidecars,
)
from route_inspector.infrastructure.text import write_tsv
from route_inspector.tactics.rrsubtree.models import (
    RRSUBTREE_IDENTITY_VERSION,
    RRSUBTREE_OCCURRENCE_SCHEMA_VERSION,
    RRSubtreeKind,
    RRSubtreeOccurrence,
)
from route_inspector.tactics.rrsubtree.notation import encode_rrsubtree

RRSUBTREE_FAMILY_SCHEMA_VERSION = 2
RRSUBTREE_OUTPUT_SCHEMA_VERSION = 5
RRSUBTREE_ERROR_FIELDS = [
    "dataset",
    "route_id",
    "stage",
    "error_type",
    "message",
    "limit",
    "candidate_count",
    "cons_candidate_count",
    "gap_candidate_count",
]


def rrsubtree_fields(kind: RRSubtreeKind) -> list[str]:
    """Return the stable family-table columns for one motif kind."""

    _validate_kind(kind)
    return [
        "family_key",
        f"RRSubtree_{kind}",
        "subtree_size",
        "popularity",
        "strict_popularity",
        "Reference",
        "Target_molecules",
    ]


def _validate_kind(kind: str) -> None:
    if kind not in ("cons", "gap"):
        raise ValueError(f"unsupported RRSubtree kind: {kind!r}")


def _occurrence_sort_key(
    occurrence: RRSubtreeOccurrence,
) -> tuple[Any, ...]:
    return (
        occurrence.subtree_size,
        occurrence.family_key,
        reference_sort_key(occurrence.route_id),
        occurrence.occurrence_id,
    )


def _deduplicate_occurrences(
    occurrences: Iterable[RRSubtreeOccurrence],
    *,
    dataset_id: str,
    kind: RRSubtreeKind,
) -> tuple[RRSubtreeOccurrence, ...]:
    """Validate and deduplicate occurrences without losing conflicts."""

    by_id: dict[str, tuple[RRSubtreeOccurrence, dict[str, Any]]] = {}
    for occurrence in occurrences:
        if not isinstance(occurrence, RRSubtreeOccurrence):
            raise TypeError("occurrences must contain RRSubtreeOccurrence records")
        if occurrence.dataset_id != dataset_id:
            raise ValueError(
                "mixed RRSubtree datasets are not allowed: "
                f"expected {dataset_id!r}, got {occurrence.dataset_id!r}"
            )
        if occurrence.kind != kind:
            raise ValueError(
                "mixed RRSubtree kinds are not allowed: "
                f"expected {kind!r}, got {occurrence.kind!r}"
            )

        payload = occurrence.to_dict()
        previous = by_id.get(occurrence.occurrence_id)
        if previous is None:
            by_id[occurrence.occurrence_id] = (occurrence, payload)
        elif previous[1] != payload:
            raise ValueError(
                "conflicting payloads share RRSubtree occurrence ID "
                f"{occurrence.occurrence_id!r}"
            )

    return tuple(
        sorted(
            (occurrence for occurrence, _payload in by_id.values()),
            key=_occurrence_sort_key,
        )
    )


def _root_target_smiles(occurrence: RRSubtreeOccurrence) -> str:
    return next(
        node.target_smiles
        for node in occurrence.nodes
        if node.reaction_node_path == occurrence.root_reaction_node_path
    )


def _family_outputs(
    occurrences: Iterable[RRSubtreeOccurrence],
    *,
    kind: RRSubtreeKind,
) -> tuple[dict[int, list[dict[str, Any]]], list[dict[str, Any]]]:
    """Build compact TSV rows and complete canonical family records."""

    grouped: dict[tuple[int, str], list[RRSubtreeOccurrence]] = defaultdict(list)
    for occurrence in occurrences:
        grouped[(occurrence.subtree_size, occurrence.family_key)].append(occurrence)

    rows_by_size: dict[int, list[dict[str, Any]]] = defaultdict(list)
    family_records: list[dict[str, Any]] = []
    for (subtree_size, family_key), members in grouped.items():
        canonical_structure = members[0].canonical_family_structure
        if any(
            member.canonical_family_structure != canonical_structure
            for member in members[1:]
        ):
            raise ValueError(
                "conflicting canonical structures share RRSubtree "
                f"family key {family_key!r}"
            )
        route_ids = tuple(
            sorted(
                {member.route_id for member in members},
                key=reference_sort_key,
            )
        )
        target_molecules = tuple(
            sorted({_root_target_smiles(member) for member in members})
        )
        strict_members = tuple(
            member for member in members if member.all_edges_rrseq_connected
        )
        strict_route_ids = {member.route_id for member in strict_members}
        statistics = {
            "family_key": family_key,
            "subtree_size": subtree_size,
            "popularity": len(route_ids),
            "occurrence_count": len(members),
            "strict_popularity": len(strict_route_ids),
            "strict_occurrence_count": len(strict_members),
        }
        rows_by_size[subtree_size].append(
            {
                "family_key": family_key,
                f"RRSubtree_{kind}": encode_rrsubtree(
                    min(members, key=_occurrence_sort_key)
                ).inline,
                "subtree_size": subtree_size,
                "popularity": len(route_ids),
                "strict_popularity": len(strict_route_ids),
                "Reference": ",".join(route_ids),
                "Target_molecules": ",".join(target_molecules),
            }
        )
        family_records.append(
            {
                **statistics,
                "kind": kind,
                "canonical_structure": canonical_structure,
                "references": list(route_ids),
                "target_molecules": list(target_molecules),
            }
        )

    def family_sort_key(row: dict[str, Any]) -> tuple[Any, ...]:
        return (
            int(row["subtree_size"]),
            -int(row["popularity"]),
            -int(row["strict_popularity"]),
            str(row["family_key"]),
        )

    for rows in rows_by_size.values():
        rows.sort(key=family_sort_key)
    family_records.sort(key=family_sort_key)
    return dict(rows_by_size), family_records


def write_rrsubtree_outputs(
    output_dir: Path,
    *,
    dataset_id: str,
    kind: RRSubtreeKind,
    occurrences: Iterable[RRSubtreeOccurrence],
    routes_seen: int,
    errors: Iterable[dict[str, Any]] = (),
    config_path: str | Path | None = None,
    input_path: str | Path | None = None,
    cli_args: Any | None = None,
) -> dict[str, Any]:
    """Write occurrence-provenanced outputs for one convergent motif kind.

    output_dir is the kind-specific stage directory. Identical duplicate
    occurrence IDs are collapsed; conflicting payloads fail before any files
    are written.
    """

    _validate_kind(kind)
    dataset_id = str(dataset_id)
    if not dataset_id:
        raise ValueError("dataset_id must not be empty")
    routes_seen = int(routes_seen)
    if routes_seen < 0:
        raise ValueError("routes_seen must be non-negative")

    unique_occurrences = _deduplicate_occurrences(
        occurrences,
        dataset_id=dataset_id,
        kind=kind,
    )
    error_rows = list(errors)
    route_ids = {occurrence.route_id for occurrence in unique_occurrences}
    if len(route_ids) > routes_seen:
        raise ValueError("routes_seen cannot be smaller than routes with motifs")

    output_dir = Path(output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    family_rows_by_size, family_records = _family_outputs(unique_occurrences, kind=kind)
    output_files: dict[str, Path] = {}

    occurrences_path = output_dir / f"{dataset_id}_rrsubtree_{kind}_occurrences.json"
    write_json(
        occurrences_path,
        [occurrence.to_dict() for occurrence in unique_occurrences],
    )
    output_files["occurrences"] = occurrences_path

    families_path = output_dir / f"{dataset_id}_rrsubtree_{kind}_families.json"
    write_json(
        families_path,
        {
            "schema_version": RRSUBTREE_FAMILY_SCHEMA_VERSION,
            "identity_version": RRSUBTREE_IDENTITY_VERSION,
            "dataset": dataset_id,
            "kind": kind,
            "families": family_records,
        },
    )
    output_files["families"] = families_path

    size_pattern = f"{dataset_id}_t*_rrsubtree_{kind}.tsv"
    for stale_path in output_dir.glob(size_pattern):
        stale_path.unlink()
    fields = rrsubtree_fields(kind)
    for subtree_size in sorted(family_rows_by_size):
        rows = family_rows_by_size[subtree_size]
        if not rows:
            continue
        path = output_dir / f"{dataset_id}_t{subtree_size}_rrsubtree_{kind}.tsv"
        write_tsv(path, fields, rows)
        output_files[f"t{subtree_size}_families"] = path

    occurrences_by_size = {
        str(subtree_size): sum(
            occurrence.subtree_size == subtree_size for occurrence in unique_occurrences
        )
        for subtree_size in sorted(family_rows_by_size)
    }
    families_by_size = {
        str(subtree_size): len(family_rows_by_size[subtree_size])
        for subtree_size in sorted(family_rows_by_size)
    }
    strict_occurrences_by_size = {
        str(subtree_size): sum(
            occurrence.subtree_size == subtree_size
            and occurrence.all_edges_rrseq_connected
            for occurrence in unique_occurrences
        )
        for subtree_size in sorted(family_rows_by_size)
    }
    strict_route_ids = {
        occurrence.route_id
        for occurrence in unique_occurrences
        if occurrence.all_edges_rrseq_connected
    }
    summary: dict[str, Any] = {
        "dataset": dataset_id,
        "kind": kind,
        "analysis_only": True,
        "routes_seen": routes_seen,
        "routes_with_motifs": len(route_ids),
        "occurrences": len(unique_occurrences),
        "unique_families": sum(families_by_size.values()),
        "strict_routes_with_motifs": len(strict_route_ids),
        "strict_occurrences": sum(strict_occurrences_by_size.values()),
        "occurrences_by_size": occurrences_by_size,
        "strict_occurrences_by_size": strict_occurrences_by_size,
        "unique_families_by_size": families_by_size,
        "errors": len(error_rows),
        "occurrence_schema_version": (RRSUBTREE_OCCURRENCE_SCHEMA_VERSION),
        "family_schema_version": RRSUBTREE_FAMILY_SCHEMA_VERSION,
        "output_schema_version": RRSUBTREE_OUTPUT_SCHEMA_VERSION,
        "output_directory": str(output_dir),
        "output_files": {key: str(path) for key, path in sorted(output_files.items())},
    }

    sidecars = write_standard_sidecars(
        output_dir,
        command_name="extract-route-motifs",
        summary=summary,
        errors=error_rows,
        error_fieldnames=RRSUBTREE_ERROR_FIELDS,
        input_files=([input_path] if input_path is not None else ()),
        output_files=output_files,
        config_path=config_path,
        cli_args=cli_args,
        extra_manifest={
            "dataset": dataset_id,
            "kind": kind,
            "analysis_only": True,
            "occurrence_schema_version": (RRSUBTREE_OCCURRENCE_SCHEMA_VERSION),
            "family_schema_version": RRSUBTREE_FAMILY_SCHEMA_VERSION,
            "output_schema_version": RRSUBTREE_OUTPUT_SCHEMA_VERSION,
        },
    )
    return {
        **summary,
        "summary_path": sidecars["summary"],
        "errors_path": sidecars["errors"],
        "manifest_path": sidecars["manifest"],
    }


__all__ = [
    "RRSUBTREE_ERROR_FIELDS",
    "RRSUBTREE_FAMILY_SCHEMA_VERSION",
    "RRSUBTREE_OUTPUT_SCHEMA_VERSION",
    "rrsubtree_fields",
    "write_rrsubtree_outputs",
]
