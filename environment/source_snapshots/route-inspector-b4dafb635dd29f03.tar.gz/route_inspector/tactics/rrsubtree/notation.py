"""Chemical rule-tree notation, independent of exact route occurrence provenance.

Rules are JSON string literals; braces, semicolons and ``gap=N:`` are interpreted
only outside those literals. The shorthand replaces literals with legend labels.
Neither representation is a chemical family identity or an executable recipe.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Mapping

from route_inspector.rules.structure import RuleEdge, RuleNode, RuleTree
from route_inspector.tactics.rrsubtree.models import (
    RRSubtreeOccurrence,
    canonical_rrsubtree_family_structure,
)


@dataclass(frozen=True)
class RRSubtreeEncoding:
    """Equivalent self-contained and legend-backed chemical tree strings."""

    inline: str
    shorthand: str
    rule_legend: Mapping[str, str]


@lru_cache(maxsize=4096)
def _validate_rule(text: str) -> None:
    from chython import smarts
    from chython.containers import ReactionContainer
    from chython.files.daylight.tokenize import smarts_tokenize

    if not isinstance(text, str) or not text.strip():
        raise ValueError("expected a nonempty mapped reaction SMARTS")
    rule = smarts(text)
    if (
        not isinstance(rule, ReactionContainer)
        or not rule.reactants
        or not rule.products
    ):
        raise ValueError(
            "expected reaction SMARTS with nonempty reactants and products"
        )
    # Inspect explicit outer-atom maps before Chython supplies default numbers.
    # Recursive SMARTS environments are atom constraints, not extra reaction atoms.
    for side in text.split(">"):
        if not side.strip():
            continue
        tokens = smarts_tokenize(side.strip().split()[0])
        maps = [value.get("parsed_mapping", 0) for kind, value in tokens if kind == 0]
        if any(number <= 0 for number in maps):
            raise ValueError(
                "every reaction atom must have an explicit positive atom map"
            )
        if len(maps) != len(set(maps)):
            raise ValueError("duplicate atom maps on one reaction side")


def _check_rule(text: str, context: str) -> None:
    try:
        _validate_rule(text)
    except Exception as exc:
        raise ValueError(
            f"invalid mapped reaction SMARTS for {context}: {exc}"
        ) from exc


class _Parser:
    def __init__(self, text: str, legend: Mapping[str, str] | None):
        self.text = text
        self.legend = legend
        self.position = 0
        self.form: str | None = None
        self.nodes: list[RuleNode] = []
        self.edges: list[RuleEdge] = []

    def error(self, message: str) -> ValueError:
        return ValueError(
            f"invalid RRSubtree annotation at position {self.position}: {message}"
        )

    def whitespace(self) -> None:
        while self.position < len(self.text) and self.text[self.position].isspace():
            self.position += 1

    def take(self, token: str) -> bool:
        self.whitespace()
        if self.text.startswith(token, self.position):
            self.position += len(token)
            return True
        return False

    def node(self) -> int:
        self.whitespace()
        start = self.position
        key = len(self.nodes)
        if self.text.startswith('"', start):
            form = "inline"
            if self.legend is not None:
                raise self.error(
                    "inline SMARTS must not receive a separate rule_legend"
                )
            try:
                rule, self.position = json.JSONDecoder().raw_decode(self.text, start)
            except json.JSONDecodeError as exc:
                self.position = exc.pos
                raise self.error("invalid quoted SMARTS string") from exc
            label = f"R{key + 1}"
        else:
            form = "shorthand"
            match = re.match(r"R[1-9][0-9]*", self.text[start:])
            if match is None:
                raise self.error("expected a quoted reaction SMARTS or R1-style label")
            label = match.group()
            self.position += len(label)
            if self.legend is None or label not in self.legend:
                raise self.error(
                    f"unresolved label {label}; supply a complete rule_legend"
                )
            rule = self.legend[label]
        if self.form is not None and self.form != form:
            raise self.error("cannot mix inline SMARTS and shorthand labels")
        self.form = form
        _check_rule(rule, f"{label} at position {start}")
        self.nodes.append(RuleNode(key, label, rule))
        if self.take("{"):
            while True:
                skipped = 0
                if self.take("gap"):
                    if not self.take("="):
                        raise self.error("expected gap=N:")
                    self.whitespace()
                    match = re.match(r"[0-9]+", self.text[self.position :])
                    if match is None:
                        raise self.error("gap must be a non-negative integer")
                    skipped = int(match.group())
                    self.position += len(match.group())
                    if not self.take(":"):
                        raise self.error("expected ':' after gap count")
                child = self.node()
                self.edges.append(RuleEdge(key, child, skipped))
                if self.take("}"):
                    break
                if not self.take(";"):
                    raise self.error("expected ';' or '}' after child")
        return key

    def parse(self) -> RuleTree:
        try:
            self.node()
        except RecursionError as exc:
            raise self.error("tree nesting exceeds the parser recursion limit") from exc
        self.whitespace()
        if self.position != len(self.text):
            raise self.error("unexpected trailing content")
        return RuleTree(tuple(self.nodes), tuple(self.edges))


def _occurrence_tree(occurrence: RRSubtreeOccurrence, *, canonical: bool) -> RuleTree:
    by_path = {node.reaction_node_path: node for node in occurrence.nodes}
    children = {path: [] for path in by_path}
    for edge in occurrence.edges:
        children[edge.parent_reaction_node_path].append(edge)

    @lru_cache(maxsize=None)
    def structural_payload(path: tuple[int, ...]) -> dict[str, Any]:
        return canonical_rrsubtree_family_structure(
            kind=occurrence.kind,
            root_reaction_node_path=path,
            nodes=occurrence.nodes,
            edges=occurrence.edges,
        )["subtree"]

    @lru_cache(maxsize=None)
    def literal_key(path: tuple[int, ...]) -> str:
        branches = sorted(
            (
                len(edge.skipped_reaction_node_paths),
                literal_key(edge.child_reaction_node_path),
            )
            for edge in children[path]
        )
        return json.dumps([by_path[path].rule_smarts, branches], separators=(",", ":"))

    nodes: list[RuleNode] = []
    edges: list[RuleEdge] = []

    def visit(path: tuple[int, ...]) -> int:
        key = len(nodes)
        node = by_path[path]
        _check_rule(node.rule_smarts, f"reaction path {list(path)}")
        nodes.append(RuleNode(key, f"R{key + 1}", node.rule_smarts, path))
        if canonical:
            ordered = sorted(
                children[path],
                key=lambda edge: (
                    json.dumps(
                        {
                            "child": structural_payload(edge.child_reaction_node_path),
                            "skipped_reaction_count": len(
                                edge.skipped_reaction_node_paths
                            ),
                        },
                        sort_keys=True,
                        separators=(",", ":"),
                    ),
                    literal_key(edge.child_reaction_node_path),
                ),
            )
        else:
            ordered = sorted(
                children[path], key=lambda edge: edge.child_reaction_node_path
            )
        for edge in ordered:
            child = visit(edge.child_reaction_node_path)
            edges.append(
                RuleEdge(
                    key,
                    child,
                    len(edge.skipped_reaction_node_paths),
                    edge.skipped_reaction_node_paths,
                )
            )
        return key

    visit(occurrence.root_reaction_node_path)
    return RuleTree(tuple(nodes), tuple(edges), occurrence.all_edges_rrseq_connected)


def _prepare_rule_tree(
    value: Mapping[str, Any] | RRSubtreeOccurrence | str,
    *,
    rule_legend: Mapping[str, str] | None = None,
    canonical: bool = False,
) -> RuleTree:
    if rule_legend is not None and not isinstance(rule_legend, Mapping):
        raise ValueError("rule_legend must map labels to mapped reaction SMARTS")
    if isinstance(value, str):
        return _Parser(value, rule_legend).parse()
    if rule_legend is not None:
        raise ValueError("occurrence inputs must not receive a separate rule_legend")
    if not isinstance(value, (Mapping, RRSubtreeOccurrence)):
        raise ValueError("expected an RRSubtree occurrence or annotation string")
    try:
        occurrence = (
            value
            if isinstance(value, RRSubtreeOccurrence)
            else RRSubtreeOccurrence.from_dict(value)
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"invalid rrsubtree_occurrence: {exc}") from exc
    return _occurrence_tree(occurrence, canonical=canonical)


def _encode_tree(tree: RuleTree) -> RRSubtreeEncoding:
    children: dict[int, list[RuleEdge]] = {node.key: [] for node in tree.nodes}
    for edge in tree.edges:
        children[edge.parent].append(edge)
    by_key = {node.key: node for node in tree.nodes}

    def visit(key: int, *, inline: bool) -> str:
        node = by_key[key]
        text = (
            json.dumps(node.rule_smarts, ensure_ascii=False) if inline else node.label
        )
        if children[key]:
            branches = [
                (f"gap={edge.skipped_count}:" if edge.skipped_count else "")
                + visit(edge.child, inline=inline)
                for edge in children[key]
            ]
            text += "{" + ";".join(branches) + "}"
        return text

    return RRSubtreeEncoding(
        inline=visit(0, inline=True),
        shorthand=visit(0, inline=False),
        rule_legend={node.label: node.rule_smarts for node in tree.nodes},
    )


def encode_rrsubtree(
    occurrence: Mapping[str, Any] | RRSubtreeOccurrence,
) -> RRSubtreeEncoding:
    """Encode a validated occurrence without changing chemistry or family identity.

    Labels follow canonical structural preorder; identical branches remain
    distinct nodes. The strings carry rules and gap lengths, not exact lineage.
    """
    if isinstance(occurrence, str):
        raise TypeError("encode_rrsubtree requires an occurrence, not a string")
    return _encode_tree(_prepare_rule_tree(occurrence, canonical=True))


__all__ = ["RRSubtreeEncoding", "encode_rrsubtree"]
