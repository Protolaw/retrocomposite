"""Build compact n1/n5 route-architecture metrics for RRSubtree analysis.

The command reads cleaned PaRoutes trees and only RRSubtree occurrence rows
from the persisted Reference-library SQLite catalogs.  It deliberately avoids
opening optional bigram and protecting-group components and publishes a small,
deterministic artifact for Tutorial 11.
"""

from __future__ import annotations

import argparse
import csv
import errno
import hashlib
import json
import os
import shutil
import sqlite3
import tempfile
from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from route_inspector.infrastructure.hashing import sha256_file as _sha256_file
from route_inspector.infrastructure.publication import publish_directory_no_replace
from route_inspector.infrastructure.text import read_json
from route_inspector.metrics.routes import route_topology_metrics
from route_inspector.reference_library.models import (
    ReferenceRouteKey,
    stable_reference_occurrence_id,
)
from route_inspector.reference_library.profile import canonical_json
from route_inspector.reference_library.storage.contracts import (
    TACTIC_CATALOG_SCHEMA_VERSION,
)
from route_inspector.reference_library.storage.manifest import ReferenceLibraryManifest
from route_inspector.routes.access import route_items
from route_inspector.tactics.rrsubtree import RRSubtreeOccurrence

ANALYSIS_SCHEMA_VERSION = 1
RRSUBTREE_KINDS = ("rrsubtree_cons", "rrsubtree_gap")
ROUTE_COLUMNS = (
    "dataset_id",
    "source_identity",
    "route_id",
    "total_reaction_count",
    "longest_linear_route",
    "distinct_leaf_count",
    "topology",
    "rrsubtree_cons_present",
    "rrsubtree_cons_occurrence_count",
    "rrsubtree_cons_native_family_count",
    "rrsubtree_cons_exact_entry_count",
    "rrsubtree_cons_strict_occurrence_count",
    "rrsubtree_cons_occurrences_per_reaction",
    "rrsubtree_gap_present",
    "rrsubtree_gap_occurrence_count",
    "rrsubtree_gap_native_family_count",
    "rrsubtree_gap_exact_entry_count",
    "rrsubtree_gap_strict_occurrence_count",
    "rrsubtree_gap_occurrences_per_reaction",
)
OCCURRENCE_COLUMNS = (
    "dataset_id",
    "source_identity",
    "route_id",
    "kind",
    "reference_occurrence_id",
    "native_occurrence_id",
    "entry_id",
    "family_id",
    "subtree_size",
    "all_edges_rrseq_connected",
    "root_precursor_arm_count",
    "boundary_precursor_count",
)


def _numeric_aware(value: str) -> tuple[int, int | str]:
    try:
        return 0, int(value)
    except ValueError:
        return 1, value


def _read_manifest(library_dir: Path) -> ReferenceLibraryManifest:
    raw = json.loads((library_dir / "manifest.json").read_text(encoding="utf-8"))
    if not isinstance(raw, Mapping):
        raise ValueError("Reference-library manifest must contain an object")
    manifest = ReferenceLibraryManifest.from_dict(raw)
    if manifest.catalog_schema_version != TACTIC_CATALOG_SCHEMA_VERSION:
        raise ValueError(
            "unsupported tactic catalog schema version: "
            f"{manifest.catalog_schema_version}"
        )
    descriptor = manifest.artifacts.get("catalog")
    if descriptor is None:
        raise ValueError("Reference library does not declare catalog.sqlite")
    if descriptor["path"] != "catalog.sqlite":
        raise ValueError("Reference library uses a non-canonical catalog path")
    catalog_path = library_dir / "catalog.sqlite"
    if catalog_path.stat().st_size != int(descriptor["size_bytes"]):
        raise ValueError("Reference-library catalog size differs from its manifest")
    return manifest


def _corpus_for_dataset(
    manifest: ReferenceLibraryManifest,
    dataset_id: str,
) -> Mapping[str, Any]:
    matching = tuple(
        corpus
        for corpus in manifest.reference_corpora
        if str(corpus["dataset_id"]) == dataset_id
    )
    if len(matching) != 1 or len(manifest.reference_corpora) != 1:
        raise ValueError(
            f"{dataset_id} architecture analysis requires one matching corpus"
        )
    return matching[0]


def _open_validated_catalog(
    library_dir: Path,
    manifest: ReferenceLibraryManifest,
) -> sqlite3.Connection:
    connection = sqlite3.connect(
        f"file:{(library_dir / 'catalog.sqlite').resolve()}?mode=ro",
        uri=True,
    )
    connection.row_factory = sqlite3.Row
    version = int(connection.execute("PRAGMA user_version").fetchone()[0])
    if version != manifest.catalog_schema_version:
        connection.close()
        raise ValueError("SQLite catalog schema version differs from its manifest")
    metadata = {
        str(row["key"]): json.loads(row["value_json"])
        for row in connection.execute("SELECT key, value_json FROM metadata")
    }
    expected = {
        "library_id": manifest.library_id,
        "configuration_fingerprint": manifest.configuration_fingerprint,
        "processing_profile": manifest.processing_profile.to_dict(),
        "entry_count": manifest.statistics["entry_count"],
        "occurrence_count": manifest.statistics["occurrence_count"],
    }
    if metadata != expected:
        connection.close()
        raise ValueError("SQLite catalog metadata differs from its manifest")
    return connection


def _read_rrsubtree_occurrences(
    connection: sqlite3.Connection,
    *,
    dataset_id: str,
    source_identity: str,
    route_ids: frozenset[str],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    sql = """
        SELECT
            o.reference_occurrence_id,
            o.native_occurrence_id,
            o.entry_id,
            o.tactic_kind,
            o.dataset_id,
            o.source_identity,
            o.route_id,
            o.native_schema_version,
            json_extract(o.occurrence_json, '$.native_payload') AS native_json,
            e.tactic_kind AS entry_kind,
            er.entry_id AS owned_entry_id
        FROM occurrences AS o
        JOIN entries AS e ON e.entry_id = o.entry_id
        LEFT JOIN entry_routes AS er
          ON er.entry_id = o.entry_id
         AND er.dataset_id = o.dataset_id
         AND er.source_identity = o.source_identity
         AND er.route_id = o.route_id
        WHERE o.tactic_kind IN ('rrsubtree_cons', 'rrsubtree_gap')
        ORDER BY o.route_id, o.tactic_kind, o.reference_occurrence_id
    """
    observed_reference_ids: set[str] = set()
    for catalog_row in connection.execute(sql):
        raw_native = json.loads(catalog_row["native_json"])
        if not isinstance(raw_native, Mapping):
            raise ValueError("catalog native_payload must contain an object")
        native = RRSubtreeOccurrence.from_dict(raw_native)
        kind = f"rrsubtree_{native.kind}"
        route_key = ReferenceRouteKey(
            native.dataset_id,
            native.source_identity,
            native.route_id,
        )
        reference_id = stable_reference_occurrence_id(
            kind=kind,  # type: ignore[arg-type]
            route=route_key,
            native_occurrence_id=native.occurrence_id,
        )
        ownership = (
            str(catalog_row["tactic_kind"]) == kind
            and str(catalog_row["entry_kind"]) == kind
            and str(catalog_row["native_occurrence_id"]) == native.occurrence_id
            and str(catalog_row["dataset_id"]) == native.dataset_id
            and str(catalog_row["source_identity"]) == native.source_identity
            and str(catalog_row["route_id"]) == native.route_id
            and int(catalog_row["native_schema_version"]) == native.schema_version
            and str(catalog_row["reference_occurrence_id"]) == reference_id
            and str(catalog_row["owned_entry_id"] or "") == str(catalog_row["entry_id"])
        )
        if not ownership:
            raise ValueError(f"invalid catalog ownership for {reference_id}")
        if reference_id in observed_reference_ids:
            raise ValueError(f"duplicate Reference occurrence: {reference_id}")
        observed_reference_ids.add(reference_id)
        if (
            native.dataset_id != dataset_id
            or native.source_identity != source_identity
            or native.route_id not in route_ids
        ):
            raise ValueError(f"RRSubtree occurrence has unknown route: {reference_id}")

        root_arm_count = len(
            {
                edge.precursor_molecule_node_path
                for edge in native.edges
                if edge.parent_reaction_node_path == native.root_reaction_node_path
            }
        )
        rows.append(
            {
                "dataset_id": dataset_id,
                "source_identity": source_identity,
                "route_id": native.route_id,
                "kind": kind,
                "reference_occurrence_id": reference_id,
                "native_occurrence_id": native.occurrence_id,
                "entry_id": str(catalog_row["entry_id"]),
                "family_id": native.family_key,
                "subtree_size": native.subtree_size,
                "all_edges_rrseq_connected": int(native.all_edges_rrseq_connected),
                "root_precursor_arm_count": root_arm_count,
                "boundary_precursor_count": len(native.boundary_precursor_node_paths),
            }
        )
    rows.sort(
        key=lambda row: (
            row["dataset_id"],
            _numeric_aware(str(row["route_id"])),
            row["kind"],
            row["reference_occurrence_id"],
        )
    )
    return rows


def _route_rows(
    *,
    dataset_id: str,
    source_identity: str,
    routes_json: Any,
    occurrence_rows: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    by_route_kind: dict[tuple[str, str], list[Mapping[str, Any]]] = defaultdict(list)
    for row in occurrence_rows:
        by_route_kind[(str(row["route_id"]), str(row["kind"]))].append(row)

    rows: list[dict[str, Any]] = []
    for raw_route_id, route in route_items(routes_json):
        route_id = str(raw_route_id)
        topology = route_topology_metrics(route)
        total_reactions = int(topology["total_reaction_count"])
        row: dict[str, Any] = {
            "dataset_id": dataset_id,
            "source_identity": source_identity,
            "route_id": route_id,
            **topology,
        }
        for kind in RRSUBTREE_KINDS:
            occurrences = by_route_kind.get((route_id, kind), ())
            occurrence_count = len(occurrences)
            row.update(
                {
                    f"{kind}_present": int(bool(occurrences)),
                    f"{kind}_occurrence_count": occurrence_count,
                    f"{kind}_native_family_count": len(
                        {item["family_id"] for item in occurrences}
                    ),
                    f"{kind}_exact_entry_count": len(
                        {item["entry_id"] for item in occurrences}
                    ),
                    f"{kind}_strict_occurrence_count": sum(
                        int(item["all_edges_rrseq_connected"]) for item in occurrences
                    ),
                    f"{kind}_occurrences_per_reaction": (
                        occurrence_count / total_reactions if total_reactions else 0.0
                    ),
                }
            )
        rows.append(row)
    rows.sort(key=lambda row: (row["dataset_id"], _numeric_aware(row["route_id"])))
    return rows


def _write_tsv(
    path: Path,
    columns: Sequence[str],
    rows: Sequence[Mapping[str, Any]],
) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def _counter_dict(values: Sequence[Any]) -> dict[str, int]:
    counts = Counter(str(value) for value in values)
    return {key: counts[key] for key in sorted(counts, key=_numeric_aware)}


def _dataset_summary(
    route_rows: Sequence[Mapping[str, Any]],
    occurrence_rows: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "route_count": len(route_rows),
        "topology_counts": dict(
            sorted(Counter(row["topology"] for row in route_rows).items())
        ),
        "route_length_distribution": _counter_dict(
            [row["longest_linear_route"] for row in route_rows]
        ),
        "distinct_leaf_distribution": _counter_dict(
            [row["distinct_leaf_count"] for row in route_rows]
        ),
        "rrsubtrees": {},
    }
    for kind in RRSUBTREE_KINDS:
        selected = [row for row in occurrence_rows if row["kind"] == kind]
        route_selected = [row for row in route_rows if row[f"{kind}_present"]]
        summary["rrsubtrees"][kind] = {
            "route_count": len(route_selected),
            "occurrence_count": len(selected),
            "strict_occurrence_count": sum(
                int(row["all_edges_rrseq_connected"]) for row in selected
            ),
            "native_family_count": len({row["family_id"] for row in selected}),
            "exact_entry_count": len({row["entry_id"] for row in selected}),
            "subtree_size_distribution": _counter_dict(
                [row["subtree_size"] for row in selected]
            ),
            "root_precursor_arm_distribution": _counter_dict(
                [row["root_precursor_arm_count"] for row in selected]
            ),
            "boundary_precursor_distribution": _counter_dict(
                [row["boundary_precursor_count"] for row in selected]
            ),
            "all_occurrences_have_two_root_arms": all(
                int(row["root_precursor_arm_count"]) == 2 for row in selected
            ),
            "per_route_occurrence_family_entry_counts_equal": all(
                int(row[f"{kind}_occurrence_count"])
                == int(row[f"{kind}_native_family_count"])
                == int(row[f"{kind}_exact_entry_count"])
                for row in route_rows
            ),
        }
    return summary


def _publish_directory_no_replace(source: Path, destination: Path) -> None:
    """Preserve the historical command's publication error arguments."""
    try:
        publish_directory_no_replace(source, destination)
    except FileExistsError:
        if os.name == "nt":
            raise
        raise FileExistsError(destination) from None
    except OSError as exc:
        if os.name != "nt" and exc.errno == errno.ENOSYS:
            raise OSError(
                errno.ENOSYS, "atomic no-replace publication unsupported"
            ) from None
        raise


def build_rrsubtree_architecture_analysis(
    *,
    route_paths: Mapping[str, str | Path],
    library_paths: Mapping[str, str | Path],
    output_dir: str | Path,
) -> dict[str, Any]:
    """Build and atomically publish deterministic architecture metrics."""

    dataset_ids = tuple(route_paths)
    if dataset_ids != tuple(library_paths):
        raise ValueError("route and library dataset ordering must agree")
    destination = Path(output_dir)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError(destination)
    temporary = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent)
    )
    connections: list[sqlite3.Connection] = []
    try:
        all_route_rows: list[dict[str, Any]] = []
        all_occurrence_rows: list[dict[str, Any]] = []
        sources: dict[str, dict[str, Any]] = {}
        fingerprints: set[str] = set()
        for dataset_id in dataset_ids:
            route_path = Path(route_paths[dataset_id])
            library_dir = Path(library_paths[dataset_id])
            manifest = _read_manifest(library_dir)
            corpus = _corpus_for_dataset(manifest, dataset_id)
            route_digest = _sha256_file(route_path)
            if route_digest != str(corpus.get("input_sha256") or ""):
                raise ValueError(
                    f"{dataset_id} cleaned-route digest differs from its library"
                )
            routes_json = read_json(route_path)
            clean_route_ids = frozenset(
                str(route_id) for route_id, _ in route_items(routes_json)
            )
            manifest_route_ids = frozenset(
                str(value) for value in corpus.get("route_ids", ())
            )
            if (
                len(clean_route_ids) != int(corpus["route_count"])
                or clean_route_ids != manifest_route_ids
            ):
                raise ValueError(
                    f"{dataset_id} cleaned routes differ from manifest route IDs"
                )
            source_identity = str(corpus["source_identity"])
            connection = _open_validated_catalog(library_dir, manifest)
            connections.append(connection)
            occurrence_rows = _read_rrsubtree_occurrences(
                connection,
                dataset_id=dataset_id,
                source_identity=source_identity,
                route_ids=clean_route_ids,
            )
            route_rows = _route_rows(
                dataset_id=dataset_id,
                source_identity=source_identity,
                routes_json=routes_json,
                occurrence_rows=occurrence_rows,
            )
            all_route_rows.extend(route_rows)
            all_occurrence_rows.extend(occurrence_rows)
            fingerprints.add(manifest.configuration_fingerprint)
            sources[dataset_id] = {
                "reference_library_id": manifest.library_id,
                "processing_profile_fingerprint": manifest.configuration_fingerprint,
                "source_identity": source_identity,
                "clean_routes_sha256": route_digest,
                "route_count": len(route_rows),
            }
        if len(fingerprints) != 1:
            raise ValueError("n1 and n5 Reference processing profiles differ")

        route_metrics_path = temporary / "route_metrics.tsv"
        occurrence_metrics_path = temporary / "rrsubtree_occurrences.tsv"
        _write_tsv(route_metrics_path, ROUTE_COLUMNS, all_route_rows)
        _write_tsv(
            occurrence_metrics_path,
            OCCURRENCE_COLUMNS,
            all_occurrence_rows,
        )
        summary = {
            "schema_version": ANALYSIS_SCHEMA_VERSION,
            "definitions": {
                "longest_linear_route": (
                    "maximum number of reaction nodes on a root-to-leaf path"
                ),
                "distinct_leaf_count": (
                    "distinct metadata.original_smiles among terminal molecule nodes"
                ),
                "convergent": ("total_reaction_count exceeds longest_linear_route"),
                "popularity_unit": "complete_route",
                "strict": "all selected RRSubtree edges are RRSeq-connected",
                "root_precursor_arms": ("distinct root-edge precursor molecule paths"),
                "boundary_precursors": (
                    "terminal precursor molecule paths retained by the occurrence"
                ),
            },
            "processing_profile_fingerprint": next(iter(fingerprints)),
            "datasets": {
                dataset_id: _dataset_summary(
                    [row for row in all_route_rows if row["dataset_id"] == dataset_id],
                    [
                        row
                        for row in all_occurrence_rows
                        if row["dataset_id"] == dataset_id
                    ],
                )
                for dataset_id in dataset_ids
            },
        }
        summary_path = temporary / "summary.json"
        summary_path.write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        artifacts = {
            name: {
                "path": path.name,
                "sha256": _sha256_file(path),
                "size_bytes": path.stat().st_size,
            }
            for name, path in (
                ("route_metrics", route_metrics_path),
                ("rrsubtree_occurrences", occurrence_metrics_path),
                ("summary", summary_path),
            )
        }
        identity_payload = {
            "schema_version": ANALYSIS_SCHEMA_VERSION,
            "sources": sources,
            "artifacts": artifacts,
        }
        analysis_id = (
            "rrsubtree_architecture_"
            + hashlib.sha256(
                canonical_json(identity_payload).encode("utf-8")
            ).hexdigest()
        )
        analysis_manifest = {
            "schema_version": ANALYSIS_SCHEMA_VERSION,
            "analysis_id": analysis_id,
            "analysis": "rrsubtree_recovery_of_paroutes_architecture",
            "sources": sources,
            "artifacts": artifacts,
        }
        (temporary / "manifest.json").write_text(
            json.dumps(analysis_manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        for connection in connections:
            connection.close()
        connections.clear()
        _publish_directory_no_replace(temporary, destination)
    except Exception:
        for connection in connections:
            connection.close()
        shutil.rmtree(temporary, ignore_errors=True)
        raise
    return {"manifest": analysis_manifest, "summary": summary}


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n1-routes", default="data/clean/n1_routes.json")
    parser.add_argument("--n5-routes", default="data/clean/n5_routes.json")
    parser.add_argument(
        "--n1-library",
        default="outputs/reference_libraries/n1",
    )
    parser.add_argument(
        "--n5-library",
        default="outputs/reference_libraries/n5",
    )
    parser.add_argument(
        "--output-dir",
        default="outputs/reference/66_rrsubtree_architecture/n1_n5",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    result = build_rrsubtree_architecture_analysis(
        route_paths={"n1": args.n1_routes, "n5": args.n5_routes},
        library_paths={"n1": args.n1_library, "n5": args.n5_library},
        output_dir=args.output_dir,
    )
    print(json.dumps(result["summary"]["datasets"], indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
