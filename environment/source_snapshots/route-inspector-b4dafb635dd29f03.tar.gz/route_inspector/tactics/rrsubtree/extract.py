"""Extract chemically continuous, occurrence-provenanced reaction subtrees.

The extractor consumes the exact root-to-leaf witnesses prepared for RRSeq
extraction.  It deduplicates those paths into one reaction graph and then
enumerates bounded rooted node subsets. Every retained edge must satisfy the
corresponding RRSeq continuity predicate. Consecutive and gapped trees remain
analysis-only entities and do not change RRSeq semantics.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Any, Iterable, Mapping

import route_inspector.routes.access as route_access
from route_inspector import chemistry
from route_inspector.rules.identity import rule_querycgr_identity
from route_inspector.rules.models import (
    PreparedRootReactionPaths,
    PreparedRouteRuleData,
    ReactionPathStep,
    RouteProcessingStats,
)
from route_inspector.rules.preparation import (
    prepare_root_reaction_paths,
    prepare_route_rule_data,
    route_target_smiles,
)
from route_inspector.tactics.rrseq.enumeration import adjacent_centers_overlap
from route_inspector.tactics.rrseq.naming import RRSEQ_CONS_KIND, RRSEQ_GAP_KIND
from route_inspector.tactics.rrseq.route_extraction import extract_route_rule_sequences
from route_inspector.tactics.rrsubtree.models import (
    NodePath,
    RRSubtreeAttachment,
    RRSubtreeEdge,
    RRSubtreeKind,
    RRSubtreeNode,
    RRSubtreeOccurrence,
    RRSubtreeRRSeqWitness,
)


@dataclass(frozen=True)
class RRSubtreeLimits:
    """Bound the size and enumeration cost of route-tree motifs."""

    min_size: int = 3
    max_size: int = 12
    max_candidates_per_route: int = 100_000

    def __post_init__(self) -> None:
        if self.min_size < 3:
            raise ValueError("min_size must be at least 3 for a convergent tree")
        if self.max_size < self.min_size:
            raise ValueError("max_size must be greater than or equal to min_size")
        if self.max_candidates_per_route < 1:
            raise ValueError("max_candidates_per_route must be positive")


class RRSubtreeCandidateLimitError(RuntimeError):
    """Report a complete route-level enumeration rejected at its safety cap."""

    def __init__(
        self,
        *,
        route_id: str,
        limit: int,
        candidate_count: int,
        cons_candidate_count: int,
        gap_candidate_count: int,
    ) -> None:
        self.route_id = str(route_id)
        self.limit = int(limit)
        self.candidate_count = int(candidate_count)
        self.cons_candidate_count = int(cons_candidate_count)
        self.gap_candidate_count = int(gap_candidate_count)
        super().__init__(
            "RRSubtree enumeration exceeded "
            f"max_candidates_per_route={self.limit} "
            f"for route {self.route_id!r}"
        )


@dataclass(frozen=True)
class RRSubtreeExtractionResult:
    """Consecutive and gapped occurrences extracted from one prepared route."""

    cons_occurrences: tuple[RRSubtreeOccurrence, ...]
    gap_occurrences: tuple[RRSubtreeOccurrence, ...]
    candidate_count: int
    cons_candidate_count: int
    gap_candidate_count: int


def rrseq_witnesses_from_occurrences(
    kind: RRSubtreeKind,
    occurrences: Iterable[Mapping[str, Any]],
) -> tuple[RRSubtreeRRSeqWitness, ...]:
    """Project exact length-2 RRSeq occurrences into compact eligibility records."""

    if kind not in ("cons", "gap"):
        raise ValueError(f"unsupported RRSubtree kind: {kind!r}")
    witnesses: dict[str, RRSubtreeRRSeqWitness] = {}
    for occurrence in occurrences:
        if kind == "cons":
            reaction_paths = tuple(
                tuple(int(index) for index in path)
                for path in occurrence.get("reaction_node_paths", ())
            )
            rules = tuple(str(rule) for rule in occurrence.get("raw_sequence", ()))
        else:
            selected_steps = tuple(occurrence.get("selected_steps", ()))
            reaction_paths = tuple(
                tuple(int(index) for index in step["reaction_node_path"])
                for step in selected_steps
            )
            rules = tuple(str(step["rule_smarts"]) for step in selected_steps)
        if len(reaction_paths) != 2 or len(rules) != 2:
            continue
        witness = RRSubtreeRRSeqWitness(
            kind=kind,
            occurrence_id=str(occurrence["occurrence_id"]),
            reaction_node_paths=reaction_paths,
            rule_smarts=rules,
        )
        previous = witnesses.setdefault(witness.occurrence_id, witness)
        if previous != witness:
            raise ValueError(
                "conflicting fixed-length RRSeq witnesses share occurrence ID "
                f"{witness.occurrence_id!r}"
            )
    return tuple(witnesses[key] for key in sorted(witnesses))


@dataclass(frozen=True)
class _RawEdge:
    parent: NodePath
    child: NodePath
    precursor_molecule_path: NodePath
    parent_reactant_index: int
    mapping_witness: tuple[tuple[int, int], ...]


@dataclass(frozen=True)
class _RouteRuleGraph:
    nodes: Mapping[NodePath, ReactionPathStep]
    children: Mapping[NodePath, tuple[NodePath, ...]]
    parent: Mapping[NodePath, NodePath]
    edge_by_child: Mapping[NodePath, _RawEdge]


@dataclass(frozen=True)
class _LogicalTree:
    root: NodePath
    selected: frozenset[NodePath]
    children: Mapping[NodePath, tuple[NodePath, ...]]
    chains: Mapping[tuple[NodePath, NodePath], tuple[_RawEdge, ...]]


def _reaction_step_signature(item: ReactionPathStep) -> tuple[Any, ...]:
    """Return fields that must agree when a path-shared node is deduplicated."""

    return (
        item.reaction_node_path,
        item.target_molecule_path,
        item.step,
        item.product_index,
        item.product_to_target_atom_map,
        item.reactant_molecule_paths,
    )


def _build_route_rule_graph(
    prepared_roots: Iterable[PreparedRootReactionPaths],
) -> _RouteRuleGraph:
    nodes: dict[NodePath, ReactionPathStep] = {}
    parent: dict[NodePath, NodePath] = {}
    edge_by_child: dict[NodePath, _RawEdge] = {}
    child_sets: dict[NodePath, set[NodePath]] = {}

    for prepared_root in prepared_roots:
        for detailed_path in prepared_root.detailed_paths:
            for item in detailed_path:
                path = item.reaction_node_path
                previous = nodes.setdefault(path, item)
                if _reaction_step_signature(previous) != _reaction_step_signature(item):
                    raise ValueError(
                        "one reaction node path has conflicting prepared witnesses: "
                        f"{path}"
                    )
                child_sets.setdefault(path, set())

            for left, right in zip(detailed_path, detailed_path[1:]):
                if (
                    left.continuation_molecule_path is None
                    or left.continuation_reactant_index is None
                ):
                    raise ValueError(
                        "prepared reaction path lacks an exact continuation witness "
                        f"at {left.reaction_node_path}"
                    )
                raw_edge = _RawEdge(
                    parent=left.reaction_node_path,
                    child=right.reaction_node_path,
                    precursor_molecule_path=left.continuation_molecule_path,
                    parent_reactant_index=left.continuation_reactant_index,
                    mapping_witness=tuple(
                        sorted(left.continuation_to_next_target_atom_map)
                    ),
                )
                old_parent = parent.setdefault(raw_edge.child, raw_edge.parent)
                old_edge = edge_by_child.setdefault(raw_edge.child, raw_edge)
                if old_parent != raw_edge.parent or old_edge != raw_edge:
                    raise ValueError(
                        "one reaction node path has conflicting parent-edge witnesses: "
                        f"{raw_edge.child}"
                    )
                child_sets.setdefault(raw_edge.parent, set()).add(raw_edge.child)

    return _RouteRuleGraph(
        nodes=nodes,
        children={
            path: tuple(sorted(children))
            for path, children in sorted(child_sets.items())
        },
        parent=parent,
        edge_by_child=edge_by_child,
    )


def _descendants(graph: _RouteRuleGraph, root: NodePath) -> tuple[NodePath, ...]:
    result: set[NodePath] = set()
    pending = list(graph.children.get(root, ()))
    while pending:
        current = pending.pop()
        if current in result:
            continue
        result.add(current)
        pending.extend(graph.children.get(current, ()))
    return tuple(sorted(result))


def _raw_chain(
    graph: _RouteRuleGraph,
    parent: NodePath,
    child: NodePath,
) -> tuple[_RawEdge, ...]:
    reverse_edges: list[_RawEdge] = []
    current = child
    while current != parent:
        edge = graph.edge_by_child.get(current)
        if edge is None:
            raise ValueError(f"{child} is not a descendant of {parent}")
        reverse_edges.append(edge)
        current = edge.parent
    return tuple(reversed(reverse_edges))


def _logical_tree(
    graph: _RouteRuleGraph,
    root: NodePath,
    selected: frozenset[NodePath],
) -> _LogicalTree:
    logical_children: dict[NodePath, list[NodePath]] = {path: [] for path in selected}
    chains: dict[tuple[NodePath, NodePath], tuple[_RawEdge, ...]] = {}
    for child in sorted(selected - {root}):
        current = graph.parent.get(child)
        while current is not None and current not in selected:
            current = graph.parent.get(current)
        if current is None:
            raise ValueError(f"selected node {child} does not descend from {root}")
        logical_children[current].append(child)
        chains[(current, child)] = _raw_chain(graph, current, child)
    return _LogicalTree(
        root=root,
        selected=selected,
        children={
            path: tuple(sorted(children)) for path, children in logical_children.items()
        },
        chains=chains,
    )


def _has_two_precursor_arms(tree: _LogicalTree) -> bool:
    root_children = tree.children.get(tree.root, ())
    if len(root_children) < 2:
        return False
    for parent, children in tree.children.items():
        precursor_paths = {
            tree.chains[(parent, child)][0].precursor_molecule_path
            for child in children
        }
        # Alternative reaction children below one precursor molecule do not make
        # independent motif arms at the root or at a nested selected reaction.
        if len(precursor_paths) != len(children):
            return False
    return True


def _is_structurally_convergent_root(
    graph: _RouteRuleGraph,
    root: NodePath,
) -> bool:
    return (
        len(
            {
                graph.edge_by_child[child].precursor_molecule_path
                for child in graph.children.get(root, ())
            }
        )
        >= 2
    )


def _consecutive_connectors(
    graph: _RouteRuleGraph,
    tree: _LogicalTree,
) -> dict[tuple[NodePath, NodePath], frozenset[int]] | None:
    connectors: dict[tuple[NodePath, NodePath], frozenset[int]] = {}
    for edge_key, chain in tree.chains.items():
        if len(chain) != 1:
            return None
        parent, child = edge_key
        left = graph.nodes[parent].step
        right = graph.nodes[child].step
        if not adjacent_centers_overlap(left, right):
            return None
        connector_maps = frozenset(left.center_atoms & right.center_atoms)
        if not connector_maps:
            # RRseq_cons also admits locally touching projected centers.  In
            # that case there is no shared center map, so retain the mapped
            # interface atoms from both rules on their common route molecule.
            # This keeps the attachment family informative instead of hashing
            # every touching edge with an empty anchor.
            common_molecule_maps = frozenset(
                int(atom_map)
                for atom_map in chemistry.parse_molecule(right.target_smiles)
            )
            connector_maps = frozenset(
                (left.center_atoms | right.center_atoms) & common_molecule_maps
            )
        if not connector_maps:
            return None
        connectors[edge_key] = connector_maps
    return connectors


def _gapped_connectors(
    graph: _RouteRuleGraph,
    tree: _LogicalTree,
) -> dict[tuple[NodePath, NodePath], frozenset[int]] | None:
    if not any(len(chain) > 1 for chain in tree.chains.values()):
        return None

    connectors: dict[tuple[NodePath, NodePath], frozenset[int]] = {}

    def visit(
        parent: NodePath,
        center_history: frozenset[int],
        skipped_center_history: frozenset[int],
    ) -> bool:
        for child in tree.children.get(parent, ()):
            chain = tree.chains[(parent, child)]
            child_center = graph.nodes[child].step.center_atoms
            new_connectors = frozenset(center_history & child_center)
            if not new_connectors:
                return False
            newly_skipped_centers = frozenset(
                atom_map
                for raw_edge in chain[:-1]
                for atom_map in graph.nodes[raw_edge.child].step.center_atoms
            )
            next_skipped_centers = skipped_center_history | newly_skipped_centers
            # An omitted reaction must be unrelated to every selected center
            # on this root-to-leaf arm, not only their shared connector atoms.
            # Checking accumulated sets also catches a later selected center
            # that overlaps an earlier skipped reaction.
            if (center_history | child_center) & next_skipped_centers:
                return False
            connectors[(parent, child)] = new_connectors
            # Each child receives its own immutable history.  A sibling's skipped
            # transformations therefore cannot contaminate this branch.
            if not visit(
                child,
                center_history | child_center,
                next_skipped_centers,
            ):
                return False
        return True

    if not visit(
        tree.root,
        graph.nodes[tree.root].step.center_atoms,
        frozenset(),
    ):
        return None
    return connectors


def _node_at_path(route: dict[str, Any], path: NodePath) -> dict[str, Any]:
    node = route
    for child_index in path:
        children = node.get("children", ()) or ()
        if child_index >= len(children) or not isinstance(children[child_index], dict):
            raise ValueError(f"route has no node at path {path}")
        node = children[child_index]
    return node


def _as_occurrence_node(item: ReactionPathStep) -> RRSubtreeNode:
    query_cgr_key = item.step.query_cgr_key or rule_querycgr_identity(
        item.step.rule_smarts
    )
    return RRSubtreeNode(
        reaction_node_path=item.reaction_node_path,
        target_molecule_node_path=item.target_molecule_path,
        rule_smarts=item.step.rule_smarts,
        reaction_smiles=item.step.reaction_smiles,
        target_smiles=item.step.target_smiles,
        center_atom_maps=tuple(sorted(item.step.center_atoms)),
        query_cgr_key=query_cgr_key,
    )


def _attachment_signature(
    prepared: PreparedRouteRuleData,
    raw_edge: _RawEdge,
    connector_maps: frozenset[int],
) -> RRSubtreeAttachment:
    from chython.exceptions import InvalidAromaticRing

    molecule_node = _node_at_path(
        prepared.route,
        raw_edge.precursor_molecule_path,
    )
    mapped_smiles = route_access.molecule_node_mapped_smiles(molecule_node)
    if not mapped_smiles:
        mapped_smiles = route_access.molecule_node_smiles(molecule_node)
    molecule = chemistry.parse_molecule(mapped_smiles)
    atom_ranks = {
        int(atom_map): int(rank) for atom_map, rank in molecule.atoms_order.items()
    }
    missing_maps = sorted(set(connector_maps) - set(atom_ranks))
    if missing_maps:
        raise ValueError(
            "connector maps are absent from their parent precursor molecule at "
            f"{raw_edge.precursor_molecule_path}: {missing_maps}"
        )
    try:
        precursor = chemistry.canonical_molecule_string(molecule)
    except InvalidAromaticRing:
        # Some valid source-route aromatic representations cannot be kekulized
        # by Chython. The precursor is occurrence evidence, not part of family
        # identity, so retain Chython's deterministic unmapped representation
        # instead of dropping the topology-valid subtree.
        precursor = str(molecule)
    return RRSubtreeAttachment(
        precursor=precursor,
        connector_atom_ranks=tuple(
            sorted(atom_ranks[atom_map] for atom_map in connector_maps)
        ),
    )


def _occurrence_edges(
    prepared: PreparedRouteRuleData,
    tree: _LogicalTree,
    connectors: Mapping[tuple[NodePath, NodePath], frozenset[int]],
) -> tuple[RRSubtreeEdge, ...]:
    edges = []
    for (parent, child), chain in tree.chains.items():
        first_edge = chain[0]
        skipped = tuple(sorted(raw_edge.child for raw_edge in chain[:-1]))
        edges.append(
            RRSubtreeEdge(
                parent_reaction_node_path=parent,
                child_reaction_node_path=child,
                precursor_molecule_node_path=first_edge.precursor_molecule_path,
                parent_reactant_index=first_edge.parent_reactant_index,
                mapping_witness=first_edge.mapping_witness,
                connector_atom_maps=tuple(sorted(connectors[(parent, child)])),
                attachment=_attachment_signature(
                    prepared,
                    first_edge,
                    connectors[(parent, child)],
                ),
                skipped_reaction_node_paths=skipped,
            )
        )
    return tuple(sorted(edges, key=lambda edge: edge.sort_key))


def _boundary_precursor_paths(
    graph: _RouteRuleGraph,
    tree: _LogicalTree,
) -> tuple[NodePath, ...]:
    span_nodes = set(tree.selected)
    span_edges: set[tuple[NodePath, NodePath]] = set()
    for chain in tree.chains.values():
        for raw_edge in chain:
            span_nodes.add(raw_edge.child)
            span_edges.add((raw_edge.parent, raw_edge.child))

    used_precursors = {
        graph.edge_by_child[child].precursor_molecule_path
        for parent, child in span_edges
        if graph.edge_by_child[child].parent == parent
    }
    boundaries: set[NodePath] = set()
    for node_path in span_nodes:
        for molecule_path in graph.nodes[node_path].reactant_molecule_paths:
            if molecule_path is not None and molecule_path not in used_precursors:
                boundaries.add(molecule_path)
    return tuple(sorted(boundaries))


def _select_rrseq_witness(
    tree: _LogicalTree,
    witnesses: tuple[RRSubtreeRRSeqWitness, ...],
) -> tuple[RRSubtreeRRSeqWitness, bool]:
    """Prefer a deterministic route witness lying inside the physical span."""

    if not witnesses:
        raise ValueError("an eligible RRSubtree kind requires an RRSeq witness")
    physical_span = set(tree.selected)
    for chain in tree.chains.values():
        physical_span.update(raw_edge.child for raw_edge in chain[:-1])
    inside = tuple(
        witness
        for witness in witnesses
        if set(witness.reaction_node_paths).issubset(physical_span)
    )
    candidates = inside or witnesses
    return min(candidates, key=lambda witness: witness.occurrence_id), bool(inside)


def _make_occurrence(
    prepared: PreparedRouteRuleData,
    graph: _RouteRuleGraph,
    tree: _LogicalTree,
    connectors: Mapping[tuple[NodePath, NodePath], frozenset[int]],
    *,
    kind: RRSubtreeKind,
    rrseq_witnesses: tuple[RRSubtreeRRSeqWitness, ...],
    all_edges_rrseq_connected: bool,
    source_identity: str,
    dataset_id: str,
    route_id: str,
) -> RRSubtreeOccurrence:
    edges = _occurrence_edges(prepared, tree, connectors)
    skipped_paths = tuple(
        sorted(
            {
                skipped_path
                for edge in edges
                for skipped_path in edge.skipped_reaction_node_paths
            }
        )
    )
    rrseq_witness, witness_is_inside = _select_rrseq_witness(tree, rrseq_witnesses)
    return RRSubtreeOccurrence.create(
        source_identity=source_identity,
        dataset_id=dataset_id,
        route_id=route_id,
        route_target_smiles=route_target_smiles(prepared.route),
        kind=kind,
        root_reaction_node_path=tree.root,
        nodes=(_as_occurrence_node(graph.nodes[path]) for path in tree.selected),
        skipped_nodes=(
            _as_occurrence_node(graph.nodes[path]) for path in skipped_paths
        ),
        edges=edges,
        boundary_precursor_node_paths=_boundary_precursor_paths(graph, tree),
        rrseq_witness=rrseq_witness,
        rrseq_witness_in_subtree=witness_is_inside,
        all_edges_rrseq_connected=all_edges_rrseq_connected,
    )


def extract_prepared_rrsubtrees(
    prepared: PreparedRouteRuleData,
    prepared_root_paths: tuple[PreparedRootReactionPaths, ...],
    *,
    route_id: Any,
    source_identity: str = "",
    dataset_id: str = "",
    limits: RRSubtreeLimits | None = None,
    rrseq_cons_witnesses: Iterable[RRSubtreeRRSeqWitness] = (),
    rrseq_gap_witnesses: Iterable[RRSubtreeRRSeqWitness] = (),
) -> RRSubtreeExtractionResult:
    """Extract both motif kinds without repeating route or rule preparation."""

    resolved_limits = limits or RRSubtreeLimits()
    witnesses_by_kind = {
        "cons": tuple(
            sorted(rrseq_cons_witnesses, key=lambda item: item.occurrence_id)
        ),
        "gap": tuple(sorted(rrseq_gap_witnesses, key=lambda item: item.occurrence_id)),
    }
    for kind, witnesses in witnesses_by_kind.items():
        if any(witness.kind != kind for witness in witnesses):
            raise ValueError(f"RRSeq witnesses do not match RRSubtree_{kind}")
    if not any(witnesses_by_kind.values()):
        return RRSubtreeExtractionResult(
            cons_occurrences=(),
            gap_occurrences=(),
            candidate_count=0,
            cons_candidate_count=0,
            gap_candidate_count=0,
        )

    graph = _build_route_rule_graph(prepared_root_paths)
    cons_occurrences: dict[str, RRSubtreeOccurrence] = {}
    gap_occurrences: dict[str, RRSubtreeOccurrence] = {}
    candidate_count = 0
    cons_candidate_count = 0
    gap_candidate_count = 0
    route_id_text = str(route_id)

    for root in sorted(graph.nodes):
        if not _is_structurally_convergent_root(graph, root):
            continue
        descendants = _descendants(graph, root)
        maximum_size = min(resolved_limits.max_size, len(descendants) + 1)
        for size in range(resolved_limits.min_size, maximum_size + 1):
            for selected_descendants in combinations(descendants, size - 1):
                tree = _logical_tree(
                    graph,
                    root,
                    frozenset((root, *selected_descendants)),
                )
                if not _has_two_precursor_arms(tree):
                    continue

                has_gap = any(len(chain) > 1 for chain in tree.chains.values())
                kind: RRSubtreeKind = "gap" if has_gap else "cons"
                rrseq_witnesses = witnesses_by_kind[kind]
                if not rrseq_witnesses:
                    continue

                candidate_count += 1
                if kind == "gap":
                    gap_candidate_count += 1
                else:
                    cons_candidate_count += 1
                if candidate_count > resolved_limits.max_candidates_per_route:
                    raise RRSubtreeCandidateLimitError(
                        route_id=route_id_text,
                        limit=resolved_limits.max_candidates_per_route,
                        candidate_count=candidate_count,
                        cons_candidate_count=cons_candidate_count,
                        gap_candidate_count=gap_candidate_count,
                    )

                strict_connectors = (
                    _gapped_connectors(graph, tree)
                    if kind == "gap"
                    else _consecutive_connectors(graph, tree)
                )
                if strict_connectors is None:
                    # Route-level RRSeq eligibility and branching topology do
                    # not establish continuity on every selected precursor arm.
                    continue
                occurrence = _make_occurrence(
                    prepared,
                    graph,
                    tree,
                    strict_connectors,
                    kind=kind,
                    rrseq_witnesses=rrseq_witnesses,
                    all_edges_rrseq_connected=True,
                    source_identity=source_identity,
                    dataset_id=dataset_id,
                    route_id=route_id_text,
                )
                destination = gap_occurrences if kind == "gap" else cons_occurrences
                destination[occurrence.occurrence_id] = occurrence

    return RRSubtreeExtractionResult(
        cons_occurrences=tuple(
            cons_occurrences[key] for key in sorted(cons_occurrences)
        ),
        gap_occurrences=tuple(gap_occurrences[key] for key in sorted(gap_occurrences)),
        candidate_count=candidate_count,
        cons_candidate_count=cons_candidate_count,
        gap_candidate_count=gap_candidate_count,
    )


def extract_rrsubtrees(
    route: dict[str, Any],
    rule_extractor: Any,
    *,
    route_id: Any,
    source_identity: str = "",
    dataset_id: str = "",
    limits: RRSubtreeLimits | None = None,
    stats: RouteProcessingStats | None = None,
) -> RRSubtreeExtractionResult:
    """Prepare one route once and extract both convergent motif kinds."""

    route_stats = stats if stats is not None else RouteProcessingStats()
    prepared = prepare_route_rule_data(route, rule_extractor, stats=route_stats)
    prepared_roots = prepare_root_reaction_paths(prepared)
    witnesses_by_kind: dict[str, tuple[RRSubtreeRRSeqWitness, ...]] = {}
    for kind, sequence_mode in (
        ("cons", RRSEQ_CONS_KIND),
        ("gap", RRSEQ_GAP_KIND),
    ):
        _sequences, _single_rules, occurrences = extract_route_rule_sequences(
            route,
            rule_extractor,
            min_length=2,
            max_length=2,
            stats=route_stats,
            sequence_mode=sequence_mode,
            route_id=route_id,
            source_identity=source_identity,
            sequence_query_cgr_keys={},
            single_rule_query_cgr_keys={},
            prepared_route=prepared,
            prepared_root_paths=prepared_roots,
        )
        witnesses_by_kind[kind] = rrseq_witnesses_from_occurrences(kind, occurrences)
    return extract_prepared_rrsubtrees(
        prepared,
        prepared_roots,
        route_id=route_id,
        source_identity=source_identity,
        dataset_id=dataset_id,
        limits=limits,
        rrseq_cons_witnesses=witnesses_by_kind["cons"],
        rrseq_gap_witnesses=witnesses_by_kind["gap"],
    )


__all__ = [
    "RRSubtreeCandidateLimitError",
    "RRSubtreeExtractionResult",
    "RRSubtreeLimits",
    "extract_rrsubtrees",
    "extract_prepared_rrsubtrees",
    "rrseq_witnesses_from_occurrences",
]
