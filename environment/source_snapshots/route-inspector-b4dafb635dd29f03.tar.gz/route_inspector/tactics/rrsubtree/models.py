"""Occurrence-provenanced models for convergent reaction-subtree motifs.

The models in this module deliberately separate structural occurrence identity
from chemistry-dependent family identity.  An occurrence identifies exact
nodes and edges in one source route.  A family key identifies a canonical
structural payload prepared by a chemistry-aware caller; this module only
serializes and hashes that payload and does not attempt chemical
canonicalization.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Iterable, Literal, Mapping, Sequence, TypeAlias

RRSUBTREE_OCCURRENCE_SCHEMA_VERSION = 3
RRSUBTREE_IDENTITY_VERSION = 2

RRSubtreeKind: TypeAlias = Literal["cons", "gap"]
NodePath: TypeAlias = tuple[int, ...]
AtomMapWitness: TypeAlias = tuple[tuple[int, int], ...]


def _path(value: Iterable[int]) -> NodePath:
    return tuple(int(index) for index in value)


def _validate_path(
    path: NodePath, *, field_name: str, allow_empty: bool = False
) -> None:
    if not allow_empty and not path:
        raise ValueError(f"{field_name} must not be empty")
    if any(index < 0 for index in path):
        raise ValueError(f"{field_name} must contain non-negative child indices")


def _validate_reaction_path(path: NodePath, *, field_name: str) -> None:
    """Validate a reaction-node path in an alternating route tree."""

    _validate_path(path, field_name=field_name)
    if len(path) % 2 != 1:
        raise ValueError(f"{field_name} must have odd reaction-node depth")


def _is_immediate_reaction_child(parent: NodePath, child: NodePath) -> bool:
    """Return whether two reaction paths are adjacent in a route tree."""

    return len(child) == len(parent) + 2 and child[: len(parent)] == parent


def _require_sorted_unique(values: Sequence[Any], *, field_name: str) -> None:
    if tuple(values) != tuple(sorted(values)):
        raise ValueError(f"{field_name} must be sorted")
    if len(values) != len(set(values)):
        raise ValueError(f"{field_name} must not contain duplicates")


def _canonical_json(value: Any) -> str:
    """Serialize a caller-canonical value deterministically for hashing."""

    try:
        return json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
            allow_nan=False,
        )
    except (TypeError, ValueError) as exc:
        raise ValueError(
            "canonical structural payload must be JSON-serializable"
        ) from exc


def stable_rrsubtree_family_key(canonical_structure: Any) -> str:
    """Hash an already-canonical nested structural payload.

    Branch ordering, QueryCGR canonicalization, and connector-label semantics
    belong to the extraction layer.  This helper intentionally performs no
    chemistry-aware normalization; it only applies deterministic JSON encoding.
    """

    payload = {
        "identity_version": RRSUBTREE_IDENTITY_VERSION,
        "canonical_structure": canonical_structure,
    }
    digest = hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()
    return f"rrsubtree_f_{digest[:24]}"


def stable_rrsubtree_occurrence_id(
    *,
    source_identity: str,
    route_id: str,
    kind: RRSubtreeKind,
    reaction_node_paths: Iterable[Iterable[int]],
    edge_skipped_reaction_paths: Iterable[
        tuple[Iterable[int], Iterable[int], Iterable[Iterable[int]]]
    ],
) -> str:
    """Return the stable ID for one exact route-tree occurrence.

    Identity excludes rule SMARTS, reaction text, family keys, and enumeration
    order.  Edge endpoints are retained alongside skipped paths so that two
    embeddings over the same selected nodes cannot be conflated.
    """

    if kind not in ("cons", "gap"):
        raise ValueError(f"unsupported RRSubtree kind: {kind!r}")

    selected_paths = sorted({_path(path) for path in reaction_node_paths})
    edge_paths = sorted(
        (
            _path(parent_path),
            _path(child_path),
            tuple(sorted({_path(path) for path in skipped_paths})),
        )
        for parent_path, child_path, skipped_paths in edge_skipped_reaction_paths
    )
    payload = {
        "identity_version": RRSUBTREE_IDENTITY_VERSION,
        "source_identity": str(source_identity),
        "route_id": str(route_id),
        "kind": kind,
        "reaction_node_paths": [list(path) for path in selected_paths],
        "edges": [
            {
                "parent_reaction_node_path": list(parent_path),
                "child_reaction_node_path": list(child_path),
                "skipped_reaction_node_paths": [list(path) for path in skipped_paths],
            }
            for parent_path, child_path, skipped_paths in edge_paths
        ],
    }
    digest = hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()
    return f"rrsubtree_o_{digest[:24]}"


@dataclass(frozen=True)
class RRSubtreeNode:
    """One selected reaction node and its exact source-route context."""

    reaction_node_path: NodePath
    target_molecule_node_path: NodePath
    rule_smarts: str
    reaction_smiles: str
    target_smiles: str
    center_atom_maps: tuple[int, ...]
    query_cgr_key: str

    def __post_init__(self) -> None:
        _validate_reaction_path(
            self.reaction_node_path, field_name="reaction_node_path"
        )
        _validate_path(
            self.target_molecule_node_path,
            field_name="target_molecule_node_path",
            allow_empty=True,
        )
        if self.target_molecule_node_path != self.reaction_node_path[:-1]:
            raise ValueError(
                "target_molecule_node_path must contain the reaction parent path"
            )
        _require_sorted_unique(self.center_atom_maps, field_name="center_atom_maps")
        if any(atom_map <= 0 for atom_map in self.center_atom_maps):
            raise ValueError("center_atom_maps must contain positive atom-map numbers")

    def to_dict(self) -> dict[str, Any]:
        return {
            "reaction_node_path": list(self.reaction_node_path),
            "target_molecule_node_path": list(self.target_molecule_node_path),
            "rule_smarts": self.rule_smarts,
            "reaction_smiles": self.reaction_smiles,
            "target_smiles": self.target_smiles,
            "center_atom_maps": list(self.center_atom_maps),
            "query_cgr_key": self.query_cgr_key,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RRSubtreeNode":
        return cls(
            reaction_node_path=_path(value["reaction_node_path"]),
            target_molecule_node_path=_path(value["target_molecule_node_path"]),
            rule_smarts=str(value["rule_smarts"]),
            reaction_smiles=str(value["reaction_smiles"]),
            target_smiles=str(value["target_smiles"]),
            center_atom_maps=tuple(
                int(atom_map) for atom_map in value.get("center_atom_maps", ())
            ),
            query_cgr_key=str(value["query_cgr_key"]),
        )


@dataclass(frozen=True)
class RRSubtreeAttachment:
    """Chemical attachment annotation for one logical occurrence edge.

    Canonical atom ranks are symmetry classes, so multiple connector atoms can
    legitimately have the same rank. Their multiplicity remains explicit.
    """

    precursor: str
    connector_atom_ranks: tuple[int, ...]

    def __post_init__(self) -> None:
        if not self.precursor:
            raise ValueError("attachment precursor must not be empty")
        if self.connector_atom_ranks != tuple(sorted(self.connector_atom_ranks)):
            raise ValueError("connector_atom_ranks must be sorted")
        if any(rank < 0 for rank in self.connector_atom_ranks):
            raise ValueError("connector_atom_ranks must be non-negative")

    def to_dict(self) -> dict[str, Any]:
        return {
            "precursor": self.precursor,
            "connector_atom_ranks": list(self.connector_atom_ranks),
        }

    @classmethod
    def from_dict(
        cls,
        value: Mapping[str, Any],
    ) -> "RRSubtreeAttachment":
        return cls(
            precursor=str(value["precursor"]),
            connector_atom_ranks=tuple(
                int(rank) for rank in value.get("connector_atom_ranks", ())
            ),
        )


@dataclass(frozen=True)
class RRSubtreeEdge:
    """Logical relation with connector maps and a first-hop mapping witness."""

    parent_reaction_node_path: NodePath
    child_reaction_node_path: NodePath
    precursor_molecule_node_path: NodePath
    parent_reactant_index: int
    mapping_witness: AtomMapWitness
    connector_atom_maps: tuple[int, ...]
    attachment: RRSubtreeAttachment
    skipped_reaction_node_paths: tuple[NodePath, ...] = ()

    def __post_init__(self) -> None:
        _validate_reaction_path(
            self.parent_reaction_node_path,
            field_name="parent_reaction_node_path",
        )
        _validate_reaction_path(
            self.child_reaction_node_path,
            field_name="child_reaction_node_path",
        )
        _validate_path(
            self.precursor_molecule_node_path,
            field_name="precursor_molecule_node_path",
        )
        if self.parent_reaction_node_path == self.child_reaction_node_path:
            raise ValueError("an edge cannot connect a reaction node to itself")
        if self.parent_reactant_index < 0:
            raise ValueError("parent_reactant_index must be non-negative")

        _require_sorted_unique(self.mapping_witness, field_name="mapping_witness")
        if not self.mapping_witness:
            raise ValueError("mapping_witness must retain the first route-edge match")
        if any(source <= 0 or target <= 0 for source, target in self.mapping_witness):
            raise ValueError("mapping_witness must contain positive atom-map numbers")
        source_maps, target_maps = zip(*self.mapping_witness)
        if len(source_maps) != len(set(source_maps)) or len(target_maps) != len(
            set(target_maps)
        ):
            raise ValueError("mapping_witness must be a one-to-one atom alignment")
        if not set(self.connector_atom_maps).issubset(source_maps):
            raise ValueError(
                "connector_atom_maps must occur in the first-edge mapping source"
            )
        _require_sorted_unique(
            self.connector_atom_maps,
            field_name="connector_atom_maps",
        )
        if any(atom_map <= 0 for atom_map in self.connector_atom_maps):
            raise ValueError(
                "connector_atom_maps must contain positive atom-map numbers"
            )
        if len(self.attachment.connector_atom_ranks) != len(self.connector_atom_maps):
            raise ValueError(
                "attachment connector ranks must correspond to connector maps"
            )
        _require_sorted_unique(
            self.skipped_reaction_node_paths,
            field_name="skipped_reaction_node_paths",
        )
        for path in self.skipped_reaction_node_paths:
            _validate_reaction_path(path, field_name="skipped_reaction_node_paths")

        chain = (
            self.parent_reaction_node_path,
            *self.skipped_reaction_node_paths,
            self.child_reaction_node_path,
        )
        if any(
            not _is_immediate_reaction_child(parent, child)
            for parent, child in zip(chain, chain[1:])
        ):
            raise ValueError(
                "skipped reaction paths must be the exact parent-to-child "
                "reaction chain"
            )
        if self.precursor_molecule_node_path != chain[1][:-1]:
            raise ValueError(
                "precursor_molecule_node_path must identify the first route edge"
            )

    @property
    def identity_key(self) -> tuple[NodePath, NodePath, tuple[NodePath, ...]]:
        """Return the chemistry-independent edge identity fields."""

        return (
            self.parent_reaction_node_path,
            self.child_reaction_node_path,
            self.skipped_reaction_node_paths,
        )

    @property
    def sort_key(self) -> tuple[Any, ...]:
        return (
            self.parent_reaction_node_path,
            self.child_reaction_node_path,
            self.precursor_molecule_node_path,
            self.parent_reactant_index,
            self.skipped_reaction_node_paths,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "parent_reaction_node_path": list(self.parent_reaction_node_path),
            "child_reaction_node_path": list(self.child_reaction_node_path),
            "precursor_molecule_node_path": list(self.precursor_molecule_node_path),
            "parent_reactant_index": self.parent_reactant_index,
            "mapping_witness": [list(pair) for pair in self.mapping_witness],
            "connector_atom_maps": list(self.connector_atom_maps),
            "attachment": self.attachment.to_dict(),
            "skipped_reaction_node_paths": [
                list(path) for path in self.skipped_reaction_node_paths
            ],
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RRSubtreeEdge":
        return cls(
            parent_reaction_node_path=_path(value["parent_reaction_node_path"]),
            child_reaction_node_path=_path(value["child_reaction_node_path"]),
            precursor_molecule_node_path=_path(value["precursor_molecule_node_path"]),
            parent_reactant_index=int(value["parent_reactant_index"]),
            mapping_witness=tuple(
                (int(source), int(target))
                for source, target in value.get("mapping_witness", ())
            ),
            connector_atom_maps=tuple(
                int(atom_map) for atom_map in value.get("connector_atom_maps", ())
            ),
            attachment=RRSubtreeAttachment.from_dict(value["attachment"]),
            skipped_reaction_node_paths=tuple(
                _path(path) for path in value.get("skipped_reaction_node_paths", ())
            ),
        )


def canonical_rrsubtree_family_structure(
    *,
    kind: RRSubtreeKind,
    root_reaction_node_path: NodePath,
    nodes: Iterable[RRSubtreeNode],
    edges: Iterable[RRSubtreeEdge],
) -> dict[str, Any]:
    """Return the branch-order-invariant topology used for family identity."""

    if kind not in ("cons", "gap"):
        raise ValueError(f"unsupported RRSubtree kind: {kind!r}")
    node_by_path = {node.reaction_node_path: node for node in nodes}
    edges_by_parent: dict[NodePath, list[RRSubtreeEdge]] = {}
    for edge in edges:
        edges_by_parent.setdefault(edge.parent_reaction_node_path, []).append(edge)

    def visit(path: NodePath) -> dict[str, Any]:
        try:
            node = node_by_path[path]
        except KeyError as exc:
            raise ValueError(
                "canonical family structure references an unknown reaction node"
            ) from exc
        branches = [
            {
                "skipped_reaction_count": len(edge.skipped_reaction_node_paths),
                "child": visit(edge.child_reaction_node_path),
            }
            for edge in edges_by_parent.get(path, ())
        ]
        branches.sort(key=_canonical_json)
        return {
            "query_cgr_key": node.query_cgr_key,
            "children": branches,
        }

    return {"kind": kind, "subtree": visit(root_reaction_node_path)}


@dataclass(frozen=True)
class RRSubtreeRRSeqWitness:
    """Compact fixed-length RRSeq evidence making a route eligible."""

    kind: RRSubtreeKind
    occurrence_id: str
    reaction_node_paths: tuple[NodePath, ...]
    rule_smarts: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.kind not in ("cons", "gap"):
            raise ValueError(f"unsupported RRSubtree RRSeq kind: {self.kind!r}")
        if not self.occurrence_id:
            raise ValueError("RRSeq witness occurrence_id must not be empty")
        if len(self.reaction_node_paths) != 2:
            raise ValueError("RRSeq eligibility witnesses must contain two reactions")
        if len(set(self.reaction_node_paths)) != 2:
            raise ValueError("RRSeq witness reaction paths must be distinct")
        for path in self.reaction_node_paths:
            _validate_reaction_path(path, field_name="reaction_node_paths")
        if len(self.rule_smarts) != 2 or any(not rule for rule in self.rule_smarts):
            raise ValueError("RRSeq eligibility witnesses must contain two rules")

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "occurrence_id": self.occurrence_id,
            "reaction_node_paths": [list(path) for path in self.reaction_node_paths],
            "rule_smarts": list(self.rule_smarts),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RRSubtreeRRSeqWitness":
        return cls(
            kind=str(value["kind"]),  # type: ignore[arg-type]
            occurrence_id=str(value["occurrence_id"]),
            reaction_node_paths=tuple(
                _path(path) for path in value["reaction_node_paths"]
            ),
            rule_smarts=tuple(str(rule) for rule in value["rule_smarts"]),
        )


@dataclass(frozen=True)
class RRSubtreeOccurrence:
    """One exact convergent reaction-subtree occurrence in a source route."""

    occurrence_id: str
    source_identity: str
    dataset_id: str
    route_id: str
    route_target_smiles: str
    kind: RRSubtreeKind
    root_reaction_node_path: NodePath
    nodes: tuple[RRSubtreeNode, ...]
    edges: tuple[RRSubtreeEdge, ...]
    boundary_precursor_node_paths: tuple[NodePath, ...]
    family_key: str
    rrseq_witness: RRSubtreeRRSeqWitness
    rrseq_witness_in_subtree: bool
    all_edges_rrseq_connected: bool
    skipped_nodes: tuple[RRSubtreeNode, ...] = ()
    analysis_only: bool = True
    schema_version: int = RRSUBTREE_OCCURRENCE_SCHEMA_VERSION
    identity_version: int = RRSUBTREE_IDENTITY_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != RRSUBTREE_OCCURRENCE_SCHEMA_VERSION:
            raise ValueError(
                "unsupported RRSubtree occurrence schema version: "
                f"{self.schema_version}"
            )
        if self.identity_version != RRSUBTREE_IDENTITY_VERSION:
            raise ValueError(
                f"unsupported RRSubtree identity version: {self.identity_version}"
            )
        if self.kind not in ("cons", "gap"):
            raise ValueError(f"unsupported RRSubtree kind: {self.kind!r}")
        if self.analysis_only is not True:
            raise ValueError("RRSubtree occurrences are analysis-only")
        if len(self.nodes) < 3:
            raise ValueError("a RRSubtree occurrence requires at least three nodes")

        node_paths = tuple(node.reaction_node_path for node in self.nodes)
        _require_sorted_unique(node_paths, field_name="nodes by reaction_node_path")
        _validate_reaction_path(
            self.root_reaction_node_path,
            field_name="root_reaction_node_path",
        )
        node_path_set = set(node_paths)
        if self.root_reaction_node_path not in node_path_set:
            raise ValueError("root_reaction_node_path must identify a selected node")

        edge_sort_keys = tuple(edge.sort_key for edge in self.edges)
        _require_sorted_unique(edge_sort_keys, field_name="edges")
        if len(self.edges) != len(self.nodes) - 1:
            raise ValueError("a RRSubtree must contain exactly nodes - 1 edges")

        selected_skip_paths: list[NodePath] = []
        indegree = {path: 0 for path in node_paths}
        children: dict[NodePath, list[NodePath]] = {path: [] for path in node_paths}
        edges_by_parent: dict[NodePath, list[RRSubtreeEdge]] = {
            path: [] for path in node_paths
        }
        for edge in self.edges:
            parent_path = edge.parent_reaction_node_path
            child_path = edge.child_reaction_node_path
            if parent_path not in node_path_set or child_path not in node_path_set:
                raise ValueError("every edge endpoint must identify a selected node")
            indegree[child_path] += 1
            children[parent_path].append(child_path)
            edges_by_parent[parent_path].append(edge)
            selected_skip_paths.extend(edge.skipped_reaction_node_paths)

        if len(selected_skip_paths) != len(set(selected_skip_paths)):
            raise ValueError(
                "a skipped reaction path cannot belong to multiple logical edges"
            )
        selected_skips = set(selected_skip_paths)
        for parent_path, parent_edges in edges_by_parent.items():
            precursor_paths = [
                edge.precursor_molecule_node_path for edge in parent_edges
            ]
            if len(precursor_paths) != len(set(precursor_paths)):
                raise ValueError(
                    "each selected parent requires distinct precursor arms: "
                    f"{parent_path}"
                )
            reactant_indexes = [edge.parent_reactant_index for edge in parent_edges]
            if len(reactant_indexes) != len(set(reactant_indexes)):
                raise ValueError(
                    "each selected parent requires distinct reactant witnesses: "
                    f"{parent_path}"
                )

        if indegree[self.root_reaction_node_path] != 0:
            raise ValueError("the root reaction node cannot have an incoming edge")
        if any(
            degree != 1
            for path, degree in indegree.items()
            if path != self.root_reaction_node_path
        ):
            raise ValueError("every non-root reaction node must have one parent")
        if len(children[self.root_reaction_node_path]) < 2:
            raise ValueError(
                "a RRSubtree root requires at least two first-arm children"
            )
        root_arm_paths = {
            edge.precursor_molecule_node_path
            for edge in self.edges
            if edge.parent_reaction_node_path == self.root_reaction_node_path
        }
        if len(root_arm_paths) < 2:
            raise ValueError("a RRSubtree root requires two distinct precursor arms")

        reachable: set[NodePath] = set()
        pending = [self.root_reaction_node_path]
        while pending:
            current = pending.pop()
            if current in reachable:
                continue
            reachable.add(current)
            pending.extend(children[current])
        if reachable != node_path_set:
            raise ValueError(
                "selected nodes and edges must form one connected rooted tree"
            )

        if selected_skips & node_path_set:
            raise ValueError("skipped reaction paths cannot also be selected nodes")
        has_skips = bool(selected_skips)
        if self.kind == "cons" and has_skips:
            raise ValueError("RRSubtree_cons edges cannot skip reactions")
        if self.kind == "gap" and not has_skips:
            raise ValueError("RRSubtree_gap requires at least one skipped reaction")
        skipped_node_paths = tuple(
            node.reaction_node_path for node in self.skipped_nodes
        )
        _require_sorted_unique(
            skipped_node_paths,
            field_name="skipped_nodes by reaction_node_path",
        )
        if set(skipped_node_paths) != selected_skips:
            raise ValueError(
                "skipped_nodes must exactly match edge skipped reaction paths"
            )

        if self.rrseq_witness.kind != self.kind:
            raise ValueError("RRSeq witness kind must match the RRSubtree kind")
        physical_span = node_path_set | selected_skips
        witness_is_inside = set(self.rrseq_witness.reaction_node_paths).issubset(
            physical_span
        )
        if self.rrseq_witness_in_subtree != witness_is_inside:
            raise ValueError(
                "rrseq_witness_in_subtree does not match the occurrence span"
            )

        edge_has_connectors = tuple(
            bool(edge.connector_atom_maps and edge.attachment.connector_atom_ranks)
            for edge in self.edges
        )
        if self.all_edges_rrseq_connected:
            if not all(edge_has_connectors):
                raise ValueError(
                    "all_edges_rrseq_connected requires certified connectors "
                    "on every edge"
                )
        elif any(
            edge.connector_atom_maps or edge.attachment.connector_atom_ranks
            for edge in self.edges
        ):
            raise ValueError(
                "non-strict RRSubtrees must not retain certified connector fields"
            )

        _require_sorted_unique(
            self.boundary_precursor_node_paths,
            field_name="boundary_precursor_node_paths",
        )
        for path in self.boundary_precursor_node_paths:
            _validate_path(path, field_name="boundary_precursor_node_paths")
        span_reaction_paths = node_path_set | selected_skips
        physical_chain_precursors = {
            reaction_path[:-1]
            for edge in self.edges
            for reaction_path in (
                *edge.skipped_reaction_node_paths,
                edge.child_reaction_node_path,
            )
        }
        for path in self.boundary_precursor_node_paths:
            if path[:-1] not in span_reaction_paths:
                raise ValueError(
                    "each boundary precursor must descend from the retained span"
                )
            if path in physical_chain_precursors:
                raise ValueError(
                    "boundary precursors cannot be internal motif-chain edges"
                )

        expected_id = stable_rrsubtree_occurrence_id(
            source_identity=self.source_identity,
            route_id=self.route_id,
            kind=self.kind,
            reaction_node_paths=node_paths,
            edge_skipped_reaction_paths=(edge.identity_key for edge in self.edges),
        )
        if self.occurrence_id != expected_id:
            raise ValueError("occurrence_id does not match occurrence identity fields")
        expected_family_key = stable_rrsubtree_family_key(
            self.canonical_family_structure
        )
        if self.family_key != expected_family_key:
            raise ValueError("family_key does not match the canonical family structure")

    @property
    def subtree_size(self) -> int:
        return len(self.nodes)

    @property
    def canonical_family_structure(self) -> dict[str, Any]:
        """Return the complete topology-only structure behind family_key."""

        return canonical_rrsubtree_family_structure(
            kind=self.kind,
            root_reaction_node_path=self.root_reaction_node_path,
            nodes=self.nodes,
            edges=self.edges,
        )

    @classmethod
    def create(
        cls,
        *,
        source_identity: str,
        dataset_id: str,
        route_id: str,
        route_target_smiles: str,
        kind: RRSubtreeKind,
        root_reaction_node_path: Iterable[int],
        nodes: Iterable[RRSubtreeNode],
        edges: Iterable[RRSubtreeEdge],
        boundary_precursor_node_paths: Iterable[Iterable[int]],
        rrseq_witness: RRSubtreeRRSeqWitness,
        rrseq_witness_in_subtree: bool,
        all_edges_rrseq_connected: bool,
        family_key: str | None = None,
        skipped_nodes: Iterable[RRSubtreeNode] = (),
    ) -> "RRSubtreeOccurrence":
        """Build an occurrence while assigning its stable structural ID."""

        ordered_nodes = tuple(sorted(nodes, key=lambda node: node.reaction_node_path))
        ordered_edges = tuple(sorted(edges, key=lambda edge: edge.sort_key))
        ordered_skipped_nodes = tuple(
            sorted(skipped_nodes, key=lambda node: node.reaction_node_path)
        )
        boundary_paths = tuple(
            sorted({_path(path) for path in boundary_precursor_node_paths})
        )
        occurrence_id = stable_rrsubtree_occurrence_id(
            source_identity=source_identity,
            route_id=route_id,
            kind=kind,
            reaction_node_paths=(node.reaction_node_path for node in ordered_nodes),
            edge_skipped_reaction_paths=(edge.identity_key for edge in ordered_edges),
        )
        canonical_structure = canonical_rrsubtree_family_structure(
            kind=kind,
            root_reaction_node_path=_path(root_reaction_node_path),
            nodes=ordered_nodes,
            edges=ordered_edges,
        )
        expected_family_key = stable_rrsubtree_family_key(canonical_structure)
        if family_key is not None and str(family_key) != expected_family_key:
            raise ValueError("family_key does not match the canonical family structure")
        return cls(
            occurrence_id=occurrence_id,
            source_identity=str(source_identity),
            dataset_id=str(dataset_id),
            route_id=str(route_id),
            route_target_smiles=str(route_target_smiles),
            kind=kind,
            root_reaction_node_path=_path(root_reaction_node_path),
            nodes=ordered_nodes,
            edges=ordered_edges,
            boundary_precursor_node_paths=boundary_paths,
            family_key=expected_family_key,
            rrseq_witness=rrseq_witness,
            rrseq_witness_in_subtree=bool(rrseq_witness_in_subtree),
            all_edges_rrseq_connected=bool(all_edges_rrseq_connected),
            skipped_nodes=ordered_skipped_nodes,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "identity_version": self.identity_version,
            "occurrence_id": self.occurrence_id,
            "source_identity": self.source_identity,
            "dataset_id": self.dataset_id,
            "route_id": self.route_id,
            "route_target_smiles": self.route_target_smiles,
            "kind": self.kind,
            "root_reaction_node_path": list(self.root_reaction_node_path),
            "nodes": [node.to_dict() for node in self.nodes],
            "edges": [edge.to_dict() for edge in self.edges],
            "boundary_precursor_node_paths": [
                list(path) for path in self.boundary_precursor_node_paths
            ],
            "family_key": self.family_key,
            "rrseq_witness": self.rrseq_witness.to_dict(),
            "rrseq_witness_in_subtree": self.rrseq_witness_in_subtree,
            "all_edges_rrseq_connected": self.all_edges_rrseq_connected,
            "skipped_nodes": [node.to_dict() for node in self.skipped_nodes],
            "analysis_only": self.analysis_only,
            "subtree_size": self.subtree_size,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RRSubtreeOccurrence":
        schema_version = int(value.get("schema_version", -1))
        if schema_version != RRSUBTREE_OCCURRENCE_SCHEMA_VERSION:
            raise ValueError(
                f"unsupported RRSubtree occurrence schema version: {schema_version}"
            )
        occurrence = cls(
            schema_version=schema_version,
            identity_version=int(value.get("identity_version", -1)),
            occurrence_id=str(value["occurrence_id"]),
            source_identity=str(value["source_identity"]),
            dataset_id=str(value["dataset_id"]),
            route_id=str(value["route_id"]),
            route_target_smiles=str(value["route_target_smiles"]),
            kind=str(value["kind"]),  # type: ignore[arg-type]
            root_reaction_node_path=_path(value["root_reaction_node_path"]),
            nodes=tuple(RRSubtreeNode.from_dict(node) for node in value["nodes"]),
            edges=tuple(RRSubtreeEdge.from_dict(edge) for edge in value["edges"]),
            boundary_precursor_node_paths=tuple(
                _path(path) for path in value.get("boundary_precursor_node_paths", ())
            ),
            family_key=str(value["family_key"]),
            rrseq_witness=RRSubtreeRRSeqWitness.from_dict(value["rrseq_witness"]),
            rrseq_witness_in_subtree=value["rrseq_witness_in_subtree"],
            all_edges_rrseq_connected=value["all_edges_rrseq_connected"],
            skipped_nodes=tuple(
                RRSubtreeNode.from_dict(node) for node in value.get("skipped_nodes", ())
            ),
            analysis_only=value.get("analysis_only", False),
        )
        if (
            "subtree_size" in value
            and int(value["subtree_size"]) != occurrence.subtree_size
        ):
            raise ValueError("subtree_size does not match nodes")
        return occurrence


__all__ = [
    "AtomMapWitness",
    "RRSUBTREE_IDENTITY_VERSION",
    "RRSUBTREE_OCCURRENCE_SCHEMA_VERSION",
    "RRSubtreeAttachment",
    "RRSubtreeEdge",
    "RRSubtreeKind",
    "RRSubtreeNode",
    "RRSubtreeOccurrence",
    "RRSubtreeRRSeqWitness",
    "NodePath",
    "canonical_rrsubtree_family_structure",
    "stable_rrsubtree_family_key",
    "stable_rrsubtree_occurrence_id",
]
