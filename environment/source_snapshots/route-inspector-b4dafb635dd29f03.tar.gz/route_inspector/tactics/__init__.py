"""Local route tactic definitions and extraction."""
