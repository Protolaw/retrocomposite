"""Source-bound NameRXN superclass counts for all four tactic kinds.

Classify exact selected reaction occurrences; preserve original mapped evidence.
This differs from representative-only RRSeq aggregate classification.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
from collections import Counter, defaultdict

from route_inspector import chemistry
from route_inspector.composite_rules.validation import compare_precursor_multisets
from route_inspector.routes.access import reaction_smiles_from_node, route_items

KINDS = ("rrseq_cons", "rrseq_gap", "rrsubtree_cons", "rrsubtree_gap")


def walk(node, path=()):
    yield path, node
    for i, child in enumerate(node.get("children") or []):
        yield from walk(child, (*path, i))


def parse_class(raw):
    labels = [x.strip() for x in raw.split(";") if x.strip()]
    codes = sorted(
        {
            x
            for x in labels
            if re.fullmatch(r"\d+\.\d+\.\d+(?:\.\d+)*", x) and x.split(".")[0] != "0"
        }
    )
    unknown = [x for x in labels if x not in codes]
    superclasses = sorted({x.split(".")[0] for x in codes}, key=int)
    return dict(
        raw_code=raw,
        codes=codes,
        superclasses=superclasses,
        classification_complete=bool(codes) and not unknown,
        unknown_labels=unknown,
        has_protection="5" in superclasses,
        has_deprotection="6" in superclasses,
    )


def presence(rows):
    protection = any(r["has_protection"] for r in rows)
    deprotection = any(r["has_deprotection"] for r in rows)
    complete = all(r["classification_complete"] for r in rows)
    category = (
        "both"
        if protection and deprotection
        else (
            "protection_only"
            if protection
            else "deprotection_only"
            if deprotection
            else "neither"
        )
    )
    return dict(
        has_protection=protection,
        has_deprotection=deprotection,
        classification_complete=complete,
        category=category if complete or category == "both" else "incomplete",
    )


def _rrseq_cons_rule_nodes(native, selected_paths):
    """Join occurrence-local rules to source matches without rewriting provenance."""
    nodes = native["source_matches"]
    paths = [tuple(node["reaction_node_path"]) for node in nodes]
    if paths != sorted(selected_paths) or len(set(paths)) != len(paths):
        raise ValueError("RRSeq_cons source matches disagree with selected step order")
    if "reaction_node_paths" in native and paths != [
        tuple(path) for path in native["reaction_node_paths"]
    ]:
        raise ValueError("RRSeq_cons source matches disagree with recorded paths")
    for index, node in enumerate(nodes):
        if "step_index" in node and node["step_index"] != index:
            raise ValueError("RRSeq_cons source match step_index disagrees with order")
        if "path_position" in node and "start_position" in native:
            if node["path_position"] != native["start_position"] + index:
                raise ValueError(
                    "RRSeq_cons source match path_position disagrees with order"
                )

    raw = native.get("raw_sequence")
    serialized = native.get("RRseq_cons")
    if serialized is not None and not isinstance(serialized, str):
        raise ValueError("RRSeq_cons serialized rules must be a string")
    stored = serialized.split("$") if serialized is not None else None
    if raw is not None and stored is not None and list(raw) != stored:
        raise ValueError("RRSeq_cons stored rule sequences disagree")
    rules = raw if raw is not None else stored
    if rules is None:
        rules = [node.get("rule_smarts") for node in nodes]
    if (
        not isinstance(rules, (list, tuple))
        or len(rules) != len(nodes)
        or any(not isinstance(rule, str) or not rule.strip() for rule in rules)
    ):
        raise ValueError("RRSeq_cons requires one recorded rule per selected step")
    resolved = []
    for node, rule in zip(nodes, rules, strict=True):
        if "rule_smarts" in node and node["rule_smarts"] != rule:
            raise ValueError(
                "RRSeq_cons source match rule disagrees with stored sequence"
            )
        resolved.append(dict(node, rule_smarts=rule))
    return resolved


def collect(library, routes, digest, *, kind="rrsubtree_cons"):
    if kind not in KINDS:
        raise ValueError(f"Unsupported tactic kind: {kind}")
    corpora = [
        c for c in library.manifest.reference_corpora if c["input_sha256"] == digest
    ]
    if len(corpora) != 1 or len(library.manifest.reference_corpora) != 1:
        raise ValueError(
            "Clean JSON must match the sole recorded reference corpus digest"
        )
    corpus = corpora[0]
    trees = dict((str(i), r) for i, r in route_items(routes))
    indexed = {}
    steps, links, occurrences = {}, [], []
    for occurrence in library.iter_occurrences(kind=kind):
        o = occurrence.to_dict()
        route = o["route"]
        rid = route["route_id"]
        if (
            route["dataset_id"] != corpus["dataset_id"]
            or route["source_identity"] != corpus["source_identity"]
        ):
            raise ValueError("Occurrence corpus identity mismatch")
        if rid not in indexed:
            nodes = [(p, n) for p, n in walk(trees[rid]) if n.get("type") == "reaction"]
            indexed[rid] = {p: (f"r{i}", n) for i, (p, n) in enumerate(nodes, 1)}
        native = o["native_payload"]
        selected = {tuple(p) for p in o["selected_reaction_node_paths"]}
        if kind in {"rrsubtree_cons", "rrsubtree_gap"}:
            rule_nodes = native["nodes"]
        elif kind == "rrseq_cons":
            rule_nodes = _rrseq_cons_rule_nodes(native, selected)
        else:
            rule_nodes = native["selected_steps"]
        native_paths = [tuple(n["reaction_node_path"]) for n in rule_nodes]
        if selected != set(native_paths) or len(native_paths) != len(selected):
            raise ValueError(
                "Selected analysis nodes do not reconcile with native rules"
            )
        entry_id = library.entry_id_for_occurrence(o["reference_occurrence_id"])
        record = dict(
            **route,
            entry_id=entry_id,
            reference_occurrence_id=o["reference_occurrence_id"],
            subtree_size=len(o["selected_reaction_node_paths"]),
            kind=kind,
            step_scope="selected",
            inter_selection_gap_widths=native.get("inter_selection_gap_widths", []),
            native_payload=native,
            step_ids=[],
        )
        for position, node in enumerate(
            sorted(rule_nodes, key=lambda n: n["reaction_node_path"]), 1
        ):
            path = tuple(node["reaction_node_path"])
            label, source_node = indexed[rid][path]
            reaction_text = reaction_smiles_from_node(source_node)
            source = chemistry.parse_reaction(reaction_text)
            witness = chemistry.parse_reaction(node["reaction_smiles"])
            for side in ("reactants", "products", "reagents"):
                a, b = getattr(source, side), getattr(witness, side)
                check = compare_precursor_multisets(
                    a, b, lineage_atom_ids={i for m in a for i in m}
                )
                if not check.chemistry_equivalent or not check.mapping_consistent:
                    raise ValueError(
                        f"Source witness mismatch: route {rid}, {label}, {side}"
                    )
            step_id = hashlib.sha256(
                json.dumps([route, path], sort_keys=True).encode()
            ).hexdigest()
            steps.setdefault(
                step_id,
                dict(
                    **route,
                    step_id=step_id,
                    step_label=label,
                    reaction_node_path=list(path),
                    mapped_forward_reaction=reaction_text,
                    classifier_input=str(source.copy()),
                ),
            )
            record["step_ids"].append(step_id)
            links.append(
                dict(
                    entry_id=entry_id,
                    reference_occurrence_id=o["reference_occurrence_id"],
                    step_id=step_id,
                    rule_position=position,
                    rule_smarts=node["rule_smarts"],
                )
            )
        occurrences.append(record)
    return sorted(steps.values(), key=lambda r: r["step_id"]), occurrences, links


def write_table(path, rows, fields):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(
            stream, fieldnames=fields, delimiter="\t", extrasaction="ignore"
        )
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    k: json.dumps(v) if isinstance(v, (list, dict)) else v
                    for k, v in row.items()
                }
            )


def reports(steps, occurrences, links, output, names):
    by_step = {r["step_id"]: r for r in steps}
    for row in steps:
        row["class_names"] = [
            names.get(c, names.get(".".join(c.split(".")[:3]), ""))
            for c in row["codes"]
        ]
    for row in occurrences:
        selected = [by_step[s] for s in row["step_ids"]]
        row.update(presence(selected))
        row["protection_steps"] = sum(s["has_protection"] for s in selected)
        row["deprotection_steps"] = sum(s["has_deprotection"] for s in selected)
    groups = defaultdict(list)
    for row in occurrences:
        groups[row["entry_id"]].append(row)
    families = [
        dict(
            entry_id=e,
            occurrences=len(rows),
            routes=len({r["route_id"] for r in rows}),
            **presence(rows),
            categories=dict(Counter(r["category"] for r in rows)),
        )
        for e, rows in sorted(groups.items())
    ]
    superclass_rows = []
    for code in sorted({c for r in steps for c in r["superclasses"]}, key=int):
        selected = {r["step_id"] for r in steps if code in r["superclasses"]}
        supporting = [r for r in occurrences if selected.intersection(r["step_ids"])]
        superclass_rows.append(
            dict(
                superclass=code,
                name={"5": "Protection", "6": "Deprotection"}.get(code, ""),
                source_reactions=len(selected),
                occurrences=len(supporting),
                families=len({r["entry_id"] for r in supporting}),
                routes=len({r["route_id"] for r in supporting}),
            )
        )
    for name, rows in [
        ("steps", steps),
        ("occurrences", occurrences),
        ("families", families),
        ("rule_step_links", links),
    ]:
        (output / f"{name}.jsonl").write_text(
            "".join(json.dumps(r) + "\n" for r in rows)
        )
    write_table(
        output / "steps.tsv",
        steps,
        [
            "dataset_id",
            "source_identity",
            "route_id",
            "step_label",
            "reaction_node_path",
            "step_id",
            "raw_code",
            "class_names",
            "superclasses",
            "has_protection",
            "has_deprotection",
            "classification_complete",
            "error",
            "mapped_forward_reaction",
        ],
    )
    write_table(
        output / "occurrences.tsv",
        occurrences,
        [
            "entry_id",
            "reference_occurrence_id",
            "route_id",
            "subtree_size",
            "kind",
            "step_scope",
            "inter_selection_gap_widths",
            "category",
            "classification_complete",
            "protection_steps",
            "deprotection_steps",
            "step_ids",
        ],
    )
    write_table(
        output / "families.tsv",
        families,
        [
            "entry_id",
            "occurrences",
            "routes",
            "has_protection",
            "has_deprotection",
            "classification_complete",
            "category",
            "categories",
        ],
    )
    write_table(
        output / "superclasses.tsv",
        superclass_rows,
        ["superclass", "name", "source_reactions", "occurrences", "families", "routes"],
    )
    incomplete = [r for r in steps if not r["classification_complete"]]
    write_table(
        output / "errors.tsv",
        incomplete,
        ["step_id", "route_id", "step_label", "raw_code", "unknown_labels", "error"],
    )
    summary = dict(
        status="incomplete" if incomplete else "complete",
        families=len(families),
        occurrences=len(occurrences),
        distinct_source_reactions=len(steps),
        rule_step_links=len(links),
        unclassified_or_partial_reactions=len(incomplete),
        occurrence_categories=dict(Counter(r["category"] for r in occurrences)),
        family_categories=dict(Counter(r["category"] for r in families)),
        by_subtree_size={
            str(n): dict(
                Counter(r["category"] for r in occurrences if r["subtree_size"] == n)
            )
            for n in sorted({r["subtree_size"] for r in occurrences})
        },
        direction="Classify recorded forward reactions; tree positions run target-to-leaves (retrosynthetic). Branches have no single linear sequence.",
        interpretation="NameRXN superclasses 5=protection and 6=deprotection. Presence is not proof of a paired protecting-group lifetime. Family presence is a union over all occurrences; incomplete classifications cannot establish absence.",
    )
    summary["presence_counts"] = {
        level: {
            "total": len(rows),
            "with_protection": sum(r["has_protection"] for r in rows),
            "with_deprotection": sum(r["has_deprotection"] for r in rows),
            "with_both": sum(
                r["has_protection"] and r["has_deprotection"] for r in rows
            ),
            "incompletely_classified": sum(
                not r["classification_complete"] for r in rows
            ),
        }
        for level, rows in [("occurrences", occurrences), ("families", families)]
    }
    table = [
        "# Protection and deprotection statistics",
        "",
        "NameRXN forward-reaction superclasses: 5 = protection; 6 = deprotection.",
        "",
        "| Unit | Total | With protection | With deprotection | With both | Incomplete |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for level, counts in summary["presence_counts"].items():
        table.append(
            "| " + level + " | " + " | ".join(str(v) for v in counts.values()) + " |"
        )
    table.extend(
        [
            "",
            "Positive counts include both-class cases. With incomplete classification, these are detected lower bounds, not final totals. Zero detections do not establish absence.",
            "Family flags are unions over occurrences; both classes need not occur in the same occurrence.",
        ]
    )
    if occurrences:
        table.extend(
            [
                "",
                f"Kind: `{occurrences[0].get('kind', 'rrsubtree_cons')}`.",
            ]
        )
    (output / "statistics.md").write_text("\n".join(table) + "\n")
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary
