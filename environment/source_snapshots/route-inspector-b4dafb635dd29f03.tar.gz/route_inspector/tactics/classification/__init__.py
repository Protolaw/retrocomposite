"""Provider-specific annotation and grouping of tactic occurrences."""
