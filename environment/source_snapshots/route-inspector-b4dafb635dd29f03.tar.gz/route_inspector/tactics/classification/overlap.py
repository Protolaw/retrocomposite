"""Compare n1/n5 tactic pools after Tier-3 reaction-class generalization.

The analysis consumes persisted occurrence provenance from two Reference tactic
libraries.  It classifies each distinct canonical, atom-map-free source reaction
once, then replaces the selected reaction in every RRSeq/RRSubtree occurrence by
its provider-specific Tier-3 code.  Composite rules are deliberately outside this
analysis because a net composite is not an elementary classifiable reaction."""

from __future__ import annotations

import hashlib
import signal
import sys
from collections import defaultdict
from collections.abc import Iterable, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any

from route_inspector import chemistry
from route_inspector.chemistry.classification.common import (
    provider_metadata,
    reconcile_batch_results,
    record_id,
    result_accepted,
)
from route_inspector.chemistry.classification.providers import (
    ReactionClassProvider,
    ReactionClassResult,
    ReactionRecord,
)
from route_inspector.reference_library import (
    ReferenceTacticLibrary,
    TacticOccurrence,
)
from route_inspector.reference_library.profile import canonical_json

TACTIC_KINDS = (
    "rrseq_cons",
    "rrseq_gap",
    "rrsubtree_cons",
    "rrsubtree_gap",
)


REGION_ORDER = {"left_only": 0, "shared": 1, "right_only": 2}


REPORT_COLUMNS = (
    "region",
    "class_identity_id",
    "class_identity_json",
    "left_popularity",
    "right_popularity",
    "left_occurrence_count",
    "right_occurrence_count",
)


ANALYSIS_SCHEMA_VERSION = 1


CLASS_IDENTITY_SCHEMA_VERSION = 1


DEFAULT_CANONICALIZATION_TIMEOUT = 10.0


@dataclass(frozen=True)
class SelectedReaction:
    """One selected elementary reaction in a persisted tactic occurrence."""

    reaction_node_path: tuple[int, ...]
    reaction_smiles: str


@dataclass
class CoverageAccumulator:
    """Completeness denominators for one dataset and tactic kind."""

    total_occurrences: int = 0
    included_occurrences: int = 0
    all_routes: set[str] = field(default_factory=set)
    included_routes: set[str] = field(default_factory=set)
    routes_with_excluded_occurrences: set[str] = field(default_factory=set)
    total_selected_reaction_uses: int = 0
    classified_selected_reaction_uses: int = 0

    def to_dict(self) -> dict[str, Any]:
        excluded_occurrences = self.total_occurrences - self.included_occurrences
        routes_without_included = self.all_routes - self.included_routes
        return {
            "total_occurrences": self.total_occurrences,
            "included_occurrences": self.included_occurrences,
            "excluded_occurrences": excluded_occurrences,
            "occurrence_coverage": _fraction(
                self.included_occurrences,
                self.total_occurrences,
            ),
            "routes_with_any_occurrence": len(self.all_routes),
            "routes_with_included_occurrence": len(self.included_routes),
            "routes_without_included_occurrence": len(routes_without_included),
            "routes_with_excluded_occurrence": len(
                self.routes_with_excluded_occurrences
            ),
            "route_coverage": _fraction(
                len(self.included_routes),
                len(self.all_routes),
            ),
            "total_selected_reaction_uses": self.total_selected_reaction_uses,
            "classified_selected_reaction_uses": (
                self.classified_selected_reaction_uses
            ),
            "unclassified_selected_reaction_uses": (
                self.total_selected_reaction_uses
                - self.classified_selected_reaction_uses
            ),
        }


@dataclass
class FamilySupport:
    """Occurrence and route support for one complete class identity."""

    routes: dict[str, set[str]] = field(
        default_factory=lambda: {"left": set(), "right": set()}
    )
    occurrences: dict[str, set[str]] = field(
        default_factory=lambda: {"left": set(), "right": set()}
    )


def _fraction(numerator: int, denominator: int) -> float | None:
    return numerator / denominator if denominator else None


def _node_path(value: Any, *, field_name: str) -> tuple[int, ...]:
    try:
        path = tuple(int(index) for index in value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be an integer node path") from exc
    if not path or any(index < 0 for index in path):
        raise ValueError(f"{field_name} must be a non-empty non-negative path")
    return path


def _mapping_rows(value: Any, *, field_name: str) -> tuple[Mapping[str, Any], ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise ValueError(f"{field_name} must be a sequence")
    if any(not isinstance(row, Mapping) for row in value):
        raise ValueError(f"{field_name} must contain JSON objects")
    return tuple(value)


def _selected_reactions(occurrence: TacticOccurrence) -> tuple[SelectedReaction, ...]:
    """Return selected source reactions in sequence/path order."""

    payload = occurrence.native_payload
    kind = occurrence.identity.kind
    if kind == "rrseq_cons":
        raw_steps = _mapping_rows(
            payload.get("source_matches"), field_name="source_matches"
        )
        steps = sorted(raw_steps, key=lambda row: int(row["step_index"]))
        indexes = tuple(int(row["step_index"]) for row in steps)
        if indexes != tuple(range(len(steps))):
            raise ValueError("RRSeq_cons source step indexes must be contiguous")
    elif kind == "rrseq_gap":
        raw_steps = _mapping_rows(
            payload.get("selected_steps"), field_name="selected_steps"
        )
        steps = sorted(raw_steps, key=lambda row: int(row["position"]))
        positions = tuple(int(row["position"]) for row in steps)
        expected_positions = tuple(
            int(value) for value in payload["selected_positions"]
        )
        if positions != expected_positions:
            raise ValueError("RRSeq_gap selected step positions disagree")
    else:
        raw_steps = _mapping_rows(payload.get("nodes"), field_name="nodes")
        steps = sorted(
            raw_steps,
            key=lambda row: _node_path(
                row["reaction_node_path"],
                field_name="reaction_node_path",
            ),
        )

    selected = tuple(
        SelectedReaction(
            reaction_node_path=_node_path(
                row["reaction_node_path"],
                field_name="reaction_node_path",
            ),
            reaction_smiles=str(row.get("reaction_smiles") or ""),
        )
        for row in steps
    )
    if not selected or any(not item.reaction_smiles for item in selected):
        raise ValueError(f"{kind} selected reactions require reaction_smiles")
    selected_paths = tuple(item.reaction_node_path for item in selected)
    if len(selected_paths) != len(set(selected_paths)):
        raise ValueError(f"{kind} selected reaction paths must be unique")
    if set(selected_paths) != set(occurrence.selected_reaction_node_paths):
        raise ValueError(f"{kind} selected paths disagree with tactic provenance")
    return selected


def rrseq_class_identity_payload(
    kind: str,
    tier3_codes: Sequence[str],
    *,
    provider: str,
    taxonomy: str,
) -> dict[str, Any]:
    """Return an ordered provider-scoped RRSeq class identity."""

    if kind not in {"rrseq_cons", "rrseq_gap"}:
        raise ValueError(f"unsupported RRSeq class kind: {kind!r}")
    codes = tuple(str(code) for code in tier3_codes)
    if len(codes) < 2 or any(not code for code in codes):
        raise ValueError("RRSeq class identities require at least two class codes")
    return {
        "schema_version": CLASS_IDENTITY_SCHEMA_VERSION,
        "provider": str(provider),
        "taxonomy": str(taxonomy),
        "tier": 3,
        "kind": kind,
        "motif": {"family": "rrseq", "tier3_codes": list(codes)},
    }


def rrsubtree_class_identity_payload(
    kind: str,
    native_payload: Mapping[str, Any],
    tier3_code_by_path: Mapping[tuple[int, ...], str],
    *,
    provider: str,
    taxonomy: str,
) -> dict[str, Any]:
    """Return a recursively canonicalized RRSubtree class identity."""

    if kind not in {"rrsubtree_cons", "rrsubtree_gap"}:
        raise ValueError(f"unsupported RRSubtree class kind: {kind!r}")
    node_rows = _mapping_rows(native_payload.get("nodes"), field_name="nodes")
    edge_rows = _mapping_rows(native_payload.get("edges"), field_name="edges")
    nodes = {
        _node_path(row["reaction_node_path"], field_name="reaction_node_path"): row
        for row in node_rows
    }
    if len(nodes) != len(node_rows):
        raise ValueError("RRSubtree node paths must be unique")
    root = _node_path(
        native_payload["root_reaction_node_path"],
        field_name="root_reaction_node_path",
    )
    if root not in nodes:
        raise ValueError("RRSubtree root is not a selected node")
    if set(tier3_code_by_path) != set(nodes):
        raise ValueError("RRSubtree class labels must cover every selected node")

    children: dict[tuple[int, ...], list[tuple[tuple[int, ...], int]]] = {
        path: [] for path in nodes
    }
    indegree = {path: 0 for path in nodes}
    skipped_paths: set[tuple[int, ...]] = set()
    for row in edge_rows:
        parent = _node_path(
            row["parent_reaction_node_path"],
            field_name="parent_reaction_node_path",
        )
        child = _node_path(
            row["child_reaction_node_path"],
            field_name="child_reaction_node_path",
        )
        if parent not in nodes or child not in nodes:
            raise ValueError("RRSubtree edge endpoints must be selected nodes")
        raw_skips = row.get("skipped_reaction_node_paths", ())
        if not isinstance(raw_skips, Sequence) or isinstance(raw_skips, (str, bytes)):
            raise ValueError("skipped_reaction_node_paths must be a sequence")
        edge_skips = tuple(
            _node_path(path, field_name="skipped_reaction_node_path")
            for path in raw_skips
        )
        if skipped_paths.intersection(edge_skips):
            raise ValueError("skipped reaction paths cannot belong to two edges")
        skipped_paths.update(edge_skips)
        children[parent].append((child, len(edge_skips)))
        indegree[child] += 1

    if len(edge_rows) != len(nodes) - 1:
        raise ValueError("RRSubtree must contain nodes - 1 logical edges")
    if indegree[root] != 0 or any(
        degree != 1 for path, degree in indegree.items() if path != root
    ):
        raise ValueError("RRSubtree edges must form one rooted tree")
    if len(children[root]) < 2:
        raise ValueError("RRSubtree root requires at least two child arms")
    has_gap = bool(skipped_paths)
    if kind == "rrsubtree_cons" and has_gap:
        raise ValueError("RRSubtree_cons cannot contain skipped reactions")
    if kind == "rrsubtree_gap" and not has_gap:
        raise ValueError("RRSubtree_gap requires a skipped reaction")

    visiting: set[tuple[int, ...]] = set()
    visited: set[tuple[int, ...]] = set()

    def visit(path: tuple[int, ...]) -> dict[str, Any]:
        if path in visiting:
            raise ValueError("RRSubtree contains a cycle")
        visiting.add(path)
        branches = [
            {
                "skipped_reaction_count": skipped_count,
                "child": visit(child),
            }
            for child, skipped_count in children[path]
        ]
        branches.sort(key=canonical_json)
        visiting.remove(path)
        visited.add(path)
        return {
            "tier3_code": str(tier3_code_by_path[path]),
            "children": branches,
        }

    class_root = visit(root)
    if visited != set(nodes):
        raise ValueError("RRSubtree contains nodes disconnected from its root")
    return {
        "schema_version": CLASS_IDENTITY_SCHEMA_VERSION,
        "provider": str(provider),
        "taxonomy": str(taxonomy),
        "tier": 3,
        "kind": kind,
        "motif": {"family": "rrsubtree", "root": class_root},
    }


def _canonical_selected_reactions(
    occurrence: TacticOccurrence,
    *,
    timeout_seconds: float,
) -> tuple[tuple[SelectedReaction, str], ...]:
    rows: list[tuple[SelectedReaction, str]] = []
    for selected in _selected_reactions(occurrence):
        classifier_key, _error = _classifier_key(
            selected.reaction_smiles,
            timeout_seconds,
        )
        rows.append((selected, classifier_key))
    return tuple(rows)


class ReactionCanonicalizationTimeout(TimeoutError):
    """Raised when Chython does not prepare one classifier input in time."""


@contextmanager
def _canonicalization_deadline(seconds: float):
    if seconds <= 0 or not hasattr(signal, "setitimer"):
        yield
        return

    def expired(_signum, _frame):
        raise ReactionCanonicalizationTimeout(
            f"reaction canonicalization exceeded {seconds:g} seconds"
        )

    previous_handler = signal.signal(signal.SIGALRM, expired)
    previous_timer = signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, *previous_timer)
        signal.signal(signal.SIGALRM, previous_handler)


@lru_cache(maxsize=None)
def _classifier_key(
    reaction_smiles: str,
    timeout_seconds: float = DEFAULT_CANONICALIZATION_TIMEOUT,
) -> tuple[str, str]:
    """Return a canonical input or a stable key for a preparation failure."""

    try:
        with _canonicalization_deadline(float(timeout_seconds)):
            classifier_input = chemistry.canonical_unmapped_reaction_string(
                reaction_smiles
            )
            if not classifier_input or ">>" not in classifier_input:
                raise ValueError("canonical classifier input is empty or invalid")
    except Exception as exc:
        digest = hashlib.sha256(reaction_smiles.encode("utf-8")).hexdigest()
        return f"canonicalization_error:{digest}", f"{type(exc).__name__}: {exc}"
    return classifier_input, ""


def _collision_safe_record_ids(inputs: Sequence[str]) -> dict[str, str]:
    buckets: dict[str, list[str]] = defaultdict(list)
    for classifier_input in inputs:
        buckets[record_id(classifier_input)].append(classifier_input)
    assigned: dict[str, str] = {}
    for base_id, values in sorted(buckets.items()):
        ordered = sorted(values)
        for ordinal, classifier_input in enumerate(ordered):
            assigned[classifier_input] = (
                base_id if len(ordered) == 1 else f"{base_id}~{ordinal:04d}"
            )
    return assigned


def _collect_unique_reactions(
    libraries: Mapping[str, ReferenceTacticLibrary],
    *,
    timeout_seconds: float,
) -> tuple[dict[str, str], dict[str, str]]:
    mapped_reactions: set[str] = set()
    for side in ("left", "right"):
        library = libraries[side]
        for kind in TACTIC_KINDS:
            for occurrence in library.iter_occurrences(kind=kind):
                mapped_reactions.update(
                    selected.reaction_smiles
                    for selected in _selected_reactions(occurrence)
                )

    mapped_by_key: dict[str, str] = {}
    errors_by_key: dict[str, str] = {}
    total = len(mapped_reactions)
    print(
        f"[reaction-class overlap] canonicalizing {total} unique mapped reactions",
        file=sys.stderr,
        flush=True,
    )
    for index, mapped_reaction in enumerate(sorted(mapped_reactions), start=1):
        classifier_key, error = _classifier_key(
            mapped_reaction,
            timeout_seconds,
        )
        mapped_by_key.setdefault(classifier_key, mapped_reaction)
        if error:
            errors_by_key.setdefault(classifier_key, error)
        if index % 500 == 0 or index == total:
            print(
                f"\r[reaction-class overlap] canonicalized {index}/{total}",
                end="",
                file=sys.stderr,
                flush=True,
            )
    if total:
        print(file=sys.stderr, flush=True)
    return mapped_by_key, errors_by_key


def _classify_unique_reactions(
    mapped_by_key: Mapping[str, str],
    canonicalization_errors: Mapping[str, str],
    *,
    provider: ReactionClassProvider,
    n_cpu: int,
    batch_size: int,
) -> dict[str, ReactionClassResult]:
    inputs = sorted(set(mapped_by_key) - set(canonicalization_errors))
    ids = _collision_safe_record_ids(inputs)
    input_by_id = {value: key for key, value in ids.items()}
    results_by_input: dict[str, ReactionClassResult] = {}
    completed = 0
    for offset in range(0, len(inputs), batch_size):
        selected_inputs = inputs[offset : offset + batch_size]
        records = [
            ReactionRecord(
                record_id=ids[classifier_input],
                mapped_reaction=mapped_by_key[classifier_input],
                classifier_input=classifier_input,
            )
            for classifier_input in selected_inputs
        ]
        results = provider.classify_many(
            records,
            n_cpu=n_cpu,
            worker_chunksize=batch_size,
        )
        reconciled = reconcile_batch_results(
            (record.record_id for record in records),
            results,
            ignore_errors=False,
        )
        missing = sorted(
            set(record.record_id for record in records) - set(reconciled.result_by_id)
        )
        if missing:
            raise RuntimeError(
                "reaction-class provider omitted submitted records: "
                + ", ".join(missing[:3])
            )
        for result_id, result in reconciled.result_by_id.items():
            if str(result.status) == "error" or result.error:
                raise RuntimeError(
                    f"reaction-class provider failed for {result_id}: "
                    f"{result.error or result.status}"
                )
            results_by_input[input_by_id[result_id]] = result
        completed += len(records)
        print(
            f"\r[reaction-class overlap] classified {completed}/{len(inputs)} "
            "unique reactions",
            end="",
            file=sys.stderr,
            flush=True,
        )
    if inputs:
        print(file=sys.stderr, flush=True)
    provider_name, provider_version, taxonomy = provider_metadata(provider)
    for classifier_key, error in canonicalization_errors.items():
        digest = classifier_key.partition(":")[2]
        results_by_input[classifier_key] = ReactionClassResult(
            record_id=f"rxn_error_{digest[:24]}",
            provider_name=provider_name,
            provider_version=provider_version,
            taxonomy_id=taxonomy,
            status="canonicalization_error",
            diagnostics={"reason": error},
            accepted=False,
            error=error,
        )
    return results_by_input


def _route_key(occurrence: TacticOccurrence) -> str:
    return canonical_json(occurrence.route.to_dict())


def _class_identity_for_occurrence(
    occurrence: TacticOccurrence,
    classifications: Mapping[str, ReactionClassResult],
    *,
    provider: str,
    taxonomy: str,
    canonicalization_timeout: float,
) -> tuple[dict[str, Any] | None, int, int]:
    selected = _canonical_selected_reactions(
        occurrence,
        timeout_seconds=canonicalization_timeout,
    )
    labels: dict[tuple[int, ...], str] = {}
    for reaction, classifier_input in selected:
        result = classifications[classifier_input]
        if result_accepted(result):
            labels[reaction.reaction_node_path] = str(result.tier3_code)
    if len(labels) != len(selected):
        return None, len(selected), len(labels)
    kind = occurrence.identity.kind
    if kind.startswith("rrseq_"):
        payload = rrseq_class_identity_payload(
            kind,
            tuple(labels[reaction.reaction_node_path] for reaction, _ in selected),
            provider=provider,
            taxonomy=taxonomy,
        )
    else:
        payload = rrsubtree_class_identity_payload(
            kind,
            occurrence.native_payload,
            labels,
            provider=provider,
            taxonomy=taxonomy,
        )
    return payload, len(selected), len(labels)


def _aggregate_class_families(
    libraries: Mapping[str, ReferenceTacticLibrary],
    classifications: Mapping[str, ReactionClassResult],
    *,
    provider: str,
    taxonomy: str,
    canonicalization_timeout: float,
) -> tuple[
    dict[str, dict[str, FamilySupport]],
    dict[str, dict[str, CoverageAccumulator]],
]:
    families: dict[str, dict[str, FamilySupport]] = {kind: {} for kind in TACTIC_KINDS}
    coverage: dict[str, dict[str, CoverageAccumulator]] = {
        kind: {
            "left": CoverageAccumulator(),
            "right": CoverageAccumulator(),
        }
        for kind in TACTIC_KINDS
    }
    for side in ("left", "right"):
        library = libraries[side]
        for kind in TACTIC_KINDS:
            stats = coverage[kind][side]
            for occurrence in library.iter_occurrences(kind=kind):
                route_key = _route_key(occurrence)
                stats.total_occurrences += 1
                stats.all_routes.add(route_key)
                payload, total_steps, classified_steps = _class_identity_for_occurrence(
                    occurrence,
                    classifications,
                    provider=provider,
                    taxonomy=taxonomy,
                    canonicalization_timeout=canonicalization_timeout,
                )
                stats.total_selected_reaction_uses += total_steps
                stats.classified_selected_reaction_uses += classified_steps
                if payload is None:
                    stats.routes_with_excluded_occurrences.add(route_key)
                    continue
                stats.included_occurrences += 1
                stats.included_routes.add(route_key)
                encoded = canonical_json(payload)
                support = families[kind].setdefault(encoded, FamilySupport())
                support.routes[side].add(route_key)
                support.occurrences[side].add(occurrence.reference_occurrence_id)
    return families, coverage


def _class_ids(payloads: Iterable[str]) -> dict[str, str]:
    buckets: dict[str, list[str]] = defaultdict(list)
    for payload in payloads:
        digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
        buckets[digest].append(payload)
    result: dict[str, str] = {}
    for digest, values in sorted(buckets.items()):
        for ordinal, payload in enumerate(sorted(values)):
            result[payload] = f"rxnclass_i_{digest}~{ordinal:04d}"
    return result


def _report_rows(families: Mapping[str, FamilySupport]) -> list[dict[str, Any]]:
    identifiers = _class_ids(families)
    rows: list[dict[str, Any]] = []
    for payload, support in families.items():
        left_count = len(support.routes["left"])
        right_count = len(support.routes["right"])
        if left_count and right_count:
            region = "shared"
        elif left_count:
            region = "left_only"
        else:
            region = "right_only"
        rows.append(
            {
                "region": region,
                "class_identity_id": identifiers[payload],
                "class_identity_json": payload,
                "left_popularity": left_count,
                "right_popularity": right_count,
                "left_occurrence_count": len(support.occurrences["left"]),
                "right_occurrence_count": len(support.occurrences["right"]),
            }
        )
    rows.sort(
        key=lambda row: (
            REGION_ORDER[str(row["region"])],
            -max(int(row["left_popularity"]), int(row["right_popularity"])),
            str(row["class_identity_id"]),
        )
    )
    return rows


def _panel_counts(rows: Sequence[Mapping[str, Any]]) -> dict[str, int]:
    counts = {
        region: sum(row["region"] == region for row in rows) for region in REGION_ORDER
    }
    return {
        **counts,
        "left_total": counts["left_only"] + counts["shared"],
        "right_total": counts["right_only"] + counts["shared"],
        "union": len(rows),
    }
