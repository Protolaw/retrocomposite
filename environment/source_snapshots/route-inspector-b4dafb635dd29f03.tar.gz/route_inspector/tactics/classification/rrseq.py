"""Classify the source reactions underlying consecutive RRSeq aggregates.

This module deliberately consumes the versioned RRSeq occurrence sidecar rather
than reconstructing occurrences from route JSON.  An aggregate TSV row can be a
QueryCGR-merged representative of several display-SMARTS strings, so row identity
is the pair ``(resolved source TSV, zero-based row index)`` throughout the join."""

from __future__ import annotations

import json
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from route_inspector import chemistry
from route_inspector.chemistry.classification.common import diagnostics as _diagnostics
from route_inspector.chemistry.classification.common import (
    reconcile_batch_results as _reconcile_batch_results,
)
from route_inspector.chemistry.classification.common import record_id as _record_id
from route_inspector.chemistry.classification.common import result_accepted
from route_inspector.chemistry.classification.common import result_attr as _result_attr
from route_inspector.chemistry.classification.common import valid_tier3 as _valid_tier3
from route_inspector.infrastructure.artifacts import (
    reference_sort_key,
)
from route_inspector.infrastructure.paths import relative_path
from route_inspector.infrastructure.text import read_tsv_rows
from route_inspector.tactics.rrseq.artifacts import (
    RRseqApplication,
    iter_rrseq_occurrence_applications,
)
from route_inspector.tactics.rrseq.naming import (
    RRSEQ_CONS_COLUMN,
    RRSEQ_CONS_KIND,
    find_rrseq_column,
)
from route_inspector.tactics.rrseq.unwrap import split_rrseq

UNCLASSIFIED = "UNCLASSIFIED"


RXN_CLASS_ERROR_FIELDS = [
    "dataset",
    "route_id",
    "reaction_steps",
    "reaction_smiles",
    "stage",
    "error_type",
    "message",
    "source_tsv",
    "source_row",
    "reaction_node_path",
    "occurrence_id",
]


REFERENCE_STEP_FIELDS = [
    "dataset",
    "source_tsv",
    "source_row",
    "rrseq_size",
    RRSEQ_CONS_COLUMN,
    "selected_occurrence_id",
    "route_id",
    "reaction_step",
    "step_index",
    "path_position",
    "reaction_node_path",
    "mapped_reaction",
    "classifier_input",
    "provider",
    "provider_version",
    "taxonomy",
    "raw_code",
    "raw_name",
    "tier3_code",
    "tier3_name",
    "diagnostic_code",
    "diagnostic_name",
    "confidence",
    "status",
    "accepted",
    "diagnostics",
    "error",
]


ANNOTATION_FIELDS = [
    "Rxn_class_sequence",
    "Rxn_class_names",
]


GENERALIZED_FIELDS = [
    "Rxn_class_sequence",
    "Rxn_class_names",
    "rrseq_size",
    "route_popularity",
    "occurrence_count",
    "template_variant_count",
    "Reference",
    "Target_molecules",
    "Source_rrseq_cons",
]


@dataclass(frozen=True)
class AggregateRow:
    """One post-QueryCGR-deduplication RRSeq TSV row."""

    source_tsv: Path
    row_index: int
    fieldnames: tuple[str, ...]
    values: Mapping[str, str]
    rrseq: str
    rrseq_size: int

    @property
    def key(self) -> tuple[Path, int]:
        return (self.source_tsv.resolve(), self.row_index)

    @property
    def source_row(self) -> int:
        """Return the human-readable TSV line number, including the header."""

        return self.row_index + 2


@dataclass
class StepOutcome:
    """One selected source step and its normalized provider result."""

    aggregate: AggregateRow
    application: RRseqApplication
    source_match: Mapping[str, Any]
    mapped_reaction: str
    classifier_input: str = ""
    record_id: str = ""
    result: Any | None = None
    error: str = ""

    @property
    def step_index(self) -> int:
        return int(self.source_match["step_index"])

    @property
    def path_position(self) -> int:
        return int(self.source_match["path_position"])

    @property
    def reaction_step(self) -> str:
        return f"r{self.path_position + 1}"

    @property
    def reaction_node_path(self) -> tuple[int, ...]:
        return tuple(int(value) for value in self.source_match["reaction_node_path"])


@dataclass(frozen=True)
class AnnotatedAggregate:
    aggregate: AggregateRow
    application: RRseqApplication
    steps: tuple[StepOutcome, ...]
    class_sequence: tuple[str, ...]
    class_names: tuple[str, ...]
    complete: bool
    provider: str
    provider_version: str
    taxonomy: str


def _existing_files(paths: Iterable[Path], *, label: str) -> list[Path]:
    values = list(paths)
    if not values:
        raise ValueError(f"no {label} files were found")
    missing = [str(path) for path in values if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"missing {label} file(s): {', '.join(missing)}")
    return values


def _load_aggregate_rows(tsv_paths: Sequence[Path]) -> list[AggregateRow]:
    aggregates: list[AggregateRow] = []
    for source_tsv in sorted(tsv_paths, key=lambda value: str(value.resolve())):
        fieldnames, rows = read_tsv_rows(source_tsv)
        sequence_column = find_rrseq_column(fieldnames, kind=RRSEQ_CONS_KIND)
        if sequence_column is None:
            raise ValueError(f"{source_tsv} has no {RRSEQ_CONS_COLUMN} column")
        required = {"Reference", "Target_molecules"}
        missing = sorted(required - set(fieldnames))
        if missing:
            raise ValueError(
                f"{source_tsv} lacks exact-provenance columns: {', '.join(missing)}"
            )
        for row_index, values in enumerate(rows):
            rrseq = (values.get(sequence_column) or "").strip()
            if not rrseq:
                raise ValueError(
                    f"empty {sequence_column} at {source_tsv}:{row_index + 2}"
                )
            rrseq_size = len(split_rrseq(rrseq))
            if rrseq_size < 2:
                raise ValueError(
                    "reaction-class sequence analysis requires multi-step "
                    f"RRseq_cons rows: {source_tsv}:{row_index + 2}"
                )
            aggregates.append(
                AggregateRow(
                    source_tsv=source_tsv,
                    row_index=row_index,
                    fieldnames=tuple(fieldnames),
                    values=dict(values),
                    rrseq=rrseq,
                    rrseq_size=rrseq_size,
                )
            )
    return aggregates


def _reference_key(application: RRseqApplication) -> tuple[Any, ...]:
    """Return the documented deterministic representative-occurrence key."""

    required = {
        "route_id": application.route_id,
        "root_index": application.root_index,
        "start_position": application.start_position,
        "branch_index": application.branch_index,
        "occurrence_id": application.occurrence_id,
    }
    missing = [name for name, value in required.items() if value is None]
    if missing or not application.reaction_node_paths:
        missing.extend(
            [] if application.reaction_node_paths else ["reaction_node_paths"]
        )
        raise ValueError(
            "RRSeq occurrence lacks exact representative-selection fields: "
            + ", ".join(missing)
        )
    return (
        reference_sort_key(application.route_id),
        int(application.root_index),
        int(application.start_position),
        tuple(
            tuple(int(value) for value in path)
            for path in application.reaction_node_paths
        ),
        int(application.branch_index),
        str(application.occurrence_id),
    )


def _validate_application(
    aggregate: AggregateRow,
    application: RRseqApplication,
) -> None:
    if application.provenance_quality != "exact":
        raise ValueError(
            "reaction classification requires exact RRSeq occurrence provenance"
        )
    if application.rrseq_size != aggregate.rrseq_size:
        raise ValueError(
            "RRSeq occurrence length does not match aggregate row at "
            f"{aggregate.source_tsv}:{aggregate.source_row}"
        )
    if len(application.source_matches) != aggregate.rrseq_size:
        raise ValueError(
            "RRSeq occurrence source-match count does not match aggregate row at "
            f"{aggregate.source_tsv}:{aggregate.source_row}"
        )
    _reference_key(application)
    sorted_matches = sorted(
        application.source_matches,
        key=lambda match: int(match.get("step_index", -1)),
    )
    step_indexes = [int(match.get("step_index", -1)) for match in sorted_matches]
    if step_indexes != list(range(aggregate.rrseq_size)):
        raise ValueError(
            "RRSeq occurrence source matches do not have one ordered match per step "
            f"at {aggregate.source_tsv}:{aggregate.source_row}"
        )
    for match in sorted_matches:
        if not str(match.get("reaction_smiles") or "").strip():
            raise ValueError(
                "RRSeq occurrence has an empty source reaction at "
                f"{aggregate.source_tsv}:{aggregate.source_row}"
            )
        if (
            match.get("path_position") is None
            or match.get("reaction_node_path") is None
        ):
            raise ValueError(
                "RRSeq occurrence source match lacks route-step provenance at "
                f"{aggregate.source_tsv}:{aggregate.source_row}"
            )


def _applications_by_row(
    tsv_paths: Sequence[Path],
    occurrence_paths: Sequence[Path],
    aggregates: Sequence[AggregateRow],
) -> dict[tuple[Path, int], list[RRseqApplication]]:
    allowed_keys = {aggregate.key for aggregate in aggregates}
    applications: dict[tuple[Path, int], list[RRseqApplication]] = defaultdict(list)
    for application in iter_rrseq_occurrence_applications(tsv_paths, occurrence_paths):
        key = (application.source_tsv.resolve(), application.row_index)
        if key in allowed_keys:
            applications[key].append(application)

    missing = [aggregate for aggregate in aggregates if not applications[aggregate.key]]
    if missing:
        examples = ", ".join(
            f"{aggregate.source_tsv}:{aggregate.source_row}"
            for aggregate in missing[:10]
        )
        suffix = "" if len(missing) <= 10 else f" (and {len(missing) - 10} more)"
        raise ValueError(
            "authoritative occurrence provenance did not link every RRseq_cons row: "
            + examples
            + suffix
        )

    for aggregate in aggregates:
        seen: set[str] = set()
        for application in applications[aggregate.key]:
            _validate_application(aggregate, application)
            occurrence_id = str(application.occurrence_id)
            if occurrence_id in seen:
                raise ValueError(
                    "duplicate occurrence linked to one RRseq_cons row: "
                    f"{aggregate.source_tsv}:{aggregate.source_row} ({occurrence_id})"
                )
            seen.add(occurrence_id)
    return applications


def _step_error(
    dataset: str,
    step: StepOutcome,
    *,
    error_type: str,
    message: str,
) -> dict[str, Any]:
    return {
        "dataset": dataset,
        "route_id": step.application.route_id or "",
        "reaction_steps": step.reaction_step,
        "reaction_smiles": step.mapped_reaction,
        "stage": "rxnclass_rrseqs",
        "error_type": error_type,
        "message": message,
        "source_tsv": relative_path(step.aggregate.source_tsv),
        "source_row": step.aggregate.source_row,
        "reaction_node_path": json.dumps(list(step.reaction_node_path)),
        "occurrence_id": step.application.occurrence_id or "",
    }


def _accepted(step: StepOutcome) -> bool:
    return result_accepted(step.result, error=step.error)


def _steps_for_references(
    aggregates: Sequence[AggregateRow],
    applications: Mapping[tuple[Path, int], Sequence[RRseqApplication]],
) -> tuple[list[StepOutcome], dict[tuple[Path, int], RRseqApplication]]:
    selected: dict[tuple[Path, int], RRseqApplication] = {}
    steps: list[StepOutcome] = []
    for aggregate in aggregates:
        application = min(applications[aggregate.key], key=_reference_key)
        selected[aggregate.key] = application
        for source_match in sorted(
            application.source_matches,
            key=lambda match: int(match["step_index"]),
        ):
            steps.append(
                StepOutcome(
                    aggregate=aggregate,
                    application=application,
                    source_match=source_match,
                    mapped_reaction=str(source_match["reaction_smiles"]).strip(),
                )
            )
    return steps, selected


def _classify_unique_reactions(
    steps: Sequence[StepOutcome],
    *,
    provider: Any,
    dataset: str,
    n_cpu: int,
    worker_chunksize: int,
    progress_interval: int,
    ignore_errors: bool,
) -> tuple[list[dict[str, Any]], int, int]:
    """Canonicalize, globally deduplicate, classify, and fan out results."""

    from route_inspector.chemistry.classification.providers import ReactionRecord

    errors: list[dict[str, Any]] = []
    first_mapped_by_input: dict[str, str] = {}
    steps_by_input: dict[str, list[StepOutcome]] = defaultdict(list)
    for step in steps:
        try:
            step.classifier_input = chemistry.canonical_unmapped_reaction_string(
                step.mapped_reaction
            )
            if not step.classifier_input or ">>" not in step.classifier_input:
                raise ValueError("canonical reaction is empty or has no reaction arrow")
            step.record_id = _record_id(step.classifier_input)
            first_mapped_by_input.setdefault(
                step.classifier_input, step.mapped_reaction
            )
            steps_by_input[step.classifier_input].append(step)
        except Exception as exc:
            step.error = str(exc)
            errors.append(
                _step_error(
                    dataset,
                    step,
                    error_type=type(exc).__name__,
                    message=f"could not canonicalize classifier input: {exc}",
                )
            )
            if not ignore_errors:
                raise ValueError(
                    f"failed to canonicalize {dataset} route "
                    f"{step.application.route_id} {step.reaction_step}: {exc}"
                ) from exc

    records = [
        ReactionRecord(
            record_id=_record_id(classifier_input),
            mapped_reaction=first_mapped_by_input[classifier_input],
            classifier_input=classifier_input,
        )
        for classifier_input in sorted(first_mapped_by_input)
    ]
    progress_every = max(0, int(progress_interval))
    last_reported = 0

    def report_progress(completed: int, total: int) -> None:
        nonlocal last_reported
        if progress_every <= 0:
            return
        if completed == total or completed - last_reported >= progress_every:
            print(
                f"[classify-rrseq-cons-reactions] classified {completed}/"
                f"{total} unique reactions",
                file=sys.stderr,
                flush=True,
            )
            last_reported = completed

    if progress_every > 0:
        print(
            "[classify-rrseq-cons-reactions] prepared "
            f"{len(records)} unique reactions from {len(steps)} selected steps",
            file=sys.stderr,
            flush=True,
        )

    try:
        results = provider.classify_many(
            records,
            n_cpu=n_cpu,
            worker_chunksize=worker_chunksize,
            progress_callback=report_progress if progress_every > 0 else None,
        )
    except Exception:
        if not ignore_errors:
            raise
        message = "provider batch failed: " + str(sys.exc_info()[1])
        results = []
        for classifier_input, matching_steps in steps_by_input.items():
            for step in matching_steps:
                step.error = message
                errors.append(
                    _step_error(
                        dataset,
                        step,
                        error_type="ProviderBatchError",
                        message=message,
                    )
                )

    reconciliation = _reconcile_batch_results(
        (record.record_id for record in records),
        results,
        ignore_errors=ignore_errors,
    )
    result_by_id = reconciliation.result_by_id
    duplicates = reconciliation.duplicate_ids
    unexpected = reconciliation.unexpected_ids
    empty_result_ids = reconciliation.empty_result_ids
    for duplicate_id in duplicates:
        for matching_steps in steps_by_input.values():
            for step in matching_steps:
                if step.record_id != duplicate_id:
                    continue
                step.error = "reaction-class provider returned a duplicate record ID"
                errors.append(
                    _step_error(
                        dataset,
                        step,
                        error_type="DuplicateProviderResult",
                        message=step.error,
                    )
                )
    for result_id in sorted(unexpected):
        errors.append(
            {
                "dataset": dataset,
                "route_id": "",
                "reaction_steps": "",
                "reaction_smiles": "",
                "stage": "rxnclass_rrseqs",
                "error_type": "UnexpectedProviderResult",
                "message": f"provider returned unknown record ID {result_id}",
                "source_tsv": "",
                "source_row": "",
                "reaction_node_path": "",
                "occurrence_id": "",
            }
        )
    for _index in range(empty_result_ids):
        errors.append(
            {
                "dataset": dataset,
                "route_id": "",
                "reaction_steps": "",
                "reaction_smiles": "",
                "stage": "rxnclass_rrseqs",
                "error_type": "EmptyProviderRecordId",
                "message": "provider returned an empty record ID",
                "source_tsv": "",
                "source_row": "",
                "reaction_node_path": "",
                "occurrence_id": "",
            }
        )

    for classifier_input, matching_steps in steps_by_input.items():
        record_id = _record_id(classifier_input)
        result = result_by_id.get(record_id)
        for step in matching_steps:
            if step.error:
                continue
            step.result = result
            if result is None:
                step.error = "reaction-class provider returned no result"
                errors.append(
                    _step_error(
                        dataset,
                        step,
                        error_type="MissingProviderResult",
                        message=step.error,
                    )
                )
            elif bool(_result_attr(result, "accepted", False)) and not _valid_tier3(
                str(_result_attr(result, "tier3_code", ""))
            ):
                step.error = "provider accepted a non-numeric or non-Tier-3 code"
                errors.append(
                    _step_error(
                        dataset,
                        step,
                        error_type="InvalidProviderResult",
                        message=step.error,
                    )
                )
            elif str(_result_attr(result, "status", "")) == "error" or str(
                _result_attr(result, "error", "")
            ):
                step.error = str(
                    _result_attr(result, "error", "provider classification failed")
                )
                errors.append(
                    _step_error(
                        dataset,
                        step,
                        error_type="ProviderClassificationError",
                        message=step.error,
                    )
                )

            if step.error and not ignore_errors:
                raise RuntimeError(
                    f"classification failed for {dataset} route "
                    f"{step.application.route_id} {step.reaction_step}: {step.error}"
                )

    unique_mapped = len({step.mapped_reaction for step in steps})
    return errors, unique_mapped, len(records)


def _annotate_aggregates(
    aggregates: Sequence[AggregateRow],
    selected: Mapping[tuple[Path, int], RRseqApplication],
    steps: Sequence[StepOutcome],
    *,
    default_provider: str,
    default_provider_version: str,
    default_taxonomy: str,
) -> list[AnnotatedAggregate]:
    steps_by_row: dict[tuple[Path, int], list[StepOutcome]] = defaultdict(list)
    for step in steps:
        steps_by_row[step.aggregate.key].append(step)

    annotated: list[AnnotatedAggregate] = []
    for aggregate in aggregates:
        row_steps = sorted(
            steps_by_row[aggregate.key], key=lambda step: step.step_index
        )
        class_sequence = tuple(
            str(_result_attr(step.result, "tier3_code", ""))
            if _accepted(step)
            else UNCLASSIFIED
            for step in row_steps
        )
        class_names = tuple(
            str(_result_attr(step.result, "tier3_name", "")) or class_code
            if class_code != UNCLASSIFIED
            else UNCLASSIFIED
            for step, class_code in zip(row_steps, class_sequence)
        )
        accepted_results = [step.result for step in row_steps if _accepted(step)]
        providers = {
            str(_result_attr(result, "provider_name", default_provider))
            for result in accepted_results
        }
        versions = {
            str(_result_attr(result, "provider_version", default_provider_version))
            for result in accepted_results
        }
        taxonomies = {
            str(_result_attr(result, "taxonomy_id", default_taxonomy))
            for result in accepted_results
        }
        complete = (
            len(row_steps) == aggregate.rrseq_size
            and all(value != UNCLASSIFIED for value in class_sequence)
            and len(providers) <= 1
            and len(taxonomies) <= 1
        )
        annotated.append(
            AnnotatedAggregate(
                aggregate=aggregate,
                application=selected[aggregate.key],
                steps=tuple(row_steps),
                class_sequence=class_sequence,
                class_names=class_names,
                complete=complete,
                provider=next(iter(sorted(providers)), default_provider),
                provider_version=next(iter(sorted(versions)), default_provider_version),
                taxonomy=next(iter(sorted(taxonomies)), default_taxonomy),
            )
        )
    return annotated


def _diagnostic_value(result: Any | None, key: str) -> str:
    value = _diagnostics(result).get(key, "")
    return "" if value is None else str(value)


def _reference_step_rows(
    annotated: Sequence[AnnotatedAggregate],
    *,
    dataset: str,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in annotated:
        for step in item.steps:
            result = step.result
            rows.append(
                {
                    "dataset": dataset,
                    "source_tsv": relative_path(item.aggregate.source_tsv),
                    "source_row": item.aggregate.source_row,
                    "rrseq_size": item.aggregate.rrseq_size,
                    RRSEQ_CONS_COLUMN: item.aggregate.rrseq,
                    "selected_occurrence_id": item.application.occurrence_id or "",
                    "route_id": item.application.route_id or "",
                    "reaction_step": step.reaction_step,
                    "step_index": step.step_index,
                    "path_position": step.path_position,
                    "reaction_node_path": json.dumps(list(step.reaction_node_path)),
                    "mapped_reaction": step.mapped_reaction,
                    "classifier_input": step.classifier_input,
                    "provider": str(
                        _result_attr(result, "provider_name", item.provider)
                    ),
                    "provider_version": str(
                        _result_attr(result, "provider_version", item.provider_version)
                    ),
                    "taxonomy": str(_result_attr(result, "taxonomy_id", item.taxonomy)),
                    "raw_code": str(_result_attr(result, "raw_code", "")),
                    "raw_name": str(_result_attr(result, "raw_name", "")),
                    "tier3_code": (
                        str(_result_attr(result, "tier3_code", ""))
                        if _accepted(step)
                        else UNCLASSIFIED
                    ),
                    "tier3_name": (
                        str(_result_attr(result, "tier3_name", ""))
                        if _accepted(step)
                        else UNCLASSIFIED
                    ),
                    "diagnostic_code": _diagnostic_value(result, "neural_code")
                    or _diagnostic_value(result, "diagnostic_code"),
                    "diagnostic_name": _diagnostic_value(result, "neural_name")
                    or _diagnostic_value(result, "diagnostic_name"),
                    "confidence": _result_attr(result, "confidence", ""),
                    "status": str(
                        _result_attr(
                            result,
                            "status",
                            "error" if step.error else "unclassified",
                        )
                    ),
                    "accepted": "true" if _accepted(step) else "false",
                    "diagnostics": json.dumps(
                        _diagnostics(result), sort_keys=True, separators=(",", ":")
                    ),
                    "error": step.error or str(_result_attr(result, "error", "")),
                }
            )
    return rows


def _annotated_row(item: AnnotatedAggregate) -> dict[str, Any]:
    row = dict(item.aggregate.values)
    row.update(
        {
            "Rxn_class_sequence": "$".join(item.class_sequence),
            "Rxn_class_names": "$".join(item.class_names),
        }
    )
    return row


def _generalized_rows(
    annotated: Sequence[AnnotatedAggregate],
    applications: Mapping[tuple[Path, int], Sequence[RRseqApplication]],
) -> dict[int, list[dict[str, Any]]]:
    aggregates: dict[tuple[str, str, tuple[str, ...]], dict[str, Any]] = {}
    for item in annotated:
        if not item.complete:
            continue
        key = (item.provider, item.taxonomy, item.class_sequence)
        aggregate = aggregates.setdefault(
            key,
            {
                "class_sequence": item.class_sequence,
                "class_names": set(),
                "route_ids": set(),
                "occurrence_ids": set(),
                "targets": set(),
                "row_keys": set(),
                "source_rrseqs": set(),
            },
        )
        aggregate["class_names"].add(item.class_names)
        aggregate["row_keys"].add(item.aggregate.key)
        aggregate["source_rrseqs"].add(item.aggregate.rrseq)
        for occurrence in applications[item.aggregate.key]:
            if occurrence.route_id is not None:
                aggregate["route_ids"].add(str(occurrence.route_id))
            if occurrence.occurrence_id is not None:
                aggregate["occurrence_ids"].add(str(occurrence.occurrence_id))
            if occurrence.target_smiles:
                aggregate["targets"].add(occurrence.target_smiles)

    rows_by_size: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for aggregate in aggregates.values():
        route_ids = sorted(aggregate["route_ids"], key=reference_sort_key)
        class_sequence = aggregate["class_sequence"]
        class_names = min(aggregate["class_names"], key=lambda value: "$".join(value))
        rows_by_size[len(class_sequence)].append(
            {
                "Rxn_class_sequence": "$".join(class_sequence),
                "Rxn_class_names": "$".join(class_names),
                "rrseq_size": len(class_sequence),
                "route_popularity": len(route_ids),
                "occurrence_count": len(aggregate["occurrence_ids"]),
                "template_variant_count": len(aggregate["row_keys"]),
                "Reference": ",".join(route_ids),
                "Target_molecules": ",".join(sorted(aggregate["targets"])),
                "Source_rrseq_cons": json.dumps(
                    sorted(aggregate["source_rrseqs"]), separators=(",", ":")
                ),
            }
        )
    for size, rows in rows_by_size.items():
        rows.sort(
            key=lambda row: (
                -int(row["route_popularity"]),
                -int(row["template_variant_count"]),
                str(row["Rxn_class_sequence"]),
            )
        )
    return dict(rows_by_size)


__all__ = [
    "ANNOTATION_FIELDS",
    "GENERALIZED_FIELDS",
    "REFERENCE_STEP_FIELDS",
    "RXN_CLASS_ERROR_FIELDS",
    "UNCLASSIFIED",
]
