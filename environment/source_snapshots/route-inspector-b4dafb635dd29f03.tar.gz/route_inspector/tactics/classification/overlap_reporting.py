"""Compare n1/n5 tactic pools after Tier-3 reaction-class generalization.

The analysis consumes persisted occurrence provenance from two Reference tactic
libraries.  It classifies each distinct canonical, atom-map-free source reaction
once, then replaces the selected reaction in every RRSeq/RRSubtree occurrence by
its provider-specific Tier-3 code.  Composite rules are deliberately outside this
analysis because a net composite is not an elementary classifiable reaction."""

from __future__ import annotations

import csv
import hashlib
import json
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import asdict
from pathlib import Path
from typing import Any

from route_inspector.chemistry.classification.providers import (
    ReactionClassResult,
)
from route_inspector.reference_library.profile import canonical_json
from route_inspector.tactics.classification.overlap import REPORT_COLUMNS


def _write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        for row in rows:
            stream.write(canonical_json(row) + "\n")


def _write_tsv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=REPORT_COLUMNS, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def _artifact_descriptor(path: Path, root: Path) -> dict[str, Any]:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return {
        "path": path.relative_to(root).as_posix(),
        "sha256": digest.hexdigest(),
        "size_bytes": path.stat().st_size,
    }


def _classification_record(
    classifier_key: str,
    mapped_reaction: str,
    result: ReactionClassResult,
) -> dict[str, Any]:
    failed_preparation = classifier_key.startswith("canonicalization_error:")
    return {
        "record_id": result.record_id,
        "classifier_input": None if failed_preparation else classifier_key,
        "canonicalization_key": classifier_key,
        "mapped_reaction": mapped_reaction,
        **asdict(result),
    }
