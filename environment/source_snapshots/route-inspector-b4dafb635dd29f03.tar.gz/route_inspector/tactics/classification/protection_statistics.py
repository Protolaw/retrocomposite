"""Aggregate existing NameRXN reports; never rerun classification or extraction.

Run from the repository root with:
python -m scripts.aggregate_namerxn_protection_statistics --replace
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from urllib.parse import quote

COHORTS = (
    ("RRSeq_cons", "selected", "rrseq_cons_reaction_classes"),
    ("RRSeq_gap", "selected", "rrseq_gap_reaction_classes"),
    ("RRSubtree_cons", "selected", "rrsubtree_reaction_classes"),
    ("RRSubtree_gap", "selected", "rrsubtree_gap_reaction_classes"),
)
FIELDS = (
    "total",
    "with_protection",
    "with_deprotection",
    "with_both",
    "incompletely_classified",
)


def cell(value):
    return str(value).replace("|", "\\|").replace("\n", " ")


def link(path, output):
    return quote(os.path.relpath(path, output.parent), safe="/._-")


def aggregate(analysis_root: Path, output: Path, examples: Path | None = None):
    """Read all four cohorts and optional saved examples; return Markdown text."""
    observed = {}

    def load_json(path):
        raw = path.read_bytes()
        observed[path] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)

    def load_jsonl(path):
        raw = path.read_bytes()
        observed[path] = hashlib.sha256(raw).hexdigest()
        return [json.loads(line) for line in raw.splitlines()]

    cohorts = []
    library_ids = set()
    fingerprints = None
    for kind, scope, dirname in COHORTS:
        directory = analysis_root / dirname
        summary = load_json(directory / "summary.json")
        manifest = load_json(directory / "manifest.json")
        if manifest["status"] not in {"complete", "incomplete"}:
            raise ValueError(f"Analysis is not classified: {directory}")
        if (manifest["kind"], manifest["step_scope"]) != (kind.lower(), scope):
            raise ValueError(f"Unexpected cohort: {directory}")
        if summary["status"] != manifest["status"]:
            raise ValueError(f"Status mismatch: {directory}")
        library_ids.add(manifest["library_id"])
        # Compare recorded inputs without requiring the original checkout or binary.
        inputs = manifest["inputs_sha256"]
        if fingerprints is not None and inputs != fingerprints:
            raise ValueError(
                "Analyses have different recorded source/classifier inputs"
            )
        fingerprints = inputs
        for level in ("occurrences", "families"):
            counts = summary["presence_counts"][level]
            if counts["total"] != summary[level]:
                raise ValueError(f"Inconsistent {level} total: {directory}")
            if any(
                not isinstance(counts[k], int) or not 0 <= counts[k] <= counts["total"]
                for k in FIELDS
            ):
                raise ValueError(f"Invalid support counts: {directory}")
            if counts["with_both"] > min(
                counts["with_protection"], counts["with_deprotection"]
            ):
                raise ValueError(f"Invalid both-class count: {directory}")
        label = kind
        cohorts.append((label, directory, summary))
    if len(library_ids) != 1:
        raise ValueError("Analyses describe different reference libraries")

    lines = [
        f"# {cell(analysis_root.name)} NameRXN protection/deprotection statistics",
        "",
        "Recorded forward-reaction classes: 5 = protection; 6 = deprotection.",
        "",
        "Counts describe detected classes, not verified protecting-group lifetimes.",
        "",
    ]
    for level in ("occurrences", "families"):
        lines += [
            f"## {level.capitalize()}",
            "",
            "| Cohort | Total | Protection | Deprotection | Both | Incompletely classified |",
            "|---|---:|---:|---:|---:|---:|",
        ]
        for label, _, summary in cohorts:
            counts = summary["presence_counts"][level]
            lines.append(
                f"| {label} | " + " | ".join(f"{counts[k]:,}" for k in FIELDS) + " |"
            )
        lines.append("")
    lines += [
        "Protection and deprotection counts include both-class cases. Family flags are unions over occurrences; both classes need not occur in the same occurrence.",
        "",
        "## Classification coverage",
        "",
        "| Cohort | Distinct source reactions | Unclassified or partial reactions |",
        "|---|---:|---:|",
    ]
    for label, _, s in cohorts:
        lines.append(
            f"| {label} | {s['distinct_source_reactions']:,} | {s['unclassified_or_partial_reactions']:,} |"
        )
    lines += [
        "",
        "Incomplete classifications cannot establish absence; positive detections are lower bounds. Counts use only the selected reaction steps belonging to each tactic. Cohorts overlap and must not be summed.",
        "",
        "## Evidence",
        "",
    ]
    for label, directory, _ in cohorts:
        lines.append(
            f"- [{label}]({link(directory / 'statistics.md', output)}): source steps, occurrence provenance, and unclassified reactions are recorded in `steps.tsv`, `occurrences.jsonl`, and `errors.tsv`."
        )
    if examples is not None:
        lines += [
            "",
            "## Protection-free tactic examples",
            "",
            "All selected steps are classified with neither protection nor deprotection. This describes the tactic, not its entire route. Step labels follow route traversal, not a linear ordering across branches.",
            "",
        ]
        saved = load_json(examples)
        for example in saved:
            steps = example["selected_steps"]
            if not steps or any(
                not r["classification_complete"]
                or r["has_protection"]
                or r["has_deprotection"]
                for r in steps
            ):
                raise ValueError("Example is not fully classified protection-free")
            dirname = dict(
                (k.lower(), d) for k, scope, d in COHORTS if scope == "selected"
            )[example["kind"]]
            directory = analysis_root / dirname
            recorded = next(
                (
                    r
                    for r in load_jsonl(directory / "occurrences.jsonl")
                    if r["reference_occurrence_id"]
                    == example["reference_occurrence_id"]
                ),
                None,
            )
            if (
                recorded is None
                or recorded != example["occurrence"]
                or example["entry_id"] != recorded["entry_id"]
                or example["route_id"] != recorded["route_id"]
                or {r["step_id"] for r in steps} != set(recorded["step_ids"])
                or len(steps) != len(recorded["step_ids"])
            ):
                raise ValueError(
                    "Example does not match the current analysis occurrence"
                )
            source_steps = {
                r["step_id"]: r for r in load_jsonl(directory / "steps.jsonl")
            }
            if any(source_steps.get(r["step_id"]) != r for r in steps):
                raise ValueError(
                    "Example classifications differ from the recorded source steps"
                )
            lines += [
                f"### {cell(example['kind'])} — route {cell(example['route_id'])}",
                "",
                f"Full tactic ID: `{example['entry_id']}`",
                "",
                "| Selected step | NameRXN code | Class |",
                "|---|---|---|",
            ]
            for r in steps:
                lines.append(
                    f"| {cell(r['step_label'])} | {cell(r['raw_code'])} | {cell('; '.join(r['class_names']))} |"
                )
            lines.append("")
        lines.append(f"[Full example provenance]({link(examples, output)}).")
    lines += [
        "",
        "## Aggregation provenance",
        "",
        f"Reference library: `{next(iter(library_ids))}`.",
        "",
        "Generated from existing reports; no classification, library construction, or chemistry was rerun. Input reports retain their original source/classifier fingerprints. Aggregation checks compatibility of those recorded fingerprints; it does not revalidate the original source files.",
        "",
    ]
    for _, directory, _ in cohorts:
        for name in ("summary.json", "manifest.json"):
            path = directory / name
            lines.append(
                f"- [{cell(directory.name + '/' + name)}]({link(path, output)}): SHA-256 `{hashlib.sha256(path.read_bytes()).hexdigest()}`"
            )
    if any(
        hashlib.sha256(path.read_bytes()).hexdigest() != digest
        for path, digest in observed.items()
    ):
        raise ValueError("Analysis input changed during aggregation")
    return "\n".join(lines) + "\n"
