"""Classify the source reactions underlying consecutive RRSeq aggregates.

This module deliberately consumes the versioned RRSeq occurrence sidecar rather
than reconstructing occurrences from route JSON.  An aggregate TSV row can be a
QueryCGR-merged representative of several display-SMARTS strings, so row identity
is the pair ``(resolved source TSV, zero-based row index)`` throughout the join."""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Mapping, Sequence

from route_inspector.infrastructure.text import write_tsv
from route_inspector.tactics.classification.rrseq import (
    ANNOTATION_FIELDS,
    GENERALIZED_FIELDS,
    REFERENCE_STEP_FIELDS,
    AnnotatedAggregate,
    _annotated_row,
    _generalized_rows,
    _reference_step_rows,
)
from route_inspector.tactics.rrseq.artifacts import (
    RRseqApplication,
)


def _write_outputs(
    *,
    dataset: str,
    output_dir: Path,
    annotated: Sequence[AnnotatedAggregate],
    applications: Mapping[tuple[Path, int], Sequence[RRseqApplication]],
) -> tuple[dict[str, Path], dict[int, int]]:
    output_dir.mkdir(parents=True, exist_ok=True)
    output_files: dict[str, Path] = {}
    annotated_by_size: dict[int, list[AnnotatedAggregate]] = defaultdict(list)
    for item in annotated:
        annotated_by_size[item.aggregate.rrseq_size].append(item)

    generalized_by_size = _generalized_rows(annotated, applications)
    generalized_counts: dict[int, int] = {}
    for size in sorted(annotated_by_size):
        items = annotated_by_size[size]
        annotated_path = output_dir / f"{dataset}_t{size}_rxnclass_rrseqs.tsv"
        original_fields: list[str] = []
        for item in items:
            for field in item.aggregate.fieldnames:
                if field not in original_fields:
                    original_fields.append(field)
        write_tsv(
            annotated_path,
            original_fields
            + [field for field in ANNOTATION_FIELDS if field not in original_fields],
            (_annotated_row(item) for item in items),
        )
        output_files[f"annotated_t{size}"] = annotated_path

        generalized_path = output_dir / f"{dataset}_t{size}_rxnclass_sequences.tsv"
        generalized_rows = generalized_by_size.get(size, [])
        write_tsv(generalized_path, GENERALIZED_FIELDS, generalized_rows)
        generalized_counts[size] = len(generalized_rows)
        output_files[f"sequences_t{size}"] = generalized_path

    reference_path = output_dir / f"{dataset}_rxnclass_reference_steps.tsv"
    write_tsv(
        reference_path,
        REFERENCE_STEP_FIELDS,
        _reference_step_rows(annotated, dataset=dataset),
    )
    output_files["reference_steps"] = reference_path
    return output_files, generalized_counts
