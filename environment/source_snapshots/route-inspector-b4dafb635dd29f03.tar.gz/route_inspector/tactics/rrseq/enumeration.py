"""Scientific RRSeq-cons and RRSeq-gap enumeration predicates."""

from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from typing import Any, Iterable

from route_inspector import chemistry
from route_inspector.rules.models import (
    MoleculeCenterProjection,
    ReactionRuleStep,
)


def project_side_centers_to_route_molecule(
    side_molecules: tuple[MoleculeCenterProjection, ...],
    route_molecule_smiles: str,
) -> tuple[frozenset[int], bool]:
    """Project side centers to route molecule onto the route molecule being compared.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    route_molecule = chemistry.parse_molecule(route_molecule_smiles)
    projected_center_atoms: set[int] = set()
    matched_route_molecule = False

    for side_molecule in side_molecules:
        if side_molecule.molecule.atoms_count != route_molecule.atoms_count:
            continue
        # Equal atom counts make every full match cover the same target atoms.
        # Chython's default automorphism filter yields only the first such match;
        # exhausting its generator still searches all discarded symmetries.
        mapping = next(side_molecule.molecule.get_mapping(route_molecule), None)
        if mapping is None:
            continue
        matched_route_molecule = True
        projected_center_atoms.update(
            mapping[atom_id]
            for atom_id in side_molecule.center_atoms
            if atom_id in mapping
        )

    return frozenset(projected_center_atoms), matched_route_molecule


def projected_center_atoms_touch(
    route_molecule_smiles: str,
    left_centers: frozenset[int],
    right_centers: frozenset[int],
) -> bool:
    """Project center atoms touch onto the route molecule being compared.

    It operates on PaRoutes route trees after atom-map normalization, which keeps
    reaction centers comparable across convergent route branches.
    """
    if left_centers & right_centers:
        return True

    route_molecule = chemistry.parse_molecule(route_molecule_smiles)
    for atom_1, atom_2, _bond in route_molecule.bonds():
        if (
            atom_1 in left_centers
            and atom_2 in right_centers
            and center_contact_allowed(
                route_molecule,
                atom_1,
                atom_2,
            )
        ):
            return True
        if (
            atom_2 in left_centers
            and atom_1 in right_centers
            and center_contact_allowed(
                route_molecule,
                atom_2,
                atom_1,
            )
        ):
            return True
    return False


def projected_center_components(
    route_molecule_smiles: str,
    center_atoms: frozenset[int],
) -> list[frozenset[int]]:
    """Project center components onto the route molecule being compared.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    route_molecule = chemistry.parse_molecule(route_molecule_smiles)
    remaining = set(center_atoms)
    components: list[frozenset[int]] = []
    adjacency: dict[int, set[int]] = {atom: set() for atom in center_atoms}
    for atom_1, atom_2, _bond in route_molecule.bonds():
        if atom_1 in center_atoms and atom_2 in center_atoms:
            adjacency[atom_1].add(atom_2)
            adjacency[atom_2].add(atom_1)

    while remaining:
        stack = [remaining.pop()]
        component = set(stack)
        while stack:
            atom = stack.pop()
            for neighbor in adjacency[atom]:
                if neighbor in remaining:
                    remaining.remove(neighbor)
                    component.add(neighbor)
                    stack.append(neighbor)
        components.append(frozenset(component))
    return components


def touches_all_center_components(
    route_molecule_smiles: str,
    left_centers: frozenset[int],
    right_centers: frozenset[int],
) -> bool:
    """Return whether all center components touches every required center.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    components = projected_center_components(route_molecule_smiles, right_centers)
    if len(components) <= 1:
        return True
    return all(
        projected_center_atoms_touch(route_molecule_smiles, left_centers, component)
        for component in components
    )


def center_contact_allowed(route_molecule: Any, atom_1: int, atom_2: int) -> bool:
    """Return whether two projected center atoms can link a rrseq sequence.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    atomic_numbers = {
        atom_number: atom.atomic_number for atom_number, atom in route_molecule.atoms()
    }
    atom_1_number = atomic_numbers.get(atom_1)
    atom_2_number = atomic_numbers.get(atom_2)
    if atom_1_number is None or atom_2_number is None:
        return False

    if atom_1_number != 6 or atom_2_number != 6:
        return True

    return is_carbonyl_carbon(route_molecule, atom_1) or is_carbonyl_carbon(
        route_molecule,
        atom_2,
    )


def is_carbonyl_carbon(route_molecule: Any, atom_number: int) -> bool:
    """Return whether carbonyl carbon matches the expected condition.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    atom = route_molecule.atom(atom_number)
    if atom.atomic_number != 6:
        return False
    for neighbor_id, bond in route_molecule._bonds[atom_number].items():
        neighbor = route_molecule.atom(neighbor_id)
        if neighbor.atomic_number == 8 and int(bond) == 2:
            return True
    return False


def adjacent_centers_overlap(left: ReactionRuleStep, right: ReactionRuleStep) -> bool:
    """Return whether adjacent route steps share a compatible reaction center.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    if (
        right.target_smiles
        and left.reactant_center_molecules
        and right.product_center_molecules
    ):
        left_centers, left_matched = project_side_centers_to_route_molecule(
            left.reactant_center_molecules,
            right.target_smiles,
        )
        right_centers, right_matched = project_side_centers_to_route_molecule(
            right.product_center_molecules,
            right.target_smiles,
        )
        if not (
            left_matched
            and right_matched
            and touches_all_center_components(
                right.target_smiles,
                left_centers,
                right_centers,
            )
            and projected_center_atoms_touch(
                right.target_smiles,
                left_centers,
                right_centers,
            )
        ):
            return False
        return not is_excluded_adjacent_pair(left, right)

    return bool(left.center_atoms & right.center_atoms)


def is_excluded_adjacent_pair(
    left: ReactionRuleStep,
    right: ReactionRuleStep,
) -> bool:
    """Return whether excluded adjacent pair matches the expected condition.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    return is_sulfonyl_ester_activation_rule(
        left.rule_smarts
    ) and is_alcohol_ester_deprotection_rule(right.rule_smarts)


def is_sulfonyl_ester_activation_rule(rule_smarts: str) -> bool:
    """Return whether sulfonyl ester activation rule matches the expected condition.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    left, _, right = rule_smarts.partition(">>")
    return (
        "-[O;D2" in left and "-[S;D4" in left and "=[O;D1" in left and "[O;D1" in right
    )


def is_alcohol_ester_deprotection_rule(rule_smarts: str) -> bool:
    """Return whether alcohol ester deprotection rule matches the expected condition.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    left, _, right = rule_smarts.partition(">>")
    return "-[O;D1" in left and "-[O;D2" in right and "=[O;D1" in right


def valid_rrseq_cons_sequences(
    path: list[ReactionRuleStep],
    *,
    min_length: int,
    max_length: int | None,
) -> Iterable[tuple[str, ...]]:
    """Return ordered rule sequences that satisfy the RRseq_cons definition.

    The result preserves reaction order and the shared-center constraint used to decide
    whether adjacent route steps form a valid rrseq rule.
    """
    for sequence, _target_smiles in valid_rrseq_cons_sequence_occurrences(
        path,
        min_length=min_length,
        max_length=max_length,
    ):
        yield sequence


def valid_rrseq_cons_sequence_occurrences(
    path: list[ReactionRuleStep],
    *,
    min_length: int,
    max_length: int | None,
) -> Iterable[tuple[tuple[str, ...], str]]:
    """Return valid RRseq_cons values and their starting route molecules."""

    for sequence, target_smiles, _start, _end in valid_rrseq_cons_occurrence_records(
        path,
        min_length=min_length,
        max_length=max_length,
    ):
        yield sequence, target_smiles


def valid_rrseq_cons_occurrence_records(
    path: list[ReactionRuleStep],
    *,
    min_length: int,
    max_length: int | None,
) -> Iterable[tuple[tuple[str, ...], str, int, int]]:
    """Return RRseq_cons values with global start and exclusive end bounds.

    The result preserves reaction order and the shared-center constraint used to decide
    whether adjacent route steps form a valid rrseq rule.
    """
    if len(path) < min_length:
        return

    def emit_segment(
        segment_start: int,
        segment_end: int,
    ) -> Iterable[tuple[tuple[str, ...], str, int, int]]:
        """Emit one contiguous ordered segment from a candidate route path.

        The helper feeds rule extraction, center-overlap filtering, or final TSV
        aggregation without changing the original route JSON in place.
        """
        if segment_end - segment_start < min_length:
            return
        for start in range(segment_start, segment_end):
            max_end = (
                segment_end
                if max_length is None
                else min(segment_end, start + max_length)
            )
            for end in range(start + min_length, max_end + 1):
                steps = path[start:end]
                yield (
                    tuple(step.rule_smarts for step in steps),
                    steps[0].target_smiles,
                    start,
                    end,
                )

    segment_start = 0
    for position in range(1, len(path)):
        if adjacent_centers_overlap(path[position - 1], path[position]):
            continue
        yield from emit_segment(segment_start, position)
        segment_start = position

    yield from emit_segment(segment_start, len(path))


def gapped_connector_maps(
    path: list[ReactionRuleStep],
    selected_positions: Iterable[int],
) -> frozenset[int]:
    """Return maps that connect each selected step to its selected history."""

    positions = tuple(int(position) for position in selected_positions)
    if not positions:
        return frozenset()
    history = set(path[positions[0]].center_atoms)
    connectors: set[int] = set()
    for position in positions[1:]:
        connectors.update(history & path[position].center_atoms)
        history.update(path[position].center_atoms)
    return frozenset(connectors)


def mapped_local_context(
    molecule_smiles: str,
    center_maps: Iterable[int],
    *,
    radius: int = 2,
) -> frozenset[int]:
    """Return mapped atoms within ``radius`` bonds of a mapped center.

    The route molecule is the authoritative continuously mapped representation.
    Missing center maps are deliberately omitted here and are reported later by the
    gapped classifier rather than being replaced with SMARTS-local atom numbers.
    """

    if radius < 0:
        raise ValueError("context radius must be non-negative")
    molecule = chemistry.parse_molecule(molecule_smiles)
    available = {int(atom_number) for atom_number in molecule}
    visited = {int(atom_number) for atom_number in center_maps} & available
    frontier = set(visited)
    adjacency: dict[int, set[int]] = defaultdict(set)
    for atom_1, atom_2, _bond in molecule.bonds():
        atom_1 = int(atom_1)
        atom_2 = int(atom_2)
        adjacency[atom_1].add(atom_2)
        adjacency[atom_2].add(atom_1)
    for _distance in range(radius):
        frontier = {
            neighbor
            for atom_number in frontier
            for neighbor in adjacency.get(atom_number, ())
            if neighbor not in visited
        }
        if not frontier:
            break
        visited.update(frontier)
    return frozenset(visited)


def gapped_gap_contexts(
    path: list[ReactionRuleStep],
    selected_positions: Iterable[int],
) -> list[dict[str, Any]]:
    """Serialize the exact mapped route states bracketing every selected gap."""

    positions = tuple(int(position) for position in selected_positions)
    contexts: list[dict[str, Any]] = []
    selected_history: set[int] = set()
    for selected_index, position in enumerate(positions):
        step = path[position]
        if selected_index == 0:
            selected_history.update(step.center_atoms)
            continue
        left_position = positions[selected_index - 1]
        connectors = selected_history & set(step.center_atoms)
        selected_history.update(step.center_atoms)
        if position <= left_position + 1:
            continue
        contexts.append(
            {
                "left_selected_position": left_position,
                "right_selected_position": position,
                "skipped_positions": list(range(left_position + 1, position)),
                "connector_maps": sorted(connectors),
                "after_left_selected_molecule": path[left_position + 1].target_smiles,
                "before_right_selected_molecule": step.target_smiles,
            }
        )
    return contexts


def stable_rrseq_gap_occurrence_id(
    *,
    source_identity: str,
    route_id: Any,
    root_index: int,
    branch_index: int,
    selected_positions: Iterable[int],
    reaction_smiles: Iterable[str],
) -> str:
    """Return the byte-compatible v1 identity for one exact gapped occurrence."""

    payload = json.dumps(
        {
            "source_identity": str(source_identity),
            "route_id": str(route_id),
            "root_index": int(root_index),
            "branch_index": int(branch_index),
            "selected_positions": [int(position) for position in selected_positions],
            "reaction_smiles": list(reaction_smiles),
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return "rrg_" + hashlib.sha256(payload.encode("utf-8")).hexdigest()[:24]


def valid_rrseq_gap_sequence_occurrences(
    path: list[ReactionRuleStep],
    *,
    min_length: int,
    max_length: int | None,
) -> Iterable[tuple[tuple[str, ...], str]]:
    """Yield noncontiguous, center-history-connected RRseq_gap occurrences.

    A selected step may extend a sequence only when its normalized mapped reaction
    center overlaps the union of centers from already selected steps. The selected
    steps retain target-to-leaf order and must contain at least one skipped reaction.
    """
    for sequence, target_smiles, _indices in valid_rrseq_gap_occurrence_records(
        path, min_length=min_length, max_length=max_length
    ):
        yield sequence, target_smiles


def valid_rrseq_gap_occurrence_records(
    path: list[ReactionRuleStep],
    *,
    min_length: int,
    max_length: int | None,
) -> Iterable[tuple[tuple[str, ...], str, tuple[int, ...]]]:
    """Yield RRseq_gap values together with their selected path positions."""
    if len(path) < min_length:
        return

    upper = len(path) if max_length is None else min(len(path), max_length)
    for start, first_step in enumerate(path):

        def extend(
            selected_indices: tuple[int, ...],
            center_history: frozenset[int],
            has_gap: bool,
            connector_maps: frozenset[int],
            skipped_center_maps: frozenset[int],
        ) -> Iterable[tuple[tuple[str, ...], str, tuple[int, ...]]]:
            if len(selected_indices) >= upper:
                return
            previous_index = selected_indices[-1]
            for candidate_index in range(previous_index + 1, len(path)):
                candidate = path[candidate_index]
                new_connector_maps = center_history & candidate.center_atoms
                if not new_connector_maps:
                    continue
                newly_skipped_center_maps = frozenset(
                    atom_map
                    for position in range(previous_index + 1, candidate_index)
                    for atom_map in path[position].center_atoms
                )
                next_connector_maps = frozenset(connector_maps | new_connector_maps)
                next_skipped_center_maps = frozenset(
                    skipped_center_maps | newly_skipped_center_maps
                )
                # A skipped reaction may be unrelated to the selected chemistry, but
                # it cannot alter an atom map that carries the selected history to a
                # later selected transformation. Omitting such a bridge changes the
                # state being composed and produces a false gapped rule.
                if next_connector_maps & next_skipped_center_maps:
                    continue
                indices = (*selected_indices, candidate_index)
                next_has_gap = has_gap or candidate_index > previous_index + 1
                if len(indices) >= min_length and next_has_gap:
                    yield (
                        tuple(path[index].rule_smarts for index in indices),
                        first_step.target_smiles,
                        indices,
                    )
                yield from extend(
                    indices,
                    frozenset(center_history | candidate.center_atoms),
                    next_has_gap,
                    next_connector_maps,
                    next_skipped_center_maps,
                )

        yield from extend(
            (start,), first_step.center_atoms, False, frozenset(), frozenset()
        )


def valid_rrseq_gap_sequences(
    path: list[ReactionRuleStep],
    *,
    min_length: int,
    max_length: int | None,
) -> Iterable[tuple[str, ...]]:
    """Yield RRseq_gap SMARTS sequences without occurrence metadata."""
    for sequence, _target_smiles in valid_rrseq_gap_sequence_occurrences(
        path,
        min_length=min_length,
        max_length=max_length,
    ):
        yield sequence


__all__ = [
    "adjacent_centers_overlap",
    "center_contact_allowed",
    "gapped_connector_maps",
    "gapped_gap_contexts",
    "is_alcohol_ester_deprotection_rule",
    "is_carbonyl_carbon",
    "is_excluded_adjacent_pair",
    "is_sulfonyl_ester_activation_rule",
    "mapped_local_context",
    "project_side_centers_to_route_molecule",
    "projected_center_atoms_touch",
    "projected_center_components",
    "stable_rrseq_gap_occurrence_id",
    "touches_all_center_components",
    "valid_rrseq_cons_occurrence_records",
    "valid_rrseq_cons_sequence_occurrences",
    "valid_rrseq_cons_sequences",
    "valid_rrseq_gap_occurrence_records",
    "valid_rrseq_gap_sequence_occurrences",
    "valid_rrseq_gap_sequences",
]
