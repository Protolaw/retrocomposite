"""Tabular RRSeq summaries; no chemistry extraction or plotting decisions."""

from collections import Counter
from statistics import mean, median

from route_inspector.tactics.rrseq.statistics_io import (
    SUPPORT_BINS,
    describe,
    quantile,
    support_bin,
    write_json,
    write_tsv,
)

KINDS = ("rrseq_cons", "rrseq_gap")
CATEGORIES = ("consecutive_only", "gapped_only", "both", "no_rrseq")


def coverage_category(counts):
    cons, gap = counts["rrseq_cons"] > 0, counts["rrseq_gap"] > 0
    return (
        "both"
        if cons and gap
        else ("consecutive_only" if cons else ("gapped_only" if gap else "no_rrseq"))
    )


def _count_row(aggregate):
    return {
        "occurrence_count": aggregate["occurrence_count"],
        "unique_family_count": len(aggregate["families"]),
        "distinct_route_count": len(aggregate["routes"]),
    }


def write_reports(
    stage,
    *,
    families,
    route_counts,
    route_families,
    topology,
    lengths,
    gaps,
    names,
    classification,
    dataset_id,
    source_identity,
    namerxn_class_names=None,
):
    total = len(route_counts)
    coverage = Counter(coverage_category(c) for c in route_counts.values())
    assert sum(coverage.values()) == total
    summary = {
        "routes_total": total,
        "routes_cons_only": coverage["consecutive_only"],
        "routes_gap_only": coverage["gapped_only"],
        "routes_both": coverage["both"],
        "routes_no_rrseq": coverage["no_rrseq"],
    }
    write_tsv(
        stage / "rrseq_route_coverage.tsv",
        [
            {
                "category": k,
                "route_count": coverage[k],
                "percentage": 100 * coverage[k] / total,
            }
            for k in CATEGORIES
        ],
        ["category", "route_count", "percentage"],
    )
    length_rows = [
        {"kind": kind, "selected_reaction_count": size, **_count_row(values)}
        for (kind, size), values in sorted(lengths.items())
    ]
    write_tsv(
        stage / "rrseq_length_distribution.tsv",
        length_rows,
        [
            "kind",
            "selected_reaction_count",
            "occurrence_count",
            "unique_family_count",
            "distinct_route_count",
        ],
    )
    summary["length_distribution"] = length_rows
    write_tsv(
        stage / "rrseq_gap_size_distribution.tsv",
        [
            {"skipped_reaction_count": n, **_count_row(values)}
            for n, values in sorted(gaps.items())
        ],
        [
            "skipped_reaction_count",
            "occurrence_count",
            "unique_family_count",
            "distinct_route_count",
        ],
    )
    support_rows, bins, support_summary, frequency = [], [], {}, []
    family_names = []
    for kind in KINDS:
        group = [f for f in families.values() if f["entry"].kind == kind]
        group.sort(
            key=lambda f: (-len(f["routes"]), -f["occurrences"], f["entry"].entry_id)
        )
        supports = [len(f["routes"]) for f in group]
        occurrences = sum(f["occurrences"] for f in group)
        suffix = kind.removeprefix("rrseq_")
        summary[f"{suffix}_unique_families"] = len(group)
        summary[f"{suffix}_occurrences"] = occurrences
        summary[f"{suffix}_singleton_families"] = supports.count(1)
        summary[f"most_supported_{suffix}_family"] = (
            group[0]["entry"].entry_id if group else None
        )
        summary[f"most_supported_{suffix}_family_route_support"] = (
            supports[0] if group else 0
        )
        stats = {
            "family_count": len(group),
            "min_support": min(supports, default=None),
            "max_support": max(supports, default=None),
            **{
                f"{k}_support" if k in ("mean", "median") else k: v
                for k, v in describe(supports).items()
            },
            **{f"q{p}": quantile(supports, p / 100) for p in (90, 95, 99)},
            "singleton_families": supports.count(1),
            "singleton_fraction": supports.count(1) / len(group) if group else None,
            "total_occurrence_count": occurrences,
        }
        for threshold in (2, 5, 10, 20):
            stats[f"families_support_ge_{threshold}"] = sum(
                s >= threshold for s in supports
            )
        cohorts = {
            "singleton": [f for f in group if len(f["routes"]) == 1],
            **{
                f"support_ge_{t}": [f for f in group if len(f["routes"]) >= t]
                for t in (2, 5, 10)
            },
        }
        for name, subset in cohorts.items():
            count = sum(f["occurrences"] for f in subset)
            stats[f"{name}_occurrence_count"] = count
            stats[f"{name}_occurrence_fraction"] = (
                count / occurrences if occurrences else None
            )
        support_summary[kind] = stats
        for _, _, label in SUPPORT_BINS:
            subset = [f for f in group if support_bin(len(f["routes"])) == label]
            bins.append(
                {
                    "kind": kind,
                    "route_support_bin": label,
                    "unique_family_count": len(subset),
                    "percentage_of_families": 100 * len(subset) / len(group)
                    if group
                    else None,
                    "total_occurrence_count": sum(f["occurrences"] for f in subset),
                    "distinct_route_coverage": len(
                        set().union(*(f["routes"] for f in subset))
                    ),
                }
            )
        for support in sorted(set(supports)):
            subset = [f for f in group if len(f["routes"]) == support]
            frequency.append(
                {
                    "kind": kind,
                    "route_support": support,
                    "unique_family_count": len(subset),
                    "occurrence_count": sum(f["occurrences"] for f in subset),
                    "distinct_route_count": len(
                        set().union(*(f["routes"] for f in subset))
                    ),
                }
            )
        top = []
        for rank, family in enumerate(group, 1):
            entry = family["entry"]
            row = {
                "kind": kind,
                "family_key": entry.entry_id,
                "rrseq_identity": family["identity"],
                "selected_reaction_count": len(family["rules"]),
                "route_support": len(family["routes"]),
                "occurrence_count": family["occurrences"],
                "route_support_bin": support_bin(len(family["routes"])),
                "ordered_rule_identities": family["rules"],
                "inter_selection_gap_widths": family[
                    "entry"
                ].identity.equivalence_payload.get("inter_selection_gap_widths", []),
            }
            support_rows.append(row)
            alternatives = []
            for (codes, class_names, status), count in sorted(
                family["namerxn"].items()
            ):
                alternatives.append(
                    {
                        "classes": codes,
                        "names": class_names,
                        "classification_status": status,
                        "occurrence_count": count,
                    }
                )
                family_names.append(
                    {
                        "kind": kind,
                        "family_key": entry.entry_id,
                        "NameRxn_sequence": codes,
                        "NameRxn_class_sequence": readable_class_sequence(
                            codes, [class_names], namerxn_class_names
                        ),
                        "NameRxn_names": class_names,
                        "classification_status": status,
                        "occurrence_count": count,
                    }
                )
            if rank <= 20:
                top.append(
                    {
                        "rank": rank,
                        **row,
                        "ordered_NameRxn_classes": alternatives,
                        "example_route_id": family["example"][0],
                        "example_occurrence_id": family["example"][1],
                    }
                )
        write_tsv(
            stage / f"top_{kind}_families.tsv",
            top,
            [
                "rank",
                "kind",
                "family_key",
                "rrseq_identity",
                "selected_reaction_count",
                "route_support",
                "occurrence_count",
                "route_support_bin",
                "ordered_rule_identities",
                "inter_selection_gap_widths",
                "ordered_NameRxn_classes",
                "example_route_id",
                "example_occurrence_id",
            ],
        )
    write_tsv(
        stage / "rrseq_family_support.tsv",
        support_rows,
        [
            "kind",
            "family_key",
            "rrseq_identity",
            "selected_reaction_count",
            "route_support",
            "occurrence_count",
            "route_support_bin",
            "ordered_rule_identities",
            "inter_selection_gap_widths",
        ],
    )
    write_tsv(
        stage / "rrseq_family_support_bins.tsv",
        bins,
        [
            "kind",
            "route_support_bin",
            "unique_family_count",
            "percentage_of_families",
            "total_occurrence_count",
            "distinct_route_coverage",
        ],
    )
    write_tsv(
        stage / "rrseq_family_support_distribution.tsv",
        frequency,
        [
            "kind",
            "route_support",
            "unique_family_count",
            "occurrence_count",
            "distinct_route_count",
        ],
    )
    write_json(stage / "rrseq_family_support_summary.json", support_summary)
    summary["family_support"] = support_summary
    write_tsv(
        stage / "rrseq_family_namerxn.tsv",
        family_names,
        [
            "kind",
            "family_key",
            "NameRxn_sequence",
            "NameRxn_class_sequence",
            "NameRxn_names",
            "classification_status",
            "occurrence_count",
        ],
    )
    _overlap(stage, families, summary)
    _namerxn(stage, names, summary, classification, namerxn_class_names)
    density = []
    for rid in sorted(
        route_counts, key=lambda x: (0, int(x)) if x.isdecimal() else (1, x)
    ):
        counts, topo = route_counts[rid], topology[rid]
        reactions = topo["total_reaction_count"]
        row = {
            "dataset_id": dataset_id,
            "source_identity": source_identity,
            "route_id": rid,
            "reaction_count": reactions,
            "route_depth": topo["longest_linear_route"],
            "leaf_count": topo["distinct_leaf_count"],
            "is_convergent": int(topo["topology"] == "convergent"),
            "category": coverage_category(counts),
        }
        for kind in KINDS:
            short = kind.removeprefix("rrseq_")
            row[f"{kind}_occurrence_count"] = counts[kind]
            row[f"{kind}_unique_family_count"] = len(route_families[rid][kind])
            row[f"{short}_occurrences_per_reaction"] = (
                counts[kind] / reactions if reactions else None
            )
            row[f"unique_{short}_families_per_reaction"] = (
                len(route_families[rid][kind]) / reactions if reactions else None
            )
        density.append(row)
    write_tsv(stage / "rrseq_route_density.tsv", density, list(density[0]))
    _route_reports(stage, density, summary)
    return summary


def _overlap(stage, families, summary):
    # The cross-kind comparison deliberately projects away gap spacing. Union
    # all width-sensitive families rather than overwriting one representative.
    by_kind = {k: {} for k in KINDS}
    for family in families.values():
        group = by_kind[family["entry"].kind].setdefault(
            family["rules"],
            {
                "rules": family["rules"],
                "identity": family["identity"],
                "routes": set(),
                "occurrences": 0,
                "entries": [],
            },
        )
        group["routes"].update(family["routes"])
        group["occurrences"] += family["occurrences"]
        group["entries"].append(family["entry"].entry_id)
    cons, gap = (set(by_kind[k]) for k in KINDS)
    shared, union = cons & gap, cons | gap
    stats = {
        "comparison_scope": "width_agnostic_ordered_rule_projection",
        "cons_only": len(cons - gap),
        "gap_only": len(gap - cons),
        "shared": len(shared),
        "union": len(union),
        "jaccard": len(shared) / len(union) if union else None,
        "fraction_of_cons_families_also_seen_gapped": len(shared) / len(cons)
        if cons
        else None,
        "fraction_of_gap_families_also_seen_consecutively": len(shared) / len(gap)
        if gap
        else None,
    }
    write_tsv(stage / "rrseq_cons_gap_overlap.tsv", [stats], list(stats))
    summary.update(
        cons_gap_shared_identities=len(shared),
        cons_gap_jaccard=stats["jaccard"],
        cons_gap_overlap=stats,
    )
    rows = []
    predominant = Counter()
    for rules in shared:
        a, b = (by_kind[k][rules] for k in KINDS)
        assert a["rules"] == b["rules"] and a["identity"] == b["identity"]
        ac, bc = len(a["routes"]), len(b["routes"])
        predominant["consecutive" if ac > bc else "gapped" if bc > ac else "equal"] += 1
        rows.append(
            {
                "rrseq_identity": a["identity"],
                "sequence_length": len(rules),
                "cons_family_key": a["entries"][0] if len(a["entries"]) == 1 else "",
                "cons_family_keys": sorted(a["entries"]),
                "gap_family_key": b["entries"][0] if len(b["entries"]) == 1 else "",
                "gap_family_keys": sorted(b["entries"]),
                "cons_route_support": ac,
                "gap_route_support": bc,
                "cons_occurrence_count": a["occurrences"],
                "gap_occurrence_count": b["occurrences"],
                "total_route_support": len(a["routes"] | b["routes"]),
                "ordered_rule_identities": rules,
            }
        )
    for metric in ("total_route_support", "cons_route_support", "gap_route_support"):
        for i, row in enumerate(
            sorted(rows, key=lambda r: (-r[metric], r["rrseq_identity"])), 1
        ):
            row[f"rank_{metric}"] = i
    rows.sort(
        key=lambda r: (
            -r["total_route_support"],
            -r["cons_route_support"],
            -r["gap_route_support"],
            r["rrseq_identity"],
        )
    )
    write_tsv(
        stage / "rrseq_shared_context_support.tsv",
        rows,
        [
            "rrseq_identity",
            "sequence_length",
            "cons_family_key",
            "gap_family_key",
            "cons_family_keys",
            "gap_family_keys",
            "cons_route_support",
            "gap_route_support",
            "cons_occurrence_count",
            "gap_occurrence_count",
            "total_route_support",
            "ordered_rule_identities",
            "rank_total_route_support",
            "rank_cons_route_support",
            "rank_gap_route_support",
        ],
    )
    summary["shared_identity_prevalence_by_route_support"] = {
        k: predominant[k] for k in ("consecutive", "gapped", "equal")
    }


def readable_class_sequence(codes, name_variants, class_names=None):
    """Render labels in the original sequence order without regrouping codes."""
    labels = []
    for position, code in enumerate(codes):
        if code == "MISSING_ANNOTATION":
            labels.append("Missing annotation")
        elif code == "UNCLASSIFIED":
            labels.append("Unclassified")
        elif class_names is not None:
            if code not in class_names:
                raise ValueError(f"NameRxn class {code} is missing from namerxn.def")
            labels.append(class_names[code])
        else:
            alternatives = sorted(
                {names[position] for names in name_variants if names[position]}
            )
            labels.append(
                " / ".join(alternatives)
                if alternatives
                else f"Class {code} (name unavailable)"
            )
    return " → ".join(labels)


def _namerxn(stage, names, summary, classification, class_names=None):
    rows = []
    for (kind, codes, status), aggregate in names.items():
        rows.append(
            {
                "kind": kind,
                "NameRxn_sequence": codes,
                "NameRxn_class_sequence": readable_class_sequence(
                    codes, aggregate["name_variants"], class_names
                ),
                "NameRxn_names": sorted(aggregate["name_variants"]),
                "selected_reaction_count": len(codes),
                "classification_status": status,
                "occurrence_count": aggregate["occurrence_count"],
                "distinct_route_count": len(aggregate["routes"]),
                "number_of_distinct_RRSeq_families": len(aggregate["families"]),
            }
        )
    rows.sort(
        key=lambda r: (
            r["kind"],
            -r["distinct_route_count"],
            r["NameRxn_sequence"],
            r["NameRxn_names"],
        )
    )
    fields = [
        "kind",
        "NameRxn_sequence",
        "NameRxn_class_sequence",
        "NameRxn_names",
        "selected_reaction_count",
        "classification_status",
        "occurrence_count",
        "distinct_route_count",
        "number_of_distinct_RRSeq_families",
    ]
    write_tsv(stage / "rrseq_namerxn_sequences.tsv", rows, fields)
    write_tsv(stage / "rrseq_rule_vs_namerxn_granularity.tsv", rows, fields)
    top = []
    compression = {}
    for kind in KINDS:
        complete = [
            r
            for r in rows
            if r["kind"] == kind and r["classification_status"] == "fully_classified"
        ]
        top.extend({"rank": i, **r} for i, r in enumerate(complete[:20], 1))
        family_counts = [r["number_of_distinct_RRSeq_families"] for r in complete]
        classified_families = set().union(
            *(
                a["families"]
                for (k, _, s), a in names.items()
                if k == kind and s == "fully_classified"
            )
        )
        compression[kind] = {
            "scope": "fully classified occurrences only; missing/unclassified sequences excluded",
            "total_rrseq_families": summary[
                f"{kind.removeprefix('rrseq_')}_unique_families"
            ],
            "families_with_fully_classified_occurrences": len(classified_families),
            "total_unique_namerxn_sequences": len(complete) if complete else None,
            "mean_families_per_sequence": mean(family_counts) if complete else None,
            "median_families_per_sequence": median(family_counts) if complete else None,
            "maximum_families_per_sequence": max(family_counts, default=None),
        }
    write_tsv(stage / "top_rrseq_namerxn_sequences.tsv", top, ["rank", *fields])
    summary["namerxn_granularity"] = compression
    for status in ("fully_classified", "partially_classified", "unclassified"):
        summary[f"{status}_namerxn_occurrences"] = sum(
            classification[k][status] for k in KINDS
        )
    summary["missing_namerxn_annotation_occurrences"] = sum(
        classification[k]["missing_annotation_occurrences"] for k in KINDS
    )


def _route_reports(stage, density, summary):
    cohorts = {
        "no_rrseq": [r for r in density if r["category"] == "no_rrseq"],
        "routes_with_any_RRSeq": [r for r in density if r["category"] != "no_rrseq"],
    }
    rows = []
    for name, group in cohorts.items():
        for variable in (
            "reaction_count",
            "route_depth",
            "leaf_count",
            "is_convergent",
        ):
            rows.append(
                {
                    "cohort": name,
                    "route_count": len(group),
                    "percentage": 100 * len(group) / len(density),
                    "variable": variable,
                    **describe([r[variable] for r in group]),
                }
            )
    write_tsv(
        stage / "rrseq_free_route_statistics.tsv",
        rows,
        [
            "cohort",
            "route_count",
            "percentage",
            "variable",
            "mean",
            "median",
            "q25",
            "q75",
        ],
    )
    summary["route_cohort_topology"] = rows
    by_length = []
    for length in sorted({r["reaction_count"] for r in density}):
        group = [r for r in density if r["reaction_count"] == length]
        row = {
            "reaction_count": length,
            "routes": len(group),
            "routes_with_RRSeq_cons": sum(
                r["rrseq_cons_occurrence_count"] > 0 for r in group
            ),
            "routes_with_RRSeq_gap": sum(
                r["rrseq_gap_occurrence_count"] > 0 for r in group
            ),
            "routes_with_any_RRSeq": sum(r["category"] != "no_rrseq" for r in group),
        }
        for short in ("cons", "gap"):
            values = [r[f"rrseq_{short}_occurrence_count"] for r in group]
            row[f"mean_{short}_occurrences"] = mean(values)
            row[f"median_{short}_occurrences"] = median(values)
            normalized = [
                r[f"{short}_occurrences_per_reaction"]
                for r in group
                if r[f"{short}_occurrences_per_reaction"] is not None
            ]
            row[f"mean_{short}_occurrences_per_reaction"] = (
                mean(normalized) if normalized else None
            )
        by_length.append(row)
    write_tsv(stage / "rrseq_by_route_length.tsv", by_length, list(by_length[0]))
    topology = []
    for label, convergent in [("linear", 0), ("convergent", 1)]:
        group = [r for r in density if r["is_convergent"] == convergent]
        row = {"topology": label, "route_count": len(group)}
        for name, predicate in [
            ("RRSeq_cons", lambda r: r["rrseq_cons_occurrence_count"] > 0),
            ("RRSeq_gap", lambda r: r["rrseq_gap_occurrence_count"] > 0),
            ("both", lambda r: r["category"] == "both"),
            ("no_RRSeq", lambda r: r["category"] == "no_rrseq"),
        ]:
            row[f"fraction_with_{name}"] = (
                sum(predicate(r) for r in group) / len(group) if group else None
            )
        for short in ("cons", "gap"):
            values = [r[f"rrseq_{short}_occurrence_count"] for r in group]
            row[f"mean_{short}_occurrences"] = mean(values) if group else None
            row[f"median_{short}_occurrences"] = median(values) if group else None
        topology.append(row)
    write_tsv(stage / "rrseq_by_route_topology.tsv", topology, list(topology[0]))
    summary["route_topology_groups"] = topology


def markdown_report(stage, summary):
    import csv

    def table(filename, fields):
        with (stage / filename).open() as handle:
            rows = list(csv.DictReader(handle, delimiter="\t"))
        return "\n".join(
            [
                "| " + " | ".join(fields) + " |",
                "| " + " | ".join("---" for _ in fields) + " |",
                *[
                    "| " + " | ".join(str(row[f]) for f in fields) + " |"
                    for row in rows
                ],
            ]
        )

    s = summary
    lines = [
        "# Set-n1 RRSeq statistics"
        if s["routes_total"] == 10000
        else "# RRSeq statistics",
        "",
        f"Analyzed routes: {s['routes_total']:,}. Family identities and occurrence assignments come from the prebuilt library.",
        "",
        "## Route coverage",
        "",
        table("rrseq_route_coverage.tsv", ["category", "route_count", "percentage"]),
        "",
        "## Family vocabulary and recurrence",
        "",
    ]
    for short in ("cons", "gap"):
        stats = s["family_support"][f"rrseq_{short}"]
        lines.append(
            f"- RRSeq_{short}: {s[f'{short}_unique_families']:,} families, {s[f'{short}_occurrences']:,} occurrences; "
            f"{stats['singleton_families']:,} singleton families ({100 * (stats['singleton_fraction'] or 0):.2f}% of families), "
            f"accounting for {100 * (stats['singleton_occurrence_fraction'] or 0):.2f}% of occurrences."
        )
    lines += [
        "",
        "## Selected-reaction lengths",
        "",
        table(
            "rrseq_length_distribution.tsv",
            [
                "kind",
                "selected_reaction_count",
                "occurrence_count",
                "unique_family_count",
                "distinct_route_count",
            ],
        ),
        "",
        "## Consecutive/gapped width-agnostic ordered-rule overlap",
        "",
        "Family counts use the library’s recorded identity policy (including gap widths in version 4). "
        "This overlap section deliberately removes gap widths and unions support across spacing variants; "
        "its projected identity counts are not counts of width-sensitive tactic families.",
        "",
        f"Shared ordered identities: {s['cons_gap_shared_identities']:,}; Jaccard: {s['cons_gap_jaccard']}. "
        f"Shared identities by larger context-specific route support: {s['shared_identity_prevalence_by_route_support']}.",
        "",
        "## NameRxn composition and compression",
        "",
        "**Sequence direction:** `NameRxn_sequence` and `NameRxn_class_sequence` are shown in "
        "**retrosynthetic order (target → precursors/building blocks)**. For **forward synthesis "
        "(building blocks → target), reverse the sequence order**. Individual NameRxn labels "
        "still describe the original forward reactions; only their order is reversed, not their "
        "chemical meaning. For gapped RRSeqs, both orders include only the selected reactions "
        "and omit the skipped steps.",
        "",
    ]
    if s["namerxn_annotations"]["status"] == "unavailable":
        lines.append(
            "Unavailable: no authoritative NameRxn 3.2 annotations were present or supplied. "
            "All missing positions are explicitly MISSING_ANNOTATION. This is not evidence of failed chemical classification; "
            "top NameRxn sequences and vocabulary compression cannot be determined."
        )
    else:
        lines += [
            table(
                "top_rrseq_namerxn_sequences.tsv",
                [
                    "rank",
                    "kind",
                    "NameRxn_sequence",
                    "NameRxn_class_sequence",
                    "distinct_route_count",
                ],
            ),
            "",
            f"Fully/partially/unclassified occurrence counts: {s['fully_classified_namerxn_occurrences']}/"
            f"{s['partially_classified_namerxn_occurrences']}/{s['unclassified_namerxn_occurrences']}; "
            f"missing annotations in {s['missing_namerxn_annotation_occurrences']} occurrences.",
            "",
            "Compression among fully classified occurrences: "
            + str(s["namerxn_granularity"]),
            "",
            "All supplied source-reaction annotation statuses: "
            + str(s["namerxn_annotations"]["source_status_counts"])
            + ". Canonicalization errors and labels excluded by the existing single Tier-3 policy "
            "are retained in errors.tsv and excluded from fully classified sequence summaries.",
        ]
    lines += [
        "",
        "## RRSeq-free versus RRSeq-containing topology",
        "",
        table(
            "rrseq_free_route_statistics.tsv",
            ["cohort", "route_count", "variable", "mean", "median", "q25", "q75"],
        ),
        "",
        "## Prevalence and density by route length",
        "",
        table(
            "rrseq_by_route_length.tsv",
            [
                "reaction_count",
                "routes",
                "routes_with_RRSeq_cons",
                "routes_with_RRSeq_gap",
                "routes_with_any_RRSeq",
                "mean_cons_occurrences_per_reaction",
                "mean_gap_occurrences_per_reaction",
            ],
        ),
        "",
        "## Interpretation and audit",
        "",
        "These statistics describe corpus recurrence, not chemical quality or preference. "
        "Support bins and length/gap bins may cover overlapping route sets; their route counts must not be added. "
        "Sequence order follows the stored target-to-precursor traversal. "
        "See summary.json, errors.tsv, manifest.json, and the occurrence/identity evidence tables for reproducibility.",
        "",
    ]
    return "\n".join(lines)
