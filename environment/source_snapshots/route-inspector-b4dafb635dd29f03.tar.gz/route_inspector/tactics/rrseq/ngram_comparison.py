"""Read-only length-matched adjacency comparison using persisted query witnesses."""

from __future__ import annotations

import argparse
import json
import tempfile
import time
from collections import Counter, defaultdict
from pathlib import Path

from route_inspector.composite_rules.overlap import (
    CACHE_ARTIFACTS,
    OVERLAP_VERSION,
    OverlapIndex,
)
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.infrastructure.publication import publish_directory_no_replace
from route_inspector.reference_library.catalog import ReferenceTacticLibrary
from route_inspector.reference_library.identity import transformation
from route_inspector.routes.access import (
    reaction_nodes,
    reaction_smiles_from_node,
    route_items,
)
from route_inspector.rules import canonical, graph, preparation
from route_inspector.rules import transformation as rule_transformation
from route_inspector.rules.preparation import (
    _structural_reaction_paths_from_node,
    root_reaction_nodes_with_paths,
)
from route_inspector.rules.transformation import POLICY
from route_inspector.tactics.rrseq.statistics import OrderedIdentityIndex
from route_inspector.tactics.rrseq.statistics_io import record, write_json, write_tsv

ERROR_FIELDS = ("severity", "stage", "record_id", "message")


def _implementation_records():
    """Hash the imported implementation, independently of the invocation directory."""
    return [
        record(Path(__file__)),
        record(Path(__file__).with_name("ngram_reporting.py")),
        record(Path(__file__).with_name("ngram_legacy.py")),
        record(Path(__file__).with_name("statistics.py")),
        record(Path(transformation.__file__)),
        record(Path(preparation.__file__)),
        record(Path(rule_transformation.__file__)),
        record(Path(graph.__file__)),
        record(Path(canonical.__file__)),
    ]


def adjacent_windows(route, lengths):
    """Unique exact segments, with shared-prefix branch memberships retained."""
    windows = {}
    for root_index, root_path, root in root_reaction_nodes_with_paths(route):
        for branch_index, path in enumerate(
            _structural_reaction_paths_from_node(root, root_path)
        ):
            for length in lengths:
                for start in range(len(path) - length + 1):
                    selected = tuple(path[start : start + length])
                    row = windows.setdefault(
                        selected,
                        {
                            "root_index": root_index,
                            "branch_indices": [],
                            "start_position": start,
                            "end_position_exclusive": start + length,
                        },
                    )
                    row["branch_indices"].append(branch_index)
    return windows


def classify(total, localized):
    if not 0 <= localized <= total or total <= 0:
        raise ValueError("Invalid localized/adjacent occurrence counts")
    return (
        "never_localized"
        if localized == 0
        else ("localized_only" if localized == total else "mixed")
    )


def _current_cache_identity(cache_dir):
    manifest = json.loads((cache_dir / "manifest.json").read_text())
    identity = manifest["identity"]
    if identity.get("version") != OVERLAP_VERSION:
        raise ValueError(
            f"Unsupported single-step cache version {identity.get('version')!r}; "
            f"expected current GUI cache version {OVERLAP_VERSION}. "
            "Prepare a current cache for this library before running the analysis."
        )
    return identity


def checked_cache(cache_dir, library, routes, dataset_id, source_identity, index):
    """Verify an existing complete cache; never extract or parse SMARTS."""
    identity = _current_cache_identity(cache_dir)
    if (
        identity["identity_policy"] != POLICY
        or identity["reference_library_id"] != library.manifest.library_id
        or identity["source_sha256"] != source_identity.removeprefix("sha256:")
        or identity["processing_profile"]
        != library.manifest.processing_profile.to_dict()
    ):
        raise ValueError(
            "Single-step cache identity/profile is incompatible with the reference library"
        )
    steps, witnesses = {}, {}
    with OverlapIndex(cache_dir, identity) as overlap:
        summary = overlap.summary
        count = sum(1 for route in routes.values() for _ in reaction_nodes(route))
        if (
            summary["successful_reactions"] != count
            or summary["total_reactions"] != count
            or summary["routes"] != len(routes)
            or summary["failed_reactions"]
            or summary["skipped_reactions"]
        ):
            raise ValueError(
                "Baseline requires complete single-step evidence; cached failures/skips must be resolved upstream"
            )
        connection = overlap.connection
        labels = {}
        for rule_id, encoding in connection.execute(
            "SELECT id,encoding FROM rules ORDER BY id"
        ):
            graph = json.loads(encoding)
            label = f"analysis_rule_{index.index.family(graph):06d}"
            labels[rule_id] = label
            witnesses.setdefault(
                label,
                {
                    "rule_identity": label,
                    "identity_version": library.tactic_identity_version,
                    "comparison_witness": graph,
                },
            )
        for rule_id, payload in connection.execute(
            "SELECT rule_id,payload FROM steps ORDER BY id"
        ):
            row = json.loads(payload)
            route_id, path = str(row["route_id"]), tuple(row["reaction_node_path"])
            key = (route_id, path)
            if (
                key in steps
                or row["dataset_id"] != dataset_id
                or row["source_identity"] != source_identity
            ):
                raise ValueError("Duplicate or foreign single-step provenance")
            if route_id not in routes:
                raise ValueError("Single-step route missing from corpus")
            steps[key] = (labels[rule_id], row)
    expected = set()
    for route_id, route in routes.items():
        for path, node in reaction_nodes(route):
            key = (route_id, path)
            expected.add(key)
            if key not in steps or steps[key][1][
                "reaction_smiles"
            ] != reaction_smiles_from_node(node):
                raise ValueError(f"Single-step source reaction mismatch: {key}")
    if set(steps) != expected:
        raise ValueError(
            "Single-step cache does not cover the exact source reaction roster"
        )
    return steps, witnesses, summary


def match_occurrences(occurrences, baseline, index, entry_rules, library, errors):
    matched, total, seen = set(), 0, set()
    for occurrence in occurrences:
        total += 1
        oid = occurrence.reference_occurrence_id
        key = (occurrence.route.route_id, occurrence.selected_reaction_node_paths)
        rules = index.rules(occurrence.identity)
        entry_id = library.entry_id_for_occurrence(oid)
        problem = None
        if key in seen:
            problem = (
                "Duplicate RRSeq occurrence at the same exact reaction-node segment"
            )
        elif key not in baseline:
            problem = "RRSeq occurrence missing from adjacent n-grams"
        elif rules != baseline[key]["rules"] or rules != entry_rules[entry_id]:
            problem = "RRSeq ordered rule identity disagrees with source n-gram or owning family"
        elif (
            occurrence.route.dataset_id != baseline[key]["dataset_id"]
            or occurrence.route.source_identity != baseline[key]["source_identity"]
        ):
            problem = "RRSeq source identity differs from baseline"
        if problem:
            errors.append(
                dict(
                    severity="error",
                    stage="occurrence_subset",
                    record_id=oid,
                    message=problem,
                )
            )
        else:
            matched.add(key)
            baseline[key]["rrseq_occurrence_id"] = oid
            baseline[key]["rrseq_entry_id"] = entry_id
        seen.add(key)
    return {
        "rrseq_occurrences_total": total,
        "rrseq_occurrences_matched_to_ngram": len(matched),
        "rrseq_occurrences_missing_from_ngram": total - len(matched),
    }


def analyse(
    library, routes_path, cache_dir, stage, dataset_id, expected_routes, errors
):
    if library.tactic_identity_version not in (3, 4):
        raise ValueError(
            "This analysis requires identity version 3 or 4 and live query-side cache witnesses"
        )
    corpora = library.manifest.reference_corpora
    digest = sha256_file(routes_path)
    if (
        len(corpora) != 1
        or corpora[0]["dataset_id"] != dataset_id
        or corpora[0]["input_sha256"] != digest
    ):
        raise ValueError("Reference source dataset/digest mismatch")
    corpus = corpora[0]
    source_identity = f"sha256:{digest}"
    items = list(route_items(json.loads(routes_path.read_text())))
    routes = {str(k): v for k, v in items}
    if (
        corpus["source_identity"] != source_identity
        or len(routes) != len(items)
        or set(routes) != set(map(str, corpus["route_ids"]))
        or len(routes) != expected_routes
        or len(routes) != corpus["route_count"]
    ):
        raise ValueError("Source route roster mismatch")
    index = OrderedIdentityIndex(library.tactic_identity_version)
    print(
        "Verifying complete cached single-step evidence and indexing query graphs",
        flush=True,
    )
    steps, witnesses, cache_summary = checked_cache(
        cache_dir, library, routes, dataset_id, source_identity, index
    )
    entry_rules = {
        entry.entry_id: index.rules(entry.identity)
        for entry in sorted(library.entries("rrseq_cons"), key=lambda e: e.entry_id)
    }
    lengths = sorted({len(rules) for rules in entry_rules.values()})
    if not lengths:
        raise ValueError("No consecutive RRSeq lengths in the reference library")
    baseline = {}
    reaction_counts = {}
    for route_id, route in routes.items():
        reaction_counts[route_id] = sum(1 for _ in reaction_nodes(route))
        for paths, location in adjacent_windows(route, lengths).items():
            baseline[(route_id, paths)] = {
                "dataset_id": dataset_id,
                "source_identity": source_identity,
                "route_id": route_id,
                "selected_reaction_node_paths": paths,
                **location,
                "rules": tuple(steps[(route_id, path)][0] for path in paths),
                "rrseq_occurrence_id": "",
                "rrseq_entry_id": "",
            }
    print(
        f"Enumerated {len(baseline):,} exact adjacent segments; checking RRSeq subset",
        flush=True,
    )
    validation = match_occurrences(
        library.iter_occurrences(kind="rrseq_cons"),
        baseline,
        index,
        entry_rules,
        library,
        errors,
    )
    support = defaultdict(list)
    for row in baseline.values():
        if row["rrseq_entry_id"]:
            support[row["rrseq_entry_id"]].append(row)
    for entry in library.entries("rrseq_cons"):
        rows = support[entry.entry_id]
        observed_routes = {
            (r["dataset_id"], r["source_identity"], r["route_id"]) for r in rows
        }
        expected_route_keys = {
            (r.dataset_id, r.source_identity, r.route_id)
            for r in entry.reference_routes
        }
        if (
            len(rows) != entry.occurrence_count
            or observed_routes != expected_route_keys
            or len(observed_routes) != entry.route_count
        ):
            errors.append(
                dict(
                    severity="error",
                    stage="support_reconciliation",
                    record_id=entry.entry_id,
                    message="Matched occurrences or route support differ from authoritative entry",
                )
            )
    if validation["rrseq_occurrences_total"] != library.manifest.statistics[
        "occurrences_by_kind"
    ].get("rrseq_cons", 0) or len(entry_rules) != library.manifest.statistics[
        "entries_by_kind"
    ].get("rrseq_cons", 0):
        errors.append(
            dict(
                severity="error",
                stage="support_reconciliation",
                record_id="manifest",
                message="RRSeq counts differ from authoritative manifest",
            )
        )
    families = defaultdict(list)
    route_counts = defaultdict(Counter)
    for row in baseline.values():
        families[row["rules"]].append(row)
        key = (row["route_id"], len(row["rules"]))
        route_counts[key]["adjacent"] += 1
        route_counts[key]["localized"] += bool(row["rrseq_occurrence_id"])
    family_validation = []
    for length in lengths:
        expected = {rules for rules in entry_rules.values() if len(rules) == length}
        missing = expected - families.keys()
        for rules in sorted(missing):
            errors.append(
                dict(
                    severity="error",
                    stage="family_subset",
                    record_id=str(rules),
                    message="RRSeq family missing from adjacent vocabulary",
                )
            )
        family_validation.append(
            dict(
                sequence_length=length,
                rrseq_family_count=len(expected),
                rrseq_families_found_in_ngram=len(expected) - len(missing),
                rrseq_families_missing_from_ngram=len(missing),
            )
        )
    from route_inspector.tactics.rrseq.ngram_reporting import write_analysis

    summary = write_analysis(
        stage, lengths, families, route_counts, reaction_counts, entry_rules
    )
    summary.update(
        dataset_id=dataset_id,
        route_count=len(routes),
        source_identity=source_identity,
        reference_library_id=library.manifest.library_id,
        identity_version=library.tactic_identity_version,
        library_format_version=library.manifest.library_format_version,
        catalog_schema_version=library.manifest.catalog_schema_version,
        occurrence_subset_validation=validation,
        family_subset_validation=family_validation,
        cache_reaction_counts={
            k: cache_summary[k]
            for k in (
                "total_reactions",
                "successful_reactions",
                "skipped_reactions",
                "failed_reactions",
            )
        },
        identity_metrics=dict(index.index.metrics),
    )
    witnesses.update(index.witnesses)
    fallback = sum(
        "exact_representation" in v["comparison_witness"] for v in witnesses.values()
    )
    summary["fallback_rule_representatives"] = fallback
    if fallback:
        errors.append(
            dict(
                severity="warning",
                stage="identity",
                record_id="fallback",
                message=f"{fallback} representatives use conservative exact-representation matching; equivalence may be underestimated.",
            )
        )
    with (stage / "rule_identity_witnesses.jsonl").open("w") as out:
        for label in sorted(witnesses):
            out.write(json.dumps(witnesses[label], sort_keys=True) + "\n")
    occurrence_rows = []
    for row in baseline.values():
        occurrence_rows.append(
            {
                **{k: v for k, v in row.items() if k != "rules"},
                "sequence_length": len(row["rules"]),
                "ordered_rule_identity": row["rules"],
                "localized": bool(row["rrseq_occurrence_id"]),
            }
        )
    write_tsv(
        stage / "ngram_occurrences.tsv",
        occurrence_rows,
        list(occurrence_rows[0]) if occurrence_rows else [],
    )
    old = library.manifest.supplementary_evidence.get("retro_bleu_bigrams", {})
    new = next((r for r in summary["by_length"] if r["sequence_length"] == 2), None)
    summary["previous_bigram_comparison"] = {
        "old_unique_family_count": old.get("retro_bleu_bigram_identity_count"),
        "old_occurrence_count": old.get("retro_bleu_bigram_occurrence_count"),
        "old_identity_configuration": old.get(
            "retro_bleu_bigram_identity_configuration"
        ),
        "new_unique_family_count": new["ngram_unique_family_count"] if new else None,
        "new_occurrence_count": new["ngram_occurrence_count"] if new else None,
        "interpretation": "Same recorded cleaned corpus and processing profile. Old ordered QueryCGR identity version 2 versus current independent complete-query-side transformation identity (version recorded in this summary). No extraction was rerun.",
    }
    summary["status"] = (
        "failed" if any(e["severity"] == "error" for e in errors) else "verified"
    )
    return summary


def build_comparison(
    *,
    library_dir,
    routes_path,
    cache_dir,
    output_dir,
    dataset_id="n1",
    expected_routes=10000,
    verification="full",
):
    destination = Path(output_dir)
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent)
    )
    library_dir, routes_path, cache_dir = map(
        Path, (library_dir, routes_path, cache_dir)
    )
    errors = []
    started = time.monotonic()
    try:
        implementation = _implementation_records()
        # Diagnose unsupported versions before looking for current-only sidecars.
        _current_cache_identity(cache_dir)
        inputs = [
            record(library_dir / "manifest.json"),
            record(routes_path),
            *[record(cache_dir / name) for name in ("manifest.json", *CACHE_ARTIFACTS)],
        ]
        with ReferenceTacticLibrary.load(
            library_dir, verification=verification
        ) as library:
            summary = analyse(
                library,
                routes_path,
                cache_dir,
                stage,
                dataset_id,
                expected_routes,
                errors,
            )
            library_artifacts = library.manifest.to_dict()["artifacts"]
        from route_inspector.tactics.rrseq.ngram_legacy import compare_previous_bigrams

        compare_previous_bigrams(library_dir, library_artifacts, stage, summary)
        summary["elapsed_seconds"] = round(time.monotonic() - started, 3)
        from route_inspector.tactics.rrseq.ngram_reporting import markdown_report, plots

        write_json(stage / "summary.json", summary)
        write_tsv(stage / "errors.tsv", errors, ERROR_FIELDS)
        (stage / "report.md").write_text(markdown_report(summary))
        if summary["status"] == "verified":
            plots(stage, summary)
        write_json(
            stage / "manifest.json",
            {
                "analysis": "rrseq_ngram_comparison",
                "analysis_schema_version": 1,
                "status": summary["status"],
                "inputs": inputs,
                "reference_library_artifacts": library_artifacts,
                "identity_policy": POLICY,
                "sequence_order": "retrosynthetic: target to precursors/building blocks",
                "occurrence_definition": "Exact route and ordered reaction-node paths; shared-prefix branch memberships unioned, not counted repeatedly.",
                "implementation": implementation,
                "artifacts": {
                    p.name: {**record(p), "path": p.name}
                    for p in sorted(stage.iterdir())
                },
            },
        )
        for item in inputs:
            if record(item["path"]) != item:
                raise ValueError(f"Input changed during analysis: {item['path']}")
        publish_directory_no_replace(stage, destination)
        return summary
    except Exception as exc:
        errors.append(
            dict(
                severity="error",
                stage="analysis",
                record_id="",
                message=f"{type(exc).__name__}: {exc}",
            )
        )
        write_tsv(stage / "errors.tsv", errors, ERROR_FIELDS)
        write_json(stage / "summary.json", {"status": "failed", "message": str(exc)})
        print(f"Incomplete diagnostics retained at {stage}", flush=True)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--library", default="outputs/reference_libraries/n1")
    parser.add_argument("--routes", default="data/clean/n1_routes.json")
    parser.add_argument("--single-step-cache", required=True)
    parser.add_argument("--output-dir", default="outputs/n1/rrseq_ngram_comparison")
    parser.add_argument("--dataset", default="n1")
    parser.add_argument("--expected-routes", type=int, default=10000)
    parser.add_argument("--verification", choices=("full", "fast"), default="full")
    args = parser.parse_args()
    summary = build_comparison(
        library_dir=args.library,
        routes_path=args.routes,
        cache_dir=args.single_step_cache,
        output_dir=args.output_dir,
        dataset_id=args.dataset,
        expected_routes=args.expected_routes,
        verification=args.verification,
    )
    print(json.dumps(summary["by_length"], indent=2))
    return 0 if summary["status"] == "verified" else 1


if __name__ == "__main__":
    raise SystemExit(main())
