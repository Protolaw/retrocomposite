"""Per-route RRSeq-cons and RRSeq-gap occurrence extraction."""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from route_inspector.datasets.paroutes.source_ids import PAROUTES_SOURCE_ID_ADAPTER
from route_inspector.infrastructure.artifacts import dataset_prefix_from_path
from route_inspector.rules.extraction import (
    SynPlannerRuleExtractor,
    serialize_reaction_rule_step,
)
from route_inspector.rules.models import (
    PreparedRootReactionPaths,
    PreparedRouteRuleData,
    RouteProcessingStats,
)
from route_inspector.rules.preparation import (
    _detailed_root_path_groups,
    _located_root_path_groups,
    prepare_route_rule_data,
    route_target_smiles,
)
from route_inspector.tactics.rrseq.enumeration import (
    gapped_connector_maps,
    gapped_gap_contexts,
    mapped_local_context,
    stable_rrseq_gap_occurrence_id,
    valid_rrseq_cons_occurrence_records,
    valid_rrseq_gap_occurrence_records,
)
from route_inspector.tactics.rrseq.gapped import (
    RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION,
    RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION,
)
from route_inspector.tactics.rrseq.naming import (
    RRSEQ_CONS_KIND,
    RRSEQ_GAP_KIND,
    normalize_rrseq_kind,
)
from route_inspector.tactics.rrseq.occurrence_builders import rrseq_cons_occurrence
from route_inspector.tactics.rrseq.occurrences import RRseqConsOccurrence


def extract_route_rule_sequences(
    route: dict[str, Any],
    rule_extractor: SynPlannerRuleExtractor,
    *,
    min_length: int,
    max_length: int | None,
    stats: RouteProcessingStats,
    sequence_mode: str = RRSEQ_CONS_KIND,
    route_id: Any = "",
    source_identity: str = "",
    dataset_id: str = "",
    source_id_adapter: str = PAROUTES_SOURCE_ID_ADAPTER,
    sequence_query_cgr_keys: (dict[tuple[str, ...], tuple[str, ...]] | None) = None,
    sequence_base_query_cgr_keys: (
        dict[tuple[str, ...], tuple[str, ...]] | None
    ) = None,
    single_rule_query_cgr_keys: (dict[tuple[str, ...], tuple[str, ...]] | None) = None,
    single_rule_base_query_cgr_keys: (
        dict[tuple[str, ...], tuple[str, ...]] | None
    ) = None,
    single_rule_occurrences: list[dict[str, Any]] | None = None,
    prepared_route: PreparedRouteRuleData | None = None,
    prepared_root_paths: (tuple[PreparedRootReactionPaths, ...] | None) = None,
) -> tuple[
    dict[tuple[str, ...], set[str]],
    dict[tuple[str, ...], set[str]],
    list[dict[str, Any]],
]:
    """Extract route rule sequences from mapped route data.

    Exact SMARTS sequences are collected without structural merging. When identity
    dictionaries are supplied, they receive the native QueryCGR-key tuple used by the
    later, length-scoped aggregation pass.
    """
    sequence_mode = normalize_rrseq_kind(sequence_mode)

    def remember_identity(
        destination: dict[tuple[str, ...], tuple[str, ...]] | None,
        sequence: tuple[str, ...],
        identity: tuple[str, ...],
    ) -> None:
        if destination is None:
            return
        previous = destination.setdefault(sequence, identity)
        if previous != identity:
            raise ValueError("one SMARTS sequence produced conflicting QueryCGR keys")

    dataset_id = str(
        dataset_id
        or (dataset_prefix_from_path(source_identity) if source_identity else "")
    )
    if prepared_route is None:
        prepared_route = prepare_route_rule_data(
            route,
            rule_extractor,
            stats=stats,
            route_id=route_id,
            source_identity=source_identity,
            dataset_id=dataset_id,
            source_id_adapter=source_id_adapter,
            include_single_rule_occurrences=single_rule_occurrences is not None,
        )
    route = prepared_route.route
    single_rules = prepared_route.single_rules
    for sequence, identity in prepared_route.single_rule_query_cgr_keys.items():
        remember_identity(single_rule_query_cgr_keys, sequence, identity)
    for sequence, identity in prepared_route.single_rule_base_query_cgr_keys.items():
        remember_identity(single_rule_base_query_cgr_keys, sequence, identity)
    if single_rule_occurrences is not None:
        single_rule_occurrences.extend(prepared_route.single_rule_occurrences)

    sequences: dict[tuple[str, ...], set[str]] = defaultdict(set)
    gap_occurrences: list[dict[str, Any]] = []
    cons_occurrences: dict[str, RRseqConsOccurrence] = {}
    gapped_history_cache: dict[tuple[str, ...], Any] = {}
    route_target = route_target_smiles(route)
    if sequence_mode == RRSEQ_GAP_KIND:
        for root_index, located_paths in _located_root_path_groups(
            prepared_route,
            prepared_root_paths,
        ):
            for branch_index, located_path in enumerate(located_paths):
                path = [item.step for item in located_path]
                for (
                    sequence,
                    target_smiles,
                    selected_positions,
                ) in valid_rrseq_gap_occurrence_records(
                    path, min_length=min_length, max_length=max_length
                ):
                    selected_set = set(selected_positions)
                    first_position, last_position = (
                        selected_positions[0],
                        selected_positions[-1],
                    )
                    selected_steps = [path[position] for position in selected_positions]
                    reaction_smiles = tuple(
                        step.reaction_smiles for step in selected_steps
                    )
                    skipped_positions = [
                        position
                        for position in range(first_position, last_position + 1)
                        if position not in selected_set
                    ]
                    connector_maps = gapped_connector_maps(path, selected_positions)
                    skipped_center_maps = {
                        atom_map
                        for position in skipped_positions
                        for atom_map in path[position].center_atoms
                    }
                    history = gapped_history_cache.get(reaction_smiles)
                    if history is None:
                        from route_inspector.tactics.rrseq.gapped import (
                            compose_gapped_history,
                        )

                        history = compose_gapped_history(reaction_smiles)
                        gapped_history_cache[reaction_smiles] = history
                    if not history.has_net_change:
                        stats.no_net_selected_change += 1

                    from route_inspector.tactics.rrseq.gapped import (
                        history_provenance_payload,
                    )

                    sequences[sequence].add(target_smiles)
                    remember_identity(
                        sequence_query_cgr_keys,
                        sequence,
                        tuple(step.query_cgr_key for step in selected_steps),
                    )
                    remember_identity(
                        sequence_base_query_cgr_keys,
                        sequence,
                        tuple(step.base_query_cgr_key for step in selected_steps),
                    )
                    selected_contexts = [
                        {
                            "position": position,
                            "context_maps": sorted(
                                mapped_local_context(
                                    path[position].target_smiles,
                                    path[position].center_atoms,
                                    radius=2,
                                )
                            ),
                        }
                        for position in selected_positions
                    ]
                    occurrence_id = stable_rrseq_gap_occurrence_id(
                        source_identity=source_identity,
                        route_id=route_id,
                        root_index=root_index,
                        branch_index=branch_index,
                        selected_positions=selected_positions,
                        reaction_smiles=reaction_smiles,
                    )
                    gap_occurrences.append(
                        {
                            "schema_version": RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION,
                            "identity_version": (RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION),
                            "occurrence_id": occurrence_id,
                            "dataset_id": dataset_id,
                            "route_id": str(route_id),
                            "source_identity": source_identity,
                            "root_index": root_index,
                            "branch_index": branch_index,
                            "start_position": first_position,
                            "selected_positions": list(selected_positions),
                            "inter_selection_gap_widths": [
                                b - a - 1
                                for a, b in zip(
                                    selected_positions, selected_positions[1:]
                                )
                            ],
                            "selected_step_ids": list(selected_positions),
                            "skipped_positions": skipped_positions,
                            "connector_maps": sorted(connector_maps),
                            "skipped_center_maps": sorted(skipped_center_maps),
                            "RRseq_gap": "$".join(sequence),
                            "RRseq": "$".join(sequence),
                            "query_cgr_keys": [
                                step.query_cgr_key for step in selected_steps
                            ],
                            "base_query_cgr_keys": [
                                step.base_query_cgr_key for step in selected_steps
                            ],
                            "route_target_smiles": route_target,
                            "target_molecule": target_smiles,
                            "selected_center_maps": sorted(
                                {
                                    atom_map
                                    for position in selected_positions
                                    for atom_map in path[position].center_atoms
                                }
                            ),
                            "accumulated_history_maps": sorted(
                                {
                                    atom_map
                                    for position in selected_positions
                                    for atom_map in path[position].center_atoms
                                }
                            ),
                            "selected_center_maps_by_step": [
                                {
                                    "position": position,
                                    "center_maps": sorted(path[position].center_atoms),
                                }
                                for position in selected_positions
                            ],
                            "selected_rule_context_maps_by_step": selected_contexts,
                            "selected_rule_context_maps": sorted(
                                {
                                    atom_map
                                    for context in selected_contexts
                                    for atom_map in context["context_maps"]
                                }
                            ),
                            "selected_steps": [
                                {
                                    "position": position,
                                    "reaction_node_path": list(
                                        located_path[position].reaction_node_path
                                    ),
                                    "target_molecule_path": list(
                                        located_path[position].target_molecule_path
                                    ),
                                    "target_molecule": path[position].target_smiles,
                                    "raw_source_record_id": (
                                        located_path[position].raw_source_record_id
                                    ),
                                    "raw_source_id": (
                                        located_path[position].raw_source_record_id
                                    ),
                                    "source_record_id": (
                                        located_path[position].source_record_id
                                    ),
                                    "source_document_id": (
                                        located_path[position].source_document_id
                                    ),
                                    "source_id_adapter": (
                                        located_path[position].source_id_adapter
                                    ),
                                    **serialize_reaction_rule_step(
                                        path[position], include_transformation=False
                                    ),
                                }
                                for position in selected_positions
                            ],
                            "skipped_steps": [
                                {
                                    "position": position,
                                    "reaction_node_path": list(
                                        located_path[position].reaction_node_path
                                    ),
                                    "target_molecule_path": list(
                                        located_path[position].target_molecule_path
                                    ),
                                    "target_molecule": path[position].target_smiles,
                                    "raw_source_record_id": (
                                        located_path[position].raw_source_record_id
                                    ),
                                    "raw_source_id": (
                                        located_path[position].raw_source_record_id
                                    ),
                                    "source_record_id": (
                                        located_path[position].source_record_id
                                    ),
                                    "source_document_id": (
                                        located_path[position].source_document_id
                                    ),
                                    "source_id_adapter": (
                                        located_path[position].source_id_adapter
                                    ),
                                    **serialize_reaction_rule_step(
                                        path[position], include_transformation=False
                                    ),
                                }
                                for position in skipped_positions
                            ],
                            "gap_contexts": gapped_gap_contexts(
                                path,
                                selected_positions,
                            ),
                            "has_persistent_net_change": bool(history.has_net_change),
                            "route_cgr_provenance": history_provenance_payload(
                                history,
                                selected_positions,
                            ),
                        }
                    )
        occurrences = gap_occurrences
    else:
        for root_index, detailed_paths in _detailed_root_path_groups(
            prepared_route,
            prepared_root_paths,
        ):
            for branch_index, detailed_path in enumerate(detailed_paths):
                path = [item.step for item in detailed_path]
                for (
                    sequence,
                    target_smiles,
                    start_position,
                    end_position,
                ) in valid_rrseq_cons_occurrence_records(
                    path,
                    min_length=min_length,
                    max_length=max_length,
                ):
                    sequences[sequence].add(target_smiles)
                    remember_identity(
                        sequence_query_cgr_keys,
                        sequence,
                        tuple(
                            path[position].query_cgr_key
                            for position in range(start_position, end_position)
                        ),
                    )
                    remember_identity(
                        sequence_base_query_cgr_keys,
                        sequence,
                        tuple(
                            path[position].base_query_cgr_key
                            for position in range(start_position, end_position)
                        ),
                    )
                    occurrence = rrseq_cons_occurrence(
                        detailed_path,
                        start_position=start_position,
                        end_position=end_position,
                        source_identity=source_identity,
                        route_id=route_id,
                        route_target=route_target,
                        root_index=root_index,
                        branch_index=branch_index,
                        dataset_id=dataset_id,
                    )
                    existing = cons_occurrences.get(occurrence.occurrence_id)
                    cons_occurrences[occurrence.occurrence_id] = (
                        occurrence
                        if existing is None
                        else existing.with_branch_index(branch_index)
                    )
        occurrences = [
            occurrence.to_dict()
            for occurrence in sorted(
                cons_occurrences.values(),
                key=lambda item: item.occurrence_id,
            )
        ]
    return sequences, single_rules, occurrences


def extract_route_rrseq_cons(
    route: dict[str, Any],
    rule_extractor: SynPlannerRuleExtractor,
    *,
    min_length: int,
    max_length: int | None,
    stats: RouteProcessingStats,
) -> dict[tuple[str, ...], set[str]]:
    """Extract RRseq_cons values from mapped route data.

    The result preserves reaction order and the shared-center constraint used to decide
    whether adjacent route steps form a valid rrseq rule.
    """
    sequences, _single_rules, _occurrences = extract_route_rule_sequences(
        route,
        rule_extractor,
        min_length=min_length,
        max_length=max_length,
        stats=stats,
    )
    return sequences


def extract_route_rrseq_gap(
    route: dict[str, Any],
    rule_extractor: SynPlannerRuleExtractor,
    *,
    min_length: int,
    max_length: int | None,
    stats: RouteProcessingStats,
) -> dict[tuple[str, ...], set[str]]:
    """Extract analysis-only RRseq_gap values from mapped route data."""
    sequences, _single_rules, _occurrences = extract_route_rule_sequences(
        route,
        rule_extractor,
        min_length=min_length,
        max_length=max_length,
        stats=stats,
        sequence_mode=RRSEQ_GAP_KIND,
    )
    return sequences


def no_rrseq_reason(
    *,
    reactions_seen: int,
    extracted_reaction_rules: int,
    skipped_reactions: int,
    min_length: int,
    no_net_selected_change: int = 0,
) -> str:
    """Explain why a processed route produced no rrseqs.

    The result preserves reaction order and the shared-center constraint used to decide
    whether adjacent route steps form a valid rrseq rule.
    """
    if reactions_seen == 0:
        return "no_reactions"
    if extracted_reaction_rules == 0 and skipped_reactions:
        return "all_reactions_skipped"
    if extracted_reaction_rules < min_length:
        return "fewer_than_min_length_extracted_reactions"
    if no_net_selected_change:
        return "no_net_selected_change"
    return "no_reaction_center_sharing_sequence"


__all__ = [
    "extract_route_rrseq_cons",
    "extract_route_rrseq_gap",
    "extract_route_rule_sequences",
    "no_rrseq_reason",
]
