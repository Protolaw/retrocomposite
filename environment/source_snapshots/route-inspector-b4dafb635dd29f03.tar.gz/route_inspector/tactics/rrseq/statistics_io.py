"""Small deterministic output and provenance helpers for RRSeq statistics."""

import csv
import json
import math
from pathlib import Path
from statistics import mean, median

from route_inspector.chemistry.classification.common import valid_tier3
from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.routes.access import reaction_smiles_from_node


def write_tsv(path, rows, fields):
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    k: json.dumps(v, sort_keys=True, separators=(",", ":"))
                    if isinstance(v, (list, tuple, dict))
                    else v
                    for k, v in row.items()
                }
            )


def write_json(path, value):
    Path(path).write_text(
        json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    )


def record(path):
    path = Path(path)
    # Resolve for access only: published metadata stays relative to the invocation cwd.
    import os

    return {
        "path": os.path.relpath(path),
        "sha256": sha256_file(path),
        "size_bytes": path.stat().st_size,
    }


def quantile(values, probability):
    """Linear interpolation at (n-1)*p, including singleton samples."""
    values = sorted(values)
    if not values:
        return None
    position = (len(values) - 1) * probability
    lo, hi = math.floor(position), math.ceil(position)
    return values[lo] + (values[hi] - values[lo]) * (position - lo)


def describe(values):
    values = list(values)
    return {
        "mean": mean(values) if values else None,
        "median": median(values) if values else None,
        **{f"q{p}": quantile(values, p / 100) for p in (25, 75)},
    }


def support_bin(support):
    for low, high, label in SUPPORT_BINS:
        if low <= support <= high:
            return label
    raise ValueError("family support must be positive")


SUPPORT_BINS = [
    (1, 1, "1"),
    (2, 2, "2"),
    (3, 5, "3-5"),
    (6, 10, "6-10"),
    (11, 20, "11-20"),
    (21, 50, "21-50"),
    (51, float("inf"), ">50"),
]


def node_at(root, path):
    node = root
    for index in path:
        node = node["children"][index]
    if node.get("type") != "reaction":
        raise ValueError(f"path {path} does not point to a reaction")
    return node


class NameRxnAnnotations:
    """Read existing RouteInspector reference-step TSVs; never invoke a provider.

    Exact source reactions, not family representatives, own annotations. Repeated
    evidence is allowed only when it agrees. Missing labels remain distinguishable
    from an explicit unclassified provider result.
    """

    def __init__(self, paths, *, routes, dataset_id, source_identity):
        self.labels = {}
        self.input_rows = 0
        self.versions = set()
        self.diagnostics = {}
        for path in paths:
            with Path(path).open(encoding="utf-8", newline="") as handle:
                reader = csv.DictReader(handle, delimiter="\t")
                required = {
                    "route_id",
                    "reaction_node_path",
                    "mapped_reaction",
                    "provider",
                    "provider_version",
                    "taxonomy",
                    "tier3_code",
                    "tier3_name",
                    "accepted",
                }
                if not required <= set(reader.fieldnames or ()):
                    raise ValueError(
                        f"{path}: missing NameRxn step fields {sorted(required - set(reader.fieldnames or ()))}"
                    )
                for row in reader:
                    self.input_rows += 1
                    supplied_dataset = row.get("dataset_id", row.get("dataset", ""))
                    if supplied_dataset != dataset_id:
                        raise ValueError(f"{path}: annotation dataset mismatch")
                    if row.get("source_identity", source_identity) != source_identity:
                        raise ValueError(f"{path}: annotation source identity mismatch")
                    if (
                        row["provider"].lower() != "namerxn"
                        or row["taxonomy"].lower() != "namerxn"
                    ):
                        raise ValueError(f"{path}: annotation is not NameRxn")
                    version = row["provider_version"]
                    import re

                    if not re.search(r"(?<!\d)3\.2(?:\D|$)", version):
                        raise ValueError(
                            f"{path}: expected NameRxn 3.2, found {version!r}"
                        )
                    self.versions.add(version)
                    route_id = row["route_id"]
                    node_path = tuple(json.loads(row["reaction_node_path"]))
                    if any(type(index) is not int or index < 0 for index in node_path):
                        raise ValueError(f"{path}: invalid reaction node path")
                    node = node_at(routes[route_id], node_path)
                    if row["mapped_reaction"] != reaction_smiles_from_node(node):
                        raise ValueError(
                            f"{path}: annotation reaction mismatch at route {route_id}, {node_path}"
                        )
                    if row["accepted"].lower() not in {"true", "false"}:
                        raise ValueError(f"{path}: accepted must be true or false")
                    accepted = row["accepted"].lower() == "true"
                    code = row["tier3_code"]
                    if accepted and (not valid_tier3(code) or row.get("error")):
                        raise ValueError(f"{path}: invalid accepted NameRxn annotation")
                    label = (
                        (code, row["tier3_name"], "classified")
                        if accepted
                        else (
                            "UNCLASSIFIED",
                            row["tier3_name"],
                            row.get("status") or "unclassified",
                        )
                    )
                    key = (route_id, node_path)
                    if row.get("error") or row.get("status") == "invalid_tier3":
                        self.diagnostics[key] = {
                            "severity": "warning",
                            "stage": "namerxn_source_annotation",
                            "record_id": f"{dataset_id}/{route_id}/{json.dumps(node_path)}",
                            "message": row.get("error")
                            or (
                                "Not accepted under the existing single Tier-3 label policy: "
                                + row.get("raw_code", "")
                            ),
                        }
                    if key in self.labels and self.labels[key] != label:
                        raise ValueError(f"{path}: conflicting annotations at {key}")
                    self.labels[key] = label

    def sequence(self, route_id, paths):
        labels = [
            self.labels.get((route_id, tuple(p)), ("MISSING_ANNOTATION", "", "missing"))
            for p in paths
        ]
        classified = sum(valid_tier3(label[0]) for label in labels)
        status = (
            "fully_classified"
            if classified == len(labels)
            else ("partially_classified" if classified else "unclassified")
        )
        return (
            tuple(x[0] for x in labels),
            tuple(x[1] for x in labels),
            status,
            sum(x[2] == "missing" for x in labels),
        )
