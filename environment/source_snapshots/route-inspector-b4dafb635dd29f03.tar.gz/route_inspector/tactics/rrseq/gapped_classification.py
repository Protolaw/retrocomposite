"""Classify exact gapped RRSeq occurrences by structural factorability.

The classifier operates on normalized, continuously atom-mapped route witnesses.  Its
``factorable`` label is deliberately structural: it does not assert experimental
independence of the skipped chemistry, reaction conditions, selectivity, or feasibility.
"""

from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from dataclasses import asdict, dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from route_inspector.infrastructure.artifacts import dataset_prefix_from_path
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.text import open_text
from route_inspector.tactics.rrseq.unwrap import (
    ChythonOneShotTraceAdapter,
    UnsupportedReactorTraceError,
)


class GappedRRSeqClass(str, Enum):
    FACTORABLE = "factorable"
    UNFACTORABLE = "unfactorable"
    COMPLEMENTARY = "complementary"
    UNRESOLVED = "unresolved"


class SelectedOnlyReplayStatus(str, Enum):
    NOT_RUN = "not_run"
    UNIQUE = "replay_unique"
    AMBIGUOUS = "replay_ambiguous"
    FAILED = "replay_failed"
    OUTCOME_LIMIT = "replay_outcome_limit_reached"
    MAPPING_FAILED = "replay_mapping_failed"


@dataclass(frozen=True)
class SelectedOnlyReplayResult:
    status: str
    viable_trajectories: int
    outcomes_examined: int
    truncated: bool
    trajectories: tuple[dict[str, Any], ...] = ()
    error_type: str | None = None
    error_message: str | None = None


@dataclass(frozen=True)
class GappedRRSeqClassification:
    occurrence_id: str
    classification: str
    reason_codes: tuple[str, ...]
    has_persistent_net_change: bool
    has_transient_restoration: bool
    skipped_connector_overlap: bool
    skipped_selected_center_overlap: bool
    skipped_selected_context_overlap: bool
    local_context_invariant: bool | None
    selected_only_replay_status: str
    selected_only_replay_outcomes: int
    protection_pair: bool
    certified: bool
    transient_atom_maps: tuple[int, ...] = ()
    transient_bond_maps: tuple[tuple[int, int], ...] = ()
    restoration_type: str | None = None
    pg_type: str | None = None
    overlapping_connector_maps: tuple[int, ...] = ()
    overlapping_selected_center_maps: tuple[int, ...] = ()
    overlapping_selected_context_maps: tuple[int, ...] = ()
    gap_diagnostics: tuple[dict[str, Any], ...] = ()
    change_ledger: tuple[dict[str, Any], ...] = ()
    replay_trace: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SelectedChangeLedger:
    records: tuple[dict[str, Any], ...]
    persistent_features: tuple[str, ...]
    restored_features: tuple[str, ...]
    transient_atom_maps: tuple[int, ...]
    transient_bond_maps: tuple[tuple[int, int], ...]
    atom_restoration: bool
    bond_restoration: bool

    @property
    def has_real_change(self) -> bool:
        return bool(self.records)

    @property
    def has_persistent_net_change(self) -> bool:
        return bool(self.persistent_features)

    @property
    def has_transient_restoration(self) -> bool:
        return bool(self.restored_features)


def _json_scalar(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    try:
        return int(value)
    except (TypeError, ValueError):
        return str(value)


def _atom_state(atom: Any) -> dict[str, Any]:
    return {
        "atomic_number": _json_scalar(getattr(atom, "atomic_number", None)),
        "formal_charge": _json_scalar(getattr(atom, "charge", None)),
        "radical": _json_scalar(getattr(atom, "is_radical", None)),
        "isotope": _json_scalar(getattr(atom, "isotope", None)),
        "implicit_hydrogens": _json_scalar(getattr(atom, "implicit_hydrogens", None)),
        "hybridization": _json_scalar(getattr(atom, "hybridization", None)),
    }


def _bond_state(bond: Any) -> dict[str, Any]:
    try:
        order = int(bond)
    except (TypeError, ValueError):
        order = _json_scalar(getattr(bond, "order", None))
    return {
        "order": order,
    }


def _side_states(
    molecules: Iterable[Any],
) -> tuple[
    dict[int, dict[str, Any]],
    dict[tuple[int, int], dict[str, Any]],
]:
    atoms: dict[int, dict[str, Any]] = {}
    bonds: dict[tuple[int, int], dict[str, Any]] = {}
    for molecule in molecules:
        for atom_number, atom in molecule.atoms():
            atoms[int(atom_number)] = _atom_state(atom)
        for atom_1, atom_2, bond in molecule.bonds():
            key = tuple(sorted((int(atom_1), int(atom_2))))
            bonds[key] = _bond_state(bond)
    return atoms, bonds


def build_selected_change_ledger(
    occurrence: Mapping[str, Any],
) -> SelectedChangeLedger:
    """Build an exact mapped atom/bond state ledger in retrosynthetic order."""

    from chython import smiles as parse_smiles

    by_feature: dict[str, list[dict[str, Any]]] = defaultdict(list)
    records: list[dict[str, Any]] = []
    selected_steps = tuple(occurrence.get("selected_steps") or ())
    for selected_step_number, step in enumerate(selected_steps):
        reaction_smiles = step.get("reaction_smiles")
        if not reaction_smiles:
            continue
        reaction = parse_smiles(str(reaction_smiles))
        # Stored route reactions are forward synthesis reactions.  Gapped RRSeqs are
        # traversed retrosynthetically, so product is state_before and reactants are
        # state_after.
        before_atoms, before_bonds = _side_states(reaction.products)
        after_atoms, after_bonds = _side_states(reaction.reactants)
        route_position = int(step.get("position", selected_step_number))
        for atom_map in sorted(set(before_atoms) | set(after_atoms)):
            state_before = before_atoms.get(atom_map)
            state_after = after_atoms.get(atom_map)
            if state_before == state_after:
                continue
            feature = f"atom:{atom_map}"
            record = {
                "feature": feature,
                "feature_type": "atom",
                "atom_map": atom_map,
                "selected_step_number": selected_step_number,
                "route_position": route_position,
                "state_before": state_before,
                "state_after": state_after,
            }
            by_feature[feature].append(record)
            records.append(record)
        for endpoints in sorted(set(before_bonds) | set(after_bonds)):
            state_before = before_bonds.get(endpoints)
            state_after = after_bonds.get(endpoints)
            if state_before == state_after:
                continue
            feature = f"bond:{endpoints[0]}-{endpoints[1]}"
            record = {
                "feature": feature,
                "feature_type": "bond",
                "atom_maps": list(endpoints),
                "selected_step_number": selected_step_number,
                "route_position": route_position,
                "state_before": state_before,
                "state_after": state_after,
            }
            by_feature[feature].append(record)
            records.append(record)

    persistent: list[str] = []
    restored: list[str] = []
    transient_atoms: set[int] = set()
    transient_bonds: set[tuple[int, int]] = set()
    atom_restoration = False
    bond_restoration = False
    for feature, feature_records in sorted(by_feature.items()):
        first_state = feature_records[0]["state_before"]
        final_state = feature_records[-1]["state_after"]
        if first_state != final_state:
            persistent.append(feature)
            continue
        if len(feature_records) < 2:
            continue
        states = [first_state]
        states.extend(record["state_after"] for record in feature_records)
        if not any(state != first_state for state in states[1:-1]):
            continue
        restored.append(feature)
        first_record = feature_records[0]
        if first_record["feature_type"] == "atom":
            atom_restoration = True
            transient_atoms.add(int(first_record["atom_map"]))
        else:
            bond_restoration = True
            endpoints = tuple(int(value) for value in first_record["atom_maps"])
            transient_bonds.add(endpoints)
            transient_atoms.update(endpoints)

    return SelectedChangeLedger(
        records=tuple(records),
        persistent_features=tuple(persistent),
        restored_features=tuple(restored),
        transient_atom_maps=tuple(sorted(transient_atoms)),
        transient_bond_maps=tuple(sorted(transient_bonds)),
        atom_restoration=atom_restoration,
        bond_restoration=bond_restoration,
    )


def _molecule_graph(molecule_smiles: str) -> tuple[Any, dict[int, set[int]]]:
    from chython import smiles as parse_smiles

    molecule = parse_smiles(molecule_smiles)
    adjacency: dict[int, set[int]] = defaultdict(set)
    for atom_1, atom_2, _bond in molecule.bonds():
        atom_1 = int(atom_1)
        atom_2 = int(atom_2)
        adjacency[atom_1].add(atom_2)
        adjacency[atom_2].add(atom_1)
    return molecule, adjacency


def _context_maps(
    molecule: Any,
    adjacency: Mapping[int, set[int]],
    center_maps: Iterable[int],
    radius: int,
) -> set[int]:
    available = {int(atom_number) for atom_number in molecule}
    visited = {int(value) for value in center_maps} & available
    frontier = set(visited)
    for _distance in range(radius):
        frontier = {
            neighbor
            for atom_number in frontier
            for neighbor in adjacency.get(atom_number, ())
            if neighbor not in visited
        }
        if not frontier:
            break
        visited.update(frontier)
    return visited


def selected_rule_context_maps(
    occurrence: Mapping[str, Any],
    *,
    context_radius: int,
) -> tuple[set[int], tuple[dict[str, Any], ...]]:
    """Project a conservative mapped rule environment for every selected step."""

    contexts: list[dict[str, Any]] = []
    union: set[int] = set()
    for step in occurrence.get("selected_steps") or ():
        position = int(step.get("position", len(contexts)))
        center = {int(value) for value in step.get("center_atoms") or ()}
        molecule_smiles = str(step.get("target_molecule") or "")
        if not molecule_smiles or not center:
            contexts.append({"position": position, "context_maps": []})
            continue
        molecule, adjacency = _molecule_graph(molecule_smiles)
        maps = _context_maps(molecule, adjacency, center, context_radius)
        union.update(maps)
        contexts.append({"position": position, "context_maps": sorted(maps)})
    return union, tuple(contexts)


def _local_environment(
    molecule_or_smiles: Any,
    connector_maps: Iterable[int],
    *,
    radius: int,
) -> dict[str, Any] | None:
    from chython import smiles as parse_smiles

    molecule = (
        parse_smiles(molecule_or_smiles)
        if isinstance(molecule_or_smiles, str)
        else molecule_or_smiles
    )
    connectors = {int(value) for value in connector_maps}
    available = {int(atom_number) for atom_number in molecule}
    if not connectors or not connectors <= available:
        return None
    adjacency: dict[int, set[int]] = defaultdict(set)
    for atom_1, atom_2, _bond in molecule.bonds():
        atom_1 = int(atom_1)
        atom_2 = int(atom_2)
        adjacency[atom_1].add(atom_2)
        adjacency[atom_2].add(atom_1)
    maps = _context_maps(molecule, adjacency, connectors, radius)
    atom_states = {
        str(atom_map): _atom_state(molecule.atom(atom_map)) for atom_map in sorted(maps)
    }
    bond_states = {}
    for atom_1, atom_2, bond in molecule.bonds():
        atom_1 = int(atom_1)
        atom_2 = int(atom_2)
        if atom_1 in maps and atom_2 in maps:
            key = f"{min(atom_1, atom_2)}-{max(atom_1, atom_2)}"
            bond_states[key] = _bond_state(bond)
    return {
        "connector_maps": sorted(connectors),
        "context_maps": sorted(maps),
        "atom_states": atom_states,
        "bond_states": dict(sorted(bond_states.items())),
    }


def _changed_environment(
    left: Mapping[str, Any],
    right: Mapping[str, Any],
) -> tuple[list[int], list[list[int]]]:
    changed_atoms = sorted(
        int(atom_map)
        for atom_map in set(left["atom_states"]) | set(right["atom_states"])
        if left["atom_states"].get(atom_map) != right["atom_states"].get(atom_map)
    )
    changed_bonds = []
    for bond in sorted(set(left["bond_states"]) | set(right["bond_states"])):
        if left["bond_states"].get(bond) == right["bond_states"].get(bond):
            continue
        atom_1, atom_2 = bond.split("-", 1)
        changed_bonds.append([int(atom_1), int(atom_2)])
    return changed_atoms, changed_bonds


def _environment_graph(
    environment: Mapping[str, Any],
) -> tuple[
    dict[int, Mapping[str, Any]],
    dict[tuple[int, int], Mapping[str, Any]],
    dict[int, set[int]],
]:
    atoms = {
        int(atom_map): state
        for atom_map, state in environment.get("atom_states", {}).items()
    }
    bonds: dict[tuple[int, int], Mapping[str, Any]] = {}
    adjacency: dict[int, set[int]] = defaultdict(set)
    for key, state in environment.get("bond_states", {}).items():
        atom_1_text, atom_2_text = str(key).split("-", 1)
        atom_1, atom_2 = int(atom_1_text), int(atom_2_text)
        endpoints = tuple(sorted((atom_1, atom_2)))
        bonds[endpoints] = state
        adjacency[atom_1].add(atom_2)
        adjacency[atom_2].add(atom_1)
    return atoms, bonds, adjacency


def local_environments_isomorphic(
    left: Mapping[str, Any],
    right: Mapping[str, Any],
) -> bool:
    """Return exact constitutional isomorphism anchored on connector atom maps.

    Connector identities are route-level lineage constraints.  Other local atom-map
    labels are representation details and may be renumbered.  Stereo is intentionally
    absent from the atom/bond state signatures because RRSeq templates are extracted
    and validated under the project's stereo-agnostic policy.
    """

    left_atoms, left_bonds, left_adjacency = _environment_graph(left)
    right_atoms, right_bonds, right_adjacency = _environment_graph(right)
    if len(left_atoms) != len(right_atoms) or len(left_bonds) != len(right_bonds):
        return False
    left_connectors = {int(value) for value in left.get("connector_maps", ())}
    right_connectors = {int(value) for value in right.get("connector_maps", ())}
    if left_connectors != right_connectors:
        return False

    def incident_signature(
        atom_map: int,
        bonds: Mapping[tuple[int, int], Mapping[str, Any]],
        adjacency: Mapping[int, set[int]],
    ) -> tuple[str, ...]:
        return tuple(
            sorted(
                json.dumps(
                    bonds[tuple(sorted((atom_map, neighbor)))],
                    sort_keys=True,
                    separators=(",", ":"),
                )
                for neighbor in adjacency.get(atom_map, ())
            )
        )

    candidates: dict[int, list[int]] = {}
    for left_atom, left_state in left_atoms.items():
        if left_atom in left_connectors:
            possible = [left_atom] if left_atom in right_atoms else []
        else:
            possible = [
                right_atom
                for right_atom in right_atoms
                if right_atom not in right_connectors
            ]
        candidates[left_atom] = [
            right_atom
            for right_atom in possible
            if left_state == right_atoms[right_atom]
            and len(left_adjacency.get(left_atom, ()))
            == len(right_adjacency.get(right_atom, ()))
            and incident_signature(left_atom, left_bonds, left_adjacency)
            == incident_signature(right_atom, right_bonds, right_adjacency)
        ]
        if not candidates[left_atom]:
            return False

    order = sorted(
        left_atoms,
        key=lambda atom_map: (
            atom_map not in left_connectors,
            len(candidates[atom_map]),
            -len(left_adjacency.get(atom_map, ())),
            atom_map,
        ),
    )
    mapping: dict[int, int] = {}
    used: set[int] = set()

    def compatible(left_atom: int, right_atom: int) -> bool:
        for mapped_left, mapped_right in mapping.items():
            left_bond = left_bonds.get(tuple(sorted((left_atom, mapped_left))))
            right_bond = right_bonds.get(tuple(sorted((right_atom, mapped_right))))
            if left_bond != right_bond:
                return False
        return True

    def visit(position: int) -> bool:
        if position == len(order):
            return True
        left_atom = order[position]
        for right_atom in candidates[left_atom]:
            if right_atom in used or not compatible(left_atom, right_atom):
                continue
            mapping[left_atom] = right_atom
            used.add(right_atom)
            if visit(position + 1):
                return True
            used.remove(right_atom)
            mapping.pop(left_atom)
        return False

    return visit(0)


def test_gap_local_context_invariance(
    occurrence: Mapping[str, Any],
    *,
    context_radius: int,
) -> tuple[bool | None, tuple[dict[str, Any], ...]]:
    """Compare mapping-aware local graph state across every skipped interval."""

    diagnostics: list[dict[str, Any]] = []
    overall: bool | None = True
    gap_contexts = tuple(occurrence.get("gap_contexts") or ())
    if not gap_contexts:
        return None, ()
    for gap in gap_contexts:
        connectors = tuple(int(value) for value in gap.get("connector_maps") or ())
        diagnostic = {
            "left_selected_position": gap.get("left_selected_position"),
            "right_selected_position": gap.get("right_selected_position"),
            "connector_maps": list(connectors),
            "context_radius": context_radius,
            "changed_atom_maps": [],
            "changed_bonds": [],
        }
        try:
            left = _local_environment(
                gap.get("after_left_selected_molecule") or "",
                connectors,
                radius=context_radius,
            )
            right = _local_environment(
                gap.get("before_right_selected_molecule") or "",
                connectors,
                radius=context_radius,
            )
        except Exception as exc:
            left = right = None
            diagnostic["error_type"] = type(exc).__name__
            diagnostic["error_message"] = str(exc)
        if left is None or right is None:
            diagnostic["invariant"] = None
            overall = None if overall is True else overall
        else:
            invariant = local_environments_isomorphic(left, right)
            diagnostic["invariant"] = invariant
            if not invariant:
                overall = False
                changed_atoms, changed_bonds = _changed_environment(left, right)
                diagnostic["changed_atom_maps"] = changed_atoms
                diagnostic["changed_bonds"] = changed_bonds
            diagnostic["state_after_left"] = left
            diagnostic["state_before_right"] = right
        diagnostics.append(diagnostic)
    return overall, tuple(diagnostics)


def _transition_connector_maps(
    selected_steps: Sequence[Mapping[str, Any]],
) -> tuple[set[int], ...]:
    if len(selected_steps) < 2:
        return ()
    history = {int(value) for value in selected_steps[0].get("center_atoms") or ()}
    connectors = []
    for step in selected_steps[1:]:
        center = {int(value) for value in step.get("center_atoms") or ()}
        connectors.append(history & center)
        history.update(center)
    return tuple(connectors)


def replay_selected_only(
    occurrence: Mapping[str, Any],
    *,
    context_radius: int = 2,
    max_replay_outcomes: int = 256,
    adapter: ChythonOneShotTraceAdapter | None = None,
) -> SelectedOnlyReplayResult:
    """Replay selected rules while omitting skipped chemistry.

    Continuations are selected by exact mapped local-graph isomorphism around the
    conserved connector, not by mapped-SMILES string equality.
    """

    if max_replay_outcomes < 1:
        raise ValueError("max_replay_outcomes must be at least 1")
    from chython import smiles as parse_smiles
    from chython.reactor import Reactor

    selected_steps = tuple(occurrence.get("selected_steps") or ())
    if len(selected_steps) < 2:
        return SelectedOnlyReplayResult(
            SelectedOnlyReplayStatus.FAILED.value,
            0,
            0,
            False,
            error_message="a gapped RRSeq requires at least two selected steps",
        )
    try:
        target = parse_smiles(str(occurrence.get("target_molecule") or ""))
        reactors = [
            Reactor.from_smarts(
                str(step["rule_smarts"]),
                delete_atoms=True,
                one_shot=True,
            )
            for step in selected_steps
        ]
    except Exception as exc:
        return SelectedOnlyReplayResult(
            SelectedOnlyReplayStatus.FAILED.value,
            0,
            0,
            False,
            error_type=type(exc).__name__,
            error_message=str(exc),
        )

    trace_adapter = adapter or ChythonOneShotTraceAdapter()
    connectors = _transition_connector_maps(selected_steps)
    active: list[tuple[Any, tuple[dict[str, Any], ...]]] = [(target, ())]
    outcomes_examined = 0
    saw_outcome = False
    for step_index, reactor in enumerate(reactors):
        final_step = step_index == len(reactors) - 1
        next_active: list[tuple[Any, tuple[dict[str, Any], ...]]] = []
        for active_molecule, prior_trace in active:
            remaining = max_replay_outcomes - outcomes_examined
            if remaining < 1:
                return SelectedOnlyReplayResult(
                    SelectedOnlyReplayStatus.OUTCOME_LIMIT.value,
                    len(next_active),
                    outcomes_examined,
                    True,
                    trajectories=tuple(trace for _molecule, trace in next_active),
                )
            try:
                enumeration = trace_adapter.enumerate(
                    reactor,
                    active_molecule,
                    max_unique_outcomes=remaining,
                )
            except UnsupportedReactorTraceError as exc:
                return SelectedOnlyReplayResult(
                    SelectedOnlyReplayStatus.MAPPING_FAILED.value,
                    0,
                    outcomes_examined,
                    False,
                    error_type=type(exc).__name__,
                    error_message=str(exc),
                )
            except Exception as exc:
                return SelectedOnlyReplayResult(
                    SelectedOnlyReplayStatus.FAILED.value,
                    0,
                    outcomes_examined,
                    False,
                    error_type=type(exc).__name__,
                    error_message=str(exc),
                )
            outcomes_examined += len(enumeration.outcomes)
            saw_outcome = saw_outcome or bool(enumeration.outcomes)
            if enumeration.truncated:
                return SelectedOnlyReplayResult(
                    SelectedOnlyReplayStatus.OUTCOME_LIMIT.value,
                    0,
                    outcomes_examined,
                    True,
                )
            for outcome in enumeration.outcomes:
                active_atom_maps = {int(atom_number) for atom_number in active_molecule}
                required_center_maps = {
                    int(value)
                    for value in selected_steps[step_index].get("center_atoms") or ()
                } & active_atom_maps
                if required_center_maps and not any(
                    required_center_maps <= {int(target) for _query, target in mapping}
                    for mapping in outcome.query_to_target_mappings
                ):
                    continue
                base_trace = {
                    "step_index": step_index,
                    "outcome_index": outcome.outcome_index,
                    "input_smiles": format(active_molecule, "m"),
                    "reaction_smiles": outcome.reaction_smiles,
                    "query_to_target_mappings": [
                        [list(pair) for pair in mapping]
                        for mapping in outcome.query_to_target_mappings
                    ],
                }
                if final_step:
                    next_active.append((active_molecule, (*prior_trace, base_trace)))
                    continue
                transition_maps = connectors[step_index]
                expected_target = selected_steps[step_index + 1].get("target_molecule")
                expected_environment = _local_environment(
                    str(expected_target or ""),
                    transition_maps,
                    radius=context_radius,
                )
                if expected_environment is None:
                    continue
                for product_index, product in enumerate(outcome.products):
                    product_environment = _local_environment(
                        product,
                        transition_maps,
                        radius=context_radius,
                    )
                    if product_environment is None or not local_environments_isomorphic(
                        product_environment,
                        expected_environment,
                    ):
                        continue
                    next_active.append(
                        (
                            product,
                            (
                                *prior_trace,
                                {
                                    **base_trace,
                                    "continuation_product_index": product_index,
                                },
                            ),
                        )
                    )
        if final_step:
            active = next_active
            break
        deduplicated: dict[str, tuple[Any, tuple[dict[str, Any], ...]]] = {}
        for molecule, trace in next_active:
            trace_key = json.dumps(trace, sort_keys=True, separators=(",", ":"))
            key = f"{format(molecule, 'm')}|{trace_key}"
            deduplicated.setdefault(key, (molecule, trace))
        active = list(deduplicated.values())
        if not active:
            status = (
                SelectedOnlyReplayStatus.MAPPING_FAILED
                if saw_outcome
                else SelectedOnlyReplayStatus.FAILED
            )
            return SelectedOnlyReplayResult(
                status.value,
                0,
                outcomes_examined,
                False,
            )

    trajectories = tuple(trace for _molecule, trace in active)
    if not trajectories:
        return SelectedOnlyReplayResult(
            (
                SelectedOnlyReplayStatus.MAPPING_FAILED.value
                if saw_outcome
                else SelectedOnlyReplayStatus.FAILED.value
            ),
            0,
            outcomes_examined,
            False,
        )
    return SelectedOnlyReplayResult(
        (
            SelectedOnlyReplayStatus.UNIQUE.value
            if len(trajectories) == 1
            else SelectedOnlyReplayStatus.AMBIGUOUS.value
        ),
        len(trajectories),
        outcomes_examined,
        False,
        trajectories=trajectories,
    )


def _protection_pair(
    occurrence: Mapping[str, Any],
    protection_index: Any,
) -> tuple[bool, str | None]:
    if protection_index is None:
        return False, None
    if callable(protection_index):
        value = protection_index(occurrence)
    elif isinstance(protection_index, Mapping):
        value = protection_index.get(str(occurrence.get("occurrence_id")))
    else:
        value = None
        selected = set(
            int(value) for value in occurrence.get("selected_positions") or ()
        )
        route_id = str(occurrence.get("route_id", ""))
        selected_reactions = {
            str(step.get("reaction_smiles") or "")
            for step in occurrence.get("selected_steps") or ()
            if step.get("reaction_smiles")
        }
        for event in protection_index:
            if str(event.get("route_id", "")) != route_id:
                continue
            positions = {
                int(value)
                for value in (
                    event.get("selected_positions")
                    or event.get("route_positions")
                    or ()
                )
            }
            if positions and positions <= selected:
                value = event
                break
            protection_reaction = str(event.get("protection_reaction_smiles") or "")
            deprotection_reaction = str(event.get("deprotection_reaction_smiles") or "")
            if (
                protection_reaction
                and deprotection_reaction
                and {protection_reaction, deprotection_reaction} <= selected_reactions
            ):
                value = event
                break
    if not value:
        return False, None
    if isinstance(value, str):
        return True, value
    if isinstance(value, Mapping):
        return True, str(
            value.get("pg_type")
            or value.get("protecting_group")
            or value.get("type")
            or ""
        ) or None
    return bool(value), None


def classify_gapped_occurrence(
    occurrence: Mapping[str, Any],
    *,
    context_radius: int = 2,
    max_replay_outcomes: int = 256,
    protection_index: Any = None,
    require_unique_replay: bool = False,
    detect_complementary: bool = False,
) -> GappedRRSeqClassification:
    """Assign exactly one structural class to an exact gapped occurrence."""

    if context_radius < 0:
        raise ValueError("context_radius must be non-negative")
    occurrence_id = str(occurrence.get("occurrence_id") or "")
    connector_maps = {int(value) for value in occurrence.get("connector_maps") or ()}
    selected_center_maps = {
        int(value) for value in occurrence.get("selected_center_maps") or ()
    }
    selected_center_maps.update(
        int(value)
        for step in occurrence.get("selected_steps") or ()
        for value in step.get("center_atoms") or ()
    )
    skipped_center_maps = {
        int(value) for value in occurrence.get("skipped_center_maps") or ()
    }
    skipped_center_maps.update(
        int(value)
        for step in occurrence.get("skipped_steps") or ()
        for value in step.get("center_atoms") or ()
    )
    connector_overlap = connector_maps & skipped_center_maps
    selected_overlap = selected_center_maps & skipped_center_maps
    try:
        context_maps, _contexts = selected_rule_context_maps(
            occurrence,
            context_radius=context_radius,
        )
    except Exception:
        context_maps = {
            int(value) for value in occurrence.get("selected_rule_context_maps") or ()
        }
    context_overlap = context_maps & skipped_center_maps
    try:
        ledger = build_selected_change_ledger(occurrence)
    except Exception:
        ledger = SelectedChangeLedger((), (), (), (), (), False, False)
    persistent = bool(
        occurrence.get(
            "has_persistent_net_change",
            ledger.has_persistent_net_change,
        )
    )
    protection_pair, pg_type = (
        _protection_pair(occurrence, protection_index)
        if detect_complementary
        else (False, None)
    )
    skipped_transient_overlap = skipped_center_maps & set(ledger.transient_atom_maps)
    local_invariant, gap_diagnostics = test_gap_local_context_invariance(
        occurrence,
        context_radius=context_radius,
    )

    base = {
        "occurrence_id": occurrence_id,
        "has_persistent_net_change": persistent,
        "has_transient_restoration": ledger.has_transient_restoration,
        "skipped_connector_overlap": bool(connector_overlap),
        "skipped_selected_center_overlap": bool(selected_overlap),
        "skipped_selected_context_overlap": bool(context_overlap),
        "local_context_invariant": local_invariant,
        "protection_pair": protection_pair,
        "transient_atom_maps": ledger.transient_atom_maps,
        "transient_bond_maps": ledger.transient_bond_maps,
        "restoration_type": (
            "atom_and_bond"
            if ledger.atom_restoration and ledger.bond_restoration
            else "atom"
            if ledger.atom_restoration
            else "bond"
            if ledger.bond_restoration
            else None
        ),
        "pg_type": pg_type,
        "overlapping_connector_maps": tuple(sorted(connector_overlap)),
        "overlapping_selected_center_maps": tuple(sorted(selected_overlap)),
        "overlapping_selected_context_maps": tuple(sorted(context_overlap)),
        "gap_diagnostics": gap_diagnostics,
        "change_ledger": ledger.records,
    }

    def result(
        classification: GappedRRSeqClass,
        reasons: Sequence[str],
        *,
        certified: bool,
        replay: SelectedOnlyReplayResult | None = None,
    ) -> GappedRRSeqClassification:
        replay = replay or SelectedOnlyReplayResult(
            SelectedOnlyReplayStatus.NOT_RUN.value, 0, 0, False
        )
        return GappedRRSeqClassification(
            classification=classification.value,
            reason_codes=tuple(reasons),
            selected_only_replay_status=replay.status,
            selected_only_replay_outcomes=replay.viable_trajectories,
            certified=certified,
            replay_trace=asdict(replay),
            **base,
        )

    if connector_overlap:
        return result(
            GappedRRSeqClass.UNRESOLVED,
            ("invalid_skipped_connector_overlap",),
            certified=False,
        )

    if not persistent and not detect_complementary:
        return result(
            GappedRRSeqClass.UNFACTORABLE,
            ("no_persistent_net_change",),
            certified=True,
        )

    # TODO: Replace this heuristic with a validated complementary-tactic
    # detector before considering it for default classification.
    if (
        detect_complementary
        and ledger.has_real_change
        and ledger.has_transient_restoration
        and not persistent
        and not skipped_transient_overlap
        and local_invariant is True
    ):
        reasons = []
        if ledger.atom_restoration:
            reasons.append("complementary_transient_atom_restoration")
        if ledger.bond_restoration:
            reasons.append("complementary_transient_bond_restoration")
        if protection_pair:
            reasons.append("complementary_protection_deprotection")
        return result(
            GappedRRSeqClass.COMPLEMENTARY,
            reasons,
            certified=True,
        )

    if not persistent:
        return result(
            GappedRRSeqClass.UNRESOLVED,
            ("zero_net_without_resolved_restoration",),
            certified=False,
        )
    if selected_overlap:
        return result(
            GappedRRSeqClass.UNFACTORABLE,
            ("skipped_reaction_changes_selected_center",),
            certified=True,
        )
    if context_overlap:
        return result(
            GappedRRSeqClass.UNFACTORABLE,
            ("skipped_reaction_changes_selected_rule_context",),
            certified=True,
        )
    if local_invariant is False:
        return result(
            GappedRRSeqClass.UNFACTORABLE,
            ("local_context_changed_across_gap",),
            certified=True,
        )
    if local_invariant is None:
        return result(
            GappedRRSeqClass.UNRESOLVED,
            ("local_context_unavailable",),
            certified=False,
        )

    replay = replay_selected_only(
        occurrence,
        context_radius=context_radius,
        max_replay_outcomes=max_replay_outcomes,
    )
    if replay.status == SelectedOnlyReplayStatus.UNIQUE.value:
        return result(
            GappedRRSeqClass.FACTORABLE,
            ("selected_only_replay_unique",),
            certified=True,
            replay=replay,
        )
    if replay.status == SelectedOnlyReplayStatus.AMBIGUOUS.value:
        if require_unique_replay:
            return result(
                GappedRRSeqClass.UNRESOLVED,
                ("selected_only_replay_ambiguous_unique_required",),
                certified=False,
                replay=replay,
            )
        return result(
            GappedRRSeqClass.FACTORABLE,
            ("selected_only_replay_ambiguous",),
            certified=False,
            replay=replay,
        )
    if replay.status in {
        SelectedOnlyReplayStatus.FAILED.value,
        SelectedOnlyReplayStatus.MAPPING_FAILED.value,
    }:
        return result(
            GappedRRSeqClass.UNFACTORABLE,
            ("selected_only_replay_failed", replay.status),
            certified=True,
            replay=replay,
        )
    return result(
        GappedRRSeqClass.UNRESOLVED,
        (replay.status,),
        certified=False,
        replay=replay,
    )


CLASSIFICATION_FIELDS = [
    "occurrence_id",
    "route_id",
    "RRseq_gap",
    "classification",
    "certified",
    "reason_codes",
    "selected_positions",
    "skipped_positions",
    "has_persistent_net_change",
    "has_transient_restoration",
    "connector_maps",
    "skipped_connector_overlap",
    "skipped_selected_center_overlap",
    "skipped_selected_context_overlap",
    "local_context_invariant",
    "selected_only_replay_status",
    "selected_only_replay_outcomes",
    "protection_pair",
]

COMPLEMENTARY_MOTIF_FIELDS = [
    "Complementary_motif_id",
    "RRseq_gap",
    "inter_selection_gap_widths",
    "popularity",
    "Reference",
    "Qualified_references_json",
    "Target_molecules",
    "selected_positions",
    "skipped_positions",
    "transient_atom_maps",
    "transient_bond_maps",
    "restoration_type",
    "protection_pair",
    "pg_type",
    "Source_occurrence_ids",
]


def _cell(value: Any) -> Any:
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, (list, tuple, dict, set)):
        return json.dumps(value, sort_keys=True, separators=(",", ":"))
    return value


def classification_tsv_row(record: Mapping[str, Any]) -> dict[str, Any]:
    return {
        field: _cell(
            record.get(
                field,
                record.get("RRseq") if field == "RRseq_gap" else "",
            )
        )
        for field in CLASSIFICATION_FIELDS
    }


def write_gapped_classification_json(
    path: Path,
    records: Iterable[Mapping[str, Any]],
) -> None:
    """Write detailed classifications as one deterministic JSON array."""

    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write("[")
        for index, record in enumerate(records):
            if index:
                stream.write(",")
            json.dump(record, stream, sort_keys=True, separators=(",", ":"))
        stream.write("]\n")


def _read_occurrence_file(path: Path) -> list[dict[str, Any]]:
    with open_text(path) as stream:
        first = stream.read(1)
        stream.seek(0)
        if first == "[":
            payload = json.load(stream)
            if not isinstance(payload, list):
                raise ValueError(f"gapped occurrence input is not a JSON list: {path}")
            return [dict(item) for item in payload]
        return [dict(json.loads(line)) for line in stream if line.strip()]


def discover_gapped_occurrence_paths(paths: Iterable[Path]) -> list[Path]:
    discovered: set[Path] = set()
    for raw_path in paths:
        path = resolve_existing_path(raw_path)
        if path.is_dir():
            for pattern in (
                "*_rrseq_gap_occurrences.json",
                "*_rrseq_gap_occurrences.jsonl.gz",
                "*_separated_occurrences.json",
            ):
                discovered.update(path.glob(pattern))
        elif path.exists():
            discovered.add(path)
        else:
            raise FileNotFoundError(path)
    if not discovered:
        raise FileNotFoundError("no gapped RRSeq occurrence sidecars were found")
    return sorted(discovered)


def load_gapped_occurrences(
    paths: Iterable[Path],
) -> tuple[list[dict[str, Any]], list[Path]]:
    source_paths = discover_gapped_occurrence_paths(paths)
    by_id: dict[str, dict[str, Any]] = {}
    for path in source_paths:
        for occurrence in _read_occurrence_file(path):
            occurrence_id = str(occurrence.get("occurrence_id") or "")
            if not occurrence_id:
                raise ValueError(f"gapped occurrence in {path} has no occurrence_id")
            previous = by_id.get(occurrence_id)
            if previous is not None and previous != occurrence:
                raise ValueError(
                    f"conflicting gapped occurrence payloads for {occurrence_id}"
                )
            by_id[occurrence_id] = occurrence
    return [by_id[key] for key in sorted(by_id)], source_paths


def _dataset_prefix(path: Path) -> str:
    stem = path.name
    for suffix in (".jsonl.gz", ".json.gz", ".json"):
        if stem.endswith(suffix):
            stem = stem[: -len(suffix)]
            break
    stem = re.sub(r"_(?:rrseq_gap|separated)_occurrences$", "", stem)
    return stem or dataset_prefix_from_path(path)


def complementary_motif_rows(
    records: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    groups: dict[tuple[Any, ...], list[Mapping[str, Any]]] = defaultdict(list)
    for record in records:
        if record.get("classification") != GappedRRSeqClass.COMPLEMENTARY.value:
            continue
        key = (
            record.get("RRseq_gap") or record.get("RRseq"),
            record.get("restoration_type"),
            bool(record.get("protection_pair")),
            record.get("pg_type"),
            tuple(
                b - a - 1
                for a, b in zip(
                    record.get("selected_positions", ()),
                    record.get("selected_positions", ())[1:],
                )
            ),
        )
        groups[key].append(record)
    rows = []
    for motif_index, (key, members) in enumerate(
        sorted(groups.items(), key=lambda item: str(item[0])), 1
    ):
        rrseq, restoration_type, protection_pair, pg_type, widths = key
        qualified_references = sorted(
            {
                (
                    str(member.get("source_identity") or ""),
                    str(member.get("route_id") or ""),
                )
                for member in members
            }
        )
        rows.append(
            {
                "Complementary_motif_id": f"GCM{motif_index:06d}",
                "RRseq_gap": rrseq,
                "inter_selection_gap_widths": _cell(widths),
                "popularity": len(qualified_references),
                "Reference": ",".join(
                    sorted({route for _source, route in qualified_references})
                ),
                "Qualified_references_json": json.dumps(
                    qualified_references, separators=(",", ":")
                ),
                "Target_molecules": ",".join(
                    sorted(
                        {str(member.get("target_molecule") or "") for member in members}
                    )
                ),
                "selected_positions": _cell(
                    [member.get("selected_positions") for member in members]
                ),
                "skipped_positions": _cell(
                    [member.get("skipped_positions") for member in members]
                ),
                "transient_atom_maps": _cell(
                    [
                        {
                            "occurrence_id": member.get("occurrence_id"),
                            "atom_maps": member.get("transient_atom_maps") or [],
                        }
                        for member in members
                    ]
                ),
                "transient_bond_maps": _cell(
                    [
                        {
                            "occurrence_id": member.get("occurrence_id"),
                            "bond_maps": member.get("transient_bond_maps") or [],
                        }
                        for member in members
                    ]
                ),
                "restoration_type": restoration_type,
                "protection_pair": protection_pair,
                "pg_type": pg_type or "",
                "Source_occurrence_ids": ",".join(
                    sorted(str(member.get("occurrence_id")) for member in members)
                ),
            }
        )
    return rows


def classification_summary(
    records: Sequence[Mapping[str, Any]],
    *,
    context_radius: int,
    max_replay_outcomes: int,
    detect_complementary: bool = False,
) -> dict[str, Any]:
    counts = {member.value: 0 for member in GappedRRSeqClass}
    for record in records:
        counts[str(record["classification"])] += 1
    seen = len(records)
    if sum(counts.values()) != seen:
        raise RuntimeError("gapped classification accounting invariant failed")
    reason_counts: dict[str, int] = defaultdict(int)
    for record in records:
        for reason in record.get("reason_codes") or ():
            reason_counts[str(reason)] += 1
    identities = set()
    for record in records:
        positions = record.get("selected_positions", ())
        widths = tuple(b - a - 1 for a, b in zip(positions, positions[1:]))
        selected_steps = record.get("selected_steps") or ()
        query_cgr_keys = tuple(
            str(step.get("query_cgr_key", "")) for step in selected_steps
        )
        if query_cgr_keys and all(query_cgr_keys):
            identities.add(("query_cgr", query_cgr_keys, widths))
            continue
        rrseq = record.get("RRseq_gap", record.get("RRseq", ""))
        if rrseq:
            identities.add(("smarts", str(rrseq), widths))
    unique_rrseq_gap = len(identities)
    return {
        "gapped_occurrences_seen": seen,
        "total_unique_rrseq_gap": unique_rrseq_gap,
        **counts,
        "factorable_certified": sum(
            record.get("classification") == "factorable"
            and bool(record.get("certified"))
            for record in records
        ),
        "factorable_ambiguous_replay": reason_counts["selected_only_replay_ambiguous"],
        "complementary_protection_deprotection": reason_counts[
            "complementary_protection_deprotection"
        ],
        "complementary_other": counts["complementary"]
        - reason_counts["complementary_protection_deprotection"],
        "unfactorable_skipped_selected_center_overlap": reason_counts[
            "skipped_reaction_changes_selected_center"
        ],
        "unfactorable_skipped_selected_context_overlap": reason_counts[
            "skipped_reaction_changes_selected_rule_context"
        ],
        "unfactorable_local_context_changed": reason_counts[
            "local_context_changed_across_gap"
        ],
        "unfactorable_selected_only_replay_failed": reason_counts[
            "selected_only_replay_failed"
        ],
        "unresolved_zero_net_without_restoration": reason_counts[
            "zero_net_without_resolved_restoration"
        ],
        "unresolved_replay_outcome_limit": reason_counts[
            "replay_outcome_limit_reached"
        ],
        "unresolved_invalid_connector_integrity": reason_counts[
            "invalid_skipped_connector_overlap"
        ],
        "context_radius": context_radius,
        "max_replay_outcomes": max_replay_outcomes,
        "detect_complementary": detect_complementary,
        "complementary_detection_status": (
            "experimental_todo" if detect_complementary else "disabled"
        ),
        "accounting_invariant": True,
    }


def load_protection_events(path: Path | None) -> Any:
    if path is None:
        return None
    resolved = resolve_existing_path(path)
    if resolved.suffix == ".tsv" or resolved.name.endswith(".tsv.gz"):
        with open_text(resolved) as stream:
            return list(csv.DictReader(stream, delimiter="\t"))
    with open_text(resolved) as stream:
        payload = json.load(stream)
    if isinstance(payload, Mapping):
        return payload.get("events", payload)
    return payload
