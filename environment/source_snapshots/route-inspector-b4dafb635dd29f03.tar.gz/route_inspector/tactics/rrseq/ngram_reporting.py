"""Tables and diagnostic figures for length-matched localization analysis."""

from collections import Counter
from statistics import mean, median

from route_inspector.tactics.rrseq.statistics_io import (
    SUPPORT_BINS,
    quantile,
    support_bin,
    write_tsv,
)

CLASSES = ("localized_only", "mixed", "never_localized")


def write_analysis(
    stage, lengths, families, route_counts, reaction_counts, entry_rules
):
    from route_inspector.tactics.rrseq.ngram_comparison import classify

    identities, supports, by_length, classes = [], [], [], []
    for rules, occurrences in sorted(families.items()):
        localized = [r for r in occurrences if r["rrseq_occurrence_id"]]
        nonlocalized = [r for r in occurrences if not r["rrseq_occurrence_id"]]
        all_routes = {r["route_id"] for r in occurrences}
        local_routes = {r["route_id"] for r in localized}
        other_routes = {r["route_id"] for r in nonlocalized}
        identities.append(
            dict(
                sequence_length=len(rules),
                ordered_rule_identity=rules,
                identity_class=classify(len(occurrences), len(localized)),
                total_adjacent_occurrences=len(occurrences),
                localized_occurrences=len(localized),
                nonlocalized_occurrences=len(nonlocalized),
                total_route_support=len(all_routes),
                localized_route_support=len(local_routes),
                nonlocalized_route_support=len(other_routes),
                localization_fraction=len(localized) / len(occurrences),
                example_localized_route_id=min(local_routes) if local_routes else "",
                example_nonlocalized_route_id=min(other_routes) if other_routes else "",
            )
        )
    for length in lengths:
        rows = [r for r in identities if r["sequence_length"] == length]
        occurrences = [
            r
            for rules, group in families.items()
            if len(rules) == length
            for r in group
        ]
        local = [r for r in occurrences if r["rrseq_occurrence_id"]]
        n_local = sum(r["localized_occurrences"] > 0 for r in rows)
        by_length.append(
            dict(
                sequence_length=length,
                ngram_occurrence_count=len(occurrences),
                rrseq_occurrence_count=len(local),
                occurrence_localization_fraction=len(local) / len(occurrences)
                if occurrences
                else None,
                ngram_unique_family_count=len(rows),
                rrseq_unique_family_count=n_local,
                authoritative_rrseq_entry_count=sum(
                    len(rules) == length for rules in entry_rules.values()
                ),
                family_localization_fraction=n_local / len(rows) if rows else None,
                ngram_distinct_route_count=len({r["route_id"] for r in occurrences}),
                rrseq_distinct_route_count=len({r["route_id"] for r in local}),
            )
        )
        counts = Counter(r["identity_class"] for r in rows)
        classes.append(
            dict(
                sequence_length=length,
                **{
                    f"{name}_{suffix}": counts[name]
                    if suffix == "family_count"
                    else (100 * counts[name] / len(rows) if rows else None)
                    for name in CLASSES
                    for suffix in ("family_count", "percent")
                },
            )
        )
        for cohort, values in (
            (
                "rrseq_cons",
                [
                    r["localized_route_support"]
                    for r in rows
                    if r["localized_occurrences"]
                ],
            ),
            (
                "never_localized",
                [
                    r["total_route_support"]
                    for r in rows
                    if r["identity_class"] == "never_localized"
                ],
            ),
        ):
            bins = Counter(map(support_bin, values))
            supports.append(
                dict(
                    sequence_length=length,
                    cohort=cohort,
                    family_count=len(values),
                    mean_route_support=mean(values) if values else None,
                    median_route_support=median(values) if values else None,
                    **{f"q{q}": quantile(values, q / 100) for q in (25, 75, 90, 95)},
                    maximum_route_support=max(values, default=None),
                    **{f"support_{label}": bins[label] for _, _, label in SUPPORT_BINS},
                )
            )
    route_rows = []
    for route_id, count in reaction_counts.items():
        for length in lengths:
            counts = route_counts[(route_id, length)]
            adjacent, localized = counts["adjacent"], counts["localized"]
            route_rows.append(
                dict(
                    route_id=route_id,
                    reaction_count=count,
                    sequence_length=length,
                    adjacent_ngram_occurrences=adjacent,
                    rrseq_cons_occurrences=localized,
                    route_localization_fraction=localized / adjacent
                    if adjacent
                    else None,
                )
            )
    for filename, rows in (
        ("rrseq_vs_ngram_by_length.tsv", by_length),
        ("ngram_localization_identity_classes.tsv", classes),
        ("ngram_identity_localization.tsv", identities),
        ("localized_vs_nonlocalized_support.tsv", supports),
        ("rrseq_vs_ngram_route_level.tsv", route_rows),
    ):
        write_tsv(stage / filename, rows, list(rows[0]) if rows else [])
    series = [
        {
            k: r[k]
            for k in (
                "sequence_length",
                "occurrence_localization_fraction",
                "family_localization_fraction",
            )
        }
        for r in by_length
    ]
    write_tsv(stage / "localization_by_length.tsv", series, list(series[0]))
    return {
        "by_length": by_length,
        "identity_classes": classes,
        "support_distributions": supports,
        "sequence_lengths": lengths,
        "total_adjacent_occurrences": sum(
            r["ngram_occurrence_count"] for r in by_length
        ),
        "definitions": {
            "sequence_order": "retrosynthetic: target to precursors/building blocks",
            "rule_identity": "existing version 3 independent complete query-side exact isomorphism; conservative exact-representation fallback",
            "localized": "exact occurrence present in authoritative RRSeq_cons library",
            "occurrence": "one exact route and ordered reaction-node segment; shared branches are unioned",
            "family": "ordered tuple of rule-family equivalence classes; labels are analysis-local witnesses, not portable chemical IDs",
            "rrseq_support": "distinct routes containing localized occurrences only",
            "nonlocalized_support": "distinct routes containing nonlocalized occurrences; may overlap localized route set",
            "empty_route_fraction": "null in JSON semantics, empty cell in TSV",
            "quantiles": "linear interpolation at (n-1)*p",
        },
    }


def markdown_report(summary):
    lines = [
        "# Length-matched RRSeq_cons versus adjacent reaction-rule n-grams",
        "",
        f"Status: **{summary['status']}**. Dataset: {summary['dataset_id']}; routes: {summary['route_count']:,}.",
        "",
        "Sequences remain in **retrosynthetic order (target → precursors/building blocks)**. "
        f"Both vocabularies use the same version {summary['identity_version']} complete-query-side transformation-family identity. "
        "Occurrences count exact route/node segments once, with shared branch memberships retained.",
        "",
        "| Length | Adjacent occurrences | RRSeq occurrences | Localized occurrences (%) | Adjacent families | RRSeq families | Localized vocabulary (%) |",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in summary["by_length"]:
        lines.append(
            f"| {r['sequence_length']} | {r['ngram_occurrence_count']:,} | {r['rrseq_occurrence_count']:,} | {100 * r['occurrence_localization_fraction']:.2f} | {r['ngram_unique_family_count']:,} | {r['rrseq_unique_family_count']:,} | {100 * r['family_localization_fraction']:.2f} |"
        )
    lines += [
        "",
        "## Identity classes",
        "",
        "“Localized only” means every observed occurrence is localized; “mixed” means the same rule tuple has "
        "both localized and nonlocalized occurrences; “never localized” means none is localized in this corpus.",
        "",
        "| Length | Localized only | Mixed | Never localized |",
        "|---:|---:|---:|---:|",
    ]
    for r in summary["identity_classes"]:
        lines.append(
            "| "
            + " | ".join(
                [
                    str(r["sequence_length"]),
                    *[
                        f"{r[name + '_family_count']:,} ({r[name + '_percent']:.2f}%)"
                        for name in CLASSES
                    ],
                ]
            )
            + " |"
        )
    lines += [
        "",
        "## Recurrence across routes",
        "",
        "RRSeq support counts routes with localized occurrences; never-localized support counts all supporting routes. "
        "Support is a route union, not an occurrence count. The full table includes quartiles, 90th/95th percentiles, maxima and common bins.",
        "",
        "| Length | RRSeq mean / median support | Never-localized mean / median support | Mean comparison |",
        "|---:|---:|---:|:---|",
    ]
    for length in summary["sequence_lengths"]:
        a, b = [
            r
            for r in summary["support_distributions"]
            if r["sequence_length"] == length
        ]
        av, bv = a["mean_route_support"], b["mean_route_support"]
        comparison = (
            "unavailable"
            if av is None or bv is None
            else ("higher" if av > bv else ("lower" if av < bv else "equal"))
        )

        def fmt(r):
            return (
                "—"
                if r["mean_route_support"] is None
                else f"{r['mean_route_support']:.3f} / {r['median_route_support']:g}"
            )

        lines.append(f"| {length} | {fmt(a)} | {fmt(b)} | {comparison} |")
    first, last = summary["by_length"][0], summary["by_length"][-1]
    lines += [
        "",
        "## Selectivity and validation",
        "",
        f"The observed occurrence fraction changes from {100 * first['occurrence_localization_fraction']:.2f}% at L={first['sequence_length']} "
        f"to {100 * last['occurrence_localization_fraction']:.2f}% at L={last['sequence_length']}; "
        f"the vocabulary fraction changes from {100 * first['family_localization_fraction']:.2f}% to {100 * last['family_localization_fraction']:.2f}%. "
        "The length table gives the full trend; these are corpus statistics, not a fitted decay model.",
        "",
    ]
    v = summary["occurrence_subset_validation"]
    lines.append(
        f"Occurrence subset: {v['rrseq_occurrences_matched_to_ngram']:,}/{v['rrseq_occurrences_total']:,} matched; "
        f"{v['rrseq_occurrences_missing_from_ngram']:,} missing or inconsistent. "
        f"Family subset: {sum(r['rrseq_families_missing_from_ngram'] for r in summary['family_subset_validation'])} missing."
    )
    old = summary["previous_bigram_comparison"]
    lines += [
        "",
        "## Earlier bigram result",
        "",
        f"Earlier catalog: {old['old_unique_family_count']} families, {old['old_occurrence_count']} occurrences. "
        f"Current baseline: {old['new_unique_family_count']} families, {old['new_occurrence_count']} occurrences. "
        + old["interpretation"],
        "",
    ]
    if crosswalk := old.get("provenance_crosswalk"):
        lines += [
            f"Exact-position crosswalk: {crosswalk['matched_occurrences']:,} occurrences matched; "
            f"{crosswalk['old_occurrences_missing_from_current']} old positions missing from the current baseline and "
            f"{crosswalk['current_occurrences_missing_from_old']} current positions absent from the old catalog. "
            f"{crosswalk['current_families_combining_multiple_old_families']} current families combine multiple old entries; "
            f"{crosswalk['old_families_spanning_multiple_current_families']} old families split across current identities. "
            f"The crosswalk accounts for {crosswalk['merge_reductions']} merge reductions and "
            f"{crosswalk['split_increments']} split increments. This is an identity-policy comparison, not a localization effect. "
            "See `old_bigram_identity_crosswalk.tsv` for the full mapping.",
            "",
        ]
    lines += [
        "## Interpretation limits",
        "",
        "Localization identifies adjacent transformations sharing the mapped local reaction-center history defined by RouteInspector. "
        "It does not measure chemical correctness, plausibility, or synthetic preference. Recurrence differences are corpus-level associations. "
        "Higher lengths have fewer observations; the longest observed lengths should be read with their sample counts. "
        f"Conservative identity fallback representatives: {summary['fallback_rule_representatives']}. "
        "No route normalization, rule extraction, RRSeq extraction, family policy, composite construction, or NameRxn annotation was changed.",
        "",
    ]
    return "\n".join(lines)


def plots(stage, summary):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    rows = summary["by_length"]
    x = [r["sequence_length"] for r in rows]

    def save(fig, name):
        fig.tight_layout()
        fig.savefig(stage / f"{name}.png", dpi=170)
        fig.savefig(stage / f"{name}.svg")
        plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    for key, label in [
        ("ngram_unique_family_count", "Adjacent n-grams"),
        ("rrseq_unique_family_count", "RRSeq_cons"),
    ]:
        ax.plot(x, [r[key] for r in rows], marker="o", label=label)
    ax.set(
        xlabel="Sequence length",
        ylabel="Unique families (log scale)",
        yscale="log",
        xticks=x,
    )
    ax.legend()
    save(fig, "figure_a_vocabulary")
    fig, ax = plt.subplots(figsize=(6, 4))
    for key, label in [
        ("family_localization_fraction", "Families"),
        ("occurrence_localization_fraction", "Occurrences"),
    ]:
        ax.plot(x, [100 * r[key] for r in rows], marker="o", label=label)
    ax.set(xlabel="Sequence length", ylabel="Localized (%)", xticks=x, ylim=(0, 100))
    ax.legend()
    save(fig, "figure_b_localization")
    fig, ax = plt.subplots(figsize=(6, 4))
    bottom = [0] * len(x)
    for name in CLASSES:
        values = [r[f"{name}_family_count"] for r in summary["identity_classes"]]
        ax.bar(x, values, bottom=bottom, label=name.replace("_", " "))
        bottom = [a + b for a, b in zip(bottom, values)]
    ax.set(xlabel="Sequence length", ylabel="Unique families", xticks=x)
    ax.legend()
    save(fig, "figure_c_identity_classes")
    fig, axes = plt.subplots(len(x), 1, figsize=(7, 2.5 * len(x)), squeeze=False)
    bins = [label for _, _, label in SUPPORT_BINS]
    for length, (ax,) in zip(x, axes):
        for offset, cohort in [(-0.2, "rrseq_cons"), (0.2, "never_localized")]:
            row = next(
                r
                for r in summary["support_distributions"]
                if r["sequence_length"] == length and r["cohort"] == cohort
            )
            values = [
                100 * row[f"support_{b}"] / row["family_count"]
                if row["family_count"]
                else 0
                for b in bins
            ]
            ax.bar(
                [i + offset for i in range(len(bins))],
                values,
                width=0.4,
                label=f"{cohort} (n={row['family_count']})",
            )
        ax.set(
            xticks=range(len(bins)),
            xticklabels=bins,
            ylabel="Families (%)",
            title=f"L = {length}",
        )
        ax.legend(fontsize=8)
    axes[-1, 0].set_xlabel("Distinct-route support bin")
    save(fig, "figure_d_route_support")
