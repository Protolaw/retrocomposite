"""Consecutive and gapped reaction-rule sequence definitions."""

from route_inspector import __version__
from route_inspector.tactics.rrseq.route_extraction import (
    extract_route_rrseq_cons,
    extract_route_rrseq_gap,
)

__all__ = ["__version__", "extract_route_rrseq_cons", "extract_route_rrseq_gap"]
