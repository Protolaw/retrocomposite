"""Occurrence-provenance crosswalk to the older, differently keyed bigram catalog."""

import csv
import json
from collections import Counter, defaultdict

from route_inspector.tactics.rrseq.statistics_io import write_tsv


def compare_previous_bigrams(library_dir, artifacts, stage, summary):
    descriptor = artifacts.get("retro_bleu_bigram_occurrences")
    if descriptor is None or 2 not in summary["sequence_lengths"]:
        return
    with (stage / "ngram_occurrences.tsv").open() as handle:
        new = {
            (
                r["dataset_id"],
                r["source_identity"],
                r["route_id"],
                tuple(map(tuple, json.loads(r["selected_reaction_node_paths"]))),
            ): tuple(json.loads(r["ordered_rule_identity"]))
            for r in csv.DictReader(handle, delimiter="\t")
            if r["sequence_length"] == "2"
        }
    cross, reverse, seen, unmatched, duplicated = (
        defaultdict(set),
        defaultdict(set),
        set(),
        0,
        0,
    )
    support = Counter()
    with (library_dir / descriptor["path"]).open() as handle:
        for line in handle:
            row = json.loads(line)
            occurrence = row["occurrence"]
            route = occurrence["route"]
            key = (
                route["dataset_id"],
                route["source_identity"],
                route["route_id"],
                tuple(map(tuple, occurrence["occurrence"]["reaction_node_paths"])),
            )
            if key not in new:
                unmatched += 1
                continue
            if key in seen:
                duplicated += 1
            seen.add(key)
            old_id, rules = row["entry_id"], new[key]
            cross[old_id].add(rules)
            reverse[rules].add(old_id)
            support[(old_id, rules)] += 1
    counts = dict(
        matched_occurrences=len(seen),
        old_occurrences_missing_from_current=unmatched,
        current_occurrences_missing_from_old=len(new.keys() - seen),
        duplicate_old_positions=duplicated,
        old_families_spanning_multiple_current_families=sum(
            len(v) > 1 for v in cross.values()
        ),
        current_families_combining_multiple_old_families=sum(
            len(v) > 1 for v in reverse.values()
        ),
        split_increments=sum(len(v) - 1 for v in cross.values()),
        merge_reductions=sum(len(v) - 1 for v in reverse.values()),
        mapped_old_family_count=len(cross),
        mapped_current_family_count=len(reverse),
    )
    summary["previous_bigram_comparison"]["provenance_crosswalk"] = counts
    rows = [
        dict(
            old_entry_id=old_id,
            ordered_rule_identity=rules,
            occurrence_count=count,
            current_families_for_old_entry=len(cross[old_id]),
            old_entries_for_current_family=len(reverse[rules]),
        )
        for (old_id, rules), count in sorted(support.items())
    ]
    write_tsv(
        stage / "old_bigram_identity_crosswalk.tsv",
        rows,
        [
            "old_entry_id",
            "ordered_rule_identity",
            "occurrence_count",
            "current_families_for_old_entry",
            "old_entries_for_current_family",
        ],
    )
