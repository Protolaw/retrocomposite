"""RRSeq artifact paths, columns, and serialization."""

from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

from route_inspector.infrastructure.artifacts import reference_sort_key, write_json
from route_inspector.infrastructure.text import write_tsv
from route_inspector.tactics.rrseq.naming import (
    RRSEQ_AGGREGATE_TSV_SCHEMA_VERSION,
    RRSEQ_CONS_KIND,
    RRSEQ_GAP_KIND,
    normalize_rrseq_kind,
    rrseq_column_for_kind,
)


def write_rrseqs(
    output: Path,
    references_by_sequence: dict[tuple[str, ...], set[Any]],
    target_molecules_by_sequence: (
        dict[tuple[str, ...], dict[Any, set[str]]] | None
    ) = None,
    evidence_by_sequence: (dict[tuple[str, ...], dict[str, Any]] | None) = None,
    *,
    sequence_kind: str = RRSEQ_CONS_KIND,
    separated: bool | None = None,
    include_single_rules: bool = True,
) -> dict[str, Any]:
    """Write RRseq_cons or RRseq_gap aggregates to disk.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    if separated is not None:
        sequence_kind = RRSEQ_GAP_KIND if separated else RRSEQ_CONS_KIND
    sequence_kind = normalize_rrseq_kind(sequence_kind)
    sequence_column = rrseq_column_for_kind(sequence_kind)
    output.parent.mkdir(parents=True, exist_ok=True)
    output_prefix = output.with_suffix("")
    output_suffix = output.suffix or ".tsv"
    output_paths: dict[int, Path] = {}
    counts_by_size: dict[int, int] = {}

    sequences_by_size: dict[int, list[tuple[tuple[str, ...], set[Any]]]] = defaultdict(
        list
    )
    for sequence, references in references_by_sequence.items():
        sequences_by_size[len(sequence)].append((sequence, references))

    for size in sorted(sequences_by_size):
        rows = sorted(
            sequences_by_size[size],
            key=lambda item: (
                -len(item[1]),
                "$".join(item[0]),
                getattr(item[0], "widths", ()),
            ),
        )
        if size == 1:
            if not include_single_rules:
                continue
            size_output = output_prefix.with_name(
                f"{output_prefix.name}_t1_single_rules"
            ).with_suffix(output_suffix)
            header = ["Rule", "popularity", "Reference", "Target_molecules"]
        else:
            size_output = output_prefix.with_name(
                f"{output_prefix.name}_t{size}_rrseq_{sequence_kind}"
            ).with_suffix(output_suffix)
            header = [
                sequence_column,
                "output_reactants_num",
                "popularity",
                "Reference",
                "Target_molecules",
            ]
        has_widths = (
            sequence_kind == RRSEQ_GAP_KIND
            and size > 1
            and any(hasattr(sequence, "widths") for sequence, _ in rows)
        )
        if has_widths:
            header.append("inter_selection_gap_widths")
        if evidence_by_sequence is not None:
            header.extend(
                [
                    "base_query_cgr_identities_json",
                    "base_identity_count",
                    "local_context_query_cgr_identity",
                    "associated_base_occurrence_count",
                    "associated_base_route_count",
                    "associated_base_source_document_count",
                    "local_occurrence_count",
                    "local_route_count",
                    "local_source_document_count",
                ]
            )
        output_paths[size] = size_output
        counts_by_size[size] = len(rows)
        with size_output.open("w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file, delimiter="\t", lineterminator="\n")
            writer.writerow(header)
            for sequence, references in rows:
                sorted_references = sorted(references, key=reference_sort_key)
                target_molecules: list[str] = []
                seen_target_molecules: set[str] = set()
                if target_molecules_by_sequence:
                    route_targets = target_molecules_by_sequence.get(sequence, {})
                    for route_id in sorted_references:
                        for target_smiles in sorted(route_targets.get(route_id, set())):
                            if (
                                target_smiles
                                and target_smiles not in seen_target_molecules
                            ):
                                seen_target_molecules.add(target_smiles)
                                target_molecules.append(target_smiles)
                if size == 1:
                    row = [
                        sequence[0],
                        len(references),
                        ",".join(map(str, sorted_references)),
                        ",".join(target_molecules),
                    ]
                else:
                    row = [
                        "$".join(sequence),
                        rrseq_output_reactants_num(sequence),
                        len(references),
                        ",".join(map(str, sorted_references)),
                        ",".join(target_molecules),
                    ]
                if has_widths:
                    row.append(json.dumps(sequence.widths, separators=(",", ":")))
                if evidence_by_sequence is not None:
                    try:
                        evidence = evidence_by_sequence[sequence]
                    except KeyError as error:
                        raise ValueError(
                            "missing identity evidence for output sequence "
                            f"{'$'.join(sequence)}"
                        ) from error
                    row.extend(
                        [
                            evidence["base_query_cgr_identities_json"],
                            evidence["base_identity_count"],
                            evidence["local_context_query_cgr_identity"],
                            evidence["associated_base_occurrence_count"],
                            evidence["associated_base_route_count"],
                            evidence["associated_base_source_document_count"],
                            evidence["local_occurrence_count"],
                            evidence["local_route_count"],
                            evidence["local_source_document_count"],
                        ]
                    )
                writer.writerow(row)

    summary = {
        "rrseq_aggregate_tsv_schema_version": 2
        if any(hasattr(sequence, "widths") for sequence in references_by_sequence)
        else RRSEQ_AGGREGATE_TSV_SCHEMA_VERSION,
        "rrseq_gap_width_in_identity": sequence_kind == RRSEQ_GAP_KIND
        and any(hasattr(sequence, "widths") for sequence in references_by_sequence),
        "output_files": {str(size): str(path) for size, path in output_paths.items()},
        "unique_single_rules": counts_by_size.get(1, 0),
        f"unique_rrseq_{sequence_kind}_by_size": {
            str(size): counts_by_size[size]
            for size in sorted(counts_by_size)
            if size > 1
        },
    }
    if sequence_kind != RRSEQ_GAP_KIND:
        summary["unique_rules_by_size"] = {
            str(size): counts_by_size[size] for size in sorted(counts_by_size)
        }
    return summary


def rrseq_summary_path_from_output(
    output: Path,
    *,
    sequence_kind: str = RRSEQ_CONS_KIND,
    separated: bool | None = None,
) -> Path:
    """Build the rrseq summary path from an output prefix.

    The returned path follows the project naming conventions so downstream commands can
    discover related summaries and error files automatically.
    """
    if separated is not None:
        sequence_kind = RRSEQ_GAP_KIND if separated else RRSEQ_CONS_KIND
    sequence_kind = normalize_rrseq_kind(sequence_kind)
    output.parent.mkdir(parents=True, exist_ok=True)
    return output.with_suffix("").parent / "summary.json"


def rrseq_routes_without_rules_path_from_output(
    output: Path,
    *,
    sequence_kind: str = RRSEQ_CONS_KIND,
) -> Path:
    """Build the rrseq routes without rules path from an output prefix.

    The returned path follows the project naming conventions so downstream commands can
    discover related summaries and error files automatically.
    """
    output.parent.mkdir(parents=True, exist_ok=True)
    prefix = output.with_suffix("")
    sequence_kind = normalize_rrseq_kind(sequence_kind)
    base_name = re.sub(
        r"(?:_t\d+)?_(?:rrseq_(?:cons|gap)|rrseqs|separated_rrseqs)$",
        "",
        prefix.name,
    )
    return prefix.with_name(f"{base_name}_routes_without_rrseq_{sequence_kind}.json")


def write_rrseq_summary(
    output: Path,
    summary: dict[str, Any],
    *,
    sequence_kind: str = RRSEQ_CONS_KIND,
    separated: bool | None = None,
) -> Path:
    """Write rrseq summary to disk.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    path = rrseq_summary_path_from_output(
        output,
        sequence_kind=sequence_kind,
        separated=separated,
    )
    write_json(path, summary)
    return path


def write_rrseq_routes_without_rules(
    output: Path,
    routes: dict[Any, dict[str, Any]],
    path: Path | None = None,
    *,
    sequence_kind: str = RRSEQ_CONS_KIND,
) -> Path:
    """Write rrseq routes without rules to disk.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    no_rules_path = path or rrseq_routes_without_rules_path_from_output(
        output,
        sequence_kind=sequence_kind,
    )
    write_json(
        no_rules_path,
        {str(route_id): route for route_id, route in routes.items()},
    )
    return no_rules_path


def write_rrseq_errors(output: Path, errors: list[dict[str, Any]]) -> None:
    """Write rrseq errors to disk.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    if not errors:
        return
    path = output.with_suffix(output.suffix + ".errors.tsv")
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["route_id", "stage", "error_type", "message"]
    write_tsv(path, fieldnames, errors)


def reaction_output_reactants_num(rule_smarts: str) -> int:
    """Return reaction output reactants num from a reaction or route node.

    The returned path follows the project naming conventions so downstream commands can
    discover related summaries and error files automatically.
    """

    _left, separator, right = rule_smarts.partition(">>")
    if not separator:
        return 0
    return len([part for part in right.split(".") if part.strip()])


def rrseq_output_reactants_num(sequence: Iterable[str]) -> int:
    """Count output reactants for the last rule in a rrseq sequence.

    The returned path follows the project naming conventions so downstream commands can
    discover related summaries and error files automatically.
    """

    total = 1
    seen_any = False
    for rule_smarts in sequence:
        seen_any = True
        total += max(reaction_output_reactants_num(rule_smarts), 1) - 1
    return total if seen_any else 0
