"""QueryCGR identities and evidence aggregation for RRSeq artifacts."""

from __future__ import annotations

import json
from collections import defaultdict
from typing import Any, Iterable, Mapping

from route_inspector.rules.identity import rule_querycgr_identity


def rrseq_sequence_identity(sequence: tuple[str, ...]) -> tuple[Any, ...]:
    """Return the ordered native QueryCGR-key tuple for legacy SMARTS input."""
    return tuple(rule_querycgr_identity(rule) for rule in sequence)


def rrseq_sequences_are_isomorphic(
    left: tuple[str, ...],
    right: tuple[str, ...],
) -> bool:
    """Compare ordered RRSeq elements through native QueryCGR keys."""
    return rrseq_sequence_identity(left) == rrseq_sequence_identity(right)


def merge_rrseq_sequences_by_querycgr(
    references_by_sequence: dict[tuple[str, ...], set[Any]],
    target_molecules_by_sequence: dict[tuple[str, ...], dict[Any, set[str]]],
    query_cgr_keys_by_sequence: dict[tuple[str, ...], tuple[str, ...]] | None = None,
) -> tuple[
    dict[tuple[str, ...], set[Any]],
    dict[tuple[str, ...], dict[Any, set[str]]],
]:
    """Aggregate exact SMARTS rows by ordered native QueryCGR identities.

    Every sequence length is an independent namespace: a t2 sequence is compared
    only with other t2 sequences, a t3 only with t3, and so on. Production callers
    supply keys captured from the extracted rule objects. Parser-derived keys are a
    compatibility fallback for historical in-memory callers only.
    """
    representatives_by_identity: dict[tuple[int, tuple[str, ...]], tuple[str, ...]] = {}
    references_out: dict[tuple[str, ...], set[Any]] = defaultdict(set)
    targets_out: dict[tuple[str, ...], dict[Any, set[str]]] = defaultdict(
        lambda: defaultdict(set)
    )

    ordered_sequences = sorted(
        references_by_sequence,
        key=lambda item: (
            len(item),
            (
                query_cgr_keys_by_sequence[item]
                if query_cgr_keys_by_sequence is not None
                else rrseq_sequence_identity(item)
            ),
            "$".join(item),
        ),
    )
    for sequence in ordered_sequences:
        identity = (
            query_cgr_keys_by_sequence[sequence]
            if query_cgr_keys_by_sequence is not None
            else rrseq_sequence_identity(sequence)
        )
        if len(identity) != len(sequence):
            raise ValueError("QueryCGR identity length does not match RRSeq length")
        bucket = (len(sequence), identity)
        representative = representatives_by_identity.setdefault(bucket, sequence)
        references_out[representative].update(references_by_sequence[sequence])
        for route_id, target_molecules in target_molecules_by_sequence.get(
            sequence,
            {},
        ).items():
            targets_out[representative][route_id].update(target_molecules)

    return references_out, targets_out


def merge_single_rules_by_querycgr(
    references_by_rule: dict[tuple[str, ...], set[Any]],
    target_molecules_by_rule: dict[tuple[str, ...], dict[Any, set[str]]],
    query_cgr_keys_by_rule: dict[tuple[str, ...], tuple[str, ...]] | None = None,
) -> tuple[
    dict[tuple[str, ...], set[Any]],
    dict[tuple[str, ...], dict[Any, set[str]]],
]:
    """Aggregate t1 rules independently from all multi-step RRSeq tables."""
    if any(len(rule) != 1 for rule in references_by_rule):
        raise ValueError("single-rule aggregation accepts only t1 entries")
    return merge_rrseq_sequences_by_querycgr(
        references_by_rule,
        target_molecules_by_rule,
        query_cgr_keys_by_rule,
    )


def raw_identity_evidence_by_representative(
    references_by_sequence: dict[tuple[str, ...], set[Any]],
    query_cgr_keys_by_sequence: dict[tuple[str, ...], tuple[str, ...]],
    base_query_cgr_keys_by_sequence: dict[tuple[str, ...], tuple[str, ...]],
    occurrences: Iterable[Mapping[str, Any]],
) -> dict[tuple[str, ...], dict[str, Any]]:
    """Build paired base/local support for local-identity representatives.

    Local and base QueryCGR identities form a many-to-many relation. A local
    graph does not encode which atoms belonged to its no-functional-group mask,
    so environment truncation or symmetry can associate one canonical local
    identity with several valid base identities. Exact occurrence sidecars keep
    each pair; compact rows report deterministic associated-base lists and
    duplicate-safe support unions.
    """

    def occurrence_identity(
        occurrence: Mapping[str, Any],
        *,
        plural_key: str,
        singular_keys: tuple[str, ...],
    ) -> tuple[str, ...]:
        keys = tuple(str(key) for key in occurrence.get(plural_key, ()) if key)
        if keys:
            return keys
        for key in singular_keys:
            value = str(occurrence.get(key) or "")
            if value:
                return (value,)
        return ()

    def source_documents(occurrence: Mapping[str, Any]) -> set[str]:
        documents = {str(occurrence.get("source_document_id") or "")}
        for collection in ("source_matches", "selected_steps", "skipped_steps"):
            for step in occurrence.get(collection, ()) or ():
                documents.add(str(step.get("source_document_id") or ""))
        documents.discard("")
        return documents

    representatives: dict[tuple[int, tuple[str, ...]], tuple[str, ...]] = {}
    bases_by_local: dict[
        tuple[str, ...],
        set[tuple[str, ...]],
    ] = defaultdict(set)
    local_routes: dict[tuple[str, ...], set[str]] = defaultdict(set)
    base_routes: dict[tuple[str, ...], set[str]] = defaultdict(set)
    for sequence in sorted(
        references_by_sequence,
        key=lambda item: (
            len(item),
            query_cgr_keys_by_sequence.get(item, ()),
            "$".join(item),
        ),
    ):
        local_identity = query_cgr_keys_by_sequence.get(sequence, ())
        base_identity = base_query_cgr_keys_by_sequence.get(sequence, ())
        if (
            len(local_identity) != len(sequence)
            or len(base_identity) != len(sequence)
            or any(not key for key in (*local_identity, *base_identity))
        ):
            raise ValueError(
                "every sequence requires complete local and base QueryCGR identities"
            )
        bases_by_local[local_identity].add(base_identity)
        bucket = (len(sequence), local_identity)
        representatives.setdefault(bucket, sequence)
        route_ids = {str(reference) for reference in references_by_sequence[sequence]}
        local_routes[local_identity].update(route_ids)
        base_routes[base_identity].update(route_ids)

    local_occurrences: dict[tuple[str, ...], set[str]] = defaultdict(set)
    base_occurrences: dict[tuple[str, ...], set[str]] = defaultdict(set)
    local_documents: dict[tuple[str, ...], set[str]] = defaultdict(set)
    base_documents: dict[tuple[str, ...], set[str]] = defaultdict(set)
    for index, occurrence in enumerate(occurrences):
        local_identity = occurrence_identity(
            occurrence,
            plural_key="query_cgr_keys",
            singular_keys=("query_cgr_key", "local_context_query_cgr_key"),
        )
        if not local_identity:
            raise ValueError("occurrence is missing its local QueryCGR identity")
        associated_bases = bases_by_local.get(local_identity)
        if associated_bases is None:
            raise ValueError("occurrence local QueryCGR identity is not represented")
        base_identity = occurrence_identity(
            occurrence,
            plural_key="base_query_cgr_keys",
            singular_keys=("base_query_cgr_key",),
        )
        if not base_identity:
            raise ValueError("occurrence is missing its base QueryCGR identity")
        if len(base_identity) != len(local_identity):
            raise ValueError(
                "occurrence local and base QueryCGR identity lengths differ"
            )
        if base_identity not in associated_bases:
            raise ValueError(
                "occurrence base QueryCGR identity is not associated with "
                "its local identity"
            )
        occurrence_token = str(occurrence.get("occurrence_id") or f"anonymous:{index}")
        local_occurrences[local_identity].add(occurrence_token)
        base_occurrences[base_identity].add(occurrence_token)
        documents = source_documents(occurrence)
        local_documents[local_identity].update(documents)
        base_documents[base_identity].update(documents)

    evidence: dict[tuple[str, ...], dict[str, Any]] = {}
    for (_size, local_identity), representative in representatives.items():
        associated_bases = tuple(sorted(bases_by_local[local_identity]))
        associated_occurrences: set[str] = set()
        associated_routes: set[str] = set()
        associated_documents: set[str] = set()
        for base_identity in associated_bases:
            associated_occurrences.update(base_occurrences[base_identity])
            associated_routes.update(base_routes[base_identity])
            associated_documents.update(base_documents[base_identity])
        evidence[representative] = {
            "base_query_cgr_identities_json": json.dumps(
                [list(identity) for identity in associated_bases],
                ensure_ascii=False,
                separators=(",", ":"),
            ),
            "base_identity_count": len(associated_bases),
            "local_context_query_cgr_identity": "$".join(local_identity),
            "associated_base_occurrence_count": len(associated_occurrences),
            "associated_base_route_count": len(associated_routes),
            "associated_base_source_document_count": len(associated_documents),
            "local_occurrence_count": len(local_occurrences[local_identity]),
            "local_route_count": len(local_routes[local_identity]),
            "local_source_document_count": len(local_documents[local_identity]),
        }
    return evidence


__all__ = [
    "merge_rrseq_sequences_by_querycgr",
    "merge_single_rules_by_querycgr",
    "raw_identity_evidence_by_representative",
    "rrseq_sequence_identity",
    "rrseq_sequences_are_isomorphic",
]
