"""Construction of exact, occurrence-provenanced RRSeq payloads."""

from __future__ import annotations

from typing import Any

from route_inspector import chemistry
from route_inspector.rules.models import ReactionPathStep
from route_inspector.tactics.rrseq.occurrences import (
    RRseqConsOccurrence,
    RRseqConsSourceLeaf,
    RRseqConsSourceMatch,
    stable_rrseq_cons_occurrence_id,
)


def rrseq_cons_occurrence(
    path: list[ReactionPathStep],
    *,
    start_position: int,
    end_position: int,
    source_identity: str,
    route_id: Any,
    route_target: str,
    root_index: int,
    branch_index: int,
    dataset_id: str = "",
) -> RRseqConsOccurrence:
    """Build one exact RRseq_cons occurrence and its source boundary leaves."""

    selected = path[start_position:end_position]
    matches: list[RRseqConsSourceMatch] = []
    leaves: list[RRseqConsSourceLeaf] = []
    for step_index, item in enumerate(selected):
        path_position = start_position + step_index
        final_step = step_index == len(selected) - 1
        continuation_index = None if final_step else item.continuation_reactant_index
        continuation_path = None if final_step else item.continuation_molecule_path
        continuation_mapping = (
            () if final_step else item.continuation_to_next_target_atom_map
        )
        if not final_step and continuation_index is None:
            raise ValueError(
                "RRseq_cons occurrence has no exact continuation witness "
                f"at path {item.reaction_node_path}"
            )
        matches.append(
            RRseqConsSourceMatch(
                step_index=step_index,
                path_position=path_position,
                reaction_node_path=item.reaction_node_path,
                target_molecule_path=item.target_molecule_path,
                rule_smarts=item.step.rule_smarts,
                reaction_smiles=item.step.reaction_smiles,
                target_smiles=item.step.target_smiles,
                product_index=item.product_index,
                center_atom_maps=tuple(sorted(item.step.center_atoms)),
                query_cgr_key=item.step.query_cgr_key,
                base_query_cgr_key=item.step.base_query_cgr_key,
                base_rule_atom_maps=tuple(sorted(item.step.base_rule_atom_maps)),
                raw_source_record_id=item.raw_source_record_id,
                source_record_id=item.source_record_id,
                source_document_id=item.source_document_id,
                source_id_adapter=item.source_id_adapter,
                product_to_target_atom_map=item.product_to_target_atom_map,
                continuation_reactant_index=continuation_index,
                continuation_molecule_path=continuation_path,
                continuation_to_next_target_atom_map=continuation_mapping,
            )
        )

        reaction = chemistry.parse_reaction(item.step.reaction_smiles)
        if len(item.reactant_molecule_paths) != len(reaction.reactants) or any(
            path is None for path in item.reactant_molecule_paths
        ):
            raise ValueError(
                "RRseq_cons source-leaf bijection invariant failed before "
                f"leaf capture at path {item.reaction_node_path}"
            )
        for reactant_index, reactant in enumerate(reaction.reactants):
            if continuation_index is not None and reactant_index == continuation_index:
                continue
            molecule_path = (
                item.reactant_molecule_paths[reactant_index]
                if reactant_index < len(item.reactant_molecule_paths)
                else None
            )
            leaves.append(
                RRseqConsSourceLeaf(
                    mapped_smiles=format(reactant, "m"),
                    step_index=step_index,
                    path_position=path_position,
                    reactant_index=reactant_index,
                    molecule_node_path=molecule_path,
                )
            )

    reaction_node_paths = tuple(item.reaction_node_path for item in selected)
    route_id_text = str(route_id)
    return RRseqConsOccurrence(
        occurrence_id=stable_rrseq_cons_occurrence_id(
            source_identity=source_identity,
            route_id=route_id_text,
            reaction_node_paths=reaction_node_paths,
            start_position=start_position,
            end_position=end_position,
        ),
        dataset_id=dataset_id,
        source_identity=source_identity,
        route_id=route_id_text,
        route_target_smiles=route_target,
        segment_target_smiles=selected[0].step.target_smiles,
        root_index=root_index,
        branch_index=branch_index,
        branch_indices=(branch_index,),
        reaction_node_paths=reaction_node_paths,
        start_position=start_position,
        end_position=end_position,
        raw_sequence=tuple(item.step.rule_smarts for item in selected),
        query_cgr_keys=tuple(item.step.query_cgr_key for item in selected),
        base_query_cgr_keys=tuple(item.step.base_query_cgr_key for item in selected),
        source_matches=tuple(matches),
        source_route_leaves=tuple(leaves),
    )


__all__ = ["rrseq_cons_occurrence"]
