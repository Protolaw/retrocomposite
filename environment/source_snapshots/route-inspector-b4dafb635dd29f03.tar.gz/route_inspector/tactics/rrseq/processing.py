"""Corpus-level streaming, multiprocessing, aggregation, and output orchestration."""

from __future__ import annotations

import copy
from typing import Any

from route_inspector.datasets.paroutes.source_ids import PAROUTES_SOURCE_ID_ADAPTER
from route_inspector.rules.extraction import (
    SynPlannerRuleExtractor,
)
from route_inspector.rules.models import (
    RouteProcessingStats,
)
from route_inspector.rules.preparation import (
    route_target_smiles,
)
from route_inspector.tactics.rrseq.naming import (
    RRSEQ_CONS_KIND,
    RRSEQ_GAP_KIND,
    normalize_rrseq_kind,
)
from route_inspector.tactics.rrseq.route_extraction import (
    extract_route_rule_sequences,
    no_rrseq_reason,
)


def process_route_for_rrseqs(
    route_id: Any,
    route: dict[str, Any],
    rule_extractor: SynPlannerRuleExtractor,
    *,
    min_length: int,
    max_length: int | None,
    store_route_without_rrseqs: bool = True,
    sequence_mode: str = RRSEQ_CONS_KIND,
    source_identity: str = "",
    dataset_id: str = "",
    source_id_adapter: str = PAROUTES_SOURCE_ID_ADAPTER,
) -> dict[str, Any]:
    """Process route for rrseqs and return serializable results.

    The result preserves reaction order and the shared-center constraint used to decide
    whether adjacent route steps form a valid rrseq rule.
    """
    sequence_mode = normalize_rrseq_kind(sequence_mode)
    stats = RouteProcessingStats(routes_seen=1)
    route_sequence_query_cgr_keys: dict[tuple[str, ...], tuple[str, ...]] = {}
    route_sequence_base_query_cgr_keys: dict[tuple[str, ...], tuple[str, ...]] = {}
    single_rule_query_cgr_keys: dict[tuple[str, ...], tuple[str, ...]] = {}
    single_rule_base_query_cgr_keys: dict[tuple[str, ...], tuple[str, ...]] = {}
    single_rule_occurrences: list[dict[str, Any]] = []
    route_sequences, single_rules, occurrences = extract_route_rule_sequences(
        route,
        rule_extractor,
        min_length=min_length,
        max_length=max_length,
        stats=stats,
        sequence_mode=sequence_mode,
        route_id=route_id,
        source_identity=source_identity,
        dataset_id=dataset_id,
        source_id_adapter=source_id_adapter,
        sequence_query_cgr_keys=route_sequence_query_cgr_keys,
        sequence_base_query_cgr_keys=route_sequence_base_query_cgr_keys,
        single_rule_query_cgr_keys=single_rule_query_cgr_keys,
        single_rule_base_query_cgr_keys=single_rule_base_query_cgr_keys,
        single_rule_occurrences=single_rule_occurrences,
    )
    route_without_rrseqs = None
    reason = ""
    if route_sequences:
        stats.routes_with_rrseqs = 1
    else:
        extracted_reaction_rules = stats.reactions_seen - stats.skipped_reactions
        reason = no_rrseq_reason(
            reactions_seen=stats.reactions_seen,
            extracted_reaction_rules=extracted_reaction_rules,
            skipped_reactions=stats.skipped_reactions,
            min_length=min_length,
            no_net_selected_change=stats.no_net_selected_change,
        )
        if store_route_without_rrseqs:
            route_without_rrseqs = copy.deepcopy(route)
            metadata = route_without_rrseqs.setdefault("metadata", {})
            metadata[f"rrseq_{sequence_mode}_extraction"] = {
                "route_id": route_id,
                "target_smiles": route_target_smiles(route),
                "reactions_seen": stats.reactions_seen,
                "extracted_reaction_rules": extracted_reaction_rules,
                "skipped_reactions": stats.skipped_reactions,
                **(
                    {"no_net_selected_change": stats.no_net_selected_change}
                    if sequence_mode == RRSEQ_GAP_KIND
                    else {}
                ),
                "reason": reason,
            }
    return {
        "route_id": route_id,
        "route_sequences": route_sequences,
        "route_sequence_query_cgr_keys": route_sequence_query_cgr_keys,
        "route_sequence_base_query_cgr_keys": (route_sequence_base_query_cgr_keys),
        "single_rules": single_rules,
        "single_rule_query_cgr_keys": single_rule_query_cgr_keys,
        "single_rule_base_query_cgr_keys": single_rule_base_query_cgr_keys,
        "single_rule_occurrences": single_rule_occurrences,
        "rrseq_cons_occurrences": (
            occurrences if sequence_mode == RRSEQ_CONS_KIND else []
        ),
        "rrseq_gap_occurrences": [
            {
                **occurrence,
                "route_id": str(route_id),
                "source_identity": source_identity,
            }
            for occurrence in (occurrences if sequence_mode == RRSEQ_GAP_KIND else [])
        ],
        "route_without_rrseqs": route_without_rrseqs,
        "no_rrseq_reason": reason,
        "stats": stats,
        "error": None,
    }


def merge_route_processing_stats(
    target: RouteProcessingStats,
    source: RouteProcessingStats,
) -> None:
    """Merge route processing stats into aggregate results.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    target.routes_seen += source.routes_seen
    target.routes_with_rrseqs += source.routes_with_rrseqs
    target.reactions_seen += source.reactions_seen
    target.reaction_rule_cache_hits += source.reaction_rule_cache_hits
    target.reaction_rule_cache_misses += source.reaction_rule_cache_misses
    target.skipped_reactions += source.skipped_reactions
    target.no_net_selected_change += source.no_net_selected_change
    target.errors += source.errors


def merge_query_cgr_key_records(
    destination: dict[tuple[str, ...], tuple[str, ...]],
    source: dict[tuple[str, ...], tuple[str, ...]],
) -> None:
    """Merge exact-SMARTS-to-native-key records without deduplicating rows."""
    for sequence, identity in source.items():
        previous = destination.setdefault(sequence, identity)
        if previous != identity:
            raise ValueError("one SMARTS sequence produced conflicting QueryCGR keys")
