from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable

from route_inspector.infrastructure.artifacts import (
    dataset_prefix_from_path,
    read_rule_from_tsv,
    split_cell,
)
from route_inspector.infrastructure.paths import (
    resolve_existing_path,
)
from route_inspector.tactics.rrseq.naming import (
    RRSEQ_CONS_COLUMN,
    RRSEQ_CONS_KIND,
    find_rrseq_column,
)


@dataclass(frozen=True)
class RRseqApplication:
    source_tsv: Path
    row_index: int
    rrseq: str
    rrseq_size: int
    route_ids: tuple[str, ...]
    target_smiles: str
    occurrence_id: str | None = None
    route_id: str | None = None
    route_target_smiles: str | None = None
    root_index: int | None = None
    branch_index: int | None = None
    branch_indices: tuple[int, ...] = ()
    reaction_node_paths: tuple[tuple[int, ...], ...] = ()
    start_position: int | None = None
    end_position: int | None = None
    source_matches: tuple[dict[str, Any], ...] = ()
    source_route_leaves: tuple[str, ...] = ()
    provenance_quality: str = "legacy_flattened"
    source_occurrence_path: Path | None = None
    source_identity: str | None = None
    occurrence_schema_version: int | None = None

    @property
    def rrseq_cons(self) -> str:
        """Canonical name for this executable consecutive sequence."""

        return self.rrseq

    @property
    def rrseq_cons_size(self) -> int:
        """Number of rules in :attr:`rrseq_cons`."""

        return self.rrseq_size


def is_gapped_rrseq_artifact(path: Path) -> bool:
    """Return whether a TSV is a non-executable RRseq_gap artifact."""

    return path.name.endswith(("_rrseq_gap.tsv", "_separated_rrseqs.tsv"))


def reject_gapped_rrseq_artifact(path: Path) -> None:
    """Reject analysis-only RRseq_gap artifacts in executable workflows."""

    if is_gapped_rrseq_artifact(path):
        raise ValueError(
            f"{path} contains analysis-only RRseq_gap values and cannot be used here"
        )


def read_rrseq_from_tsv(path: Path, row_index: int) -> str:
    """Read a selected executable RRseq_cons string from a TSV row.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    reject_gapped_rrseq_artifact(path)
    return read_rule_from_tsv(
        path,
        row_index,
        columns=(RRSEQ_CONS_COLUMN, "RRseq"),
    )


def iter_rrseq_applications(
    tsv_paths: Iterable[Path],
) -> Iterable[RRseqApplication]:
    """Yield RRseq_cons applications from one or more TSV files.

    Keeping this helper in the IO layer avoids duplicating low-level file and table
    behavior in the chemistry-focused modules.
    """
    from route_inspector.tactics.rrseq.unwrap import split_rrseq

    for tsv_path in tsv_paths:
        with tsv_path.open(encoding="utf-8") as file:
            reader = csv.DictReader(file, delimiter="\t")
            fieldnames = reader.fieldnames or []
            sequence_column = find_rrseq_column(fieldnames, kind=RRSEQ_CONS_KIND)
            if sequence_column is None:
                raise ValueError(f"{tsv_path} has no {RRSEQ_CONS_COLUMN} column")
            if "Target_molecules" not in fieldnames:
                raise ValueError(f"{tsv_path} has no Target_molecules column")

            for row_index, row in enumerate(reader):
                rrseq = row[sequence_column].strip()
                if not rrseq:
                    continue
                route_ids = tuple(split_cell(row.get("Reference")))
                targets = split_cell(row.get("Target_molecules"))
                rrseq_size = len(split_rrseq(rrseq))
                for target_smiles in targets:
                    yield RRseqApplication(
                        source_tsv=tsv_path,
                        row_index=row_index,
                        rrseq=rrseq,
                        rrseq_size=rrseq_size,
                        route_ids=route_ids,
                        target_smiles=target_smiles,
                    )


def expand_rrseq_occurrence_paths(paths: Iterable[Path]) -> list[Path]:
    """Resolve explicit RRseq_cons occurrence sidecars, accepting directories."""

    expanded: list[Path] = []
    seen: set[Path] = set()
    for raw_path in paths:
        path = resolve_existing_path(raw_path)
        candidates = [path]
        if path.is_dir():
            candidates = sorted(path.glob("*_rrseq_cons_occurrences.json"))
            if not candidates:
                candidates = sorted(path.glob("*_rrseq_cons_occurrences.jsonl*"))
            if not candidates:
                candidates = sorted(path.glob("*_rrseq_occurrences.json"))
            if not candidates:
                candidates = sorted(path.glob("*_rrseq_occurrences.jsonl*"))
        for candidate in candidates:
            key = candidate.resolve() if candidate.exists() else candidate
            if key not in seen:
                seen.add(key)
                expanded.append(candidate)
    return expanded


def discover_rrseq_occurrence_paths(
    tsv_paths: Iterable[Path],
) -> list[Path]:
    """Discover authoritative RRseq_cons occurrence sidecars for input TSVs."""

    discovered: list[Path] = []
    seen: set[Path] = set()
    for tsv_path in tsv_paths:
        stem = re.sub(r"_t\d+_(?:rrseq_cons|rrseqs)$", "", tsv_path.stem)
        candidates = (
            tsv_path.with_name(f"{stem}_rrseq_cons_occurrences.json"),
            tsv_path.with_name(f"{stem}_rrseq_cons_occurrences.jsonl.gz"),
            tsv_path.with_name(f"{stem}_rrseq_cons_occurrences.jsonl"),
            tsv_path.with_name(f"{stem}_rrseq_occurrences.json"),
            tsv_path.with_name(f"{stem}_rrseq_occurrences.jsonl.gz"),
            tsv_path.with_name(f"{stem}_rrseq_occurrences.jsonl"),
        )
        for candidate in candidates:
            if not candidate.exists():
                continue
            key = candidate.resolve()
            if key not in seen:
                seen.add(key)
                discovered.append(candidate)
            break
    return discovered


@lru_cache(maxsize=32768)
def _rrseq_structural_identity(rrseq: str) -> tuple[Any, ...]:
    """Return the ordered native QueryCGR identity used during aggregation."""

    from route_inspector.tactics.rrseq.identities import rrseq_sequence_identity
    from route_inspector.tactics.rrseq.unwrap import split_rrseq

    sequence = tuple(split_rrseq(rrseq))
    return ("query_cgr", len(sequence), rrseq_sequence_identity(sequence))


def _rrseq_artifact_corpus_key(path: Path) -> tuple[Path, str]:
    """Identify one generated corpus without adding its path to TSV rows."""

    return (path.parent.resolve(), dataset_prefix_from_path(path))


def _rrseq_cons_legacy_application_contract(occurrence: Any) -> dict[str, Any]:
    """Return the schema-v1/v2 fields that determine exact composite replay."""

    source_matches = []
    for match in occurrence.source_matches:
        source_matches.append(
            {
                "step_index": match.step_index,
                "path_position": match.path_position,
                "reaction_node_path": list(match.reaction_node_path),
                "target_molecule_path": list(match.target_molecule_path),
                "rule_smarts": match.rule_smarts,
                "reaction_smiles": match.reaction_smiles,
                "target_smiles": match.target_smiles,
                "product_index": match.product_index,
                "center_atom_maps": list(match.center_atom_maps),
                "product_to_target_atom_map": [
                    list(pair) for pair in match.product_to_target_atom_map
                ],
                "continuation_reactant_index": match.continuation_reactant_index,
                "continuation_molecule_path": (
                    list(match.continuation_molecule_path)
                    if match.continuation_molecule_path is not None
                    else None
                ),
                "continuation_to_next_target_atom_map": [
                    list(pair) for pair in match.continuation_to_next_target_atom_map
                ],
            }
        )
    return {
        "occurrence_id": occurrence.occurrence_id,
        "source_identity": occurrence.source_identity,
        "route_id": occurrence.route_id,
        "route_target_smiles": occurrence.route_target_smiles,
        "segment_target_smiles": occurrence.segment_target_smiles,
        "root_index": occurrence.root_index,
        "branch_index": occurrence.branch_index,
        "branch_indices": list(occurrence.branch_indices),
        "reaction_node_paths": [list(path) for path in occurrence.reaction_node_paths],
        "start_position": occurrence.start_position,
        "end_position": occurrence.end_position,
        "raw_sequence": list(occurrence.raw_sequence),
        "query_cgr_keys": list(occurrence.query_cgr_keys),
        "source_matches": source_matches,
        "source_route_leaves": [
            leaf.to_dict() for leaf in occurrence.source_route_leaves
        ],
    }


def _rrseq_cons_shared_application_contract(
    occurrence: Any,
    *,
    schema_version: int,
) -> dict[str, Any]:
    """Project an occurrence onto the contract shared at ``schema_version``."""

    if schema_version >= 3:
        payload = occurrence.to_dict()
        payload.pop("schema_version", None)
        return payload
    # No distinct schema-v2 boundary was published. It is supported as a
    # legacy/pre-context payload with the same required replay contract as v1.
    return _rrseq_cons_legacy_application_contract(occurrence)


def _deduplicate_rrseq_occurrence_records(
    occurrence_records: list[tuple[Path, tuple[Path, str], Any]],
) -> list[tuple[Path, tuple[Path, str], Any]]:
    """Choose deterministic, schema-rich duplicate records or fail on conflict."""

    records_by_id: dict[
        str,
        list[tuple[Path, tuple[Path, str], Any]],
    ] = defaultdict(list)
    for record in occurrence_records:
        records_by_id[record[2].occurrence_id].append(record)

    selected_records: list[tuple[Path, tuple[Path, str], Any]] = []
    for occurrence_id in sorted(records_by_id):
        candidates = records_by_id[occurrence_id]
        corpus_keys = {candidate[1] for candidate in candidates}
        if len(corpus_keys) != 1:
            sources = ", ".join(sorted(str(candidate[0]) for candidate in candidates))
            raise ValueError(
                "duplicate RRseq_cons occurrence is associated with different "
                f"TSV corpora: {occurrence_id} ({sources})"
            )
        candidates.sort(
            key=lambda candidate: (
                -int(candidate[2].schema_version),
                str(candidate[0].resolve()),
                json.dumps(
                    candidate[2].to_dict(),
                    sort_keys=True,
                    separators=(",", ":"),
                ),
            )
        )
        selected = candidates[0]
        selected_occurrence = selected[2]
        for candidate in candidates[1:]:
            candidate_occurrence = candidate[2]
            shared_version = min(
                int(selected_occurrence.schema_version),
                int(candidate_occurrence.schema_version),
            )
            if _rrseq_cons_shared_application_contract(
                selected_occurrence,
                schema_version=shared_version,
            ) != _rrseq_cons_shared_application_contract(
                candidate_occurrence,
                schema_version=shared_version,
            ):
                raise ValueError(
                    "conflicting duplicate RRseq_cons occurrence across sidecars: "
                    f"{occurrence_id}; {selected[0]} (schema v"
                    f"{selected_occurrence.schema_version}) and {candidate[0]} "
                    f"(schema v{candidate_occurrence.schema_version}) disagree "
                    f"under the shared schema-v{shared_version} exact "
                    "composite-application contract"
                )
        selected_records.append(selected)
    return selected_records


def iter_rrseq_occurrence_applications(
    tsv_paths: Iterable[Path],
    occurrence_paths: Iterable[Path],
    *,
    occurrence_schema_versions: set[int] | None = None,
) -> Iterable[RRseqApplication]:
    """Yield exact applications linked to route, target, branch, and matches.

    When supplied, occurrence_schema_versions receives every validated record
    version present in the input sidecars, including records not selected by
    the aggregate TSVs or deduplicated across sidecars.
    """

    from route_inspector.tactics.rrseq.occurrences import iter_rrseq_cons_occurrences

    tsv_paths = list(tsv_paths)
    occurrence_paths = list(occurrence_paths)
    tsv_corpus_keys = {_rrseq_artifact_corpus_key(tsv_path) for tsv_path in tsv_paths}

    def occurrence_corpus_key(occurrence_path: Path) -> tuple[Path, str]:
        occurrence_key = _rrseq_artifact_corpus_key(occurrence_path)
        if occurrence_key in tsv_corpus_keys:
            return occurrence_key
        prefix_matches = [key for key in tsv_corpus_keys if key[1] == occurrence_key[1]]
        if len(prefix_matches) == 1:
            return prefix_matches[0]
        if len(tsv_corpus_keys) == 1:
            return next(iter(tsv_corpus_keys))
        raise ValueError(
            "cannot associate RRSeq occurrence sidecar with one TSV "
            f"corpus: {occurrence_path}"
        )

    # A TSV retains one display-SMARTS representative per native QueryCGR
    # identity. Learn that representative's extraction-time identity from the
    # authoritative occurrence sidecar instead of reparsing display SMARTS.
    # Re-parsing is kept only for historical sidecars without native keys.
    occurrence_records: list[tuple[Path, tuple[Path, str], Any]] = []
    for occurrence_path in occurrence_paths:
        corpus_key = occurrence_corpus_key(occurrence_path)
        for occurrence in iter_rrseq_cons_occurrences(occurrence_path):
            if occurrence_schema_versions is not None:
                occurrence_schema_versions.add(int(occurrence.schema_version))
            occurrence_records.append((occurrence_path, corpus_key, occurrence))
    occurrence_records = _deduplicate_rrseq_occurrence_records(occurrence_records)

    native_identities_by_rrseq: dict[
        tuple[Path, str], dict[str, set[tuple[Any, ...]]]
    ] = defaultdict(lambda: defaultdict(set))
    for _occurrence_path, corpus_key, occurrence in occurrence_records:
        if occurrence.query_cgr_keys:
            native_identities_by_rrseq[corpus_key][occurrence.rrseq_cons].add(
                (
                    "query_cgr",
                    occurrence.rrseq_cons_size,
                    occurrence.query_cgr_keys,
                )
            )

    allowed_rows_by_corpus: dict[
        tuple[Path, str],
        dict[
            tuple[Any, ...],
            list[
                tuple[
                    Path,
                    int,
                    str,
                    frozenset[str],
                    frozenset[str],
                ]
            ],
        ],
    ] = defaultdict(lambda: defaultdict(list))
    for tsv_path in tsv_paths:
        corpus_key = _rrseq_artifact_corpus_key(tsv_path)
        with tsv_path.open(encoding="utf-8") as file:
            reader = csv.DictReader(file, delimiter="\t")
            fieldnames = set(reader.fieldnames or ())
            required = {"Reference", "Target_molecules"}
            missing = sorted(required - fieldnames)
            sequence_column = find_rrseq_column(
                fieldnames,
                kind=RRSEQ_CONS_KIND,
            )
            if sequence_column is None:
                missing.append(RRSEQ_CONS_COLUMN)
            if missing:
                raise ValueError(
                    f"{tsv_path} lacks exact-provenance columns: " + ", ".join(missing)
                )
            for row_index, row in enumerate(reader):
                rrseq = (row.get(sequence_column) or "").strip()
                if rrseq:
                    native_identities = native_identities_by_rrseq[corpus_key].get(
                        rrseq, set()
                    )
                    if len(native_identities) > 1:
                        raise ValueError(
                            "one RRSeq display representation has conflicting "
                            f"native QueryCGR identities: {tsv_path}:{row_index + 2}"
                        )
                    identity = (
                        next(iter(native_identities))
                        if native_identities
                        else _rrseq_structural_identity(rrseq)
                    )
                    allowed_rows_by_corpus[corpus_key][identity].append(
                        (
                            tsv_path,
                            row_index,
                            rrseq,
                            frozenset(split_cell(row.get("Reference"))),
                            frozenset(split_cell(row.get("Target_molecules"))),
                        )
                    )

    for occurrence_path, corpus_key, occurrence in occurrence_records:
        allowed_rows = allowed_rows_by_corpus[corpus_key]
        occurrence_identity = (
            (
                "query_cgr",
                occurrence.rrseq_cons_size,
                occurrence.query_cgr_keys,
            )
            if occurrence.query_cgr_keys
            else _rrseq_structural_identity(occurrence.rrseq_cons)
        )
        source_rows = [
            source_row
            for source_row in allowed_rows.get(occurrence_identity, [])
            if occurrence.route_id in source_row[3]
            and occurrence.segment_target_smiles in source_row[4]
        ]
        if not source_rows:
            continue
        (
            source_tsv,
            source_row,
            _representative_rrseq,
            _route_ids,
            _target_molecules,
        ) = sorted(
            source_rows,
            key=lambda item: (str(item[0]), item[1]),
        )[0]
        yield RRseqApplication(
            source_tsv=source_tsv,
            row_index=source_row,
            rrseq=occurrence.rrseq_cons,
            rrseq_size=occurrence.rrseq_cons_size,
            route_ids=(occurrence.route_id,),
            target_smiles=occurrence.segment_target_smiles,
            occurrence_id=occurrence.occurrence_id,
            route_id=occurrence.route_id,
            route_target_smiles=occurrence.route_target_smiles,
            root_index=occurrence.root_index,
            branch_index=occurrence.branch_index,
            branch_indices=occurrence.branch_indices,
            reaction_node_paths=occurrence.reaction_node_paths,
            start_position=occurrence.start_position,
            end_position=occurrence.end_position,
            source_matches=tuple(
                match.to_dict() for match in occurrence.source_matches
            ),
            source_route_leaves=tuple(
                leaf.mapped_smiles for leaf in occurrence.source_route_leaves
            ),
            provenance_quality="exact",
            source_occurrence_path=occurrence_path,
            source_identity=occurrence.source_identity,
            occurrence_schema_version=occurrence.schema_version,
        )


def expand_rrseq_tsv_paths(paths: Iterable[Path]) -> list[Path]:
    """Resolve executable RRseq_cons TSV paths.

    Centralizing this logic keeps file naming, compressed input handling, and TSV/JSON
    formatting consistent across extraction, scoring, and tutorials.
    """
    expanded: list[Path] = []
    seen: set[Path] = set()
    for raw_path in paths:
        path = resolve_existing_path(raw_path)
        reject_gapped_rrseq_artifact(path)
        if path.is_dir() and any(
            is_gapped_rrseq_artifact(candidate)
            for pattern in ("*_rrseq_gap.tsv", "*_separated_rrseqs.tsv")
            for candidate in path.glob(pattern)
        ):
            raise ValueError(f"{path} contains analysis-only RRseq_gap artifacts")
        candidate_paths = (
            sorted(path.glob("*_rrseq_cons.tsv")) if path.is_dir() else [path]
        )
        if path.is_dir():
            candidate_paths.extend(sorted(path.glob("*_rrseqs.tsv")))
        if path.is_dir() and not candidate_paths:
            candidate_paths = sorted(path.glob("*.tsv"))

        candidate_paths = [
            candidate
            for candidate in candidate_paths
            if not is_gapped_rrseq_artifact(candidate)
        ]
        for candidate in candidate_paths:
            key = candidate.resolve() if candidate.exists() else candidate
            if key not in seen:
                seen.add(key)
                expanded.append(candidate)
    return expanded
