"""Corpus-level streaming, multiprocessing, aggregation, and output orchestration."""

from __future__ import annotations

import traceback
from multiprocessing import get_context
from typing import Any

from route_inspector.datasets.paroutes.source_ids import PAROUTES_SOURCE_ID_ADAPTER
from route_inspector.infrastructure.runtime import setup_runtime_cache_dirs
from route_inspector.rules.config import (
    RuleExtractionSettings,
)
from route_inspector.rules.extraction import (
    PrecomputedRuleExtractor,
    SerializedReactionRuleStep,
    SynPlannerRuleExtractor,
    serialize_reaction_rule_step,
)
from route_inspector.rules.models import (
    RouteProcessingStats,
)
from route_inspector.tactics.rrseq.naming import (
    RRSEQ_CONS_KIND,
)
from route_inspector.tactics.rrseq.processing import (
    process_route_for_rrseqs,
)

_RRSEQ_WORKER_EXTRACTOR: Any | None = None
_RRSEQ_WORKER_MIN_LENGTH = 2
_RRSEQ_WORKER_MAX_LENGTH: int | None = 100
_RRSEQ_WORKER_STORE_ROUTES_WITHOUT_RRSEQS = True
_RRSEQ_WORKER_SEQUENCE_MODE = RRSEQ_CONS_KIND
_RRSEQ_WORKER_SOURCE_IDENTITY = ""
_RRSEQ_WORKER_DATASET_ID = ""
_RRSEQ_WORKER_SOURCE_ID_ADAPTER = PAROUTES_SOURCE_ID_ADAPTER
_RRSEQ_MULTIPROCESSING_CONTEXT = get_context("spawn")


def _init_rrseq_worker(
    extractor_args: dict[str, Any],
    min_length: int,
    max_length: int | None,
    store_routes_without_rrseqs: bool,
    sequence_mode: str = RRSEQ_CONS_KIND,
    source_identity: str = "",
    dataset_id: str = "",
    source_id_adapter: str = PAROUTES_SOURCE_ID_ADAPTER,
) -> None:
    """Run the worker entry point for init rrseq.

    The result preserves reaction order and the shared-center constraint used to decide
    whether adjacent route steps form a valid rrseq rule.
    """
    global _RRSEQ_WORKER_EXTRACTOR
    global _RRSEQ_WORKER_MIN_LENGTH
    global _RRSEQ_WORKER_MAX_LENGTH
    global _RRSEQ_WORKER_STORE_ROUTES_WITHOUT_RRSEQS
    global _RRSEQ_WORKER_SEQUENCE_MODE
    global _RRSEQ_WORKER_SOURCE_IDENTITY
    global _RRSEQ_WORKER_DATASET_ID
    global _RRSEQ_WORKER_SOURCE_ID_ADAPTER
    setup_runtime_cache_dirs()
    _RRSEQ_WORKER_EXTRACTOR = SynPlannerRuleExtractor.from_args(
        RuleExtractionSettings(**extractor_args)
    )
    _RRSEQ_WORKER_MIN_LENGTH = min_length
    _RRSEQ_WORKER_MAX_LENGTH = max_length
    _RRSEQ_WORKER_STORE_ROUTES_WITHOUT_RRSEQS = store_routes_without_rrseqs
    _RRSEQ_WORKER_SEQUENCE_MODE = sequence_mode
    _RRSEQ_WORKER_SOURCE_IDENTITY = source_identity
    _RRSEQ_WORKER_DATASET_ID = dataset_id
    _RRSEQ_WORKER_SOURCE_ID_ADAPTER = source_id_adapter


def _rrseq_route_worker(item: tuple[Any, dict[str, Any]]) -> dict[str, Any]:
    """Run the worker entry point for rrseq route.

    The result preserves reaction order and the shared-center constraint used to decide
    whether adjacent route steps form a valid rrseq rule.
    """
    route_id, route = item
    try:
        if _RRSEQ_WORKER_EXTRACTOR is None:
            raise RuntimeError("rrseq worker was not initialized")
        return process_route_for_rrseqs(
            route_id,
            route,
            _RRSEQ_WORKER_EXTRACTOR,
            min_length=_RRSEQ_WORKER_MIN_LENGTH,
            max_length=_RRSEQ_WORKER_MAX_LENGTH,
            store_route_without_rrseqs=(_RRSEQ_WORKER_STORE_ROUTES_WITHOUT_RRSEQS),
            sequence_mode=_RRSEQ_WORKER_SEQUENCE_MODE,
            source_identity=_RRSEQ_WORKER_SOURCE_IDENTITY,
            dataset_id=_RRSEQ_WORKER_DATASET_ID,
            source_id_adapter=_RRSEQ_WORKER_SOURCE_ID_ADAPTER,
        )
    except Exception as exc:
        return {
            "route_id": route_id,
            "route_sequences": {},
            "route_sequence_query_cgr_keys": {},
            "route_sequence_base_query_cgr_keys": {},
            "single_rules": {},
            "single_rule_query_cgr_keys": {},
            "single_rule_base_query_cgr_keys": {},
            "single_rule_occurrences": [],
            "rrseq_cons_occurrences": [],
            "rrseq_gap_occurrences": [],
            "route_without_rrseqs": None,
            "no_rrseq_reason": "",
            "stats": RouteProcessingStats(routes_seen=1, errors=1),
            "error": {
                "route_id": route_id,
                "stage": "extract_route_rrseq_cons",
                "error_type": type(exc).__qualname__,
                "message": str(exc) or traceback.format_exc(limit=1).strip(),
            },
        }


def _rrseq_route_chunk_worker(
    items: list[tuple[Any, dict[str, Any]]],
) -> list[dict[str, Any]]:
    """Run the worker entry point for rrseq route chunk.

    The result preserves reaction order and the shared-center constraint used to decide
    whether adjacent route steps form a valid rrseq rule.
    """
    return [_rrseq_route_worker(item) for item in items]


def _init_precomputed_rrseq_worker(
    serialized_steps_by_reaction: dict[str, SerializedReactionRuleStep | None],
    errors_by_reaction: dict[str, dict[str, str]],
    min_length: int,
    max_length: int | None,
    store_routes_without_rrseqs: bool,
    sequence_mode: str,
    source_identity: str = "",
    dataset_id: str = "",
    source_id_adapter: str = PAROUTES_SOURCE_ID_ADAPTER,
) -> None:
    """Run the worker entry point for init precomputed rrseq.

    The result preserves reaction order and the shared-center constraint used to decide
    whether adjacent route steps form a valid rrseq rule.
    """
    global _RRSEQ_WORKER_EXTRACTOR
    global _RRSEQ_WORKER_MIN_LENGTH
    global _RRSEQ_WORKER_MAX_LENGTH
    global _RRSEQ_WORKER_STORE_ROUTES_WITHOUT_RRSEQS
    global _RRSEQ_WORKER_SEQUENCE_MODE
    global _RRSEQ_WORKER_SOURCE_IDENTITY
    global _RRSEQ_WORKER_DATASET_ID
    global _RRSEQ_WORKER_SOURCE_ID_ADAPTER
    setup_runtime_cache_dirs()
    _RRSEQ_WORKER_EXTRACTOR = PrecomputedRuleExtractor(
        serialized_steps_by_reaction,
        errors_by_reaction,
    )
    _RRSEQ_WORKER_MIN_LENGTH = min_length
    _RRSEQ_WORKER_MAX_LENGTH = max_length
    _RRSEQ_WORKER_STORE_ROUTES_WITHOUT_RRSEQS = store_routes_without_rrseqs
    _RRSEQ_WORKER_SEQUENCE_MODE = sequence_mode
    _RRSEQ_WORKER_SOURCE_IDENTITY = source_identity
    _RRSEQ_WORKER_DATASET_ID = dataset_id
    _RRSEQ_WORKER_SOURCE_ID_ADAPTER = source_id_adapter


def _unique_reaction_worker(reaction_smiles: str) -> dict[str, Any]:
    """Run the worker entry point for unique reaction.

    The helper feeds rule extraction, center-overlap filtering, or final TSV aggregation
    without changing the original route JSON in place.
    """
    try:
        if _RRSEQ_WORKER_EXTRACTOR is None:
            raise RuntimeError("unique reaction worker was not initialized")
        step, _cache_hit = _RRSEQ_WORKER_EXTRACTOR.extract(reaction_smiles)
        return {
            "reaction_smiles": reaction_smiles,
            "step": serialize_reaction_rule_step(step) if step is not None else None,
            "skipped": step is None,
            "error": None,
        }
    except Exception as exc:
        return {
            "reaction_smiles": reaction_smiles,
            "step": None,
            "skipped": False,
            "error": {
                "error_type": type(exc).__qualname__,
                "message": str(exc) or traceback.format_exc(limit=1).strip(),
            },
        }
