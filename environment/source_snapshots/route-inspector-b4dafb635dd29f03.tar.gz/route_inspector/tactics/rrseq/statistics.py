"""Analysis-only RRSeq statistics from immutable, prebuilt reference libraries."""

from __future__ import annotations

import argparse
import json
import shutil
import tempfile
import time
from collections import Counter
from pathlib import Path

from route_inspector.infrastructure.hashing import sha256_file
from route_inspector.infrastructure.publication import publish_directory_no_replace
from route_inspector.infrastructure.text import read_json
from route_inspector.metrics.routes import route_topology_metrics
from route_inspector.reference_library.catalog import ReferenceTacticLibrary
from route_inspector.routes.access import route_items
from route_inspector.rules.transformation import RuleFamilyIndex
from route_inspector.tactics.rrseq.statistics_io import (
    NameRxnAnnotations,
    node_at,
    record,
    write_json,
    write_tsv,
)

KINDS = ("rrseq_cons", "rrseq_gap")
ERROR_FIELDS = ("severity", "stage", "record_id", "message")
OCCURRENCE_FIELDS = (
    "dataset_id",
    "source_identity",
    "route_id",
    "kind",
    "family_key",
    "reference_occurrence_id",
    "native_occurrence_id",
    "rrseq_identity",
    "selected_reaction_count",
    "selected_reaction_node_paths",
    "skipped_reaction_node_paths",
    "skipped_reaction_count",
    "skipped_reactions_per_gap",
    "inter_selection_gap_widths",
    "number_of_gaps",
    "maximum_single_gap_size",
    "mean_gap_size",
    "NameRxn_sequence",
    "NameRxn_names",
    "classification_status",
    "missing_annotation_steps",
)


class OrderedIdentityIndex:
    """Context-free ordered identity using the library's existing exact policy.

    Labels are deterministic within a fixed input library and explicitly scoped
    to this analysis. Their integer values are never used as chemical evidence.
    """

    def __init__(self, version):
        if version not in (2, 3, 4):
            raise ValueError(
                "RRSeq statistics supports recorded identity versions 2, 3, and 4; historical version 1 is not reinterpreted"
            )
        self.version = version
        self.index = RuleFamilyIndex()
        self.native = {}
        self.witnesses = {}
        self.sequences = {}

    def rules(self, identity):
        if identity.identity_version != self.version:
            raise ValueError("mixed identity versions")
        payload = identity.equivalence_payload
        if self.version >= 3:
            rules = []
            for graph in payload["rule_sides"]:
                family = self.index.family(graph)
                label = f"analysis_rule_{family:06d}"
                self.witnesses.setdefault(
                    label,
                    {
                        "rule_identity": label,
                        "identity_version": self.version,
                        "comparison_witness": graph,
                    },
                )
                rules.append(label)
            return tuple(rules)
        rules = []
        for native in payload["query_cgr_keys"]:
            if native not in self.native:
                label = f"analysis_rule_{len(self.native):06d}"
                self.native[native] = label
                self.witnesses[label] = {
                    "rule_identity": label,
                    "identity_version": 2,
                    "query_cgr_key": native,
                }
            rules.append(self.native[native])
        return tuple(rules)

    def sequence(self, rules):
        if rules not in self.sequences:
            self.sequences[rules] = f"analysis_rrseq_{len(self.sequences):06d}"
        return self.sequences[rules]


def gap_metrics(occurrence):
    """Count actual skipped paths and reconcile stored inter-selection widths."""
    paths = occurrence.selected_reaction_node_paths
    widths = []
    for left, right in zip(paths, paths[1:]):
        if right[: len(left)] != left or (len(right) - len(left)) % 2:
            raise ValueError(
                "RRSeq selection is not an ordered root-to-leaf reaction path"
            )
        widths.append((len(right) - len(left)) // 2 - 1)
    expected_skipped = {
        right[:depth]
        for left, right in zip(paths, paths[1:])
        for depth in range(len(left) + 2, len(right), 2)
    }
    if expected_skipped != set(occurrence.skipped_reaction_node_paths):
        raise ValueError("skipped reaction paths disagree with the selected path span")
    recorded = occurrence.annotations.get("gap_widths")
    # The native schema records positive widths only (adjacent pairs are omitted).
    positive = [value for value in widths if value]
    if recorded is not None and list(recorded) != positive:
        raise ValueError("recorded gap widths disagree with source paths")
    return {
        "skipped_reaction_count": sum(widths),
        "skipped_reactions_per_gap": positive,
        "inter_selection_gap_widths": widths,
        "number_of_gaps": len(positive),
        "maximum_single_gap_size": max(positive, default=0),
        "mean_gap_size": sum(positive) / len(positive) if positive else 0.0,
    }


def _progress(message):
    print(message, flush=True)


def _analyse(
    library,
    routes_path,
    dataset_id,
    expected_routes,
    annotation_paths,
    stage,
    errors,
    namerxn_class_names=None,
):
    manifest = library.manifest
    corpora = manifest.reference_corpora
    if len(corpora) != 1 or corpora[0]["dataset_id"] != dataset_id:
        raise ValueError("analysis requires one matching dataset corpus")
    corpus = corpora[0]
    digest = sha256_file(routes_path)
    if (
        digest != corpus.get("input_sha256")
        or f"sha256:{digest}" != corpus["source_identity"]
    ):
        raise ValueError("cleaned route digest differs from reference-library source")
    items = list(route_items(read_json(routes_path)))
    routes = {str(key): root for key, root in items}
    roster = set(map(str, corpus["route_ids"]))
    if (
        len(routes) != len(items)
        or set(routes) != roster
        or len(roster) != corpus["route_count"]
    ):
        raise ValueError("cleaned route IDs do not match the complete library roster")
    if len(routes) != expected_routes:
        raise ValueError(f"expected {expected_routes} routes, found {len(routes)}")
    annotations = NameRxnAnnotations(
        annotation_paths,
        routes=routes,
        dataset_id=dataset_id,
        source_identity=corpus["source_identity"],
    )
    errors.extend(annotations.diagnostics.values())
    if not annotation_paths:
        errors.append(
            dict(
                severity="warning",
                stage="namerxn",
                record_id=dataset_id,
                message="No NameRxn annotation input: missing labels are MISSING_ANNOTATION, not provider classifications. NameRxn compression and top sequences are unavailable.",
            )
        )
    topology = {key: route_topology_metrics(root) for key, root in routes.items()}
    route_counts = {key: Counter() for key in routes}
    route_families = {key: {kind: set() for kind in KINDS} for key in routes}
    index = OrderedIdentityIndex(library.tactic_identity_version)
    entries = sorted(
        (entry for kind in KINDS for entry in library.entries(kind)),
        key=lambda e: e.entry_id,
    )
    families = {}
    context_keys = set()
    for entry in entries:
        rules = index.rules(entry.identity)
        pair = (
            entry.kind,
            rules,
            tuple(
                entry.identity.equivalence_payload.get("inter_selection_gap_widths", ())
            ),
        )
        if pair in context_keys:
            raise ValueError(
                f"duplicate exact ordered family within {entry.kind}: {entry.entry_id}"
            )
        context_keys.add(pair)
        identity = index.sequence(rules)
        families[entry.entry_id] = {
            "entry": entry,
            "rules": rules,
            "identity": identity,
            "routes": set(),
            "occurrences": 0,
            "namerxn": Counter(),
            "example": None,
        }
    _progress(
        f"Indexed {len(entries):,} authoritative RRSeq families; scanning occurrence provenance"
    )
    lengths, gaps = {}, {}
    names = {}
    classification = {kind: Counter() for kind in KINDS}
    seen = set()
    occurrence_rows = []
    for kind in KINDS:
        for occurrence in library.iter_occurrences(kind=kind):
            oid = occurrence.reference_occurrence_id
            if oid in seen:
                raise ValueError(f"duplicate occurrence {oid}")
            seen.add(oid)
            key = occurrence.route
            if (
                key.dataset_id != dataset_id
                or key.source_identity != corpus["source_identity"]
                or key.route_id not in routes
            ):
                raise ValueError(f"occurrence source route mismatch: {oid}")
            route_id = key.route_id
            for path in (
                *occurrence.selected_reaction_node_paths,
                *occurrence.skipped_reaction_node_paths,
            ):
                node_at(routes[route_id], path)
            try:
                metrics = gap_metrics(occurrence)
            except ValueError as exc:
                raise ValueError(f"{oid} (route {route_id}): {exc}") from exc
            entry_id = library.entry_id_for_occurrence(oid)
            family = families[entry_id]
            if not occurrence.identity.equivalent_to(family["entry"].identity):
                raise ValueError(f"ordered identity mismatch for {oid}")
            family["routes"].add(key)
            family["occurrences"] += 1
            if family["example"] is None:
                family["example"] = (route_id, oid)
            route_counts[route_id][kind] += 1
            route_families[route_id][kind].add(entry_id)
            size = len(occurrence.selected_reaction_node_paths)
            _aggregate(lengths, (kind, size), route_id, entry_id)
            if kind == "rrseq_gap":
                _aggregate(gaps, metrics["skipped_reaction_count"], route_id, entry_id)
            codes, class_names, status, missing = annotations.sequence(
                route_id, occurrence.selected_reaction_node_paths
            )
            family["namerxn"][(codes, class_names, status)] += 1
            classification[kind][status] += 1
            classification[kind]["missing_annotation_occurrences"] += bool(missing)
            classification[kind]["missing_annotation_selected_steps"] += missing
            classification[kind]["annotated_unclassified_occurrences"] += (
                status == "unclassified" and not missing
            )
            name_key = (kind, codes, status)
            _aggregate(names, name_key, route_id, entry_id)
            names[name_key].setdefault("name_variants", set()).add(class_names)
            occurrence_rows.append(
                {
                    **key.to_dict(),
                    "kind": kind,
                    "family_key": entry_id,
                    "reference_occurrence_id": oid,
                    "native_occurrence_id": occurrence.occurrence_id,
                    "rrseq_identity": family["identity"],
                    "selected_reaction_count": size,
                    "selected_reaction_node_paths": occurrence.selected_reaction_node_paths,
                    "skipped_reaction_node_paths": occurrence.skipped_reaction_node_paths,
                    **metrics,
                    "NameRxn_sequence": codes,
                    "NameRxn_names": class_names,
                    "classification_status": status,
                    "missing_annotation_steps": missing,
                }
            )
    for family in families.values():
        entry = family["entry"]
        if not family["occurrences"] or family["occurrences"] != entry.occurrence_count:
            raise ValueError(f"occurrence support mismatch: {entry.entry_id}")
        if (
            family["routes"] != set(entry.reference_routes)
            or len(family["routes"]) != entry.route_count
        ):
            raise ValueError(f"route support mismatch: {entry.entry_id}")
        if entry.route_count > entry.occurrence_count:
            raise ValueError(
                f"route support exceeds occurrence count: {entry.entry_id}"
            )
    for kind in KINDS:
        expected = manifest.statistics["occurrences_by_kind"].get(kind, 0)
        if sum(row[kind] for row in route_counts.values()) != expected:
            raise ValueError(f"occurrence total mismatch: {kind}")
        if sum(
            f["entry"].kind == kind for f in families.values()
        ) != manifest.statistics["entries_by_kind"].get(kind, 0):
            raise ValueError(f"family total mismatch: {kind}")
    fallback = sum(
        "exact_representation" in row.get("comparison_witness", {})
        for row in index.witnesses.values()
    )
    if fallback:
        errors.append(
            dict(
                severity="warning",
                stage="identity",
                record_id=dataset_id,
                message=f"{fallback} single-rule representatives use the library conservative exact-representation fallback; overlap may be underestimated.",
            )
        )
    with (stage / "rrseq_rule_identity_witnesses.jsonl").open("w") as out:
        for label, row in sorted(index.witnesses.items()):
            out.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
    write_tsv(
        stage / "rrseq_occurrence_provenance.tsv",
        occurrence_rows,
        OCCURRENCE_FIELDS,
    )
    write_tsv(
        stage / "rrseq_gap_occurrences.tsv",
        [r for r in occurrence_rows if r["kind"] == "rrseq_gap"],
        OCCURRENCE_FIELDS,
    )
    from route_inspector.tactics.rrseq.statistics_reporting import write_reports

    summary = write_reports(
        stage,
        families=families,
        route_counts=route_counts,
        route_families=route_families,
        topology=topology,
        lengths=lengths,
        gaps=gaps,
        names=names,
        classification=classification,
        dataset_id=dataset_id,
        source_identity=corpus["source_identity"],
        namerxn_class_names=namerxn_class_names,
    )
    summary["identity_comparison"] = {
        "identity_version": index.version,
        "rule_index_metrics": dict(index.index.metrics),
        "fallback_rule_representatives": fallback,
        "order": "stored target-to-precursor traversal",
        "analysis_identity_scope": manifest.library_id,
    }
    summary["namerxn_annotations"] = {
        "status": "available" if annotation_paths else "unavailable",
        "input_rows": annotations.input_rows,
        "distinct_source_reactions": len(annotations.labels),
        "provider_versions": sorted(annotations.versions),
        "source_status_counts": dict(
            Counter(label[2] for label in annotations.labels.values())
        ),
        "source_diagnostic_count": len(annotations.diagnostics),
        "classification_level": "Tier 3 (three-part numeric code)",
        "by_kind": {k: dict(v) for k, v in classification.items()},
    }
    summary["integrity"] = {
        "status": "passed",
        "checks": [
            "complete source-digest-bound route roster",
            "disjoint exhaustive route coverage",
            "occurrence route and node paths",
            "nonempty families",
            "occurrence support and exact route unions agree with catalog",
            "support <= occurrences",
            "ordered rule identity and ownership",
            "versioned exact matching without SMARTS re-extraction",
            "NameRxn supplied-row source reactions and versions",
        ],
        "namerxn_source_check": "passed"
        if annotation_paths
        else "not applicable: no annotations supplied",
    }
    return summary


def _aggregate(table, key, route_id, entry_id):
    row = table.setdefault(
        key, {"occurrence_count": 0, "routes": set(), "families": set()}
    )
    row["occurrence_count"] += 1
    row["routes"].add(route_id)
    row["families"].add(entry_id)


def build_rrseq_statistics(
    *,
    library_dir,
    routes_path,
    output_dir,
    dataset_id="n1",
    expected_routes=10000,
    namerxn_steps=(),
    namerxn_def=None,
    verification="full",
):
    """Verify inputs, analyse existing evidence, and publish without replacement."""
    destination = Path(output_dir)
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent)
    )
    errors = []
    started = time.monotonic()
    try:
        library_dir, routes_path = Path(library_dir), Path(routes_path)
        inputs = {
            "library_manifest": record(library_dir / "manifest.json"),
            "routes": record(routes_path),
            "namerxn_steps": [record(p) for p in namerxn_steps],
            "namerxn_def": record(namerxn_def) if namerxn_def else None,
        }
        from route_inspector.chemistry.classification.taxonomy import taxonomy_names

        class_names = taxonomy_names(namerxn_def) if namerxn_def else None
        _progress("Verifying the prebuilt library (no extraction or library rebuild)")
        with ReferenceTacticLibrary.load(
            library_dir, verification=verification
        ) as library:
            summary = _analyse(
                library,
                routes_path,
                dataset_id,
                expected_routes,
                namerxn_steps,
                stage,
                errors,
                namerxn_class_names=class_names,
            )
            inputs["library_id"] = library.library_id
            inputs["configuration_fingerprint"] = (
                library.manifest.configuration_fingerprint
            )
            inputs["catalog_artifacts"] = library.manifest.artifacts
            inputs["processing_profile"] = library.manifest.processing_profile.to_dict()
        for item in [
            inputs["library_manifest"],
            inputs["routes"],
            *inputs["namerxn_steps"],
            *([inputs["namerxn_def"]] if namerxn_def else []),
        ]:
            if record(item["path"]) != item:
                raise ValueError(f"input changed during analysis: {item['path']}")
        summary["warning_count"] = len(errors)
        summary["error_count"] = 0
        write_json(stage / "summary.json", summary)
        write_tsv(stage / "errors.tsv", errors, ERROR_FIELDS)
        from route_inspector.tactics.rrseq.statistics_reporting import markdown_report

        report = markdown_report(stage, summary)
        (stage / "report.md").write_text(report)
        artifacts = {
            path.name: {
                "path": path.name,
                "sha256": sha256_file(path),
                "size_bytes": path.stat().st_size,
            }
            for path in sorted(stage.iterdir())
            if path.is_file()
        }
        write_json(
            stage / "manifest.json",
            {
                "analysis_schema_version": 1,
                "status": "complete",
                "analysis": "rrseq_statistics",
                "dataset_id": dataset_id,
                "inputs": inputs,
                "library_verification": verification,
                "expected_route_count": expected_routes,
                "implementation": [
                    record(Path(__file__).with_name(name))
                    for name in (
                        "statistics.py",
                        "statistics_io.py",
                        "statistics_reporting.py",
                    )
                ],
                "definitions": {
                    "quantiles": "linear interpolation at (n-1)*p",
                    "convergence": "existing route_topology_metrics: total reactions > longest root-to-leaf reaction depth",
                    "leaves": "existing distinct_leaf_count; unique metadata.original_smiles",
                    "zero_reaction_density": "null/empty TSV cell",
                    "support_bin_coverage": "route union within each bin; bins can overlap",
                    "sequence_order": "stored target-to-precursor order, not synthetic execution order",
                },
                "elapsed_seconds": round(time.monotonic() - started, 3),
                "artifacts": artifacts,
            },
        )
        publish_directory_no_replace(stage, destination)
        _progress(report)
        return summary
    except Exception as exc:
        errors.append(
            dict(
                severity="error",
                stage="analysis",
                record_id="",
                message=f"{type(exc).__name__}: {exc}",
            )
        )
        # Retain diagnostics but never publish a partial result as a completed analysis.
        for path in stage.iterdir():
            if path.is_file():
                path.unlink()
        write_tsv(stage / "errors.tsv", errors, ERROR_FIELDS)
        write_json(
            stage / "manifest.json",
            {"analysis_schema_version": 1, "status": "failed", "error": str(exc)},
        )
        failed = destination.parent / f"{stage.name}.failed"
        stage.rename(failed)
        raise RuntimeError(
            f"RRSeq analysis failed; diagnostics: {failed / 'errors.tsv'}"
        ) from exc
    finally:
        if stage.exists():
            shutil.rmtree(stage)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--library", type=Path, default=Path("outputs/reference_libraries/n1")
    )
    parser.add_argument(
        "--routes", type=Path, default=Path("data/clean/n1_routes.json")
    )
    parser.add_argument(
        "--output-dir", type=Path, default=Path("outputs/n1/rrseq_analysis")
    )
    parser.add_argument("--dataset", default="n1")
    parser.add_argument("--expected-routes", type=int, default=10000)
    parser.add_argument("--namerxn-steps", action="append", type=Path, default=[])
    parser.add_argument(
        "--namerxn-def",
        type=Path,
        help="NameRxn taxonomy definitions for readable class sequences",
    )
    parser.add_argument(
        "--verification",
        choices=["full", "fast"],
        default="full",
        help="fast is only for a previously verified unchanged library",
    )
    args = parser.parse_args(argv)
    build_rrseq_statistics(
        library_dir=args.library,
        routes_path=args.routes,
        output_dir=args.output_dir,
        dataset_id=args.dataset,
        expected_routes=args.expected_routes,
        namerxn_steps=args.namerxn_steps,
        namerxn_def=args.namerxn_def,
        verification=args.verification,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
