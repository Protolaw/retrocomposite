from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence


def split_rrseq(rrseq: str) -> list[str]:
    """Split rrseq rule into normalized values.

    Rules are applied retrosynthetically in their encoded order; failures are raised as
    route unwrapping errors so callers can report the skipped target.
    """
    rules = [part.strip() for part in rrseq.split("$") if part.strip()]
    if not rules:
        raise ValueError("RRseq rule is empty")
    return rules


@dataclass
class UnwrapResult:
    routes_json: dict[int, dict[str, Any]]
    target_molecule: Any
    leaf_molecules: list[Any]
    reactions: list[Any]


AtomMapping = tuple[tuple[int, int], ...]


@dataclass(frozen=True)
class ReactorApplicationOutcome:
    """One unique reactor outcome and all matches producing its selected identity."""

    outcome_index: int
    reaction: Any
    products: tuple[Any, ...]
    reaction_smiles: str
    product_smiles: tuple[str, ...]
    query_to_target_mappings: tuple[AtomMapping, ...]


@dataclass(frozen=True)
class ReactorApplicationEnumeration:
    """Bounded outcome enumeration from one rule application."""

    outcomes: tuple[ReactorApplicationOutcome, ...]
    truncated: bool


@dataclass(frozen=True)
class RuleStepOutcomeTrace:
    """Serializable match and continuation evidence for one possible outcome."""

    outcome_index: int
    reaction_smiles: str
    product_smiles: tuple[str, ...]
    query_to_target_mappings: tuple[AtomMapping, ...]
    continuation_product_indices: tuple[int, ...]


@dataclass(frozen=True)
class RuleStepTrace:
    """Application evidence retained for one selected RRseq step."""

    step_index: int
    rule_smarts: str
    input_smiles: str
    outcomes: tuple[RuleStepOutcomeTrace, ...]
    selected_outcome_index: int
    selected_continuation_index: int | None
    truncated: bool = False


@dataclass
class TracedUnwrapResult(UnwrapResult):
    """An unwrap result augmented with outcome- and atom-match provenance."""

    step_traces: list[RuleStepTrace]


class RuleApplicationError(ValueError):
    """Raised when an extracted rule sequence cannot be applied to a molecule."""


class RuleApplicationOutcomeLimitError(RuleApplicationError):
    """Raised when bounded enumeration cannot establish an exact source match."""


class UnsupportedReactorTraceError(RuntimeError):
    """Raised when Chython no longer satisfies the trace adapter contract."""


class ChythonOneShotTraceAdapter:
    """Isolate Chython's non-public match-to-outcome data behind one adapter."""

    _REQUIRED_ATTRIBUTES = (
        "_patterns",
        "_products_atoms",
        "_automorphism_filter",
        "_patcher",
        "_one_shot",
    )

    def __init__(self, *, preserve_atom_mapping: bool = False) -> None:
        self.preserve_atom_mapping = preserve_atom_mapping

    def enumerate(
        self,
        reactor: Any,
        molecule: Any,
        *,
        max_unique_outcomes: int | None = None,
    ) -> ReactorApplicationEnumeration:
        """Enumerate unique outcomes, optionally distinguishing mapped lineage.

        The default groups chemical equivalents. Exact branch replay must opt
        into mapped identity so symmetry cannot discard the required atom cut.
        """

        if max_unique_outcomes is not None and max_unique_outcomes < 1:
            raise ValueError("max_unique_outcomes must be at least 1")
        missing = [
            attribute
            for attribute in self._REQUIRED_ATTRIBUTES
            if not hasattr(reactor, attribute)
        ]
        if missing:
            raise UnsupportedReactorTraceError(
                "Chython Reactor trace contract changed; missing " + ", ".join(missing)
            )
        if not reactor._one_shot:
            raise UnsupportedReactorTraceError(
                "trace adapter supports one-shot reactors only"
            )
        if len(reactor._patterns) != 1:
            raise UnsupportedReactorTraceError(
                "trace adapter supports one-reactant retrosynthetic rules only"
            )

        from chython.containers.reaction import ReactionContainer
        from chython.exceptions import InvalidAromaticRing

        pattern = reactor._patterns[0]
        records: dict[str, dict[str, Any]] = {}
        truncated = False
        mappings: Iterable[dict[int, int]] = pattern.get_mapping(
            molecule,
            automorphism_filter=reactor._automorphism_filter,
        )
        for raw_mapping in mappings:
            mapping = {
                int(query_atom): int(target_atom)
                for query_atom, target_atom in raw_mapping.items()
            }
            mapping_items: AtomMapping = tuple(sorted(mapping.items()))
            try:
                patched = reactor._patcher(molecule, mapping)
            except InvalidAromaticRing:
                continue
            products = (
                list(patched.split()) if len(reactor._products_atoms) > 1 else [patched]
            )
            reaction = ReactionContainer(
                reactants=(molecule.copy(),),
                products=tuple(products),
            )
            if len(products) > 1:
                reaction.contract_ions()
            outcome_key = (
                format(reaction, "m") if self.preserve_atom_mapping else str(reaction)
            )
            existing = records.get(outcome_key)
            if existing is not None:
                if mapping_items not in existing["mappings"]:
                    existing["mappings"].append(mapping_items)
                continue
            if max_unique_outcomes is not None and len(records) >= max_unique_outcomes:
                truncated = True
                break
            final_products = tuple(reaction.products)
            records[outcome_key] = {
                "reaction": reaction,
                "products": final_products,
                "reaction_smiles": format(reaction, "m"),
                "product_smiles": tuple(
                    format(product, "m") for product in final_products
                ),
                "mappings": [mapping_items],
            }

        outcomes = tuple(
            ReactorApplicationOutcome(
                outcome_index=index,
                reaction=record["reaction"],
                products=record["products"],
                reaction_smiles=record["reaction_smiles"],
                product_smiles=record["product_smiles"],
                query_to_target_mappings=tuple(record["mappings"]),
            )
            for index, record in enumerate(records.values())
        )
        return ReactorApplicationEnumeration(outcomes=outcomes, truncated=truncated)


def _compare_source_precursors(
    expected: Iterable[Any],
    actual: Iterable[Any],
    *,
    lineage_atom_ids: set[int],
) -> Any:
    """Compare source precursors while ignoring new-atom map labels."""

    from route_inspector.composite_rules.validation import (
        compare_precursor_multisets,
    )

    return compare_precursor_multisets(
        tuple(expected),
        tuple(actual),
        lineage_atom_ids=lineage_atom_ids,
    )


def _source_precursors_match(
    expected: Iterable[Any],
    actual: Iterable[Any],
    *,
    lineage_atom_ids: set[int],
) -> bool:
    """Match source precursors strictly while ignoring new-atom map labels."""

    comparison = _compare_source_precursors(
        expected,
        actual,
        lineage_atom_ids=lineage_atom_ids,
    )
    return comparison.chemistry_equivalent and comparison.mapping_consistent


def _source_step_reaction(
    source_match: Mapping[str, Any],
    *,
    step_index: int,
    rule_smarts: str,
) -> Any:
    """Parse and validate one serialized exact-source step witness."""

    from chython import smiles as parse_smiles

    recorded_step_index = source_match.get("step_index")
    if recorded_step_index is not None and int(recorded_step_index) != step_index:
        raise RuleApplicationError(
            f"source match step index does not match RRseq position {step_index + 1}"
        )
    recorded_rule = source_match.get("rule_smarts")
    if recorded_rule is not None and str(recorded_rule).strip() != rule_smarts.strip():
        raise RuleApplicationError(
            f"source match rule does not match RRseq step {step_index + 1}"
        )
    reaction_smiles = source_match.get("reaction_smiles")
    if not reaction_smiles:
        raise RuleApplicationError(
            f"source match for RRseq step {step_index + 1} has no reaction_smiles"
        )
    reaction = parse_smiles(str(reaction_smiles))
    if not getattr(reaction, "reactants", ()) or not getattr(
        reaction,
        "products",
        (),
    ):
        raise RuleApplicationError(
            f"source match for RRseq step {step_index + 1} is not a reaction"
        )
    return reaction


def _validate_source_step_target(
    source_match: Mapping[str, Any],
    source_reaction: Any,
    active_molecule: Any,
    *,
    step_index: int,
) -> None:
    """Require exact constitutional identity and recorded target-atom lineage."""

    product_index = source_match.get("product_index")
    if product_index is None:
        raise RuleApplicationError(
            f"source match for RRseq step {step_index + 1} has no product_index"
        )
    product_index = int(product_index)
    if product_index < 0 or product_index >= len(source_reaction.products):
        raise RuleApplicationError(
            f"source match for RRseq step {step_index + 1} has an invalid product_index"
        )
    source_product = source_reaction.products[product_index]
    comparison = _compare_source_precursors(
        (source_product,),
        (active_molecule,),
        lineage_atom_ids={int(atom_number) for atom_number in source_product},
    )
    if not comparison.chemistry_equivalent:
        raise RuleApplicationError(
            "active molecule is not constitutionally isomorphic to the recorded "
            f"source target at RRseq step {step_index + 1}"
        )
    if not comparison.mapping_consistent:
        raise RuleApplicationError(
            "active molecule does not preserve the recorded source-target atom "
            f"lineage at RRseq step {step_index + 1}"
        )


def _recorded_continuation_product_index(
    source_match: Mapping[str, Any],
    source_reaction: Any,
    outcome: ReactorApplicationOutcome,
    *,
    step_index: int,
    final_step: bool,
    lineage_atom_ids: set[int],
) -> int | None:
    """Locate the replay product containing the recorded mapped continuation."""

    continuation_index = source_match.get("continuation_reactant_index")
    if final_step:
        if continuation_index is not None:
            raise RuleApplicationError(
                f"final source match at RRseq step {step_index + 1} unexpectedly "
                "records a continuation"
            )
        return None
    if continuation_index is None:
        raise RuleApplicationError(
            f"source match for RRseq step {step_index + 1} has no continuation"
        )
    continuation_index = int(continuation_index)
    if continuation_index < 0 or continuation_index >= len(source_reaction.reactants):
        raise RuleApplicationError(
            f"source match for RRseq step {step_index + 1} has an invalid "
            "continuation_reactant_index"
        )

    source_continuation = source_reaction.reactants[continuation_index]
    recorded_mapping = tuple(
        (int(source), int(target))
        for source, target in source_match.get(
            "continuation_to_next_target_atom_map",
            (),
        )
    )
    source_atom_ids = {int(atom_number) for atom_number in source_continuation}
    if any(source not in source_atom_ids for source, _target in recorded_mapping):
        raise RuleApplicationError(
            f"source continuation map at RRseq step {step_index + 1} refers to "
            "an atom outside the recorded reactant"
        )

    candidates: list[int] = []
    for product_index, product in enumerate(outcome.products):
        if _source_precursors_match(
            (source_continuation,),
            (product,),
            lineage_atom_ids=lineage_atom_ids,
        ):
            candidates.append(product_index)
    if len(candidates) != 1:
        raise RuleApplicationError(
            "could not identify one replay product for the recorded mapped "
            f"continuation at RRseq step {step_index + 1}"
        )
    return candidates[0]


def first_retro_reaction(reactor: Any, molecule: Any) -> Any | None:
    """Return the first retrosynthetic reaction generated by a reactor.

    Rules are applied retrosynthetically in their encoded order; failures are raised as
    route unwrapping errors so callers can report the skipped target.
    """
    for reaction in reactor(molecule):
        return reaction
    return None


def select_retro_reaction(
    reactor: Any,
    molecule: Any,
    next_reactor: Any | None = None,
) -> tuple[Any, list[Any], list[tuple[int, Any]]] | None:
    """Select retro reaction for the next processing step.

    Rules are applied retrosynthetically in their encoded order; failures are raised as
    route unwrapping errors so callers can report the skipped target.
    """
    for reaction in reactor(molecule):
        products = list(reaction.products)
        if not products:
            continue
        if next_reactor is None:
            return reaction, products, []

        next_candidates = []
        for product_index, product in enumerate(products):
            if first_retro_reaction(next_reactor, product) is not None:
                next_candidates.append((product_index, product))
        if next_candidates:
            return reaction, products, next_candidates

    return None


def molecule_node(molecule: Any, *, in_stock: bool = False) -> dict[str, Any]:
    """Return molecule node from a molecule or molecule node.

    Rules are applied retrosynthetically in their encoded order; failures are raised as
    route unwrapping errors so callers can report the skipped target.
    """
    return {"type": "mol", "smiles": str(molecule), "in_stock": in_stock}


def mark_leaf_molecules_in_stock(node: dict[str, Any]) -> None:
    """Mark leaf molecules in stock in an unwrapped route tree.

    Rules are applied retrosynthetically in their encoded order; failures are raised as
    route unwrapping errors so callers can report the skipped target.
    """
    if node.get("type") == "mol" and not node.get("children"):
        node["in_stock"] = True
        return
    for child in node.get("children", []) or []:
        if isinstance(child, dict):
            mark_leaf_molecules_in_stock(child)


def unwrap_rrseq_cons(
    target_smiles: str,
    rrseq: str,
    *,
    route_id: int = 0,
    mark_leaves_in_stock: bool = True,
) -> dict[int, dict[str, Any]]:
    """Unwrap an executable RRseq_cons into a retrosynthetic route.

    Rules are applied retrosynthetically in their encoded order; failures are raised as
    route unwrapping errors so callers can report the skipped target.
    """
    return unwrap_rule_sequence(
        target_smiles,
        split_rrseq(rrseq),
        route_id=route_id,
        rule_key_prefix="rrseq",
        mark_leaves_in_stock=mark_leaves_in_stock,
    ).routes_json


def unwrap_rule_sequence(
    target_smiles: str,
    rule_smarts: list[str],
    *,
    route_id: int = 0,
    rule_key_prefix: str = "rule",
    mark_leaves_in_stock: bool = True,
) -> UnwrapResult:
    """Unwrap rule sequence into a retrosynthetic route.

    Rules are applied retrosynthetically in their encoded order; failures are raised as
    route unwrapping errors so callers can report the skipped target.
    """
    from chython import smiles as parse_smiles
    from synplan.chem.reaction import CanonicalRetroReactor

    reactors = [
        CanonicalRetroReactor.from_smarts(rule, delete_atoms=True, one_shot=True)
        for rule in rule_smarts
    ]

    target_molecule = parse_smiles(target_smiles)
    root = molecule_node(target_molecule, in_stock=False)
    active_node = root
    active_molecule = target_molecule
    node_molecules = {id(root): target_molecule}
    reactions = []

    for step_index, reactor in enumerate(reactors):
        next_reactor = (
            reactors[step_index + 1] if step_index < len(reactors) - 1 else None
        )
        selected = select_retro_reaction(reactor, active_molecule, next_reactor)
        if selected is None:
            raise RuleApplicationError(
                f"rule {step_index + 1} did not match active molecule {active_molecule}"
            )

        reaction, products, next_candidates = selected
        reactions.append(reaction)
        child_nodes = [molecule_node(product, in_stock=False) for product in products]
        node_molecules.update(
            {
                id(child_node): product
                for child_node, product in zip(child_nodes, products)
            }
        )
        reaction_node = {
            "type": "reaction",
            "smiles": format(reaction, "m"),
            "rule_key": f"{rule_key_prefix}:{step_index + 1}",
            "children": child_nodes,
        }
        active_node["children"] = [reaction_node]

        if step_index == len(reactors) - 1:
            break

        if not next_candidates:
            raise RuleApplicationError(
                f"rule {step_index + 2} did not match any reactant produced by "
                f"rule {step_index + 1}"
            )
        if len(next_candidates) > 1:
            # Deterministic first-match behavior keeps the unwrapped route as a
            # single route. The JSON keeps all sibling precursors from each step.
            pass

        product_index, active_molecule = next_candidates[0]
        active_node = child_nodes[product_index]

    if mark_leaves_in_stock:
        mark_leaf_molecules_in_stock(root)

    leaf_molecules = []

    def collect_leaf_molecules(node: dict[str, Any]) -> None:
        """Collect leaf molecules from route-analysis input data.

        Rules are applied retrosynthetically in their encoded order; failures are raised
        as route unwrapping errors so callers can report the skipped target.
        """
        if node.get("type") == "mol" and not node.get("children"):
            leaf_molecules.append(node_molecules[id(node)])
            return
        for child in node.get("children", []) or []:
            if isinstance(child, dict):
                collect_leaf_molecules(child)

    collect_leaf_molecules(root)

    return UnwrapResult(
        routes_json={route_id: root},
        target_molecule=target_molecule,
        leaf_molecules=leaf_molecules,
        reactions=reactions,
    )


def unwrap_rrseq_cons_traced(
    target_smiles: str,
    rrseq: str,
    *,
    route_id: int = 0,
    mark_leaves_in_stock: bool = True,
    source_matches: Sequence[Mapping[str, Any]] | None = None,
    max_outcomes_per_step: int | None = None,
) -> TracedUnwrapResult:
    """Unwrap RRseq_cons while retaining every selected step's match evidence."""

    return unwrap_rule_sequence_traced(
        target_smiles,
        split_rrseq(rrseq),
        route_id=route_id,
        rule_key_prefix="rrseq",
        mark_leaves_in_stock=mark_leaves_in_stock,
        source_matches=source_matches,
        max_outcomes_per_step=max_outcomes_per_step,
    )


def unwrap_rule_sequence_traced(
    target_smiles: str,
    rule_smarts: list[str],
    *,
    route_id: int = 0,
    rule_key_prefix: str = "rule",
    mark_leaves_in_stock: bool = True,
    source_matches: Sequence[Mapping[str, Any]] | None = None,
    adapter: ChythonOneShotTraceAdapter | None = None,
    max_outcomes_per_step: int | None = None,
) -> TracedUnwrapResult:
    """Unwrap a sequence while preserving generated outcomes and atom matches."""

    from chython import smiles as parse_smiles
    from synplan.chem.reaction import CanonicalRetroReactor

    # Source witnesses distinguish atom origins even in chemically identical
    # products. Do not collapse those alternatives before checking the witness.
    adapter = adapter or ChythonOneShotTraceAdapter(
        preserve_atom_mapping=source_matches is not None
    )
    reactors = [
        CanonicalRetroReactor.from_smarts(
            rule,
            delete_atoms=True,
            one_shot=True,
            automorphism_filter=source_matches is None,
        )
        for rule in rule_smarts
    ]
    if source_matches is not None and len(source_matches) != len(rule_smarts):
        raise RuleApplicationError(
            "source match count does not match the RRseq_cons length"
        )
    target_molecule = parse_smiles(target_smiles)
    root = molecule_node(target_molecule, in_stock=False)
    active_node = root
    active_molecule = target_molecule
    node_molecules = {id(root): target_molecule}
    reactions: list[Any] = []
    step_traces: list[RuleStepTrace] = []

    for step_index, reactor in enumerate(reactors):
        source_match = (
            source_matches[step_index] if source_matches is not None else None
        )
        source_reaction = None
        if source_match is not None:
            if not isinstance(source_match, Mapping):
                raise RuleApplicationError(
                    f"source match for RRseq step {step_index + 1} is not serialized"
                )
            source_reaction = _source_step_reaction(
                source_match,
                step_index=step_index,
                rule_smarts=rule_smarts[step_index],
            )
            _validate_source_step_target(
                source_match,
                source_reaction,
                active_molecule,
                step_index=step_index,
            )
        next_reactor = (
            reactors[step_index + 1] if step_index < len(reactors) - 1 else None
        )
        enumeration = adapter.enumerate(
            reactor,
            active_molecule,
            max_unique_outcomes=max_outcomes_per_step,
        )
        outcome_traces: list[RuleStepOutcomeTrace] = []
        selected: (
            tuple[
                ReactorApplicationOutcome,
                tuple[int, ...],
            ]
            | None
        ) = None
        for outcome in enumeration.outcomes:
            continuation_indices = tuple(
                product_index
                for product_index, product in enumerate(outcome.products)
                if next_reactor is not None
                and first_retro_reaction(next_reactor, product) is not None
            )
            outcome_traces.append(
                RuleStepOutcomeTrace(
                    outcome_index=outcome.outcome_index,
                    reaction_smiles=outcome.reaction_smiles,
                    product_smiles=outcome.product_smiles,
                    query_to_target_mappings=outcome.query_to_target_mappings,
                    continuation_product_indices=continuation_indices,
                )
            )
            if source_match is not None:
                lineage_atom_ids = {int(atom_number) for atom_number in active_molecule}
                if not _source_precursors_match(
                    source_reaction.reactants,
                    outcome.products,
                    lineage_atom_ids=lineage_atom_ids,
                ):
                    continue
                if selected is None:
                    recorded_continuation = _recorded_continuation_product_index(
                        source_match,
                        source_reaction,
                        outcome,
                        step_index=step_index,
                        final_step=next_reactor is None,
                        lineage_atom_ids=lineage_atom_ids,
                    )
                    selected = (
                        outcome,
                        (
                            ()
                            if recorded_continuation is None
                            else (recorded_continuation,)
                        ),
                    )
                continue
            if (
                selected is None
                and outcome.products
                and (next_reactor is None or continuation_indices)
            ):
                selected = (outcome, continuation_indices)

        if selected is None:
            limit_note = " before the outcome limit" if enumeration.truncated else ""
            if source_match is not None:
                error_class = (
                    RuleApplicationOutcomeLimitError
                    if enumeration.truncated
                    else RuleApplicationError
                )
                raise error_class(
                    f"rule {step_index + 1} generated no outcome matching the "
                    f"recorded source reaction{limit_note}"
                )
            raise RuleApplicationError(
                f"rule {step_index + 1} did not match active molecule "
                f"{active_molecule}{limit_note}"
            )

        outcome, continuation_indices = selected
        reactions.append(outcome.reaction)
        child_nodes = [
            molecule_node(product, in_stock=False) for product in outcome.products
        ]
        node_molecules.update(
            {
                id(child_node): product
                for child_node, product in zip(child_nodes, outcome.products)
            }
        )
        active_node["children"] = [
            {
                "type": "reaction",
                "smiles": outcome.reaction_smiles,
                "rule_key": f"{rule_key_prefix}:{step_index + 1}",
                "children": child_nodes,
            }
        ]
        selected_continuation = (
            continuation_indices[0] if next_reactor is not None else None
        )
        step_traces.append(
            RuleStepTrace(
                step_index=step_index,
                rule_smarts=rule_smarts[step_index],
                input_smiles=format(active_molecule, "m"),
                outcomes=tuple(outcome_traces),
                selected_outcome_index=outcome.outcome_index,
                selected_continuation_index=selected_continuation,
                truncated=enumeration.truncated,
            )
        )
        if next_reactor is None:
            break
        if selected_continuation is None:
            raise RuleApplicationError(
                f"rule {step_index + 2} did not match any reactant produced by "
                f"rule {step_index + 1}"
            )
        active_molecule = outcome.products[selected_continuation]
        if source_match is not None:
            recorded_continuation_mapping = {
                int(source): int(target)
                for source, target in source_match.get(
                    "continuation_to_next_target_atom_map",
                    (),
                )
            }
            if not recorded_continuation_mapping:
                raise RuleApplicationError(
                    f"source match for RRseq step {step_index + 1} has no "
                    "continuation atom map"
                )
            continuation_index = int(source_match["continuation_reactant_index"])
            source_continuation = source_reaction.reactants[continuation_index]
            continuation_comparison = _compare_source_precursors(
                (source_continuation,),
                (active_molecule,),
                lineage_atom_ids={
                    int(atom_number)
                    for atom_number in source_reaction.products[
                        int(source_match["product_index"])
                    ]
                },
            )
            expected_to_replay = {
                int(expected): int(replay)
                for atom_mapping in continuation_comparison.atom_mappings
                for expected, replay in atom_mapping
            }
            source_atom_ids = {int(atom_number) for atom_number in source_continuation}
            replay_atom_ids = {int(atom_number) for atom_number in active_molecule}
            if (
                not continuation_comparison.chemistry_equivalent
                or not continuation_comparison.mapping_consistent
                or set(expected_to_replay) != source_atom_ids
                or set(expected_to_replay.values()) != replay_atom_ids
                or set(recorded_continuation_mapping) != source_atom_ids
            ):
                raise RuleApplicationError(
                    f"source continuation map at RRseq step {step_index + 1} "
                    "does not cover the selected replay product and source target"
                )
            replay_to_expected = {
                replay: expected for expected, replay in expected_to_replay.items()
            }
            continuation_mapping = {
                replay: recorded_continuation_mapping[expected]
                for replay, expected in replay_to_expected.items()
            }
            active_molecule = active_molecule.copy()
            active_molecule.remap(continuation_mapping)
            child_nodes[selected_continuation]["smiles"] = str(active_molecule)
            node_molecules[id(child_nodes[selected_continuation])] = active_molecule
        active_node = child_nodes[selected_continuation]

    if mark_leaves_in_stock:
        mark_leaf_molecules_in_stock(root)

    leaf_molecules: list[Any] = []

    def collect_leaf_molecules(node: dict[str, Any]) -> None:
        if node.get("type") == "mol" and not node.get("children"):
            leaf_molecules.append(node_molecules[id(node)])
            return
        for child in node.get("children", []) or []:
            if isinstance(child, dict):
                collect_leaf_molecules(child)

    collect_leaf_molecules(root)
    return TracedUnwrapResult(
        routes_json={route_id: root},
        target_molecule=target_molecule,
        leaf_molecules=leaf_molecules,
        reactions=reactions,
        step_traces=step_traces,
    )
