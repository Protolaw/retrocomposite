"""Exact inter-selection spacing; zeros are meaningful positional evidence."""


def validate_gap_widths(widths, selected_count):
    if not isinstance(widths, (list, tuple)) or len(widths) != selected_count - 1:
        raise ValueError(
            "inter_selection_gap_widths must contain one width per selected pair"
        )
    if any(type(w) is not int or w < 0 for w in widths) or not any(widths):
        raise ValueError(
            "RRSeq_gap widths must be nonnegative integers with at least one positive width"
        )
    return tuple(widths)


def widths_from_paths(selected, skipped):
    selected = tuple(map(tuple, selected))
    widths, expected_skipped = [], set()
    for left, right in zip(selected, selected[1:]):
        if (
            right[: len(left)] != left
            or len(right) <= len(left)
            or (len(right) - len(left)) % 2
        ):
            raise ValueError(
                "RRSeq_gap selected paths must follow one ordered reaction chain"
            )
        widths.append((len(right) - len(left)) // 2 - 1)
        expected_skipped.update(
            right[:depth] for depth in range(len(left) + 2, len(right), 2)
        )
    if expected_skipped != set(map(tuple, skipped)) or len(expected_skipped) != len(
        skipped
    ):
        raise ValueError("RRSeq_gap widths disagree with exact skipped-node provenance")
    return validate_gap_widths(widths, len(selected))


def occurrence_gap_widths(occurrence):
    widths = widths_from_paths(
        occurrence.selected_reaction_node_paths, occurrence.skipped_reaction_node_paths
    )
    native = occurrence.native_payload
    positions = native.get(
        "selected_positions", occurrence.annotations.get("selected_positions")
    )
    if positions is not None:
        expected = tuple(b - a - 1 for a, b in zip(positions, positions[1:]))
        if expected != widths:
            raise ValueError("RRSeq_gap widths disagree with selected positions")
    for payload in (native, occurrence.annotations):
        if (
            "inter_selection_gap_widths" in payload
            and validate_gap_widths(
                payload["inter_selection_gap_widths"],
                len(occurrence.selected_reaction_node_paths),
            )
            != widths
        ):
            raise ValueError(
                "Recorded inter-selection widths disagree with source paths"
            )
        if "gap_widths" in payload and list(payload["gap_widths"]) != [
            w for w in widths if w
        ]:
            raise ValueError("Recorded positive-only widths disagree with source paths")
    return widths


class SpacedSequence(tuple):
    """Internal aggregate key retaining sequence tuple behavior and exact spacing."""

    def __new__(cls, rules, widths):
        value = super().__new__(cls, rules)
        value.widths = validate_gap_widths(widths, len(value))
        return value

    def __hash__(self):
        return hash((tuple(self), self.widths))

    def __eq__(self, other):
        return (
            isinstance(other, SpacedSequence)
            and tuple(self) == tuple(other)
            and self.widths == other.widths
        )

    def __ne__(self, other):
        return not self == other

    def __reduce__(self):
        return type(self), (tuple(self), self.widths)


def native_gap_widths(record):
    positions = record["selected_positions"]
    widths = validate_gap_widths(
        [b - a - 1 for a, b in zip(positions, positions[1:])], len(positions)
    )
    if (
        "inter_selection_gap_widths" in record
        and validate_gap_widths(record["inter_selection_gap_widths"], len(positions))
        != widths
    ):
        raise ValueError("Native gap widths disagree with selected positions")
    return widths


def aggregate_native_gaps(records, query_keys, base_keys):
    """Apply existing native identity aggregation independently per spacing vector."""
    from collections import defaultdict

    from route_inspector.tactics.rrseq.identities import (
        merge_rrseq_sequences_by_querycgr,
        raw_identity_evidence_by_representative,
    )

    by_width = defaultdict(list)
    for row in records:
        by_width[native_gap_widths(row)].append(row)
    references, targets, evidence = {}, {}, {}
    for widths, rows in sorted(by_width.items()):
        refs, tgts = defaultdict(set), defaultdict(lambda: defaultdict(set))
        for row in rows:
            rules = tuple(str(row.get("RRseq_gap") or row["RRseq"]).split("$"))
            route = row["route_id"]
            refs[rules].add(route)
            tgts[rules][route].add(row["target_molecule"])
        merged, merged_targets = merge_rrseq_sequences_by_querycgr(
            refs, tgts, query_keys
        )
        ev = raw_identity_evidence_by_representative(refs, query_keys, base_keys, rows)
        for rules in merged:
            key = SpacedSequence(rules, widths)
            references[key], targets[key], evidence[key] = (
                merged[rules],
                merged_targets[rules],
                ev[rules],
            )
    return references, targets, evidence
