"""Read persisted RRSeq scoring inputs without extracting reactions."""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path

from route_inspector.infrastructure.artifacts import split_cell
from route_inspector.infrastructure.paths import resolve_existing_path
from route_inspector.infrastructure.text import read_tsv_rows
from route_inspector.metrics.rrseq_overlap import (
    RRseqClassificationSet,
    RRseqSet,
    empty_classification_set,
    normalize_rrseq,
)
from route_inspector.tactics.rrseq.artifacts import expand_rrseq_tsv_paths


def popularity_from_row(row: dict[str, str]) -> int:
    """Read a rule popularity value from an extracted-rule TSV row.

    The scorer normalizes rule sequences before comparison so order-sensitive rrseq
    rules can be matched exactly and weighted by popularity.
    """
    for column in ("popularity", "route_ids_size"):
        value = row.get(column, "").strip()
        if value.isdigit():
            return int(value)
    references = split_cell(row.get("Reference"))
    return max(len(references), 1)


def split_rrseqs_cell(value: str | None) -> list[str]:
    """Split rrseqs cell into normalized values.

    The scorer normalizes rule sequences before comparison so order-sensitive rrseq
    rules can be matched exactly and weighted by popularity.
    """
    if not value:
        return []
    return [part.strip() for part in value.split(" || ") if part.strip()]


def classification_from_row(row: dict[str, str], path: Path) -> str | None:
    """Read positive or negative composite classification from a TSV row.

    Classification-aware scores reward overlap with positive composite rules and
    penalize overlap with rules already explained by default templates.
    """
    value = row.get("classification", "").strip().lower()
    if value in {"positive", "pos"}:
        return "positive"
    if value in {"negative", "neg"}:
        return "negative"

    stem = path.stem.lower()
    if stem.endswith("_pos") or stem.endswith("_positive"):
        return "positive"
    if stem.endswith("_neg") or stem.endswith("_negative"):
        return "negative"
    return None


def expand_classification_tsv_paths(paths: list[Path]) -> list[Path]:
    """Resolve output path information for expand classification TSV paths.

    Classification-aware scores reward overlap with positive composite rules and
    penalize overlap with rules already explained by default templates.
    """
    expanded: list[Path] = []
    seen: set[Path] = set()
    for raw_path in paths:
        path = resolve_existing_path(raw_path)
        if path.is_dir():
            candidate_paths = sorted(
                candidate
                for candidate in path.glob("*_classified_composite_rules.tsv")
                if not candidate.stem.endswith(("_pos", "_neg"))
            )
            if not candidate_paths:
                candidate_paths = sorted(path.glob("*.tsv"))
        else:
            candidate_paths = [path]

        for candidate in candidate_paths:
            key = candidate.resolve() if candidate.exists() else candidate
            if key not in seen:
                seen.add(key)
                expanded.append(candidate)
    return expanded


def load_rrseq_classifications(
    paths: list[Path] | None,
) -> RRseqClassificationSet:
    """Load rrseq rule classifications from configured sources.

    Classification-aware scores reward overlap with positive composite rules and
    penalize overlap with rules already explained by default templates.
    """
    if not paths:
        return empty_classification_set()

    positive_weight_by_rule: dict[str, int] = defaultdict(int)
    negative_weight_by_rule: dict[str, int] = defaultdict(int)
    rows_seen = 0
    parse_errors = 0
    resolved_paths = expand_classification_tsv_paths(paths)

    for path in resolved_paths:
        fieldnames, rows = read_tsv_rows(path)
        rrseq_column = "RRseq_cons" if "RRseq_cons" in fieldnames else "RRseqs"
        if rrseq_column not in fieldnames:
            raise ValueError(f"{path} has no RRseq_cons column")
        for row in rows:
            rows_seen += 1
            classification = classification_from_row(row, path)
            if classification is None:
                parse_errors += 1
                continue
            weight = popularity_from_row(row)
            for raw_rule in split_rrseqs_cell(row.get(rrseq_column)):
                try:
                    rule = normalize_rrseq(raw_rule)
                except ValueError:
                    parse_errors += 1
                    continue
                if classification == "positive":
                    positive_weight_by_rule[rule] += weight
                else:
                    negative_weight_by_rule[rule] += weight

    return RRseqClassificationSet(
        source=",".join(str(path) for path in resolved_paths),
        positive_weight_by_rule=dict(positive_weight_by_rule),
        negative_weight_by_rule=dict(negative_weight_by_rule),
        rows_seen=rows_seen,
        parse_errors=parse_errors,
    )


def load_extracted_rrseq_set(paths: list[Path]) -> RRseqSet:
    """Load extracted rrseq rule set from configured sources.

    Reference rules are extracted directly from the route JSON with the same SynPlanner
    settings used for the candidate rrseqs.
    """
    popularity_by_rule: dict[str, int] = defaultdict(int)
    references_by_rule: dict[str, set[str]] = defaultdict(set)
    rows_seen = 0
    parse_errors = 0
    resolved_paths = expand_rrseq_tsv_paths(paths)

    for path in resolved_paths:
        fieldnames, rows = read_tsv_rows(path)
        rrseq_column = "RRseq_cons" if "RRseq_cons" in fieldnames else "RRseq"
        if rrseq_column not in fieldnames:
            raise ValueError(f"{path} has no RRseq_cons column")
        for row in rows:
            rows_seen += 1
            try:
                rule = normalize_rrseq(row.get(rrseq_column, ""))
            except ValueError:
                parse_errors += 1
                continue
            popularity_by_rule[rule] += popularity_from_row(row)
            references_by_rule[rule].update(split_cell(row.get("Reference")))

    return RRseqSet(
        source=",".join(str(path) for path in resolved_paths),
        popularity_by_rule=dict(popularity_by_rule),
        references_by_rule={
            rule: set(refs) for rule, refs in references_by_rule.items()
        },
        rows_seen=rows_seen,
        parse_errors=parse_errors,
    )
