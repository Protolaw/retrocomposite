"""Canonical names for the two reaction-rule-sequence variants."""

from __future__ import annotations

from collections.abc import Iterable

RRSEQ_CONS_KIND = "cons"
RRSEQ_GAP_KIND = "gap"
RRSEQ_CONS_COLUMN = "RRseq_cons"
RRSEQ_GAP_COLUMN = "RRseq_gap"
RRSEQ_LEGACY_COLUMN = "RRseq"
RRSEQ_AGGREGATE_TSV_SCHEMA_VERSION = 1


def normalize_rrseq_kind(value: str | None) -> str:
    """Return the canonical RRSeq variant for a current or legacy mode name."""

    normalized = (value or RRSEQ_CONS_KIND).strip().lower().replace("-", "_")
    aliases = {
        "cons": RRSEQ_CONS_KIND,
        "consecutive": RRSEQ_CONS_KIND,
        "ordinary": RRSEQ_CONS_KIND,
        "classic": RRSEQ_CONS_KIND,
        "classical": RRSEQ_CONS_KIND,
        "gap": RRSEQ_GAP_KIND,
        "gapped": RRSEQ_GAP_KIND,
        "separated": RRSEQ_GAP_KIND,
    }
    try:
        return aliases[normalized]
    except KeyError as exc:
        raise ValueError(f"unsupported RRSeq variant: {value!r}") from exc


def rrseq_column_for_kind(kind: str) -> str:
    """Return the canonical TSV/JSON sequence field for one RRSeq variant."""

    return (
        RRSEQ_CONS_COLUMN
        if normalize_rrseq_kind(kind) == RRSEQ_CONS_KIND
        else RRSEQ_GAP_COLUMN
    )


def find_rrseq_column(
    fieldnames: Iterable[str],
    *,
    kind: str = RRSEQ_CONS_KIND,
    allow_legacy: bool = True,
) -> str | None:
    """Find a canonical RRSeq field, optionally accepting the legacy field."""

    names = set(fieldnames)
    canonical = rrseq_column_for_kind(kind)
    if canonical in names:
        return canonical
    if allow_legacy and RRSEQ_LEGACY_COLUMN in names:
        return RRSEQ_LEGACY_COLUMN
    return None


__all__ = [
    "RRSEQ_AGGREGATE_TSV_SCHEMA_VERSION",
    "RRSEQ_CONS_COLUMN",
    "RRSEQ_CONS_KIND",
    "RRSEQ_GAP_COLUMN",
    "RRSEQ_GAP_KIND",
    "RRSEQ_LEGACY_COLUMN",
    "find_rrseq_column",
    "normalize_rrseq_kind",
    "rrseq_column_for_kind",
]
