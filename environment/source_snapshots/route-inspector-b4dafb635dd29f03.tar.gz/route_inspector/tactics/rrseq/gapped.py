from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Sequence


@dataclass(frozen=True)
class GappedCenterComponent:
    """One net RouteCGR center component with selected-step provenance."""

    atoms: frozenset[int]
    step_numbers: frozenset[int]
    atomic_step_numbers: frozenset[int] = frozenset()


@dataclass(frozen=True)
class ComposedGappedHistory:
    """Selected-reaction RouteCGR and its attributable net center components."""

    route_cgr: Any
    reaction: Any
    components: tuple[GappedCenterComponent, ...]

    @property
    def center_atoms(self) -> frozenset[int]:
        return frozenset(
            atom_number
            for component in self.components
            for atom_number in component.atoms
        )

    @property
    def has_net_change(self) -> bool:
        return bool(self.components)


def _atom_has_step_change(state: Any) -> bool:
    if not isinstance(state, (tuple, list)) or len(state) != 4:
        return False
    charge, product_charge, radical, product_radical = state
    return charge != product_charge or radical != product_radical


def _bond_has_step_change(state: Any) -> bool:
    return isinstance(state, (tuple, list)) and len(state) == 2 and state[0] != state[1]


def center_component_step_numbers(
    route_cgr: Any,
    center_atoms: Iterable[int],
) -> frozenset[int]:
    """Return selected RouteCGR steps that explicitly changed a center component.

    RouteCGR composition of noncontiguous reactions can expose state differences
    caused solely by omitted reactions. Such components have no dynamic selected-step
    provenance and are deliberately excluded from gapped composite templates.
    """

    center = set(int(atom_number) for atom_number in center_atoms)
    step_numbers: set[int] = set()

    for atom_number in center:
        atom = route_cgr._atoms.get(atom_number)
        if atom is None:
            continue
        step_numbers.update(int(step) for step in getattr(atom, "route_step_order", ()))
        for step, state in getattr(atom, "route_atom_step_states", {}).items():
            if _atom_has_step_change(state):
                step_numbers.add(int(step))

    for atom_1, atom_2, bond in route_cgr.bonds():
        if atom_1 not in center or atom_2 not in center:
            continue
        if bond.order == bond.p_order:
            continue
        step_numbers.update(int(step) for step in getattr(bond, "route_step_order", ()))
        for step, state in getattr(bond, "route_bond_step_states", {}).items():
            if _bond_has_step_change(state):
                step_numbers.add(int(step))

    return frozenset(step_numbers)


def center_component_context_step_numbers(
    route_cgr: Any,
    center_atoms: Iterable[int],
) -> frozenset[int]:
    """Return selected steps whose recorded states touch a net component."""

    center = set(int(atom_number) for atom_number in center_atoms)
    step_numbers: set[int] = set()
    for atom_number in center:
        atom = route_cgr._atoms.get(atom_number)
        if atom is None:
            continue
        step_numbers.update(int(step) for step in getattr(atom, "route_step_order", ()))
        step_numbers.update(
            int(step) for step in getattr(atom, "route_atom_step_states", {})
        )
    for atom_1, atom_2, bond in route_cgr.bonds():
        if atom_1 not in center and atom_2 not in center:
            continue
        step_numbers.update(int(step) for step in getattr(bond, "route_step_order", ()))
        step_numbers.update(
            int(step) for step in getattr(bond, "route_bond_step_states", {})
        )
    return frozenset(step_numbers)


def compose_gapped_history(
    reaction_smiles: Sequence[str],
) -> ComposedGappedHistory:
    """Compose only selected transformations into a net, provenance-aware RouteCGR."""

    if not reaction_smiles:
        raise ValueError("a gapped history must contain at least one reaction")

    from chython import smiles
    from chython.containers import ReactionContainer

    from route_inspector.routes.synplanner import compose_route_cgr

    reactions = {
        step_number: smiles(value) for step_number, value in enumerate(reaction_smiles)
    }
    result = compose_route_cgr(
        {0: reactions},
        0,
        preserve_transient_bonds=False,
    )
    if not result or result.get("cgr") is None:
        raise ValueError("selected reactions did not produce a RouteCGR")

    route_cgr = result["cgr"]
    components = []
    for atoms in route_cgr.centers_list:
        atom_set = frozenset(int(atom_number) for atom_number in atoms)
        atomic_step_numbers = center_component_step_numbers(route_cgr, atom_set)
        context_step_numbers = center_component_context_step_numbers(
            route_cgr, atom_set
        )
        step_numbers = atomic_step_numbers | context_step_numbers
        components.append(
            GappedCenterComponent(
                atom_set,
                step_numbers,
                atomic_step_numbers,
            )
        )

    return ComposedGappedHistory(
        route_cgr=route_cgr,
        reaction=ReactionContainer.from_cgr(route_cgr),
        components=tuple(components),
    )


def group_center_components_by_step_provenance(
    components: Sequence[GappedCenterComponent],
) -> tuple[GappedCenterComponent, ...]:
    """Reunite centers from one reaction and transitively linked route steps."""

    groups: list[tuple[set[int], set[int], set[int]]] = []
    for component in components:
        matching = [
            index
            for index, (_atoms, _steps, atomic_steps) in enumerate(groups)
            if atomic_steps & set(component.atomic_step_numbers)
        ]
        atoms = set(component.atoms)
        steps = set(component.step_numbers)
        atomic_steps = set(component.atomic_step_numbers)
        for index in reversed(matching):
            prior_atoms, prior_steps, prior_atomic_steps = groups.pop(index)
            atoms.update(prior_atoms)
            steps.update(prior_steps)
            atomic_steps.update(prior_atomic_steps)
        groups.append((atoms, steps, atomic_steps))

        # A merge can create another transitive overlap through a genuine route step.
        changed = True
        while changed:
            changed = False
            current_atoms, current_steps, current_atomic_steps = groups[-1]
            for index in range(len(groups) - 1):
                prior_atoms, prior_steps, prior_atomic_steps = groups[index]
                if current_atomic_steps & prior_atomic_steps:
                    current_atoms.update(prior_atoms)
                    current_steps.update(prior_steps)
                    current_atomic_steps.update(prior_atomic_steps)
                    groups.pop(index)
                    changed = True
                    break

    return tuple(
        GappedCenterComponent(
            frozenset(atoms),
            frozenset(steps),
            frozenset(atomic_steps),
        )
        for atoms, steps, atomic_steps in groups
    )


def history_provenance_payload(
    history: ComposedGappedHistory,
    selected_positions: Sequence[int],
) -> dict[str, Any]:
    """Serialize stable RouteCGR provenance for an occurrence sidecar."""

    position_by_step = {
        step_number: int(position)
        for step_number, position in enumerate(selected_positions, start=1)
    }
    return {
        "net_center_maps": sorted(history.center_atoms),
        "net_center_components": [
            {
                "center_maps": sorted(component.atoms),
                "selected_step_numbers": sorted(component.step_numbers),
                "atomic_selected_step_numbers": sorted(component.atomic_step_numbers),
                "selected_positions": sorted(
                    position_by_step[step]
                    for step in component.step_numbers
                    if step in position_by_step
                ),
            }
            for component in history.components
        ],
        "composed_selected_reaction_smiles": format(history.reaction, "m"),
        "preserve_transient_bonds": False,
    }


RRSEQ_GAP_OCCURRENCE_SCHEMA_VERSION = 3
RRSEQ_GAP_OCCURRENCE_IDENTITY_VERSION = 1
