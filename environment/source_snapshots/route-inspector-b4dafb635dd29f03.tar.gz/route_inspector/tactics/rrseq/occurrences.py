"""Versioned occurrence-level provenance for ``RRseq_cons``.

The aggregate RRseq_cons TSV is intentionally a compact, human-facing summary. It
cannot represent the route/target/branch relationship needed to replay a rule
sequence.  The records in this module are the lossless companion contract used
by replay and composite-rule validation.
"""

from __future__ import annotations

import gzip
import hashlib
import json
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Iterable, Mapping

from route_inspector.rules.occurrences import _path, _validate_source_identifiers

RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION = 3
RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION = 1
_SUPPORTED_RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSIONS = frozenset({1, 2, 3})


def stable_rrseq_cons_occurrence_id(
    *,
    source_identity: str,
    route_id: str,
    reaction_node_paths: Iterable[Iterable[int]],
    start_position: int,
    end_position: int,
) -> str:
    """Return a stable ID for one structural route occurrence.

    Branch indices are deliberately absent: a route-tree prefix can be visited
    by several root-to-leaf branch enumerations while still denoting one source
    occurrence.  Its complete node-path tuple is the structural identity.
    """

    # Keep the original identity payload byte-for-byte stable. Payload schema
    # versions may evolve independently without changing occurrence IDs used by
    # composite validation and downstream joins.
    payload = {
        "schema_version": RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
        "source_identity": str(source_identity),
        "route_id": str(route_id),
        "reaction_node_paths": [list(_path(path)) for path in reaction_node_paths],
        "start_position": int(start_position),
        "end_position": int(end_position),
    }
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")
    return f"rro_{hashlib.sha256(encoded).hexdigest()[:24]}"


@dataclass(frozen=True)
class RRseqConsSourceMatch:
    """How one RRseq_cons step is embedded in its normalized source route."""

    step_index: int
    path_position: int
    reaction_node_path: tuple[int, ...]
    target_molecule_path: tuple[int, ...]
    rule_smarts: str
    reaction_smiles: str
    target_smiles: str
    product_index: int | None
    center_atom_maps: tuple[int, ...] = ()
    query_cgr_key: str = ""
    base_query_cgr_key: str = ""
    base_rule_atom_maps: tuple[int, ...] = ()
    raw_source_record_id: str = ""
    source_record_id: str = ""
    source_document_id: str = ""
    source_id_adapter: str = "raw"
    product_to_target_atom_map: tuple[tuple[int, int], ...] = ()
    continuation_reactant_index: int | None = None
    continuation_molecule_path: tuple[int, ...] | None = None
    continuation_to_next_target_atom_map: tuple[tuple[int, int], ...] = ()

    def __post_init__(self) -> None:
        if self.step_index < 0 or self.path_position < 0:
            raise ValueError("source match positions must be non-negative")
        if not self.reaction_node_path:
            raise ValueError("source match reaction_node_path is required")
        if any(index < 0 for index in self.reaction_node_path):
            raise ValueError("source match reaction_node_path must be non-negative")
        if any(index < 0 for index in self.target_molecule_path):
            raise ValueError("source match target_molecule_path must be non-negative")
        if self.target_molecule_path != self.reaction_node_path[:-1]:
            raise ValueError(
                "source match target_molecule_path must parent reaction_node_path"
            )
        if not self.rule_smarts or not self.reaction_smiles or not self.target_smiles:
            raise ValueError(
                "source match rule_smarts, reaction_smiles, and target_smiles are required"
            )
        if self.product_index is not None and self.product_index < 0:
            raise ValueError("source match product_index must be non-negative")
        if tuple(sorted(set(self.center_atom_maps))) != self.center_atom_maps:
            raise ValueError("source match center_atom_maps must be sorted and unique")
        if tuple(sorted(set(self.base_rule_atom_maps))) != self.base_rule_atom_maps:
            raise ValueError(
                "source match base_rule_atom_maps must be sorted and unique"
            )
        # ``RRseqConsSourceMatch`` is nested inside versioned occurrence records
        # but does not itself carry that version. Schema-v1/v2 records predate
        # ``base_rule_atom_maps``. Validate the relationship when the optional
        # witness is present; the parent occurrence requires it for schema v3.
        if self.base_rule_atom_maps and not set(self.center_atom_maps) <= set(
            self.base_rule_atom_maps
        ):
            raise ValueError(
                "source match center_atom_maps must be a subset of base_rule_atom_maps"
            )
        for field_name, atom_mapping in (
            ("product_to_target_atom_map", self.product_to_target_atom_map),
            (
                "continuation_to_next_target_atom_map",
                self.continuation_to_next_target_atom_map,
            ),
        ):
            if len(atom_mapping) != len(set(atom_mapping)):
                raise ValueError(f"source match {field_name} must contain unique pairs")
            sources = tuple(source for source, _target in atom_mapping)
            targets = tuple(target for _source, target in atom_mapping)
            if len(sources) != len(set(sources)) or len(targets) != len(set(targets)):
                raise ValueError(f"source match {field_name} must be bijective")
        if (
            self.continuation_reactant_index is not None
            and self.continuation_reactant_index < 0
        ):
            raise ValueError("continuation_reactant_index must be non-negative")
        if self.continuation_molecule_path is not None and any(
            index < 0 for index in self.continuation_molecule_path
        ):
            raise ValueError("continuation_molecule_path must be non-negative")
        _validate_source_identifiers(
            raw_source_record_id=self.raw_source_record_id,
            source_record_id=self.source_record_id,
            source_document_id=self.source_document_id,
            source_id_adapter=self.source_id_adapter,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "step_index": self.step_index,
            "path_position": self.path_position,
            "reaction_node_path": list(self.reaction_node_path),
            "target_molecule_path": list(self.target_molecule_path),
            "rule_smarts": self.rule_smarts,
            "reaction_smiles": self.reaction_smiles,
            "target_smiles": self.target_smiles,
            "product_index": self.product_index,
            "center_atom_maps": list(self.center_atom_maps),
            "query_cgr_key": self.query_cgr_key,
            "base_query_cgr_key": self.base_query_cgr_key,
            "base_rule_atom_maps": list(self.base_rule_atom_maps),
            "raw_source_id": self.raw_source_record_id,
            "raw_source_record_id": self.raw_source_record_id,
            "source_record_id": self.source_record_id,
            "source_document_id": self.source_document_id,
            "source_id_adapter": self.source_id_adapter,
            "product_to_target_atom_map": [
                [source, target] for source, target in self.product_to_target_atom_map
            ],
            "continuation_reactant_index": self.continuation_reactant_index,
            "continuation_molecule_path": (
                list(self.continuation_molecule_path)
                if self.continuation_molecule_path is not None
                else None
            ),
            "continuation_to_next_target_atom_map": [
                [source, target]
                for source, target in self.continuation_to_next_target_atom_map
            ],
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RRseqConsSourceMatch":
        if (
            "raw_source_record_id" in value
            and "raw_source_id" in value
            and str(value["raw_source_record_id"]) != str(value["raw_source_id"])
        ):
            raise ValueError("raw source identifier aliases disagree")
        continuation_path = value.get("continuation_molecule_path")
        return cls(
            step_index=int(value["step_index"]),
            path_position=int(value["path_position"]),
            reaction_node_path=_path(value["reaction_node_path"]),
            target_molecule_path=_path(value["target_molecule_path"]),
            rule_smarts=str(value["rule_smarts"]),
            reaction_smiles=str(value["reaction_smiles"]),
            target_smiles=str(value["target_smiles"]),
            product_index=(
                None
                if value.get("product_index") is None
                else int(value["product_index"])
            ),
            center_atom_maps=tuple(
                int(atom_map) for atom_map in value.get("center_atom_maps", ())
            ),
            query_cgr_key=str(value.get("query_cgr_key", "")),
            base_query_cgr_key=str(value.get("base_query_cgr_key", "")),
            base_rule_atom_maps=tuple(
                int(atom_map) for atom_map in value.get("base_rule_atom_maps", ())
            ),
            raw_source_record_id=str(
                value.get("raw_source_record_id") or value.get("raw_source_id") or ""
            ),
            source_record_id=str(value.get("source_record_id", "")),
            source_document_id=str(value.get("source_document_id", "")),
            source_id_adapter=str(value.get("source_id_adapter", "raw")),
            product_to_target_atom_map=tuple(
                (int(source), int(target))
                for source, target in value.get("product_to_target_atom_map", ())
            ),
            continuation_reactant_index=(
                None
                if value.get("continuation_reactant_index") is None
                else int(value["continuation_reactant_index"])
            ),
            continuation_molecule_path=(
                None if continuation_path is None else _path(continuation_path)
            ),
            continuation_to_next_target_atom_map=tuple(
                (int(source), int(target))
                for source, target in value.get(
                    "continuation_to_next_target_atom_map", ()
                )
            ),
        )


@dataclass(frozen=True)
class RRseqConsSourceLeaf:
    """One authoritative boundary precursor from the normalized route slice."""

    mapped_smiles: str
    step_index: int
    path_position: int
    reactant_index: int
    molecule_node_path: tuple[int, ...] | None = None

    def __post_init__(self) -> None:
        if not self.mapped_smiles:
            raise ValueError("source leaf mapped_smiles is required")
        if self.step_index < 0 or self.path_position < 0 or self.reactant_index < 0:
            raise ValueError("source leaf indices must be non-negative")
        if self.molecule_node_path is not None and any(
            index < 0 for index in self.molecule_node_path
        ):
            raise ValueError("source leaf molecule_node_path must be non-negative")

    def to_dict(self) -> dict[str, Any]:
        return {
            "mapped_smiles": self.mapped_smiles,
            "step_index": self.step_index,
            "path_position": self.path_position,
            "reactant_index": self.reactant_index,
            "molecule_node_path": (
                list(self.molecule_node_path)
                if self.molecule_node_path is not None
                else None
            ),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RRseqConsSourceLeaf":
        molecule_path = value.get("molecule_node_path")
        return cls(
            mapped_smiles=str(value["mapped_smiles"]),
            step_index=int(value["step_index"]),
            path_position=int(value["path_position"]),
            reactant_index=int(value["reactant_index"]),
            molecule_node_path=(
                None if molecule_path is None else _path(molecule_path)
            ),
        )


@dataclass(frozen=True)
class RRseqConsOccurrence:
    """One RRseq_cons occurrence tied to exact source-route nodes."""

    occurrence_id: str
    source_identity: str
    route_id: str
    route_target_smiles: str
    segment_target_smiles: str
    root_index: int
    branch_index: int
    branch_indices: tuple[int, ...]
    reaction_node_paths: tuple[tuple[int, ...], ...]
    start_position: int
    end_position: int
    raw_sequence: tuple[str, ...]
    source_matches: tuple[RRseqConsSourceMatch, ...]
    source_route_leaves: tuple[RRseqConsSourceLeaf, ...]
    query_cgr_keys: tuple[str, ...] = ()
    base_query_cgr_keys: tuple[str, ...] = ()
    dataset_id: str = ""
    context_history_ref: str = ""
    route_context_history_id: str = ""
    context_history_projection_id: str = ""
    context_history_reference_schema_version: int = 0
    schema_version: int = RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version not in _SUPPORTED_RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSIONS:
            raise ValueError(
                "unsupported RRseq_cons occurrence schema version: "
                f"{self.schema_version}"
            )
        if self.end_position <= self.start_position:
            raise ValueError(
                "end_position must be exclusive and greater than start_position"
            )
        if (
            self.root_index < 0
            or self.branch_index < 0
            or self.start_position < 0
            or any(index < 0 for index in self.branch_indices)
        ):
            raise ValueError("route and occurrence indices must be non-negative")
        if any(
            not path or any(index < 0 for index in path)
            for path in self.reaction_node_paths
        ):
            raise ValueError("reaction_node_paths must be non-empty and non-negative")
        expected_length = self.end_position - self.start_position
        current_schema = self.schema_version == RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION
        if current_schema and (
            not self.dataset_id
            or not self.source_identity
            or not self.route_id
            or not self.route_target_smiles
            or not self.segment_target_smiles
            or len(self.query_cgr_keys) != expected_length
            or len(self.base_query_cgr_keys) != expected_length
            or any(not key for key in self.query_cgr_keys)
            or any(not key for key in self.base_query_cgr_keys)
        ):
            raise ValueError(
                "current RRseq_cons occurrences require dataset and paired identities"
            )
        if len(self.raw_sequence) != expected_length:
            raise ValueError("raw_sequence length does not match the occurrence bounds")
        if len(self.reaction_node_paths) != expected_length:
            raise ValueError(
                "reaction_node_paths length does not match occurrence bounds"
            )
        if len(self.source_matches) != expected_length:
            raise ValueError("source_matches length does not match occurrence bounds")
        if len(set(self.reaction_node_paths)) != len(self.reaction_node_paths):
            raise ValueError("reaction_node_paths must be unique")
        if self.query_cgr_keys and len(self.query_cgr_keys) != expected_length:
            raise ValueError("query_cgr_keys length does not match occurrence bounds")
        if (
            self.base_query_cgr_keys
            and len(self.base_query_cgr_keys) != expected_length
        ):
            raise ValueError(
                "base_query_cgr_keys length does not match occurrence bounds"
            )
        for step_index, match in enumerate(self.source_matches):
            path_position = self.start_position + step_index
            if match.step_index != step_index:
                raise ValueError(
                    "source_matches step_index does not match sequence order"
                )
            if match.path_position != path_position:
                raise ValueError(
                    "source_matches path_position does not match occurrence bounds"
                )
            if match.reaction_node_path != self.reaction_node_paths[step_index]:
                raise ValueError(
                    "source_matches reaction path differs from reaction_node_paths"
                )
            if match.rule_smarts != self.raw_sequence[step_index]:
                raise ValueError("source_matches rule_smarts differs from raw_sequence")
            if (
                self.query_cgr_keys
                and match.query_cgr_key
                and match.query_cgr_key != self.query_cgr_keys[step_index]
            ):
                raise ValueError(
                    "source_matches query_cgr_key differs from query_cgr_keys"
                )
            if (
                self.base_query_cgr_keys
                and match.base_query_cgr_key
                and match.base_query_cgr_key != self.base_query_cgr_keys[step_index]
            ):
                raise ValueError(
                    "source_matches base_query_cgr_key differs from base_query_cgr_keys"
                )
            if match.base_rule_atom_maps and not set(match.center_atom_maps) <= set(
                match.base_rule_atom_maps
            ):
                raise ValueError(
                    "source match center_atom_maps must be a subset of "
                    "base_rule_atom_maps"
                )
            if current_schema and (
                match.product_index is None
                or not match.product_to_target_atom_map
                or not match.query_cgr_key
                or not match.base_query_cgr_key
                or not match.base_rule_atom_maps
            ):
                raise ValueError(
                    "current source match requires exact identity and product witnesses"
                )
            strict_context = bool(
                self.query_cgr_keys
                and self.base_query_cgr_keys
                and match.query_cgr_key
                and match.base_query_cgr_key
            )
            if strict_context:
                final_step = step_index == expected_length - 1
                if final_step and (
                    match.continuation_reactant_index is not None
                    or match.continuation_molecule_path is not None
                    or match.continuation_to_next_target_atom_map
                ):
                    raise ValueError("final source match cannot contain a continuation")
                if not final_step and (
                    match.continuation_reactant_index is None
                    or match.continuation_molecule_path is None
                    or not match.continuation_to_next_target_atom_map
                ):
                    raise ValueError(
                        "intermediate source match requires a continuation witness"
                    )
                if (
                    not final_step
                    and match.continuation_molecule_path
                    != self.source_matches[step_index + 1].target_molecule_path
                ):
                    raise ValueError(
                        "source match continuation path differs from the next target"
                    )
                if not final_step and (
                    len(match.continuation_molecule_path)
                    != len(match.reaction_node_path) + 1
                    or match.continuation_molecule_path[:-1] != match.reaction_node_path
                ):
                    raise ValueError(
                        "source match continuation leaves the exact route branch"
                    )
        if self.source_matches[0].target_smiles != self.segment_target_smiles:
            raise ValueError(
                "segment_target_smiles differs from the first source match target"
            )
        leaf_keys: set[tuple[int, int]] = set()
        leaf_paths: set[tuple[int, ...]] = set()
        for leaf in self.source_route_leaves:
            if leaf.step_index < 0 or leaf.step_index >= expected_length:
                raise ValueError("source_route_leaves step_index is outside occurrence")
            if leaf.path_position != self.start_position + leaf.step_index:
                raise ValueError(
                    "source_route_leaves path_position does not match step_index"
                )
            leaf_key = (leaf.step_index, leaf.reactant_index)
            if leaf_key in leaf_keys:
                raise ValueError("source_route_leaves contain a duplicate reactant")
            leaf_keys.add(leaf_key)
            source_match = self.source_matches[leaf.step_index]
            if source_match.continuation_reactant_index == leaf.reactant_index:
                raise ValueError(
                    "source leaf cannot duplicate the continuation reactant"
                )
            if current_schema and leaf.molecule_node_path is None:
                raise ValueError(
                    "current source leaf requires its exact molecule node path"
                )
            if leaf.molecule_node_path is not None:
                strict_context = bool(
                    self.query_cgr_keys
                    and self.base_query_cgr_keys
                    and source_match.query_cgr_key
                    and source_match.base_query_cgr_key
                )
                if strict_context and (
                    len(leaf.molecule_node_path)
                    != len(source_match.reaction_node_path) + 1
                    or leaf.molecule_node_path[:-1] != source_match.reaction_node_path
                ):
                    raise ValueError(
                        "source leaf molecule path is not a direct reactant node"
                    )
                if leaf.molecule_node_path in leaf_paths:
                    raise ValueError(
                        "source_route_leaves contain a duplicate node path"
                    )
                leaf_paths.add(leaf.molecule_node_path)
        expected_id = stable_rrseq_cons_occurrence_id(
            source_identity=self.source_identity,
            route_id=self.route_id,
            reaction_node_paths=self.reaction_node_paths,
            start_position=self.start_position,
            end_position=self.end_position,
        )
        if self.occurrence_id != expected_id:
            raise ValueError("occurrence_id does not match occurrence identity fields")
        if not self.branch_indices or self.branch_index not in self.branch_indices:
            raise ValueError("branch_index must be present in branch_indices")
        if tuple(sorted(set(self.branch_indices))) != self.branch_indices:
            raise ValueError("branch_indices must be sorted and unique")
        if self.branch_index != self.branch_indices[0]:
            raise ValueError("branch_index must be the canonical first branch index")
        if (
            self.context_history_ref
            and self.route_context_history_id
            and self.context_history_ref != self.route_context_history_id
        ):
            raise ValueError(
                "context_history_ref and route_context_history_id disagree"
            )

    @property
    def rrseq_cons(self) -> str:
        return "$".join(self.raw_sequence)

    @property
    def rrseq_cons_size(self) -> int:
        """Return the number of elementary rules in this occurrence."""

        return len(self.raw_sequence)

    def with_branch_index(self, branch_index: int) -> "RRseqConsOccurrence":
        branches = tuple(sorted({*self.branch_indices, int(branch_index)}))
        return replace(self, branch_index=branches[0], branch_indices=branches)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "identity_version": RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
            "occurrence_id": self.occurrence_id,
            "source_identity": self.source_identity,
            "dataset_id": self.dataset_id,
            "route_id": self.route_id,
            "route_target_smiles": self.route_target_smiles,
            "segment_target_smiles": self.segment_target_smiles,
            "root_index": self.root_index,
            "branch_index": self.branch_index,
            "branch_indices": list(self.branch_indices),
            "reaction_node_paths": [list(path) for path in self.reaction_node_paths],
            "start_position": self.start_position,
            "end_position": self.end_position,
            "raw_sequence": list(self.raw_sequence),
            "query_cgr_keys": list(self.query_cgr_keys),
            "base_query_cgr_keys": list(self.base_query_cgr_keys),
            "context_history_ref": self.context_history_ref,
            "route_context_history_id": self.route_context_history_id,
            "context_history_projection_id": self.context_history_projection_id,
            "context_history_reference_schema_version": (
                self.context_history_reference_schema_version
            ),
            "RRseq_cons": self.rrseq_cons,
            "rrseq_cons_size": self.rrseq_cons_size,
            "source_matches": [match.to_dict() for match in self.source_matches],
            "source_route_leaves": [
                leaf.to_dict() for leaf in self.source_route_leaves
            ],
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RRseqConsOccurrence":
        version = int(value.get("schema_version", -1))
        if version not in _SUPPORTED_RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSIONS:
            raise ValueError(
                f"unsupported RRseq_cons occurrence schema version: {version}"
            )
        identity_version = int(
            value.get(
                "identity_version",
                RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION,
            )
        )
        if identity_version != RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION:
            raise ValueError(
                "unsupported RRseq_cons occurrence identity version: "
                f"{identity_version}"
            )
        raw_sequence = tuple(str(rule) for rule in value["raw_sequence"])
        serialized_sequence = value.get("RRseq_cons")
        if serialized_sequence is not None and str(serialized_sequence) != "$".join(
            raw_sequence
        ):
            raise ValueError("RRseq_cons differs from raw_sequence")
        serialized_size = value.get("rrseq_cons_size")
        if serialized_size is not None and int(serialized_size) != len(raw_sequence):
            raise ValueError("rrseq_cons_size differs from raw_sequence length")
        occurrence = cls(
            schema_version=version,
            occurrence_id=str(value["occurrence_id"]),
            source_identity=str(value["source_identity"]),
            dataset_id=str(value.get("dataset_id", "")),
            route_id=str(value["route_id"]),
            route_target_smiles=str(value["route_target_smiles"]),
            segment_target_smiles=str(value["segment_target_smiles"]),
            root_index=int(value["root_index"]),
            branch_index=int(value["branch_index"]),
            branch_indices=tuple(int(index) for index in value["branch_indices"]),
            reaction_node_paths=tuple(
                _path(path) for path in value["reaction_node_paths"]
            ),
            start_position=int(value["start_position"]),
            end_position=int(value["end_position"]),
            raw_sequence=raw_sequence,
            query_cgr_keys=tuple(str(key) for key in value.get("query_cgr_keys", ())),
            base_query_cgr_keys=tuple(
                str(key) for key in value.get("base_query_cgr_keys", ())
            ),
            context_history_ref=str(
                value.get("context_history_ref")
                or value.get("route_context_history_id")
                or ""
            ),
            route_context_history_id=str(
                value.get("route_context_history_id")
                or value.get("context_history_ref")
                or ""
            ),
            context_history_projection_id=str(
                value.get("context_history_projection_id") or ""
            ),
            context_history_reference_schema_version=int(
                value.get("context_history_reference_schema_version") or 0
            ),
            source_matches=tuple(
                RRseqConsSourceMatch.from_dict(match)
                for match in value["source_matches"]
            ),
            source_route_leaves=tuple(
                RRseqConsSourceLeaf.from_dict(leaf)
                for leaf in value["source_route_leaves"]
            ),
        )
        if (
            "rrseq_cons_size" in value
            and int(value["rrseq_cons_size"]) != occurrence.rrseq_cons_size
        ):
            raise ValueError("rrseq_cons_size does not match raw_sequence")
        legacy_size = value.get("rrseq_size")
        if legacy_size is not None and int(legacy_size) != occurrence.rrseq_cons_size:
            raise ValueError("rrseq_size does not match raw_sequence")
        sequence_value = value.get("RRseq_cons", value.get("RRseq"))
        if sequence_value is not None and str(sequence_value) != occurrence.rrseq_cons:
            raise ValueError("RRseq_cons does not match raw_sequence")
        return occurrence


def rrseq_cons_occurrence_sidecar_path(output: Path) -> Path:
    """Return the occurrence sidecar path for an RRseq_cons TSV prefix."""

    stem = output.with_suffix("")
    return stem.with_name(f"{stem.name}_rrseq_cons_occurrences.json")


def write_rrseq_cons_occurrences(
    path: Path,
    occurrences: Iterable[RRseqConsOccurrence | Mapping[str, Any]],
) -> Path:
    """Write a deterministic plain-JSON array of exact occurrences."""

    records = [
        occurrence
        if isinstance(occurrence, RRseqConsOccurrence)
        else RRseqConsOccurrence.from_dict(occurrence)
        for occurrence in occurrences
    ]
    records.sort(key=lambda item: item.occurrence_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(
            [occurrence.to_dict() for occurrence in records],
            stream,
            sort_keys=True,
            separators=(",", ":"),
        )
        stream.write("\n")
    return path


def iter_rrseq_cons_occurrences(path: Path) -> Iterable[RRseqConsOccurrence]:
    """Read plain-JSON occurrences or a legacy JSONL/JSONL-gzip sidecar."""

    if path.suffix == ".json":
        with path.open("r", encoding="utf-8") as stream:
            values = json.load(stream)
        if not isinstance(values, list):
            raise ValueError(f"RRseq_cons occurrence JSON must be an array: {path}")
        for record_index, value in enumerate(values):
            try:
                yield RRseqConsOccurrence.from_dict(value)
            except Exception as exc:
                raise ValueError(
                    f"invalid RRseq_cons occurrence at {path}[{record_index}]: {exc}"
                ) from exc
        return

    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            if not line.strip():
                continue
            try:
                yield RRseqConsOccurrence.from_dict(json.loads(line))
            except Exception as exc:
                raise ValueError(
                    f"invalid RRseq_cons occurrence at {path}:{line_number}: {exc}"
                ) from exc


__all__ = [
    "RRSEQ_CONS_OCCURRENCE_SCHEMA_VERSION",
    "RRSEQ_CONS_OCCURRENCE_IDENTITY_VERSION",
    "RRseqConsOccurrence",
    "RRseqConsSourceLeaf",
    "RRseqConsSourceMatch",
    "iter_rrseq_cons_occurrences",
    "rrseq_cons_occurrence_sidecar_path",
    "stable_rrseq_cons_occurrence_id",
    "write_rrseq_cons_occurrences",
]
