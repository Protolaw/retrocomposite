# Route Inspector

Route Inspector builds reusable tactic libraries from Reference synthesis routes
and analyses which patterns in new retrosynthetic routes are known or novel.
It is a SynPlanner/Chython toolkit for PaRoutes-style `mol`/`reaction` trees,
with exact links from each discovered motif to its source occurrence.

## Why use it?

Most retrosynthesis tools focus on individual reaction templates. Route
Inspector asks route-level questions:

- Which **consecutive reaction-center-sharing sequences** (``RRseq_cons``) repeat across a
  route collection?
- Which ``RRseq_cons`` applications collapse into **composite pseudo-reactions**?
- Which chemically connected local tactics persist across unrelated intervening
  chemistry as **gapped sequences** (``RRseq_gap``)?
- Which route motifs span multiple precursor arms as occurrence-provenanced
  **RRSubtrees**, and which retain strict reaction-center continuity?
- Which discovered route fragments overlap a reference route vocabulary?
- Which ordered **Tier-3 reaction-class sequences** generalize distinct RRSeq templates?
- Where are **protecting groups** introduced, inherited from stock, or removed?

<p align="center">
  <img src="docs/assets/route-inspector-demo.svg" alt="Route Inspector workflow: route JSON to RRseq_cons and RRseq_gap motifs, composite rules, SVG unwrapping, scoring, and protection analysis" width="880">
</p>

<p align="center">
  <a href="LICENSE"><img alt="License: MIT" src="https://img.shields.io/badge/License-MIT-yellow.svg"></a>
  <img alt="Python 3.11–3.13" src="https://img.shields.io/badge/python-3.11%E2%80%933.13-blue.svg">
  <img alt="CLI" src="https://img.shields.io/badge/interface-CLI%20%2B%20notebooks-informational.svg">
</p>

## What it does

- **Extract route motifs:** consecutive and gapped RRSeqs, plus branched
  RRSubtrees with selected/skipped-step and precursor-arm provenance.
- **Build reusable Reference libraries:** persist exact motif identities,
  occurrences and reports, with optional SQLite acceleration for indexed reads.
- **Analyse new routes:** compare motifs under the same processing profile,
  report known versus novel tactics, and keep supplementary bigram evidence separate.
- **Inspect chemistry:** visualize source routes and reaction rules, unwrap
  consecutive sequences, and explore replay-certified composite decompositions.
- **Study context and protection:** trace functional groups and protecting-group
  lifecycles, inspect protected intervals, and compare reaction-class sequences.

Gapped sequences and native RRSubtrees are analysis motifs, not executable
reaction templates. Recurrence is corpus precedent—not proof of feasibility,
yield or route quality. Scientific definitions and validation limits are in the
[methods guides](docs/methods/index.rst).

## Installation

Route Inspector supports Python 3.11--3.13 and pins SynPlanner's tested 1.8
development snapshot at `7a8287dc452ff2f09afca84673bfa0322196c1b9`.
`pip install .` installs that revision automatically; Git and access to GitHub
are required. SynPlanner 1.6 and 1.7 are no longer supported because they lack
the route drawing backend. Route Inspector releases are distributed as Git tags
rather than through PyPI. From a reviewed checkout or tag:

```bash
conda activate synplan
python -m pip install .
route-inspector --version
route-inspector --help
```

For development, use an editable installation so notebooks and commands import
the same package:

```bash
python -m pip install -e ".[dev,notebooks]"
python -m route_inspector.cli --help
```

## Build once, analyse routes

Build a versioned library from a preprocessed Reference corpus:

```bash
route-inspector build-reference-library \
  --routes-json data/clean/n1_routes.json \
  --output-dir outputs/reference_libraries/n1 \
  --reference-id paroutes-n1 \
  --config route_inspector/configs/rule_extraction_functional_groups.yaml
```

Built-in defaults live only in `route_inspector/configs/`. These paths resolve
to the installed package outside a checkout too. To customize a profile, copy
its YAML to a separate file and pass that file with `--config`. The historical
`configs/...` spelling remains a compatibility alias; there is no root-level
configuration directory.
Portable JSONL is the complete library backend. The default build also includes
an indexed SQLite accelerator for lazy provenance reads; pass
`--no-sqlite-catalog` when a database-free artifact is preferred.
It also records exact Retro-BLEU-like rule bigrams as supplementary evidence;
pass `--no-retro-bleu-bigrams` for a tactic-only library.

Before accepting a newly built or imported library, fully verify its persisted
output:

```bash
route-inspector verify-reference-library \
  --library outputs/reference_libraries/n1
```

Keep that verified version unchanged; publish updates as a new library version.
Then analyse one route, a route collection, or one selected route from a
collection without reprocessing the Reference corpus:

```bash
route-inspector assess-route \
  --route data/generated/model_routes.json \
  --route-id 0 \
  --library outputs/reference_libraries/n1 \
  --output-dir outputs/generated/64_route_assessment/route-0 \
  --config route_inspector/configs/rule_extraction_functional_groups.yaml
```

Assessment defaults to `--verification fast`: it trusts a previously verified,
unchanged library and skips whole-file hashes on the lazy SQLite path. It does
not guarantee detection of subsequent same-size edits or corruption. Use
`--verification full` to audit the library before assessment, particularly after
copying, importing or modifying it. Both modes retain exact candidate matching;
fast never means matching by the lookup key alone. The requested policy is
recorded in assessment `summary.json`. See the
[trusted-fast contract](docs/reference_library/index.rst).

Build and assessment use the same preprocessing, mapping validation, rule extraction,
and four-kind motif processor. Assessment fails on an incompatible scientific
configuration. It reports occurrence-level and unique-identity coverage as
``fully_covered``, ``partially_novel``, ``tactic_novel``,
``no_extracted_tactics``, or ``assessment_incomplete``. The no-tactic status
means only that the current RRSeq/RRSubtree definitions extracted nothing; it
does not mean that the route contains no synthetic tactic.
Separately, each ordered parent-to-child rule bigram is compared with all
Reference routes and with the Reference routes containing neither RRSeq kind.
This supplementary local structural familiarity never changes the tactic status
or its denominator. It is not a Retro-BLEU score, an executability test, or a
feasibility estimate.

### Optional components

- **Protecting-group strategy:** add PG lifecycles and protected-interval
  evidence without changing tactic status. See the
  [PG-strategy guide](docs/pg_library/pg_strategy.rst) and
  [PG tutorials](tutorials/pg/README.md).
- **Certified composite decompositions:** build a companion catalog for
  replay-validated branched reverse expansion. See the
  [composite-rule guide](docs/methods/composite_rules.rst).
- **Standalone extraction and context indexing:** use the
  [advanced workflow examples](docs/workflows/extraction_examples.md) when
  individual stages, detailed diagnostics or an occurrence-level evidence index
  are needed.

Keep source data under `data/` and generated artifacts under `outputs/`.
Inspect each stage's `summary.json`, diagnostics and manifest before accepting
its results. PaRoutes preprocessing propagates recorded atom maps; it does not
run a neural atom mapper. See the
[preprocessing guide](docs/workflows/preprocessing.rst) for that contract.

## Local graphical interface

Explore an existing library **route-wise** (route → its tactic occurrences),
**tactic-wise** (tactic type → entry → source routes), or **composite-wise**
(certified net rule → original decompositions → source occurrences):

```bash
python -m pip install -e ".[gui]"
route-inspector gui --workspace . --port 8080
```

Alternatively, build the shared CLI/GUI Docker image from this checkout:

```bash
export RI_UID="$(id -u)" RI_GID="$(id -g)"
mkdir -p data outputs
docker compose build
docker compose up -d gui
docker compose run --rm cli --help
```

On a fresh workspace, the `prepare-data` service downloads and verifies the
pinned n1/n5 bundles before the GUI starts. Existing compatible datasets are
preserved; preprocessing and library construction are not repeated. Private
release downloads require the token-file setup in
[Docker setup](docs/getting_started/docker.rst). Set `RI_PREPARED_DATASETS=none`
to use only your own prepared data. Docker Desktop's GUI port link automatically
redirects to HTTPS through a localhost-only gateway.

Open `https://localhost:8080`. Choose **n1** or **n5**; the GUI automatically finds
`data/clean/<dataset>_routes.json` and `outputs/reference_libraries/<dataset>`,
verifies them, then offers the browsing modes. Composite-wise additionally needs
the matching companion in `outputs/composite_libraries/<dataset>`; its absence
does not prevent route-wise or tactic-wise browsing. No file paths are needed on
the opening screen. Missing libraries are reported, not built automatically.

For remote work, forward port 8080 through SSH or VS Code. HTTPS alone does not
make a remote localhost reachable. The default local certificate is self-signed:
verify the fingerprint printed in the terminal before approving the browser
warning, or supply a trusted certificate. The GUI can also analyse one prepared
query route at a time; it never rebuilds libraries or edits chemistry. See the
[GUI guide](docs/getting_started/gui.rst) for certificate setup and remote access.

## Documentation

The documentation is organized by audience and task:

- [Getting started](docs/getting_started/index.rst): installation, quick start,
  and the notebook map.
- [Workflows](docs/workflows/index.rst): data preparation and complete analyses.
- [Advanced extraction workflows](docs/workflows/extraction_examples.md):
  standalone extraction, context indexing, command outputs and folder layout.
- [Complete n1 pipeline](docs/workflows/n1_pipeline.rst): the end-to-end stage recipe.
- [Reference libraries](docs/reference_library/index.rst): construction,
  persistence, verification, assessment, and protecting-group evidence.
- [Scientific methods](docs/methods/index.rst): definitions, provenance,
  limitations, and interpretation.
- [Stable Python API](docs/api/index.rst): curated v1 interfaces and
  compatibility boundary.
- [Development](docs/development/index.rst): versioning, validation, and release
  policy.

Interactive examples follow the [Reference-library tutorial sequence](tutorials/README.md).
Start with [building the n1 motif library](tutorials/01_n1_build_reference_library.ipynb).
Protecting-group examples have their own [PG tutorial guide](tutorials/pg/README.md).
Retired standalone-stage notebooks remain available in Git history.

## AI-assisted workflows

Reusable project workflows are provided as Agent Skills:

- [`preprocess-paroutes`](skills/preprocess-paroutes/SKILL.md)
- [`run-rrseq-pipeline`](skills/run-rrseq-pipeline/SKILL.md)
- [`analyze-protection`](skills/analyze-protection/SKILL.md)
- [`run-pg-recovery`](skills/run-pg-recovery/SKILL.md)
- [`diagnose-gui-performance`](skills/diagnose-gui-performance/SKILL.md)
- [`audit-generated-artifacts`](skills/audit-generated-artifacts/SKILL.md)
- [`validate-composite-rules`](skills/validate-composite-rules/SKILL.md)
- [`release-route-inspector`](skills/release-route-inspector/SKILL.md)

Codex discovers these skills through `.agents/skills/`, while Claude Code uses
`.claude/skills/`. Both discovery trees point to the authoritative instructions
under `skills/`. Repository-wide conventions are defined in [`AGENTS.md`](AGENTS.md)
and [`CLAUDE.md`](CLAUDE.md).

## Licensing and optional dependencies

Route Inspector is MIT licensed. The isolated Chython functional-group source
snapshot under [`route_inspector/context/vendor/chython`](route_inspector/context/vendor/chython)
remains LGPL-3.0-or-later. It is vendored unmodified at a pinned upstream commit;
the adjacent [`NOTICE.md`](route_inspector/context/vendor/chython/NOTICE.md) records
the source and license hashes and adapter modification history, and
[`COPYING.LESSER`](route_inspector/context/vendor/chython/COPYING.LESSER) contains
the license text. The adapter uses the installed `chython-synplan` runtime and
does not install a second Chython distribution.

ReactionClassifier support is optional and imported only by the reaction-class
stage. Install it with `python -m pip install -e ".[rxnclass]"`, or pass a local
checkout with `--reaction-classifier-path`. NameRXN is an alternate backend but
requires its separately licensed proprietary executable; `--namerxn-path`
accepts either a HazELNut root or its compiled `build/namerxn` binary.
