"""A finished search as data: the node graph, the winning ids, the statistics.

The record says what happened; it cannot resume a search. The policy network,
the reaction rules and the evaluation function are machinery, not data, and the
building-block catalogue belongs to the run's configuration -- it is referenced
by name there, never embedded here.
"""

from __future__ import annotations

import gzip
import json
from dataclasses import dataclass, field
from os import PathLike
from pathlib import Path
from typing import TYPE_CHECKING

from synplan.chem.precursor import Precursor
from synplan.chem.stereo import parse_smiles_preserving_stereo as read_smiles
from synplan.chem.utils import in_atom_order, molecule_key
from synplan.mcts.config import TreeConfig
from synplan.mcts.node import Node
from synplan.mcts.tree import Tree

if TYPE_CHECKING:
    from chython.containers import MoleculeContainer

__all__ = [
    "SEARCH_RECORD_SCHEMA",
    "SearchRecord",
    "read_search_record",
    "write_search_record",
]

#: Versioned identifier for the search-record file. Bump when the shape changes.
SEARCH_RECORD_SCHEMA = "synplan-tree/3"


@dataclass
class SearchRecord:
    """A search read back from a file: its nodes, its routes, its statistics.

    Not a :class:`~synplan.mcts.tree.Tree` -- it has no policy, no rules and no
    evaluator, so it cannot search. It answers the questions that need only the
    node graph, and :meth:`routes` rebuilds the routes the search found.

    :param target: The molecule the search was run on.
    :param nodes: The search's nodes, by id, as the search left them.
    :param stats: ``to_stats_dict()`` plus ``branching_profile`` and
        ``routes_found_at`` -- the counters the node graph cannot recompute.
        :meth:`winning_rule_ranks` is recomputed, not stored.
    """

    target: MoleculeContainer
    nodes: dict[int, Node]
    parents: dict[int, int]
    children: dict[int, set[int]]
    winning_nodes: list[int]
    stats: dict
    config: TreeConfig = field(default_factory=TreeConfig)
    original_target: MoleculeContainer | None = None

    # The Tree readouts that touch nodes and parents only, bound from the real
    # class: a record has to answer them exactly as the search did.
    route_node_ids = Tree.route_node_ids
    route_steps = Tree.route_steps
    route_to_node = Tree.route_to_node
    route_score = Tree.route_score
    route_log_likelihood = Tree.route_log_likelihood
    route_details = Tree.route_details
    step_metadata = Tree.step_metadata
    synthesis_route = Tree.synthesis_route
    winning_rule_ranks = Tree.winning_rule_ranks
    routes = Tree.routes

    def __len__(self) -> int:
        return len(self.nodes)

    def __repr__(self) -> str:
        return (
            f"<SearchRecord {self.target}: {len(self.nodes)} nodes, "
            f"{len(self.winning_nodes)} routes>"
        )

    @property
    def proposal_nodes(self):
        return [
            n
            for n, node in self.nodes.items()
            if node.is_terminal() and not node.is_solved()
        ]


def _open(file_path: str | PathLike[str], mode: str):
    """``.gz`` writes and reads itself; anything else is plain text."""

    opener = gzip.open if str(file_path).endswith(".gz") else open
    return opener(file_path, mode, encoding="utf-8")


def _counters(tree: Tree | SearchRecord) -> dict:
    """The statistics the node graph cannot recompute, from a search or a record."""

    if isinstance(tree, SearchRecord):
        return tree.stats
    return {
        # winning_rule_ranks is a third of the file and every number in it is on
        # the nodes, so it is recomputed rather than stored
        **tree.to_stats_dict(),
        "branching_profile": tree.branching_profile(),
        "routes_found_at": tree.stats.routes_found_at,
    }


def write_search_record(
    tree: Tree | SearchRecord, file_path: str | PathLike[str]
) -> Path:
    """Write a search as a record, gzipped when the path ends in ``.gz``.

    The routes are not written: a route is a path through the node graph, so
    :meth:`SearchRecord.routes` rebuilds them from the nodes rather than the
    file carrying a second copy of them. Node values are written unrounded, so
    the record scores a route with the number the search scored it with.

    Molecules are written mapped. Atom numbers are what say which reactant atom
    became which product atom, and a route that lost them would write reactions
    whose reactants collide on the same numbers into the public v1 file.

    :param tree: A finished :class:`~synplan.mcts.tree.Tree`, or a
        :class:`SearchRecord` read back from a file.
    :return: The path written.
    """

    molecules: dict[str, int] = {}

    def index(precursor: Precursor) -> int:
        key = format(in_atom_order(precursor.molecule), "m")
        return molecules.setdefault(key, len(molecules))

    nodes = [
        {
            "id": node_id,
            "parent": tree.parents[node_id],
            "depth": node.depth,
            "visits": node.visit,
            "value": node.total_value,
            "init": node.init_value,
            "prob": node.prob,
            "policy_probability": node.policy_probability,
            "rule": node.rule_key,
            "rank": node.policy_rank,
            "new": [index(precursor) for precursor in node.new_precursors],
            # the unexpanded precursors: the first is the one the node was
            # expanding, an empty list is a solved node, and the whole list is
            # the route's unresolved leaves
            "expand": [index(precursor) for precursor in node.precursors_to_expand],
            "stereo_local": list(node.stereo_obligations.local)
            if not tree.parents[node_id]
            or node.stereo_obligations
            is not tree.nodes[tree.parents[node_id]].stereo_obligations
            else [],
            "stereo_events": list(node.stereo_events),
            "stereo_evidence": list(node.stereo_evidence),
            "stereo_history": node.stereo_history,
            "stereo_summary": getattr(node, "stereo_summary", None),
            "selected_stock": [
                p.molecule.meta.get("selected_stock") for p in node.new_precursors
            ],
            "assumed_trivial": [
                p.molecule.meta.get("assumed_trivial") for p in node.new_precursors
            ],
            "reconstructed": node.reconstructed_route.to_json()
            if hasattr(node, "reconstructed_route")
            else None,
        }
        for node_id, node in sorted(tree.nodes.items())
    ]
    record = {
        "schema": SEARCH_RECORD_SCHEMA,
        "target": molecule_key(tree.nodes[1].curr_precursor.molecule),
        "molecules": list(molecules),
        "nodes": nodes,
        "winning": list(tree.winning_nodes),
        "stats": _counters(tree),
    }
    if tree.config.stereo_mode == "off":
        record.update(stereo_mode="off", original_target=str(tree.original_target))
    with _open(file_path, "wt") as file:
        json.dump(record, file)
    return Path(file_path)


def _rule(key: str | None) -> tuple[str | None, int | None]:
    """``rule_source`` and ``rule_id`` back out of a ``rule_key``."""

    source, _, rule_id = (key or "").rpartition(":")
    if not source:
        return None, None
    return source, int(rule_id)


def read_search_record(file_path: str | PathLike[str]) -> SearchRecord:
    """Read a search record back into nodes its routes can be rebuilt from.

    Molecules are interned in the file, but each occurrence comes back as its
    own object: a route is held together by which molecule *object* a step makes
    and the next one consumes, and a convergent route makes the same molecule
    twice.

    :raises ValueError: if the file is not a search record this version reads,
        or a node claims a precursor no ancestor of it produced.
    """

    with _open(file_path, "rt") as file:
        raw = json.load(file)
    if raw.get("schema") not in {
        "synplan-tree/1",
        "synplan-tree/2",
        SEARCH_RECORD_SCHEMA,
    }:
        raise ValueError(
            f"{file_path} is {raw.get('schema')!r}, not a {SEARCH_RECORD_SCHEMA} "
            "search record"
        )

    molecules = [read_smiles(smiles) for smiles in raw["molecules"]]
    nodes: dict[int, Node] = {}
    parents: dict[int, int] = {}
    children: dict[int, set[int]] = {}
    unexpanded: dict[int, tuple[int, ...]] = {}

    for entry in raw["nodes"]:  # a node is always written after its parent
        node_id, parent_id = entry["id"], entry["parent"]
        new = tuple(
            Precursor(molecules[i].copy(), canonicalize=False) for i in entry["new"]
        )
        for precursor, selected in zip(new, entry.get("selected_stock", ())):
            if selected:
                precursor.molecule.meta["selected_stock"] = selected
                precursor.selected_stock = selected
        for precursor, cutoff in zip(new, entry.get("assumed_trivial", ())):
            if cutoff:
                precursor.molecule.meta["assumed_trivial"] = cutoff
        # what this node could still have to expand: what its parent handed on,
        # then what this node itself made
        pool = list(zip(entry["new"], new))
        if parent_id:
            leftover = zip(unexpanded[parent_id][1:], nodes[parent_id].next_precursor)
            pool = [*leftover, *pool]
        expand = []
        for wanted in entry["expand"]:
            # take the first unclaimed precursor spelling it: which occurrence of
            # two equal ones is which is not written down, and swapping them
            # swaps interchangeable subtrees
            slot = next((s for s, (i, _) in enumerate(pool) if i == wanted), None)
            if slot is None:
                raise ValueError(
                    f"node {node_id} has {raw['molecules'][wanted]} to expand, but "
                    "no ancestor of it produced that molecule"
                )
            expand.append(pool.pop(slot)[1])

        rule_source, rule_id = _rule(entry["rule"])
        from synplan.chem.stereo import StereoObligations

        obligations = (
            nodes[parent_id].stereo_obligations if parent_id else StereoObligations()
        )
        nodes[node_id] = Node(
            precursors_to_expand=tuple(expand),
            new_precursors=new,
            visit=entry["visits"],
            depth=entry["depth"],
            prob=entry["prob"],
            init_value=entry["init"],
            total_value=entry["value"],
            rule_id=rule_id,
            rule_source=rule_source,
            rule_key=entry["rule"],
            policy_rank=entry["rank"],
            policy_probability=entry.get("policy_probability"),
            stereo_obligations=obligations.extend(entry.get("stereo_local", ())),
            stereo_events=entry.get("stereo_events", ()),
            stereo_evidence=entry.get("stereo_evidence", ()),
            stereo_history=entry.get("stereo_history", ""),
        )
        if entry.get("stereo_summary"):
            nodes[node_id].stereo_summary = entry["stereo_summary"]
        if entry.get("reconstructed"):
            from synplan.chem.reaction.routes.route import Route

            nodes[node_id].reconstructed_route = Route.from_json(entry["reconstructed"])
        parents[node_id] = parent_id
        unexpanded[node_id] = tuple(entry["expand"])
        children.setdefault(node_id, set())
        if parent_id:
            children.setdefault(parent_id, set()).add(node_id)

    stats = dict(raw["stats"])
    # JSON has no int keys and no tuples; the search's statistics have both
    stats["branching_profile"] = {
        int(depth): profile for depth, profile in stats["branching_profile"].items()
    }
    stats["routes_found_at"] = [tuple(found) for found in stats["routes_found_at"]]
    return SearchRecord(
        target=nodes[1].curr_precursor.molecule,
        nodes=nodes,
        parents=parents,
        children=children,
        winning_nodes=list(raw["winning"]),
        stats=stats,
        config=TreeConfig(stereo_mode=raw.get("stereo_mode", "proposal")),
        original_target=read_smiles(raw.get("original_target", raw["target"])),
    )
