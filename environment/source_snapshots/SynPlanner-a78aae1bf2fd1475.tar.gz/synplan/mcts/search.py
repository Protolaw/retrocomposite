"""Module containing functions for running tree search for the set of target
molecules."""

import csv
import gzip
import json
import logging
import os.path
from collections.abc import Iterator, Mapping
from pathlib import Path

from chython import smiles
from chython.containers import MoleculeContainer
from tqdm.auto import tqdm

from synplan import __version__
from synplan.chem.precursor import is_purchasable
from synplan.chem.reaction import CanonicalRetroReactor
from synplan.chem.reaction.routes.io import (
    make_json,
    write_routes_csv,
    write_routes_json,
)
from synplan.chem.reaction.routes.quality.scorer import RouteScorer
from synplan.chem.reaction.routes.representation import extract_reactions
from synplan.chem.utils import mol_from_smiles
from synplan.mcts.config import CombinedPolicyConfig
from synplan.mcts.tree import Tree, TreeConfig
from synplan.ml.config import PolicyNetworkConfig
from synplan.utils.files import iter_csv_smiles, iter_smiles_records
from synplan.utils.loading import (
    load_building_blocks,
    load_combined_policy_function,
    load_evaluation_function,
    load_policy_function,
    load_reaction_rules,
)
from synplan.utils.visualisation import extract_routes, routes_report_html

#: Versioned identifier for the public route-export contract emitted by
#: :func:`export_routes_artifact`. Bump when the envelope/manifest shape changes.
ROUTE_EXPORT_SCHEMA_VERSION = "synplan-routes/2"


def _canonical_target_key(smiles: str) -> str:
    """Chython canonical stereo-preserving key (route export schema 2)."""
    try:
        return str(mol_from_smiles(smiles, clean2d=False))
    except ValueError:
        logging.warning(
            "Could not Chython-canonicalize target SMILES %r for route export; "
            "keying by the raw string.",
            smiles,
        )
        return smiles


def _iter_target_smiles(targets_path: str) -> Iterator[str]:
    """Yield target SMILES from a targets file.

    Supports plain SMILES-per-line files and tabular ``.tsv``/``.csv`` files
    with a SMILES column (read via :func:`iter_csv_smiles`).
    """
    suffix = Path(targets_path).suffix.lower()
    if suffix in (".tsv", ".csv"):
        delimiter = "\t" if suffix == ".tsv" else ","
        yield from iter_csv_smiles(targets_path, delimiter=delimiter)
        return
    yield from iter_smiles_records(targets_path)


def extract_tree_stats(
    tree: Tree, target: str | MoleculeContainer, init_smiles: str | None = None
):
    """Collects various statistics from a tree and returns them in a dictionary format.

    :param tree: The built search tree.
    :param target: The target molecule associated with the tree.
    :param init_smiles: initial SMILES of the molecule, optional.
    :return: A dictionary with the calculated statistics.
    """

    newick_tree, newick_meta = tree.newickify(visits_threshold=0)
    newick_meta_line = ";".join(
        [f"{nid},{v[0]},{v[1]},{v[2]}" for nid, v in newick_meta.items()]
    )

    stats = tree.to_stats_dict()
    stats["target_smiles"] = init_smiles if init_smiles is not None else str(target)
    stats["newick_tree"] = newick_tree
    stats["newick_meta"] = newick_meta_line
    return stats


def build_target_routes(tree, reactions: dict | None = None) -> list[dict]:
    """Public per-target route shape for the route-export contract.

    Returns the list of route-tree dicts for one solved target. Each route tree
    is a recursive bipartite structure of ``{"type": "mol", ...}`` and
    ``{"type": "reaction", ...}`` nodes whose format is exactly the output of
    :func:`synplan.chem.reaction.routes.io.make_json` (node shape is not
    reshaped). Returns ``[]`` when the tree has no winning nodes.

    :param tree: A completed :class:`~synplan.mcts.tree.Tree`.
    :param reactions: Optional precomputed ``extract_reactions(tree)`` result to
        avoid a second tree traversal. When ``None`` it is computed here.
    """
    if not bool(tree.winning_nodes):
        return []
    if reactions is None:
        reactions = extract_reactions(tree)
    return list(
        make_json(
            reactions,
            keep_ids=True,
            building_blocks=tree.building_blocks,
        ).values()
    )


def export_routes_artifact(
    results: dict,
    results_root,
    *,
    filename: str = "results.json.gz",
) -> Path:
    """Write the target-keyed route-export artifact (public contract).

    Gzip-writes ``results`` as JSON to ``results_root/filename``. ``results`` is
    the public envelope: a top-level dict keyed by the Chython-canonical target
    SMILES (see
    :func:`_canonical_target_key`) mapping to ``[route_tree, ...]`` with ``[]``
    for unsolved targets, where each ``route_tree`` is a
    :func:`build_target_routes` / ``make_json`` node tree.

    Also writes ``results_root/manifest.json`` with a top-level ``directives``
    dict (``{"adapter": "synplanner", "raw_results_filename": filename}``) plus
    top-level ``schema_version`` and ``synplan_version`` keys.

    :return: Path to the written gzipped results file.
    """
    results_root = Path(results_root)
    results_root.mkdir(parents=True, exist_ok=True)

    results_path = results_root.joinpath(filename)
    with gzip.open(results_path, "wt", encoding="utf-8") as fh:
        json.dump(results, fh)

    manifest = {
        "schema_version": ROUTE_EXPORT_SCHEMA_VERSION,
        "target_key_backend": "chython_canonical_stereo_smiles",
        "stereo_schema": 1,
        "synplan_version": __version__,
        "directives": {
            "adapter": "synplanner",
            "raw_results_filename": filename,
        },
    }
    with open(results_root.joinpath("manifest.json"), "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2)

    return results_path


def run_search(
    targets_path: str,
    search_config: dict,
    policy_config: PolicyNetworkConfig,
    evaluation_config,
    reaction_rules_path: str,
    building_blocks_path: str,
    results_root: str = "search_results",
    route_scorer: RouteScorer | None = None,
    priority_rules: dict[str, list[CanonicalRetroReactor]] | None = None,
    reconcile_atom_mapping: bool = False,
    export_routes: bool = False,
    routes_filename: str = "results.json.gz",
) -> None:
    """Performs a tree search on a set of target molecules using specified configuration
    and reaction rules, logging the results and statistics.

    :param targets_path: The path to the file containing the target molecules (in SDF or
        SMILES format).
    :param search_config: The config object containing the configuration for the tree
        search.
    :param policy_config: The config object containing the configuration for the policy.
    :param evaluation_config: The evaluation configuration object (e.g., RolloutEvaluationConfig).
    :param reaction_rules_path: The path to the file containing reaction rules.
    :param building_blocks_path: The path to the file containing building blocks.
    :param results_root: The name of the folder where the results of the tree search
        will be saved.
    :param route_scorer: Optional post-search route scorer (e.g.
        ProtectionRouteScorer). When given, the routes on each target's HTML
        report come back in its order instead of search order.
    :param priority_rules: Optional mapping of curated rule sets
        (``{set_name: [Reactor, ...]}``) forwarded to every per-target
        :class:`Tree`. See :meth:`Tree.__init__` for the full semantics.
        When supplied, set ``search_config["use_priority"] = True`` (or pass
        a :class:`TreeConfig` with ``use_priority=True``); otherwise the rules
        are accepted but never tried.
    :param reconcile_atom_mapping: If False (default), build the exported
        routes_dict directly from the tree (fast path, per-step-local atom
        numbering). If True, use the slower ``compose_route_cgr`` path to give
        cross-step-reconciled atom-map numbering in the exported reactions.
    :param export_routes: When True, additionally emit the public route-export
        artifact (``routes_filename`` + ``manifest.json``) keyed by the
        Chython-canonical target SMILES (
        ``[]`` for unsolved targets), for downstream consumers. Defaults to
        False, leaving the existing outputs byte-identical.
    :param routes_filename: Filename (under ``results_root``) for the gzipped
        target-keyed routes artifact. Only used when ``export_routes`` is True.
    :return: None.
    """

    # results folder
    results_root = Path(results_root)
    results_root.mkdir(parents=True, exist_ok=True)

    # output files
    stats_file = results_root.joinpath("tree_search_stats.csv")
    routes_file = results_root.joinpath("extracted_routes.json")
    routes_folder = results_root.joinpath("extracted_routes_html")
    routes_folder.mkdir(exist_ok=True)

    # stats header
    stats_header = [
        "target_smiles",
        "target_in_stock",
        "num_routes",
        "num_nodes",
        "num_iter",
        "tree_depth",
        "search_time",
        "solved",
        # Policy performance
        "expansion_calls",
        "expansion_successes",
        "unique_expanded_molecules",
        "unique_expanded_states",
        "iterations_without_expansion",
        "root_disconnections",
        "solved_root_disconnections",
        "total_rules_tried",
        "total_rules_succeeded",
        "rule_applicability_rate",
        "dead_end_nodes",
        "stereo_proposals",
        "stereo_incompatible_outcomes",
        "stereo_unresolved_outcomes",
        "stereo_incomplete_assessments",
        # Search dynamics
        "first_solution_iteration",
        "first_solution_time",
        # Tree shape
        "max_branching_factor",
        "mean_branching_factor",
        # Route quality
        "best_route_score",
        "mean_winning_rule_rank",
        # Tree structure
        "newick_tree",
        "newick_meta",
        "error",
        # Priority rules
        "fraction_routes_with_priority",
        "n_routes_with_priority",
        "per_priority_source",
        "priority_rules_tried",
        "policy_rules_tried",
        "priority_rules_succeeded",
        "policy_rules_succeeded",
    ]

    # Load resources
    if isinstance(policy_config, CombinedPolicyConfig):
        policy_function = load_combined_policy_function(combined_config=policy_config)
    else:
        policy_function = load_policy_function(policy_config=policy_config)
    reaction_rules = load_reaction_rules(reaction_rules_path)
    building_blocks = load_building_blocks(building_blocks_path, standardize=False)
    is_json_catalogue = isinstance(building_blocks, Mapping)

    # Create evaluation strategy from config
    evaluation_function = load_evaluation_function(evaluation_config)

    # run search
    n_solved = 0
    extracted_routes = []
    # Public route-export accumulator keyed by Chython-canonical target SMILES:
    # {canonical_target_smiles: [route_tree, ...]}.
    exported_routes: dict[str, list[dict]] = {}
    # CLI runs may contain many targets whose per-tree node IDs overlap, so the
    # sidecar is target-keyed before it is route-node-keyed.
    route_costs: dict[str, dict[str, dict]] = {}
    n_in_stock = 0

    tree_config = TreeConfig.from_dict(search_config)
    tree_config.silent = True
    if tree_config.stereo_mode == "off" and not is_json_catalogue:
        building_blocks = frozenset(
            str(smiles(s, ignore_stereo=True)) for s in building_blocks
        )
    with open(stats_file, "w", encoding="utf-8", newline="\n") as csvfile:
        statswriter = csv.DictWriter(csvfile, delimiter=",", fieldnames=stats_header)
        statswriter.writeheader()

        for ti, target_smi in tqdm(
            enumerate(_iter_target_smiles(targets_path)),
            leave=True,
            desc="Number of target molecules processed: ",
            bar_format="{desc}{n} [{elapsed}]",
        ):
            target_smi = target_smi.strip()
            if is_json_catalogue:
                route_costs[target_smi] = {}
            # Key the export dict by the Chython-canonical target SMILES so keys
            # match the canonicalizer recorded in the manifest. Every target starts
            # empty; only a solved one overwrites it.
            export_key = None
            if export_routes:
                export_key = _canonical_target_key(target_smi)
                exported_routes[export_key] = []
            try:
                target_mol = mol_from_smiles(target_smi, clean_stereo=False)
                if is_purchasable(
                    target_mol,
                    building_blocks,
                    match_stereo=tree_config.stereo_mode != "off",
                ):
                    n_in_stock += 1
                    tqdm.write(
                        f"{target_smi} is already in the building blocks - "
                        + (
                            "connectivity match only; stereo was not assessed"
                            if tree_config.stereo_mode == "off"
                            else "no search run, buy it instead"
                        )
                    )
                    row = dict.fromkeys(stats_header, "")
                    row["target_smiles"] = target_smi
                    row["target_in_stock"] = True
                    row["num_routes"] = 0
                    row["solved"] = False
                    statswriter.writerow(row)
                    csvfile.flush()
                    continue
                # run search
                tree = Tree(
                    target=target_mol,
                    config=tree_config,
                    reaction_rules=reaction_rules,
                    building_blocks=building_blocks,
                    expansion_function=policy_function,
                    evaluation_function=evaluation_function,
                    priority_rules=priority_rules,
                )

                tree.run()

            except Exception as e:
                extracted_routes.append(
                    [
                        {
                            "type": "mol",
                            "smiles": target_smi,
                            "in_stock": False,
                            "children": [],
                        }
                    ]
                )
                logging.warning(
                    f"Retrosynthetic_planning {target_smi} failed with the following error: {e}"
                )

                continue

            # is solved
            n_solved += bool(tree.winning_nodes)
            if bool(tree.winning_nodes):
                # extract routes
                extracted_routes.append(extract_routes(tree))

                # save routes
                routes = tree.routes()
                if route_scorer is not None:
                    routes = route_scorer.rank(routes)
                if is_json_catalogue:
                    route_costs[target_smi] = {
                        str(route.provenance.tree_node_id): route.calculate_cost(
                            building_blocks
                        )
                        for route in routes
                    }
                routes_report_html(
                    routes,
                    os.path.join(routes_folder, f"retroroutes_target_{ti}.html"),
                    stats=tree.to_stats_dict(),
                    building_blocks=building_blocks,
                )

                # save json routes
                with open(routes_file, "w", encoding="utf-8") as f:
                    json.dump(extracted_routes, f)

                # Save mapped reactions (CSV)
                routes_dict = extract_reactions(
                    tree, reconcile_atom_mapping=reconcile_atom_mapping
                )
                write_routes_csv(
                    routes_dict, os.path.join(routes_folder, f"mapped_routes_{ti}.csv")
                )

                # save mapped reactions (JSON)
                write_routes_json(
                    routes_dict,
                    os.path.join(routes_folder, f"mapped_routes_{ti}.json"),
                    tree=tree,
                )

                # public route export (reuse extract_reactions result)
                if export_routes:
                    exported_routes[export_key] = build_target_routes(
                        tree, reactions=routes_dict
                    )

            # save stats
            if tree.proposal_nodes:
                from synplan.chem.reaction.routes.route import Route

                proposals = [
                    Route.from_tree(tree, node_id) for node_id in tree.proposal_nodes
                ]
                proposal_path = Path(routes_folder) / f"stereo_proposals_{ti}.json"
                proposal_path.write_text(
                    json.dumps([r.to_json() for r in proposals], indent=2)
                )
                routes_report_html(
                    proposals, str(Path(routes_folder) / f"stereo_proposals_{ti}.html")
                )
            stats_row = extract_tree_stats(tree, target_smi)
            stats_row["target_in_stock"] = False
            statswriter.writerow(stats_row)
            csvfile.flush()

    if export_routes:
        export_routes_artifact(exported_routes, results_root, filename=routes_filename)
    if is_json_catalogue:
        with open(
            results_root.joinpath("route_costs.json"), "w", encoding="utf-8"
        ) as file:
            json.dump(route_costs, file, indent=2)

    print(f"Number of solved target molecules: {n_solved}")
    if n_in_stock:
        print(f"Already purchasable, not searched: {n_in_stock}")
