"""Module containing a class Tree that used for tree search of retrosynthetic routes."""

import json
import logging
from collections import deque
from collections.abc import Iterator, Mapping
from dataclasses import dataclass, field, fields
from hashlib import sha256
from itertools import pairwise
from math import log
from time import time

from chython import inchi_key, smiles
from chython.containers import MoleculeContainer
from tqdm.auto import tqdm

from synplan.chem.building_blocks import (
    BuildingBlockCatalogue,
    SQLiteBuildingBlockCatalogue,
)
from synplan.chem.precursor import Precursor
from synplan.chem.reaction import CanonicalRetroReactor, Reaction, apply_reaction_rule
from synplan.chem.reaction.routes.route import Route
from synplan.chem.reaction.rules import POLICY_SOURCE_NAME
from synplan.chem.stereo import (
    StereoObligations,
    UnresolvedStereo,
    assess_inheritance,
    has_stereo,
    has_stereo_groups,
    stereo_requirements,
)
from synplan.mcts.config import TreeConfig
from synplan.mcts.evaluation import EvaluationStrategy
from synplan.mcts.node import Node
from synplan.mcts.policy import Policy, PriorityPolicy

from .algorithm import (
    UCT,
    Beam,
    BestFirst,
    BreadthFirst,
    LazyNestedMonteCarlo,
    NestedMonteCarlo,
)

ALGORITHMS = {
    "breadth_first": BreadthFirst,
    "best_first": BestFirst,
    "beam": Beam,
    "uct": UCT,
    "nmcs": NestedMonteCarlo,
    "lazy_nmcs": LazyNestedMonteCarlo,
}

logger = logging.getLogger(__name__)


def _not_a_node(node_id) -> str:
    """The message for a route asked about by something that is not a node id."""

    return (
        f"{node_id!r} is not a node of this tree: a route is identified by the "
        "id of the node it ends at (tree.winning_nodes), not by its position"
    )


@dataclass
class PerSourceCounters:
    """Per-priority-set counters within :class:`TreeStats`."""

    tried: int = 0
    succeeded: int = 0


@dataclass
class TreeStats:
    """Typed counters for an MCTS search run.

    ``priority_rules_tried`` / ``priority_rules_succeeded`` are aggregates
    across every priority set; the per-set breakdown lives in
    ``per_priority_source`` keyed by the source name supplied as the dict
    key in ``Tree(priority_rules={...})``.
    """

    expansion_calls: int = 0
    expansion_successes: int = 0
    total_rules_tried: int = 0
    total_rules_succeeded: int = 0
    policy_rules_tried: int = 0
    policy_rules_succeeded: int = 0
    priority_rules_tried: int = 0
    priority_rules_succeeded: int = 0
    per_priority_source: dict[str, PerSourceCounters] = field(default_factory=dict)
    dead_end_nodes: int = 0
    first_solution_iteration: int | None = None
    first_solution_time: float | None = None
    routes_found_at: list[tuple[int, float]] = field(default_factory=list)
    iterations_without_expansion: int = 0
    stereo_incompatible_outcomes: int = 0
    stereo_unresolved_outcomes: int = 0
    stereo_incomplete_assessments: int = 0

    def __getitem__(self, key: str):
        if key in {f.name for f in fields(self)}:
            raise TypeError(
                f"TreeStats is a dataclass since 1.5.0. "
                f"Use tree.stats.{key} instead of tree.stats[{key!r}]."
            )
        raise KeyError(key)


@dataclass(slots=True)
class _ExpansionContext:
    """State shared by all candidate rules during one node expansion."""

    node_id: int
    parent: Node
    previous_precursors: list[Precursor]
    seen_products: set


@dataclass(frozen=True, slots=True)
class _RuleCandidate:
    """Reaction rule and provenance yielded by :meth:`Tree._iter_rules`."""

    probability: float
    rule: CanonicalRetroReactor
    rule_id: int
    rule_source: str
    policy_rank: int | None


_REMOVED_NODE_ATTRS: dict[str, tuple[str, str]] = {
    "nodes_visit": ("tree.nodes[node_id].visit", "1.5.0"),
    "nodes_depth": ("tree.nodes[node_id].depth", "1.5.0"),
    "nodes_prob": ("tree.nodes[node_id].prob", "1.5.0"),
    "nodes_init_value": ("tree.nodes[node_id].init_value", "1.5.0"),
    "nodes_total_value": ("tree.nodes[node_id].total_value", "1.5.0"),
    "nodes_rules": ("tree.nodes[node_id].rule_id", "1.5.0"),
}


class Tree:
    """Tree class with attributes and methods for Monte-Carlo tree search."""

    def __init__(
        self,
        target: MoleculeContainer,
        config: TreeConfig,
        reaction_rules: list[CanonicalRetroReactor],
        building_blocks: set[str] | frozenset[str] | BuildingBlockCatalogue,
        expansion_function: Policy,
        evaluation_function: EvaluationStrategy = None,
        priority_rules: dict[str, list[CanonicalRetroReactor]] | None = None,
    ):
        """Initializes a tree object with optional parameters for tree search for target
        molecule.

        :param target: A target molecule for retrosynthetic routes search.
        :param config: A tree configuration.
        :param reaction_rules: A loaded reaction rules.
        :param building_blocks: A loaded building blocks.
        :param expansion_function: A loaded policy function.
        :param evaluation_function: An evaluation strategy. If None, a random
            evaluation strategy is used as default.
        :param priority_rules: Optional **mapping** of curated rule sets,
            ``{set_name: [Reactor, ...]}``. Each set contributes rules tagged
            with its mapping key as ``rule_source``; e.g.
            ``priority_rules={"ugi": ugi_rules, "boc_deprotection": boc_rules}``
            yields a search where each Ugi child carries ``rule_source="ugi"``
            and each Boc child carries ``rule_source="boc_deprotection"``.
            Per-set tried/succeeded counters are kept in
            ``tree.stats.per_priority_source[<set_name>]``; the
            ``priority_rules_tried`` / ``priority_rules_succeeded`` aggregates
            sum across all sets. Reserved set name: ``"policy"`` (raises
            ``ValueError``). When ``config.use_priority`` is set, every
            priority set is tried *before* the policy on every node — rules
            match by simple substructure isomorphism (``pattern < molecule``)
            and enter with ``prob=1.0``; combined with the per-product
            fragment-count multiplier in :meth:`_add_child_if_new`
            (``scaled_prob = prob × n_qualifying_fragments``), a priority
            disconnect producing N qualifying fragments enters UCB with prior
            N. Multi-fragment priority disconnects (e.g. 4-component Ugi)
            therefore dominate sibling selection by design.
        """

        # tree config parameters
        self.config = config
        self._stereo_assessments = {}
        for record in config.stereo_assessments:
            self._stereo_assessments.setdefault(record.get("context"), []).append(
                record
            )

        # building blocks and reaction reaction_rules
        self.reaction_rules = tuple(reaction_rules)
        if config.stereo_mode == "off":
            from synplan.chem.reaction.reactor import stereo_free_rule

            self.reaction_rules = tuple(map(stereo_free_rule, self.reaction_rules))
            priority_rules = {
                name: list(map(stereo_free_rule, rules))
                for name, rules in (priority_rules or {}).items()
            }
        if isinstance(building_blocks, Mapping):
            if self.config.direction == "forward":
                raise ValueError(
                    "JSON building-block catalogues are supported only for retrosynthesis"
                )
            self.building_blocks = building_blocks
            self._building_block_count = (
                building_blocks.record_count
                if isinstance(building_blocks, SQLiteBuildingBlockCatalogue)
                else sum(len(bucket) for bucket in building_blocks.values())
            )
            self._building_block_bucket_count: int | None = len(building_blocks)
        else:
            # ponytail: CLI stock is already normalized, but direct Tree callers need
            # this. Reusing prepared stock would avoid reparsing it for every target.
            self.building_blocks = (
                frozenset(str(smiles(s, ignore_stereo=True)) for s in building_blocks)
                if config.stereo_mode == "off"
                else frozenset(building_blocks)
            )
            self._building_block_count = len(self.building_blocks)
            self._building_block_bucket_count = None
        self.priority_rules: dict[str, tuple[CanonicalRetroReactor, ...]] = {
            name: tuple(rules) for name, rules in (priority_rules or {}).items()
        }
        if self.config.use_priority and not self.priority_rules:
            raise ValueError(
                "config.use_priority=True but no priority_rules were supplied. "
                "Pass priority_rules={'<name>': [...rules]} or set use_priority=False."
            )
        # Curated-rule selection is delegated to a PriorityPolicy per source.
        self._priority_policies: dict[str, PriorityPolicy] = {
            name: PriorityPolicy(rules) for name, rules in self.priority_rules.items()
        }

        # policy and evaluation services
        assert expansion_function is not None, "Expansion function is required"
        # Node expansion is driven through the Policy seam.
        self.expansion_function: Policy = expansion_function
        prepare_rules = getattr(
            self.expansion_function, "prepare_rule_associations", None
        )
        if prepare_rules is not None:
            prepare_rules(self.reaction_rules)

        assert evaluation_function is not None, "Evaluation function is required"
        self.evaluator = evaluation_function
        rollout = getattr(self.evaluator, "rollout", None)

        # A forward search only makes sense if the tree and its evaluator share a finish line. The
        # tree stops on `building_blocks`; a rollout evaluator carries its OWN copy and rewards
        # reaching that. Nothing couples them, so `building_blocks={target}, min_mol_size=0` on the
        # Tree and the retro defaults on the evaluator gives a search that halts at the goal while
        # still being scored on how close it got to stock — plausible numbers, wrong ones.
        if self.config.direction == "forward":
            if not self.building_blocks:
                raise ValueError(
                    "config.direction='forward' but building_blocks is empty; in forward mode "
                    "it is the GOAL to reach, so an empty set can never be satisfied."
                )
            if rollout is not None and (
                frozenset(rollout.building_blocks) != self.building_blocks
                or rollout.min_mol_size != self.config.min_mol_size
            ):
                raise ValueError(
                    f"config.direction='forward' requires the evaluator to score the same finish "
                    f"line as the tree: tree has {len(self.building_blocks)} building_blocks and "
                    f"min_mol_size={self.config.min_mol_size}, the rollout evaluator has "
                    f"{len(frozenset(rollout.building_blocks))} and "
                    f"min_mol_size={rollout.min_mol_size}."
                )

        if rollout is not None:
            # Rollouts must use the same normalized stock, rules and stereo mode as the tree.
            rollout.building_blocks = self.building_blocks
            rollout.reaction_rules = self.reaction_rules
            rollout.match_stereo = config.stereo_mode != "off"

        # tree initialization
        target_node = self._init_target_node(target)
        self.nodes: dict[int, Node] = {1: target_node}
        self.parents: dict[int, int] = {1: 0}
        self.redundant_children: dict[int, set[int]] = {1: set()}
        self.children: dict[int, set[int]] = {1: set()}
        self.winning_nodes: list[int] = []
        self.proposal_nodes: list[int] = []
        self.stereo_diagnostics: list[dict] = []
        self.visited_nodes: set[int] = set()
        self.expanded_nodes: set[int] = set()

        # default search parameters
        self.init_node_value: float = self.config.init_node_value

        # tree building limits
        self.curr_iteration: int = 0
        self.curr_tree_size: int = 2
        self.start_time: float = 0
        self.curr_time: float = 0

        # utils
        self._tqdm = True  # needed to disable tqdm with multiprocessing module

        # other tree search algorithms
        self.stop_at_first = config.stop_at_first
        self.found_a_route = False
        self.big_dict_of_all_tuples_of_precursors_to_expand_but_not_building_blocks = {}

        # search statistics
        self.stats: TreeStats = TreeStats()
        self._expanded_molecule_keys: set[str] = set()
        self._expanded_state_keys: set[tuple[str, ...]] = set()

        # choose search algorithm (normalize key)
        algo_key = str(config.algorithm).lower()
        if algo_key not in ALGORITHMS:
            raise ValueError(
                f"Unknown algorithm '{config.algorithm}'. Allowed: {list(ALGORITHMS.keys())}"
            )
        self.algorithm = ALGORITHMS[algo_key](self)

        priority_rules_total = sum(len(rules) for rules in self.priority_rules.values())
        logger.debug(
            f"Tree init: target={str(target)[:50]}, "
            f"building_blocks={self._building_block_count}, "
            f"building_block_buckets={self._building_block_bucket_count}, "
            f"reaction_rules={len(self.reaction_rules)}, "
            f"priority_rules={priority_rules_total} across "
            f"{len(self.priority_rules)} sets {list(self.priority_rules)}, "
            f"use_priority={self.config.use_priority}, "
            f"algorithm={algo_key}, "
            f"max_iterations={config.max_iterations}, "
            f"max_tree_size={config.max_tree_size}, "
            f"max_time={config.max_time}, "
            f"max_depth={config.max_depth}, "
            f"min_mol_size={config.min_mol_size}, "
            f"search_strategy={config.search_strategy}, "
            f"normalize_scores={config.normalize_scores}, "
        )

    def __len__(self) -> int:
        """Returns the current size (the number of nodes) in the tree."""

        return self.curr_tree_size - 1

    def __iter__(self) -> "Tree":
        """The function is defining an iterator for a Tree object.

        Also needed for the bar progress display.
        """

        self.start_time = time()
        if self._tqdm:
            self._tqdm = tqdm(
                total=self.config.max_iterations, disable=self.config.silent
            )
        return self

    def __repr__(self) -> str:
        """Returns a string representation of the tree (target SMILES, tree size, and
        the number of found routes)."""
        return self.report()

    def __next__(self) -> tuple[bool, list[int]]:
        """The __next__ method is used to do one iteration of the tree building.

        :return: Returns True if the route was found and the node id of the last node in
            the route. Otherwise, returns False and the id of the last visited node.
        """

        if self.curr_iteration >= self.config.max_iterations:
            raise StopIteration("Iterations limit exceeded.")
        if self.curr_tree_size >= self.config.max_tree_size:
            raise StopIteration("Max tree size exceeded or all possible routes found.")
        if time() - self.start_time >= self.config.max_time:
            raise StopIteration("Time limit exceeded.")
        if self.stop_at_first and self.found_a_route:
            raise StopIteration("Already found a route.")

        # start new iteration
        self.curr_iteration += 1
        self.curr_time = time() - self.start_time

        if self._tqdm:
            self._tqdm.update()

        previous_routes = len(self.winning_nodes)
        previous_expansions = self.stats.expansion_calls
        is_solved, last_node_id = self.algorithm.step()
        self.curr_time = time() - self.start_time
        self.stats.iterations_without_expansion += (
            self.stats.expansion_calls == previous_expansions
        )

        new_routes = len(self.winning_nodes) - previous_routes
        if new_routes:
            self.stats.routes_found_at.extend(
                [(self.curr_iteration, round(self.curr_time, 4))] * new_routes
            )
            if self.stats.first_solution_iteration is None:
                self.stats.first_solution_iteration = self.curr_iteration
                self.stats.first_solution_time = round(self.curr_time, 4)

        return is_solved, last_node_id

    def run(self) -> "Tree":
        """Run the search to completion and return the tree.

        Search stops on whichever limit is reached first — ``max_iterations``,
        ``max_tree_size``, ``max_time``, or a route being found when
        ``stop_at_first`` is set. Inspect the finished tree through
        :attr:`stats`, or extract its routes with the functions in
        ``synplan.chem.reaction.routes``.

        Iterate the tree directly instead when you need the per-iteration
        ``(is_solved, node_ids)`` results — to report progress, or to stop on a
        condition of your own::

            for is_solved, node_ids in tree:
                if is_solved and my_condition(tree):
                    break

        ``run()`` is the same search without the intermediate results.
        """
        deque(self, maxlen=0)  # exhaust without materialising the yielded tuples
        return self

    def _init_target_node(self, target: MoleculeContainer):
        assert isinstance(target, MoleculeContainer), (
            "Target should be given as MoleculeContainer"
        )
        assert len(target) > 3, "Target molecule has less than 3 atoms"

        self.original_target = target.copy()
        if self.config.stereo_mode == "off":
            target = target.copy()
            target.clean_stereo()
        target_molecule = Precursor(target)
        obligations = []
        try:
            stereo_requirements(target_molecule.molecule)
            if has_stereo_groups(target_molecule.molecule):
                obligations.append(
                    {
                        "reason": "relative_or_mixture_stereo",
                        "detail": "Target group semantics require assessment; original CXSMILES is preserved.",
                    }
                )
        except UnresolvedStereo as error:
            obligations.append({"reason": error.reason, "detail": str(error)})
        target_molecule.prev_precursors.append(Precursor(target))
        target_node = Node(
            precursors_to_expand=(target_molecule,),
            new_precursors=(target_molecule,),
            stereo_obligations=tuple(obligations),
        )

        return target_node

    def _expand_node(self, node_id: int) -> None:
        """Expands the node by generating new precursors using the policy function.

        :param node_id: The id of the node to be expanded.
        :return: None.
        """
        curr_node = self.nodes[node_id]
        if curr_node.is_terminal():
            return
        prev_precursor = curr_node.curr_precursor.prev_precursors

        self._expanded_molecule_keys.add(str(curr_node.curr_precursor.molecule))
        self._expanded_state_keys.add(
            tuple(sorted(str(p.molecule) for p in curr_node.precursors_to_expand))
        )

        # Deduplicate accepted complete precursor multisets, including multiplicity.
        tmp_products = set()
        context = _ExpansionContext(
            node_id=node_id,
            parent=curr_node,
            previous_precursors=prev_precursor,
            seen_products=tmp_products,
        )
        expanded = False
        for candidate in self._iter_rules(curr_node):
            self._increment_rule_stats(candidate.rule_source, tried=1)
            rule_produced = False
            # Multi-application fires for any priority source (every source
            # other than "policy"); the configured boolean is a global switch.
            enable_multirule = bool(
                candidate.rule_source != POLICY_SOURCE_NAME
                and self.config.priority_rule_multiapplication
            )
            diagnostics = []
            for products in apply_reaction_rule(
                curr_node.curr_precursor.molecule,
                candidate.rule,
                top_reactions_num=self.config.max_reaction_outcomes,
                multirule=enable_multirule,
                rm_dup=enable_multirule,
                max_mapping_work=self.config.max_mapping_work,
                diagnostics=diagnostics,
            ):
                if self._add_child_if_new(context, products, candidate):
                    rule_produced = True
                    expanded = True
            for diagnostic in diagnostics:
                self.stereo_diagnostics.append(
                    {
                        "node": node_id,
                        "rule_key": self._make_rule_key(
                            candidate.rule_source, candidate.rule_id
                        ),
                        **diagnostic,
                    }
                )
                self.stats.stereo_incomplete_assessments += 1

            if rule_produced:
                self._increment_rule_stats(candidate.rule_source, succeeded=1)

        # update statistics
        for diagnostic in curr_node.curr_precursor.molecule.meta.pop(
            "query_assessment_diagnostics", ()
        ):
            self.stereo_diagnostics.append({"node": node_id, **diagnostic})
            self.stats.stereo_incomplete_assessments += 1
        self.stats.expansion_calls += 1
        if expanded:
            self.stats.expansion_successes += 1
        elif node_id != 1:
            self.stats.dead_end_nodes += 1

        if not expanded and node_id == 1:
            raise StopIteration("\nThe target molecule was not expanded.")

    def _iter_rules(self, curr_node: Node):
        """Yield reaction rules from each enabled source for the current node.

        When ``config.use_priority`` is set and ``priority_rules`` is non-empty,
        every priority set is iterated **first** with ``prob=1.0`` and a
        ``rule_source`` equal to its mapping key (e.g. ``"ugi"``). Combined
        with the fragment-count multiplier applied in :meth:`_add_child_if_new`,
        priority disconnects intentionally dominate sibling selection — see the
        ``priority_rules`` parameter on :meth:`__init__` for details. Sets are
        iterated in insertion order; rules within a set in their list order.

        Policy rules follow, paginated by ``policy_top_rules`` and yielded with
        the policy probability and a 1-indexed ``policy_rank``. Priority and
        policy rules are *additive*, not gated: both run on every node.
        """

        if self.config.use_priority and self._priority_policies:
            for source_name, policy in self._priority_policies.items():
                for prob, rule, rule_id in policy.predict_reaction_rules(
                    curr_node.curr_precursor, self.reaction_rules
                ):
                    yield _RuleCandidate(
                        probability=prob,
                        rule=rule,
                        rule_id=rule_id,
                        rule_source=source_name,
                        policy_rank=None,
                    )

        policy_top_rules = getattr(self.expansion_function, "top_rules", None)
        if policy_top_rules is not None:
            policy_top_rules = int(policy_top_rules)
        for policy_rank, (prob, rule, rule_id) in enumerate(
            self.expansion_function.predict_reaction_rules(
                curr_node.curr_precursor, self.reaction_rules
            ),
            start=1,
        ):
            if policy_top_rules is not None and policy_rank > policy_top_rules:
                break
            yield _RuleCandidate(
                probability=prob,
                rule=rule,
                rule_id=rule_id,
                rule_source=POLICY_SOURCE_NAME,
                policy_rank=policy_rank,
            )

    def _add_child_if_new(
        self,
        context: _ExpansionContext,
        products,
        candidate: _RuleCandidate,
    ) -> bool:
        """Add a child node if the generated products form a new valid state."""

        node_id = context.node_id
        curr_node = context.parent
        prev_precursor = context.previous_precursors
        tmp_products = context.seen_products
        prob = candidate.probability
        rule_id = candidate.rule_id
        policy_rank = candidate.policy_rank
        rule_source = candidate.rule_source

        products = [m.copy() for m in products]
        if self.config.stereo_mode == "off":
            for molecule in products:
                molecule.clean_stereo()
        assessment = assess_inheritance(curr_node.curr_precursor.molecule, products)
        if self.config.direction == "forward" and any(
            has_stereo(m) for m in (curr_node.curr_precursor.molecule, *products)
        ):
            assessment["obligations"].append(
                {
                    "reason": "forward_stereo_not_assessed",
                    "detail": "Stereo route fulfillment currently supports retrosynthetic search.",
                }
            )
        from synplan.chem.stereo_evidence import (
            apply_chemistry_assessment,
            assess_chemistry_records,
            reaction_context,
        )

        evidence, decision = (), "unreviewed"
        if self._stereo_assessments and self.config.stereo_mode != "off":
            forward = Reaction(products, [curr_node.curr_precursor.molecule])
            evidence_context = reaction_context(forward)
            evidence = self._stereo_assessments.get(evidence_context, ())
            decision = apply_chemistry_assessment(
                assessment, assess_chemistry_records(evidence, evidence_context)
            )
        if decision == "rejected":
            self.stats.stereo_incompatible_outcomes += 1
            return False
        if decision == "conflicting":
            assessment["obligations"].append(
                {
                    "reason": "conflicting_chemistry_assessments",
                    "detail": "Recorded assessments disagree for this exact context.",
                }
            )
        if any(
            o["reason"] == "configuration_contradicted"
            for o in assessment["obligations"]
        ):
            self.stats.stereo_incompatible_outcomes += 1
            return False
        if assessment["obligations"]:
            self.stats.stereo_unresolved_outcomes += 1
            if self.config.stereo_mode == "strict":
                return False
        obligations = curr_node.stereo_obligations.extend(
            {
                **o,
                "tree_node_id": self.curr_tree_size,
                "rule_key": self._make_rule_key(rule_source, rule_id),
            }
            for o in assessment["obligations"]
        )
        product_key = tuple(sorted(str(molecule) for molecule in products))
        # Identical precursors can arise from different stereo operations or
        # evidence. Keep those alternatives and their provenance distinct.
        if obligations or assessment["events"]:
            product_key = (product_key, self._make_rule_key(rule_source, rule_id))
        if not products or product_key in tmp_products:
            return False

        rule_key = self._make_rule_key(rule_source, rule_id)
        for molecule in products:
            molecule.meta["reactor_id"] = rule_id
            molecule.meta["rule_source"] = rule_source
            molecule.meta["rule_key"] = rule_key
            molecule.meta["policy_rank"] = policy_rank

        # ``apply_reaction_rule`` already validated + canonicalized each
        # product in a single kekule pass; skip the redundant copy here.
        new_precursor = tuple(Precursor(mol, canonicalize=False) for mol in products)
        # Multiply prob by the number of qualifying fragments so that
        # disconnections producing more usable precursors are preferred. Note:
        # priority rules enter here with prob=1.0, so a priority disconnect
        # producing N qualifying fragments is recorded with prior N — this is
        # the intentional mechanism that lets curated priority rules outrank
        # policy rules during UCB sibling selection.
        scaled_prob = prob * len(
            [mol for mol in products if len(mol) > self.config.min_mol_size]
        )

        if not set(prev_precursor).isdisjoint(new_precursor):
            return False

        precursors_to_expand = (
            *curr_node.next_precursor,
            *(
                x
                for x in new_precursor
                if not x.is_building_block(
                    self.building_blocks,
                    self.config.min_mol_size,
                    match_stereo=self.config.stereo_mode != "off",
                )
            ),
        )

        # Pruning must retain path obligations and stereo operation provenance.
        for precursor in new_precursor:
            for diagnostic in precursor.stock_diagnostics:
                self.stereo_diagnostics.append(
                    {
                        "node": node_id,
                        "rule_key": rule_key,
                        "molecule": str(precursor),
                        **diagnostic,
                    }
                )
                self.stats.stereo_incomplete_assessments += 1
        # State comparison is linear in explicitly stored records, never in all
        # possible stereoisomer assignments.
        history = curr_node.stereo_history
        if assessment["events"] or evidence:
            local = {
                "products": [str(p) for p in new_precursor],
                "rule": rule_key,
                "events": assessment["events"],
                "evidence": evidence,
                "stock": [p.selected_stock for p in new_precursor],
            }
            history = sha256(
                (history + json.dumps(local, sort_keys=True)).encode()
            ).hexdigest()
        pruning_key = (precursors_to_expand, obligations.key, history)
        if self.config.enable_pruning:
            if (
                precursors_to_expand != ()
                and pruning_key
                in self.big_dict_of_all_tuples_of_precursors_to_expand_but_not_building_blocks
            ):
                existing_id = self.big_dict_of_all_tuples_of_precursors_to_expand_but_not_building_blocks[
                    pruning_key
                ]
                self.redundant_children[node_id].add(existing_id)
                tmp_products.add(product_key)
                return True

            self.big_dict_of_all_tuples_of_precursors_to_expand_but_not_building_blocks[
                pruning_key
            ] = self.curr_tree_size

        child_node = Node(
            precursors_to_expand=precursors_to_expand,
            new_precursors=new_precursor,
            stereo_obligations=obligations,
            stereo_events=tuple(assessment["events"]),
            stereo_evidence=tuple(evidence),
            stereo_history=history,
        )

        for np in new_precursor:
            np.prev_precursors = [np, *prev_precursor]

        self._add_node(
            node_id=node_id,
            new_node=child_node,
            policy_prob=scaled_prob,
            rule_id=rule_id,
            policy_rank=policy_rank,
            rule_source=rule_source,
            policy_probability=prob if rule_source == POLICY_SOURCE_NAME else None,
        )
        tmp_products.add(product_key)
        return True

    def _increment_rule_stats(
        self, rule_source: str, tried: int = 0, succeeded: int = 0
    ) -> None:
        """Track per-source and aggregate rule usage statistics.

        Policy rules increment the dedicated policy counters. Anything else is
        treated as a priority source: the priority aggregates plus the
        per-source breakdown in ``stats.per_priority_source[rule_source]``.

        .. note::
           ``succeeded`` counts are **order-dependent** when two rule sources
           can produce the same product set on the same node. ``_iter_rules``
           yields priority sets first, then policy; ``_add_child_if_new``
           shares a single ``tmp_products`` deduplication set across the loop.
           If a priority rule "claims" a product set, an equivalent policy
           rule fired afterwards is silently skipped and the policy counter
           for that node is *not* incremented. The total tree shape is
           correct (we don't want duplicate children for the same product
           set) but per-source success rates can underrepresent the policy
           when priority rules overlap.
        """

        self.stats.total_rules_tried += tried
        self.stats.total_rules_succeeded += succeeded

        if rule_source == POLICY_SOURCE_NAME:
            self.stats.policy_rules_tried += tried
            self.stats.policy_rules_succeeded += succeeded
            return

        self.stats.priority_rules_tried += tried
        self.stats.priority_rules_succeeded += succeeded
        per_source = self.stats.per_priority_source.setdefault(
            rule_source, PerSourceCounters()
        )
        per_source.tried += tried
        per_source.succeeded += succeeded

    @staticmethod
    def _make_rule_key(rule_source: str | None, rule_id: int | None) -> str | None:
        """Build a collision-safe rule identifier."""

        if rule_source is None or rule_id is None:
            return None
        return f"{rule_source}:{rule_id}"

    def _add_node(
        self,
        node_id: int,
        new_node: Node,
        policy_prob: float | None = None,
        rule_id: int | None = None,
        policy_rank: int | None = None,
        rule_source: str | None = None,
        policy_probability: float | None = None,
    ) -> None:
        """Adds a new node to the tree with probability of reaction rules predicted by
        policy function and applied to the parent node of the new node.

        :param node_id: The id of the parent node.
        :param new_node: The new node to be added.
        :param policy_prob: The probability of reaction rules predicted by policy
            function for thr parent node.
        :return: None.
        """

        new_node_id = self.curr_tree_size

        # Per-node search state and provenance live on the Node itself.
        new_node.visit = 0
        new_node.prob = policy_prob if policy_prob is not None else 0.0
        new_node.rule_id = rule_id
        new_node.rule_source = rule_source
        new_node.rule_key = self._make_rule_key(rule_source, rule_id)
        new_node.policy_rank = policy_rank
        new_node.policy_probability = policy_probability
        new_node.depth = self.nodes[node_id].depth + 1

        self.nodes[new_node_id] = new_node
        self.parents[new_node_id] = node_id
        self.redundant_children[new_node_id] = set()
        self.children[node_id].add(new_node_id)
        self.children[new_node_id] = set()
        self.curr_tree_size += 1
        if new_node.is_terminal():
            self.audit_terminal_stereo(new_node_id)
        if new_node.is_terminal() and not new_node.is_solved():
            self.proposal_nodes.append(new_node_id)

        if self.config.search_strategy == "evaluation_first":
            node_value = self._get_node_value(new_node_id)
        elif self.config.search_strategy == "expansion_first":
            node_value = self.init_node_value

        new_node.init_value = node_value
        new_node.total_value = node_value

    def audit_terminal_stereo(self, node_id):
        """Whole-route verification precedes any winning-node flag or reward."""
        from frozendict import frozendict

        from synplan.chem.building_blocks import BuildingBlock
        from synplan.chem.mapping import MappingBudgetExceeded, mapping_budget
        from synplan.chem.reaction.routes.stereo import audit_stereo_inheritance
        from synplan.chem.stereo_evidence import route_stereo_summary

        node = self.nodes[node_id]
        try:
            route = Route.from_tree(self, node_id)
        except ValueError as error:
            node.stereo_obligations = node.stereo_obligations.extend(
                (
                    {
                        "reason": "mapping_or_representation_unresolved",
                        "detail": str(error),
                    },
                )
            )
            return
        if self.config.stereo_mode == "off":
            node.stereo_summary = route.stereo
            return
        audit = None
        carries_stereo = any(
            has_stereo(mol)
            for step in route.steps
            for mol in (*step.reaction.reactants, *step.reaction.products)
        )
        if not node.stereo_obligations and carries_stereo:
            catalogue = self.building_blocks
            if not isinstance(catalogue, Mapping):
                buckets = {}
                for leaf in route.leaves():
                    if str(leaf) in catalogue:
                        key = inchi_key(leaf)
                        buckets.setdefault(key[:14], []).append(
                            BuildingBlock(str(leaf), key, False)
                        )
                catalogue = frozendict(
                    {key: tuple(records) for key, records in buckets.items()}
                )
            try:
                with mapping_budget(self.config.max_mapping_work):
                    audit = audit_stereo_inheritance(
                        route,
                        self.original_target,
                        catalogue,
                        mapping_sources={
                            i: f"search:{step.origin.rule_key}"
                            for i, step in enumerate(route.steps)
                        },
                        allow_unconstrained_target=True,
                        min_mol_size=self.config.min_mol_size,
                    )
                if audit.supported:
                    node.reconstructed_route = route = audit.route
                else:
                    node.stereo_obligations = StereoObligations().extend(audit.issues)
            except (MappingBudgetExceeded, ValueError, KeyError) as error:
                node.stereo_obligations = StereoObligations().extend(
                    (
                        {
                            "reason": "mapping_or_representation_unresolved",
                            "detail": str(error),
                        },
                    )
                )
        node.stereo_summary = route_stereo_summary(
            route,
            original_target=self.original_target,
            status=node.stereo_status,
            obligations=node.stereo_obligations,
            audit=audit.to_dict() if audit else None,
        )
        if any(step.reaction.meta.get("stereo_evidence") for step in route.steps):
            node.stereo_summary["selectivity_evidence_status"] = (
                "scoped_chemist_assessment_present"
            )
            if node.is_solved():
                node.stereo_summary["basis"] = (
                    "reviewed_transformations_and_inherited_stock"
                )

    def _get_node_value(self, node_id: int) -> float:
        """Calculates the value for the given node (for example with rollout or value
        network).

        :param node_id: The id of the node to be evaluated.
        :return: The estimated value of the node.
        """

        node = self.nodes[node_id]
        if node.is_terminal() and not node.is_solved():
            return 0.0
        node_value = self.evaluator.evaluate_node(
            node=node,
            node_id=node_id,
            nodes=self.nodes,
        )
        # Heuristic values are proposal scores. An unresolved stereo operation
        # must not receive the same maximal value as a fulfilled route.
        return min(node_value, 0.5) if node.stereo_obligations else node_value

    def _log_final_stats(self, reason: str = "completed") -> None:
        """Logs final tree statistics after search completes.

        :param reason: Reason for stopping (e.g., "iterations limit", "time limit").
        """
        max_depth = max(n.depth for n in self.nodes.values()) if self.nodes else 0
        logger.debug(
            f"Tree finished ({reason}): "
            f"iterations={self.curr_iteration}, "
            f"tree_size={self.curr_tree_size}, "
            f"nodes={len(self.nodes)}, "
            f"visited_nodes={len(self.visited_nodes)}, "
            f"expanded_nodes={len(self.expanded_nodes)}, "
            f"winning_nodes={len(self.winning_nodes)}, "
            f"max_depth={max_depth}, "
            f"time={self.curr_time:.2f}s, "
            f"children={sum(len(v) for v in self.children.values())}, "
            f"redundant_children={sum(len(v) for v in self.redundant_children.values())}"
        )

    def _update_visits(self, node_id: int) -> None:
        """Updates the number of visits from the current node to the root node.

        :param node_id: The id of the current node.
        :return: None.
        """

        while node_id:
            self.nodes[node_id].visit += 1
            node_id = self.parents[node_id]

    def report(self) -> str:
        """Returns the string representation of the tree."""

        return (
            f"Tree for: {self.nodes[1].precursors_to_expand[0]!s}\n"
            f"Time: {round(self.curr_time, 1)} seconds\n"
            f"Number of nodes: {len(self)}\n"
            f"Number of iterations: {self.curr_iteration}\n"
            f"Number of visited nodes: {len(self.visited_nodes)}\n"
            f"Number of found routes: {len(self.winning_nodes)}"
        )

    def route_score(self, node_id: int) -> float:
        """Calculates the score of a given route from the current node to the root node.
        The score depends on cumulated node values and the route length.

        This is the search's own number. Judging a finished route by anything else
        (e.g. a protection-group penalty) is a
        :class:`~synplan.chem.reaction.routes.quality.scorer.RouteScorer`'s job,
        after the search.

        :param node_id: The id of the current given node.
        :return: The route score.
        :raises ValueError: if ``node_id`` is not a node of this tree.
        """

        if node_id not in self.nodes:  # a route of no nodes has no length to divide by
            raise ValueError(_not_a_node(node_id))
        route_nodes = tuple(self.route_to_node(node_id))
        route_length = len(route_nodes)
        cumulated_nodes_value = sum(node.total_value for node in route_nodes)

        return cumulated_nodes_value / (route_length**2)

    def route_log_likelihood(self, node_id: int) -> float:
        """Sum the unscaled policy log probabilities along a route or partial path.

        This score uses no reference route and no search values. A zero probability
        gives negative infinity. Rules without a policy probability (including
        curated priority rules and old records) cannot be scored this way.
        """
        if node_id not in self.nodes:
            raise ValueError(_not_a_node(node_id))
        score = 0.0
        for node in self.route_to_node(node_id)[1:]:
            probability = node.policy_probability
            if probability is None or not 0 <= probability <= 1:
                raise ValueError(
                    "Route likelihood requires policy probabilities in [0, 1]."
                )
            score += log(probability) if probability else -float("inf")
        return score

    def routes(self, solved_only: bool = True) -> list["Route"]:
        """The tree's routes as objects, best score first.

        ``winning_nodes`` stays the raw id list the search appends to; this is
        its companion for callers who want something they can draw, score and
        serialise.

        :param solved_only: When False, also return the unfinished routes, one
            per search leaf that was never solved. The root is skipped: a search
            that stopped before its first expansion leaves it childless, and a
            route of no steps is not a route. That enumeration is blunt -- most
            such leaves are one step deep -- so filter on ``len(route)``.
        """

        node_ids = sorted(set(self.winning_nodes))
        if not solved_only:
            node_ids += [
                node_id
                for node_id in self.nodes
                if node_id != 1
                and not self.children.get(node_id)
                and not self.nodes[node_id].is_solved()
            ]
        routes = [Route.from_tree(self, node_id) for node_id in node_ids]
        routes.sort(key=lambda route: route.provenance.search_score, reverse=True)
        return routes

    def route_node_ids(self, node_id: int) -> tuple[int, ...]:
        """The ids from the root down to ``node_id``.

        :raises KeyError: if a node on the way up is not in this tree.
        """

        path = []
        while node_id:
            path.append(node_id)
            node_id = self.parents[node_id]
        path.reverse()
        return tuple(path)

    def route_steps(self, node_id: int) -> Iterator[tuple[Node, Node]]:
        """Chronological ``(before, after)`` pairs down to ``node_id``."""

        return pairwise(self.route_to_node(node_id))

    def route_to_node(self, node_id: int) -> list[Node,]:
        """Returns the route (list of id of nodes) to from the node current node to the
        root node.

        :param node_id: The id of the current node.
        :return: The list of nodes.
        """

        return [self.nodes[i] for i in self.route_node_ids(node_id)]

    def synthesis_route(self, node_id: int) -> tuple[Reaction,]:
        """Given a node_id, return a tuple of reactions that represent the
        retrosynthetic route from the current node.

        Molecules keep the coordinates the reactor gave them, so a precursor still
        sits where its atoms sat in the product. Callers that need a layout of their
        own call ``clean2d()`` themselves.

        :param node_id: The id of the current node.
        :return: The tuple of extracted reactions representing the synthesis route.
        """

        reconstructed = getattr(self.nodes[node_id], "reconstructed_route", None)
        if reconstructed is not None:
            return tuple(step.reaction for step in reconstructed.steps)
        reaction_sequence = [
            Reaction(
                [x.molecule for x in after.new_precursors],
                [before.curr_precursor.molecule],
                meta={
                    "stereo_events": list(after.stereo_events),
                    "stereo_obligations": list(after.stereo_obligations.local)
                    if after.stereo_obligations is not before.stereo_obligations
                    else [],
                    "stereo_evidence": list(after.stereo_evidence),
                    "selectivity_evidence_status": "not_evaluated",
                },
            )
            for after_node_id, (before, after) in zip(
                self.route_node_ids(node_id)[1:], self.route_steps(node_id)
            )
        ]

        return tuple(reversed(reaction_sequence))

    def newickify(self, visits_threshold: int = 0, root_node_id: int = 1):
        """
        Adopted from https://stackoverflow.com/questions/50003007/how-to-convert-python-dictionary-to-newick-form-format.

        :param visits_threshold: The minimum number of visits for the given node.
        :param root_node_id: The id of the root node.

        :return: The newick string and meta dict.
        """
        visited_nodes = set()

        def newick_render_node(current_node_id: int) -> str:
            """Recursively generates a Newick string representation of the tree.

            :param current_node_id: The id of the current node.
            :return: A string representation of a node in a Newick format.
            """
            assert current_node_id not in visited_nodes, (
                "Error: The tree may not be circular!"
            )
            node_visit = self.nodes[current_node_id].visit

            visited_nodes.add(current_node_id)
            if self.children[current_node_id]:
                # Nodes
                children = [
                    child
                    for child in list(self.children[current_node_id])
                    if self.nodes[child].visit >= visits_threshold
                ]
                children_strings = [newick_render_node(child) for child in children]
                children_strings = ",".join(children_strings)
                if children_strings:
                    return f"({children_strings}){current_node_id}:{node_visit}"
                # leafs within threshold
                return f"{current_node_id}:{node_visit}"

            return f"{current_node_id}:{node_visit}"

        newick_string = newick_render_node(root_node_id) + ";"

        meta = {}
        for node_id in iter(visited_nodes):
            node = self.nodes[node_id]
            node_value = round(node.total_value, 3)

            node_synthesisability = round(node.init_value)

            visit_in_node = node.visit
            meta[node_id] = (node_value, node_synthesisability, visit_in_node)

        return newick_string, meta

    # ------------------------------------------------------------------
    # Analysis methods
    # ------------------------------------------------------------------

    def winning_rule_ranks(self) -> list[dict]:
        """For each winning route, return the rule rank and probability at each step.

        When available, the rank is the exact 1-indexed position of the chosen
        policy rule in the model's Top-N prediction list. If that value is not
        stored for a node, the rank falls back to a sibling-probability
        approximation.

        :return: List of dicts, one per winning route, each containing
            ``winning_node_id`` and ``steps`` (list of per-step dicts with
            node_id, rule_id, prob, rank).
        """
        results = []
        for win_id in self.winning_nodes:
            steps = []
            nid = win_id
            while nid and nid != 1:
                parent_id = self.parents[nid]
                node = self.nodes[nid]
                rule_id = node.rule_id
                prob = node.prob

                rank = node.policy_rank
                if rank is None:
                    siblings = self.children.get(parent_id, set())
                    rank = 1 + sum(
                        1
                        for sib in siblings
                        if sib != nid and self.nodes[sib].prob > prob
                    )

                steps.append(
                    {
                        "node_id": nid,
                        "rule_id": rule_id,
                        "rule_source": node.rule_source,
                        "rule_key": node.rule_key,
                        "policy_rank": node.policy_rank,
                        "prob": round(prob, 6),
                        "rank": rank,
                    }
                )
                nid = parent_id

            results.append(
                {
                    "winning_node_id": win_id,
                    "steps": list(reversed(steps)),
                }
            )
        return results

    def rule_applicability_rate(self) -> float:
        """Fraction of tried rules that produced valid products.

        :return: Float in [0, 1], or 0.0 if no rules were tried.
        """
        tried = self.stats.total_rules_tried
        if tried == 0:
            return 0.0
        return self.stats.total_rules_succeeded / tried

    def branching_profile(self) -> dict[int, dict]:
        """Compute mean branching factor per depth level (expanded nodes only).

        :return: Dict mapping depth -> {"mean_children": float, "nodes": int}.
        """
        from collections import defaultdict

        depth_children: dict[int, list[int]] = defaultdict(list)
        for nid in self.expanded_nodes:
            depth = self.nodes[nid].depth
            n_children = len(self.children.get(nid, set()))
            depth_children[depth].append(n_children)

        return {
            depth: {
                "mean_children": round(sum(counts) / len(counts), 2),
                "nodes": len(counts),
            }
            for depth, counts in sorted(depth_children.items())
        }

    def step_metadata(self, node_id: int) -> dict[int, dict]:
        """The rule behind each step of a route, keyed by step number.

        :meth:`route_details` numbers steps from the target down; a route numbers
        them from the deepest step up, so the two run opposite ways and this is
        where they are reconciled.

        :raises ValueError: if ``node_id`` is not a node of this tree.
        """

        steps = self.route_details(node_id).get("steps", [])
        return {
            len(steps) - 1 - index: {
                "step_id": len(steps) - 1 - index,
                "tree_node_id": step.get("node_id"),
                "rule_id": step.get("rule_id"),
                "rule_source": step.get("rule_source"),
                "rule_key": step.get("rule_key"),
            }
            for index, step in enumerate(steps)
        }

    def route_details(self, node_id: int) -> dict:
        """Get full details about a route ending at the given node.

        :param node_id: The id of the terminal (winning) node.
        :return: Dict with route_score, route_length, and per-step details.
        :raises ValueError: if ``node_id`` is not a node of this tree.
        """
        if node_id not in self.nodes:
            raise ValueError(_not_a_node(node_id))
        route_ids = self.route_node_ids(node_id)
        steps = []
        for route_node_id in route_ids[1:]:
            node = self.nodes[route_node_id]
            steps.append(
                {
                    "node_id": route_node_id,
                    "depth": node.depth,
                    "rule_id": node.rule_id,
                    "rule_source": node.rule_source,
                    "rule_key": node.rule_key,
                    "policy_rank": node.policy_rank,
                    "prob": round(node.prob, 6),
                    "init_value": round(node.init_value, 4),
                    "total_value": round(node.total_value, 4),
                    "visits": node.visit,
                    "is_solved": node.is_solved(),
                    "n_precursors": len(node.new_precursors),
                }
            )

        return {
            "node_id": node_id,
            "route_score": round(self.route_score(node_id), 6),
            "route_length": len(steps),
            "steps": steps,
        }

    def to_stats_dict(self) -> dict:
        """Return a flat dict with all tree statistics for CSV/JSON export.

        Combines basic tree metrics with policy analytics and search dynamics.
        """
        # Branching stats
        all_children_counts = [
            len(self.children.get(nid, set())) for nid in self.expanded_nodes
        ]
        max_bf = max(all_children_counts) if all_children_counts else 0
        mean_bf = (
            round(sum(all_children_counts) / len(all_children_counts), 2)
            if all_children_counts
            else 0.0
        )

        # Best route info
        best_score = None
        mean_winning_rank = None
        if self.winning_nodes:
            best_score = round(
                max(self.route_score(nid) for nid in self.winning_nodes), 6
            )
            ranks_info = self.winning_rule_ranks()
            all_ranks = [
                step["rank"] for route in ranks_info for step in route["steps"]
            ]
            if all_ranks:
                mean_winning_rank = round(sum(all_ranks) / len(all_ranks), 2)

        # A "priority" step is any step whose rule_source is not the policy
        # bucket. With multi-source priority sets, each set's name lives in
        # rule_source; this check folds them together for the aggregate.
        n_routes_with_priority = 0
        for route_id in self.winning_nodes:
            nid = route_id
            while nid and nid != 1:
                src = self.nodes[nid].rule_source
                if src is not None and src != POLICY_SOURCE_NAME:
                    n_routes_with_priority += 1
                    break
                nid = self.parents[nid]
        fraction_routes_with_priority = (
            n_routes_with_priority / len(self.winning_nodes)
            if self.winning_nodes
            else 0.0
        )

        per_priority_source = {
            name: {"tried": counters.tried, "succeeded": counters.succeeded}
            for name, counters in self.stats.per_priority_source.items()
        }

        return {
            # Existing basics
            "num_routes": len(self.winning_nodes),
            "num_nodes": len(self),
            "num_iter": self.curr_iteration,
            "tree_depth": (
                max(n.depth for n in self.nodes.values()) if self.nodes else 0
            ),
            "search_time": round(self.curr_time, 1),
            "solved": len(self.winning_nodes) > 0,
            "stereo_proposals": len(self.proposal_nodes),
            "stereo_incompatible_outcomes": self.stats.stereo_incompatible_outcomes,
            "stereo_unresolved_outcomes": self.stats.stereo_unresolved_outcomes,
            "stereo_incomplete_assessments": self.stats.stereo_incomplete_assessments,
            # Policy performance
            "expansion_calls": self.stats.expansion_calls,
            "unique_expanded_molecules": len(self._expanded_molecule_keys),
            "unique_expanded_states": len(self._expanded_state_keys),
            "iterations_without_expansion": self.stats.iterations_without_expansion,
            "root_disconnections": len(self.children[1]),
            "solved_root_disconnections": len(
                {
                    self.route_node_ids(node_id)[1]
                    for node_id in self.winning_nodes
                    if node_id != 1
                }
            ),
            "expansion_successes": self.stats.expansion_successes,
            "total_rules_tried": self.stats.total_rules_tried,
            "total_rules_succeeded": self.stats.total_rules_succeeded,
            "policy_rules_tried": self.stats.policy_rules_tried,
            "policy_rules_succeeded": self.stats.policy_rules_succeeded,
            "rule_applicability_rate": round(self.rule_applicability_rate(), 4),
            "dead_end_nodes": self.stats.dead_end_nodes,
            # Priority rules usage
            "priority_rules_tried": self.stats.priority_rules_tried,
            "priority_rules_succeeded": self.stats.priority_rules_succeeded,
            "per_priority_source": per_priority_source,
            "n_routes_with_priority": n_routes_with_priority,
            "fraction_routes_with_priority": fraction_routes_with_priority,
            # Search dynamics
            "first_solution_iteration": self.stats.first_solution_iteration,
            "first_solution_time": self.stats.first_solution_time,
            # Tree shape
            "max_branching_factor": max_bf,
            "mean_branching_factor": mean_bf,
            # Route quality
            "best_route_score": best_score,
            "mean_winning_rule_rank": mean_winning_rank,
        }

    def __getattr__(self, name: str):
        if name in _REMOVED_NODE_ATTRS:
            new_api, version = _REMOVED_NODE_ATTRS[name]
            raise AttributeError(
                f"Tree.{name} was removed in {version}. "
                f"Use {new_api} instead. "
                f"See the {version} CHANGELOG entry."
            )
        raise AttributeError(f"'Tree' object has no attribute {name!r}")
