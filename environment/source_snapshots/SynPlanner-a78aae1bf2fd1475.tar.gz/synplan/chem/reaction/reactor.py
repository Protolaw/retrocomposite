"""Module containing classes and functions for manipulating reactions and reaction
rules."""

import logging
from collections.abc import Iterator
from copy import copy, deepcopy
from typing import Any

from chython.containers import MoleculeContainer, ReactionContainer, SynthonContainer
from chython.exceptions import InvalidAromaticRing
from chython.reactor import Reactor

from synplan.chem.mapping import (
    MappingBudget,
    MappingBudgetExceeded,
    bounded_query,
    mapping_budget,
)
from synplan.chem.stereo import (
    assert_stereo_preserved,
    assign_stereo,
    has_stereo,
    stereo_requirements,
)
from synplan.chem.utils import safe_canonicalization, validate_and_canonicalize

logger = logging.getLogger(__name__)


class Reaction(ReactionContainer):
    """Reaction class used for a general representation of reaction."""


class CanonicalRetroReactor(Reactor):
    """Reactor subclass that emits **already-canonical** products in a
    single aromatization pass.

    Subclasses :class:`chython.reactor.Reactor` with
    ``fix_aromatic_rings=False`` so the inner ``_patcher`` skips its
    own ``kekule + thiele``; we inline the full canonicalize pipeline
    here instead. Result: ``kekule`` and ``thiele`` each run once per
    product (vs twice in the legacy wrapper + canonicalize pattern).

    Failures raise ``InvalidAromaticRing``, which chython's
    ``_single_stage`` catches and skips silently.
    """

    def __init__(self, *args, **kwargs):
        kwargs["fix_tautomers"] = True
        kwargs["fix_aromatic_rings"] = False  # we run all aromatization in _patcher
        if args:
            args = (tuple(bounded_query(q) for q in args[0]), *args[1:])
        elif "patterns" in kwargs:
            kwargs["patterns"] = tuple(bounded_query(q) for q in kwargs["patterns"])
        super().__init__(*args, **kwargs)

    def _patcher(
        self, structure: MoleculeContainer, mapping: dict[int, int]
    ) -> MoleculeContainer:
        from synplan.chem.mapping import backend_preparation

        with backend_preparation():
            return self.canonical_patch(structure, mapping)

    def canonical_patch(self, structure, mapping):
        new = super()._patcher(structure, mapping)
        patched = new.copy() if has_stereo(new) else None

        new.kekule(ignore_pyrrole_hydrogen=self._fix_broken_pyrroles)

        if new.check_valence():
            # ValenceError would escape; InvalidAromaticRing is caught.
            raise InvalidAromaticRing("patched molecule has invalid valence")

        new.standardize(_fix_stereo=False)
        new.implicify_hydrogens(_fix_stereo=False)
        if not new.thiele(fix_tautomers=self._fix_tautomers):
            new.fix_stereo()
        new.standardize_charges(prepare_molecule=False)
        new.standardize_tautomers(prepare_molecule=False)
        if patched is not None:
            assert_stereo_preserved(patched, new)

        return new


def add_small_mols(
    big_mol: MoleculeContainer, small_molecules: Any | None = None
) -> list[MoleculeContainer]:
    """Takes a molecule and returns a list of modified molecules where each small
    molecule has been added to the big molecule.

    :param big_mol: A molecule.
    :param small_molecules: A list of small molecules that need to be added to the
        molecule.
    :return: Returns a list of molecules.
    """
    if small_molecules:
        tmp_mol = big_mol.copy()
        transition_mapping = {}
        for small_mol in small_molecules:
            for n, atom in small_mol.atoms():
                new_number = tmp_mol.add_atom(atom.copy())
                transition_mapping[n] = new_number

            for atom, neighbor, bond in small_mol.bonds():
                tmp_mol.add_bond(
                    transition_mapping[atom], transition_mapping[neighbor], bond
                )

            transition_mapping = {}
        return tmp_mol.split()

    return [big_mol]


def stereo_free_rule(rule):
    """Project a reactor once per tree, preserving its non-stereo options.

    Chython exposes no reactor projection API; its cached replacement must be
    cleared alongside the input/output templates. Never mutate shared rules.
    """
    if not any(has_stereo(q) for q in (*rule._patterns, *rule._products)):
        return rule
    rule = deepcopy(rule)
    for query in (*rule._patterns, *rule._products, rule._replacement):
        if isinstance(query, MoleculeContainer):
            query.clean_stereo()
            continue
        for _, atom in query.atoms():
            atom._stereo = None
        for *_, bond in query.bonds():
            bond._stereo = None
        query.flush_cache()
    return rule


def apply_reaction_rule(
    molecule: MoleculeContainer,
    reaction_rule: "CanonicalRetroReactor",
    sort_reactions: bool = False,
    top_reactions_num: int = 5,
    rebuild_with_cgr: bool = False,
    multirule: bool = False,
    rm_dup: bool = False,
    co_reactants: tuple[MoleculeContainer, ...] = (),
    max_mapping_work: int = 100_000,
    diagnostics: list[dict] | None = None,
) -> Iterator[list[MoleculeContainer,]]:
    """Applies a reaction rule to a given molecule.

    The yielded precursors are always in canonical form — either
    produced directly by :class:`CanonicalRetroReactor._patcher`
    (default path) or canonicalized via
    :func:`synplan.chem.utils.validate_and_canonicalize` when the CGR
    rebuild path is used. Callers can wrap them with
    ``Precursor(mol, canonicalize=False)`` without further work.

    :param molecule: A molecule to which reaction rule will be applied.
    :param reaction_rule: A :class:`CanonicalRetroReactor`. (Any chython
        ``Reactor`` instance also works mechanically but the yielded
        precursors won't be canonicalized — only ``CanonicalRetroReactor``
        is supported by SynPlanner's MCTS state-dedup contract.)
    :param sort_reactions: If True, candidate reactions are sorted by the
        number of large product fragments (length > 6) before truncation.
    :param top_reactions_num: The maximum amount of reactions after the
        application of reaction rule. **Default raised from 3 → 5 in 1.5.0**;
        callers that depended on the previous default must pass
        ``top_reactions_num=3`` explicitly.
    :param rebuild_with_cgr: If True, products are re-derived by composing
        the reaction into a CGR and decomposing it (recovery path for
        cases where the reactor's direct output has mapping or mass-
        balance issues). The CGR-rebuilt fragments are canonicalized
        explicitly via ``validate_and_canonicalize``; otherwise the
        reactor's already-canonical products are yielded directly.
    :param multirule: If True, repeatedly applies the reaction rule to generated
        reactants in a BFS-style loop until no new reactant set is produced.
        Used for priority rules that should iterate (e.g. strip every protective
        group of a given kind from a fully-protected substrate).
    :param rm_dup: If True, removes duplicate reactant sets from yielded outputs
        using a canonical-SMILES dedup key. Recommended whenever ``multirule``
        is set.
    :param co_reactants: Extra structures handed to the rule alongside
        ``molecule``. A retro rule is unimolecular on its reactant side, so the
        default empty tuple is the whole of retrosynthesis; a **forward**
        bimolecular rule needs both partners at once and matches nothing when
        handed one structure — it yields zero reactions, silently. Partner
        *selection* is the caller's problem: this only forwards what it is
        given. No caller supplies it today — in particular
        :class:`~synplan.mcts.tree.Tree` expands without it, so a
        ``direction="forward"`` search runs unimolecular rules only.
    :return: An iterator yielding the products of reaction rule application.
    :raises TypeError: if ``molecule`` carries synthon labels.
        ``QueryElement.__eq__`` never consults ``_label``, so a plain reactor
        matches a labelled synthon and emits unlabelled products — the labels
        vanish with no error. A caller holding a labelled synthon must strip
        the labels or stop, not expand it here.
    """
    if isinstance(molecule, SynthonContainer) and molecule.synthon_labels:
        raise TypeError(
            f"refusing to apply a label-blind reaction rule to the labelled "
            f"synthon {molecule}: it would silently strip the labels"
        )

    work_budget = MappingBudget(max_mapping_work)
    if isinstance(reaction_rule, Reactor) and not isinstance(
        reaction_rule, CanonicalRetroReactor
    ):
        reaction_rule = copy(reaction_rule)
        reaction_rule._patterns = tuple(
            bounded_query(q) for q in reaction_rule._patterns
        )

    def _collect_reactions(
        current_molecule: MoleculeContainer,
    ) -> list[ReactionContainer]:
        reactants = add_small_mols(current_molecule, small_molecules=co_reactants)
        reactions = []
        try:
            # The budget applies before any successful match/product is yielded.
            with mapping_budget(max_mapping_work, budget=work_budget):
                for reaction in reaction_rule(*reactants):
                    reactions.append(reaction)
                    if not sort_reactions and len(reactions) == top_reactions_num:
                        break
        except MappingBudgetExceeded as error:
            if diagnostics is not None:
                diagnostics.append(
                    {"reason": "mapping_budget_exceeded", "detail": str(error)}
                )
            else:
                logger.warning("Incomplete rule application: %s", error)
        except (IndexError, InvalidAromaticRing, ValueError):
            pass
        # Earlier valid outcomes survive exhaustion or a later invalid match.
        if sort_reactions:
            reactions.sort(
                key=lambda react: sum(len(m) > 6 for m in react.products), reverse=True
            )
        return reactions[:top_reactions_num]

    def _prepare_reactants(
        reaction: ReactionContainer,
    ) -> list[MoleculeContainer] | None:
        # temporary solution - incorrect leaving groups
        reactant_atom_nums = []
        for reactant in reaction.reactants:
            reactant_atom_nums.extend(reactant.atoms_numbers)
        product_atom_nums = []
        for product in reaction.products:
            product_atom_nums.extend(product.atoms_numbers)
        leaving_atom_nums = set(reactant_atom_nums) - set(product_atom_nums)
        if len(leaving_atom_nums) > len(product_atom_nums):
            return None

        if rebuild_with_cgr:
            # CGR recovery path bypasses _patcher; canonicalize per fragment.
            # chython.compose raises ValueError on element-substitution rules.
            try:
                cgr = reaction.compose()
                reactants = cgr.decompose()[1].split()
            except (ValueError, InvalidAromaticRing):
                return None
            reactants = [mol for mol in reactants if len(mol) > 0]
            canon = []
            for mol in reactants:
                # A CGR contains bond edits, not stereo. Restore the mapped
                # direct output before normalizing or accepting this recovery.
                for original in reaction.products:
                    for req in stereo_requirements(original):
                        if all(mol.has_atom(n) for n in (*req.atoms, *req.environment)):
                            assign_stereo(mol, req)
                c = validate_and_canonicalize(mol)
                if c is None:
                    return None
                c.meta.update(mol.meta)
                canon.append(c)
            return canon

        return [mol for mol in reaction.products if len(mol) > 0]

    def _reactants_key(reactants: list[MoleculeContainer]) -> tuple[str, ...]:
        return tuple(sorted(str(reactant) for reactant in reactants))

    track_keys = rm_dup or multirule
    seen_reactants: set[tuple[str, ...]] = set()
    pending_reactants: list[list[MoleculeContainer]] = [[molecule]]
    expanded_keys: set[tuple[str, ...]] = (
        {_reactants_key([molecule])} if multirule else set()
    )
    pending_index = 0

    while pending_index < len(pending_reactants):
        current_reactants = pending_reactants[pending_index]
        pending_index += 1

        for mol_index, current_molecule in enumerate(current_reactants):
            for reaction in _collect_reactions(current_molecule):
                new_reactants = _prepare_reactants(reaction)
                if new_reactants is None:
                    continue

                merged_reactants = [
                    reactant
                    for idx, reactant in enumerate(current_reactants)
                    if idx != mol_index
                ]
                merged_reactants.extend(new_reactants)
                merged_reactants = [
                    reactant for reactant in merged_reactants if len(reactant) > 0
                ]

                reactants_key = _reactants_key(merged_reactants) if track_keys else None

                if rm_dup and reactants_key in seen_reactants:
                    continue

                if rm_dup:
                    seen_reactants.add(reactants_key)
                _warn_if_not_canonical(merged_reactants)
                yield merged_reactants

                if multirule and reactants_key not in expanded_keys:
                    expanded_keys.add(reactants_key)
                    pending_reactants.append(merged_reactants)

        if not multirule:
            break


def reaction_rules_appliance(
    molecule: MoleculeContainer, reaction_rules: list[CanonicalRetroReactor]
) -> tuple[list[int], list[int]]:
    """Applies each reaction rule from the list of reaction rules to a given molecule
    and returns the indexes of the successfully applied regular and prioritized reaction
    rules.

    :param molecule: The input molecule.
    :param reaction_rules: The list of reaction rules.
    :return: The two lists of indexes of successfully applied regular reaction rules and
        priority reaction rules.
    """

    applied_rules, priority_rules = [], []
    for i, rule in enumerate(reaction_rules):
        rule_applied = False
        rule_prioritized = False

        try:
            for reaction in rule([molecule]):
                for prod in reaction.products:
                    tmp_prod = prod.copy()
                    tmp_prod.remove_coordinate_bonds(keep_to_terminal=False)
                    tmp_prod.kekule()
                    if tmp_prod.check_valence():
                        break
                    rule_applied = True

                    # check priority rules
                    if len(reaction.products) > 1:
                        # check coupling retro manual
                        if all(len(mol) > 6 for mol in reaction.products):
                            if (
                                sum(len(mol) for mol in reaction.products)
                                - len(reaction.reactants[0])
                                < 6
                            ):
                                rule_prioritized = True
                    else:
                        # check cyclization retro manual
                        if sum(len(mol.sssr) for mol in reaction.products) < sum(
                            len(mol.sssr) for mol in reaction.reactants
                        ):
                            rule_prioritized = True
            #
            if rule_applied:
                applied_rules.append(i)
                #
                if rule_prioritized:
                    priority_rules.append(i)
        except Exception as e:
            logger.debug(e)
            continue

    return applied_rules, priority_rules


def _warn_if_not_canonical(precursors: list[MoleculeContainer]) -> None:
    """Report a precursor this library would not have written itself.

    Off unless this module's logger is set to ``DEBUG``: the only way to tell is to
    canonicalize, and canonicalizing every precursor costs the search about a tenth
    of its time. Turn it on when hunting::

        logging.getLogger("synplan.chem.reaction.reactor").setLevel(logging.DEBUG)

    The reactor canonicalizes the whole patched molecule, but what is yielded are
    its fragments, and a fragment on its own does not always canonicalize the way
    it did inside the whole -- three per celecoxib search, all of them a ring
    hydrogen the canonicalizer puts on the other nitrogen, e.g.
    ``FC(F)(F)c1[nH]nc(-c2ccc(cc2)C)c1``. Aromatic either way, so no aromaticity
    check can see them.

    Nothing is repaired here. A repair hides where the molecule came from, and the
    point of saying so is to be able to go and look -- at a building-block file, a
    target, or a rule's own SMILES.

    Aromaticity is the usual suspect and is usually innocent. None of these is
    reported, because each comes out canonical:

    * ``OCc1cc(=O)c2ccccc2n1C`` with ``[C:1]-[O;h1:2]>>[C:1]=[O:2]`` --
      1-methyl-2-(hydroxymethyl)quinolin-4(1H)-one. The pyridinone ring comes out
      kekulized because RDKit aromatises 4-quinolinones and chython does not, so
      the input arrived claiming an aromaticity this model rejects. This is the
      case the old aromaticity restorer existed for, and restoring it produced a
      molecule ``canonicalize`` disagreed with.
    * ``FC(F)(F)c1[nH]nc(c1Br)C`` with ``[c:1]-[Br:2]>>[c:1]-[O:2]`` -- the rule
      itself turns the pyrazole into a pyrazolone, which chython does not hold
      aromatic.
    * ``FC(F)(F)c1cc(OS(=O)(=O)C(F)(F)F)n(n1)-c2ccc(cc2)S(=O)(=O)N`` losing its
      triflate -- the patcher leaves an aromatic 5-hydroxypyrazole and
      ``standardize_tautomers`` moves it to the pyrazolone.
    """
    if not logger.isEnabledFor(logging.DEBUG):
        return
    for molecule in precursors:
        canonical = str(safe_canonicalization(molecule))
        if str(molecule) != canonical:
            logger.debug(
                "precursor %s is not canonical; the canonicalizer writes it %s",
                molecule,
                canonical,
            )
