"""Module containing functions for preparation of the training sets for policy and value
network."""

import logging
import os
from abc import ABC
from concurrent.futures.process import BrokenProcessPool

import torch
from chython import smiles
from chython.containers import MoleculeContainer
from torch import Tensor
from torch_geometric.data import InMemoryDataset
from torch_geometric.data.data import Data
from tqdm.auto import tqdm

from synplan.chem.reaction.reactor import reaction_rules_appliance
from synplan.ml.featurization.molecules import mol_to_pyg
from synplan.utils.cache import load_pyg_dataset, save_pyg_dataset
from synplan.utils.loading import load_reaction_rules
from synplan.utils.parallel import chunked, default_num_workers, process_pool_map_stream

logger = logging.getLogger(__name__)

_RANKING_POLICY_PARALLEL_BATCH_SIZE = 1000
RankingGraphPayload = tuple[
    list[list[int]],
    list[list[int]],
    list[list[float]],
    int,
    str,
]


class ValueNetworkDataset(InMemoryDataset, ABC):
    """Value network dataset."""

    def __init__(self, extracted_precursor: dict[str, float]) -> None:
        """Initializes a value network dataset object.

        :param extracted_precursor: The dictionary with the extracted from the built
            search trees precursor and their labels.
        """
        super().__init__(None, None, None)

        if extracted_precursor:
            self.data, self.slices = self.graphs_from_extracted_precursor(
                extracted_precursor
            )

    @staticmethod
    def mol_to_graph(molecule: MoleculeContainer, label: float) -> Data | None:
        """Takes a molecule as input, and converts the molecule to a PyTorch geometric
        graph, assigns the reward value (label) to the graph, and returns the graph.

        :param molecule: The input molecule.
        :param label: The label (solved/unsolved routes in the tree) of the molecule
            (precursor).
        :return: A PyTorch Geometric graph representation of a molecule.
        """
        if len(molecule) > 2:
            pyg = mol_to_pyg(molecule)
            if pyg:
                pyg.y = torch.tensor([label])
                return pyg

        return None

    def graphs_from_extracted_precursor(
        self, extracted_precursor: dict[str, float]
    ) -> tuple[Data, dict]:
        """Converts the extracted from the search trees precursor to the PyTorch geometric
        graphs.

        :param extracted_precursor: The dictionary with the extracted from the built
            search trees precursor and their labels.
        :return: The PyTorch geometric graphs and slices.
        """
        processed_data = []
        for smi, label in extracted_precursor.items():
            mol = smiles(smi)
            pyg = self.mol_to_graph(mol, label)
            if pyg:
                processed_data.append(pyg)
        data, slices = self.collate(processed_data)
        return data, slices


def convert_ranking_item(item: tuple[str, str]) -> tuple[Data, str] | None:
    """Convert a (product_smiles, rule_id_str) pair into a labelled PyG graph.

    Module-level function so it can be pickled by :class:`ProcessPoolExecutor`.
    Returns ``(pyg_graph, product_smiles)`` or ``None`` on failure.
    """
    product_smi, rule_id_str = item
    try:
        molecule = smiles(product_smi)
        pyg_graph = mol_to_pyg(molecule)
        if pyg_graph is not None:
            pyg_graph.y_rules = torch.tensor([int(rule_id_str)], dtype=torch.long)
            return pyg_graph, product_smi
    except Exception:
        return None
    return None


def _ranking_graph_to_payload(graph: Data, product_smi: str) -> RankingGraphPayload:
    """Serialize a ranking graph without torch objects for process-pool IPC.

    PyTorch tensors crossing a multiprocessing boundary are transferred via
    shared-memory file descriptors. Large ranking batches can therefore hit
    ``Too many open files`` while unpickling results in the parent process.
    Keep worker payloads as plain Python lists and reconstruct tensors in the
    parent instead.
    """
    return (
        graph.x.tolist(),
        graph.edge_index.tolist(),
        graph.edge_attr.tolist(),
        int(graph.y_rules.reshape(-1)[0].item()),
        product_smi,
    )


def _ranking_payload_to_graph(payload: RankingGraphPayload) -> tuple[Data, str]:
    """Rebuild a PyG graph from the plain-Python worker payload."""
    x, edge_index, edge_attr, rule_id, product_smi = payload
    graph = Data(
        x=torch.tensor(x, dtype=torch.uint8),
        edge_index=torch.tensor(edge_index, dtype=torch.long).reshape(2, -1),
        edge_attr=torch.tensor(edge_attr, dtype=torch.float).reshape(-1, 4),
    )
    graph.y_rules = torch.tensor([rule_id], dtype=torch.long)
    return graph, product_smi


def _convert_ranking_batch(
    batch: list[tuple[str, str]],
) -> tuple[int, list[RankingGraphPayload]]:
    """Convert a batch of ranking policy rows inside one worker process.

    Returning batches amortizes ProcessPool IPC overhead.
    The first tuple element is the number of input rows, so the parent can update
    progress even when some rows fail conversion and produce no graph.
    """
    converted: list[RankingGraphPayload] = []
    for item in batch:
        result = convert_ranking_item(item)
        if result is not None:
            converted.append(_ranking_graph_to_payload(result[0], result[1]))
    return len(batch), converted


class RankingPolicyDataset(InMemoryDataset):
    """Ranking policy network dataset.

    Reads a policy training mapping file (TSV with ``product_smiles`` and
    ``rule_id`` columns) produced by :func:`extract_rules_from_reactions`.
    """

    def __init__(self, policy_data_path: str, output_path: str, num_workers: int = 0):
        """Initializes a ranking policy network dataset.

        :param policy_data_path: Path to the policy training mapping file
            (``*_policy_data.tsv``) generated during rule extraction.
        :param output_path: Path where the cached PyG dataset will be saved.
        :param num_workers: CPU workers for parallel graph conversion.
            ``0`` auto-detects via :func:`default_num_workers`.
        """
        super().__init__(None, None, None)

        self.policy_data_path = policy_data_path
        self.output_path = output_path
        self.num_workers = num_workers
        self._product_keys: list[str] | None = None

        if output_path and os.path.exists(output_path):
            data, slices, product_keys, self._sf_handle = load_pyg_dataset(output_path)
            self.data, self.slices = data, slices
            self._product_keys = product_keys
        else:
            self.data, self.slices = self.prepare_data()

    @property
    def num_classes(self) -> int:
        return self._infer_num_classes(self._data.y_rules)

    def prepare_data(self) -> tuple[Data, dict[str, Tensor]]:
        """Reads the policy mapping file and converts product SMILES to PyG graphs.

        :return: The collated PyTorch Geometric data and slices.
        """
        # 1. Read TSV into a list of (smiles, rule_id) pairs
        items: list[tuple[str, str]] = []
        with open(self.policy_data_path, encoding="utf-8") as f:
            f.readline()  # skip header
            for line in f:
                parts = line.rstrip("\n").split("\t")
                items.append((parts[0], parts[1]))

        # 2. Convert molecules to PyG graphs
        # Parallel only helps for large datasets; for small ones the process
        # spawn + PyG Data pickling overhead dominates (especially on macOS).
        _MIN_ITEMS_FOR_PARALLEL = 5000
        workers = self.num_workers if self.num_workers > 0 else default_num_workers()
        if len(items) < _MIN_ITEMS_FOR_PARALLEL:
            workers = 1
        list_of_graphs: list[Data] = []
        product_keys: list[str] = []

        def _collect_serial():
            for item in tqdm(
                items,
                desc="Building policy dataset: ",
                bar_format="{desc}{n}/{total} [{elapsed}]",
            ):
                result = convert_ranking_item(item)
                if result is not None:
                    list_of_graphs.append(result[0])
                    product_keys.append(result[1])

        if workers <= 1:
            _collect_serial()
        else:
            try:
                batches = chunked(items, _RANKING_POLICY_PARALLEL_BATCH_SIZE)
                results = process_pool_map_stream(
                    batches,
                    _convert_ranking_batch,
                    max_workers=workers,
                    max_pending=max(1, workers * 2),
                )
                with tqdm(
                    total=len(items),
                    desc=f"Building policy dataset ({workers} workers): ",
                    bar_format="{desc}{n}/{total} [{elapsed}]",
                ) as progress:
                    for processed_count, batch_results in results:
                        progress.update(processed_count)
                        for payload in batch_results:
                            graph, product_smi = _ranking_payload_to_graph(payload)
                            list_of_graphs.append(graph)
                            product_keys.append(product_smi)
            except BrokenProcessPool as exc:
                raise RuntimeError(
                    "Parallel ranking policy dataset build failed before "
                    "completion. Refusing silent serial fallback because it "
                    "hides worker crashes and can turn this stage into a "
                    "single-core run; rerun with --workers 1 only for "
                    "diagnostics."
                ) from exc

        self._product_keys = product_keys
        data, slices = self.collate(list_of_graphs)
        if self.output_path:
            save_pyg_dataset(self.output_path, data, slices, product_keys=product_keys)

        return data, slices


class FilteringPolicyDataset(InMemoryDataset):
    """Filtering policy network dataset."""

    def __init__(
        self,
        molecules_path: str,
        reaction_rules_path: str,
        output_path: str,
        num_cpus: int,
    ) -> None:
        """Initializes a policy network dataset object.

        :param molecules_path: The path to the file containing the molecules for
            reaction rule appliance.
        :param reaction_rules_path: The path to the file containing the reaction rules.
        :param output_path: The output path to the file where policy network dataset
            will be stored.
        :param num_cpus: The number of CPUs to be used for the dataset preparation.
        :return: None.
        """
        super().__init__(None, None, None)

        self.molecules_path = molecules_path
        self.reaction_rules_path = reaction_rules_path
        self.output_path = output_path
        self.num_cpus = num_cpus
        self.batch_size = 100

        if output_path and os.path.exists(output_path):
            data, slices, _, self._sf_handle = load_pyg_dataset(output_path)
            self.data, self.slices = data, slices
        else:
            self.data, self.slices = self.prepare_data()

    @property
    def num_classes(self) -> int:
        return self._data.y_rules.shape[1]

    def prepare_data(self) -> tuple[Data, dict]:
        """Preprocesses molecules by applying reaction rules and converting them to
        PyTorch geometric graphs using a process pool.

        :return: The PyTorch geometric graphs and slices.
        """

        with open(self.molecules_path, encoding="utf-8") as inp_data:
            molecules = inp_data.read().splitlines()

        workers = self.num_cpus if self.num_cpus > 0 else default_num_workers()

        def _collect_serial():
            # Ensure module-level worker state is set for the serial path.
            global _worker_state
            _worker_state = load_reaction_rules(self.reaction_rules_path)
            try:
                results = []
                for mol_smi in tqdm(
                    molecules,
                    desc="Number of molecules processed: ",
                    bar_format="{desc}{n} [{elapsed}]",
                ):
                    result = _preprocess_filtering_policy_molecule(mol_smi)
                    if result is not None:
                        results.append(result)
                return results
            finally:
                _worker_state = None

        if workers <= 1:
            processed_data = _collect_serial()
        else:
            try:
                processed_data = []
                for result in tqdm(
                    process_pool_map_stream(
                        molecules,
                        _preprocess_filtering_policy_molecule,
                        max_workers=workers,
                        initializer=_init_filtering_worker,
                        initargs=(self.reaction_rules_path,),
                    ),
                    total=len(molecules),
                    desc=f"Number of molecules processed ({workers} workers): ",
                    bar_format="{desc}{n} [{elapsed}]",
                ):
                    if result is not None:
                        processed_data.append(result)
            except BrokenProcessPool as exc:
                raise RuntimeError(
                    "Parallel filtering policy dataset build failed before "
                    "completion. Refusing silent serial fallback because it "
                    "hides worker crashes and can turn this stage into a "
                    "single-core run; rerun with --num_cpus 1 only for "
                    "diagnostics."
                ) from exc

        for pyg in processed_data:
            pyg.y_rules = pyg.y_rules.to_dense()
            pyg.y_priority = pyg.y_priority.to_dense()

        data, slices = self.collate(processed_data)
        if self.output_path:
            save_pyg_dataset(self.output_path, data, slices)

        return data, slices


# Worker state and functions for FilteringPolicyDataset parallel processing.
_worker_state = None


def _init_filtering_worker(reaction_rules_path: str) -> None:
    """Initializer for each worker process in the filtering policy pool.

    Loads reaction rules once per worker and stores them in module-level
    ``_worker_state`` so that :func:`_preprocess_filtering_policy_molecule`
    can access them without re-loading on every call.
    """
    global _worker_state
    _worker_state = load_reaction_rules(reaction_rules_path)


def _preprocess_filtering_policy_molecule(molecule_smi: str) -> Data | None:
    """Preprocess a single molecule SMILES for filtering policy training.

    Applies all reaction rules loaded into ``_worker_state`` (set by
    :func:`_init_filtering_worker`) to the molecule, builds the sparse
    label tensors, and converts the molecule to a PyG graph.

    When running serially (no initializer), the function falls back to using
    the ``_worker_state`` that must have been set before calling.

    :param molecule_smi: SMILES string for the molecule.
    :return: A PyG :class:`Data` object with ``y_rules`` and ``y_priority``
        attributes, or ``None`` if parsing / conversion fails.
    """
    reaction_rules = _worker_state
    if reaction_rules is None:
        return None

    try:
        molecule = smiles(molecule_smi)
        if not isinstance(molecule, MoleculeContainer):
            return None

        # reaction rules application
        applied_rules, priority_rules = reaction_rules_appliance(
            molecule, reaction_rules
        )

        y_rules = torch.sparse_coo_tensor(
            [applied_rules],
            torch.ones(len(applied_rules)),
            (len(reaction_rules),),
            dtype=torch.uint8,
        )
        y_priority = torch.sparse_coo_tensor(
            [priority_rules],
            torch.ones(len(priority_rules)),
            (len(reaction_rules),),
            dtype=torch.uint8,
        )

        y_rules = torch.unsqueeze(y_rules, 0)
        y_priority = torch.unsqueeze(y_priority, 0)

        pyg_graph = mol_to_pyg(molecule)
        if not pyg_graph:
            return None
        pyg_graph.y_rules = y_rules
        pyg_graph.y_priority = y_priority
        return pyg_graph

    except Exception:
        return None
